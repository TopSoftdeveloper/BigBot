#pragma once
#include <Windows.h>

#define MAX_MESSAGE_LENGTH 32

typedef struct {
    char message[MAX_MESSAGE_LENGTH];  // Message buffer for "SHOW2ND" or "HIDE2ND"
    // Note: Mutex handles cannot be shared directly, use named mutex instead
} MonitorSharedMemoryData;

// Initialize shared memory (creates it)
BOOL InitSharedMemory();

// Release shared memory
void ReleaseSharedMemory();

// Send message to ScreenMirror application
BOOL SendMessageToMirror(const char* message);

// Send SHOW2ND message
BOOL ShowMirrorWindow();

// Send HIDE2ND message
BOOL HideMirrorWindow();
