#include <Windows.h>
#include <string.h>
#include "SharedMemoryHost.h"

HANDLE g_hMonitorMapFile = NULL;
MonitorSharedMemoryData* g_sharedMonitorData = NULL;
HANDLE g_hMutex = NULL;

// Initialize shared memory (creates it)
BOOL InitSharedMemory()
{
    // Create file mapping
    g_hMonitorMapFile = CreateFileMappingA(
        INVALID_HANDLE_VALUE,   // Use paging file
        NULL,                    // Default security
        PAGE_READWRITE,          // Read/write access
        0,                       // High-order DWORD of size
        sizeof(MonitorSharedMemoryData), // Low-order DWORD of size
        "OneMonitorMemory");     // Name of mapping object

    if (g_hMonitorMapFile == NULL) {
        return FALSE;
    }

    // Check if the file mapping already existed
    BOOL bAlreadyExists = (GetLastError() == ERROR_ALREADY_EXISTS);

    // Map view of file into address space
    g_sharedMonitorData = (MonitorSharedMemoryData*)MapViewOfFile(
        g_hMonitorMapFile,              // Handle to map object
        FILE_MAP_ALL_ACCESS,     // Read/write permission
        0,
        0,
        sizeof(MonitorSharedMemoryData));

    if (g_sharedMonitorData == NULL) {
        CloseHandle(g_hMonitorMapFile);
        g_hMonitorMapFile = NULL;
        return FALSE;
    }

    // Initialize shared data if we created it (not if it already existed)
    if (!bAlreadyExists) {
        // Create mutex
        g_hMutex = CreateMutexA(
            NULL,                 // Default security attributes
            FALSE,                // Initially not owned
            "OneMonitorMutex");   // Named mutex

        if (g_hMutex == NULL) {
            UnmapViewOfFile(g_sharedMonitorData);
            CloseHandle(g_hMonitorMapFile);
            g_hMonitorMapFile = NULL;
            g_sharedMonitorData = NULL;
            return FALSE;
        }

        // Initialize shared data
        g_sharedMonitorData->message[0] = '\0';
    }
    else {
        // If already exists, just open the mutex
        g_hMutex = OpenMutexA(MUTEX_ALL_ACCESS, FALSE, "OneMonitorMutex");
        if (g_hMutex == NULL) {
            UnmapViewOfFile(g_sharedMonitorData);
            CloseHandle(g_hMonitorMapFile);
            g_hMonitorMapFile = NULL;
            g_sharedMonitorData = NULL;
            return FALSE;
        }
    }

    return TRUE;
}

// Release shared memory
void ReleaseSharedMemory()
{
    if (g_sharedMonitorData != NULL) {
        UnmapViewOfFile(g_sharedMonitorData);
        g_sharedMonitorData = NULL;
    }

    if (g_hMonitorMapFile != NULL) {
        CloseHandle(g_hMonitorMapFile);
        g_hMonitorMapFile = NULL;
    }

    if (g_hMutex != NULL) {
        CloseHandle(g_hMutex);
        g_hMutex = NULL;
    }
}

// Send message to ScreenMirror application
BOOL SendMessageToMirror(const char* message)
{
    if (g_sharedMonitorData == NULL || g_hMutex == NULL) {
        return FALSE;
    }

    if (message == NULL || strlen(message) == 0) {
        return FALSE;
    }

    // Wait for mutex
    DWORD dwWaitResult = WaitForSingleObject(g_hMutex, INFINITE);
    if (dwWaitResult == WAIT_OBJECT_0) {
        // Copy message to shared memory
        strncpy_s(g_sharedMonitorData->message, MAX_MESSAGE_LENGTH, message, _TRUNCATE);
        
        // Release mutex
        ReleaseMutex(g_hMutex);
        return TRUE;
    }

    return FALSE;
}

// Send SHOW2ND message
BOOL ShowMirrorWindow()
{
    return SendMessageToMirror("SHOW2ND");
}

// Send HIDE2ND message
BOOL HideMirrorWindow()
{
    return SendMessageToMirror("HIDE2ND");
}
