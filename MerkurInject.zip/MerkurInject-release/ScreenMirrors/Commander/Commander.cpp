// HostMain.cpp
// Example main function for host application
// This demonstrates how to use the shared memory functions

#include <Windows.h>
#include <stdio.h>
#include <conio.h>
#include "SharedMemoryHost.h"

// Example: Simple console application
int main()
{
    // Initialize shared memory
    if (!InitSharedMemory()) {
        printf("Failed to initialize shared memory!\n");
        printf("Error: %lu\n", (unsigned long)GetLastError());
        return 1;
    }

    printf("Shared memory initialized successfully!\n");
    printf("Commands:\n");
    printf("  1 - Send SHOW2ND message (show mirror window)\n");
    printf("  2 - Send HIDE2ND message (hide mirror window)\n");
    printf("  q - Quit\n");
    printf("\nWaiting for commands...\n");

    int choice;
    while (true) {
        choice = _getch();

        if (choice == '1') {
            if (ShowMirrorWindow()) {
                printf("Sent SHOW2ND message\n");
            }
            else {
                printf("Failed to send SHOW2ND message\n");
            }
        }
        else if (choice == '2') {
            if (HideMirrorWindow()) {
                printf("Sent HIDE2ND message\n");
            }
            else {
                printf("Failed to send HIDE2ND message\n");
            }
        }
        else if (choice == 'q' || choice == 'Q') {
            break;
        }
    }

    // Cleanup
    ReleaseSharedMemory();
    printf("Exiting...\n");

    return 0;
}
