#pragma once
#include "SuperIo.h"

class CSensor 
{
public:
	CSensor();
	~CSensor();
public:
	BYTE m_by30;
	BYTE m_by38;
	BYTE m_by28;
public:
	virtual DWORD sub_10009DF0(DWORD);
	virtual DWORD sub_10008200(DWORD);
};

