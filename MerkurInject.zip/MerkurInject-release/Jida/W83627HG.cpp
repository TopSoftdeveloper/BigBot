#include "stdafx.h"
#include "W83627HG.h"
#include "Jida_global.h"
CW83627HG::CW83627HG()
{
}


CW83627HG::~CW83627HG()
{
}


void CW83627HG::sub_1000CBD0()
{
}

#if 0
BOOL CW83627HG::sub_1000A6B0()
{
	return TRUE;
}
#endif

DWORD CW83627HG::sub_1000BEC0()
{
	return 6;
}

#if 0
DWORD CW83627HG::sub_10006E70(DWORD dwFlag)
{
	int result; // eax

	result = 0;
	switch ( dwFlag )
	{
	case 0:
		return sub_1000A490();
	case 1:
		return sub_1000A4B0();
	case 2:
		return sub_1000A4A0();
	}
	return result;
}



DWORD CW83627HG::sub_10006EB0(DWORD dwArg1, DWORD dwArg2, PDWORD pdwArg3)
{
	int result; 
	result = 0;
	switch ( dwArg1 )
	{
	case 0:
		return sub_1000A730(dwArg2, pdwArg3);//38
	case 1:
		return sub_1000AB50(dwArg2, pdwArg3);//3c
	case 2:
		return sub_1000A7E0(dwArg2, pdwArg3);//40
	}
	return result;
}


void CW83627HG::sub_10006F00()
{
}


void CW83627HG::sub_10006F60()
{
}


void CW83627HG::sub_10006FB0()
{
}


void CW83627HG::sub_10007000()
{
}


void CW83627HG::sub_10007050()
{
}


BYTE CW83627HG::sub_1000A490()
{
	return m_by30;
}


BYTE CW83627HG::sub_1000A4B0()
{
	return m_by38;
}


BYTE CW83627HG::sub_1000A4A0()
{
	return m_by28;
}


void CW83627HG::sub_1000A730()
{
}


void CW83627HG::sub_1000AB50()
{
}


void CW83627HG::sub_1000A7E0()
{
}


void CW83627HG::sub_1000A860()
{
}


void CW83627HG::sub_1000ABC0()
{
}


void CW83627HG::sub_1000A8A0()
{
}


void CW83627HG::sub_1000A900()
{
}


void CW83627HG::sub_1000AC20()
{
}


DWORD CW83627HG::sub_10009DE0()
{
	return 1;
}


void CW83627HG::sub_1000AC60()
{
}


void CW83627HG::sub_1000A940()
{
}


void CW83627HG::sub_1000A9A0()
{
}


void CW83627HG::sub_1000ACE0()
{
}


void CW83627HG::sub_1000AA00()
{
}


void CW83627HG::sub_1000AD60()
{
}


void CW83627HG::sub_1000AA90()
{
}
#endif

PDWORD CW83627HG::sub_1000DB80(DWORD *pdwArg1, BYTE *pdwArg2)
{
	DWORD *result; 

	result = pdwArg1;
	*pdwArg1 = (DWORD)g_dword_10015A84;
	*pdwArg2 = 3;
	return result;
}


PDWORD CW83627HG::sub_1000DBA0(DWORD *pdwArg1, BYTE *pdwArg2)
{
	DWORD *result; // eax

	result = pdwArg1;
	*pdwArg1 = (DWORD)g_dword_10015B28;
	*pdwArg2 = 9;
	return result;
}


PDWORD CW83627HG::sub_1000DBC0(DWORD *pdwArg1, BYTE *pdwArg2)
{
	DWORD *result; 

	result = pdwArg1;
	*pdwArg1 = (DWORD)g_dword_10015BB0;
	*pdwArg2 = 3;
	return result;
}

#if 0
void CW83627HG::sub_1000A4D0()
{
}
#endif

void CW83627HG::sub_1000B4E0()
{
	// ecx -= 4;
	
}
