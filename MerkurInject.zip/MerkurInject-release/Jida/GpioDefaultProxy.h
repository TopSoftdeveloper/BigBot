#pragma once
#include "stdafx.h"
#include "GpioProxy.h"

class CGpioDefaultProxy : public CGpioProxy
{
public:
	CGpioDefaultProxy();
	virtual ~CGpioDefaultProxy();
public:
	HANDLE m_hHandle;
public:

	virtual DWORD sub_10009EA0(DWORD *pdwArg1);
	virtual DWORD sub_1000A330(DWORD dwArg1, DWORD dwArg2);
	virtual DWORD sub_1000A200(DWORD dwArg1, PDWORD pdwArg2);
	virtual DWORD sub_1000A040(DWORD dwArg1, PDWORD pdwArg2);
	virtual DWORD sub_10009F00(DWORD dwArg1, PDWORD pdwArg2);
	virtual DWORD sub_1000A0D0(DWORD dwArg1, DWORD dwArg2);
	virtual DWORD sub_10009FA0(DWORD dwArg1, PDWORD pdwArg2);
	virtual DWORD sub_1000A2A0(DWORD dwArg1, DWORD dwArg2);
	virtual DWORD sub_1000A160(DWORD dwArg1, PDWORD pdwArg2);
	virtual DWORD sub_1000A430(DWORD dwArg1, PDWORD pdwArg2);
	virtual DWORD sub_1000A4D0(BYTE InBuffer, BYTE *pbBuff);
	virtual DWORD sub_1000A570(BYTE InBuffer, DWORD *pdwBuff);
	virtual DWORD sub_1000A610(BYTE InBuffer, DWORD *pdwArg2, DWORD *pdwArg3 );
	virtual DWORD sub_1000A3C0(DWORD* lpOutBuffer);
	virtual OVERLAPPED* sub_1000A6C0();
	virtual DWORD sub_10007520(DWORD* pdwArg1);
};

