#include "stdafx.h"
#include "Sensor.h"


CSensor::CSensor()
{
}


CSensor::~CSensor()
{
}


DWORD CSensor::sub_10009DF0(DWORD)
{
	return 1;
}
DWORD CSensor::sub_10008200(DWORD)
{
	return 1;
}

