#include "stdafx.h"
#include "W83L771Ax.h"

BYTE g_byte_10015DB4[12] = {0,0,1,5,6,60,1,10,0,7,8,18};
CW83L771Ax::CW83L771Ax()
{
}


CW83L771Ax::~CW83L771Ax()
{
}


void CW83L771Ax::sub_1000CBD0()
{
}


DWORD CW83L771Ax::sub_1000BEB0()
{
	return 1;
}


DWORD CW83L771Ax::sub_1000B190()
{
	return 2;
}


DWORD CW83L771Ax::sub_100081C0(DWORD i)
{
	return 1;
}


DWORD CW83L771Ax::sub_10008200(DWORD dwArg1, DWORD dwArg2, PDWORD pdwArg3)
{
	int result; 
	result = 0;
	switch ( dwArg1 )
	{
	case 0:
		return sub_1000AEB0(dwArg2, pdwArg3);//38
	case 1:
		return _JidaVgaSetContrastEnable(dwArg2, pdwArg3);//3c
	case 2:
		return _JidaVgaSetContrastEnable(dwArg2, pdwArg3);//40
	}
	return result;

}


DWORD CW83L771Ax::sub_10008250(DWORD dwArg1, DWORD dwArg2, DWORD* pdwArg3, DWORD* pdwArg4)
{

	switch ( dwArg1 )
	{
	case 0:
		return sub_1000B060((WORD)dwArg2, pdwArg3, pdwArg4);//44
	case 1:
		return _JidaVoltageSetLimits((WORD)dwArg2, pdwArg3, pdwArg4);//48
	case 2:
		return _JidaVoltageSetLimits((WORD)dwArg2, pdwArg3, pdwArg4);//4c
	}
	return 0;
}


DWORD CW83L771Ax::sub_100082B0(DWORD dwArg1, DWORD dwArg2, PDWORD pdwArg3)
{
	int result; 
	result = 0;
	switch ( dwArg1 )
	{
	case 0:
		return sub_1000B0B0((WORD)dwArg2, pdwArg3);//50
	case 1:
		return _JidaVgaSetContrastEnable(dwArg2, pdwArg3);//54
	case 2:
		return _JidaVgaSetContrastEnable(dwArg2, pdwArg3);//58
	}
	return result;
}


DWORD CW83L771Ax::sub_10008300(DWORD dwFlag, DWORD dwArg2, PDWORD pdwArg3)
{
	switch ( dwFlag )
	{
	case 0:

		return sub_1000AF70(dwArg2, pdwArg3);//60
	case 1:

		return _JidaVgaSetContrastEnable(dwArg2, pdwArg3);//5c
	case 2:

		return _JidaVgaSetContrastEnable(dwArg2, pdwArg3);//64
	}
	return 0;
}


DWORD CW83L771Ax::sub_10008350(DWORD dwFlag, DWORD dwArg2, PDWORD pdwArg3)
{
	switch ( dwFlag )
	{
	case 0:
		return sub_1000AFF0(dwArg2, pdwArg3);//68
	case 1:
		return _JidaVgaSetContrastEnable(dwArg2, pdwArg3);//6c
	case 2:
		return _JidaVgaSetContrastEnable(dwArg2, pdwArg3);//70
	}
	return 0;
}


DWORD CW83L771Ax::sub_100083A0(DWORD dwArg1, DWORD dwArg2, PDWORD pdwArg3)
{
	switch ( dwArg1 )
	{
	case 0:
		return sub_1000B0F0(dwArg2, (PDWORD)pdwArg3); //74
	case 1:
		return _JidaVgaSetContrastEnable(dwArg2, (PDWORD)pdwArg3);//78
	case 2:
		return _JidaVgaSetContrastEnable(dwArg2, pdwArg3);//7C
	}
	return 0;
}


DWORD CW83L771Ax::sub_1000C590()
{
	return 0;
}


DWORD CW83L771Ax::sub_1000AEB0(DWORD dwArg1, DWORD *pdwArg2)
{
	BYTE *pbyTmp; 
	BYTE byRet1; 
	BYTE byRet2; 
	
	byRet1 = 0;
	byRet2 = 0;
	if ( (WORD)dwArg1 < 2 )
	{
		pbyTmp = &g_byte_10015DB4[6 * (WORD)dwArg1];
		if ( m_pSmbus_Def4 )
		{
			m_pSmbus_Def4->sub_1000AA90(7, m_by08, pbyTmp[0], &byRet2, 1);
		
		}
		if ( !pbyTmp[2] )
		{
		
			if ( m_pSmbus_Def4 )	m_pSmbus_Def4->sub_1000AA90(7, m_by08, pbyTmp[1], &byRet1, 1);
			
		}
		*pdwArg2 = 125 * ((byRet1 >> 5) + 8 * byRet2);
		return 1;
	}
	return 0;
}


DWORD CW83L771Ax::_JidaVgaSetContrastEnable(DWORD dwArg1, DWORD *pdwArg2)
{
	return 1;
}


DWORD CW83L771Ax::sub_1000B060(WORD wArg1, DWORD *pdwArg2, DWORD *pdwArg3)
{
	if ( wArg1 < 2 )
	{
		*pdwArg2 = 0xFFFE0C00;
		*pdwArg3 = g_byte_10015DB4[2+6 * wArg1] != 0 ? 0x1F018 : 0x1F383;
		return 1;
	}
	return 0;
}


BOOL CW83L771Ax::_JidaVoltageSetLimits(WORD wArg1, DWORD *pdwArg2, DWORD *pdwArg3)
{
	return 0;
}


DWORD CW83L771Ax::sub_1000B0B0(WORD wArg1, DWORD *pdwArg2)
{
	if ( wArg1 < 2 )
	{
		*pdwArg2 = g_byte_10015DB4[2+6 * wArg1] != 0 ? 1000 : 125;
		return 1;
	}
	return 0;
}


DWORD CW83L771Ax::sub_1000AF70(DWORD dwArg1, DWORD *pdwArg2)
{
	
	
	BYTE byTmp1; 
	byTmp1 = 0;
	if ( (WORD)dwArg1 < 2)
	{
		if ( m_pSmbus_Def4 )
		{
			
			m_pSmbus_Def4->sub_1000AA90(7, m_by08, g_byte_10015DB4[3+6 * (WORD)dwArg1], &byTmp1, 1);
		}
		*pdwArg2 = 1000 * byTmp1;
		return 1;
	}
	return 0;
}


DWORD CW83L771Ax::sub_1000AFF0(DWORD dwArg1, DWORD *pdwArg2)
{
	BYTE byRet; 
	byRet = 0;
	if ( (WORD)dwArg1 < 2 )
	{
		if ( m_pSmbus_Def4 )
		{			
			m_pSmbus_Def4->sub_1000AA90(7, m_by08, g_byte_10015DB4[4+6 * (WORD)dwArg1], &byRet, 1);
			
		}
		*pdwArg2 = 1000 * byRet;
		return 1;
	}
	return 0;
}


DWORD CW83L771Ax::sub_1000B0F0( DWORD dwArg1, DWORD *pdwArg2)
{
	BYTE byTmp1; 
	int result; 
	BYTE byRet1;

	byTmp1 = 0;
	result = 0;
	byRet1 = 0;
	if ((WORD)dwArg1 < 2)
	{
		if ( m_pSmbus_Def4 )
		{						
			m_pSmbus_Def4->sub_1000AA90(7, m_by08, 2, &byRet1, 1);
			byTmp1 = byRet1;
		}
		*pdwArg2 = 0;
		if ((byTmp1 & g_byte_10015DB4[5+6 * dwArg1]) != 0 )
			*pdwArg2 = 2;
		if ( g_byte_10015DB4[2+6 * dwArg1] )
			*pdwArg2 |= (byTmp1 & 4) != 0 ? 4 : 1;
		else
			*pdwArg2 |= 1;
		return 1;
	}
	return result;
}


DWORD CW83L771Ax::sub_10009DF0()
{
	return 1;
}
