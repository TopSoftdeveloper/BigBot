#include "stdafx.h"
#include "Adt7475.h"
#include "Jida_global.h"

CAdt7475::CAdt7475()
{
}


CAdt7475::~CAdt7475()
{
}


void CAdt7475::sub_1000CBD0()
{
}


DWORD CAdt7475::sub_1000B1E0()
{
	BYTE byRet1; 
	byRet1 = 0;
	m_dw08 = 0;
	if ( m_pSmbus_Def0C )
	{
		
		if(m_pSmbus_Def0C->sub_1000AA90(7, m_by04, 37, &byRet1, 1) != -1)
		{
			sub_10008A60(m_by04, 124, &byRet1);
			m_dw10 = byRet1 & 1;
			sub_10008A60(m_dw10, 115, &byRet1);
			m_dw14 = (byRet1 & 0x20) == 0;
			m_dw08 = 1;
			sub_1000BB80(&m_dw1C, &m_by18);
		}
	}
	return m_dw08;
}


DWORD CAdt7475::sub_1000C590()
{
	return 0;
}


DWORD CAdt7475::sub_100081C0(DWORD i)
{
	DWORD result; 
	result = 0;
	switch ( i )
	{
	case 0:
		return sub_1000B770();//2c
	case 1:
		return sub_1000B1A0();//30
	case 2:
		return sub_10009DD0();//34
	}
	return result;
}

DWORD CAdt7475::sub_10009DD0()
{
	return 4;
}
DWORD CAdt7475::sub_10008200(DWORD dwArg1, DWORD dwArg2, PDWORD pdwArg3)
{
	int result; 
	result = 0;
	switch ( dwArg1 )
	{
	case 0:
		return sub_1000B780((WORD)dwArg2, pdwArg3);//38
	case 1:
		return sub_1000B410(dwArg2, pdwArg3);//3c
	case 2:
		return sub_1000B2A0((WORD)dwArg2, pdwArg3);//40
	}
	return result;

}

DWORD CAdt7475::sub_10008250(DWORD dwArg1, DWORD dwArg2, PDWORD pdwArg3, PDWORD pdwArg4)
{
	int result; 
	result = 0;
	switch ( dwArg1 )
	{
	case 0:
		return sub_1000B840((WORD)dwArg2, pdwArg3, pdwArg4);//44
	case 1:
		return sub_1000B4E0(dwArg2, pdwArg3, pdwArg4);//48
	case 2:
		return sub_1000B360((WORD)dwArg2, pdwArg3, pdwArg4);//4c
	}
	return result;

}


DWORD CAdt7475::sub_100082B0(DWORD dwFlag, DWORD dwArg1, PDWORD pdwArg2)
{
	int result; 
	result = 0;
	switch ( dwFlag )
	{
	case 0:
		return sub_1000B890( (WORD)dwArg1, pdwArg2);//0x50
	case 1:
		return sub_1000B550( dwArg1, pdwArg2);//0x54
	case 2:
		return _JidaVgaSetContrastEnable();//0x58
	}
	return result;
}



DWORD CAdt7475::sub_10008300(DWORD dwFlag, DWORD dwArg1, PDWORD pdwArg2)
{
	int result; 
	result = 0;
	switch ( dwFlag )
	{
	case 0:
		return sub_1000B8C0( (WORD)dwArg1, pdwArg2);//0x60
	case 1:
		return sub_1000B5B0( dwArg1, pdwArg2);//0x5C
	case 2:
		return _JidaVgaSetContrastEnable();//0x64
	}
	return result;
}


DWORD CAdt7475::sub_10008350(DWORD dwFlag, DWORD dwArg1, PDWORD pdwArg2)
{
	int result; 
	result = 0;
	switch ( dwFlag )
	{
	case 0:
		return sub_1000B930( (WORD)dwArg1, pdwArg2);//0x68
	case 1:
		return sub_1000B650( dwArg1, pdwArg2);//0x6C
	case 2:
		return _JidaVgaSetContrastEnable();//0x70
	}
	return result;
}

DWORD CAdt7475::sub_100083A0(DWORD dwFlag, DWORD dwArg1, LPVOID pdwArg2)
{
	int result; 
	result = 0;
	switch ( dwFlag )
	{
	case 0:
		return sub_1000B9A0( dwArg1, (WORD*)pdwArg2);//0x74
	case 1:
		return sub_1000B6F0( (WORD)dwArg1, (WORD*)pdwArg2);//0x78
	case 2:
		return sub_1000B390( (WORD)dwArg1, (PBYTE)pdwArg2);//0x7C
	}
	return result;
}

DWORD CAdt7475::sub_1000B770()
{
	return 3;
}


WORD CAdt7475::sub_1000B1A0()
{
	return (WORD)m_by18;
}


BOOL CAdt7475::sub_1000B780(WORD wArg1, DWORD *pdwArg2)
{
	BYTE *pbyTmp; 
	BYTE byTmp1; 
	BYTE byTmp2; 
	BYTE byTmp3; 
	
	byTmp3 = 0;
	byTmp2 = 0;
	if ( m_dw08 == 1 && wArg1 < 3 )
	{
	
		pbyTmp = &g_byte_10015D30[8 * wArg1];
		m_pSmbus_Def0C->sub_1000AA90(7, m_by04, g_byte_10015D30[8 * wArg1], &byTmp3, 1);
		m_pSmbus_Def0C->sub_1000AA90(7, m_by04, pbyTmp[1], &byTmp2, 1);
		byTmp1 = (byTmp3 & pbyTmp[2]) >> pbyTmp[3];

		if ( m_dw10)
			byTmp1 = byTmp1 + 4 * (BYTE)byTmp2;
		else
			byTmp1 = byTmp1 + 4 * byTmp2 - 256;
		*pdwArg2 = 250 * byTmp1;
		return 1;
	}
	return 0;
}


BOOL CAdt7475::sub_1000B410(DWORD dwArg, PDWORD pdwArg)
{
	BYTE *pbyoff; 
	int dwVal; 
	BYTE bytmp1; 
	BYTE bytmp2; 

	bytmp1 = 0;
	bytmp2 = 0;
	if ( m_dw08 == 1 && (WORD)dwArg < m_by18 )
	{
		pbyoff = (BYTE *)(m_dw1C + 12 * (WORD)dwArg);
		if ( m_dw14 && sub_1000BB70(dwArg) )
			dwVal = *(WORD *)(pbyoff + 6);
		else
			dwVal = 1000;
		m_pSmbus_Def0C->sub_1000AA90(7, m_by04, *pbyoff, &bytmp1, 1);
		m_pSmbus_Def0C->sub_1000AA90(7, m_by04, pbyoff[1], &bytmp2, 1);
		*pdwArg = 22 * dwVal * ((BYTE)((bytmp1 & pbyoff[2]) >> pbyoff[3]) | (4 * bytmp2)) / 10000;
		return TRUE;
	}
	return FALSE;
}

BOOL CAdt7475::sub_1000B2A0(WORD wArg, DWORD *pdwVal)
{
	WORD wVal; 
	BYTE bytmp;
	WORD wtmp; 

	bytmp = 0;
	if ( m_dw08 != 1 || wArg >= 4)
		return FALSE;
	
	m_pSmbus_Def0C->sub_1000AA90(7, m_by04, g_byte_10015D20[wArg*4+1], &bytmp, 1);
	wtmp = bytmp;
	m_pSmbus_Def0C->sub_1000AA90(7, m_by04, g_byte_10015D20[wArg*4], &bytmp, 1);
	
	wVal = (bytmp << 8) | wtmp;
	if ( !wVal )
		return FALSE;
	*pdwVal = 5400000 / wVal;
	return TRUE;
}

BOOL CAdt7475::sub_1000B840(WORD wArg, PDWORD pdwVal1, PDWORD pdwVal2)
{
	if ( m_dw08 == 1 && wArg < 3 )
	{
		if ( m_dw10 )
		{
			*pdwVal1 = -128000;
			*pdwVal2 = 127000;
		}
		else
		{
			*pdwVal1 = -64000;
			*pdwVal2 = 191000;
		}
		return TRUE;
	}
	return FALSE;
}

BOOL CAdt7475::sub_1000B4E0( DWORD dwArg, PDWORD pdwVal1, PDWORD pdwVal2)
{
	DWORD dwOff; 
	int dwVal;

	if ( m_dw08 == 1 && (WORD)dwArg < m_by18 )
	{
		dwOff = m_dw1C + 12 * (WORD)dwArg;
		if ( m_dw14 && sub_1000BB70(dwArg) )
			dwVal = *(WORD *)(dwOff + 6);
		else
			dwVal = 1000;
		*pdwVal1 = 0;
		*pdwVal2 = 22506 * dwVal / 10000;
		return TRUE;
	}
	return FALSE;
}

BOOL CAdt7475::sub_1000B360(WORD wArg, PDWORD pdwVal1, PDWORD pdwVal2)
{
	if ( m_dw08 == 1 && wArg < 4 )
	{
		*pdwVal1 = 82;
		*pdwVal2 = 5400000;
		return TRUE;
	}
	return FALSE;
}

BOOL CAdt7475::sub_1000B890(WORD wArg, PDWORD pdwVal)
{
	if ( m_dw08 == 1 && wArg < 3 )
	{
		*pdwVal = 250;
		return TRUE;
	}
	return FALSE;
}

BOOL CAdt7475::sub_1000B550(DWORD dwArg, DWORD* pdwVal)
{
	DWORD dwOff;
	DWORD dwval;
	BYTE bytmp; 

	bytmp = 0;
	if ( m_dw08 == 1 && (WORD)dwArg < (WORD)m_by18 )
	{
		dwOff = m_dw1C + 12 * (WORD)dwArg;
		if (m_dw14 && sub_1000BB70(dwArg)) 
		{
			dwval = *(WORD *)(dwOff + 6);
		}
		else
			dwval = 1000;		

		*pdwVal = 22 * dwval / 10000;
		return TRUE;
	}
	return FALSE;
}


DWORD CAdt7475::_JidaVgaSetContrastEnable()
{
	return 0;
}

BOOL CAdt7475::sub_1000B5B0(DWORD dwArg, DWORD* pdwVal)
{
	DWORD dwOff;
	DWORD dwval;
	BYTE bytmp; 

	bytmp = 0;
	if ( m_dw08 == 1 && (WORD)dwArg < (WORD)m_by18 )
	{
		dwOff = m_dw1C + 12 * (WORD)dwArg;
		if (m_dw14 && sub_1000BB70(dwArg)) 
		{
			dwval = *(WORD *)(dwOff + 6);
		}
		else
			dwval = 1000;
		m_pSmbus_Def0C->sub_1000AA90(7, m_by04, *(BYTE*)(dwOff + 4), &bytmp, 1);

		*pdwVal = 88 * dwval * bytmp / 10000;
		return TRUE;
	}
	return FALSE;
}

BOOL CAdt7475::sub_1000B8C0(WORD wArg, DWORD* pdwVal)
{
	int ntmp; 
	BYTE bytmp; 	
	bytmp = 0;
	if ( m_dw08 == 1 && wArg < 3 )
	{
		m_pSmbus_Def0C->sub_1000AA90(7, m_by04, g_byte_10015D30[wArg*8+4], &bytmp, 1);

		if ( m_dw10 )
			ntmp = bytmp;
		else
			ntmp = bytmp - 64;
		*pdwVal = 1000 * ntmp;
		return TRUE;
	}
	return FALSE;
}

BOOL CAdt7475::sub_1000B930(WORD wArg, DWORD *pdwVal)
{
	int ntmp; 
	BYTE bytmp;

	bytmp = 0;
	if ( m_dw08 == 1 && wArg < 3 )
	{
		m_pSmbus_Def0C->sub_1000AA90(7, m_by04, g_byte_10015D30[wArg*8+5], &bytmp, 1);
		if ( m_dw10 )
			ntmp = bytmp;
		else
			ntmp = bytmp - 64;
		*pdwVal = 1000 * ntmp;
		return TRUE;
	}
	return FALSE;
}

BOOL CAdt7475::sub_1000B650(DWORD dwArg, DWORD* pdwVal)
{
	DWORD dwOff;
	DWORD dwval;
	BYTE bytmp; 

	bytmp = 0;
	if ( m_dw08 == 1 && (WORD)dwArg < (WORD)m_by18 )
	{
		dwOff = m_dw1C + 12 * (WORD)dwArg;
		if (m_dw14 && sub_1000BB70(dwArg)) // sub_10009580
		{
			dwval = *(WORD *)(dwOff + 6);
		}
		else
			dwval = 1000;
		m_pSmbus_Def0C->sub_1000AA90(7, m_by04, *(BYTE*)(dwOff + 5), &bytmp, 1);

		*pdwVal = 88 * dwval * bytmp / 10000;
		return TRUE;
	}
	return FALSE;
}

BOOL CAdt7475::sub_1000B9A0(DWORD dwArg, WORD *pwVal)
{
	BYTE bytmp; 

	bytmp = 0;
	if ( m_dw08 != 1)
		return 0;

	if(!sub_1000B780((WORD)dwArg, &dwArg))
		return 0;

	m_pSmbus_Def0C->sub_1000AA90(7, m_by04, g_byte_10015D30[dwArg*8+6], &bytmp, 1);
	if ((bytmp & (g_byte_10015D30[dwArg*8+7])) != 0)
	{
		*pwVal = 2;
		return 1;
	}
	DWORD dwCom = -64;
	if (m_dw10 != 0) dwCom = -128;
	if (dwArg == dwCom)
	{
		*pwVal = 4;
		return 1;
	}
	else
	{
		dwCom = 191;
		if (m_dw10 != 0)
		{
			dwCom = 127;
		}
		if (dwArg == dwCom)
		{
			*pwVal = 8;
		}
		else
			*pwVal = 1;		
	}
	return 1;
}


BOOL CAdt7475::sub_1000B6F0(WORD wArg, WORD* pwVal)
{
	BYTE bytmp;
	if (m_dw08 != 1 || wArg >= m_by18)
	{
		return 0;
	}
	bytmp = 0;	
	m_pSmbus_Def0C->sub_1000AA90(7, m_by04, *(BYTE*)(m_dw1C+12*wArg+8), &bytmp, 1);

	*pwVal = ((bytmp & *(BYTE*)(m_dw1C+12*wArg+9)) != 0) + 1;
	return 1;
}


DWORD CAdt7475::sub_1000B390(WORD wArg1, PBYTE pbyArg2)
{
	BYTE byRet; 
	byRet = 0;
	if ( m_dw08==1 && wArg1 < 4 )
	{
		
		m_pSmbus_Def0C->sub_1000AA90(7, m_by04, g_byte_10015D20[4 * wArg1 + 2], &byRet, 1);
		if ( (byRet & g_byte_10015D20[3+4 * wArg1]) != 0 )
		{
			*pbyArg2 = 2;
			return 1;
		}
		else
		{
			
			*pbyArg2 = 1;
			return 1;
		}
	}
	return 0;
}


DWORD CAdt7475::sub_1000BB70(DWORD dwArg)
{
	return 1;
}


PDWORD CAdt7475::sub_1000BB80(PDWORD pdwArg1, BYTE *pbyArg2)
{

	DWORD *result; 

	result = pdwArg1;
	*pdwArg1 = (DWORD)g_dword_10015D48;
	*pbyArg2 = 2;
	return result;
}


// DWORD CAdt7475::sub_10009DF0()
// {
// 	return 1;
// }

DWORD CAdt7475::sub_10008A60(DWORD dwArg1, DWORD dwArg2, BYTE* pDest)
{
	//LOBYTE(a2) = *(_BYTE *)(a1 + 4);
	return (m_pSmbus_Def0C->sub_1000AA90(7,	m_by04,	(BYTE)dwArg2,	pDest,	1) == 0);
}
