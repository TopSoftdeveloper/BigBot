#include "stdafx.h"
#include <setupapi.h>
#include <cfgmgr32.h>
#include "Jida_global.h"
#include "Smbus_Def.h"
#include <malloc.h>
#include "SuperIo.h"
#include "Sensor.h"
#include "W836x.h"
#include "Adt7475.h"
#include "Adt7490.h"
#include "W83L771Ax.h"
#include "NCT7802.h"
#include "AmdBrazos.h"
#include "W83627DHGP.h"

LPUpdateDriverForPlugAndPlayDevices pUpdateDriverForPlugAndPlayDevices;
LPInstallSelectedDriver pInstallSelectedDriver;

DWORD sub_10005A10(PBYTE byBuf)
{	
	OVERLAPPED *lpoverlap;	
	DWORD result; 
	DWORD NumberOfBytesTransferred; 
	char OutBuffer[32];

	NumberOfBytesTransferred = 0;
	result = 0;
	lpoverlap = sub_100065B0();

	if ( !lpoverlap )
		return 1450;
	DeviceIoControl(g_hFile, 0xEA606280, 0, 0, OutBuffer, 0x20, 0, lpoverlap);
	if ( !GetOverlappedResult(g_hFile, lpoverlap, &NumberOfBytesTransferred, 1) )
	{
		result = GetLastError();

		if ( result == 0xE0000109 )
			return 1460;
	}

	if ( !result )
	{
		*byBuf = OutBuffer[0];
		return result;
	}
	return result;
}

int sub_10004B10(BYTE *pbBuff1, int nVal, BYTE *pbBuff2)
{
	int result; 
	int nFlag; 

	result = 0;
	nFlag = 0x7FFFFFFE;
	if ( nVal )
	{
		while ( nFlag && *pbBuff1 )
		{
			*pbBuff2 = *pbBuff1;
			--nVal;
			++pbBuff2;
			++pbBuff1;
			--nFlag;
			if ( !nVal )
			{
				result = 0x8007007A;
				*(pbBuff2 - 1) = 0;
				return result;
			}
		}
		*pbBuff2 = 0;
	}
	else
	{
		result = 0x8007007A;
		*(pbBuff2 - 1) = 0;
	}
	return result;
}

DWORD		sub_100030C0(char InBuffer, LPVOID lpOutBuffer)
{
	OVERLAPPED *pOverlapped; // esi
	DWORD result; // eax
	DWORD NumberOfBytesTransferred; // [esp+Ch] [ebp-4h] BYREF

	NumberOfBytesTransferred = 0;
	pOverlapped = (struct _OVERLAPPED *)sub_100065B0();
	if ( !pOverlapped )
		return 1450;
	DeviceIoControl(g_hFile, 0xEA60E034, &InBuffer, 2, lpOutBuffer, 4, 0, pOverlapped);
	if ( GetOverlappedResult(g_hFile, pOverlapped, &NumberOfBytesTransferred, 1) )
		return 0;
	result = GetLastError();
	if ( result == 0xE0000109 )
		return 1460;
	return result;
}

DWORD sub_10004750(BYTE bArg1, DWORD dwArg2)
{

	OVERLAPPED *pOverlapped; 
	DWORD result; 
	DWORD NumberOfBytesTransferred;
	DWORD InBuffer[2]; 


	NumberOfBytesTransferred = 0;
	InBuffer[0] = bArg1;
	InBuffer[1] = dwArg2;
	pOverlapped = (OVERLAPPED *)getTlsValue_10004D00();

	if ( !pOverlapped )
		return ERROR_NO_SYSTEM_RESOURCES;
	DeviceIoControl(g_hFile, 0xEA60A028, InBuffer, 8, 0, 0, 0, pOverlapped);
	if ( GetOverlappedResult(g_hFile, pOverlapped, &NumberOfBytesTransferred, 1) )
		return 0;
	result = GetLastError();
	if ( result == 0xE0000109 )
		return ERROR_TIMEOUT;
	return result;
}


DWORD sub_100073E0(PDWORD pDest, SMBUSPARAM* plpParam)
{
	DWORD dwRet; // eax
	dwRet = 0x103;
	if ( !plpParam->pAddHeaderInfo_8 ) return dwRet;

	if ( *(WORD*)(plpParam->pAddHeaderInfo_8 + 2) > 4 || !pDest ) return 0x7A;

	memcpy_s(pDest, 4, (BYTE*)(plpParam->pAddHeaderInfo_8 + 4), *(WORD*)(plpParam->pAddHeaderInfo_8 + 2));
	*(DWORD*)(plpParam->pAddrBody_4 + 8) -= 1;
	if ( *(DWORD*)(plpParam->pAddrBody_4 + 8) )
	{
		if ( *(PWORD)(plpParam->pAddHeaderInfo_8 + 2) >= 4 )
			plpParam->pAddHeaderInfo_8 = plpParam->pAddHeaderInfo_8 + *(PWORD)(plpParam->pAddHeaderInfo_8 + 2) + 4;
		else
			plpParam->pAddHeaderInfo_8 = plpParam->pAddHeaderInfo_8 + 8;
		return 0;
	}
	else
	{
		plpParam->pAddHeaderInfo_8 = 0;
		return 0;
	}
	return dwRet;
}

DWORD sub_10007460(SMBUSPARAM* lpBuf, DWORD dwParam, DWORD dwCmd, PDWORD pdwOut)
{
	FUNCSTRUC10* pFunStruc; // ebp
	DWORD dwRet; // eax

	if (!lpBuf) return 0x57;

	pFunStruc = (FUNCSTRUC10*)dwParam;
	dwParam = 0;
	if ( !pFunStruc || pFunStruc->dwSelfAddr00 != (DWORD)pFunStruc || strcmp(pFunStruc->szStr0C, "HACPI") ) return 0x57;

	lpBuf->pAddHeaderInfo_8 = 0;
	lpBuf->dwUnk_C = pFunStruc->dwParam10;
	lpBuf->dwUnk_14 = dwCmd;
	dwRet = sub_10006910(g_hFile, 0xEA60E024, lpBuf, lpBuf->wHeaderlen_0 + lpBuf->wBodyLen_2, lpBuf, lpBuf->wHeaderlen_0 + lpBuf->wBodyLen_2, (PDWORD )&dwParam);
	if ( !dwRet )
	{		
		if ( *(PDWORD )(lpBuf->pAddrBody_4 + 8) )
		{
			lpBuf->pAddHeaderInfo_8 = lpBuf->pAddrBody_4 + 0xC;
			if ( pdwOut )
				*pdwOut = *(PDWORD )(lpBuf->pAddrBody_4 + 8);
		}
	}
	return dwRet;
}

void sub_100072A0(WORD wCnt, BYTE *pSrc, SMBUSPARAM* pDest, WORD wMod)
{
	WORD v5; // cx

	DWORD pBody; // ecx

	v5 = 4;
	if ( wCnt >= 4 )
		v5 = wCnt;

	if ( pDest->dwCode_10 != 0x43696541 ) return;
	if (wCnt == 0) return;


	pBody = (DWORD)pDest->pAddHeaderInfo_8;// pdest + 0x20
	if ( pDest->wHeaderlen_0 < (WORD)(v5 + 4 + pBody - (DWORD)pDest) ) return;

	switch ( wMod )
	{
	case 0:		
		*(PWORD)pBody = 0;
		*(PWORD)(pBody + 2) = 4;
		*(PDWORD )(pBody + 4) = *(PDWORD )pSrc;
		break;
	case 1:
		*(PWORD)pBody = 1;
		*(PWORD)(pBody + 2) = strlen((char*)pSrc) + 1;///???
		memcpy((void *)(pBody + 4), pSrc, *(PWORD)(pBody + 2));
		break;
	case 2:
		*(PWORD)pBody = 2;
		*(PWORD)(pBody + 2) = wCnt;
		memcpy((void *)(pBody + 4), pSrc, *(PWORD)(pBody + 2));
		break;
	case 3:
		*(PWORD)pBody = 3;
		*(PWORD)(pBody + 2) = wCnt;
		memcpy_s((void *)(pBody + 4),*(PWORD)(pBody + 2),pSrc,*(PWORD)(pBody + 2));
		break;
	default:
		return;
	}
	pDest->dwUnk_18 += v5 + 4;
	pDest->dwUnk_1C++;

	if ( *(PWORD)(pBody + 2) >= 4)
		pDest->pAddHeaderInfo_8 = pDest->pAddHeaderInfo_8 + *(PWORD)(pBody + 2) + 4;
	else
		pDest->pAddHeaderInfo_8 = pDest->pAddHeaderInfo_8 + 8;

	return;

}

DWORD sub_100091E0(const WCHAR *pszArg1, BOOL *pbyArg2)
{
	DWORD result; 
	HDEVINFO hDevInfo1; 
	size_t nLen; 
	DWORD LastError; 
	HMODULE hModule; 
	GUID ClassGuid;
	SP_DEVINFO_DATA DeviceInfoData; 
	WCHAR wClassName[32];

	result = 87;
	if ( pszArg1 && pbyArg2 )
	{
		if ( SetupDiGetINFClass(pszArg1, &ClassGuid, wClassName, 0x20, 0) )
		{
			hDevInfo1 = SetupDiCreateDeviceInfoList(&ClassGuid, 0);
			DeviceInfoData.cbSize = 28;
			if ( SetupDiCreateDeviceInfo(hDevInfo1, wClassName, &ClassGuid, 0, 0, 1, &DeviceInfoData)
				&& (nLen = wcsnlen((const wchar_t *)L"root\\CPLD0", 0x104),
				SetupDiSetDeviceRegistryProperty(hDevInfo1, &DeviceInfoData, 1, (const BYTE*)("root\\CPLD0"), 2 * nLen))
				&& SetupDiCallClassInstaller(0x19, hDevInfo1, &DeviceInfoData) )
			{
				LastError = 1157;
				hModule = LoadLibrary(L"newdev.dll");
				//v7 = hModule;
				if ( hModule )
				{
					LastError = 687;
					pUpdateDriverForPlugAndPlayDevices = (LPUpdateDriverForPlugAndPlayDevices) GetProcAddress(hModule, "UpdateDriverForPlugAndPlayDevicesW");
					if ( pUpdateDriverForPlugAndPlayDevices )
					{
						LastError = 0;
						if ( !pUpdateDriverForPlugAndPlayDevices(0, (LPCWSTR)L"root\\CPLD0", pszArg1, 1, pbyArg2) )
							LastError = GetLastError();
					}
					FreeLibrary(hModule);
				}
			}
			else
			{
				LastError = GetLastError();
			}
			if ( hDevInfo1 != (HDEVINFO)INVALID_HANDLE_VALUE )
				SetupDiDestroyDeviceInfoList(hDevInfo1);
			return LastError;
		}
		else
		{
			return GetLastError();
		}
	}
	return result;

}
DWORD sub_10009330(PCWSTR FileName, DWORD dwArg2, int *pdwArg3)
{
	HMODULE hModule; 
	DWORD dwLastError; 
	DWORD dwTmp1; 
	unsigned int dwTmp2; 
	HDEVINFO hClassDevs; 
	DWORD dwErrCode; 
	const WCHAR *pszTmp; 
	DWORD i; 
	DWORD dwTmp3; 
	BYTE *PropertyBuffer; 
	DWORD dwResult; 
	int dwFlag; 
	DWORD RequiredSize; 
	int dwInstallSelDrvRet; 
	DWORD dwBuff1[4]; 
	HINF hInfFile; 
	SP_DEVINFO_DATA DeviceInfoData; 
	SP_CLASSINSTALL_HEADER ClassInstallParams; 
	SP_DEVINSTALL_PARAMS DeviceInstallParams; 

	dwFlag = 0;
	dwInstallSelDrvRet = 0;
	if ( !FileName || !pdwArg3 )
		return 87;
	hModule = LoadLibrary(L"newdev.dll");
	
	if ( !hModule )
		return GetLastError();

	pInstallSelectedDriver = (LPInstallSelectedDriver)GetProcAddress(hModule, "InstallSelectedDriver");
	if ( !pInstallSelectedDriver )
		return GetLastError();

	hInfFile = SetupOpenInfFileW(FileName, 0, 2, 0);
	
	if ( hInfFile == (HINF)INVALID_HANDLE_VALUE )
	{
		dwLastError = GetLastError();
		FreeLibrary(hModule);
		return dwLastError;
	}
	dwBuff1[0] = 0;
	dwBuff1[1] = 0;
	dwBuff1[2] = 0;
	*pdwArg3 = 0;
	dwResult = sub_10009990(hInfFile, (PDWORD)dwBuff1);
	if ( !dwResult )
	{
		dwTmp1 = 0;
		dwTmp2 = 0;
		PropertyBuffer = 0;
		dwTmp3 = 0;
		dwBuff1[3] = 0;
		hClassDevs = SetupDiGetClassDevsW(0, 0, 0, 4);
		if ( dwBuff1[1] )
		{
			//v21 = dwBuff1[0];
			if ( dwBuff1[0] )
			{
				do
				{
					DeviceInfoData.cbSize = 28;
					i = 0;
					if ( SetupDiEnumDeviceInfo(hClassDevs, 0, &DeviceInfoData) )
					{
						do
						{
							if ( dwArg2 )
								CM_Reenumerate_DevNode(DeviceInfoData.DevInst, 1u);
							dwErrCode = 0;
							RequiredSize = dwTmp1;
							if ( !SetupDiGetDeviceRegistryPropertyW(hClassDevs,	&DeviceInfoData, 1, 0,	PropertyBuffer,	2 * dwBuff1[3], &RequiredSize) )
								dwErrCode = GetLastError();
							if ( RequiredSize != dwTmp1 )
							{
								dwTmp3 = RequiredSize >> 1;
								dwTmp1 = RequiredSize >> 1;
							}
							
							if ( dwErrCode == 122 )
							{
								if ( PropertyBuffer )
									HeapFree(g_hHeap_1001FE9C, 0, PropertyBuffer);
								PropertyBuffer = (BYTE *)HeapAlloc(g_hHeap_1001FE9C, 8, 2 * dwTmp1);
								dwBuff1[3] = dwTmp1;
								dwTmp1 = dwTmp3;
								dwErrCode = sub_10009940(dwTmp1, &dwTmp1, hClassDevs, &DeviceInfoData, PropertyBuffer);
							}

							if ( !dwErrCode )
							{
								pszTmp = (const WCHAR *)PropertyBuffer;
								for ( i = wcslen((const WCHAR *)PropertyBuffer); i; i = wcslen(pszTmp) )
								{
									const wchar_t* p = (const wchar_t *)sub_10009170(dwBuff1);
									if ( !_wcsicmp(pszTmp, p) )
									{
										if ( !dwArg2 )
										{
											ClassInstallParams.cbSize = 8;
											ClassInstallParams.InstallFunction = 5;
											SetupDiSetClassInstallParams(hClassDevs, &DeviceInfoData, &ClassInstallParams, 0x10);
											if ( SetupDiCallClassInstaller(5, hClassDevs, &DeviceInfoData) )
											{
												
												DeviceInstallParams.cbSize = 556;
												SetupDiGetDeviceInstallParams(hClassDevs, &DeviceInfoData, &DeviceInstallParams);
												dwFlag = (DeviceInstallParams.Flags & 0x180) != 0;
												if ( !*pdwArg3 )
													*pdwArg3 = dwFlag;
											}
										}

									}
									else{
										dwFlag = 0;
										dwInstallSelDrvRet = pInstallSelectedDriver(0,	hClassDevs,	0,	0,	&dwFlag);
										if ( !*pdwArg3 )
										{
											*pdwArg3 = dwFlag;
										}
									}

									pszTmp += i + 1;
								}
								dwTmp1 = dwTmp3;
							}
							++i;
						}
						while ( SetupDiEnumDeviceInfo(hClassDevs, i, &DeviceInfoData) );
						
					}
					
					
					if ( ++dwTmp2 >= dwBuff1[1] )
						break;
				}
				while ( dwBuff1[dwTmp2] );
				if ( PropertyBuffer )
					HeapFree(g_hHeap_1001FE9C, 0, PropertyBuffer);
			}
		}
	}
	SetupCloseInfFile(hInfFile);
	if ( dwArg2 && !dwInstallSelDrvRet && !SetupCopyOEMInfW(FileName, 0, 1, 0, 0, 0, 0, 0) )
		dwResult = GetLastError();
	sub_10009180(dwBuff1);
	FreeLibrary(hModule);
	return dwResult;
}

DWORD *sub_10009180(DWORD *dwBuff)
{
	DWORD *pdwTmp;
	DWORD i;
	DWORD *pdwTmp2;
	pdwTmp = dwBuff;
	if ( dwBuff[0] )
	{
		i = 0;
		if ( dwBuff[1] )
		{
			do
			{
				dwBuff = (DWORD *)dwBuff[0];
				pdwTmp2 = (PDWORD)pdwTmp[0];
				if ( pdwTmp2[i] )
				{
					if ( *(DWORD*)pdwTmp2[i] )
						HeapFree(g_hHeap_1001FE9C, 0, (LPVOID)(*(DWORD*)pdwTmp2[i]));
					dwBuff = (DWORD *)HeapFree(g_hHeap_1001FE9C, 0, (LPVOID)(*(DWORD*)pdwTmp2[i]));
				}
				++i;
			}
			while ( i < pdwTmp[1] );
		}
		
		if ( pdwTmp[0] )
			return (DWORD*)HeapFree(g_hHeap_1001FE9C, 0, (PDWORD)pdwTmp[0]);
	}
	return dwBuff;
}

DWORD sub_10009170(DWORD *pdwBuff)
{
	if ( pdwBuff[2] )
		return pdwBuff[0];
	else
		return 0;
}

DWORD sub_10009990(HINF InfHandle, PDWORD pdwArg2)
{
	DWORD dwRet; 
	int i;
	INFCONTEXT Context1; 
	wchar_t Destination[258]; 
	LPVOID lpMem1  = NULL;
	LPVOID lpMem = NULL;
	dwRet = 0;
	if ( !SetupFindFirstLineW(InfHandle, L"Manufacturer", 0, &Context1) )
		return GetLastError();
	i = 2;
	dwRet = 11;
	if ( sub_10009C60(0, (PDWORD)lpMem1, &Context1) )
	{
		while ( sub_10009C60(1, (PDWORD)lpMem, &Context1) )
		{
			wcsncpy_s(Destination, 0xFF, (const wchar_t*)lpMem, 0);
			bool fBreak = false;
			while ( sub_10009B40(InfHandle, 0, Destination, &pdwArg2) )
			{
				++i;
				if ( !sub_10009C60(2, (PDWORD)lpMem, &Context1) )
				{
					fBreak = true;
					 dwRet = 11;
					break;

				}
				Destination[0] = '.';
				wcsncpy_s(&Destination[1], 0xFE, (const WCHAR*)lpMem, 0);
				
			}
			
			if(!fBreak)
				dwRet = 1223;
			if ( !SetupFindNextLine(&Context1, &Context1) )
				break;
			if ( !sub_10009C60(0, (PDWORD)lpMem, &Context1) )
			{ dwRet = 11; break;}
		}
	}
	
	if(lpMem) HeapFree(g_hHeap_1001FE9C, 0, lpMem);
	if(lpMem1) HeapFree(g_hHeap_1001FE9C, 0, lpMem1);
	return dwRet;
}
int sub_10009C60(DWORD dwArg1, PDWORD pdwArg2, PINFCONTEXT Context)
{
	INFCONTEXT *pInfoContext; 
	DWORD LastError; 
	WCHAR *lpMem; 
	DWORD dwTmp1; 
	BOOL StringFieldW; 

	pInfoContext = Context;
	dwTmp1 = pdwArg2[1];
	Context = 0;
	StringFieldW = SetupGetStringFieldW(Context, dwArg1, (PWCHAR)pdwArg2[0], dwTmp1, (PDWORD)&Context);
	LastError = GetLastError();
	if ( LastError == 8 || StringFieldW && !pdwArg2[0] )
	{
		if ( pdwArg2[0] )
			HeapFree(g_hHeap_1001FE9C, 0, (LPVOID)pdwArg2[0]);
		lpMem = (WCHAR *)HeapAlloc(g_hHeap_1001FE9C,	8,	2 * (DWORD)Context);
		pdwArg2[0] = (DWORD)lpMem;
		pdwArg2[1] = (DWORD)Context;
		if ( SetupGetStringFieldW(pInfoContext, dwArg1, lpMem, (DWORD)Context, (PDWORD)&Context) )
		{
			pdwArg2[2] = (DWORD)Context;
			return pdwArg2[0];
		}
		LastError = GetLastError();
	}
	if ( !LastError )
	{

		pdwArg2[2] = (DWORD)Context;
		return pdwArg2[0];
	}
	pdwArg2[2] = 0;
	return 0;
}

DWORD sub_10009940(	int dwArg1,	DWORD *pdwArg2, HDEVINFO DeviceInfoSet, PSP_DEVINFO_DATA DeviceInfoData,	PBYTE PropertyBuffer)
{
	DWORD LastError; // edi
	DWORD RequiredSize; // [esp+4h] [ebp-4h] BYREF

	RequiredSize = *pdwArg2;
	LastError = 0;
	if ( !SetupDiGetDeviceRegistryPropertyW(DeviceInfoSet, DeviceInfoData, 1u, 0, PropertyBuffer, 2 * dwArg1, &RequiredSize) )
		LastError = GetLastError();
	if ( RequiredSize != *pdwArg2 )
		*pdwArg2 = RequiredSize >> 1;
	return LastError;
}
int sub_10009D20(PDWORD pdwArg1, PDWORD dwArg2)
{
	DWORD dwTmp1;
	DWORD *pdwTmp2;

	if ( pdwArg1[0] &&  (pdwArg1[1]!= pdwArg1[2]) )
	{

		*(DWORD*)((DWORD)pdwArg1[0] + 4 * (DWORD)pdwArg1[1]) = (DWORD)dwArg2;
		pdwArg1[1]++;
		return 1;
	}
	dwTmp1 = pdwArg1[2] + 16;
	pdwTmp2 = (PDWORD)HeapAlloc(g_hHeap_1001FE9C, 8, 4 * dwTmp1);
	if ( pdwTmp2 )
	{
		if ( pdwArg1[0] )
		{
			memcpy_s(pdwTmp2, 4 * dwTmp1, (LPVOID)pdwArg1[0], 4 * pdwArg1[2]);
			if ( pdwArg1[0] )
				HeapFree(g_hHeap_1001FE9C, 0, (LPVOID)pdwArg1[0]);
		}
		pdwArg1[0] = (DWORD)pdwTmp2;
		pdwArg1[2]= dwTmp1;
		*(DWORD*)(pdwArg1[0] + 4 * pdwArg1[1]) = (DWORD)dwArg2;
		pdwArg1[1]++;
		return 1;
	}
	return 0;
}
int sub_10009B40(HINF InfHandle, int dwArg2, PCWSTR Section, PDWORD *pdwArg4)
{
	PDWORD pdwTmp2; 
	DWORD *pdwBuff1; 
	DWORD j; 
	PDWORD pdwRet; 
	INFCONTEXT Context; 

	if ( pdwArg4 && SetupFindFirstLineW(InfHandle, Section, 0, &Context) )
	{
		pdwTmp2 = 0;
		while ( 1 )
		{
			if ( !pdwTmp2 )
			{
				pdwBuff1 = (PDWORD)HeapAlloc(g_hHeap_1001FE9C, 8, 0xC);
				if ( pdwBuff1 )
				{
					pdwBuff1[0] = 0;
					pdwBuff1[1] = 0;
					pdwBuff1[2] = 0;
				}
				else
				{
					pdwBuff1 = 0;
				}
				pdwTmp2 = pdwBuff1;
				if ( !pdwBuff1 )
					break;
			}
			if ( (pdwRet = (PDWORD)sub_10009C60(2, pdwBuff1, &Context)) )
			{
				j = 0;
				if ( pdwArg4[1] && (pdwRet != (PDWORD)*(DWORD*)pdwArg4[0]))
				{
					while ( !pdwRet[2] || !pdwBuff1[2] || _wcsicmp((wchar_t*)pdwRet[0], (wchar_t*)pdwBuff1[0]) )
					{
						if ( ++j < (DWORD)pdwArg4[1] )
						{
							pdwRet = (PDWORD)*((DWORD*)pdwArg4[0] + j);
							if ( pdwRet )
								continue;
						}
						
					}
				}
				sub_10009D20((PDWORD)pdwArg4, pdwBuff1);
				pdwTmp2 = 0;
				
			}
			if ( !SetupFindNextLine(&Context, &Context) )
			{
				if ( pdwTmp2 )
				{
					if ( *pdwTmp2 )
						HeapFree(g_hHeap_1001FE9C, 0, (LPVOID)*pdwTmp2);
					HeapFree(g_hHeap_1001FE9C, 0, pdwTmp2);
				}
				return 1;
			}
		}
	}
	return 1;
}

////////////////////////////////0215//////////////////////////////////////////
//////////////////////////////0215////////////////////////////////////////////
char szHACPI[8] = "HACPI"; 
PDWORD  sub_1000A150()
{
	PDWORD result; // eax

	result = (DWORD*)HeapAlloc(g_hHeap_1001FE9C, 8, 0x14);
	if ( result )
	{
		result[0] = (DWORD)result;
		result[1] = 0;
		result[2] = 4;
		result[3] = (DWORD)szHACPI;
	}
	return result;
}
DWORD sub_1000CA00(LPVOID pParam, HDEVINFO hDevInfo, SP_DEVINFO_DATA* pDevData, DWORD* dwBytes)
{

	BYTE *pbTemp1; 
	DWORD cnt; 
	int nVal; 
	int ret; 
	DWORD result; 
	BYTE* pbData = (BYTE*)pParam;
	result = 0;

	if ( pbData ) pbTemp1 = &pbData[15];
	else	pbTemp1 = 0;
	if ( pbData && pbData[0] > 0x3C ){
		nVal = pbData[0] - 60;
		cnt = 0;
	}
	else{
		nVal = 0;
		cnt = 0;
	}

	do
	{
		ret = 0;
		if ( g_dword_1001AC40[cnt].unk08 )
		{
			LPFnD_HPDPDP pFunc = (LPFnD_HPDPDP)g_dword_1001AC40[cnt].pFunc;
			if ( pFunc(hDevInfo, pDevData, g_dword_1001AC40[cnt].unk08,	pbTemp1,	nVal,	(PDWORD )&ret) )
			{
				if ( pParam )
					*(PDWORD )((char *)pParam + g_dword_1001AC40[cnt].unk00) = 0;
				result += ret;
			}
			else
			{
				*(PDWORD )((char *)pParam + g_dword_1001AC40[cnt].unk04) = (DWORD)pbTemp1;
				nVal -= ret;
				pbTemp1 += ret;
				result += ret;
			}
		}
		else if ( pParam )
		{
			PBYTE pTemp = (BYTE *)pParam + g_dword_1001AC40[cnt].unk04;
			LPFnD_HPDPDP pFunc = (LPFnD_HPDPDP)g_dword_1001AC40[cnt].pFunc;
			if ( pFunc(hDevInfo,pDevData,g_dword_1001AC40[cnt].unk08,	pTemp,4,0) )
			{
				*(DWORD*)pTemp = 0;
			}
		}
		cnt++;
	}
	while ( cnt < 9 );
	*dwBytes = result + 0x3C;
	if ( pParam!=NULL && (*(DWORD*)pParam) >= result )
		return 0;
	else
		return 0x7A;
}
DWORD sub_10009F30(wchar_t *Source, void *a2)//sub_1000C6B0
{
	DWORD result;
	size_t nLen; 
	DWORD dwOut; 

	result = 87;
	dwOut = 0;
	if ( Source )
	{
		nLen = wcsnlen(Source, 0x104);
		return sub_10006910(g_hFile, 0xEA60E184, Source, 2 * nLen + 2, a2, 4, &dwOut);
	}
	return result;
}
DWORD sub_100070F0(WCHAR* wszStr)//sub_10008CA0
{
	DWORD dwOutsize; 
	PDWORD  dwRet; // esi
	HDEVINFO hDevInfo; // eax
	DWORD dwinfo; // ebx
	PDWORD pAlloc; // edi
	DWORD dwSubRet; // eax
	DWORD dwTmpSize; // esi
	WCHAR* wszsubstr; // eax
	DWORD dwBytes; 


	dwOutsize = 0;
	dwRet = 0;
	if ( !wszStr )		return 0;
	if ( !g_dword_1001FEA4 )
	{
		hDevInfo = SetupDiGetClassDevsW(0, L"ACPI", 0, DIGCF_ALLCLASSES | DIGCF_PRESENT );
		if ( hDevInfo != (HDEVINFO)-1 )
			sub_1000C8D0(hDevInfo);//c8d0
		if ( !g_dword_1001FEA4 )
			return 0;

	}
	dwinfo = sub_1000C700();//c700
	if (!dwinfo ) return 0;

	pAlloc = 0;
	dwBytes = 0;

	while ( 1 )
	{
		dwSubRet = sub_1000A060(0, dwinfo, dwOutsize, &dwBytes);
		if ( dwSubRet == 0x7A )
		{
			if ( pAlloc )
				HeapFree(g_hHeap_1001FE9C, 0, pAlloc);
			dwTmpSize = dwBytes;
			pAlloc = (DWORD*)HeapAlloc(g_hHeap_1001FE9C, 8, dwBytes);
			if ( !pAlloc )
				return 0;
			dwOutsize = dwTmpSize;
			dwSubRet = sub_1000A060(pAlloc, dwinfo, dwTmpSize, &dwBytes);
		}
		if ( !dwSubRet )
		{
			wszsubstr = (WCHAR*)pAlloc[13];
			if ( wszsubstr )
			{
				if ( !wcscmp(wszsubstr, wszStr) )
					break;
			}
		}
		dwinfo = sub_10009FF0(dwinfo);
		if ( !dwinfo )
		{
			if ( pAlloc )
				HeapFree(g_hHeap_1001FE9C, 0, pAlloc);
			return 0;
		}
	}
	dwRet = sub_1000A150();
	*(PDWORD )sub_100070A0(dwRet) = dwinfo;
	if ( pAlloc )
		HeapFree(g_hHeap_1001FE9C, 0, pAlloc);

	return (DWORD)dwRet;
}
DWORD sub_1000C8D0(HDEVINFO hDevInfo)//sub_A180
{

	SIZE_T dwBytes; 
	SP_DEVINFO_DATA DeviceInfoData; 
	int cnt = 0;
	LPVOID hHeap = NULL;
	DWORD dwRet = FALSE;
	DeviceInfoData.cbSize = 28;
	DWORD var_24[2];
	if (SetupDiEnumDeviceInfo(hDevInfo, 0, &DeviceInfoData))
	{
		do{
			if( (dwRet = sub_1000CA00(hHeap, hDevInfo, &DeviceInfoData, &dwBytes))== 0x7A)//sub_1000CA00
			{
				HeapFree((LPVOID)g_hHeap_1001FE9C, 0, hHeap);

				hHeap = HeapAlloc(g_hHeap_1001FE9C, 8, dwBytes);
				if(!hHeap){
					HeapFree((LPVOID)g_hHeap_1001FE9C, 0, hHeap);
					SetupDiDestroyDeviceInfoList(hDevInfo);
					return 8;
				}
				dwRet = sub_1000CA00(hHeap, hDevInfo, &DeviceInfoData, &dwBytes);//sub_1000CA00
			}
			PDWORD  pData= (PDWORD )hHeap;
			pData[0] = dwBytes;
			pData[1] = DeviceInfoData.ClassGuid.Data1;
			pData[2] = DeviceInfoData.ClassGuid.Data2;
			pData[3] = *(PDWORD )(DeviceInfoData.ClassGuid.Data4);
			pData[4] = *(PDWORD )(DeviceInfoData.ClassGuid.Data4 +4);
			if(!dwRet){
				var_24[0] = dwRet;
				if(!sub_10009F30((wchar_t*)pData[7], (void*)var_24))//sub_1000C6B0
				{
					g_dword_1001FEA4 = var_24[0];
					break;
				}

			}
			memset(pData, 0, pData[0]);

		}while(SetupDiEnumDeviceInfo(hDevInfo, cnt, &DeviceInfoData));
		if(hHeap)
			HeapFree(g_hHeap_1001FE9C, 0, hHeap);
	}
	SetupDiDestroyDeviceInfoList(hDevInfo);
	return 1;

}
DWORD sub_1000C700()//sub_1000C700
{
	OVERLAPPED* pOverlap; 
	DWORD OutBuffer; 
	DWORD InBuffer; 
	DWORD NumberOfBytesTransferred; 

	InBuffer = g_dword_1001FEA4;
	NumberOfBytesTransferred = 0;
	OutBuffer = 0;
	pOverlap = sub_100065B0();
	if ( pOverlap )
	{
		DeviceIoControl(g_hFile, 0xEA60E188, &InBuffer, 4, &OutBuffer, 4, 0, pOverlap);
		if ( !GetOverlappedResult(g_hFile, pOverlap, &NumberOfBytesTransferred, 1) )
			GetLastError();
	}
	return OutBuffer;
}
DWORD  sub_1000A060(PDWORD pdwOut, DWORD InBuffer, DWORD nOutBufferSize, PDWORD a4)
{
	PDWORD pOutbuf; 
	OVERLAPPED* pOverlap; 
	DWORD result; 
	DWORD dwtmp; 
	DWORD NumberOfBytesTransferred; 
	DWORD dwOut; 

	NumberOfBytesTransferred = 0;
	dwOut = 0;
	if ( pdwOut && nOutBufferSize >= 0x38 )
	{
		pOutbuf = pdwOut;
	}
	else
	{
		pOutbuf = &dwOut;
		nOutBufferSize = 4;
	}

	result = 0;
	pOverlap = getTlsValue_10004D00();
	if ( pOverlap )
	{
		DeviceIoControl(g_hFile, 0xEA60E190, &InBuffer, 4, pOutbuf, nOutBufferSize, 0, pOverlap);
		if ( !GetOverlappedResult(g_hFile, pOverlap, &NumberOfBytesTransferred, 1) )
		{
			result = GetLastError();
			if ( result == 0xE0000109 )				
				result = 0x5B4;
		}
	}
	else
	{
		result = 0x5AA;
	}
	if ( !result )
	{
		if ( NumberOfBytesTransferred == 4 )
		{
			dwtmp = dwOut;
			result = 0x7A;
		}
		else
		{
			dwtmp = *(WORD*)pdwOut;
			pdwOut[13] = pdwOut[13] + (DWORD)pdwOut;		
			pdwOut[12] = pdwOut[12] + (DWORD)pdwOut;
			pdwOut[11] = pdwOut[11] + (DWORD)pdwOut;				
			result = 0;
		}
		if ( a4 )
			*a4 = dwtmp;
	}
	return result;
}
DWORD sub_10009FF0(DWORD InBuffer)
{

	OVERLAPPED *lpOverlap; 
	DWORD OutBuffer; 
	DWORD NumberOfBytesTransferred; 

	OutBuffer = 0;
	NumberOfBytesTransferred = 0;
	lpOverlap = getTlsValue_10004D00();
	if ( lpOverlap )
	{
		DeviceIoControl(g_hFile, 0xEA60E18C, &InBuffer, 4, &OutBuffer, 4, 0, lpOverlap);
		if ( !GetOverlappedResult(g_hFile, lpOverlap, &NumberOfBytesTransferred, 1) )
			GetLastError();
	}
	return OutBuffer;
}
PDWORD  sub_100070A0(PDWORD  pdwBuf)
{
	if ( pdwBuf && pdwBuf[0] == (DWORD)pdwBuf && !strcmp((char*)pdwBuf[3], "HACPI") )
		return pdwBuf + 0x10;
	else return 0;
}

DWORD sub_10008CA0(WCHAR* wszStr)//sub_10008CA0 //sub_10008CA0
{
	DWORD dwOutsize; 
	PDWORD  dwRet; // esi
	HDEVINFO hDevInfo; // eax
	DWORD dwinfo; // ebx
	PDWORD pAlloc; // edi
	DWORD dwSubRet; // eax
	DWORD dwTmpSize; // esi
	WCHAR* wszsubstr; // eax
	DWORD dwBytes; 


	dwOutsize = 0;
	dwRet = 0;
	if ( !wszStr )		return 0;
	if ( !g_dword_1001FEA4 )
	{
		hDevInfo = SetupDiGetClassDevsW(0, L"ACPI", 0, DIGCF_ALLCLASSES | DIGCF_PRESENT );
		if ( hDevInfo != (HDEVINFO)-1 )
			sub_1000C8D0(hDevInfo);//sub_1000C8D0
		if ( !g_dword_1001FEA4 )
			return 0;

	}
	dwinfo = sub_1000C700();//sub_1000C700
	if (!dwinfo ) return 0;

	pAlloc = 0;
	dwBytes = 0;

	while ( 1 )
	{
		dwSubRet = sub_1000A060(0, dwinfo, dwOutsize, &dwBytes);//sub_1000C7E0
		if ( dwSubRet == 0x7A )
		{
			if ( pAlloc )
				HeapFree(g_hHeap_1001FE9C, 0, pAlloc);
			dwTmpSize = dwBytes;
			pAlloc = (DWORD*)HeapAlloc(g_hHeap_1001FE9C, 8, dwBytes);
			if ( !pAlloc )
				return 0;
			dwOutsize = dwTmpSize;
			dwSubRet = sub_1000A060(pAlloc, dwinfo, dwTmpSize, &dwBytes);//sub_1000C7E0
		}
		if ( !dwSubRet )
		{
			wszsubstr = (WCHAR*)pAlloc[13];
			if ( wszsubstr )
			{
				if ( !wcscmp(wszsubstr, wszStr) )
					break;
			}
		}
		dwinfo = sub_10009FF0(dwinfo);//sub_1000C770
		if ( !dwinfo )
		{
			if ( pAlloc )
				HeapFree(g_hHeap_1001FE9C, 0, pAlloc);
			return 0;
		}
	}
	dwRet = sub_1000A150();
	*(PDWORD )sub_100070A0(dwRet) = dwinfo;//sub_10008C50
	if ( pAlloc )
		HeapFree(g_hHeap_1001FE9C, 0, pAlloc);

	return (DWORD)dwRet;
}
