#pragma once
#include "Storage.h"

class CCmos : public CStorage
{
public:
	CCmos();
	virtual ~CCmos();//sub_100052B0


public:
	virtual BOOL sub_1000BEB0();
	virtual BOOL sub_10007CF0(BYTE byVal, BYTE* pbyBuf, int nCnt);
	virtual BOOL sub_10007D50(BYTE byVal, BYTE* pbyBuf, int nCnt);
	virtual DWORD sub_10007DB0(DWORD* pdwVal1, DWORD* pdwVal2);
	virtual BOOL _JidaVgaSetContrastEnable(DWORD arg1, DWORD arg2);
};


