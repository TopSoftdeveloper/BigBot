#pragma once
#include "MultiSensor.h"
//#include "Jida_global.h"

typedef struct tagW836XPARAM_6C //0x4E4
{
	WORD wHeaderlen_0;		//0xD0
	WORD wBodyLen_2;		//0x414
	DWORD pAddrBody_4;		// SMBUSPARAM* + 0xD0
	DWORD pAddHeaderInfo_8;	// SMBUSPARAM* + 0x20
	DWORD dwUnk_C;
	DWORD dwCode_10;
	DWORD dwUnk_14;
	DWORD dwUnk_18;
	DWORD dwUnk_1C;
	DWORD dwPrefixBody_4C;
} W836XPARAM_6C, *LW836XPARAM_6C;

typedef struct tagSMBUSPARAM //0x4E4
{
	WORD wHeaderlen_0;		//0xD0
	WORD wBodyLen_2;		//0x414
	DWORD pAddrBody_4;		// SMBUSPARAM* + 0xD0
	DWORD pAddHeaderInfo_8;	// SMBUSPARAM* + 0x20
	DWORD dwUnk_C;
	DWORD dwCode_10;
	DWORD dwUnk_14;
	DWORD dwUnk_18;
	DWORD dwUnk_1C;
	BYTE  AddInfo_20[0xB0];
	BYTE  Body_D0[0x414];
} SMBUSPARAM, *LPSMBUSPARAM;

class CW836x;
typedef BYTE (__thiscall CW836x:: *CW386_LPFnB_DBP)(DWORD, BYTE, PBYTE);
typedef BYTE (__thiscall CW836x:: *CW386_LPFnB_DBB)(DWORD, BYTE, BYTE);
class CW836x : public CMultiSensor, public CSuperIo
{

public:

	CW836x();
	BOOL sub_1000B150();//sub_1000D890
	BOOL sub_1000B2B0(DWORD bySrc, BYTE byVal, BYTE *pDest);
	BOOL sub_1000B370(DWORD bySrc, BYTE byVal,BYTE byParam);
	void sub_1000B070(DWORD OutBuffer, BYTE byParam, BYTE *pDest);
	void sub_1000B0F0(BYTE byArg1, BYTE byArg2, BYTE byArg3);
	WORD sub_10008630();
	BYTE sub_1000AE80();//sub_1000D5C0
	BYTE sub_1000AAE0(WORD wArg1);
	BYTE sub_1000ADF0();//sub_1000D530
	BYTE sub_1000AF00();//sub_1000D640
	BOOL sub_1000AF70();//sub_1000D6B0
	DWORD sub_1000A620();
	DWORD m_dw04;
	WORD m_w08;
	CW386_LPFnB_DBP m_lpFn10;//sub_1000B2B0
	DWORD m_dw14;
	CW386_LPFnB_DBB m_lpFn18;
	DWORD m_dw1C;
	WORD m_w20;
	WORD m_w22;
	
	PBYTE m_pby24;
	BYTE m_by28;
	WORD m_w2A;
	PBYTE m_pby2C;
	BYTE m_by30;
	WORD m_w32;
	PBYTE  m_pby34;
	BYTE m_by38;
	WORD m_w3A;
	DWORD m_dw3C;
	CRITICAL_SECTION m_cs40;
	DWORD m_dw58;
	DWORD m_dw5C;
	DWORD* m_pdw60;
	W836XPARAM_6C* m_pWPARAM64;
	
public:	
	virtual ~CW836x(); //virtual void sub_1000CC20();
	//virtual DWORD sub_1000CBD0();
	virtual DWORD sub_1000CDF0();
	//virtual DWORD purecall();
	virtual DWORD sub_100081C0();
	virtual DWORD sub_10008200(DWORD dwArg);
	virtual DWORD sub_10008250(DWORD dwArg1, DWORD dwArg2, PDWORD pdwArg3);
	virtual DWORD sub_100082B0(DWORD dwArg1, DWORD dwArg2, PDWORD pdwArg3, PDWORD pdwArg4);
	virtual DWORD sub_10006F60(DWORD dwArg1, DWORD dwArg2, PDWORD pdwArg3);
	virtual DWORD sub_10008300(DWORD dwFlag, DWORD dwArg2, PDWORD pdwArg3);
	virtual DWORD sub_10008350(DWORD dwFlag, DWORD dwArg2, PDWORD pdwArg3);
	virtual DWORD sub_100083A0(DWORD dwArg1, DWORD dwArg2, PDWORD pdwArg3);
	virtual BYTE sub_1000CBE0();
	virtual BYTE sub_1000CC00();
	virtual BYTE sub_1000CBF0();
	virtual DWORD sub_1000CE70(WORD, PDWORD);
	virtual DWORD sub_1000D290(WORD dwArg1, DWORD *pdwArg2);
	virtual DWORD sub_1000CF20(WORD dwArg1, DWORD *pdwArg2);
	virtual DWORD sub_1000CFA0(BYTE byArg1, DWORD *a3, DWORD *a4);
	virtual DWORD sub_1000D300(WORD wArg1, DWORD *pdwArg2, DWORD *pdwArg3);
	virtual DWORD sub_1000CFE0(WORD wArg1, DWORD *pdwArg2, DWORD *pdwArg3);
	virtual DWORD sub_1000D040(WORD wArg1, PDWORD pdwArg2);
	virtual DWORD sub_1000D360(WORD wArg1, PDWORD pdwArg2);
	virtual DWORD _JidaVgaSetContrastEnable(DWORD, PDWORD);
	virtual DWORD sub_1000D3A0(WORD wArg1, DWORD *pdwArg4);
	virtual DWORD sub_1000D080(WORD wArg1, DWORD *pdwArg2);
	//virtual DWORD _JidaVgaSetContrastEnable(DWORD, PDWORD);
	virtual DWORD sub_1000D0E0(WORD wArg1, DWORD *pdwArg2);
	virtual DWORD sub_1000D420(WORD wArg1, DWORD *pdwArg2);
	//virtual DWORD _JidaVgaSetContrastEnable(DWORD, PDWORD);
	virtual DWORD sub_1000D140(WORD wArg1, PWORD pdwArg2);
	virtual DWORD sub_1000D4A0(WORD wArg1, PDWORD pdwArg2);
	virtual DWORD sub_1000D1D0(WORD wArg1, PDWORD pdwArg2);
	//purecall
	//purecall
	//purecall
	//virtual LPVOID sub_1000A4D0(LPVOID lpMem, BYTE bFlag);//
	//virtual void sub_1000B4E0();//
};

