#pragma once
#include "MultiSensor.h"
#include "Smbus_Def.h"
class CW83L771Ax;
typedef BYTE (__thiscall CW83L771Ax:: *CW83L771Ax_LPFnB_DDDDPD)(DWORD, DWORD, DWORD, DWORD, BYTE *, DWORD);
typedef BYTE (__thiscall CW83L771Ax:: *CW83L771Ax_LPFnB_DBB)(DWORD, BYTE, BYTE);
class CW83L771Ax:public CMultiSensor
{
public:
	CW83L771Ax();
	~CW83L771Ax();
public:
	CSmbus_Def* m_pSmbus_Def4;
	BYTE m_by08;
	
public:

	virtual void sub_1000CBD0();
	virtual DWORD sub_1000BEB0();
	virtual DWORD sub_1000B190();
	virtual DWORD sub_100081C0(DWORD i);
	virtual DWORD sub_10008200(DWORD dwArg1, DWORD dwArg2, PDWORD pdwArg3);
	virtual DWORD sub_10008250(DWORD dwArg1, DWORD dwArg2, DWORD* pdwArg3, DWORD* pdwArg4);
	virtual DWORD sub_100082B0(DWORD dwArg1, DWORD dwArg2, PDWORD pdwArg3);
	virtual DWORD sub_10008300(DWORD dwFlag, DWORD dwArg2, PDWORD pdwArg3);
	virtual DWORD sub_10008350(DWORD dwFlag, DWORD dwArg2, PDWORD pdwArg3);
	virtual DWORD sub_100083A0(DWORD dwArg1, DWORD dwArg2, PDWORD pdwArg3);
	virtual DWORD sub_1000C590();
	virtual DWORD sub_1000AEB0(DWORD dwArg1, DWORD *pdwArg2);
	virtual DWORD _JidaVgaSetContrastEnable(DWORD dwArg1, DWORD *pdwArg2);
	virtual DWORD sub_1000B060(WORD wArg1, DWORD *pdwArg2, DWORD *pdwArg3);
	virtual BOOL _JidaVoltageSetLimits(WORD wArg1, DWORD *pdwArg2, DWORD *pdwArg3);
	virtual DWORD sub_1000B0B0(WORD wArg1, DWORD *pdwArg2);
	virtual DWORD sub_1000AF70(DWORD dwArg1, DWORD *pdwArg2);
	virtual DWORD sub_1000AFF0(DWORD dwArg1, DWORD *pdwArg2);
	virtual DWORD sub_1000B0F0(DWORD dwArg1, DWORD *pdwArg2);
	virtual DWORD sub_10009DF0();//escape
};

