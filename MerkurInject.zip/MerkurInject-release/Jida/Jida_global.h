#pragma once
#include <setupapi.h>
#include "Cmos.h"
#include "EmbeddedEeprom.h"
#include "GpioDefaultProxy.h"
//#include "Smbus_Def.h"
#include "W83627DHGP.h"
#pragma comment(lib,"../Lib/SetupAPI.Lib")
typedef struct tagFuncTable20{
	DWORD unk00;
	DWORD unk04;
	DWORD unk08;
	DWORD unk0C;
	LPVOID pFunc;
} FUNCTBL20, *PFUNCTBL20;
typedef struct tagFUNCSTRUC14{
	DWORD dwSelfAddr00;
	LPVOID pFunc04;
	DWORD dwFlag08;
	char* szStr0C;
	DWORD dwParam10;
} FUNCSTRUC14, *PFUNCSTRUC14;


/////////////////////
typedef struct tagDEVINFO {
	FLONG   flGraphicsCaps;
	LOGFONTW  lfDefaultFont;
	LOGFONTW  lfAnsiVarFont;
	LOGFONTW  lfAnsiFixFont;
	ULONG  cFonts;
	ULONG  iDitherFormat;
	USHORT  cxDither;
	USHORT  cyDither;
	HPALETTE  hpalDefault;
	FLONG  flGraphicsCaps2;
} DEVINFO, *PDEVINFO;

typedef struct tagFuncTable16{
	DWORD unk00;
	DWORD unk04;
	DWORD unk08;
	LPVOID pFunc;
} FUNCTBL16, *PFUNCTBL16;

typedef struct tagFUNCSTRUC10{
	DWORD dwSelfAddr00;
	LPVOID pFunc04;
	DWORD dwFlag08;
	char* szStr0C;
	DWORD dwParam10;
} FUNCSTRUC10, *PFUNCSTRUC10;


typedef struct tagDEVINPUT_1C 
{
	int nCmd_0;
	int nParam_4;
	int nParam_8;
	int nParam_c;
	int nParam_10;
	int nParam_14;
	int nParam_18;
} DEVINPUT_1C, *LPDEVINPUT_1C;
typedef struct tagDEVOUT_0C 
{
	int nErrCode_0;
	int nResult_4;
	int nAddInfo_8;

} DEVOUT_0C, *LPDEVOUT_0C;
typedef struct tagSTRINGARRAY{
	DWORD dwIndex;
	char* szStr;
} STRINGARRAY, *PSTRINGARRAY;

//////////////////////////////////////////////////////////////////////////
typedef struct tagControlDevice30{
	DWORD dwOutBuffer[5];
	LPVOID lpClass;
	DWORD dwUnk18;
	DWORD dwUnk1C;
	DWORD dwUnk20;
	DWORD dwUnk24;
	DWORD dwFlag;
	DWORD dwUnk2C;

}ControlDevice30,*PControlDevice30;
typedef void (__thiscall* LPFnV_BDB)(BYTE, DWORD, BYTE);
typedef UINT (__thiscall* LPFnU_V)(VOID);
typedef VOID (__thiscall* LPFnV_V)(VOID);
typedef UINT (__thiscall* LPFnU_D)(DWORD);
typedef VOID (__thiscall* LPFnV_D)(DWORD);
typedef UINT (__thiscall* LPFnU_DDDD)(DWORD, DWORD, DWORD, DWORD);
typedef UINT (__thiscall* LPFnU_DDD)(DWORD, DWORD, DWORD);
typedef VOID (__thiscall* LPFnV_P)(PDWORD);

typedef UINT (__thiscall* LPFnU_DDDDD)(DWORD, DWORD, DWORD, DWORD, DWORD);
typedef UINT (__thiscall* LPFnU_DDDPD)(DWORD, DWORD, DWORD, LPVOID, DWORD);
typedef DWORD (__thiscall* LPFnD_DDD)(DWORD, DWORD, DWORD);
typedef DWORD (__thiscall* LPFnD_DDDP)(DWORD, DWORD, DWORD, LPVOID);
typedef UINT (__thiscall* LPFnU_DD)(DWORD, DWORD);
typedef UINT (__thiscall* LPFnU_DDPP)(DWORD, DWORD, LPVOID, LPVOID);
typedef UINT (__thiscall* LPFnU_DDP)(DWORD, DWORD, LPVOID);
typedef UINT (__thiscall* LPFnU_DP)(DWORD, LPVOID);
typedef UINT (__thiscall* LPFnU_PP)(LPVOID, LPVOID);
typedef DWORD (__thiscall* LPFnD_BDD)(BYTE, DWORD, DWORD);

typedef DWORD* (__thiscall* LPFnP_V)(VOID);
typedef DWORD* (__cdecl* LPFnP_D)(DWORD);
typedef DWORD (__cdecl* LPFnD_V)(VOID);
typedef DWORD (__cdecl* LPFnD_HPDPDP)( HDEVINFO, PSP_DEVINFO_DATA, DWORD, PBYTE, DWORD, PDWORD );
typedef BOOL (WINAPI *LPUpdateDriverForPlugAndPlayDevices)(HWND, LPCWSTR, LPCWSTR, DWORD, PBOOL);
typedef int  (WINAPI *LPInstallSelectedDriver)(DWORD, HDEVINFO, DWORD, DWORD, int *);

extern FUNCTBL16 g_dword_1001AC40[9];
extern HANDLE g_hFile;
extern DWORD g_dwTlsIndex_1001F01C;
extern DWORD g_dword_1001FEA4;
extern DWORD g_dword_1001FDB8[24];
extern DWORD g_dword_1001FE18[10];

extern LPVOID g_pGpioDefaultProxy_1001FE40;
extern CRITICAL_SECTION g_CS_1001FE44;



extern HMODULE g_hModule_1001FE5C;
extern PDWORD g_pClassList_1001FE60[8];
extern DWORD g_dword_1001FE80;
extern DWORD g_dword_1001FE84;
extern DWORD g_dword_1001FE88;
extern DWORD g_dword_1001FE8C;
extern DWORD g_dword_1001FE90;
extern HANDLE g_hMutex_1001FE94;
extern HANDLE g_hMutex_1001FEB0;
extern DWORD g_DWORD_1001FE98;
extern HANDLE g_hHeap_1001FE9C;
extern DWORD g_pCSmbus_Def_1001FEA0;


extern DWORD g_dword_1001FEB4[8];
extern DWORD g_dword_1001FED4;
extern LPVOID g_lpMem_1001FED8;
// extern LPVOID g_pEmbeddedEeprom_1001FEDC;
// extern LPVOID g_pCCmos_1001FEE0;
extern LPVOID g_pStorage_1001FEDC[2];
//
//
extern DWORD g_dword_1001FEE4;
extern DWORD g_dword_1001AF88[24];
extern DWORD g_dword_1001AFE8[60];
extern DWORD g_dword_1001FEA8[2];
//////////////////////////////////////////////////////////////////////////
extern  DWORD g_dword_1001AE3C[4];
extern  DWORD g_dword_10015D48[6];
extern  DWORD g_dword_10015D60[21];
extern  BYTE g_byte_10015D20[16];
extern  BYTE g_byte_10015D30[24];
extern DWORD g_dword_1001AF48[16];
extern DWORD g_dword_10015BB0[14];
extern DWORD g_dword_10015A60[9];
extern DWORD g_dword_10015AA8[32];
extern DWORD g_dword_10015A84[9];
extern DWORD g_dword_10015B28[32];
extern BYTE g_byte_10015BA8[8];
extern STRINGARRAY g_dword_1001AE48[24];

DWORD sub_10005A10(PBYTE byBuf);
OVERLAPPED*  getTlsValue_10004D00(void);
OVERLAPPED* sub_100065B0();
DWORD sub_10004550();
DWORD sub_10006AC0(DWORD* pdwIn, LPCWSTR lpServiceName);
DWORD sub_10006980(HANDLE* pFileHandle, GUID* bGUID);
DWORD sub_100048E0(PBYTE lpOutBuffer);
DWORD sub_10006B30();
DWORD sub_10006AA0();
BOOL sub_10008E40();
DWORD sub_10006D30();
void sub_10007490();
BOOL sub_10008E40();
BOOL sub_10006E90();
LPVOID sub_10009DF0();
SHORT *sub_10007E20();
LPVOID sub_10006F60(PBYTE pbAddr, DWORD dwClassAddr, PDWORD  pdwOutBuff, DWORD dwFlag);
BOOL sub_10006FA0(PControlDevice30 lpParam);
LPVOID		sub_10007770(LPVOID lpMem);
DWORD sub_10004BC0(PDWORD  pdwIn, DWORD dwFlag, WORD wSize, PWORD dwVal4);
DWORD sub_1000AC60(WORD wArg1);
BOOL sub_10008120(DWORD dwArg1, int iClassType);
DWORD sub_100047D0(BYTE InBuffer, LPVOID lpOutBuffer);
LPVOID sub_1000CC50(SHORT wArg1, BYTE bArg2, BYTE bArg3, DWORD dwArg4);

SHORT* sub_10007FD0(PDWORD  pdwArg1, int iClassType);
DWORD sub_1000C8D0(HDEVINFO hDevInfo);
DWORD sub_10006910(	void *a1, 
				   DWORD dwIoControlCode,	
				   void *lpInBuffer,	
				   DWORD nInBufferSize,
				   void *lpOutBuffer,
				   DWORD nOutBufferSize, 
				   PDWORD  lpNumberOfBytesTransferred);
int sub_10006D90(PDWORD  pdwBuff1, PDWORD  pdwBuff2);
int sub_10005430(DWORD dwArg1, LPVOID lpOutBuffer);
int sub_10004960(DWORD *pdwArg1);
int sub_100085C0(DWORD *pdwArg1, BYTE byArg2);
int sub_10006BA0(char bParam1, PDWORD  pdwParam2, WORD wParam3, PDWORD pdwRetVal);
int sub_10008540( int nVal,	 PDWORD pdwBuff1, PBYTE pbMem, WORD wSize, PWORD pdwRet);
int sub_10008C10(PBYTE pbBuff1, PBYTE pbBuff2);
int sub_100083F0(BYTE * pbBuff1, BYTE *pbBuff2);
int  sub_10008770(PBYTE pbBuff1, PBYTE pbBuff2);
int  sub_100086B0(PBYTE pbSrc, PBYTE pbBuff);
int sub_10004680();
DWORD sub_10005FB0(PFUNCSTRUC14 pFuncInfo);
int sub_100049C0(DWORD *pdwArg1);
DWORD sub_10005F20(BYTE byArg1);
int  sub_10004110(DWORD dwArg1, PFUNCSTRUC14 pFuncInfo);
PControlDevice30 sub_10007840(WORD wCnt, PDWORD pdwArg2);
DWORD sub_10001000(PControlDevice30 pCtrlDev);
int sub_10007440(PControlDevice30 pCtrlDev, void *lpArg2, size_t dwArg3, DWORD dwArg4);
int sub_10007120(PControlDevice30 pCtrlDevice, SIZE_T nSize, DWORD dwArg2, BYTE *Src);
int  sub_10007370(PControlDevice30 pCtrlDev);
int sub_10007290(PControlDevice30 pCtrlDev, SIZE_T dwArg2, unsigned int dwArg3);
void* memset_10006790(size_t Size , void * lpDest);
LPVOID sub_10006770(void *lpSrc);
DWORD sub_10001040(DWORD *pdwOffset, DWORD *pdwRes);
DWORD sub_10001080(DWORD *pdwOffset, DWORD *pdwRes1, DWORD* pdwRes2);
DWORD sub_100010D0(DWORD *pdwOffset, DWORD *pdwRes);
DWORD sub_10001110(DWORD *pdwOffset, DWORD *pdwRes);
DWORD sub_10001150(DWORD *pdwOffset, DWORD *pdwRes);
int sub_10001190(DWORD* pdwOffset, PDWORD pdwRes);
WCHAR* sub_100067E0(char* szStr, DWORD dwSizeWBuf, WCHAR* wszStr);
DWORD sub_100063C0(WCHAR *pwSrc, WCHAR *pwDest, int dwLen);
BOOL sub_10006870(WCHAR* wszBuf,WCHAR* pwDest,int nMaxLen);
BOOL sub_10004420(FUNCSTRUC14* pfun, DWORD dwArgIdx, WORD wArg, WORD* pwDest, DWORD dwMaxLen, DWORD* pdwStrlen);
int sub_10006290(char *pszDest, char* pszSrc, DWORD dwLen);
BOOL sub_10006850(char* pszStr,char* pszDest, int nMax);
int sub_10004340(FUNCSTRUC14* pfun,DWORD dwArgIdx,WORD wArg, char* pszDest,  int nMax, DWORD* pdwRes);
DWORD sub_10005500(DWORD dwArg2, DWORD dwArg3, DWORD dwParam );
DWORD sub_100055D0(DWORD dwArg, DWORD dwParam);
DWORD sub_100056A0(LPVOID lpOutBuffer, DWORD dwParam);
DWORD sub_10006140(LPVOID lpOutBuffer);
DWORD sub_10006050(char InBuffer, DWORD dwParam);
DWORD sub_100060D0(LPVOID lpOutBuffer);
DWORD sub_100061B0(DWORD InBuffer, DWORD dwMilliseconds);
int sub_10004D40(rsize_t dwArg1, int dwArg2, SHORT dwArg3, DWORD *pdwDest, PDWORD pdwArg5);
DWORD sub_10005760(DWORD* pdwArg, BYTE* pbyArg);
DWORD sub_10004E80(DWORD a1, WORD a2, void *Source, DWORD dwSizeSrc, PDWORD a5, DWORD a6);
DWORD sub_10004FB0(DWORD dwArg1, DWORD dwArg2, WORD wArg3, void *Source, DWORD SrcSize, DWORD* pdwArg6, void* Dest,PDWORD pdwArg8,  int nArg9);
DWORD sub_10006CC0(DWORD dwParam);
int sub_100052C0(int nSizeDest, int a2, WORD a3, WORD a4, int a5, void *pDest);
int sub_10005160(DWORD dwlen, DWORD a2, DWORD a3, WORD a4, WORD a5, void *Source);
int sub_10009720(DWORD dwArg1, DWORD *pdwArg2);
DWORD sub_100091E0(const WCHAR *pszArg1, BOOL *a2);
DWORD sub_10009330(PCWSTR FileName, DWORD dwArg2, int *pdwArg3);
DWORD sub_10009990(HINF InfHandle, PDWORD pdwArg2);
DWORD sub_10009170(DWORD *pdwBuff);
int sub_10009C60(DWORD dwArg1, PDWORD pdwArg2, PINFCONTEXT Context);
int sub_10009B40(HINF InfHandle, int dwArg2, PCWSTR Section, PDWORD *pdwArg4);
void sub_100072A0(WORD wCnt, BYTE *pSrc, SMBUSPARAM* pDest, WORD wMod);
DWORD sub_10009940(	int dwArg1,	DWORD *pdwArg2, HDEVINFO DeviceInfoSet, PSP_DEVINFO_DATA DeviceInfoData,	PBYTE PropertyBuffer);
DWORD *sub_10009180(DWORD *dwBuff);
DWORD sub_100070F0(WCHAR* wszStr);
DWORD MySetupDiGetDeviceRegistryProperty_1000CB20(	HDEVINFO DeviceInfoSet,	PSP_DEVINFO_DATA DeviceInfoData,DWORD Property,	PBYTE PropertyBuffer,	DWORD PropertyBufferSize,	PDWORD  RequiredSize);
DWORD MySetupDiGetDeviceRegistryProperty_1000CB70(	HDEVINFO DeviceInfoSet,	PSP_DEVINFO_DATA DeviceInfoData,DWORD Property,	PBYTE PropertyBuffer);
DWORD sub_1000C700();
DWORD  sub_1000A060(PDWORD pdwOut, DWORD InBuffer, DWORD nOutBufferSize, PDWORD a4);
DWORD sub_10009FF0(DWORD InBuffer);
PDWORD  sub_100070A0(PDWORD  pdwBuf);
DWORD sub_10007460(SMBUSPARAM* lpBuf, DWORD dwParam, DWORD dwCmd, PDWORD pdwOut);
DWORD sub_100073E0(PDWORD pDest, SMBUSPARAM* plpParam);
DWORD sub_10004750(BYTE bArg1, DWORD dwArg2);
DWORD		sub_100030C0(char InBuffer, LPVOID lpOutBuffer);
DWORD sub_1000CA00(LPVOID pParam, HDEVINFO hDevInfo, SP_DEVINFO_DATA* pDevData, DWORD* dwBytes);
DWORD sub_10009F30(wchar_t *Source, void *a2);
int  sub_10008830(PBYTE pbBuff1, PBYTE pbBuff2);
int  sub_100088B0(PBYTE pbBuff1, PBYTE pbBuff2);
int  sub_100089D0(PBYTE pbBuff1, PBYTE pbBuff2);
int  sub_10008A90(PBYTE pbBuff1, PBYTE pbBuff2);
int  sub_10008AE0(PBYTE pbBuff1, PBYTE pbBuff2);
int  sub_10008B30(PBYTE pbBuff1, PBYTE pbBuff2);
int sub_10004B10(BYTE *pbBuff1, int nVal, BYTE *pbBuff2);