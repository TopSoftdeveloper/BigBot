#include "stdafx.h"
#include "GpioDefaultProxy.h"
#include "Jida_global.h"

CGpioDefaultProxy::CGpioDefaultProxy()
{
}


CGpioDefaultProxy::~CGpioDefaultProxy()
{
}


DWORD CGpioDefaultProxy::sub_10009EA0(DWORD *pdwArg1)
{
	DWORD result; 
	DWORD dwTmp; 
	DWORD pdwTmp[10];
	
	result = sub_1000A3C0(pdwTmp);
	if ( !result )
	{
		dwTmp = (pdwTmp[0] | pdwTmp[1]) - (((pdwTmp[0] | pdwTmp[1]) >> 1) & 0x55555555);
		*pdwArg1 = (16843009*(((dwTmp & 0x33333333) + ((dwTmp >> 2) & 0x33333333) + (((dwTmp & 0x33333333) + ((dwTmp >> 2) & 0x33333333)) >> 4)) & 0xF0F0F0F)) >> 24;
	}
	return result;
}


DWORD CGpioDefaultProxy::sub_1000A330(DWORD dwArg1, DWORD dwArg2)
{
	
	OVERLAPPED *pOverlapped; 
	struct _OVERLAPPED *v5; 
	DWORD result; 
	DWORD NumberOfBytesTransferred; 
	int InBuffer[9]; 

	
	NumberOfBytesTransferred = 0;
	InBuffer[0] = dwArg1;
	InBuffer[1] = dwArg2;
	pOverlapped = (OVERLAPPED *)sub_100065B0();
	v5 = pOverlapped;
	if ( !pOverlapped )
		return 1450;
	DeviceIoControl(m_hHandle, 0xEA60A100, InBuffer, 0x24, 0, 0, 0, pOverlapped);
	if ( GetOverlappedResult(m_hHandle, pOverlapped, &NumberOfBytesTransferred, 1) )
		return 0;
	result = GetLastError();
	if ( result == 0xE0000109 )
		return 1460;
	return result;
}


DWORD CGpioDefaultProxy::sub_1000A200(DWORD InBuffer, PDWORD pdwArg2)
{
	 
	
	 OVERLAPPED *pOverlapped; 
	
	 DWORD result; 
	 DWORD NumberOfBytesTransferred;
	 int OutBuffer[9]; 

	
	 NumberOfBytesTransferred = 0;
	 pOverlapped = (struct _OVERLAPPED *)sub_100065B0();
	 if ( !pOverlapped )
		 return 1450;

	 DeviceIoControl(m_hHandle, 0xEA60E118, &InBuffer, 4, OutBuffer, 0x24u, 0, pOverlapped);
	 if ( GetOverlappedResult(m_hHandle, pOverlapped, &NumberOfBytesTransferred, 1) )
	 {
		 *pdwArg2 = OutBuffer[0];
		 return 0;
	 }
	 result = GetLastError();
	
	 if ( result == 0xE0000109 )
		 return 1460;

	 if ( !result )
	 {

		  *pdwArg2 = OutBuffer[0];
		 return 0;
	 }
	 return result;

}


DWORD CGpioDefaultProxy::sub_1000A040(DWORD dwArg1, PDWORD pdwArg2)
{
	
	OVERLAPPED *pOverlapped;
	
	DWORD result; 
	DWORD NumberOfBytesTransferred; 
	int InBuffer[9];
	
	NumberOfBytesTransferred = 0;
	InBuffer[0] = dwArg1;
	memcpy(&InBuffer[1], pdwArg2, 32);
	
	pOverlapped = (OVERLAPPED *)sub_100065B0();
	if ( !pOverlapped )
		return 1450;
	DeviceIoControl(m_hHandle, 0xEA60A108, InBuffer, 0x24, 0, 0, 0, pOverlapped);
	if ( GetOverlappedResult(m_hHandle, pOverlapped, &NumberOfBytesTransferred, 1) )
		return 0;
	result = GetLastError();
	if ( result == 0xE0000109 )
		return 1460;
	return result;
}


DWORD CGpioDefaultProxy::sub_10009F00(DWORD dwArg1, PDWORD pdwArg2)
{
	
	OVERLAPPED *pOverlapped; 
	DWORD result; 
	DWORD NumberOfBytesTransferred; 
	int OutBuffer[9]; 
	NumberOfBytesTransferred = 0;
	pOverlapped = (OVERLAPPED *)sub_100065B0();

	if ( !pOverlapped )
		return 1450;
	DeviceIoControl(m_hHandle, 0xEA60E124, &dwArg1, 4, OutBuffer, 0x24, 0, pOverlapped);
	if ( GetOverlappedResult(m_hHandle, pOverlapped, &NumberOfBytesTransferred, 1) ){
		*pdwArg2 = OutBuffer[0];
		return 0;
	}
	result = GetLastError();
	if ( result == 0xE0000109 )
		return 1460;
	if ( !result )
	{
		*pdwArg2 = OutBuffer[0];
		return 0;
	}
	return result;
}


DWORD CGpioDefaultProxy::sub_1000A0D0(DWORD dwArg1, DWORD dwArg2)
{
	OVERLAPPED *pOverlapped; // eax
	DWORD result; 
	DWORD NumberOfBytesTransferred;
	int InBuffer[9]; 
	
	NumberOfBytesTransferred = 0;
	InBuffer[0] = dwArg1;
	InBuffer[1] = dwArg2;
	pOverlapped = (OVERLAPPED *)sub_100065B0();
	
	if ( !pOverlapped )
		return 1450;
	DeviceIoControl(m_hHandle, 0xEA60A10C, InBuffer, 0x24, 0, 0, 0, pOverlapped);
	if ( GetOverlappedResult(m_hHandle, pOverlapped, &NumberOfBytesTransferred, 1) )
		return 0;
	result = GetLastError();
	if ( result == 0xE0000109 )
		return 1460;
	return result;
}


DWORD CGpioDefaultProxy::sub_10009FA0(DWORD dwArg1, PDWORD dwArg2)
{
	OVERLAPPED *pOverlapped; 
	DWORD result; 
	DWORD NumberOfBytesTransferred; 
	int OutBuffer[9]; 

	NumberOfBytesTransferred = 0;

	pOverlapped = (OVERLAPPED *)sub_100065B0();
	if ( !pOverlapped )
		return 1450;
	DeviceIoControl(m_hHandle, 0xEA60E120, &dwArg1, 4, OutBuffer, 0x24, 0, pOverlapped);
	if ( GetOverlappedResult(m_hHandle, pOverlapped, &NumberOfBytesTransferred, 1) )
	{
		*dwArg2 = OutBuffer[0];
		return 0;
	}
	result = GetLastError();
	if ( result == 0xE0000109 )
		return 1460;
	if ( !result )
	{	*dwArg2 = OutBuffer[0];
		return 0;
	}
	return result;
}


DWORD CGpioDefaultProxy::sub_1000A2A0(DWORD dwArg1, DWORD dwArg2)
{
	
	OVERLAPPED *pOverlapped;
	DWORD result; 
	DWORD NumberOfBytesTransferred; 
	int InBuffer[9]; 
	
	NumberOfBytesTransferred = 0;
	InBuffer[0] = dwArg1;
	InBuffer[1] = dwArg2;
	pOverlapped = (OVERLAPPED *)sub_100065B0();
	if ( !pOverlapped )
		return 1450;
	DeviceIoControl(m_hHandle, 0xEA60A104, InBuffer, 0x24, 0, 0, 0, pOverlapped);
	if ( GetOverlappedResult(m_hHandle, pOverlapped, &NumberOfBytesTransferred, 1) )
		return 0;
	result = GetLastError();
	if ( result == 0xE0000109 )
		return 1460;
	return result;
}


DWORD CGpioDefaultProxy::sub_1000A160(DWORD dwArg1, PDWORD pdwArg2)
{
	OVERLAPPED *pOverlapped; 
	DWORD result;
	DWORD NumberOfBytesTransferred; 
	int OutBuffer[9]; 
	NumberOfBytesTransferred = 0;
	pOverlapped = (struct _OVERLAPPED *)sub_100065B0();
	if ( !pOverlapped )
		return 1450;
	DeviceIoControl(m_hHandle, 0xEA60E11C, &dwArg1, 4, OutBuffer, 0x24, 0, pOverlapped);
	if ( GetOverlappedResult(m_hHandle, pOverlapped, &NumberOfBytesTransferred, 1) )
	{
		*pdwArg2 = OutBuffer[0];
		return 0;
	}
	result = GetLastError();
	
	if ( result == 0xE0000109 )
		return 1460;
	if ( !result )
	{
		*pdwArg2 = OutBuffer[0];
		return 0;
	}
	return result;
}


DWORD CGpioDefaultProxy::sub_1000A430(DWORD dwArg1, PDWORD pdwArg2)
{
	OVERLAPPED *pOverlapped; 
	DWORD result; 
	DWORD NumberOfBytesTransferred; 
	int InBuffer[36]; 
	
	InBuffer[0] = dwArg1;
	InBuffer[1] = (DWORD)pdwArg2;
		
	NumberOfBytesTransferred = 0;
	pOverlapped = (OVERLAPPED *)sub_100065B0();
	if ( !pOverlapped )
		return 1450;
	DeviceIoControl(m_hHandle, 0xEA60A110, &InBuffer, 0x24, 0, 0, 0, pOverlapped);
	if ( GetOverlappedResult(m_hHandle, pOverlapped, &NumberOfBytesTransferred, 1) )
		return 0;
	result = GetLastError();
	if ( result == 0xE0000109 )
		return 1460;
	return result;
}


DWORD CGpioDefaultProxy::sub_1000A4D0(BYTE InBuffer, BYTE *pbBuff)
{
	

	OVERLAPPED *pOverlapped; 
	DWORD result; 
	DWORD NumberOfBytesTransferred; 
	BYTE OutBuffer[36];


	
	NumberOfBytesTransferred = 0;
	
	pOverlapped = (struct _OVERLAPPED *)sub_100065B0();
	
	if ( !pOverlapped )
		return 1450;
	DeviceIoControl(m_hHandle, 0xEA60E12C, &InBuffer, 4, OutBuffer, 0x24, 0, pOverlapped);
	if ( GetOverlappedResult(m_hHandle, pOverlapped, &NumberOfBytesTransferred, 1) )
	{
		memcpy(pbBuff, OutBuffer + 4, 0x20);
		return 0;
	}
	result = GetLastError();
	
	if ( result == 0xE0000109 )
		return 1460;

	if ( !result )
	{
		memcpy(pbBuff, OutBuffer + 4, 0x20);
		return 0;
	}
	return result;
}


DWORD CGpioDefaultProxy::sub_1000A570(BYTE InBuffer, DWORD *pdwBuff)
{

	
	OVERLAPPED *pOverlapped; 
	
	DWORD result; 
	DWORD NumberOfBytesTransferred; 
	DWORD OutBuffer[9];


	NumberOfBytesTransferred = 0;
	pOverlapped = (struct _OVERLAPPED *)sub_100065B0();
	
	if ( !pOverlapped )
		return 1450;
	DeviceIoControl(m_hHandle, 0xEA60E130, &InBuffer, 4, OutBuffer, 0x24, 0, pOverlapped);
	if ( GetOverlappedResult(m_hHandle, pOverlapped, &NumberOfBytesTransferred, 1) )
	{
		pdwBuff[0] = OutBuffer[0];
		return 0;
	}
	result = GetLastError();
	
	if ( result == 0xE0000109 )
		return 1460;
	if ( !result )
	{

		pdwBuff[0] = OutBuffer[0];
		return 0;
	}
	return result;
}


DWORD CGpioDefaultProxy::sub_1000A610(BYTE InBuffer, DWORD *pdwArg2, DWORD *pdwArg3 )
{

	OVERLAPPED *pOverlapped; 
	
	DWORD result;
	DWORD NumberOfBytesTransferred; 
	int OutBuffer[2]; 

	
	NumberOfBytesTransferred = 0;
	
	pOverlapped = (OVERLAPPED *)sub_100065B0();
	
	if ( !pOverlapped )
		return 1450;
	DeviceIoControl(m_hHandle, 0xEA606134, &InBuffer, 4, OutBuffer, 8, 0, pOverlapped);
	if ( GetOverlappedResult(m_hHandle, pOverlapped, &NumberOfBytesTransferred, 1) )
	{
		if ( pdwArg2 )
			pdwArg2[0] = OutBuffer[0];
		if ( pdwArg3 )
			pdwArg3[0] = OutBuffer[1];
		return 0;
	}
	result = GetLastError();
	
	if ( result == 0xE0000109 )
		return 1460;
	if ( !result )
	{

		if ( pdwArg2 )
			pdwArg2[0] = OutBuffer[0];
		if ( pdwArg3 )
			pdwArg3[0] = OutBuffer[1];
		return 0;
	}
	return result;
}


DWORD CGpioDefaultProxy::sub_1000A3C0(PDWORD  lpOutBuffer)
{
	
	OVERLAPPED *pOverlapped; 
	DWORD result; 
	DWORD NumberOfBytesTransferred; 
	
	NumberOfBytesTransferred = 0;
	pOverlapped = (OVERLAPPED *)sub_100065B0();

	if ( !pOverlapped )
		return 1450;

	DeviceIoControl(m_hHandle, 0xEA606128, 0, 0, lpOutBuffer, 0x28, 0, pOverlapped);
	if ( GetOverlappedResult(m_hHandle, pOverlapped, &NumberOfBytesTransferred, 1) )
		return 0;

	result = GetLastError();
	if ( result == 0xE0000109 )
		return 1460;
	return result;
}


OVERLAPPED* CGpioDefaultProxy::sub_1000A6C0()
{
	OVERLAPPED *result; 
	DWORD NumberOfBytesTransferred; 
	NumberOfBytesTransferred = 0;
	result = (OVERLAPPED *)sub_100065B0();
	if ( result )
	{
		DeviceIoControl(m_hHandle, 0xEA606138, 0, 0, 0, 0, 0, result);
		result = (OVERLAPPED *)GetOverlappedResult(m_hHandle, result, &NumberOfBytesTransferred, 1);
		if ( !result )
			return (OVERLAPPED *)GetLastError();
	}
	return result;
}


DWORD CGpioDefaultProxy::sub_10007520(DWORD* pdwArg1)
{
	*pdwArg1 = (DWORD)this;
	//HeapFree(g_hHeap_1001FE9C, 0, pdwArg1);
	return (DWORD)pdwArg1;
}
