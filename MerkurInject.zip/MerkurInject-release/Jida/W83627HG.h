#pragma once
#include "W836x.h"

class CW83627HG : public CW836x
{
public:
	CW83627HG();
	virtual ~CW83627HG();

public:

	virtual void sub_1000CBD0();
//	virtual DWORD sub_1000A6B0();
	virtual DWORD sub_1000BEC0();
#if 0
	virtual DWORD sub_10006E70(DWORD dwFlag);
	virtual DWORD sub_10006EB0(DWORD dwArg1, DWORD dwArg2, PDWORD pdwArg3);
	virtual void sub_10006F00();
	virtual void sub_10006F60();
	virtual void sub_10006FB0();
	virtual void sub_10007000();
	virtual void sub_10007050();
	virtual BYTE sub_1000A490();
	virtual BYTE sub_1000A4B0();
	virtual BYTE sub_1000A4A0();
	virtual void sub_1000A730();
	virtual void sub_1000AB50();
	virtual void sub_1000A7E0();
	virtual void sub_1000A860();
	virtual void sub_1000ABC0();
	virtual void sub_1000A8A0();
	virtual void sub_1000A900();
	virtual void sub_1000AC20();
	virtual DWORD sub_10009DE0();
	virtual void sub_1000AC60();
	virtual void sub_1000A940();
	virtual void sub_1000A9A0();
	virtual void sub_1000ACE0();
	virtual void sub_1000AA00();
	virtual void sub_1000AD60();
	virtual void sub_1000AA90();
#endif
	virtual PDWORD sub_1000DB80(DWORD *pdwArg1, BYTE *pdwArg2);
	virtual PDWORD sub_1000DBA0(DWORD *pdwArg1, BYTE *pdwArg2);
	virtual PDWORD sub_1000DBC0(DWORD *pdwArg1, BYTE *pdwArg2);
	//virtual void sub_1000A4D0();
	virtual void sub_1000B4E0();
};

