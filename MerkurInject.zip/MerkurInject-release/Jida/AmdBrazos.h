#pragma once
#include "MultiSensor.h"

class CAmdBrazos : public CMultiSensor
{
public:
	CAmdBrazos();
	~CAmdBrazos();

public:

	virtual void sub_1000CBD0();
	virtual void sub_1000BEB0();
	virtual DWORD sub_1000B290();
	virtual DWORD sub_100081C0(DWORD i);
	virtual void sub_10008200();
	virtual void sub_10008250();
	virtual void sub_100082B0();
	virtual void sub_10008300();
	virtual void sub_10008350();
	virtual void sub_100083A0();
	virtual void sub_1000C590();
	virtual void sub_1000C5C0();
	virtual DWORD _JidaVgaSetContrastEnable();
	virtual void sub_1000C640();
	virtual void _JidaVoltageSetLimits();
	virtual void sub_1000C670();
	virtual void sub_1000C600();
	virtual void sub_1000C690();
	virtual DWORD sub_10009DF0();
};

