#include "stdafx.h"
#include "Smbus_Def.h"
#include "Jida_global.h"


CSmbus_Def::CSmbus_Def()
{
}


CSmbus_Def::~CSmbus_Def()
{
}

DWORD CSmbus_Def::sub_1000A780()
{
	SMBUSPARAM *pAlloc; 

	m_funcstr20 = (FUNCSTRUC14*)sub_100070F0(L"\\_SB_");

	if ( m_funcstr20 )
	{
		pAlloc = (SMBUSPARAM*)HeapAlloc(g_hHeap_1001FE9C, 8, 0x4E4);
		if ( pAlloc )
		{
			pAlloc->wHeaderlen_0 = 0xD0;			
			pAlloc->wBodyLen_2 = 0x414;
			pAlloc->pAddrBody_4 = ((DWORD)pAlloc + 0xD0);
			pAlloc->pAddHeaderInfo_8 = ((DWORD)pAlloc + 0x20);
			pAlloc->dwCode_10 = 0x43696541;
			pAlloc->dwUnk_18 = 0;
			pAlloc->dwUnk_1C = 0;
			*(DWORD*)(pAlloc+0xD0) = 0x426F6541;
		}
		m_lp24 = pAlloc;
		if ( pAlloc )
		{
			InitializeCriticalSection(&m_cs_04);
			m_dw1C = 1;
			return m_dw1C;
		}
		CloseHandle((HANDLE)m_funcstr20);
		m_funcstr20 = 0;
	}
	return m_dw1C;
}


void CSmbus_Def::sub_1000A820()
{
	if (!m_dw1C) return;
	if (m_funcstr20 && m_funcstr20->dwSelfAddr00 == (DWORD)m_funcstr20)
	{
		if (m_funcstr20->pFunc04)
		{
			LPFnV_P pFnProc1  = (LPFnV_P)m_funcstr20->pFunc04;
			if (m_funcstr20->dwFlag08)
			{				
				pFnProc1(&m_funcstr20->dwParam10);				
			}
			else
			{
				pFnProc1(0);	
			}
		}
		HeapFree(g_hHeap_1001FE9C, 0, m_funcstr20);
	}
	if ( m_lp24 )
		HeapFree(g_hHeap_1001FE9C, 0, m_lp24);
	DeleteCriticalSection(&m_cs_04);
	m_lp24 = 0;
	m_funcstr20 = 0;
	m_dw1C = 0;	
}
DWORD GetError_10008340(DWORD dwErr)
{
	DWORD dwRet; // eax

	dwRet = ERROR_INTERNAL_ERROR;//0x54F;
	switch ( dwErr )
	{
	case 0:
		dwRet = ERROR_SUCCESS;//0;
		break;
	case 0x10:
		dwRet = ERROR_INVALID_ADDRESS;//0x1E7;
		break;
	case 0x11:
		dwRet = ERROR_GEN_FAILURE;//0x1F;
		break;
	case 0x12:
		dwRet = ERROR_ACCESS_DENIED;//5;
		break;
	case 0x18:
		dwRet = ERROR_TIMEOUT;//0x5B4;
		break;
	case 0x1A:
		dwRet = ERROR_BUSY;//0xAA;
		break;
	case 0x1F:
		dwRet = ERROR_CRC;//0x17;
		break;
	default:
		return dwRet;
	}
	return dwRet;
}


DWORD CSmbus_Def::sub_1000A8A0(LPCRITICAL_SECTION lpCriticalSection,  BYTE byOpt1,	 BYTE byOpt2,  BYTE* pbybuf,  DWORD dwOut)
{
	
	DWORD dwTmp; // bl
	CRITICAL_SECTION* lpCriticalSectiona; 

	DWORD dwRet = 0x32;
	if (!m_dw1C) return 0x32;

	if ( (!pbybuf && lpCriticalSection != (LPCRITICAL_SECTION)2 && lpCriticalSection != (LPCRITICAL_SECTION)4) || ((BYTE)dwOut > 0x10)) return 0x57;
	dwTmp = dwOut;
	lpCriticalSectiona = &m_cs_04;
	EnterCriticalSection(&m_cs_04);
	
	if ( m_lp24 )
	{
		m_lp24->pAddHeaderInfo_8 = ((DWORD)m_lp24 + 0x20);		
		m_lp24->dwCode_10 = 0x43696541;
		m_lp24->dwUnk_18 = 0;
		m_lp24->dwUnk_1C = 0;
	}
	
	dwOut = (DWORD)lpCriticalSection;
	sub_100072A0(4, (BYTE *)&dwOut, m_lp24, 0);	
	dwOut = byOpt1;
	sub_100072A0(4, (BYTE *)&dwOut, m_lp24, 0);
	if ( lpCriticalSection == (LPCRITICAL_SECTION)4 )
		dwOut = *pbybuf;
	else
		dwOut = byOpt2;

	sub_100072A0(4, (BYTE*)&dwOut, m_lp24, 0);

	dwOut = dwTmp;
	sub_100072A0(4, (BYTE*)&dwOut, m_lp24, 0);

	if ( !dwTmp || pbybuf == 0 )
	{
		dwOut = 0;
		sub_100072A0(4, (BYTE*)&dwOut, m_lp24, 0);
	}
	if ( dwTmp >= 5 )
	{
		sub_100072A0((WORD)dwTmp, pbybuf, m_lp24, 2);
	}
	else
	{
		switch ( dwTmp )
		{
		case 1:
			dwOut = pbybuf[0];
			break;
		case 2:
			dwOut = pbybuf[0]  + (pbybuf[1] << 8);
			break;
		case 3:
			dwOut = pbybuf[0] + (pbybuf[1] << 8) + (pbybuf[2] << 16);
			break;
		case 4:
			dwOut = *(DWORD *)pbybuf;
			break;
		default:			
			break;
		}
		sub_100072A0(4, (BYTE*)&dwOut, m_lp24, 0);
	}
	dwRet = sub_10007460(m_lp24, (DWORD)m_funcstr20, 0x57424D53, 0);//90b0
	if ( !dwRet )
	{
		sub_100073E0(&dwOut, m_lp24);//9030
		dwRet = GetError_10008340(dwOut);
	}
	LeaveCriticalSection(lpCriticalSectiona);
	return dwRet;
}


DWORD CSmbus_Def::sub_1000AA90(DWORD dwFlag, BYTE byOpt1, BYTE byOpt2, BYTE *pDest, BYTE byLen)
{
	DWORD dwRet; 
	DWORD dwOut; 
	DWORD n = 0;
	LPCRITICAL_SECTION lpCriticalSection; 

	dwRet = 0x32;
	if ( !m_dw1C ) return dwRet;
	if ( (pDest || dwFlag == 3) && byLen <= 0x10 )
	{
		lpCriticalSection = &m_cs_04;
		EnterCriticalSection(&m_cs_04);
		if ( m_lp24 )
		{
			m_lp24->pAddHeaderInfo_8 = (DWORD)m_lp24 + 0x20;
			m_lp24->dwCode_10 = 0x43696541;
			m_lp24->dwUnk_18 = 0;
			m_lp24->dwUnk_1C = 0;
		}

		dwOut = 0;
		sub_100072A0(4, (BYTE*)&dwFlag, m_lp24, 0);
		dwFlag = byOpt1;
		sub_100072A0(4, (BYTE*)&dwFlag, m_lp24, 0);		
		dwFlag = byOpt2;
		sub_100072A0(4, (BYTE*)&dwFlag, m_lp24, 0);
		dwRet = sub_10007460(m_lp24, (DWORD)m_funcstr20, 0x52424D53, &dwOut);
		if ( !dwRet )
		{
			if ( dwOut >= 3 )
			{
				sub_100073E0(&dwFlag, m_lp24);
				dwRet = GetError_10008340(dwFlag);
				if ( !dwRet )
				{
					sub_100073E0(&dwFlag, m_lp24);
					if ( dwOut >= byLen )
						dwOut = byLen;
					for(n = 0; n < dwOut; n++)
					{
						sub_100073E0(&dwFlag, m_lp24);
						pDest[n] = (BYTE)dwFlag;
					}
				}
			}
		}
		LeaveCriticalSection(lpCriticalSection);
		return dwRet;
	}
	else
	{
		return 0x57;
	}
}

