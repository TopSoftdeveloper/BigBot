#pragma once
#include "MultiSensor.h"
#include "Smbus_Def.h"
class CNCT7802 : public CMultiSensor
{
public:
	CNCT7802();
	~CNCT7802();
public:
	CSmbus_Def* m_pSmbus_Def04;
	BYTE m_by08;
public:

	virtual void sub_1000CBD0();
	virtual DWORD sub_1000BEB0();
	virtual void sub_1000B190();
	virtual DWORD sub_100081C0(DWORD i);
	virtual void sub_10008200();
	virtual void sub_10008250();
	virtual void sub_100082B0();
	virtual void sub_10008300();
	virtual void sub_10008350();
	virtual void sub_100083A0();
	virtual void sub_1000BEC0();
	virtual void sub_1000B770();
	virtual void sub_1000BED0();
	virtual void sub_1000C150();
	virtual void sub_1000C3F0();
	virtual void sub_1000BFF0();
	virtual void sub_1000C1D0();
	virtual void sub_1000C470();
	virtual void sub_1000C040();
	virtual void sub_1000C210();
	virtual DWORD _JidaVgaSetContrastEnable();
	virtual void sub_1000C240();
	virtual void sub_1000BF50();
	virtual void sub_1000C4A0();
	virtual void sub_1000BFA0();
	virtual void sub_1000C2C0();
	virtual void sub_1000C070();
	virtual void sub_1000C340();
	virtual void sub_1000C500();
	virtual DWORD sub_10009DF0();
};

