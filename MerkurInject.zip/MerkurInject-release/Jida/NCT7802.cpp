#include "stdafx.h"
#include "NCT7802.h"


CNCT7802::CNCT7802()
{
}


CNCT7802::~CNCT7802()
{
}


void CNCT7802::sub_1000CBD0()
{
}


DWORD CNCT7802::sub_1000BEB0()
{
	return 1;
}


void CNCT7802::sub_1000B190()
{
}


DWORD CNCT7802::sub_100081C0(DWORD i)
{
	return 1;
}


void CNCT7802::sub_10008200()
{
}


void CNCT7802::sub_10008250()
{
}


void CNCT7802::sub_100082B0()
{
}


void CNCT7802::sub_10008300()
{
}


void CNCT7802::sub_10008350()
{
}


void CNCT7802::sub_100083A0()
{
}


void CNCT7802::sub_1000BEC0()
{
}


void CNCT7802::sub_1000B770()
{
}


void CNCT7802::sub_1000BED0()
{
}


void CNCT7802::sub_1000C150()
{
}


void CNCT7802::sub_1000C3F0()
{
}


void CNCT7802::sub_1000BFF0()
{
}


void CNCT7802::sub_1000C1D0()
{
}


void CNCT7802::sub_1000C470()
{
}


void CNCT7802::sub_1000C040()
{
}


void CNCT7802::sub_1000C210()
{
}


DWORD CNCT7802::_JidaVgaSetContrastEnable()
{
	return 1;
}


void CNCT7802::sub_1000C240()
{
}


void CNCT7802::sub_1000BF50()
{
}


void CNCT7802::sub_1000C4A0()
{
}


void CNCT7802::sub_1000BFA0()
{
}


void CNCT7802::sub_1000C2C0()
{
}


void CNCT7802::sub_1000C070()
{
}


void CNCT7802::sub_1000C340()
{
}


void CNCT7802::sub_1000C500()
{
}


DWORD CNCT7802::sub_10009DF0()
{
	return 1;
}
