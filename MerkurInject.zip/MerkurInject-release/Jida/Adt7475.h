#pragma once
#include "Adt74x.h"
#include "Smbus_Def.h"
class CAdt7475 : public CAdt74x
{
public:
	CAdt7475();
	virtual ~CAdt7475();//virtual DWORD sub_10009DF0();
public:
	BYTE m_by04;
	DWORD m_dw08;
	CSmbus_Def* m_pSmbus_Def0C;
	DWORD m_dw10;
	DWORD m_dw14;
	BYTE m_by18;
	DWORD m_dw1C;
public:
	DWORD sub_10008A60(DWORD dwArg1, DWORD dwArg2, BYTE* pDest);
public:

	virtual void sub_1000CBD0();
	virtual DWORD sub_1000B1E0();
	virtual DWORD sub_1000C590();
	virtual DWORD sub_100081C0(DWORD i);
	virtual DWORD sub_10008200(DWORD dwArg1, DWORD dwArg2, PDWORD pdwArg3);
	virtual DWORD sub_10008250(DWORD dwArg1, DWORD dwArg2, PDWORD pdwArg3, PDWORD pdwArg4);
	virtual DWORD sub_100082B0(DWORD dwFlag, DWORD dwArg1, PDWORD pdwArg2);
	virtual DWORD sub_10008300(DWORD dwFlag, DWORD dwArg1, PDWORD pdwArg2);
	virtual DWORD sub_10008350(DWORD dwFlag, DWORD dwArg1, PDWORD pdwArg2);
	virtual DWORD sub_100083A0(DWORD dwFlag, DWORD dwArg1, LPVOID pdwArg2);
	virtual DWORD sub_1000B770();
	virtual WORD sub_1000B1A0();
	virtual DWORD sub_10009DD0();
	virtual BOOL sub_1000B780(WORD wArg1, DWORD *pdwArg2);
	virtual BOOL sub_1000B410(DWORD dwArg, PDWORD pdwArg);
	virtual BOOL sub_1000B2A0(WORD wArg, DWORD *pdwVal);
	virtual BOOL sub_1000B840(WORD wArg, PDWORD pdwVal1, PDWORD pdwVal2);
	virtual BOOL sub_1000B4E0( DWORD dwArg, PDWORD pdwVal1, PDWORD pdwVal2);
	virtual BOOL sub_1000B360(WORD wArg, PDWORD pdwVal1, PDWORD pdwVal2);
	virtual BOOL sub_1000B890(WORD wArg, PDWORD pdwVal);
	virtual BOOL sub_1000B550(DWORD dwArg, DWORD* pdwVal);
	virtual DWORD _JidaVgaSetContrastEnable();
	virtual BOOL sub_1000B5B0(DWORD dwArg, DWORD* pdwVal);
	virtual BOOL sub_1000B8C0(WORD wArg, DWORD* pdwVal);
	virtual BOOL sub_1000B930(WORD wArg, DWORD *pdwVal);
	virtual BOOL sub_1000B650(DWORD dwArg, DWORD* pdwVal);
	virtual BOOL sub_1000B9A0(DWORD dwArg, WORD *pwVal);
	virtual BOOL sub_1000B6F0(WORD wArg, WORD* pwVal);
	virtual DWORD sub_1000B390(WORD wArg1, PBYTE pbyArg2);
	virtual DWORD sub_1000BB70(DWORD dwArg);
	virtual PDWORD sub_1000BB80(PDWORD pdwArg1, BYTE *pbyArg2);
	
};

