#pragma once
#include "SmbusInrerface.h"
#include "Jida_global.h"

class CSmbus_Def : public CSmbusInrerface
{
public:
	CSmbus_Def();
	virtual ~CSmbus_Def();
public:
	CRITICAL_SECTION m_cs_04;
	DWORD m_dw1C;
	FUNCSTRUC14* m_funcstr20;
	SMBUSPARAM* m_lp24;
public:

	virtual DWORD sub_1000A780();
	virtual void sub_1000A820();
	virtual DWORD sub_1000A8A0(LPCRITICAL_SECTION lpCriticalSection,  BYTE byOpt1,	 BYTE byOpt2,  BYTE* pbybuf,  DWORD dwOut);
	virtual DWORD sub_1000AA90(DWORD dwFlag, BYTE byOpt1, BYTE byOpt2, BYTE *pDest, BYTE byLen);
};

