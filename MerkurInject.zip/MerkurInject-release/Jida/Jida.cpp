// Jida.cpp : Defines the exported functions for the DLL application.
//

#include "stdafx.h"
#include "Jida_global.h"
#include "Jida.h"
#include "GpioDefaultProxy.h"
#include "Smbus_Def.h"
#include <malloc.h> 
#include <stdio.h> 


JIDA_API DWORD JidaVgaSetContrastEnable(DWORD dwArg1, DWORD dwArg2)
{
	return 1;
}
JIDA_API DWORD JidaVoltageSetLimits(DWORD dwArg1, DWORD dwArg2, DWORD dwArg3)
{
	return 0;
}
JIDA_API int JidaDllGetVersion()
{
	WORD OutBuffer[4]; // [esp+4h] [ebp-8h] BYREF

	if ( sub_100048E0((PBYTE)OutBuffer) )
		return 0;
	else
		return  OutBuffer[1] + (OutBuffer[0] << 16);
}

JIDA_API int JidaDllInitialize()
{
	int result; 
	int nCnt; 
	DWORD OutBuffer[2]; 
	result = g_dword_1001FE88;
	if ( !g_dword_1001FE88 )
	{
		if ( !sub_10004550() )
		{
			nCnt = 12;
			for (nCnt = 0; nCnt < 12; nCnt++)
			{
				if (!sub_10005430(g_dword_1001AF88[0], OutBuffer) && OutBuffer[0] || g_dword_1001AF88[nCnt*2] == 16 && g_pCSmbus_Def_1001FEA0 )
				{
					g_dword_1001FDB8[g_dword_1001FE84*2] = g_dword_1001AF88[nCnt*2];
					g_dword_1001FDB8[g_dword_1001FE84*2+1] = g_dword_1001AF88[nCnt*2+1];
					g_dword_1001FE84++;
				}
			}
			
			memset((LPVOID)g_dword_1001FE18, 0, sizeof(DWORD)*10);
			if ( g_pGpioDefaultProxy_1001FE40 )
			{
				if(((CGpioDefaultProxy*)g_pGpioDefaultProxy_1001FE40)->sub_1000A3C0(g_dword_1001FE18))	
				g_dword_1001FE80 = 1;
			}
			g_dword_1001FE88 = 1;
		}
		return 0;
	}
	return result;
}
JIDA_API int JidaDllUninitialize()
{
	g_dword_1001FE84 = 0;
	g_dword_1001FE80 = 0;
	g_dword_1001FE88 = 0;
	memset(g_dword_1001FE18, 0, sizeof(DWORD)*10);
	
	return sub_10004680();
}
JIDA_API BOOL JidaDllIsAvailable()
{
	return g_dword_1001FE8C != 0;
}
JIDA_API int JidaBoardClose(PFUNCSTRUC14 pdwArg1)
{
	DWORD result; // eax
	DWORD *pdwTmp1; // ecx
	
	result = 0;
	if ( (DWORD)pdwArg1 < 0x7FFFFFFF )
	{
		pdwTmp1 = NULL;
		if ( pdwArg1 && pdwArg1->dwSelfAddr00 == (DWORD)pdwArg1 )
		{			
			LPFnV_P pFnFunc = (LPFnV_P)pdwArg1->pFunc04;
			if ( pFnFunc )
			{
				if(pdwArg1->dwFlag08)
					pdwTmp1 = &pdwArg1->dwParam10;
				pFnFunc(pdwTmp1);
			}
			HeapFree(g_hHeap_1001FE9C, 0, pdwArg1);
		}
		return 1;
	}
	return result;
}

JIDA_API int JidaBoardGetBootCounter(PFUNCSTRUC14 pFuncInfo, PDWORD pdwArg2)
{
	
	if ( !pFuncInfo )
		return 0;
	if ( pFuncInfo->dwSelfAddr00 != (DWORD)pFuncInfo )
		return 0;
	if ( strcmp(pFuncInfo->szStr0C, "JHANDLE") )
		return 0;
	if ( !pdwArg2 )
		return 0;
	if ( !(sub_10004960(pdwArg2) == 0) )
		return 0;
	return 1;
}

JIDA_API int JidaBoardGetRunningTimeMeter(PFUNCSTRUC14 pFuncInfo, PDWORD pdwArg2)
{
	
	if ( !pFuncInfo )
		return 0;
	if ( pFuncInfo->dwSelfAddr00 != (DWORD)pFuncInfo )
		return 0;
	if ( strcmp(pFuncInfo->szStr0C, "JHANDLE") )
		return 0;
	if ( !pdwArg2 )
		return 0;
	
	if ( sub_100049C0(pdwArg2) == 0 )
		return 1;
	return 0;
}
JIDA_API int JidaBoardGetOption(int a1, int a2, int a3)
{
	return 0;
}
JIDA_API int JidaBoardGetBootErrorLog(int a1, int a2, int a3, int a4, int a5)
{
	return 0;
}
JIDA_API int JidaStorageAreaEraseStatus(int a1, int a2, int a3, int a4, int a5)
{
	return 0;
}
JIDA_API int JidaIOGetNameW(int a1, int a2, int a3)
{
	return 0;
}
JIDA_API int JidaIOGetNameA(int a1, int a2, int a3)
{
	return 0;
}
JIDA_API int JidaBoardSetOption(int a1, int a2, int a3)
{
	return 0;
}
JIDA_API int JidaWDogSetTriggerCount(int a1, int a2, int a3)
{
	return 0;
}
JIDA_API int JidaPerformanceGetCurrent(int a1, int a2, int a3)
{
	return 0;
}
JIDA_API int JidaPerformanceSetCurrent(int a1, int a2, int a3)
{
	return 0;
}
JIDA_API int JidaPerformanceGetPolicyCaps(int a1, int a2, int a3)
{
	return 0;
}

JIDA_API int JidaPerformanceGetPolicy(int a1, int a2, int a3)
{
	return 0;
}
JIDA_API int JidaPerformanceSetPolicy(int a1, int a2, int a3)
{
	return 0;
}
JIDA_API int JidaTemperatureSetLimits(int a1, int a2, int a3)
{
	return 0;
}
JIDA_API int JidaFanSetLimits(int a1, int a2, int a3)
{
	return 0;
}

//////////////////////////////////////////////////////////////////////////
JIDA_API int JidaVgaGetContrast(int a1, int a2)
{
	return 0;
}
JIDA_API int JidaVgaSetContrast(int a1, int a2)
{
	return 0;
}
JIDA_API int JidaWDogGetTriggerCount(int a1, int a2)
{
	return 0;
}
JIDA_API int JidaVgaGetContrastEnable(int a1, int a2)
{
	return 0;
}
JIDA_API int JidaVgaGetBacklight(PFUNCSTRUC14 pFuncInfo, PDWORD pdwArg2)
{
	if ( !pFuncInfo )
		return 0;
	if ( pFuncInfo->dwSelfAddr00 != (DWORD)pFuncInfo )
		return 0;
	if ( strcmp(pFuncInfo->szStr0C, "JHANDLE") )
		return 0;
	if ( !pdwArg2 )
		return 0;
	*(PBYTE)&pFuncInfo->dwSelfAddr00 = 0;
	if ( sub_10005FB0(pFuncInfo) )
		return 0;
	*pdwArg2 = (BYTE)pFuncInfo->dwSelfAddr00;
	return 1;
}

JIDA_API BOOL JidaVgaSetBacklight(PFUNCSTRUC14 pFuncInfo, unsigned int dwArg2)
{
	BOOL result;

	result = 0;
	if ( pFuncInfo && pFuncInfo->dwSelfAddr00 == (DWORD)pFuncInfo && !strcmp(pFuncInfo->szStr0C, "JHANDLE")  && dwArg2 <= 0xFF )
		return sub_10005F20((BYTE)dwArg2) == 0;
	return result;
}
JIDA_API int JidaVgaEndDarkBoot(DWORD dwArg1)
{
	return 0;
}
JIDA_API  int JidaStorageAreaCount(PFUNCSTRUC14 pFuncInfo, int dwArg2)
{
	DWORD dwFlag; 
	DWORD result; 
	DWORD i; 
	DWORD dwTmp1; 

	dwFlag = 0;
	if ( pFuncInfo && pFuncInfo->dwSelfAddr00 == (DWORD)pFuncInfo && !strcmp(pFuncInfo->szStr0C, "JHANDLE") )
		dwFlag = (DWORD)&pFuncInfo->dwParam10;
	result = 0;
	if ( dwFlag )
	{
		if ( dwArg2 )
		{
			dwTmp1 = sub_10004110(dwArg2, pFuncInfo);
			i = (WORD)g_dword_1001FED4;
			result = 0;
			if ( LOWORD(g_dword_1001FED4) )
			{
				PControlDevice30 pCtrlDev = (PControlDevice30)g_lpMem_1001FED8;
				do 
				{
					if(pCtrlDev->dwOutBuffer[1]==dwTmp1 && pCtrlDev->dwOutBuffer[2])
						++result;
					pCtrlDev++;
					--i;
				} while (i);
			}

		}
		else
		{
			result = 0;
			if ( LOWORD(g_dword_1001FED4) >0 )
			{
				PControlDevice30 pCtrlDev = (PControlDevice30)g_lpMem_1001FED8;
				i = LOWORD(g_dword_1001FED4);
				do 
				{
					if(pCtrlDev->dwOutBuffer[1]==0xFFFFFFFF && pCtrlDev->dwOutBuffer[2])
						++result;
					pCtrlDev++;
					--i;
				} while (i);


			}
			
			if ( LOWORD(g_dword_1001FED4) >0)
			{
				PControlDevice30 pCtrlDev = (PControlDevice30)g_lpMem_1001FED8;
				i = LOWORD(g_dword_1001FED4);
				do 
				{
					if(pCtrlDev->dwOutBuffer[1]==0 && pCtrlDev->dwOutBuffer[2])
						++result;
					pCtrlDev++;
					--i;
				} while (i);

			}
			
			if ( LOWORD(g_dword_1001FED4) >0)
			{
				PControlDevice30 pCtrlDev = (PControlDevice30)g_lpMem_1001FED8;
				i = LOWORD(g_dword_1001FED4);
				do 
				{
					if(pCtrlDev->dwOutBuffer[1]==0xFFFFFFFF && pCtrlDev->dwOutBuffer[2])
						++result;
					pCtrlDev++;
					--i;
				} while (i);
			}
		
			if ( LOWORD(g_dword_1001FED4) >0)
			{
				PControlDevice30 pCtrlDev = (PControlDevice30)g_lpMem_1001FED8;
				i = LOWORD(g_dword_1001FED4);
				do 
				{
					if(pCtrlDev->dwOutBuffer[1]==0xFFFFFFFF && pCtrlDev->dwOutBuffer[2])
						++result;
					pCtrlDev++;
					--i;
				} while (i);


			}
			
			if ( LOWORD(g_dword_1001FED4) >0)
			{
				PControlDevice30 pCtrlDev = (PControlDevice30)g_lpMem_1001FED8;
				i = LOWORD(g_dword_1001FED4);
				do 
				{
					if(pCtrlDev->dwOutBuffer[1]==0xFFFFFFFF && pCtrlDev->dwOutBuffer[2])
						++result;
					pCtrlDev++;
					--i;
				} while (i);


			}
			return result;
		}
	}
	return result;
}

JIDA_API DWORD JidaStorageAreaType(PFUNCSTRUC14 pFuncInfo, int dwArg2)
{
	PDWORD pdwTmp; 
	DWORD result;
	pdwTmp = 0;
	if ( pFuncInfo && pFuncInfo->dwSelfAddr00 == (DWORD)pFuncInfo && !strcmp(pFuncInfo->szStr0C, "JHANDLE") )
		pdwTmp = &pFuncInfo->dwParam10;
	result = 0;
	if ( pdwTmp )
	{
		if ( !dwArg2 )
			return 0x10000;
	}
	return result;
}

JIDA_API DWORD JidaStorageAreaSize(PFUNCSTRUC14 pFuncInfo, DWORD dwArg2)
{
	PDWORD pdwTmp; 
	PControlDevice30 pRet; 

	pdwTmp = 0;
	if ( pFuncInfo && pFuncInfo->dwSelfAddr00 == (DWORD)pFuncInfo && !strcmp(pFuncInfo->szStr0C, "JHANDLE") )
		pdwTmp = &pFuncInfo->dwParam10;
	if ( pdwTmp && !(WORD)dwArg2)
	{
		sub_10004110(dwArg2, pFuncInfo);
		if((pRet = sub_10007840((WORD)g_dword_1001FED4, (PDWORD)pFuncInfo)) != 0 )
			return pRet->dwOutBuffer[4];
		else return 0;
	}
	else
		return 0;
}
JIDA_API DWORD JidaStorageAreaBlockSize(PFUNCSTRUC14 pFuncInfo, WORD wArg2)
{
	PDWORD pdwTmp; // edi
	PControlDevice30 pRet = NULL;
	pdwTmp = 0;
	if ( pFuncInfo && pFuncInfo->dwSelfAddr00 == (DWORD)pFuncInfo && !strcmp(pFuncInfo->szStr0C, "JHANDLE") )
		pdwTmp =&pFuncInfo->dwParam10;
	if ( pdwTmp && !wArg2)
	{
		sub_10004110(wArg2, pFuncInfo);
		if((pRet = sub_10007840((WORD)g_dword_1001FED4, (PDWORD)pFuncInfo))!=0) 
			return sub_10001000(pRet);
	}
	
	return 0;
}
JIDA_API int JidaStorageAreaRead(PFUNCSTRUC14 pFuncInfo, int dwArg2, int dwArg3, int dwArg4, int dwArg5)
{
	PDWORD pdwTmp; // edi
	PControlDevice30 pRet = NULL;
	pdwTmp = 0;
	if ( pFuncInfo && pFuncInfo->dwSelfAddr00 == (DWORD)pFuncInfo && !strcmp(pFuncInfo->szStr0C, "JHANDLE") )
		pdwTmp = &pFuncInfo->dwParam10;
	if ( pdwTmp && !(WORD)dwArg2)
	{
		sub_10004110(dwArg2, pFuncInfo);
		if((pRet  = sub_10007840((WORD)g_dword_1001FED4, (PDWORD)pFuncInfo)) != 0 )
		{
			return sub_10007440(pRet, (LPVOID)dwArg4, dwArg5, dwArg3);
		}
	}

		return 0;
}

JIDA_API int  JidaStorageAreaWrite(PFUNCSTRUC14 pFuncInfo, int dwArg2, int dwArg3, PBYTE pbyArg4, int dwArg5)
{
	PDWORD pdwRet;
	PControlDevice30 pRet = NULL;
	pdwRet = 0;
	if ( pFuncInfo && pFuncInfo->dwSelfAddr00 == (DWORD)pFuncInfo && !strcmp(pFuncInfo->szStr0C, "JHANDLE") )
		pdwRet = &pFuncInfo->dwParam10;
	if ( pdwRet && !(WORD)dwArg2)
	{
		sub_10004110(dwArg2, pFuncInfo);
		if( (pRet = sub_10007840((WORD)g_dword_1001FED4, (PDWORD)pFuncInfo)) != 0)
		return sub_10007120(pRet, dwArg5, dwArg3, pbyArg4);
	}
	
		return 0;
}
JIDA_API DWORD  JidaStorageAreaErase(PFUNCSTRUC14 pFuncInfo, int dwArg1, int dwArg2, int dwArg3)
{
	int v4; // edi
	PDWORD pdwRet;
	PControlDevice30 pRet = NULL;
	pdwRet = 0;
	v4 = 0;
	if ( pFuncInfo && pFuncInfo->dwSelfAddr00 == (DWORD)pFuncInfo && !strcmp(pFuncInfo->szStr0C, "JHANDLE") )
		pdwRet = &pFuncInfo->dwParam10;
	if ( pdwRet && !(WORD)dwArg1 )
	{
		sub_10004110(dwArg1, pFuncInfo);
		if((pRet = sub_10007840((WORD)g_dword_1001FED4, (PDWORD)pFuncInfo)) != 0)
		return sub_10007290(pRet, dwArg3, dwArg2);
	}
	return 0;
}
//////////////////////////////////////////////////////////////////////////
JIDA_API int  JidaI2CCount(PFUNCSTRUC14 pFuncInfo)
{
	PDWORD pdwTmp;

	pdwTmp = 0;
	if ( pFuncInfo && pFuncInfo->dwSelfAddr00 == (DWORD)pFuncInfo && !strcmp(pFuncInfo->szStr0C, "JHANDLE") )
		pdwTmp = &pFuncInfo->dwParam10;
	return pdwTmp != 0 ? g_dword_1001FE84 : 0;
}
JIDA_API  BOOL JidaI2CIsAvailable(PFUNCSTRUC14 pFuncInfo, unsigned int dwArg2)
{
	if( pFuncInfo && pFuncInfo->dwSelfAddr00 == (DWORD)pFuncInfo)
	{
		
		if(!strcmp(*(const char **)(pFuncInfo + 12), "JHANDLE") && (&pFuncInfo->dwParam10) != 0 && dwArg2 < g_dword_1001FE84)
		{
			return 1;
		}
		
	}
	return 0;
}

JIDA_API  BOOL JidaI2CRead(PFUNCSTRUC14 pFuncInfo, DWORD dwArg2, BYTE byArg3, PDWORD pdwArg4, DWORD dwArg5)
{
	PDWORD pdwTmp; 
	BOOL result; 

	pdwTmp = 0;
	if ( pFuncInfo && pFuncInfo->dwSelfAddr00 == (DWORD)pFuncInfo && !strcmp(pFuncInfo->szStr0C, "JHANDLE") )
		pdwTmp = &pFuncInfo->dwParam10;
	pFuncInfo = 0;
	result = 0;
	if ( pdwTmp )
	{
		if ( dwArg2 < g_dword_1001FE84 )
		{
			
			if ( !sub_10004D40(dwArg5, g_dword_1001FDB8[2 * dwArg2], byArg3, pdwArg4, (PDWORD)&pFuncInfo) && (DWORD)pFuncInfo == (DWORD)dwArg5 )
				return 1;
		}
	}
	return result;
}

JIDA_API BOOL JidaI2CWrite(PFUNCSTRUC14 pFuncInfo, DWORD dwArg2, BYTE byArg3, void *lpSrc, DWORD dwArg5)
{
	PDWORD pdwTmp;
	BOOL result; 

	pdwTmp = 0;
	if ( pFuncInfo && pFuncInfo->dwSelfAddr00 == (DWORD)pFuncInfo && !strcmp(pFuncInfo->szStr0C, "JHANDLE") )
		pdwTmp = &pFuncInfo->dwParam10;
	pFuncInfo = 0;
	result = 0;
	if ( pdwTmp )
	{
		if ( dwArg2 < g_dword_1001FE84 )
		{
			if ( !sub_10004E80(g_dword_1001FDB8[2 * dwArg2], byArg3, lpSrc, dwArg5, (PDWORD)&pFuncInfo, 1) && (DWORD)pFuncInfo == (DWORD)dwArg5 )
				return 1;
		}
	}
	return result;
}

JIDA_API  BOOL JidaI2CReadRegister(PFUNCSTRUC14 pFuncInfo, unsigned int dwArg2, DWORD dwArg3, DWORD dwArg4, LPVOID lpArg5)
{
	PDWORD pdwTmp; 
	int dwRet; 
	
	pdwTmp = 0;
	if ( pFuncInfo && pFuncInfo->dwSelfAddr00 == (DWORD)pFuncInfo && !strcmp(pFuncInfo->szStr0C, "JHANDLE") )
		pdwTmp = &pFuncInfo->dwParam10;
	dwRet = 87;
	if ( !pdwTmp || dwArg2 >= g_dword_1001FE84 )
		return dwRet == 0;
	
	if ( g_dword_1001FDB8[2 * dwArg2] != 16 )
	{
		dwRet = sub_100052C0(1, g_dword_1001FDB8[2 * dwArg2], (BYTE)dwArg3, (WORD)dwArg4, 0, lpArg5);
		return dwRet == 0;
	}
	
	if(g_pCSmbus_Def_1001FEA0)
	{
		if( ((CSmbus_Def*)g_pCSmbus_Def_1001FEA0)->sub_1000AA90(7,	(BYTE)dwArg3,	(BYTE)dwArg4,	(PBYTE)lpArg5,	1) == 0)
			return 1;
		
	}
	return 0;
		
}

JIDA_API BOOL JidaI2CWriteRegister(PFUNCSTRUC14 pFuncInfo, unsigned int dwArg2, int dwArg3, int dwArg4, BYTE byArg5)
{
	PDWORD pdwTmp; // edi
	int dwRet; // eax
	
	pdwTmp = 0;
	if ( pFuncInfo && pFuncInfo->dwSelfAddr00 == (DWORD)pFuncInfo && !strcmp(pFuncInfo->szStr0C, "JHANDLE") )
		pdwTmp = &pFuncInfo->dwParam10;

	dwRet = 87;
	if ( !pdwTmp || dwArg2 >= g_dword_1001FE84 )
		return dwRet == 0;

	if ( g_dword_1001FDB8[2 * dwArg2] != 16 )
	{
		dwRet = sub_10005160(1, 0, g_dword_1001FDB8[2 * dwArg2], (BYTE)dwArg3, dwArg4, &byArg5);
		return dwRet == 0;
	}
	if ( !g_pCSmbus_Def_1001FEA0 )
		return 0;
	
	*(BYTE*)&pFuncInfo = (BYTE)byArg5;
	return ((CSmbus_Def*)g_pCSmbus_Def_1001FEA0)->sub_1000A8A0((LPCRITICAL_SECTION)6, dwArg3, dwArg4, (PBYTE)&pFuncInfo, 1) == 0;//c
}

JIDA_API  DWORD  JidaIOCount(PFUNCSTRUC14 pFuncInfo)
{
	PDWORD pdwTmp;
	pdwTmp = 0;
	if ( pFuncInfo && pFuncInfo->dwSelfAddr00 == (DWORD)pFuncInfo && !strcmp(pFuncInfo->szStr0C, "JHANDLE") )
		pdwTmp = &pFuncInfo->dwParam10;
	if ( pdwTmp )
		return g_dword_1001FE80;
	return 0;
}
JIDA_API BOOL  JidaIOIsAvailable(FUNCSTRUC14* pfun, DWORD dwArg)
{
	DWORD dwval; 
	DWORD dwcom; 

	dwval = 0;
	if ( pfun && pfun->dwSelfAddr00 == (DWORD)pfun && !strcmp(pfun->szStr0C, "JHANDLE") )
		dwval = (DWORD)pfun + 16;
	dwcom = 0;
	if ( dwval )
		dwcom = g_dword_1001FE80;
	return dwArg < dwcom;
}
JIDA_API  BOOL  JidaIORead(PFUNCSTRUC14 pFuncInfo, unsigned int dwArg2, int dwArg3)
{
	int dwRet;

	if ( !JidaIOIsAvailable(pFuncInfo, dwArg2) )
		return 0;
	if ( !dwArg3 )
		return 0;
	dwRet = 1168;
	if ( g_pGpioDefaultProxy_1001FE40 )

		dwRet = ((CGpioDefaultProxy*)g_pGpioDefaultProxy_1001FE40)->sub_1000A160(g_dword_1001FE18[0]|g_dword_1001FE18[1], (PDWORD)dwArg3);//24
				
	return dwRet == 0;
}

JIDA_API BOOL JidaIOWrite(PFUNCSTRUC14 pFuncInfo, DWORD dwArg2, DWORD dwArg3)
{
	int dwRet; 
	if ( !JidaIOIsAvailable(pFuncInfo, dwArg2) )
		return 0;
	dwRet = 1168;
	if ( g_pGpioDefaultProxy_1001FE40 )
		dwRet = ((CGpioDefaultProxy*)g_pGpioDefaultProxy_1001FE40)->sub_1000A2A0(g_dword_1001FE18[1], dwArg3);//20
	return dwRet == 0;
}

JIDA_API int JidaIOXorAndXor(PFUNCSTRUC14 pFuncInfo, DWORD dwArg2, DWORD dwArg3, DWORD dwArg4, DWORD dwArg5)
{
	if ( !JidaIOIsAvailable(pFuncInfo, dwArg2) )
		return 0;
	DWORD dwRet = 0;
	dwArg2 = 0;
	if ( g_pGpioDefaultProxy_1001FE40 )
	{

		((CGpioDefaultProxy*)g_pGpioDefaultProxy_1001FE40)->sub_1000A160(g_dword_1001FE18[0]|g_dword_1001FE18[1], (PDWORD)dwArg2);//24
		((CGpioDefaultProxy*)g_pGpioDefaultProxy_1001FE40)->sub_1000A2A0(g_dword_1001FE18[1], ((dwArg5 ^ dwArg4) & (dwArg3 ^ dwArg2)));//20
	}
	return 1;
}
JIDA_API BOOL  JidaDllInstall(DWORD dwArg1)
{
	DWORD dwRet; 
	DWORD result; 

	result = 0;
	dwRet = sub_10009720(dwArg1, &result);
	if ( !dwRet && result == 1 )
		MessageBoxW(0, L"Need Reboot!", L"Kontron BSP", 0x30);
	return dwRet == 0;
}
//////////////////////////////////////////////////////////////////////////
DWORD sub_10005E20(DWORD InBuffer)
{	
	OVERLAPPED *pOverlap; 	
	DWORD result; 
	DWORD NumberOfBytesTransferred; 

	NumberOfBytesTransferred = 0;
	pOverlap = sub_100065B0();

	if ( !pOverlap )
		return ERROR_NO_SYSTEM_RESOURCES;
	DeviceIoControl(g_hFile, 0xEA60E1C0, &InBuffer, 4, 0, 0, 0, pOverlap);
	if ( GetOverlappedResult(g_hFile, pOverlap, &NumberOfBytesTransferred, 1) )
		return 0;
	result = GetLastError();
	if ( result == 0xE0000109 )
		return ERROR_TIMEOUT;
	return result;
}
DWORD sub_10005E90(DWORD *pdwRes)
{
	OVERLAPPED *pOverlap;	
	DWORD result; 
	DWORD NumberOfBytesTransferred; 
	DWORD OutBuffer[5]; 

	NumberOfBytesTransferred = 0;
	result = 0;
	pOverlap = sub_100065B0();	
	if ( !pOverlap )
		return ERROR_NO_SYSTEM_RESOURCES;
	DeviceIoControl(g_hFile, 0xEA6061C4, 0, 0, OutBuffer, 0x14, 0, pOverlap);
	if ( !GetOverlappedResult(g_hFile, pOverlap, &NumberOfBytesTransferred, 1) )
	{		
		result = GetLastError();
		if ( result == 0xE0000109 )
			return ERROR_TIMEOUT;
	}
	if ( !result )
	{
		*pdwRes = OutBuffer[0];
	}
	return result;
}
int sub_10004A20(char InBuffer, DWORD* lpOutBuffer, DWORD DestinationSize, PDWORD pdwRet)
{
	PDWORD pdwTemp1; 
	PDWORD p_Source; 
	OVERLAPPED *pOverLapped1; 
	OVERLAPPED *pOverLapped2; 
	DWORD LastError; 
	int nRetCode; 
	DWORD dwTempVal; 
	DWORD Source; 
	DWORD NumberOfBytesTransferred; 
	DWORD nOutBufferSize; 
	DWORD dwTempVal2; 

	pdwTemp1 = (PDWORD )lpOutBuffer;
	NumberOfBytesTransferred = 0;
	Source = 0;
	dwTempVal2 = 0;
	if ( lpOutBuffer && DestinationSize >= 4 )
	{
		nOutBufferSize = DestinationSize;
		p_Source = (PDWORD )lpOutBuffer;
		dwTempVal2 = *(PDWORD )lpOutBuffer;
	}
	else
	{
		p_Source = &Source;
		nOutBufferSize = 4;
	}

	lpOutBuffer = 0;
	pOverLapped1 = sub_100065B0();
	pOverLapped2 = pOverLapped1;
	if ( pOverLapped1 )
	{
		DeviceIoControl(g_hFile, 0xEA606008, &InBuffer, 4, p_Source, nOutBufferSize, 0, pOverLapped1);
		if ( !GetOverlappedResult(g_hFile, pOverLapped2, &NumberOfBytesTransferred, 1) )
		{
			LastError = GetLastError();
			if ( LastError != 0xE0000109 )
			{	
				*lpOutBuffer = ERROR_TIMEOUT;
			}
		}
	}
	else
	{
		*lpOutBuffer = ERROR_NO_SYSTEM_RESOURCES;
	}
	LastError = *lpOutBuffer;

	nRetCode = LastError;
	if ( LastError )
	{
		if ( LastError == ERROR_MORE_DATA )
		{
			dwTempVal = *p_Source;
			nRetCode = ERROR_INSUFFICIENT_BUFFER;
			if ( p_Source == pdwTemp1 )
				*pdwTemp1 = dwTempVal2;
		}
		else
		{
			dwTempVal = Source;
		}
	}
	else
	{
		dwTempVal = NumberOfBytesTransferred;
		if ( DestinationSize >= NumberOfBytesTransferred && pdwTemp1 )
		{
			if ( p_Source == &Source )
			{
				memcpy_s(pdwTemp1, DestinationSize, &Source, NumberOfBytesTransferred);
				dwTempVal = NumberOfBytesTransferred;
			}
		}
		else
		{
			nRetCode = ERROR_INSUFFICIENT_BUFFER;
		}
	}
	if ( pdwRet )
		*pdwRet = dwTempVal;
	return nRetCode;
}
FUNCSTRUC14* sub_10006D60(char* szStr)
{
	FUNCSTRUC14* result; 

	result = (FUNCSTRUC14*)HeapAlloc(g_hHeap_1001FE9C, 8, 0x14);
	if ( result )
	{
		result->dwSelfAddr00 = (DWORD)result;
		result->pFunc04 = 0;
		result->dwFlag08 = 4;
		result->szStr0C = szStr;
	}
	return result;
}
char* sub_100067B0(int cbMultiByte, WCHAR *wszStr, char* szStr)
{
	if ( !szStr )
		return 0;
	if ( !wszStr )
		return 0;
	*szStr = 0;
	if( WideCharToMultiByte(0, 0, wszStr, -1, szStr, cbMultiByte, 0, 0) == 0)
		return 0;	
	return szStr;
}
int sub_10004180(WCHAR* wszStr, DWORD *pdwRet)
{
	int result;
	int dwAllocsize; 
	char *szNewStr;
	char *szRet; 
	char* szStr; 
	char* szString; 

	result = 87;
	if ( wszStr && pdwRet )
	{
		dwAllocsize = 2 * wcslen(wszStr) + 2;
		szStr = (char*)_alloca(dwAllocsize);
		szString = 0;
		if ( szStr )
		{
			szStr[0] = 0;
			if ( WideCharToMultiByte(0, 0, wszStr, -1, szStr, dwAllocsize, 0, 0) )
				szString = szStr;
		}
		result = _stricmp(szString, "CPU");
		if (! result )
		{
			*pdwRet = 1;
		}
		else
		{			
			szNewStr = (char*)_alloca(dwAllocsize);
			szRet = (char *)sub_100067B0(dwAllocsize, wszStr,szNewStr);
			result = _stricmp(szRet, "VGA");
			if ( result )
			{				
				if ( !_stricmp(szRet, "IO") )
				{
					*pdwRet = 4;
					return 0;
				}
				else
				{
					return ERROR_NOT_FOUND;
				}
			}
			else
			{
				*pdwRet = 2;
			}
		}

	}
	return result;
}
DWORD sub_10004B40(LPVOID lpOutBuffer, ...)
{
	OVERLAPPED *pOverlap; 
	DWORD result; 
	DWORD NumberOfBytesTransferred; 
	va_list va;
	va_start(va, lpOutBuffer);
	NumberOfBytesTransferred = 0;
	pOverlap = sub_100065B0();
	if ( !pOverlap )
		return ERROR_NO_SYSTEM_RESOURCES;
	DeviceIoControl(g_hFile, 0xEA606004, va, 4, lpOutBuffer, 4, 0, pOverlap);
	if ( GetOverlappedResult(g_hFile, pOverlap, &NumberOfBytesTransferred, 1) )
		return 0;
	result = GetLastError();
	if ( result == 0xE0000109 )
		return ERROR_TIMEOUT;
	return result;
}
int sub_100042F0(WCHAR* wszStr, char InBuffer)
{
	int result; 
	int OutBuffer; 
	DWORD dwRet;

	if ( sub_10004180(wszStr, &dwRet) )
		return 0;
	if ( sub_10004B40(&OutBuffer, InBuffer) )
		return 0;
	result = 1;
	if ( (OutBuffer & dwRet) == 0 )
		return 0;
	return result;
}
BOOL sub_100066C0(const char *szStr, WORD *pwbuf)
{
	int dwVal; 
	int result; 

	if ( !szStr )
		return 0;

	if ( sscanf_s(szStr, "%hd/%hd/%hd", pwbuf + 1, pwbuf + 2, pwbuf) != 3  )
		return 0;
	dwVal = g_dword_1001AF48[pwbuf[1]] + pwbuf[2];
	if ( (pwbuf[0] & 3) == 0 && pwbuf[1] > 2 )
		++dwVal;
	result = 1;
	pwbuf[3] = (((pwbuf[0] - 1970) >> 2) + dwVal + 365 * (pwbuf[0] - 1970) + 4) % 7;
	return result;
}
DWORD sub_10005C80()
{

	OVERLAPPED *pOverlapped;

	DWORD result; 
	DWORD NumberOfBytesTransferred; 


	NumberOfBytesTransferred = 0;
	pOverlapped = sub_100065B0();

	if ( !pOverlapped )
		return ERROR_NO_SYSTEM_RESOURCES;

	DeviceIoControl(g_hFile, 0xEA60A294, 0, 0, 0, 0, 0, pOverlapped);
	if ( GetOverlappedResult(g_hFile, pOverlapped, &NumberOfBytesTransferred, 1) )
		return 0;

	result = GetLastError();

	if ( result == 0xE0000109 )
		return ERROR_TIMEOUT;

	return result;
}
DWORD  sub_10005AA0(PDWORD  pdwBuff)
{

	OVERLAPPED *pOverlapped; 
	DWORD result; 
	DWORD NumberOfBytesTransferred; 


	NumberOfBytesTransferred = 0;

	pOverlapped = sub_100065B0();

	if ( !pOverlapped )
		return ERROR_NO_SYSTEM_RESOURCES;

	DeviceIoControl(g_hFile, 0xEA60A29C, pdwBuff, 0x1C, 0, 0, 0, pOverlapped);

	if ( GetOverlappedResult(g_hFile, pOverlapped, &NumberOfBytesTransferred, 1) )
		return 0;

	result = GetLastError();

	if ( result == 0xE0000109 )
		return ERROR_TIMEOUT;

	return result;
}
DWORD sub_10005C10()
{

	OVERLAPPED *pOverlapped;

	DWORD result; 
	DWORD NumberOfBytesTransferred; 


	NumberOfBytesTransferred = 0;
	pOverlapped = (OVERLAPPED *)sub_100065B0();

	if ( !pOverlapped )
		return ERROR_NO_SYSTEM_RESOURCES;

	DeviceIoControl(g_hFile, 0xEA60A290, 0, 0, 0, 0, 0, pOverlapped);
	if ( GetOverlappedResult(g_hFile, pOverlapped, &NumberOfBytesTransferred, 1) )
		return 0;

	result = GetLastError();

	if ( result == 0xE0000109 )
		return ERROR_TIMEOUT;

	return result;
}
DWORD sub_10005B10(PDWORD pdwbuf)
{
	DWORD dwret;
	OVERLAPPED *poverlap; 
	DWORD result;
	DWORD NumberOfBytesTransferred; 
	char OutBuffer[32]; 


	NumberOfBytesTransferred = 0;
	dwret = 0;
	poverlap = sub_100065B0();

	if ( !poverlap )
		return ERROR_NO_SYSTEM_RESOURCES;
	DeviceIoControl(g_hFile, 0xEA606284, 0, 0, OutBuffer, 0x20, 0, poverlap);
	if ( !GetOverlappedResult(g_hFile, poverlap, &NumberOfBytesTransferred, 1) )
	{
		result = GetLastError();
		dwret = result;
		if ( result == 0xE0000109 )
			return ERROR_TIMEOUT;
	}
	if ( !result )
	{
		memcpy((PBYTE)pdwbuf, OutBuffer, 0x1C);
		return dwret;
	}
	return result;
}
DWORD sub_10005BA0()
{

	OVERLAPPED *pOverlapped1;
	DWORD result; 
	DWORD NumberOfBytesTransferred; 


	NumberOfBytesTransferred = 0;
	pOverlapped1 = (OVERLAPPED *)sub_100065B0();

	if ( !pOverlapped1 )
		return ERROR_NO_SYSTEM_RESOURCES;
	DeviceIoControl(g_hFile, 0xEA60A298, 0, 0, 0, 0, 0, pOverlapped1);
	if ( GetOverlappedResult(g_hFile, pOverlapped1, &NumberOfBytesTransferred, 1) )
		return 0;
	result = GetLastError();
	if ( result == 0xE0000109 )
		return ERROR_TIMEOUT;
	return result;
}
/////////////////////////////////////////
JIDA_API BOOL JidaWDogCount(FUNCSTRUC14* pfun)
{
	char byVal; 

	byVal = 0;
	return pfun && pfun->dwSelfAddr00 == (DWORD)pfun && !strcmp(pfun->szStr0C, "JHANDLE") && !sub_10005A10((PBYTE)&byVal);
}
JIDA_API BOOL JidaWDogIsAvailable(FUNCSTRUC14* pfun, DWORD dwArg)
{
	return dwArg < (DWORD)JidaWDogCount(pfun);
}
JIDA_API BOOL  JidaWDogTrigger(FUNCSTRUC14* pfun, DWORD dwArg)
{
	return ((DWORD)JidaWDogCount(pfun) > (DWORD)dwArg) && (sub_10005BA0() == 0);
}
JIDA_API BOOL JidaWDogGetConfigStruct(FUNCSTRUC14* pfun, DWORD dwArg, DWORD *pdwRes)
{
	DWORD dwbuf[7]; 

	if ( (DWORD)JidaWDogCount(pfun) <= dwArg )
		return 0;
	if ( !pdwRes || *pdwRes != 16 || sub_10005B10(dwbuf) )
		return 0;
	if ( dwbuf[5] == 2 )
	{
		pdwRes[3] = 0;
	}
	else if ( dwbuf[5] == 3 )
	{
		pdwRes[3] = 1;
	}
	else
	{
		pdwRes[3] = -1;
	}

	pdwRes[2] = dwbuf[0];
	pdwRes[1] = dwbuf[4];
	return 1;
}

JIDA_API BOOL JidaWDogSetConfigStruct(FUNCSTRUC14* pfun, DWORD dwArg, DWORD *pdwBuf)
{
	DWORD InBuffer[7];
	if ( (DWORD)JidaWDogCount(pfun) <= dwArg )
		return 0;
	if ( pdwBuf && *pdwBuf == 16 )
	{		
		InBuffer[5] = 0;
		if ( !pdwBuf[3] )
		{
			InBuffer[5] = 2;
		}
		if ( pdwBuf[3] == 1 )
		{
			InBuffer[5] = 3;			
		}

		sub_10005C80();

		InBuffer[0] = 0;
		InBuffer[1] = pdwBuf[2];
		InBuffer[2] = 0;
		InBuffer[3] = 0;
		InBuffer[4] = pdwBuf[1];
		InBuffer[6] = 1;
		if ( !sub_10005AA0(InBuffer) )
			return sub_10005C10() == 0;
		return 0;
	}
	return 0;
}
JIDA_API BOOL JidaWDogSetConfig(FUNCSTRUC14* pfun, int dwArg, int a3, int a4, int a5)
{
	DWORD dwbuf[4]; 

	dwbuf[2] = a4;
	dwbuf[3] = a5;
	dwbuf[1] = a3;
	dwbuf[0] = 16;
	return JidaWDogSetConfigStruct(pfun, dwArg, dwbuf);
}
JIDA_API BOOL JidaWDogDisable(FUNCSTRUC14* pfun, DWORD dwArg)
{
	return ((DWORD)JidaWDogCount(pfun) > dwArg) && (sub_10005C80() == 0);
}
JIDA_API BOOL JidaBoardCountA(char* szStr, char byArg)
{
	WCHAR *pwszStr; 
	unsigned int dwLen;
	WCHAR *pAlloc;	

	if ( szStr )
	{
		dwLen = 2 * strlen(szStr) + 2;
		pAlloc = (WCHAR*)_alloca(dwLen);
		pwszStr = 0;
		if ( pAlloc )
		{
			pAlloc[0] = 0;
			if ( MultiByteToWideChar(0, 0, szStr, -1, pAlloc, dwLen >> 1) )
				pwszStr = pAlloc;
		}
	}
	else
	{
		pwszStr = 0;
	}
	return g_dword_1001FE8C && (!pwszStr || sub_100042F0(pwszStr, (byArg & 1) == 1) == 1);
}
JIDA_API BOOL JidaBoardOpenW(WCHAR* wszName, int nArg, char byVal, DWORD *pdwRes)
{
	FUNCSTRUC14 *pfun; 

	if ( nArg )
		return 0;
	if ( !pdwRes )
		return 0;
	if ( !g_dword_1001FE8C )
		return 0;
	if ( !sub_100042F0(wszName, (byVal & 1) == 1) )
		return 0;
	pfun = sub_10006D60("JHANDLE");
	if ( !pfun )
		return 0;
	*pdwRes = (DWORD)pfun;
	return 1;
}
JIDA_API BOOL JidaBoardOpenA(char* szStr, int nArg, char byArg, DWORD *pdwRes)
{
	WCHAR *pwszStr; 
	DWORD dwlen; 
	WCHAR *pAlloc; 	

	if ( szStr )
	{
		dwlen = 2 * strlen(szStr) + 2;
		pAlloc = (WCHAR*)_alloca(dwlen);
		pwszStr = 0;
		if ( pAlloc )
		{
			pAlloc[0] = 0;
			if ( MultiByteToWideChar(0, 0, szStr, -1, pAlloc, dwlen >> 1) )
				pwszStr = pAlloc;
		}
	}
	else
	{
		pwszStr = 0;
	}
	return JidaBoardOpenW(pwszStr, nArg, byArg, pdwRes);
}
JIDA_API BOOL JidaBoardOpenByNameW(WCHAR *wszStr, DWORD *pdwRes)
{
	BOOL bret; 
	WCHAR *pwAlloc; 	
	DWORD dwBytes; 
	FUNCSTRUC14* pfun;

	bret = 0;
	dwBytes = 0;
	if ( !g_dword_1001FE8C )
		return 0;
	if ( !wszStr || sub_10004A20(0, 0, 0, &dwBytes) != ERROR_INSUFFICIENT_BUFFER )
		return 0;

	pwAlloc = (WCHAR *)HeapAlloc(g_hHeap_1001FE9C, 8, dwBytes);

	if ( pwAlloc )
	{
		sub_10004A20(0, (PDWORD)pwAlloc, dwBytes, 0);
		if ( !_wcsnicmp(pwAlloc, wszStr, 4) )
		{
			pfun = sub_10006D60("JHANDLE");
			if ( pfun )
			{
				*pdwRes = (DWORD)pfun;
				bret = 1;
			}
		}
		HeapFree(g_hHeap_1001FE9C, 0, pwAlloc);
	}
	return bret;
}
JIDA_API BOOL JidaBoardOpenByNameA(char* szStr, DWORD *pdwRes)
{
	WCHAR *pwszStr; 
	DWORD dwlen; 
	WCHAR *pAlloc; 

	if ( szStr )
	{
		dwlen = 2 * strlen(szStr) + 2;
		pAlloc = (WCHAR*)_alloca(dwlen);
		pwszStr = 0;
		if ( pAlloc )
		{
			pAlloc[0] = 0;
			if ( MultiByteToWideChar(0, 0, szStr, -1, pAlloc, dwlen >> 1) )
				pwszStr = pAlloc;
		}
	}
	else
	{
		pwszStr = 0;
	}
	return JidaBoardOpenByNameW(pwszStr, pdwRes);
}



JIDA_API BOOL JidaBoardGetNameW(FUNCSTRUC14* pfun, WCHAR *wszStr, int nMax)
{
	DWORD dwtmp; 
	WCHAR *pAlloc; 


	dwtmp = 0;
	if ( pfun && pfun->dwSelfAddr00 == (DWORD)pfun && !strcmp(pfun->szStr0C, "JHANDLE") )
		dwtmp = (DWORD)pfun + 16;
	if ( !dwtmp )
		return 0;	
	if ( !wszStr )
		return 0;
	pfun = 0;
	if ( sub_10004A20(0, 0, 0, (PDWORD)&pfun) != 122 )
		return 0;

	pAlloc = (WCHAR*)HeapAlloc(g_hHeap_1001FE9C, 8, (DWORD)pfun);
	if ( !pAlloc )
		return 0;
	sub_10004A20(0, (PDWORD)pAlloc, (DWORD)pfun, 0);
	sub_10006870(pAlloc, wszStr, nMax);
	HeapFree(g_hHeap_1001FE9C, 0, pAlloc);
	return 1;
}
JIDA_API BOOL  JidaBoardGetNameA(DWORD dwBytes, char *pszStr, int nlen)
{
	DWORD dwlenstr; 
	char *pszAlloc; 	
	WCHAR WideCharStr[8]; 

	if ( !JidaBoardGetNameW((FUNCSTRUC14*)dwBytes, WideCharStr, 7) )
		return 0;
	*pszStr = 0;
	if ( WideCharStr )
		dwlenstr = wcslen(WideCharStr);
	else
		dwlenstr = 0;
	pszAlloc = (char*)_alloca(2 * dwlenstr + 2);
	if ( pszAlloc )
	{
		pszAlloc[0] = 0;
		if ( WideCharToMultiByte(0, 0, WideCharStr, -1, pszAlloc, 2 * dwlenstr + 2, 0, 0) )
			sub_10006290(pszStr, pszAlloc, nlen);
	}
	return 1;
}
JIDA_API int JidaBoardGetInfoA(FUNCSTRUC14* pfun, char *pBuf)
{
	DWORD dwtmp; 
	int result;
	char* pszString; 
	WCHAR *pAlloc;
	int dwlenAlloc; 
	char *szAlloc; 
	char *pbySub; 
	int nCnt; 
	int nindex; 
	const char *pszKind; 
	DWORD dwlen2; 
	WORD OutBuffer[4];
	int dwVar1;
	DWORD dwBytes;
	int dwVar; 
	WORD wval[4]; 
	int dwVAL; 
	DWORD* lpMem; 

	dwtmp = 0;
	if ( pfun && pfun->dwSelfAddr00 == (DWORD)pfun && !strcmp(pfun->szStr0C, "JHANDLE") )
		dwtmp = (DWORD)pfun + 16;

	result = 0;
	lpMem = 0;
	dwVAL = 0;
	if ( pBuf && *(DWORD *)pBuf == 256 && dwtmp )
	{
		dwVar = 0;
		dwVar1 = 0;
		memset(pBuf, 0, 0x100);
		*(DWORD *)pBuf = 256;
		JidaBoardGetNameA((DWORD)pfun, (pBuf + 24), 16);
		dwBytes = 0;
		pszString = (char*)(pBuf + 40);
		pBuf[40] = 0;
		if ( sub_10004A20(1, 0, 0, &dwBytes) == 122 )
		{			
			pAlloc = (WCHAR *)HeapAlloc(g_hHeap_1001FE9C, 8, dwBytes);
			if ( pAlloc )
			{
				*pAlloc = 0;
				sub_10004A20(1, (PDWORD)pAlloc, dwBytes, 0);
				dwlenAlloc = 2 * wcslen(pAlloc) + 2;
				szAlloc = (char*)_alloca(dwlenAlloc);
				szAlloc = sub_100067B0(dwlenAlloc, pAlloc, szAlloc);
				sub_10006850(szAlloc, pszString, 16);
				pBuf[55] = 0;
				sub_10006770(pAlloc);
			}		
		}
		if ( !*(BYTE *)pszString  )
		{
			sprintf(pszString, "N/A");
		}
		sub_100085C0((PDWORD)&lpMem, 2);		
		if ( lpMem[5])
		{			
			pbySub = pBuf + 104;
			if ( lpMem[5] )
			{
				nCnt = 16;
				nindex = lpMem[5] - (DWORD)pbySub;
				while ( !nCnt )
				{					
					if ( !pbySub[nindex] )
						break;
					*pbySub++ = pbySub[nindex];
					if ( !--nCnt )
					{
						--pbySub;
						break;
					}
				}
				*pbySub = 0;
			}
		}
		if ( lpMem[4] )
		{
			sscanf_s((const char*)lpMem[4], "%hi.%hi", &dwVar, &dwVar1);
			*((WORD *)pBuf + 60) = dwVar1 | ((WORD)dwVar << 8);
		}
		if ( &lpMem )
		{
			HeapFree(g_hHeap_1001FE9C, 0, lpMem);
			lpMem = 0;
		}
		sub_10004B40(&dwVAL, 0);

		if ( (dwVAL & 1) != 0 )
		{			
			sprintf(pBuf + 128, "CPU");

		}
		if ( (dwVAL & 2) != 0 )
		{
			sprintf(pBuf+128, "%s,VGA", pBuf+128);
		}
		if ( (dwVAL & 4) != 0 )
		{
			sprintf(pBuf+128, "%s,VGA", pBuf+128);
		}
		sprintf(pBuf+56, "JUMP");		
		sub_10004B40(&dwVAL, 1);		
		switch ( dwVAL )
		{
		case 1:
			pszKind = "CPU";
			break;
		case 2:
			pszKind = "VGA";
			break;
		case 4:
			pszKind = "IO";
			break;
		}

		sprintf(pBuf+8, "%s", pszKind);

		sub_100085C0(lpMem, 0);
		if ( lpMem[3] )
		{
			dwlen2 = strlen((const char *)lpMem[3]);
			if ( dwlen2 > 5 )
				*((WORD *)pBuf + 63) = *(char *)(lpMem[3] + 5) - 48;
			if ( dwlen2 > 6 )
				*((WORD *)pBuf + 61) = (*(char *)(lpMem[3] + 6) - 48) << 8;
			if ( dwlen2 > 7 )
				*((WORD *)pBuf + 61) |= *(char *)(lpMem[3] + 7) - 48;

		}
		if ( &lpMem )
		{
			HeapFree(g_hHeap_1001FE9C, 0, lpMem);
			lpMem = 0;
		}
		sub_100085C0(lpMem, 160);		
		if ( lpMem )
		{
			if ( sub_100066C0((char*)lpMem[5], wval) )
			{				
				*((WORD *)pBuf + 38) = wval[3];			
				*((WORD *)pBuf + 39) = wval[2];
				*((WORD *)pBuf + 37) = wval[1];
				*((WORD *)pBuf + 36) = wval[0];
			}
			if ( sub_100066C0((char*)lpMem[6],wval) )
			{
				*((WORD *)pBuf + 46) = wval[3];			
				*((WORD *)pBuf + 47) = wval[2];
				*((WORD *)pBuf + 45) = wval[1];
				*((WORD *)pBuf + 44) = wval[0];
			}
		}
		if ( &lpMem )
		{
			if ( lpMem )
				HeapFree(g_hHeap_1001FE9C, 0, lpMem);
		}
		sub_100048E0((PBYTE)OutBuffer);
		*((WORD *)pBuf + 62) = OutBuffer[1] | (OutBuffer[0] << 8);
		return 1;
	}
	return result;
}
JIDA_API BOOL JidaBoardCountW(WCHAR* wszStr, char byVal)
{
	if ( !g_dword_1001FE8C )
		return 0;
	if (!wszStr)
	{
		return TRUE;
	}
	if (sub_100042F0(wszStr, (byVal & 1) == 1) == 1)
	{
		return TRUE;
	}
	return FALSE;
}





JIDA_API BOOL JidaBoardGetInfoW(DWORD dwArg1, PDWORD pdwRes)///////////////////
{
	return 0;
}
JIDA_API BOOL JidaVgaGetBacklightEnable(FUNCSTRUC14* pfun, PDWORD pdwRes)
{
	DWORD dwtmp; 

	dwtmp = 0;
	if ( pfun && pfun->dwSelfAddr00 == (DWORD)pfun && !strcmp(pfun->szStr0C, "JHANDLE") )
		dwtmp = (DWORD)pfun + 16;
	if ( !dwtmp )
		return 0;
	if ( !pdwRes )
		return 0;
	pfun = 0;
	if ( sub_10005E90((PDWORD)&pfun) )
		return 0;
	*pdwRes = (DWORD)pfun;
	return 1;
}
JIDA_API BOOL JidaVgaSetBacklightEnable(FUNCSTRUC14* pfun, DWORD dwArg)
{
	DWORD dwtmp; 	
	DWORD dwParam = 0;
	dwtmp = 0;
	if ( pfun && pfun->dwSelfAddr00 == (DWORD)pfun && !strcmp(pfun->szStr0C, "JHANDLE") )
		dwtmp = (DWORD)pfun + 16;

	if ( dwtmp )
	{
		if ( dwArg )
		{
			dwParam = 1;			
		}
		if (!sub_10005E20(dwParam))
		{
			return TRUE;
		}
	}
	return FALSE;
}
JIDA_API int JidaI2CType(FUNCSTRUC14* pfun, DWORD dwArg)
{
	DWORD dwtmp; 

	dwtmp = 0;
	if ( pfun && pfun->dwSelfAddr00 == (DWORD)pfun && !strcmp(pfun->szStr0C, "JHANDLE") )
		dwtmp = (DWORD)pfun + 16;

	if ( dwtmp )
	{
		if ( dwArg < g_dword_1001FE84 )
			return g_dword_1001FDB8[2 * dwArg + 1];
	}
	return 0;
}
JIDA_API BOOL JidaI2CWriteReadCombined(FUNCSTRUC14* pfun, DWORD dwArg1, BYTE dwArg2, int dwArg3, int dwArg4, int dwArg5, int dwVal)
{
	DWORD dwtmp; 	
	DWORD dwVar; 

	dwtmp = 0;
	if ( pfun && pfun->dwSelfAddr00 == (DWORD)pfun && !strcmp(pfun->szStr0C, "JHANDLE") )
		dwtmp = (DWORD)pfun + 16;
	dwVar = 0;
	pfun = 0;	
	if ( dwtmp )
	{
		if ( dwArg1 < g_dword_1001FE84 )
		{
			if ( !sub_10004FB0(dwVal, g_dword_1001FDB8[2 * dwArg1], dwArg2, (LPVOID)dwArg3, dwArg4, (PDWORD)&pfun, (LPVOID)dwArg5, &dwVar, 1) && (DWORD)pfun == (DWORD)dwArg4 && dwVar == dwVal )
				return TRUE;
		}
	}
	return FALSE;
}

JIDA_API BOOL JidaIOGetDirection(FUNCSTRUC14* pfun, int a2, int a3)
{
	int dwRet; 

	if ( !JidaIOIsAvailable(pfun, a2) || !a3)
		return 0;
	dwRet = 0x490;
	if ( g_pGpioDefaultProxy_1001FE40 )
		dwRet = ((CGpioDefaultProxy*)g_pGpioDefaultProxy_1001FE40)->sub_10009F00(g_dword_1001FE18[0] | g_dword_1001FE18[1], (PDWORD)a3);

	if (!dwRet) return TRUE;
	return FALSE;
}

JIDA_API BOOL JidaIOSetDirection(FUNCSTRUC14* pfun, int a2, int a3)
{
	int dwRet; 

	if ( !JidaIOIsAvailable(pfun, a2) )
		return 0;
	dwRet = 0x490;
	if ( g_pGpioDefaultProxy_1001FE40 )
		dwRet = ((CGpioDefaultProxy*)g_pGpioDefaultProxy_1001FE40)->sub_1000A040(g_dword_1001FE18[0] | g_dword_1001FE18[1], (PDWORD)a3);

	if (!dwRet) return TRUE;
	return FALSE;
}
JIDA_API BOOL JidaIOGetDirectionCaps(DWORD dwArg1, DWORD dwArg2, DWORD *pdwRes1, DWORD *pdwRes2)
{
	DWORD dwBuf[10]; 

	if ( !JidaIOIsAvailable((FUNCSTRUC14*)dwArg1, dwArg2)
		|| !pdwRes1
		|| !pdwRes2
		|| !g_pGpioDefaultProxy_1001FE40
		|| ((CGpioDefaultProxy*)g_pGpioDefaultProxy_1001FE40)->sub_1000A3C0(dwBuf) )
	{
		return 0;
	}

	*pdwRes1 = dwBuf[0];
	*pdwRes2 = dwBuf[1];
	return 1;
}


/////////////////////////////////////////////////////////////////////////
JIDA_API int JidaTemperatureCount(FUNCSTRUC14* pfun)
{
	DWORD dwval;
	int result; 

	dwval = 0;
	if ( pfun && pfun->dwSelfAddr00 == (DWORD)pfun && !strcmp(pfun->szStr0C, "JHANDLE") )
		dwval = (DWORD)pfun + 16;
	result = 0;
	if ( dwval )
		return (int)LOWORD(g_dword_1001FEB4[2]);
	return result;
}

JIDA_API BOOL JidaTemperatureGetInfo(FUNCSTRUC14* pfuns, WORD wArg, DWORD *pdwRes)
{
	int dwtmp; 
	PDWORD pdwOff; 
	int nIdx; 
	int nCnt; 
	DWORD dwvar4; 

	dwtmp = 0;
	if ( pfuns && pfuns->dwSelfAddr00 == (DWORD)pfuns && !strcmp(pfuns->szStr0C, "JHANDLE") )
		dwtmp = (DWORD)pfuns + 16;

	if ( wArg < LOWORD(g_dword_1001FEB4[2]) )
	{
		pdwOff = (PDWORD)(g_dword_1001FEB4[3] + 20 * wArg);
		if ( pdwOff )
		{
			if ( dwtmp && pdwRes && *pdwRes == 44 )
			{
				pdwRes[2] = 0;
				pdwRes[3] = 0;
				pdwRes[8] = 0;
				pdwRes[10] = 0;
				pdwRes[4] = -1;
				pdwRes[5] = -1;
				pdwRes[6] = -1;
				pdwRes[7] = -1;
				pdwRes[9] = -1;
				if ( sub_10001110(pdwOff, (PDWORD)&pfuns) == 1 )
					pdwRes[7] = (DWORD)pfuns;
				if ( sub_10001150(pdwOff, (PDWORD)&pfuns) == 1 )
					pdwRes[9] = (DWORD)pfuns;
				if ( sub_10001080(pdwOff, (PDWORD)&wArg, (PDWORD)&pdwRes) == 1 )
				{
					if (wArg < 0)		
						pdwRes[5] = 0;
					else
						pdwRes[5] = wArg;
					if (pdwRes < 0)		
						pdwRes[6] = 0;
					else
						pdwRes[6] = (DWORD)pdwRes;					
				}
				if ( sub_100010D0(pdwOff, &dwvar4) == 1 )
					pdwRes[4] = dwvar4;

				nIdx = 0;
				nCnt = 0;
				BOOL bflag = 0;
				while ( g_dword_1001AFE8[nCnt] != pdwOff[1] )
				{
					nCnt += 3;
					++nIdx;
					if ( nCnt >= 60 )
					{						
						bflag = 1;
						break;
					}
				}
				pdwRes[0] = 44;
				if (!bflag)
				{
					pdwRes[1] = g_dword_1001AFE8[3 * nIdx + 1];					
				}
				else
				{
					pdwRes[1] = 7;
				}
				return TRUE;
			}
		}
	}
	return FALSE;
}
JIDA_API BOOL JidaTemperatureGetCurrent(FUNCSTRUC14* pfun, WORD wArg, DWORD *pdwVal, DWORD *pdwRes)
{
	DWORD dwtmp; 
	DWORD dwVal; 	

	dwtmp = 0;
	if ( pfun && pfun->dwSelfAddr00 == (DWORD)pfun && !strcmp(pfun->szStr0C, "JHANDLE") )
		dwtmp = (DWORD)pfun + 16;
	dwVal = 0;
	if ( wArg < LOWORD(g_dword_1001FEB4[2]) )
		dwVal = g_dword_1001FEB4[3] + 20 * wArg;
	wArg = 0;
	if ( !dwtmp || !pdwRes)
		return 0;	

	if ( !pdwVal || !dwVal )
		return 0;
	if ( !sub_10001040((DWORD*)dwVal, (PDWORD)&wArg) )
		return 0;
	if (wArg <= 0)
	{
		*pdwVal = 0;
	}
	else 
		*pdwVal = wArg;
	sub_10001190((PDWORD)dwVal, (PDWORD)&pfun);
	*pdwRes = (WORD)pfun;
	return 1;
}
JIDA_API int JidaFanCount(FUNCSTRUC14* pfun)
{
	DWORD dwval;
	int result; 

	dwval = 0;
	if ( pfun && pfun->dwSelfAddr00 == (DWORD)pfun && !strcmp(pfun->szStr0C, "JHANDLE") )
		dwval = (DWORD)pfun + 16;
	result = 0;
	if ( dwval )
		return (int)LOWORD(g_dword_1001FEB4[6]);
	return result;
}

JIDA_API BOOL JidaFanGetInfo(FUNCSTRUC14* pfuns, WORD wArg, DWORD *pdwRes)
{
	int dwtmp; 
	PDWORD pdwOff; 
	int nIdx; 
	int nCnt; 
	DWORD dwvar4; 
	DWORD dwRes;

	dwtmp = 0;
	if ( pfuns && pfuns->dwSelfAddr00 == (DWORD)pfuns && !strcmp(pfuns->szStr0C, "JHANDLE") )
		dwtmp = (DWORD)pfuns + 16;

	if ( wArg < LOWORD(g_dword_1001FEB4[6]) )
	{
		pdwOff = (PDWORD)(g_dword_1001FEB4[7] + 20 * wArg);
		if ( pdwOff )
		{
			if ( dwtmp && pdwRes && *pdwRes == 52 )
			{
				pdwRes[2] = 0;
				pdwRes[3] = 0;
				pdwRes[8] = 0;
				pdwRes[10] = 0;
				pdwRes[5] = -1;
				pdwRes[6] = -1;
				pdwRes[7] = -1;
				pdwRes[9] = -1;
				pdwRes[11] = -1;
				pdwRes[12] = -1;
				if ( sub_10001110(pdwOff, &dwRes) == 1 )
					pdwRes[7] = dwRes;
				if ( sub_10001150(pdwOff, &dwRes) == 1 )
					pdwRes[9] = dwRes;
				if ( sub_10001080(pdwOff, (PDWORD)&wArg, &dwRes) == 1 )
				{
					pdwRes[5] = wArg;
					pdwRes[6] = dwRes;
				}
				if ( sub_100010D0(pdwOff, &dwvar4) == 1 )
					pdwRes[5] = dwvar4;

				nIdx = 0;
				nCnt = 0;
				BOOL bflag = 0;
				while ( g_dword_1001AFE8[nCnt] != pdwOff[1] )
				{
					nCnt += 3;
					++nIdx;
					if ( nCnt >= 60 )
					{						
						bflag = 1;
						break;
					}
				}
				pdwRes[0] = 52;
				if (!bflag)
				{
					pdwRes[1] = g_dword_1001AFE8[3 * nIdx + 1];
					pdwRes[4] = g_dword_1001AFE8[3 * nIdx + 2];
				}
				else
				{
					pdwRes[1] = 5;
					pdwRes[4] = -1;
				}
				return TRUE;
			}
		}
	}
	return FALSE;
}
JIDA_API BOOL JidaFanGetCurrent(FUNCSTRUC14* pfun, WORD wArg, DWORD *pdwVal, DWORD *pdwRes)
{
	DWORD dwtmp; 
	DWORD dwVal; 	

	dwtmp = 0;
	if ( pfun && pfun->dwSelfAddr00 == (DWORD)pfun && !strcmp(pfun->szStr0C, "JHANDLE") )
		dwtmp = (DWORD)pfun + 16;
	dwVal = 0;
	if ( wArg < LOWORD(g_dword_1001FEB4[6]) )
		dwVal = g_dword_1001FEB4[7] + 20 * wArg;
	wArg = 0;
	if ( !dwtmp || !pdwRes)
		return 0;	

	if ( !pdwVal || !dwVal )
		return 0;
	if ( !sub_10001040((DWORD*)dwVal, (PDWORD)&wArg) )
		return 0;
	*pdwVal = wArg;
	sub_10001190((PDWORD)dwVal, (PDWORD)&pfun);
	*pdwRes = (WORD)pfun;
	return 1;
}
JIDA_API int JidaVoltageCount(FUNCSTRUC14* pfun)
{
	DWORD dwval;
	int result; 

	dwval = 0;
	if ( pfun && pfun->dwSelfAddr00 == (DWORD)pfun && !strcmp(pfun->szStr0C, "JHANDLE") )
		dwval = (DWORD)pfun + 16;
	result = 0;
	if ( dwval )
		return (int)LOWORD(g_dword_1001FEB4[4]);
	return result;
}
JIDA_API BOOL JidaVoltageGetInfo(FUNCSTRUC14* pfuns, WORD wArg, DWORD *pdwRes)
{
	int dwtmp; 
	PDWORD pdwOff; 
	int nIdx; 
	int nCnt; 
	DWORD dwvar4; 
	DWORD dwRes;

	dwtmp = 0;
	if ( pfuns && pfuns->dwSelfAddr00 == (DWORD)pfuns && !strcmp(pfuns->szStr0C, "JHANDLE") )
		dwtmp = (DWORD)pfuns + 16;

	if ( wArg < LOWORD(g_dword_1001FEB4[4]) )
	{
		pdwOff = (PDWORD)(g_dword_1001FEB4[5] + 20 * wArg);
		if ( pdwOff )
		{
			if ( dwtmp && pdwRes && *pdwRes == 48 )
			{
				pdwRes[4] = 0;
				pdwRes[3] = 0;
				pdwRes[9] = 0;
				pdwRes[11] = 0;
				pdwRes[8] = -1;
				pdwRes[10] = -1;
				pdwRes[6] = -1;
				pdwRes[7] = -1;
				pdwRes[5] = -1;
				if ( sub_10001110(pdwOff, &dwRes) == 1 )
					pdwRes[8] = dwRes;
				if ( sub_10001150(pdwOff, &dwRes) == 1 )
					pdwRes[10] = dwRes;
				if ( sub_10001080(pdwOff, (PDWORD)&wArg, &dwRes) == 1 )
				{
					pdwRes[6] = wArg;
					pdwRes[7] = dwRes;
				}
				if ( sub_100010D0(pdwOff, &dwvar4) == 1 )
					pdwRes[5] = dwvar4;

				nIdx = 0;
				nCnt = 0;
				BOOL bflag = 0;
				while ( g_dword_1001AFE8[nCnt] != pdwOff[1] )
				{
					nCnt += 3;
					++nIdx;
					if ( nCnt >= 60 )
					{						
						bflag = 1;
						break;
					}
				}
				pdwRes[0] = 0x30;
				if (!bflag)
				{
					pdwRes[1] = g_dword_1001AFE8[3 * nIdx + 1];
					pdwRes[2] = g_dword_1001AFE8[3 * nIdx + 2];
				}
				else
				{
					pdwRes[1] = 6;
					pdwRes[2] = -1;
				}
				return TRUE;
			}
		}
	}
	return FALSE;
}
JIDA_API BOOL JidaVoltageGetCurrent(FUNCSTRUC14* pfun, WORD wArg, DWORD *pdwVal, DWORD *pdwRes)
{
	DWORD dwtmp; 
	DWORD dwVal; 	

	dwtmp = 0;
	if ( pfun && pfun->dwSelfAddr00 == (DWORD)pfun && !strcmp(pfun->szStr0C, "JHANDLE") )
		dwtmp = (DWORD)pfun + 16;
	dwVal = 0;
	if ( wArg < LOWORD(g_dword_1001FEB4[4]) )
		dwVal = g_dword_1001FEB4[5] + 20 * wArg;
	wArg = 0;
	if ( !dwtmp || !pdwRes)
		return 0;	

	if ( !pdwVal || !dwVal )
		return 0;
	if ( !sub_10001040((DWORD*)dwVal, (PDWORD)&wArg) )
		return 0;
	*pdwVal = wArg;
	sub_10001190((PDWORD)dwVal, (PDWORD)&pfun);
	*pdwRes = (WORD)pfun;
	return 1;
}


JIDA_API BOOL JidaVoltageGetStringA(FUNCSTRUC14* pfun, WORD wArg, char* pszDest, int nMax, DWORD* pdwRes)
{
	return sub_10004340(pfun, 1, wArg, pszDest, nMax, pdwRes);
}
JIDA_API BOOL JidaTemperatureGetStringA(FUNCSTRUC14* pfun, WORD wArg, char* pszDest, int nMax, DWORD* pdwRes)
{
	return sub_10004340(pfun, 2, wArg, pszDest, nMax, pdwRes);
}

JIDA_API BOOL JidaFanGetStringA(FUNCSTRUC14* pfun, WORD wArg, char* pszDest, int nMax, DWORD* pdwRes)
{
	return sub_10004340(pfun, 0, wArg, pszDest, nMax, pdwRes);
}

JIDA_API BOOL JidaVoltageGetStringW(FUNCSTRUC14* pFun, WORD wArg, WORD* pwDest,  int nMax, DWORD* pdwRes)
{
	return sub_10004420(pFun, 1, wArg, pwDest, nMax, pdwRes);
}
JIDA_API BOOL JidaTemperatureGetStringW(FUNCSTRUC14* pFun, WORD wArg, WORD* pwDest,  int nMax, DWORD* pdwRes)
{
	return sub_10004420(pFun, 0, wArg, pwDest, nMax, pdwRes);
}
JIDA_API BOOL JidaFanGetStringW(FUNCSTRUC14* pfun, DWORD wArg, WORD* pwDest, int nMax, DWORD* pdwRes)
{
	return sub_10004420(pfun, 2, (WORD)wArg, pwDest, nMax, pdwRes);
}


JIDA_API BOOL JidaI2CSetTimeouts(FUNCSTRUC14* pfuns, DWORD dwArg1, DWORD dwArg2, DWORD dwArg3)
{
	DWORD dwVal; 
	DWORD dwRet; 
	dwVal = 0;
	if ( pfuns && pfuns->dwSelfAddr00 == (DWORD)pfuns && !strcmp(pfuns->szStr0C, "JHANDLE") )
		dwVal = (DWORD)pfuns + 16;

	dwRet = 87;
	if ( dwVal && dwArg1 < g_dword_1001FE84 && g_dword_1001FDB8[2 * dwArg1] != 16 )
		dwRet = sub_10005500(dwArg2, dwArg3, g_dword_1001FDB8[2 * dwArg1]);
	return dwRet == 0;
}


JIDA_API BOOL JidaI2CSetBaudrate(FUNCSTRUC14* pfuns, DWORD dwArg1, DWORD dwArg2)
{
	DWORD dwVal;
	DWORD dwret;

	dwVal = 0;
	if ( pfuns && pfuns->dwSelfAddr00 == (DWORD)pfuns && !strcmp(pfuns->szStr0C, "JHANDLE") )
		dwVal = (DWORD)pfuns + 16;
	dwret = 87;
	if ( dwVal && dwArg1 < g_dword_1001FE84 && g_dword_1001FDB8[2 * dwArg1] != 16 )
		dwret = sub_100055D0(dwArg2, g_dword_1001FDB8[2 * dwArg1]);
	return dwret == 0;
}

JIDA_API BOOL JidaI2CGetBaudrate(FUNCSTRUC14* pfuns, DWORD dwArg, LPVOID lpOutBuffer)
{
	int dwVal;
	int dwRet;

	dwVal = 0;
	if ( pfuns && pfuns->dwSelfAddr00 == (DWORD)pfuns && !strcmp(pfuns->szStr0C, "JHANDLE") )
		dwVal = (DWORD)pfuns + 16;
	dwRet = 87;
	if ( dwVal && dwArg < g_dword_1001FE84 && lpOutBuffer && g_dword_1001FDB8[2 * dwArg]  != 16 )
		dwRet = sub_100056A0(lpOutBuffer, g_dword_1001FDB8[2 * dwArg]);
	if (!dwRet) return TRUE;
	return FALSE;
}

JIDA_API BOOL JidaMuxCaps(FUNCSTRUC14* pfuns, LPVOID lpOutBuffer)
{
	DWORD dwVal;

	dwVal = 0;
	if ( pfuns && pfuns->dwSelfAddr00 == (DWORD)pfuns && !strcmp(pfuns->szStr0C, "JHANDLE") )
		dwVal = (DWORD)pfuns + 16;

	if ( !lpOutBuffer || !dwVal)
		return 0;
	if(!sub_10006140(lpOutBuffer)) return TRUE;
	return FALSE;
}


JIDA_API BOOL JidaMuxEnable(FUNCSTRUC14* pfun, char InBuffer, int a3)
{
	if ( !pfun || pfun->dwSelfAddr00 != (DWORD)pfun || strcmp(pfun->szStr0C, "JHANDLE"))
		return 0;
	if ( (int)pfun == -16 )
		return 0;
	if(!sub_10006050(InBuffer, a3)) return TRUE;
	return FALSE;
}

JIDA_API BOOL JidaMuxGetState(FUNCSTRUC14* pfuns, LPVOID lpOutBuffer)
{
	DWORD dwVal; 

	dwVal = 0;
	if ( pfuns && pfuns->dwSelfAddr00 == (DWORD)pfuns && !strcmp(pfuns->szStr0C, "JHANDLE") )
		dwVal = (DWORD)pfuns + 16;
	if ( !lpOutBuffer  || !dwVal)
		return 0;
	if (!sub_100060D0(lpOutBuffer)) return TRUE;
	return FALSE;
}


JIDA_API BOOL JidaBeep(FUNCSTRUC14* pfnstruct, DWORD InBuffer, DWORD dwMilliseconds)
{
	if ( !pfnstruct || pfnstruct->dwSelfAddr00 != (DWORD)pfnstruct || strcmp(pfnstruct->szStr0C, "JHANDLE") || (int)pfnstruct == -16)
		return 0;

	if ( !sub_100061B0(InBuffer, dwMilliseconds) ) return TRUE;
	return FALSE;
}