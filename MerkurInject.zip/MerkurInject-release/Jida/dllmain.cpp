// dllmain.cpp : Defines the entry point for the DLL application.
#include "stdafx.h"
#include <setupapi.h>
#include <cfgmgr32.h>
#include "Jida_global.h"
#include "Smbus_Def.h"
#include <malloc.h>
#include "SuperIo.h"
#include "Sensor.h"
#include "W836x.h"
#include "Adt7475.h"
#include "Adt7490.h"
#include "W83L771Ax.h"
#include "NCT7802.h"
#include "AmdBrazos.h"
#include "W83627DHGP.h"
#include <tchar.h>

HANDLE g_hFile = INVALID_HANDLE_VALUE;
DWORD g_dwTlsIndex_1001F01C;
DWORD g_dword_1001FE80;
DWORD g_dword_1001FE84;
DWORD g_dword_1001FE88;
DWORD g_DS_0[2];
CRITICAL_SECTION g_CS_1001FE44;
LPVOID g_pGpioDefaultProxy_1001FE40;
HMODULE g_hModule_1001FE5C;
PDWORD g_pClassList_1001FE60[8];
DWORD g_dword_1001FE8C;
DWORD g_dword_1001FE90;
HANDLE g_hMutex_1001FE94;
HANDLE g_hMutex_1001FEB0;
DWORD g_DWORD_1001FE98;
HANDLE g_hHeap_1001FE9C;
DWORD g_pCSmbus_Def_1001FEA0;


DWORD g_dword_1001FEB4[8];
//LPVOID g_dword_1001FEB8;
DWORD g_dword_1001FED4;
LPVOID g_lpMem_1001FED8;
// LPVOID g_pEmbeddedEeprom_1001FEDC;
// LPVOID g_pCCmos_1001FEE0;
LPVOID g_pStorage_1001FEDC[2];
DWORD g_dword_1001FEE4;
DWORD  g_ClassGuid_1001AA90[4] = {0x0D8FA159F, 0x4823C65F, 0x8B84E48A, 0x0AE8446DE};
DWORD	g_ClassGuid_1001AAA0[4]= {0x0F9CAB201, 0x4389BB2E, 0x0A9E55197, 0x0EF6DBA99};
DWORD g_dword_1001FEA8[2];
BYTE g_byte_1001AE1C[4] = {0x2E, 0x4E, 0, 0};
DWORD g_dword_1001FEA4;
DWORD g_dword_1001FDB8[24];
DWORD g_dword_1001FE18[10];
DWORD releaseTlsValue_10006560();
BOOL InitDll_10006490(HMODULE hMod);
DWORD sub_10006410();
OVERLAPPED* sub_100065B0();
HANDLE ReleaseDll_100064C0();
int sub_10004680();
void sub_10008160();
void sub_10007790();

DWORD sub_1000BAA0(DWORD dwArg1);
DWORD sub_1000BBA0(DWORD dwArg1);
DWORD sub_1000AE10(DWORD dwArg1);
DWORD sub_1000BDE0(DWORD dwArg1);
DWORD sub_1000C5A0(DWORD dwArg1);
DWORD sub_10007DD0(DWORD dwArg1);
DWORD	sub_10006E30();
LPVOID	sub_10009E70();
LPVOID sub_1000A710();

FUNCTBL20 g_dword_1001F03C[3] ={
	{
		0x0FC1FF2F1,0x41118870,0x235F3C90,0x117489F1, (LPVOID)sub_10006E30 // CSmbus_constructor
	},
	{
		0x85118BA9,0x4544B089,0x787498A8,0x0AD6C7915, (LPVOID)sub_10009E70// CGpioDefalut_constructor
	},
	{
		0x0C3B40AAB,0x4FAF5EE8,0x0CA94B591,0x0B094009D, (LPVOID)sub_1000A710//CGpioDefalut_constructor
	}
};

LPVOID CSensorIoCreators_1001AE20[7]=
{
	sub_1000BAA0, sub_1000BBA0, sub_1000AE10, sub_1000BDE0, sub_1000C5A0, sub_10007DD0, sub_10007DD0
	////CAdt7475,CAdt7490,CW83L771Ax,CNCT7802,CAmdBrazos,CSuperIo,CSuperIo
};
FUNCTBL16 g_dword_1001AC40[9]=
{{0, 0x2C, 1,(LPVOID)MySetupDiGetDeviceRegistryProperty_1000CB20},  
{0x0B, 30,0x1,(LPVOID)MySetupDiGetDeviceRegistryProperty_1000CB20},
{0x1,0x1C,0x1,(LPVOID)MySetupDiGetDeviceRegistryProperty_1000CB20},
{0x2,0x20,0x1,(LPVOID)MySetupDiGetDeviceRegistryProperty_1000CB20},
{0x12,0x34,0x1,(LPVOID)MySetupDiGetDeviceRegistryProperty_1000CB20},
{0x0E,0x28,0x1,(LPVOID)MySetupDiGetDeviceRegistryProperty_1000CB20},
{0x9,0x38,0x1,(LPVOID)MySetupDiGetDeviceRegistryProperty_1000CB20},
{0x19,0x24,0,(LPVOID)MySetupDiGetDeviceRegistryProperty_1000CB70},
{0x0F,0x18,0, (LPVOID)MySetupDiGetDeviceRegistryProperty_1000CB70}
};
DWORD g_dword_1001AF88[24] = {   
	0, 0x10000, 0x12, 0x60000, 0x3, 0x50000, 1, 0x40000, 9, 0x80000,
	0xA, 0x90000, 0xD, 0xA0000, 0xE, 0xB0000, 5, 0xE0000,
	6, 0xF0000, 10, 0x20000, 4, 0x30000};
DWORD g_dword_1001AFE8[60] = 
	{ 1, 0x0, 0xFFFFFFFF, 0x2, 0x1, 0xFFFFFFFF, 0x3, 0x2, 0xFFFFFFFF, 
	4, 0x3, 0xFFFFFFFF, 0x5, 0x5, 0xFFFFFFFF, 0x6, 0x6, 0xFFFFFFFF,
	0xB, 0x0, 0xFFFFFFFF, 0x0C, 0x3, 0x9C4, 0x0D, 0x4, 0xFFFFFFFF,
	0xE, 0x1, 0xFFFFFFFF, 0x0F, 0x7, 0x41A, 0x10, 0x8, 0x9C4, 0x11,
	9, 0x0CE4, 0x12, 0x0A, 0x0CE4, 0x13, 0x0B, 0x1388, 0x14, 0x2,
	0x1388, 0x1A, 0x0, 0xFFFFFFFF, 0x1B, 0x1, 0xFFFFFFFF, 0x1C,
	3, 0xFFFFFFFF, 0x1D, 0x4, 0xFFFFFFFF};

 DWORD g_dword_1001AE3C[4] = {7, 0x0A, 0x1E, 0x01};
 DWORD g_dword_10015D48[6] = {0x2062176, 0x5354647, 0x241, 0x4302276, 0x7A44849, 0x441};
 DWORD g_dword_10015D60[21] = {0x2062176, 0x5354647, 0x200241, 0x4302276, 0x7A44849, 0x441, 0x4301E1F,
	 0x3E88486,0x8081,0x6C02376,0xB934A4B,0x400841,0x32477,0x1BC74C4D,0x800142,0x32076,0x5C84445,0x100141,0x6C01D1F,0x5C88587,0x4081};
 BYTE g_byte_10015D20[16] = {0x29, 0x28, 0x42, 0x04, 0x2B, 0x2A, 0x42, 0x08, 0x2D, 0x2C, 0x42, 0x10, 0x2f, 0x2E, 0x42,0x20};
 BYTE g_byte_10015D30[24] = {0x77,0x25,0x6,0x7,0x4f,0x4e,0x41,0x10,
	 0x77,0x26,0x30,0x4,0x51,0x50,0x41,0x20,
	 0x77,0x27, 0xc0, 0x6, 0x53, 0x52, 0x41, 0x40};

 DWORD g_dword_1001AF48[16] = {0x80000, 0xFFFFFFFF, 0x1E, 0x3A, 0x59, 0x77, 0x96, 0xB4, 0xD3,0xF2, 0x110, 0x12F, 0x14D, 0x16C, 0x7270, 0};
 DWORD g_dword_10015BB0[14] = 
 {
	 0x14D0028, 0x5D043047,0x290320,	0x0C047044D,0x4405D06,0x104D002A,0x5D06C04B,0x3F0580,0x3590447,0x5804C00,0x1470553,
	 0x59020C59,	0x580,	0x0
 };
 DWORD g_dword_10015A60[9] = {0x27,0x77007600,0x10045900,0x1520150,0x79007801,0x20045900,0x2520250,0x7B007A00,0x20045A00};

 DWORD g_dword_10015AA8[32] = {
	 0x20, 0x2C002B00,0x1045900,0x216408,0x2D000000,0x59002E00,0x64080204,0x24,0x34003300,0x1045A00,0x256408,0x35000000,
	 0x5B003600,	0x64082004,	0x26,0x38003700,0x10045B00,0x5506408,0x54000000,0x5B055505,0x0C8080104,0x5D0551,0x57055601,
	 0x2045B05,	0x23C808,0x31000000,0x59003200,0x0C8080804,0x22,0x30002F00,	0x4045900,	0x0C808};

 DWORD g_dword_10015A84[9] = 
 {
	 0x27, 0x3900, 0x10045900, 0x1520150, 0x15501, 0x20045900, 0x2520250,0x25501, 0x20045A00
 };

 DWORD g_dword_10015B28[32] = 
 {0x20,
 0x2C002B00,	0x1045900,	0x216410,	0x2D000000,	0x59002E00,	0x64100204,	0x22,	0x30002F00,	0x4045900,	0x236410,
 0x31000000,	0x59003200,	0x0A8100804,	0x24,	0x34003300,	0x1045A00,	0x256410,	0x35000000,	0x5A003600,	0x64100204,
 0x26,	0x38003700,	0x4045A00,	0x5506410,	0x54000000,	0x5B055505,	0x98100104,	0x5D0551,	0x57055601,	0x2045B05,
 0x6410,
 };
BYTE g_byte_10015BA8[8] = {1,2,4,8,0x10,0x20,0x40,0x80};
STRINGARRAY g_dword_1001AE48[24] = {{1,"Temp CPU"}, { 2, "Temp Box"},{ 3, "Temp Environment"},{ 4, "Temp Module"},{ 5, "Temp Chipset"},
{ 6, "Temp Video"},{ 7, "Temp Unknown"},{ 0xA,"Voltage Unknown"},{ 0xB,"Voltage CPU"},{ 0xC,"Voltage CMOS Battery"},{ 0xD,"Voltage Battery"},
{ 0x14,"Voltage Standby"},{ 0xE,"Voltage Module Input"},{ 0xF,"Voltage 1.05V"},{ 0x10,"Voltage 2.5V"},{ 0x11,"Voltage 3.3V S0"},
{ 0x12,"Voltage 3.3V S5"},{ 0x13,"Voltage 5V S0"},{ 0x14,"Voltage 5V S5"},{ 0x1A, "Fan CPU"},{ 0x1B,"Fan Box"},{ 0x1C, "Fan Chipset"},
{ 0x1D, "Fan Video"},{ 0x1E, "Fan Unknown"}};


 LPVOID createClasssW83627DHGP_1000CD00(SHORT wArg1, CW83627DHGP* pW83627DHGP, DWORD dwArg3);

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
					 )
{
	BOOL result = FALSE;
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		{
			TCHAR tszModuleName[MAX_PATH] = _T("");
			TCHAR tszDllName[MAX_PATH] = _T("");
			GetModuleFileName(NULL, tszModuleName, MAX_PATH);
			TCHAR* p = _tcsrchr(tszModuleName, '\\');

			*(p) = NULL;
			SetCurrentDirectory(tszModuleName);
		}
		result = InitDll_10006490(hModule);
		break;
	case DLL_THREAD_ATTACH:
		result = sub_100065B0() != 0;
		break;
	case DLL_THREAD_DETACH:
		releaseTlsValue_10006560();
		result = TRUE;
		break;
	case DLL_PROCESS_DETACH:
		if (!lpReserved)
		{
			ReleaseDll_100064C0();			
		}
		result = TRUE;
		break;
	}
	return result;
}

BOOL InitDll_10006490(HMODULE hMod)
{
	
	g_hModule_1001FE5C = hMod;
	if (!g_DWORD_1001FE98)
	{
		if(!sub_10006410())
			return FALSE;
	}
	g_dwTlsIndex_1001F01C = TlsAlloc();
	if (sub_100065B0())
	{
		return TRUE;
	}
	return FALSE;
}

OVERLAPPED*  getTlsValue_10004D00(void)
{
	OVERLAPPED* result;

	HANDLE EventW; 

	result = (OVERLAPPED*)TlsGetValue(g_dwTlsIndex_1001F01C);
	if ( !result )
	{
		result = (OVERLAPPED*)HeapAlloc(g_hHeap_1001FE9C, 8, sizeof(OVERLAPPED));

		if ( result )
		{
			result->Internal = 0;
			result->InternalHigh = 0;
			result->Offset = 0;
			result->OffsetHigh = 0;
			result->hEvent = NULL;
			EventW = CreateEventW(0, 0, 0, 0);
			result->hEvent = EventW;
			if ( EventW )
			{
				TlsSetValue(g_dwTlsIndex_1001F01C, (LPVOID)result);
				return result;
			}
			else
			{
				HeapFree(g_hHeap_1001FE9C, 0, (LPVOID)result);
				return NULL;
			}
		}
	}
	return result;
}

DWORD sub_10006410()
{
	DWORD result; 

	g_hHeap_1001FE9C = HeapCreate(4, 0, 0);
	if ( g_hHeap_1001FE9C) 
	{
		g_hMutex_1001FE94 = CreateMutexW(0, 0, L"JIDA32_MUTEX_D3FBDCCE-066A-4658-BC5B-0E0B6F786417");
		if (g_hMutex_1001FE94)
		{
			InitializeCriticalSection(&g_CS_1001FE44);
			g_DWORD_1001FE98 = 1;
			result = 1;
		}
	}
	else
	{		
		if ( !g_DWORD_1001FE98 )
		{
			DeleteCriticalSection(&g_CS_1001FE44);
			if ( g_hMutex_1001FE94)
				CloseHandle(g_hMutex_1001FE94);
			if ( g_hHeap_1001FE9C )
				HeapDestroy(g_hHeap_1001FE9C);			
		}
		result = g_DWORD_1001FE98;
	}
	return result;
}
OVERLAPPED* sub_100065B0()
{
	DWORD *result;
	DWORD *pAlloc;
	HANDLE EventW;

	result = (PDWORD)TlsGetValue(g_dwTlsIndex_1001F01C);
	if ( !result )
	{
		pAlloc = (PDWORD)HeapAlloc(g_hHeap_1001FE9C, HEAP_ZERO_MEMORY, 0x14);
		result = pAlloc;
		if ( pAlloc )
		{
			memset(pAlloc, 0, 0x14);

			EventW = CreateEventW(0, 0, 0, 0);
			pAlloc[4] = (DWORD)EventW;
			if ( EventW )
			{
				TlsSetValue(g_dwTlsIndex_1001F01C, (LPVOID)pAlloc);
				return (LPOVERLAPPED)pAlloc;
			}
			else
			{
				HeapFree(g_hHeap_1001FE9C, 0, pAlloc);
				return 0;
			}
		}
	}
	return (LPOVERLAPPED)result;
}
DWORD releaseTlsValue_10006560()
{
	LPVOID result; 

	result = TlsGetValue(g_dwTlsIndex_1001F01C);
	PDWORD pdwMem = (PDWORD)result;	
	if ( result )
	{
		if ( pdwMem[4] )
			CloseHandle((HANDLE)pdwMem[4]);
		HeapFree(g_hHeap_1001FE9C, 0, result);
		return TlsSetValue(g_dwTlsIndex_1001F01C, 0);
	}
	return (DWORD)result;
}

HANDLE ReleaseDll_100064C0()
{
	HANDLE *Value; 
	HANDLE result; 
	if (g_dword_1001FE8C )
	{
		while ( g_dword_1001FE8C )
		{
			sub_10004680();
		}	
	}
	Value = (HANDLE *)TlsGetValue(g_dwTlsIndex_1001F01C);	
	if ( Value )
	{
		if ( Value[4] )
			CloseHandle(Value[4]);
		HeapFree(g_hHeap_1001FE9C, 0, Value);
		TlsSetValue(g_dwTlsIndex_1001F01C, 0);
	}
	TlsFree(g_dwTlsIndex_1001F01C);
	DeleteCriticalSection(&g_CS_1001FE44);
	if ( g_hMutex_1001FE94 )
		CloseHandle(g_hMutex_1001FE94);
	result = g_hHeap_1001FE9C;
	if ( g_hHeap_1001FE9C )
		return (HANDLE)HeapDestroy(g_hHeap_1001FE9C);
	return result;
}

int sub_10004680()
{
	DWORD dwRet; 
	dwRet = 0;
	WaitForSingleObject(g_hMutex_1001FE94, INFINITE);
	if ( g_dword_1001FE8C >= 1 ) 
	{
		g_dword_1001FE8C--;
		dwRet = 1;
		if (!g_dword_1001FE8C)
		{
			sub_10008160();
			/////////////////////////////////////////////////////////////////////////
			if(g_pGpioDefaultProxy_1001FE40)
			{
				delete g_pGpioDefaultProxy_1001FE40;
			}
			if ( g_pCSmbus_Def_1001FEA0 )
			{
				((CSmbus_Def*)g_pCSmbus_Def_1001FEA0)->sub_1000A820();

				if ( g_pCSmbus_Def_1001FEA0 ){
					delete ((CSmbus_Def*)g_pCSmbus_Def_1001FEA0);
				}
				g_pCSmbus_Def_1001FEA0 = NULL;
			}
			//////////////////////////////////////////////////////////////////////////
			sub_10007790();
			CloseHandle(g_hFile);
			g_hFile = INVALID_HANDLE_VALUE;
			if ( !g_dword_1001FE90 )
				sub_10006B30();
		}
	}
	ReleaseMutex(g_hMutex_1001FE94);
	return dwRet;
}
void sub_10008160()
{
	int i;

	for ( i = 0; i < 8; ++i )
	{
		PDWORD pClassAddr = g_pClassList_1001FE60[i];
		if ( pClassAddr )
		{
			delete (CSensor*)pClassAddr;
			g_pClassList_1001FE60[i] = NULL;
		}
	}
	if ( g_dword_1001FEB4[1] )
		HeapFree(g_hHeap_1001FE9C, 0, (LPVOID)g_dword_1001FEB4[1]);
	g_dword_1001FEB4[1] = 0;
	g_dword_1001FEB4[0] = 0;

}


void sub_10007790()
{
	
	
	if ( g_dword_1001FEE4 == 1 )
	{
		if ( LOWORD(g_dword_1001FED4) )
		{
			PDWORD p = (PDWORD)(g_lpMem_1001FED8) + 6;
			do
			{
				if ( p - 6 )
				{
					if ( *p )
						HeapFree(g_hHeap_1001FE9C, 0, (LPVOID)*p);
					*p = 0;
				}
				p += 12;
				--g_dword_1001FED4;
				
			}
			while ( LOWORD(g_dword_1001FED4) );
		}
// 		for ( i = 2; i < 4; ++i )
// 		{
// 			v2 = (void (__thiscall ***)(_DWORD, int))dword_1001FED4[i];
// 			if ( v2 )
// 			{
// 				(**v2)(v2, 1);
// 				dword_1001FED4[i] = 0;
// 			}
// 		}
		
		if ( g_lpMem_1001FED8 )
			HeapFree(g_hHeap_1001FE9C, 0, g_lpMem_1001FED8);
		g_lpMem_1001FED8 = 0;
		g_dword_1001FEE4 = 0;
	}

}
DWORD sub_10006B30()//ok
{
	SC_HANDLE hManager; 
	SC_HANDLE hService; 
	DWORD LastError; 
	SERVICE_STATUS ServiceStatus; 

	hManager = OpenSCManagerW(0, 0, SC_MANAGER_CREATE_SERVICE);
	hService = OpenServiceW(hManager, L"KCPLD", SERVICE_ALL_ACCESS);
	if ( !hService )
		return GetLastError();
	if ( ControlService(hService, 1, &ServiceStatus) )
	{
		CloseServiceHandle(hService);
		return 0;
	}
	else
	{
		LastError = GetLastError();
		CloseServiceHandle(hService);
		return LastError;
	}
}
DWORD sub_100048E0(LPVOID lpOutBuffer)//ok
{
	DWORD LastError; 	DWORD result; 

	OVERLAPPED* lpOverlap; 

	LastError = 0;
	result = 87;
	lpOutBuffer = 0;
	if ( lpOutBuffer )
	{
		lpOverlap = (OVERLAPPED *)sub_100065B0();
		if ( !lpOverlap )
			return ERROR_NO_SYSTEM_RESOURCES;
		DeviceIoControl(g_hFile, 0xEA606000, 0, 0, lpOutBuffer, 6, 0, lpOverlap);
		if ( !GetOverlappedResult(g_hFile, lpOverlap, (LPDWORD)&lpOutBuffer, 1) )
		{
			LastError = GetLastError();
			if ( LastError == 0xE0000109 )
				return ERROR_TIMEOUT;
		}
		return LastError;
	}
	return result;
}

DWORD sub_10004550()
{

		BYTE bOutBuffer[8];
		DWORD ret = 0;
		WaitForSingleObject(g_hMutex_1001FE94, INFINITE);
		if(g_hFile)
		{
			if((ret = sub_10006AC0(&g_dword_1001FE90, L"KCPLD")) || (ret = sub_10006980(&g_hFile, (GUID*)g_ClassGuid_1001AA90))) 
			{ ReleaseMutex(g_hMutex_1001FE94);	return ret;}
			if((ret = sub_100048E0(bOutBuffer)))
			{
				CloseHandle(g_hFile);
				g_hFile = INVALID_HANDLE_VALUE;
				if(g_dword_1001FE90 ==0)
					sub_10006B30();
				ReleaseMutex(g_hMutex_1001FE94);
				return 1;
			}

			if(*(PWORD)bOutBuffer != 5)
			{
				sub_10006AA0();
				if(!g_dword_1001FE90)
				{
					sub_10006B30();

				}
				ReleaseMutex(g_hMutex_1001FE94);	return 0x0E0000120;
			}
			sub_10006D30();
			sub_10007490();
			sub_10008E40();
			sub_10006E90();
			g_pGpioDefaultProxy_1001FE40  = (CGpioDefaultProxy*)sub_10009DF0();
			sub_10007E20();

		}

		g_dword_1001FE8C++;
		ReleaseMutex(g_hMutex_1001FE94);
		return 0;
}

DWORD sub_10006AC0(DWORD* pdwIn, LPCWSTR lpServiceName)
{
	SC_HANDLE hManager; 
	SC_HANDLE hService;
	DWORD LastError; 

	hManager = OpenSCManagerW(0, 0, 2);
	hService = OpenServiceW(hManager, lpServiceName, SERVICE_ALL_ACCESS);
	if ( !hService )
		return GetLastError();
	if ( StartServiceW(hService, 0, 0) )
	{
		*pdwIn = 1;
		CloseServiceHandle(hService);
		return 0;
	}
	else
	{
		LastError = GetLastError();
		if ( LastError == ERROR_SERVICE_ALREADY_RUNNING )
		{
			*pdwIn = 0;
			LastError = 0;
		}
		CloseServiceHandle(hService);
		return LastError;
	}
}
DWORD sub_10006980(HANDLE* pFileHandle, GUID* bGUID)
{
	DWORD LastError; 
	SP_DEVICE_INTERFACE_DETAIL_DATA * pDeviceData;
	DWORD RequiredSize; 
	DWORD MemberIndex; 
	SP_DEVICE_INTERFACE_DATA DeviceInterfaceData; 

	RequiredSize = 0;
	LastError = 1168;
	HDEVINFO hClassDevs = (HDEVINFO)SetupDiGetClassDevs((LPGUID)bGUID, 0, 0, 0x12);
	if ( (HANDLE)hClassDevs == INVALID_HANDLE_VALUE)
		return LastError;
	MemberIndex = 0;
	DeviceInterfaceData.cbSize = 28;
	while ( !SetupDiEnumDeviceInterfaces(hClassDevs, 0, (LPGUID)bGUID, MemberIndex, &DeviceInterfaceData) )
	{
		if ( GetLastError() == 259 )
		{ SetupDiDestroyDeviceInfoList(hClassDevs); return GetLastError();}

		++MemberIndex;
	}
	do{
		SetupDiGetDeviceInterfaceDetailW(hClassDevs, &DeviceInterfaceData, 0, 0, &RequiredSize, 0);
		LastError = GetLastError();
		++MemberIndex;
	}
	while(LastError != ERROR_INSUFFICIENT_BUFFER);

	LastError = 8;
	pDeviceData = (SP_DEVICE_INTERFACE_DETAIL_DATA *)HeapAlloc(g_hHeap_1001FE9C, 8u, RequiredSize);

	if ( pDeviceData )
	{
		pDeviceData->cbSize = 6;
		SetupDiGetDeviceInterfaceDetailW(hClassDevs, &DeviceInterfaceData, pDeviceData, RequiredSize, &RequiredSize, 0);
		LastError = 110;
		HANDLE hFile = CreateFileW(pDeviceData->DevicePath, 0xC0000000, 3, 0, 3, 0x40000000, 0);
		if ( hFile != INVALID_HANDLE_VALUE )
		{
			LastError = 0;
			*pFileHandle = hFile;
		}
		HeapFree(g_hHeap_1001FE9C, 0, pDeviceData);
	}

	SetupDiDestroyDeviceInfoList(hClassDevs);
	return LastError;
}

DWORD sub_100048E0(PBYTE lpOutBuffer)
{
	DWORD LastError; 
	DWORD result; 
	OVERLAPPED* pOverLapped1; 	

	LastError = 0;
	result = 87;
	*(DWORD*)lpOutBuffer = NULL;
	if ( lpOutBuffer )
	{
		pOverLapped1 = (OVERLAPPED *)getTlsValue_10004D00();

		if ( !pOverLapped1 )
			return ERROR_NO_SYSTEM_RESOURCES;
		DeviceIoControl(g_hFile, 0xEA606000, 0, 0, (LPDWORD)lpOutBuffer, 6, 0, pOverLapped1);
		if ( !GetOverlappedResult(g_hFile, pOverLapped1, (LPDWORD)lpOutBuffer, 1) )
		{
			LastError = GetLastError();
			if ( LastError == 0xE0000109 )
				return ERROR_TIMEOUT;
		}
		return LastError;
	}
	return result;
}

DWORD sub_10006AA0()
{
	CloseHandle(g_hFile);
	g_hFile = INVALID_HANDLE_VALUE;
	return 1;
}
DWORD sub_10006D30()
{
	if ( g_hMutex_1001FEB0 )
		return 1;
	g_hMutex_1001FEB0 = CreateMutexW(0, 0, L"KBSP_MUTEX_CE8C0FFA-D8B3-43e4-8F58-24AFB0E31F6A");
	return (g_hMutex_1001FEB0 != 0);
}

void sub_10007490()
{
	DWORD dwVal1 = 0, dwVal2 = 0, dwTemp1, dwCnt;
	int i = dwVal1;
	DWORD dwOffset;
	DWORD OutBuffer;
	DWORD NumberOfBytesTransferred;
	DWORD InBuffer;
	DWORD dwLastError = 0;
	if(g_dword_1001FEE4)//dword_1001FEE4
	{
		InBuffer = 5;
		NumberOfBytesTransferred = 0;
		OutBuffer = 0;
		OVERLAPPED* pRet = (OVERLAPPED* )sub_100065B0();
		if(pRet)
		{
			DeviceIoControl(g_hFile, 0xEA60E00C, &InBuffer, 4, &OutBuffer, 4, 0, pRet);
			if(!GetOverlappedResult(g_hFile, pRet, &NumberOfBytesTransferred, 1))
			{
				dwLastError = GetLastError();
				if ( dwLastError == 0xE0000109 )
					dwLastError = ERROR_TIMEOUT;
			}
		}
		else
			dwLastError = ERROR_NO_SYSTEM_RESOURCES;

		if(dwLastError == 0)
		{
			OutBuffer = NumberOfBytesTransferred;
			dwOffset = InBuffer-2;
			if(dwOffset==0 && g_DS_0[1] && g_DS_0[0] <= 0)
			{
			/*	dwVal2 = 1;//4*/
				dwVal1 = 0;
				do{
					dwTemp1 = *(PDWORD )(g_DS_0[1]+dwOffset+0x0C);
					if(dwTemp1)
					{
						dwTemp1 += dwOffset;
						*(PDWORD )(g_DS_0[1]+dwOffset+0x0C)= dwTemp1+g_DS_0[1]+8;
					}
					dwTemp1 = *(PDWORD )(g_DS_0[1]+dwOffset+0x14);
					if(dwTemp1)
					{
						dwTemp1 += dwOffset;
						*(PDWORD )(g_DS_0[1]+dwOffset+0x14)= dwTemp1+g_DS_0[1]+0x10;
					}
					dwTemp1 = *(PDWORD )(g_DS_0[1]+dwOffset+0x1C);
					if(dwTemp1)
					{
						dwTemp1 += dwOffset;
						*(PDWORD )(g_DS_0[1]+dwOffset+0x1C)= dwTemp1+g_DS_0[1]+0x18;

					}
					dwCnt = LOWORD(g_DS_0[0]);
					dwVal1++;
					dwOffset += 0x20;
				}while(dwVal1 >dwCnt);
			}
			OutBuffer = NumberOfBytesTransferred;
			dwLastError = ERROR_MORE_DATA;
		}


		if(dwLastError == ERROR_MORE_DATA)
		{
			PWORD pHeap = NULL;
			if(pHeap = (PWORD)HeapAlloc(g_hHeap_1001FE9C, HEAP_ZERO_MEMORY, OutBuffer))
			{
				sub_10004BC0((PDWORD )pHeap,5, (WORD)OutBuffer, 0);//sub_10004BC0

				g_lpMem_1001FED8 = HeapAlloc(g_hHeap_1001FE9C, HEAP_ZERO_MEMORY, sizeof(ControlDevice30)*pHeap[0]);

				PBYTE lpMem  = (PBYTE)g_lpMem_1001FED8;
				if(g_lpMem_1001FED8)
				{
					if(pHeap[0])
					{
						OutBuffer = (DWORD)((BYTE*)pHeap+4);
						do
						{
							DWORD temp = *(DWORD*)(OutBuffer+4);
							if(!g_pStorage_1001FEDC[temp])
							{
								if(temp !=0 )
								{
									if(temp == 1)

										g_pStorage_1001FEDC[1] = (CStorage*)new CCmos();

								}
								else
								{

									g_pStorage_1001FEDC[0] = (CStorage*)(new CEmbeddedEeprom());
									if(g_pStorage_1001FEDC[0])
									{
										((CEmbeddedEeprom*)(g_pStorage_1001FEDC[0]))->m_dw04 = (DWORD)INVALID_HANDLE_VALUE;
										((CEmbeddedEeprom*)(g_pStorage_1001FEDC[0]))->m_dw08 = 0;
									}
									else
										g_pStorage_1001FEDC[0] = NULL;


								}

								if(temp ==0) 
								{
									CEmbeddedEeprom* pEmbeddedEeprom = (CEmbeddedEeprom*)g_pStorage_1001FEDC[0];
									if(!pEmbeddedEeprom->sub_10007AA0()){//
										delete pEmbeddedEeprom;
										g_pStorage_1001FEDC[0] = NULL;
									}
								}
								else if(temp == 1) 
								{
									CCmos* pCmos = (CCmos*)g_pStorage_1001FEDC[1];
									if(!pCmos->sub_1000BEB0()){
										delete pCmos;
										g_pStorage_1001FEDC[1] = NULL;
									}
								}
							}

							if ( g_pStorage_1001FEDC[temp] )
							{
								if ( lpMem )
									sub_10006F60(lpMem, (DWORD)g_pStorage_1001FEDC[temp], (PDWORD )OutBuffer, (temp == 0));

								if ( sub_10006FA0((PControlDevice30)lpMem) )
								{
									g_dword_1001FED4++;
									(PBYTE)lpMem += sizeof(ControlDevice30);
								}
								else if ( lpMem )
								{
									sub_10007770(lpMem);
								}
							}
							
							OutBuffer += 20;
							++i;

						}while(i <pHeap[0]);
					}
					g_dword_1001FEE4 = 1;
				}
				
				HeapFree(g_hHeap_1001FE9C, 0, pHeap);
			}
		}
	}
}

BOOL sub_10008E40()
{

	if ( g_dword_1001FEA4 )
		return 1;
	HDEVINFO hDevInfo;
	if ( (hDevInfo = SetupDiGetClassDevsW(0, L"ACPI", 0, DIGCF_ALLCLASSES | DIGCF_PRESENT)) != INVALID_HANDLE_VALUE)
		sub_1000C8D0(hDevInfo);//sub_1000C8D0
	return 0;

}
int sub_10006D90(PDWORD  pdwBuff1, PDWORD  pdwBuff2)
{
	DWORD i; 
	i = 4;
	while ( pdwBuff2[i] == pdwBuff1[i] )
	{
		i--;

		if ( i < 1 )
			return 1;
	}
	return 0;
}
BOOL sub_10006E90()
{

	DWORD dwTemp[4]; 
	if ( g_pCSmbus_Def_1001FEA0 || sub_10004BC0(dwTemp, 0, 0x10, 0) )
		return (g_pCSmbus_Def_1001FEA0 != 0);
	int i = 0;
	while(1) 
	{
		if ( !sub_10006D90((DWORD*)&g_dword_1001F03C[i], dwTemp) )//sub_10006D90
		{
			LPFnP_V pFunc = (LPFnP_V)g_dword_1001F03C[i].pFunc;
			CSmbus_Def* pClass = (CSmbus_Def*)pFunc();// call class contructor
			if(pClass)
			{
				if(((CSmbus_Def*)pClass)->sub_1000A780())// func_off = 4
				{
					g_pCSmbus_Def_1001FEA0 = (DWORD)pClass; return TRUE;
				}
				delete pClass;
			}

		}
		i++;
		if(i >=1)
			return (g_pCSmbus_Def_1001FEA0 != 0);

	}

	return (g_pCSmbus_Def_1001FEA0 != 0);
}

LPVOID sub_10009DF0()
{
	int i; 
	PDWORD  pdwTemp; 
	DWORD dwOffset; 
	DWORD dwBuff[9];

	if ( sub_10004BC0(dwBuff, 3, 0x24, 0) )
		return 0;
	i = 0;
	pdwTemp = &g_dword_1001F03C[1].unk08;//g_dword_1001A038;
	dwOffset = 0;
	while ( (*(pdwTemp-2) != dwBuff[1]) || (*(pdwTemp - 1) != dwBuff[2]) || (pdwTemp[0]!= dwBuff[3]) || (pdwTemp[1] != dwBuff[4]) )
	{
		dwOffset += 20;
		++i;
		pdwTemp += 5;
		if ( dwOffset >= 30 )
			return 0;
	}
	LPFnD_V pFunc = (LPFnD_V)g_dword_1001F03C[i].pFunc;// create a CGpioDefaultProxy;

	return (LPVOID)pFunc();
}

SHORT *sub_10007E20()
{
	PDWORD pdwMem; 
	int j; 
	SHORT dwRet; 
	SHORT *result; 
	DWORD dwAddr; 
	int idx;

	dwAddr = 0;
	g_dword_1001FEB4[0] = 0;
	g_dword_1001FEB4[2] = 0;
	g_dword_1001FEB4[3] = 0;
	g_dword_1001FEB4[4] = 0;
	g_dword_1001FEB4[5] = 0;
	g_dword_1001FEB4[6] = 0;
	g_dword_1001FEB4[7] = 0;
	int i = 0;
	if(sub_10004BC0(0, 2, 0, (WORD*)&dwAddr) == ERROR_INSUFFICIENT_BUFFER)
	{
		pdwMem = (PDWORD )HeapAlloc(g_hHeap_1001FE9C, 8, (WORD)dwAddr);
		if(pdwMem)
		{
			sub_10004BC0(pdwMem, 2, (WORD)dwAddr, 0);
			if(pdwMem[0] )
			{
				DWORD dwOffset = 0;

				do 
				{
					if(i >=8) break;
					idx = *(DWORD*)(dwOffset + pdwMem[1]);
					if(idx <7)
					{
						LPFnP_D pFnClassCreator = (LPFnP_D)CSensorIoCreators_1001AE20[idx];
						DWORD dwTmp = *(BYTE*)(pdwMem[1] + dwOffset + 4);
						g_pClassList_1001FE60[i] = (PDWORD )pFnClassCreator(dwTmp);
						if(g_pClassList_1001FE60[i])
						{
							if(!sub_10008120((DWORD)g_pClassList_1001FE60[i], idx)) // initialize classes
							{ 								
								delete (CSensor*)g_pClassList_1001FE60[i];
								g_pClassList_1001FE60[i] = NULL;
							}
						}
						i++;
					}
					dwOffset += 0x20;

				}while ( i < (WORD)pdwMem[0] );

			}

		}
	}
	if(i < 8)
	{

		CW83627DHGP* pW83627DHGP = (CW83627DHGP*)sub_1000AC60(0);//sub_1000AC60
		CSuperIo* pSuperIo = dynamic_cast<CSuperIo*>((CSensor*)pW83627DHGP);
		g_pClassList_1001FE60[i] = (PDWORD )pSuperIo;

	}

	j = 0;
	if ( g_pClassList_1001FE60[i] )
	{
		dwAddr = 0;
		do
		{
			dwRet = (SHORT)((CW83627DHGP*)g_pClassList_1001FE60[i])->sub_100081C0();
			dwAddr = dwRet + dwAddr;
			++j;
		}
		while ( j < 3 );
		g_dword_1001FEB4[0] += dwAddr;
		if ( dwAddr == 0 )
		{
			delete g_pClassList_1001FE60[i];
			g_pClassList_1001FE60[i] = 0;
		}
	}
	result = sub_10007FD0((PDWORD )pdwMem, idx);//sub_10006C80
	if ( pdwMem )
		return (SHORT *)HeapFree(g_hHeap_1001FE9C, 0, pdwMem);
	return result;
}

LPVOID sub_10006F60(PBYTE pbAddr, DWORD dwClassAddr, PDWORD  pdwOutBuff, DWORD dwFlag)
{
	PControlDevice30 pCtrlDev = (PControlDevice30)pbAddr;
	pCtrlDev->dwOutBuffer[0] = pdwOutBuff[0];
	pCtrlDev->dwOutBuffer[1] = pdwOutBuff[1];
	pCtrlDev->dwOutBuffer[2] = pdwOutBuff[2];
	pCtrlDev->dwOutBuffer[3] = pdwOutBuff[3];
	pCtrlDev->dwOutBuffer[4] = pdwOutBuff[4];
	pCtrlDev->lpClass = (LPVOID)dwClassAddr;
	pCtrlDev->dwUnk18 = 0;
	pCtrlDev->dwUnk1C = 0;
	pCtrlDev->dwUnk20 = 0;
	pCtrlDev->dwUnk24 = 0;
	pCtrlDev->dwFlag = dwFlag;
	pCtrlDev->dwUnk2C = 0;

	return pbAddr;
}
BOOL sub_10006FA0(PControlDevice30 lpParam)
{
	PControlDevice30 pVal = (PControlDevice30)lpParam;
	DWORD dwVal1;
	DWORD dwBytes;
	CCmos* pCmos = NULL;	
	CEmbeddedEeprom* pEeprom=NULL;
	DWORD dwRet = 0;
	if(pVal->dwFlag == 0)
		pCmos = (CCmos*)pVal->lpClass;
	else 
		pEeprom = (CEmbeddedEeprom*)pVal->lpClass;

	if(!pVal->dwOutBuffer[4] && pVal->dwOutBuffer[3])
	{


		if(pVal->dwFlag == 0)
			dwRet = pCmos->sub_10007DB0(&dwBytes, &dwVal1);//14
		else 
			dwRet = pEeprom->sub_100078F0(&dwBytes, &dwVal1);//14

		if(dwRet)
		{
			LPVOID lpTemp1 = HeapAlloc(g_hHeap_1001FE9C, 8, dwBytes);
			PBYTE lpTemp2 = (PBYTE)lpTemp1 + dwBytes;
			if(lpTemp2)
			{

				if(pVal->dwFlag == 0)
					dwRet = pCmos->sub_10007D50(0, (BYTE*)lpTemp1, dwBytes);//0c
				else 
					dwRet = pEeprom->sub_100079F0(0, (BYTE*)lpTemp1, dwBytes);//0c
				if(dwRet)
				{
					PBYTE lpTemp3 = (PBYTE)lpTemp1 + (2*(*(BYTE*)((BYTE*)lpTemp1+4)));
					if(lpTemp3 < lpTemp2)
					{
						while ( *(WORD*)((PBYTE)lpTemp3 + 1) )
						{
							if ( *(PBYTE)lpTemp3 == 0xF0 && *(WORD*)((PBYTE)lpTemp3 + 3) == 0xAD2C && *(DWORD*)((PBYTE)lpTemp3 + 6) == 0x52535524 )
							{

								pVal->dwOutBuffer[4] = 2 * (WORD)((*(PWORD)((PBYTE)lpTemp3 + 1))<<8) - 14;;
								pVal->dwOutBuffer[3] = (PBYTE)lpTemp3 - (PBYTE)lpTemp1 + 14;
								pVal->dwUnk2C= (PBYTE)lpTemp3 - (PBYTE)lpTemp1 + 12;
								if ( !pVal->dwFlag )
								{

									pVal->dwUnk18 = (DWORD)HeapAlloc(g_hHeap_1001FE9C, 8, pVal->dwOutBuffer[4]);
									if ( pVal->dwUnk18 )
									{
										memcpy((void*)pVal->dwUnk18 ,(void*)(lpTemp3 + 14), pVal->dwOutBuffer[4]);
										*(WORD*)((PBYTE)lpParam + 28) = (*((PWORD)lpTemp3 + 6))<<8;
										*(DWORD*)((PBYTE)lpParam + 32) = (*(PBYTE)lpTemp3) & 1;
									}
								}
								break;
							}
							DWORD val = (2 * ((*(PWORD)((PBYTE)lpTemp3 + 1))<<8));
							(PBYTE)lpTemp3 += val;
							if ( lpTemp3 >= lpTemp2 )
								break;
						}
					}

					HeapFree(g_hHeap_1001FE9C, 0, lpTemp1);
				}

			}
		}
	}

	if ( !pVal->dwOutBuffer[4] )
		return 0;
	if ( pVal->dwFlag )
	{
		pVal->dwUnk18 =(DWORD) HeapAlloc(g_hHeap_1001FE9C, 8, pVal->dwOutBuffer[4]);
		if ( pVal->dwUnk18 )
		{

			if(pVal->dwFlag == 0)
				dwRet = pCmos->sub_10007D50((BYTE)pVal->dwOutBuffer[3], (PBYTE)pVal->dwUnk18, pVal->dwOutBuffer[4]);
			else 
				dwRet = pEeprom->sub_100079F0((BYTE)pVal->dwOutBuffer[3], (PBYTE)pVal->dwUnk18, pVal->dwOutBuffer[4]);
			if(!dwRet)
			{ 
				pVal->dwOutBuffer[4] = 0; pVal->dwOutBuffer[3] = 0;
			}

		}
	}
	return 1;
}

LPVOID		sub_10007770(LPVOID lpMem)
{
	PDWORD  pTemp = (PDWORD )lpMem;
	if (pTemp[6])
		HeapFree(g_hHeap_1001FE9C, 0, (LPVOID)pTemp[6]);
	pTemp[6] = 0;
	return lpMem;
}

DWORD sub_10004BC0(PDWORD  pdwIn, DWORD dwFlag, WORD wSize, PWORD dwVal4)
{
	PDWORD  pdwTemp; 

	OVERLAPPED *pOverLapped6; 
	DWORD LastError; 
	int nOffset = 0; 
	DWORD i = 0; 

	DWORD dwRetVal; 
	DWORD dwRetError; 
	DWORD NumberOfBytesTransferred; 
	DWORD dwVal14; 
	DWORD nOutBufferSize; 
	NumberOfBytesTransferred = 0;
	dwVal14 = 0;
	if ( pdwIn && wSize >= 4 )
	{
		pdwTemp = pdwIn;
		nOutBufferSize = wSize;
	}
	else
	{
		pdwTemp = (PDWORD )&dwVal14;
		nOutBufferSize = 4;
	}

	dwRetError = 0;
	pOverLapped6 = (OVERLAPPED *)sub_100065B0();

	if ( pOverLapped6 )
	{
		DeviceIoControl(g_hFile, 0xEA60E00C, &dwFlag, 4, pdwTemp, nOutBufferSize, 0, pOverLapped6);
		if ( !GetOverlappedResult(g_hFile, pOverLapped6, &NumberOfBytesTransferred, 1) )
		{
			LastError = GetLastError();
			if ( LastError == 0xE0000109 )
				dwRetError = ERROR_TIMEOUT;
		}
	}
	else
	{
		dwRetError = ERROR_NO_SYSTEM_RESOURCES;
	}
	LastError = dwRetError;

	if ( LastError )
	{
		if ( LastError == ERROR_MORE_DATA )
		{
			dwRetVal = *pdwTemp;
			LastError = ERROR_INSUFFICIENT_BUFFER;
		}
		else
		{

			*(WORD*)&dwRetVal = (WORD)dwVal14;
		}

	}
	else
	{

		if ( wSize >= NumberOfBytesTransferred && pdwIn )
		{
			if ( pdwTemp == (DWORD*)&dwVal14 )
				memcpy_s(pdwIn, wSize, pdwTemp, NumberOfBytesTransferred);


		}
		else
		{
			LastError = ERROR_INSUFFICIENT_BUFFER;
		}

		if ( dwFlag == 1 )
		{
			*pdwIn += (int)pdwIn;

		}
		else if ( dwFlag == 2 && pdwIn[1] && *(WORD*)pdwIn)
		{

			do
			{
				DWORD dwFlag = 0;
				dwFlag = *(DWORD*)(nOffset + pdwIn[1] + 12);
				if ( dwFlag )
					*(DWORD*)(nOffset + pdwIn[1] + 12) = nOffset + dwFlag + pdwIn[1] + 8;

				dwFlag = *(DWORD*)(nOffset + pdwIn[1] + 20);
				if ( dwFlag )
					*(DWORD*)(nOffset + pdwIn[1] + 20) = nOffset + dwFlag + pdwIn[1] + 16;

				dwFlag = *(PDWORD )(nOffset + pdwIn[1] + 28);
				if ( dwFlag )
					*(DWORD*)(nOffset + pdwIn[1] + 28) = nOffset + dwFlag + pdwIn[1] + 24;
				++i;
				nOffset += 32;
			}
			while ( i < *(WORD*)pdwIn );
		}

	}

	if ( dwVal4 )
		*dwVal4 =(WORD)NumberOfBytesTransferred;
	return LastError;
}

BOOL sub_10008120(DWORD dwArg1, int iClassType)
{
	WORD dwVal; 
	int i; 
	WORD wRet; 
	dwVal = 0;
	switch(iClassType)
	{
	case 0:
		{
			CAdt7475* pAdt7475 = (CAdt7475*)dwArg1;
			for ( i = 0; i < 3; ++i )
			{

				wRet =(WORD)pAdt7475->sub_100081C0(i);
				dwVal += wRet;
			}
		}

		break;
	case 1:
		{
			CAdt7490* pAdt7490 = (CAdt7490*)dwArg1;
			for ( i = 0; i < 3; ++i )
			{

				wRet =(WORD)pAdt7490->sub_100081C0(i);
				dwVal += wRet;
			}
		}
		break;
	case 2:
		{
			CW83L771Ax* pW83L771Ax = (CW83L771Ax*)dwArg1;
			for ( i = 0; i < 3; ++i )
			{

				wRet =(WORD)pW83L771Ax->sub_100081C0(i);
				dwVal += wRet;
			}
		}
		break;
	case 3:
		{
			CNCT7802* pNCT7802 = (CNCT7802*)dwArg1;
			for ( i = 0; i < 3; ++i )
			{

				wRet =(WORD)pNCT7802->sub_100081C0(i);
				dwVal += wRet;
			}
		}
		break;
	case 4:
		{
			CAmdBrazos* pAmdBrazos = (CAmdBrazos*)dwArg1;
			for ( i = 0; i < 3; ++i )
			{

				wRet =(WORD)pAmdBrazos->sub_100081C0(i);
				dwVal += wRet;
			}
		}
		break;
	case 5:
	case 6:
		{
			CSuperIo* pSuperIo = (CSuperIo*)dwArg1;
			for ( i = 0; i < 3; ++i )
			{

				pSuperIo->purecall();
				dwVal = 0;
				//dwVal += wRet;
			}
		}
		break;
	}

	g_dword_1001FEB4[0] += dwVal;
	return dwVal != 0;

}

DWORD sub_100047D0(BYTE InBuffer, LPVOID lpOutBuffer)
{
	OVERLAPPED *pOverlapped; 
	DWORD result; 
	DWORD NumberOfBytesTransferred; 
	NumberOfBytesTransferred = 0;
	pOverlapped = (OVERLAPPED *)sub_100065B0();
	if ( !pOverlapped )
		return ERROR_NO_SYSTEM_RESOURCES;
	DeviceIoControl(g_hFile, 0xEA60E034, &InBuffer, 2, lpOutBuffer, 4, 0, pOverlapped);
	if ( GetOverlappedResult(g_hFile, pOverlapped, &NumberOfBytesTransferred, 1) )
		return 0;
	result = GetLastError();
	if ( result == 0xE0000109 )
		return ERROR_TIMEOUT;
	return result;
}

DWORD sub_1000AC60(WORD wArg1)
{
	int i; 
	DWORD result; 
	DWORD j; 
	DWORD OutBuffer;
	DWORD InBuffer; 

	DWORD NumberOfBytesTransferred; 
	DWORD dwTmp3; 
	i = 0;
	while ( g_dword_1001FEA8[i] )
	{

		sub_10004750(g_byte_1001AE1C[i], 135);
		sub_10004750(g_byte_1001AE1C[i], 135);
		sub_10004750(g_byte_1001AE1C[i], 32);

		OutBuffer = -1;
		InBuffer = (BYTE)g_byte_1001AE1C[i] + 1;
		sub_100047D0((BYTE)InBuffer, &OutBuffer);
		sub_10004750(g_byte_1001AE1C[i], 33);
		InBuffer = -1;
		NumberOfBytesTransferred = (BYTE)g_byte_1001AE1C[i] + 1;
		dwTmp3 = 0;
		sub_100047D0((BYTE)g_byte_1001AE1C[i] + 1, &InBuffer);
		result = sub_10004750((BYTE)g_byte_1001AE1C[i], 170);

		if((BYTE)OutBuffer != 0xFF)
		{
			j = 0;
			do
			{
				result = (BYTE)g_byte_1001AE1C[i];
				result =(DWORD) sub_1000CC50((SHORT)result , (BYTE)OutBuffer, (BYTE)InBuffer, wArg1!=(WORD)result);
				if ( result )
				{
					g_dword_1001FEA8[i] = 1;
					return result;
				}
				j += 4;
				
			}while(j<4);
		}
		if ( ++i >= 2 )
			return 0;
	}
	return result;
}

LPVOID sub_1000CC50(SHORT wArg1, BYTE bArg2, BYTE bArg3, DWORD dwArg4)
{

	CW83627DHGP* pW83627DHGP;
	if ( bArg2 == (char)0xB0 )
	{
		if ( (bArg3 & 0xF0) == 0x70 )
		{

			pW83627DHGP = new CW83627DHGP();
			if ( !pW83627DHGP )
				return 0;
			createClasssW83627DHGP_1000CD00(wArg1, pW83627DHGP, dwArg4);
			if(!pW83627DHGP->sub_1000CDF0())
			{
				delete pW83627DHGP;
				return 0;
			}
			return (LPVOID)pW83627DHGP;
		}
		else return 0;

	}
	if ( bArg2 != 82 )
		return 0;

	pW83627DHGP = new CW83627DHGP();

	if ( !pW83627DHGP )
		return 0;
	createClasssW83627DHGP_1000CD00(wArg1, pW83627DHGP, dwArg4);
	if(!pW83627DHGP->sub_1000CDF0())
	{
		delete pW83627DHGP;
		return 0;
	}
	return (LPVOID)pW83627DHGP;


}
LPVOID createClasssW83627DHGP_1000CD00(SHORT wArg1, CW83627DHGP* pW83627DHGP, DWORD dwArg3)
{

	pW83627DHGP->m_w08 = wArg1;
	*(WORD *)(pW83627DHGP + 0x32) = 0;
	pW83627DHGP->m_w32 = 0;
	pW83627DHGP->m_w2A = 0;
	pW83627DHGP->m_w22 = 0;
	pW83627DHGP->m_pby24 = 0;
	pW83627DHGP->m_by28 = 0;
	pW83627DHGP->m_pby2C = NULL;
	pW83627DHGP->m_by30 = 0;
	pW83627DHGP->m_pby34 = NULL;
	pW83627DHGP->m_by38 = 0;
	pW83627DHGP->m_w3A = 0;
	pW83627DHGP->m_dw3C = dwArg3;
	InitializeCriticalSection(&pW83627DHGP->m_cs40);
	pW83627DHGP->m_pdw60 = 0;
	pW83627DHGP->m_pWPARAM64 = 0;
	return (LPVOID)pW83627DHGP;
}

SHORT* sub_10007FD0(PDWORD  pdwArg1, int iClassType)
{
	PWORD lpMem; 
	PWORD pdwTmp1; 
	int j; 
	int k; 
	int i; 
	WORD dwRet; 
	WORD wTmp2; 
	WORD ii; 
	PDWORD pdwTmp2; 
	PWORD pwTmp3; 

	lpMem = (PWORD)HeapAlloc(g_hHeap_1001FE9C, 8, 20 * (WORD)g_dword_1001FEB4[0]);

	g_dword_1001FEB4[1] =(DWORD)lpMem;
	if ( lpMem )
	{
		pdwTmp1 = lpMem;
		j = 0;
		pwTmp3 = (PWORD)g_dword_1001FEB4;
		do
		{
			k = 0;
			g_dword_1001FEB4[3] = (DWORD)lpMem;
			i = 0;
			do
			{
				if ( g_pClassList_1001FE60[i] )
				{

					switch(iClassType)
					{
					case 0:
						{
							CAdt7475* pAdt7475 = (CAdt7475*)g_pClassList_1001FE60[i];
							pAdt7475->sub_1000C590();//c
							dwRet = (WORD)pAdt7475->sub_100081C0(j);//10
						}

						break;
					case 1:
						{
							CAdt7490* pAdt7490 = (CAdt7490*)g_pClassList_1001FE60[i];
							pAdt7490->sub_1000BEB0();
							dwRet = (WORD)pAdt7490->sub_100081C0(j);
						}
						break;
					case 2:
						{
							CW83L771Ax* pW83L771Ax = (CW83L771Ax*)g_pClassList_1001FE60[i];
							pW83L771Ax->sub_1000B190();
							dwRet = (WORD)pW83L771Ax->sub_100081C0(j);
						}
						break;
					case 3:
						{
							CNCT7802* pNCT7802 = (CNCT7802*)g_pClassList_1001FE60[i];
							pNCT7802->sub_1000B190();
							dwRet = (WORD)pNCT7802->sub_100081C0(j);
						}
						break;
					case 4:
						{
							CAmdBrazos* pAmdBrazos = (CAmdBrazos*)g_pClassList_1001FE60[i];
							pAmdBrazos->sub_1000B290();
							dwRet = (WORD)pAmdBrazos->sub_100081C0(j);

						}
						break;
					case 5:
					case 6:
						{
							CSuperIo* pSuperIo = (CSuperIo*)g_pClassList_1001FE60[i];
							pSuperIo->purecall();
							//pSuperIo->purecall(j);
							dwRet = 0;

						}
						break;
					}

					wTmp2 = 0;

					if ( pdwArg1 && k < *(WORD*)pdwArg1 )
					{

						wTmp2 = *(PWORD)((pdwArg1[1]+ 8*(j + 4 * k)) + 8);
						pdwTmp2 = *(DWORD **)((pdwArg1[1]+ 8*(j + 4 * k)) + 12);
					}
					else
					{
						pdwTmp2 = 0;
					}
					ii = 0;
					if ( dwRet )
					{
						do
						{
							if ( !pdwTmp2 || pdwTmp2[0] )
							{
								DWORD dwVal1 = 0, dwVal2 = 0;
								if ( pdwTmp1 )
								{
									if ( ii >= wTmp2 )
									{  dwVal1 = 1000, dwVal2 = g_dword_1001AE3C[j];}
									else
									{	dwVal1 = pdwTmp2[1],dwVal2 = pdwTmp2[0];}

									*(PDWORD )pdwTmp1 = (DWORD)g_pClassList_1001FE60[i];
									*((PDWORD )pdwTmp1 + 1) = dwVal2;
									*((PDWORD )pdwTmp1 + 2) = j;
									*(WORD*)((PDWORD )pdwTmp1 + 3) = (WORD)dwVal1;
									*((PDWORD )pdwTmp1 + 4) = dwVal1;
								}
								pdwTmp1 += 10;
								pwTmp3[2]++;

							}
							++ii;
							//v10 += 2;
						}
						while ( ii < dwRet );

					}
				}
				++i;
				++k;
			}
			while ( i != 8 );
			lpMem = (PWORD)g_dword_1001FEB4[2];
			++j;

			pwTmp3 += 4;
		}
		while ( (int)pwTmp3 < (int)g_dword_1001FEB4[6] );
	}
	return (SHORT*)lpMem;
}


//sub_1000CA00

DWORD sub_1000C6B0(wchar_t *Source, void *a2)//sub_1000C6B0
{
	DWORD result; 
	size_t nLen; 
	DWORD dwOut; 

	result = 87;
	dwOut = 0;
	if ( Source )
	{
		nLen = wcsnlen(Source, 0x104);
		return sub_10006910(g_hFile, 0xEA60E184, Source, 2 * nLen + 2, a2, 4, &dwOut);//sub_10006910
	}
	return result;
}
DWORD sub_10006910(	void *a1, 
				   DWORD dwIoControlCode,	
				   void *lpInBuffer,	
				   DWORD nInBufferSize,
				   void *lpOutBuffer,
				   DWORD nOutBufferSize, 
				   PDWORD  lpNumberOfBytesTransferred)
{
	OVERLAPPED *pOverLapped; 
	DWORD result; 

	pOverLapped = (OVERLAPPED *)sub_100065B0();

	if ( !pOverLapped )
		return ERROR_NO_SYSTEM_RESOURCES;
	DeviceIoControl(a1, dwIoControlCode, lpInBuffer, nInBufferSize, lpOutBuffer, nOutBufferSize, 0, pOverLapped);
	if ( GetOverlappedResult(a1, pOverLapped, lpNumberOfBytesTransferred, 1) )
		return 0;
	result = GetLastError();
	if ( result == 0xE0000109 )
		return ERROR_TIMEOUT;
	return result;
}
int sub_10005430(DWORD dwArg1, LPVOID lpOutBuffer)
{
	DWORD LastError; 
	BYTE byTmp1; 
	OVERLAPPED *pOverlapped; 
	int result; 
	DWORD NumberOfBytesTransferred; 
	DWORD InBuffer[6]; 
	LastError = 0;
	byTmp1 = 0;
	NumberOfBytesTransferred = 0;
	switch ( dwArg1 )
	{
	case 8:
	case 9:
	case 10:
	case 11:
		dwArg1 = 1;
		break;
	case 17:
	case 18:
	case 19:
		byTmp1 = (BYTE)(dwArg1 - 16);
		dwArg1 = 0;
		break;
	default:
		break;
	}
	InBuffer[0] = dwArg1;
	InBuffer[3] = 0;
	pOverlapped = (OVERLAPPED *)sub_100065B0();
	if ( pOverlapped )
	{
		DeviceIoControl(g_hFile, 0xEA60E054, InBuffer, 0x18, lpOutBuffer, 8, 0, pOverlapped);
		if ( !GetOverlappedResult(g_hFile, pOverlapped, &NumberOfBytesTransferred, 1) )
		{
			LastError = GetLastError();
			if ( LastError == 0xE0000109 )
				LastError = ERROR_TIMEOUT;
		}
	}
	else
	{
		LastError = ERROR_NO_SYSTEM_RESOURCES;
	}
	if ( LastError )
		return LastError;
	result = 1168;
	if ( byTmp1 < *((BYTE *)lpOutBuffer + 4) )
		return LastError;
	return result;
}

int sub_10004960(DWORD *pdwArg1)
{
	int result; 
	DWORD dwRet; 
	PDWORD pdwMem; 
	pdwMem = NULL;
	result = sub_100085C0(pdwMem, 161);
	if ( !result )
	{
		if ( pdwMem[4] == -1 && pdwMem[5] == -1 )
		{
			dwRet = 50;
		}
		else
		{
			*pdwArg1 = pdwMem[4];
			dwRet = 0;
		}
		if ( pdwMem )
			HeapFree(g_hHeap_1001FE9C, 0, pdwMem);
		return dwRet;
	}
	return result;
}

int sub_100085C0(DWORD *pdwArg1, BYTE byArg2)
{
	int result; 
	void *lpMem; 
	DWORD dwRet3; 
	DWORD dwRet1; 
	DWORD dwRet2; 

	dwRet1 = 0;
	dwRet2 = 0;
	result = 87;
	if ( pdwArg1 )
	{
		*pdwArg1 = 0;
		result = sub_10006BA0(byArg2,0, 0, &dwRet1);
		if ( result == 122 )
		{
			lpMem = HeapAlloc(g_hHeap_1001FE9C, 8, (WORD)dwRet1);
			if ( lpMem )
			{
				sub_10006BA0(byArg2, (PDWORD)lpMem, (WORD)dwRet1, &dwRet1);
				dwRet3 = sub_10008540(dwRet1, 0, (PBYTE)lpMem, 0, (PWORD)&dwRet2);
				if ( dwRet3 == 122 )
				{
					dwRet3 = 8;
					*pdwArg1 = (DWORD)HeapAlloc(g_hHeap_1001FE9C, 8,(WORD)dwRet2);
					if ( *pdwArg1 )
						dwRet3 = sub_10008540(dwRet1, (PDWORD)*pdwArg1, (PBYTE)lpMem, (WORD)dwRet2, 0);
				}
				HeapFree(g_hHeap_1001FE9C, 0, lpMem);
				return dwRet3;
			}
			else
			{
				return 8;
			}
		}
	}
	return result;
}

int sub_10006BA0(char bParam1, PDWORD  pdwParam2, WORD wParam3, PDWORD pdwRetVal)
{
	PDWORD p_Source; 

	OVERLAPPED *pOverLapped1; 

	DWORD LastError; 
	int nRetCode; 
	int nTmp1; 
	char InBuffer[4]; 
	DWORD dwErrCode; 
	int Source; 
	DWORD NumberOfBytesTransferred;
	DWORD nOutBufferSize; 
	int nTmp2; 

	NumberOfBytesTransferred = 0;
	Source = 0;
	nTmp2 = 0;
	InBuffer[0] = bParam1;
	InBuffer[1] = 0;
	if ( pdwParam2 && wParam3 >= 4)
	{
		p_Source = pdwParam2;
		nOutBufferSize = wParam3;
		nTmp2 = *pdwParam2;
	}
	else
	{
		p_Source = (PDWORD )&Source;
		nOutBufferSize = 4;
	}
	dwErrCode = 0;
	pOverLapped1 = (OVERLAPPED *)sub_100065B0();

	if ( pOverLapped1 )
	{
		DeviceIoControl(g_hFile, 0xEA606020, InBuffer, 2, p_Source, nOutBufferSize, 0, pOverLapped1);
		if ( !GetOverlappedResult(g_hFile, pOverLapped1, &NumberOfBytesTransferred, 1) )
		{
			LastError = GetLastError();
			if ( LastError == 0xE0000109 )
			{	
				dwErrCode = ERROR_TIMEOUT;
			}
		}
	}
	else
	{
		dwErrCode = ERROR_NO_SYSTEM_RESOURCES;
	}
	LastError = dwErrCode;

	nRetCode = LastError;
	if ( LastError )
	{
		if ( LastError == ERROR_MORE_DATA )
		{
			nTmp1 = *p_Source;
			nRetCode = ERROR_INSUFFICIENT_BUFFER;
			if ( p_Source == pdwParam2 )
				*pdwParam2 = nTmp2;
		}
		else
		{
			nTmp1 = Source;
		}
	}
	else
	{
		if ( wParam3 >= NumberOfBytesTransferred && pdwParam2 )
		{
			if ( p_Source == (PDWORD )&Source )
			{
				memcpy_s(pdwParam2, wParam3, &Source, NumberOfBytesTransferred);
				nTmp1 = NumberOfBytesTransferred;

			}
		}
		else
		{
			nRetCode = ERROR_INSUFFICIENT_BUFFER;
		}
		nTmp1 = NumberOfBytesTransferred;
	}

	if ( pdwRetVal )
		*pdwRetVal = (WORD)nTmp1;
	return nRetCode;
}

int sub_10008540( int nVal,	 PDWORD pdwBuff1, PBYTE pbMem, WORD wSize, PWORD pdwRet)
{
	int result; 
	WORD wRetVal; 

	result = 87;
	if ( pbMem && nVal )
	{
		wRetVal = sub_10008C10(pbMem, pbMem + nVal) + 72;//sub_10008C10
		result = ERROR_INSUFFICIENT_BUFFER;
		if ( pdwBuff1 && wSize >= wRetVal )
		{
			memset(pdwBuff1, 0, wSize);
			*pdwBuff1 = wRetVal;
			*((BYTE *)pdwBuff1 + 4) = *(BYTE *)pbMem;
			*((BYTE *)pdwBuff1 + 5) = *(BYTE *)(pbMem + 1);
			*((PWORD)pdwBuff1 + 3) = *(PWORD)(pbMem + 2);
			result = sub_100083F0((PBYTE)pdwBuff1, (BYTE *)pbMem) != 1 ? 0x646 : 0;//sub_100083F0
		}
		if ( pdwRet )
			*pdwRet = wRetVal;
	}
	return result;
}
int sub_10008C10(PBYTE pbBuff1, PBYTE pbBuff2)
{
	BYTE *pbTemp1; 
	int result; 
	PBYTE pbEnd;

	pbTemp1 = (BYTE *)(pbBuff1 + *(PBYTE)(pbBuff1 + 1));
	result = 0;
	pbEnd = pbBuff2 - 1;
	if ( *pbTemp1 || pbTemp1[1] )
	{
		for ( result = 1; pbTemp1 < pbEnd; ++result )
		{
			if ( !*pbTemp1 && !pbTemp1[1] )
				break;
			++pbTemp1;
		}
	}
	return result;
}

int sub_100083F0(BYTE * pbBuff1, BYTE *pbBuff2)
{
	int result; 

	switch ( *pbBuff2 )
	{
	case 0:
		result = sub_100086B0(pbBuff2, pbBuff1);//sub_100086B0
		break;
	case 1:
		result = sub_10008770(pbBuff1, pbBuff2);//sub_10008770
		break;
	case 2:
		result = sub_10008830(pbBuff1, pbBuff2);//sub_10008830
		break;
	case 4:
		result = sub_100088B0(pbBuff1, pbBuff2);//sub_100088B0
		break;
	case 0x11:
		result = sub_100089D0(pbBuff2, pbBuff1);//sub_100089D0
		break;
	case 0xA0:
		result = sub_10008A90(pbBuff2, pbBuff1);//sub_10008A90
		break;
	case 0xA1:
		result = sub_10008AE0(pbBuff2, pbBuff1);//sub_10008AE0
		break;
	case 0xA2:
		result = sub_10008B30(pbBuff1, pbBuff2);//sub_10008B30
		break;
	default:
		result = 0;
		break;
	}
	return result;
}

int  sub_10008B30(PBYTE pbBuff1, PBYTE pbBuff2)
{
	DWORD dwRet; 

	*(PDWORD )(pbBuff1 + 8) = *(PDWORD )(pbBuff2 + 4);
	*(BYTE *)(pbBuff1 + 12) = *(BYTE *)(pbBuff2 + 8);
	dwRet = *(BYTE *)(pbBuff2 + 9);
	if ( (*(BYTE *)(pbBuff2 + 9) & 3) != 0 )
	{
		if ( (*(BYTE *)(pbBuff2 + 9) & 3) == 1 )
		{
			*(PDWORD )(pbBuff1 + 16) = 1;
		}
		else if ( (*(BYTE *)(pbBuff2 + 9) & 3) == 2 )
		{
			*(PDWORD )(pbBuff1 + 16) = 2;
		}
		else
		{
			*(PDWORD )(pbBuff1 + 16) = -1;
		}
	}
	else
	{
		*(PDWORD )(pbBuff1 + 16) = 0;
	}
	*(PDWORD )(pbBuff1 + 20) = (dwRet >> 2) & 1;
	*(BYTE *)(pbBuff1 + 25) = *(BYTE *)(pbBuff2 + 10);
	*(PDWORD )(pbBuff1 + 28) = *(PDWORD )(pbBuff2 + 12);
	return 1;
}
DWORD64  sub_100068A0(DWORD64 dwVal)
{
	DWORD64 ret;
	PBYTE pDest = (PBYTE)&ret;
	PBYTE pSrc = (PBYTE)&dwVal;

	pDest[7] = pSrc[0];
	pDest[6] = pSrc[1];
	pDest[5] = pSrc[2];
	pDest[4] = pSrc[3];
	pDest[3] = pSrc[4];
	pDest[2] = pSrc[5];
	pDest[1] = pSrc[6];
	pDest[0] = pSrc[7];


	return ret;
}
int  sub_10008AE0(PBYTE pbBuff1, PBYTE pbBuff2)
{
	*(PDWORD )(pbBuff2 + 8) = *(PDWORD )(pbBuff1 + 4);
	*(BYTE *)(pbBuff2 + 12) = *(BYTE *)(pbBuff1 + 8);
	*(DWORD64 *)(pbBuff2 + 16) = sub_100068A0(*(DWORD64 *)(pbBuff1 + 12));//sub_100068A0
	*(DWORD64 *)(pbBuff2 + 24) = sub_100068A0(*(DWORD64 *)(pbBuff1 + 20));
	return 1;
}
BYTE* sub_10008BA0(BYTE bVal, PBYTE pbBuff1, BYTE *pbBuff2, BYTE *pbBuff3)
{
	BYTE bTemp1; 
	char *pbTmp;
	DWORD nStrLen; 

	bTemp1 = *(BYTE *)(bVal + pbBuff1);
	pbTmp = (char *)(pbBuff1 + *(BYTE *)(pbBuff1 + 1));
	if ( !bTemp1 )
		return pbBuff3;
	while ( bTemp1 > 1 )
	{
		if ( !*pbTmp++ )
			--bTemp1;
	}
	if ( !pbTmp )
		return pbBuff3;
	nStrLen = strlen(pbTmp) + 1;
	if ( pbBuff2 )
		*pbBuff2 = (BYTE)pbBuff3;
	if ( *pbBuff2 )
	{
		if ( (WORD)nStrLen )
			sub_10004B10((BYTE*)pbTmp, nStrLen, pbBuff2);
	}
	return &pbBuff3[nStrLen];
}
int  sub_100086B0(PBYTE pbSrc, PBYTE pbBuff)
{
	BYTE *pbRet1; 
	BYTE *pbRet2; 
	char bTemp1; 
	SHORT wTemp3; 
	int result; 

	pbRet1 = sub_10008BA0(4, pbSrc, (BYTE *)(pbBuff + 8), (BYTE *)(pbBuff + 72));//sub_10008BA0
	pbRet2 = sub_10008BA0(5, pbSrc, (BYTE *)(pbBuff + 12), pbRet1);
	*(PWORD)(pbBuff + 16) = *(PWORD)(pbSrc + 6);
	sub_10008BA0(8, pbSrc, (BYTE *)(pbBuff + 20), pbRet2);
	*(PDWORD )(pbBuff + 24) = (*(char *)(pbSrc + 9) + 1) << 16;
	*(PDWORD )(pbBuff + 28) = *(PDWORD )(pbSrc + 10);
	*(PWORD)(pbBuff + 36) = *(PWORD)(pbSrc + 14);
	*(PWORD)(pbBuff + 38) = *(PWORD)(pbSrc + 16);
	bTemp1 = *(BYTE *)(pbBuff + 5) - 18;
	*(BYTE *)(pbBuff + 34) = *(BYTE *)(pbBuff + 5) - 18;
	if ( !bTemp1 )
		return 1;

	wTemp3 = *(BYTE *)(pbSrc + 18);
	*(PWORD)(pbBuff + 32) = wTemp3;
	if ( bTemp1 == 1 )
		return 1;
	bTemp1--;

	*(PWORD)(pbBuff + 32) = wTemp3 | (*(BYTE *)(pbSrc + 19) << 8);
	if ( bTemp1 == 1 )
		return 1;
	bTemp1--;

	*(BYTE *)(pbBuff + 40) = *(BYTE *)(pbSrc + 20);
	if ( bTemp1 == 1 )
		return 1;
	bTemp1--;

	*(BYTE *)(pbBuff + 41) = *(BYTE *)(pbSrc + 21);
	if ( bTemp1 == 1 )
		return 1;
	bTemp1--;
	*(BYTE *)(pbBuff + 42) = *(BYTE *)(pbSrc + 22);
	result = 1;
	if ( bTemp1 != 1 )
		*(BYTE *)(pbBuff + 43) = *(BYTE *)(pbSrc + 23);
	return result;
}
int  sub_10008770(PBYTE pbBuff1, PBYTE pbBuff2)
{
	char bVal; 
	PBYTE pbTmp1; 
	BYTE *pbRet; 
	char bVal2;


	bVal = *(BYTE *)(pbBuff1 + 5);
	pbTmp1 = pbBuff1 + 8;
	pbRet = sub_10008BA0(4, pbBuff2, (BYTE *)(pbBuff1 + 8), (BYTE *)(pbBuff1 + 72));
	pbRet = sub_10008BA0(5, pbBuff2, (BYTE *)(pbTmp1 + 4), pbRet);
	pbRet = sub_10008BA0(6, pbBuff2, (BYTE *)(pbTmp1 + 8), pbRet);
	pbRet = sub_10008BA0(7, pbBuff2, (BYTE *)(pbTmp1 + 12), pbRet);

	bVal2 = bVal - 8;
	if ( bVal != 8 )
	{
		*(PDWORD )(pbTmp1 + 16) = *(PDWORD )(pbBuff2 + 8);
		*(PWORD)(pbTmp1 + 20) = *(PWORD)(pbBuff2 + 12);
		*(PWORD)(pbTmp1 + 22) = *(PWORD)(pbBuff2 + 14);
		memcpy_s((void *const)(pbTmp1 + 24), 8, (const void *const)(pbBuff2 + 16), 8u);

		*(PDWORD )(pbTmp1 + 32) = *(BYTE *)(pbBuff2 + 24);
		if ( bVal2 != 17 )
		{
			bVal2 -= 17;
			pbRet = sub_10008BA0(0x19, pbBuff2, (BYTE *)(pbTmp1 + 36), pbRet);
			if ( bVal2 != 1 )
				sub_10008BA0(0x1A, pbBuff2, (BYTE *)(pbTmp1 + 40), pbRet);
		}
	}
	return 1;
}

int  sub_10008830(PBYTE pbBuff1, PBYTE pbBuff2)
{
	BYTE bVal1; 
	int result; 
	PBYTE pbTmp; 
	BYTE *pbRet; 


	bVal1 = *(BYTE *)(pbBuff2 + 5);
	result = 0;
	pbTmp  = pbBuff2 + 8;
	if ( bVal1 >= 8u )
	{
		pbRet = sub_10008BA0(4, pbBuff1, (BYTE *)pbTmp, (BYTE *)(pbBuff2 + 72));
		pbRet = sub_10008BA0(5, pbBuff1, (BYTE *)(pbTmp + 4), pbRet);
		pbRet = sub_10008BA0(6, pbBuff1, (BYTE *)(pbTmp + 8), pbRet);
		pbRet = sub_10008BA0(7, pbBuff1, (BYTE *)(pbTmp + 12), pbRet);
		bVal1 = bVal1 - 8;
		if ( bVal1 )
		{
			sub_10008BA0(8, pbBuff1, (BYTE *)(pbTmp + 16), pbRet);
			if ( bVal1 != 1 )
				*(BYTE *)(pbTmp + 40) = *(BYTE *)(pbBuff1 + 9);
		}
		return 1;
	}
	return result;
}
int  sub_100088B0(PBYTE pbBuff1, PBYTE pbBuff2)
{
	BYTE* pbTemp1; 
	BYTE *pbRet; 


	char bTmpVal; 

	pbTemp1 = pbBuff1 + 8;
	pbRet = sub_10008BA0(4, pbBuff2, (BYTE *)(pbBuff1 + 8), (BYTE *)(pbBuff1 + 72));
	*(PDWORD )(pbTemp1 + 4) = *(char *)(pbBuff2 + 5);
	*(PDWORD )(pbTemp1 + 8) = (WORD)(*(char *)(pbBuff2 + 6));
	pbRet = sub_10008BA0(7, pbBuff2, (BYTE *)(pbTemp1 + 12), pbRet);
	*(PDWORD )(pbTemp1 + 16) = *(PDWORD )(pbBuff2 + 8);
	*(PDWORD )(pbTemp1 + 20) = *(PDWORD )(pbBuff2 + 12);
	pbRet = sub_10008BA0(0x10, pbBuff2, (BYTE *)(pbTemp1 + 24), pbRet);
	bTmpVal = *(BYTE *)(pbBuff2 + 17);
	if ( bTmpVal < 0 )
	{

		*(PWORD)(pbTemp1 + 28) = 100 * (bTmpVal & 0x7F);
	}
	else if ( (bTmpVal & 1) != 0 )
	{
		*(PWORD)(pbTemp1 + 28) = 5000;

	}
	else if ( (bTmpVal & 2) != 0 )
	{

		*(PWORD)(pbTemp1 + 28) = 3300;

	}
	else if ( (bTmpVal & 4) != 0 )
		*(PWORD)(pbTemp1 + 28) = 2900;

	*(PWORD)(pbTemp1 + 30) = *(PWORD)(pbBuff2 + 18);
	*(PWORD)(pbTemp1 + 32) = *(PWORD)(pbBuff2 + 20);
	*(PWORD)(pbTemp1 + 34) = *(PWORD)(pbBuff2 + 22);
	*(PDWORD )(pbTemp1 + 36) = *(BYTE *)(pbBuff2 + 24) & 7;
	pbRet = sub_10008BA0(0x20, pbBuff2, (BYTE *)(pbTemp1 + 40), pbRet);
	pbRet = sub_10008BA0(0x21, pbBuff2, (BYTE *)(pbTemp1 + 44), pbRet);
	sub_10008BA0(0x22, pbBuff2, (BYTE *)(pbTemp1 + 48), pbRet);
	*(BYTE *)(pbTemp1 + 52) = *(BYTE *)(pbBuff2 + 35);
	*(BYTE *)(pbTemp1 + 53) = *(BYTE *)(pbBuff2 + 36);
	*(BYTE *)(pbTemp1 + 54) = *(BYTE *)(pbBuff2 + 37);
	*(PWORD)(pbTemp1 + 56) = *(PWORD)(pbBuff2 + 38);
	return 1;
}
int  sub_100089D0(PBYTE pbBuff1, PBYTE pbBuff2)
{
	DWORD dwTmp1; 
	BYTE *pbRet; 


	*(PWORD)(pbBuff2 + 8) = *(PWORD)(pbBuff1 + 8);
	*(PWORD)(pbBuff2 + 10) = *(PWORD)(pbBuff1 + 10);
	dwTmp1 = *(PWORD)(pbBuff1 + 12);
	*(PDWORD )(pbBuff2 + 12) = dwTmp1;
	if ( dwTmp1 == 0x7FFF )
		*(PDWORD )(pbBuff2 + 12) = *(PDWORD )(pbBuff1 + 28);
	*(PDWORD )(pbBuff2 + 16) = *(char *)(pbBuff1 + 14);
	*(BYTE *)(pbBuff2 + 20) = *(BYTE *)(pbBuff1 + 15);
	pbRet = sub_10008BA0(0x10, pbBuff1, (BYTE *)(pbBuff2 + 24), (BYTE *)(pbBuff2 + 72));
	pbRet = sub_10008BA0(0x11, pbBuff1, (BYTE *)(pbBuff2 + 28), pbRet);
	*(PDWORD )(pbBuff2 + 32) = *(char *)(pbBuff1 + 18);
	*(PWORD)(pbBuff2 + 60) = *(PWORD)(pbBuff1 + 19);
	*(PWORD)(pbBuff2 + 36) = *(PWORD)(pbBuff1 + 21);
	pbRet = sub_10008BA0(0x17u, pbBuff1, (BYTE *)(pbBuff2 + 40), pbRet);
	pbRet = sub_10008BA0(0x18u, pbBuff1, (BYTE *)(pbBuff2 + 44), pbRet);
	pbRet = sub_10008BA0(0x19u, pbBuff1, (BYTE *)(pbBuff2 + 48), pbRet);
	sub_10008BA0(0x1Au, pbBuff1, (BYTE *)(pbBuff2 + 52), pbRet);
	*(BYTE *)(pbBuff2 + 56) = *(BYTE *)(pbBuff1 + 27);
	*(PWORD)(pbBuff2 + 58) = *(PWORD)(pbBuff1 + 32);
	return 1;
}
int  sub_10008A90(PBYTE pbBuff1, PBYTE pbBuff2)
{
	BYTE *pbRet; 

	*(PDWORD )(pbBuff2 + 8) = *(PDWORD )(pbBuff1 + 4);
	*(BYTE *)(pbBuff2 + 12) = *(BYTE *)(pbBuff1 + 8);
	pbRet = sub_10008BA0(9, pbBuff1, (BYTE *)(pbBuff2 + 16), (BYTE *)(pbBuff2 + 72));
	pbRet = sub_10008BA0(0xA, pbBuff1, (BYTE *)(pbBuff2 + 20), pbRet);
	pbRet = sub_10008BA0(0xB, pbBuff1, (BYTE *)(pbBuff2 + 24), pbRet);
	sub_10008BA0(0xC, pbBuff1, (BYTE *)(pbBuff2 + 28), pbRet);
	return 1;
}

int sub_100049C0(DWORD *pdwArg1)
{
	int result; 
	DWORD dwRet; 
	PDWORD lpMem; 

	lpMem = 0;
	result = sub_100085C0((PDWORD)&lpMem, 161);
	if ( !result )
	{		
		if ( lpMem[6]== -1 && lpMem[7] == -1 )
		{
			dwRet = 50;
		}
		else
		{
			*pdwArg1 = lpMem[6];
			dwRet = 0;
		}
		if ( lpMem )
			HeapFree(g_hHeap_1001FE9C, 0, lpMem);
		return dwRet;
	}
	return result;
}
DWORD sub_10005FB0(PFUNCSTRUC14 pFuncInfo)
{
	OVERLAPPED *pOverlapped; 
	DWORD result; 
	int OutBuffer; 
	int InBuffer; 
	DWORD NumberOfBytesTransferred; 

	
	InBuffer = -1;
	NumberOfBytesTransferred = 0;
	OutBuffer = 0;
	pOverlapped = (OVERLAPPED *)sub_100065B0();
	if ( !pOverlapped )
		return 1450;
	DeviceIoControl(g_hFile, 0xEA60E254, &InBuffer, 4, &OutBuffer, 4, 0, pOverlapped);
	if ( GetOverlappedResult(g_hFile, pOverlapped, &NumberOfBytesTransferred, 1) )
	{
		pFuncInfo->dwSelfAddr00 = (BYTE)OutBuffer;
		return 0;
	}
	result = GetLastError();
	if ( result == 0xE0000109 )
		return 1460;
	if ( !result )
	{

		pFuncInfo->dwSelfAddr00 = (BYTE)OutBuffer;
		return 0;
	}
	return result;
}
DWORD sub_10005F20(BYTE byArg1)
{
	OVERLAPPED *pOverlapped; 
	DWORD result; 
	DWORD NumberOfBytesTransferred; 
	DWORD InBuffer[2];

	NumberOfBytesTransferred = 0;
	InBuffer[1] = byArg1;
	InBuffer[0] = 0xFFFFFFFF;
	pOverlapped = (OVERLAPPED *)sub_100065B0();
	
	if ( !pOverlapped )
		return 1450;
	DeviceIoControl(g_hFile, 0xEA60A258, InBuffer, 8, 0, 0, 0, pOverlapped);
	if ( GetOverlappedResult(g_hFile, pOverlapped, &NumberOfBytesTransferred, 1) )
		return 0;
	result = GetLastError();
	if ( result == 0xE0000109 )
		return 1460;
	return result;
}
int  sub_10004110(DWORD dwArg1, PFUNCSTRUC14 pFuncInfo)
{
	DWORD result;
	DWORD dwFlag;

	result = 0xFFFFFFFF;
	dwFlag = dwArg1 & 0xFFFF0000;
	pFuncInfo->dwSelfAddr00 = 0xFFFFFFFF;
	if ( dwFlag > 0x30000 )
	{
		switch ( dwFlag )
		{
		case 0x80010000:
			pFuncInfo->dwSelfAddr00 = 1;
			return 0;
		case 0x80010001:
			pFuncInfo->dwSelfAddr00 = 2;
			return 0;
		case 0x80030000:
			pFuncInfo->dwSelfAddr00 = 3;
			return 1;
		}
	}
	else if ( dwFlag == 0x30000 )
	{
		pFuncInfo->dwSelfAddr00 = 0xFFFFFFFF;
	}
	else if ( !dwFlag || dwFlag == 0x10000 )
	{
		pFuncInfo->dwSelfAddr00 = 0;
		return 0;
	}
	return result;
}

PControlDevice30 sub_10007840(WORD wCnt, PDWORD pdwArg2)
{
	
	DWORD result; 
	int j; 
	PControlDevice30 *pTmp; 
	PControlDevice30 i; 

	result = 0;
	j = 0;
	if ( wCnt )
	{
		pTmp = (PControlDevice30*)g_lpMem_1001FED8;
		for ( i = (PControlDevice30)g_lpMem_1001FED8; i->dwOutBuffer[0] != (DWORD)pdwArg2; i++ )
		{
			if ( ++j >= wCnt )
				return 0;
		}
		return (PControlDevice30)&pTmp[j];
	}
	return (PControlDevice30)result;
}

DWORD sub_10001000(PControlDevice30 pCtrlDev)
{
	DWORD result; 
	DWORD dwParam2; 
	DWORD dwParam1; 
	dwParam1 = 0;
	dwParam2 = 0;
	CCmos* pCmos = NULL;	
	CEmbeddedEeprom* pEeprom=NULL;
	DWORD dwRet = 0;
	if(pCtrlDev->dwFlag == 0)
	{
		pCmos = (CCmos*)pCtrlDev->lpClass;
		pCmos->sub_10007DB0(&dwParam1, &dwParam2);//14
	}
	else 
	{
		pEeprom = (CEmbeddedEeprom*)pCtrlDev->lpClass;
		pEeprom->sub_100078F0(&dwParam1, &dwParam2);//14
	}
	result = 1;
	if ( !(pCtrlDev->dwOutBuffer[3] % dwParam2) )
		return dwParam2;
	return result;
}

int sub_10007440(PControlDevice30 pCtrlDev, void *lpArg2, size_t dwArg3, DWORD dwArg4)
{
	
	if ( lpArg2 )
	{
		if ( (dwArg4 < pCtrlDev->dwOutBuffer[4])
			&& (dwArg3 <= pCtrlDev->dwOutBuffer[4]) && (dwArg4 + dwArg3 <= pCtrlDev->dwOutBuffer[4]) )
		{
			
						if ( pCtrlDev->dwUnk18 )
			{
				memcpy(lpArg2, (LPVOID)(pCtrlDev->dwUnk18 + dwArg4), dwArg3);
				return 1;
			}
			else
			{
				CCmos* pCmos = NULL;	
				CEmbeddedEeprom* pEeprom=NULL;
				DWORD dwRet = 0;
				if(pCtrlDev->dwFlag == 0)
				{
					pCmos = (CCmos*)pCtrlDev->lpClass;
					return pCmos->sub_10007D50((BYTE)(dwArg4 + pCtrlDev->dwOutBuffer[3]), (PBYTE)lpArg2, dwArg3);//c
				}
				else 
				{
					pEeprom = (CEmbeddedEeprom*)pCtrlDev->lpClass;
					return pEeprom->sub_100079F0(dwArg4 + pCtrlDev->dwOutBuffer[3], lpArg2, dwArg3);//c
				}
				
			}
		}
	}
	return 0;
}

int sub_10007120(PControlDevice30 pCtrlDevice, SIZE_T nSize, DWORD dwArg2, BYTE *Src)
{
	LPVOID lpMem;
	int dwResult;
	int dwCnt;
	dwCnt = dwArg2;

	int dwTmp = 0;
	if(dwArg2 >= pCtrlDevice->dwOutBuffer[4] || nSize< pCtrlDevice->dwOutBuffer[4] || dwArg2+nSize < pCtrlDevice->dwOutBuffer[4])
	{

		CCmos* pCmos = NULL;	
		CEmbeddedEeprom* pEeprom=NULL;
		DWORD dwRet = 0;

		if(pCtrlDevice->dwFlag == 0)
		{
			pCmos = (CCmos*)pCtrlDevice->lpClass;
			dwRet = dwTmp = pCmos->sub_10007CF0((BYTE)(pCtrlDevice->dwOutBuffer[3] + dwArg2), Src, nSize);
		}
		else 
		{
			pEeprom = (CEmbeddedEeprom*)pCtrlDevice->lpClass;
			dwRet = dwTmp = pEeprom->sub_10007920((BYTE)(pCtrlDevice->dwOutBuffer[3] + dwArg2), (char*)Src, nSize);
		}

		//eax = call eax(edx, Src, esi);
		if(dwRet == 1)
		{
			if(dwRet == pCtrlDevice->dwUnk24)// + 0x24)
			{
				lpMem = HeapAlloc(g_hHeap_1001FE9C, HEAP_ZERO_MEMORY, nSize);
				if(lpMem)
				{					
					if(pCtrlDevice->dwFlag == 0)
					{
						pCmos = (CCmos*)pCtrlDevice->lpClass;
						dwRet = dwTmp = pCmos->sub_10007CF0((BYTE)(pCtrlDevice->dwOutBuffer[3] + dwArg2), (BYTE*)lpMem, nSize);
					}
					else 
					{
						pEeprom = (CEmbeddedEeprom*)pCtrlDevice->lpClass;
						dwRet = dwTmp = pEeprom->sub_10007920((BYTE)(pCtrlDevice->dwOutBuffer[3] + dwArg2), (char*)lpMem, nSize);
					}


					dwCnt = nSize;
					bool fBreak = false;
					int i = nSize/4;
					PBYTE pData  = (PBYTE)lpMem;
					if(nSize >= 4)
					{
						do{

							if(pData[i] == Src[i])
							{
								i++;
								dwCnt-=4;
								// 								
							}
							else { fBreak = true; break;}

						}while(dwCnt>=4);

					}

					if(fBreak == false && dwCnt == 0) dwTmp = 0;
					else
					{
						if((dwTmp = pData[0] - Src[0]) == 0)
						{
							if(dwCnt <= 1) { dwTmp = 0;}
							else if((dwTmp = pData[1] - Src[1]) == 0)
							{
								if(dwCnt <=2){dwTmp = 0;}
								else if((dwTmp = pData[2] - Src[2]) == 0)
								{
									if(dwCnt<=3) {dwTmp = 0;}
									else
									{
										dwTmp = pData[3] - Src[3];
									}
								}
							}
						}
						if(dwTmp != 0)
						{
							dwTmp >>= 31;
							dwTmp |= 1;
						}

					}

					if(dwTmp == 0) dwResult = 1;
					else dwResult = 0;

					HeapFree(g_hHeap_1001FE9C, 0, lpMem);

					if(dwResult != 1) return dwResult;
				}
			}


			if(pCtrlDevice->dwUnk18){
				memcpy((void*)(pCtrlDevice->dwUnk18+dwArg2), Src, nSize);
			}
			if(pCtrlDevice->dwUnk20 == 1)
				return sub_10007370(pCtrlDevice);

			return dwResult;
		}
		return 0;
	}

	return 0;
}
int  sub_10007370(PControlDevice30 pCtrlDev)
{

	int result; 
	DWORD i;

	DWORD eax = 0, dwTmp1, dwResult = 0;
	PBYTE pbData = (PBYTE)pCtrlDev->dwUnk18;
	for( i = 0; i < pCtrlDev->dwOutBuffer[4]; i++)
	{

		dwTmp1 = (WORD)((BYTE)(dwResult >> 8)) | (WORD)(dwResult <<=8);
		dwResult = (WORD)((WORD)dwTmp1 ^(WORD)pbData[i]);
		BYTE bTmp2 = (BYTE)dwResult; bTmp2 >>= 4; dwResult ^=(WORD)bTmp2;
		dwResult ^= (dwResult<<12);
		dwTmp1 = (BYTE)dwResult; dwTmp1 <<= 5; dwTmp1 ^= dwResult;
		dwResult = (WORD)dwTmp1;

	}

	dwResult = (WORD)(dwResult<< 8);
	CCmos* pCmos = NULL;	
	CEmbeddedEeprom* pEeprom=NULL;
	DWORD dwRet = 0;
	if(pCtrlDev->dwFlag == 0)
	{
		pCmos = (CCmos*)pCtrlDev->lpClass;
		pCmos->sub_10007CF0((BYTE)pCtrlDev->dwUnk2C, (BYTE*)&dwResult, 2);//8
		pCmos->sub_10007D50((BYTE)pCtrlDev->dwUnk2C, (BYTE*)&i, 2);//c
	}
	else 
	{
		pEeprom = (CEmbeddedEeprom*)pCtrlDev->lpClass;
		pEeprom->sub_10007920((BYTE)pCtrlDev->dwUnk2C, (char*)&dwResult, 2);//8
		pEeprom->sub_100079F0((BYTE)pCtrlDev->dwUnk2C, (BYTE*)&i, 2);//c
	}

	if ( (WORD)dwResult != (WORD)i )
		return 0;
	result = 1;
	pCtrlDev->dwUnk1C = (dwResult<<8);
	return result;
}

int sub_10007290(PControlDevice30 pCtrlDev, SIZE_T dwArg2, unsigned int dwArg3)
{
	
	int result; 

	if(dwArg3 <pCtrlDev->dwOutBuffer[4] &&  dwArg2 <= pCtrlDev->dwOutBuffer[4] && (dwArg2 + dwArg3 < pCtrlDev->dwOutBuffer[4]))
	{
		CCmos* pCmos = NULL;	
		CEmbeddedEeprom* pEeprom=NULL;
		DWORD dwRet = 0;
		if(pCtrlDev->dwFlag == 0)
		{
			pCmos = (CCmos*)pCtrlDev->lpClass;
			result  = pCmos->_JidaVgaSetContrastEnable(dwArg3 + pCtrlDev->dwOutBuffer[3],dwArg2);//10
		}
		else 
		{
			pEeprom = (CEmbeddedEeprom*)pCtrlDev->lpClass;
			result  =  pEeprom->_JidaVgaSetContrastEnable(dwArg3 + pCtrlDev->dwOutBuffer[3],dwArg2);//10
			
		}
		if(result == 1)
		{
			if(pCtrlDev->dwUnk24 == result)
			{
				LPVOID lpMem = HeapAlloc(g_hHeap_1001FE9C, 8u, dwArg2);
				if(lpMem)
				{
					if(pCtrlDev->dwFlag == 0)
					{
						pCmos = (CCmos*)pCtrlDev->lpClass;
						result  = pCmos->sub_10007D50((BYTE)(dwArg3 + pCtrlDev->dwOutBuffer[3]), (PBYTE)lpMem, dwArg2);//10
					}
					else 
					{
						pEeprom = (CEmbeddedEeprom*)pCtrlDev->lpClass;
						result  =  pEeprom->sub_100079F0(dwArg3 + pCtrlDev->dwOutBuffer[3],lpMem, dwArg2);//10

					}
					if ( (DWORD)lpMem != (DWORD)lpMem + dwArg2 )
					{
						PDWORD pwTmp = (PDWORD)lpMem;
						while ( !*pwTmp++ )
						{
							if ( (DWORD)pwTmp == (DWORD)lpMem + dwArg2 )
							{
								result = 0;
								break;
							}
						}
						
					}
					sub_10006770(lpMem);
					if(result != 1) return 0;
				}
			}
			if(pCtrlDev->dwUnk18)
				memset_10006790(dwArg2, pCtrlDev->dwUnk18 + pCtrlDev);
			if(pCtrlDev->dwUnk20 == 1)
				return sub_10007370(pCtrlDev);
			
		}

	}

	return result;

}

void* memset_10006790(size_t Size , void * lpDest)
{
	if ( lpDest )
		return memset(lpDest, 0, Size);
	else
		return 0;
}
LPVOID sub_10006770(void *lpSrc)
{
	if ( lpSrc )
		return (void *)HeapFree(g_hHeap_1001FE9C, 0, lpSrc);
	return lpSrc;
}
//////////////////////////////////////////////////////////////////////////


DWORD sub_10001040(DWORD *pdwOffset, DWORD *pdwRes)
{
	int dwRet; 
	LPFnU_DDP pFunc =(LPFnU_DDP) (*(PDWORD )*pdwOffset + 20);
	dwRet = pFunc(	pdwOffset[2],	*((PWORD)pdwOffset + 6), pdwRes);
	*pdwRes = *pdwRes * pdwOffset[4] / 1000;
	return dwRet;
}
DWORD sub_10001080(DWORD *pdwOffset, DWORD *pdwRes1, DWORD* pdwRes2)
{
	int dwRet; 
	LPFnU_DDPP pFunc =(LPFnU_DDPP) (*(PDWORD )*pdwOffset + 0x18);
	dwRet = pFunc(	pdwOffset[2],	*((PWORD)pdwOffset + 6), pdwRes1, pdwRes2);
	*pdwRes1 = *pdwRes1 * pdwOffset[4] / 1000;
	*pdwRes2 = *pdwRes2 * pdwOffset[4] / 1000;
	return dwRet;
}
DWORD sub_100010D0(DWORD *pdwOffset, DWORD *pdwRes)
{
	int dwRet; 
	LPFnU_DDP pFunc =(LPFnU_DDP) (*(PDWORD )*pdwOffset + 0x1C);
	dwRet = pFunc(	pdwOffset[2],	*((PWORD)pdwOffset + 6), pdwRes);
	*pdwRes = *pdwRes * pdwOffset[4] / 1000;	
	return dwRet;
}
DWORD sub_10001110(DWORD *pdwOffset, DWORD *pdwRes)
{
	int dwRet; 
	LPFnU_DDP pFunc =(LPFnU_DDP) (*(PDWORD )*pdwOffset + 0x20);
	dwRet = pFunc(	pdwOffset[2],	*((PWORD)pdwOffset + 6), pdwRes);
	*pdwRes = *pdwRes * pdwOffset[4] / 1000;
	return dwRet;
}
DWORD sub_10001150(DWORD *pdwOffset, DWORD *pdwRes)
{
	int dwRet; 
	LPFnU_DDP pFunc =(LPFnU_DDP) (*(PDWORD )*pdwOffset + 0x24);
	dwRet = pFunc(	pdwOffset[2],	*((PWORD)pdwOffset + 6), pdwRes);
	*pdwRes = *pdwRes * pdwOffset[4] / 1000;
	return dwRet;
}
int sub_10001190(DWORD* pdwOffset, PDWORD pdwRes)
{
	int dwRet;
	LPFnU_DDP pFunc =(LPFnU_DDP) (*(PDWORD )*pdwOffset + 0x28);
	dwRet = pFunc(	pdwOffset[2],	*((PWORD)pdwOffset + 6), pdwRes);	
	return dwRet;
}
WCHAR* sub_100067E0(char* szStr, DWORD dwSizeWBuf, WCHAR* wszStr)
{
	if ( !szStr || !wszStr)
		return 0;

	*wszStr = 0;

	if ( MultiByteToWideChar(0, 0, szStr, -1, wszStr, dwSizeWBuf >> 1) == 0 )
		return 0;
	return wszStr;
}
DWORD sub_100063C0(WCHAR *pwSrc, WCHAR *pwDest, int dwLen)
{
	DWORD result;
	int nCnt; 

	result = 0;
	nCnt = 0x7FFFFFFE;
	if ( dwLen )
	{
		while ( nCnt && *pwSrc )
		{
			*pwDest = *pwSrc;
			--dwLen;
			++pwDest;
			++pwSrc;
			--nCnt;
			if ( !dwLen )
			{
				result = 0x8007007A;
				*(pwDest - 1) = 0;
				return result;
			}
		}
	}
	else
	{
		--pwDest;
		result = 0x8007007A;
	}
	*pwDest = 0;
	return result;
}
BOOL sub_10006870(WCHAR* wszBuf,WCHAR* pwDest,int nMaxLen)
{
	return wszBuf && pwDest && nMaxLen > 0 && sub_100063C0(wszBuf, pwDest, nMaxLen) >= 0;
}
BOOL sub_10004420(FUNCSTRUC14* pfun, DWORD dwArgIdx, WORD wArg, WORD* pwDest, DWORD dwMaxLen, DWORD* pdwStrlen)
{
	DWORD dwVal; 
	DWORD dwtmp; 
	BOOL result; 
	DWORD dwStrlen; 
	DWORD dwIndex; 
	char *pszStr; 
	int nCnt; 
	WCHAR *wszBuf; 
	DWORD dwSizeWBuf;

	dwVal = 0;
	if ( pfun && pfun->dwSelfAddr00 == (DWORD)pfun && !strcmp(pfun->szStr0C, "JHANDLE") )
		dwVal = (DWORD)pfun + 16;
	dwtmp = 0;
	if ( dwArgIdx < 3 && wArg < LOWORD(g_dword_1001FEB4[2 * dwArgIdx +2]) )
		dwtmp = g_dword_1001FEB4[2 * dwArgIdx + 3] + 20 * wArg;
	result = 0;
	dwStrlen = 0;
	if ( dwVal && dwtmp )
	{
		dwIndex = *(DWORD *)(dwtmp + 4);
		pszStr = 0;
		nCnt = 0;
		while ( g_dword_1001AE48[nCnt].dwIndex != dwIndex )
		{
			if ( ++nCnt >= 24 )
				break;;
		}
		pszStr = g_dword_1001AE48[nCnt].szStr;
		if ( !pszStr )
		{
			dwStrlen = 0;			
		}
		else
			dwStrlen = strlen(pszStr) + 1;

		if ( pwDest && dwStrlen && dwStrlen <= dwMaxLen )
		{
			if ( pszStr )
			{
				dwSizeWBuf = 2 * strlen(pszStr) + 2;
				wszBuf = (WCHAR*)_alloca(dwSizeWBuf);
				wszBuf = sub_100067E0(pszStr, dwSizeWBuf, wszBuf);
			}
			sub_10006870(wszBuf, (WCHAR*)pwDest, dwMaxLen);
			result = 1;
		}
	}
	if ( pdwStrlen )
		*pdwStrlen = dwStrlen;
	return result;
}
int sub_10006290(char *pszDest, char* pszSrc, DWORD dwLen)
{
	int result; 

	result = 0;
	if ( dwLen <= 0 )
		result = 0x80070057;
	if ( result >= 0 )
	{
		result = 0;
		if ( dwLen )
		{			
			while ( 1 )
			{			
				if ( !*pszSrc )
					break;
				*pszDest = *pszSrc;
				pszDest++;
				pszSrc++;
				dwLen--;
				if ( !dwLen )
				{
					result = 0x8007007A;
					*(pszDest - 1) = 0;
					return result;
				}
			}
		}
		if ( !dwLen )
		{
			--pszDest;
			result = 0x8007007A;
		}
		*pszDest = 0;
	}
	return result;
}
BOOL sub_10006850(char* pszStr,char* pszDest, int nMax)
{
	return pszStr && pszDest && (int)sub_10006290(pszStr, pszDest, nMax) >= 0;
}
int sub_10004340(FUNCSTRUC14* pfun,DWORD dwArgIdx,WORD wArg, char* pszDest,  int nMax, DWORD* pdwRes)
{
	int dwtmp; // ecx
	int dwVal; // edi
	int bRet; // edx
	DWORD dwCnt; // esi
	int dwIdx; // edi
	char *pszStr; // eax
	DWORD dwStrLen;

	dwtmp = 0;
	if ( pfun && pfun->dwSelfAddr00 == (DWORD)pfun && !strcmp(pfun->szStr0C, "JHANDLE") )
		dwtmp = (DWORD)pfun + 16;
	dwVal = 0;
	if ( dwArgIdx < 3 && wArg < LOWORD(g_dword_1001FEB4[2 * dwArgIdx + 2]) )
		dwVal = g_dword_1001FEB4[2 * dwArgIdx + 3] + 20 * wArg;
	bRet = 0;
	dwCnt = 0;
	if ( dwtmp && dwVal )
	{
		dwIdx = *(DWORD *)(dwVal + 4);
		pszStr = 0;
		while ( g_dword_1001AE48[dwCnt].dwIndex != dwIdx )
		{
			if ( ++dwCnt >= 0x18 )
				break;
		}
		pszStr = g_dword_1001AE48[dwCnt].szStr;
		if ( !pszStr )
		{
			dwStrLen = 0;			
		}
		else
			dwStrLen = strlen(pszStr) + 1;

		if ( pszDest && dwStrLen && dwStrLen <= (DWORD)nMax )
		{
			sub_10006850(pszStr, pszDest, nMax);
			bRet = 1;
		}
	}
	if ( pdwRes )
		*pdwRes = dwStrLen;
	return bRet;
}
DWORD sub_10005500(DWORD dwArg2, DWORD dwArg3, DWORD dwParam )
{
	BYTE byIn; 
	OVERLAPPED *pOverlap;	
	DWORD result;
	DWORD NumberOfBytesTransferred; 
	BYTE InBuffer[24]; 

	byIn = 0;
	NumberOfBytesTransferred = 0;
	switch ( dwParam )
	{
	case 8:
	case 9:
	case 10:
	case 11:
		dwParam = 1;
		break;
	case 17:
	case 18:
	case 19:
		byIn = (BYTE)(dwParam - 16);
		dwParam = 0;
		break;
	default:
		break;
	}

	*(DWORD*)InBuffer = dwParam;
	*(DWORD*)(InBuffer+4) = dwArg2;
	*(DWORD*)(InBuffer+8) = dwArg3;
	InBuffer[12] = byIn;
	pOverlap = sub_100065B0();
	if ( !pOverlap )
		return ERROR_NO_SYSTEM_RESOURCES;
	DeviceIoControl(g_hFile, 0xEA60A058, InBuffer, 0x18, 0, 0, 0, pOverlap);
	if ( GetOverlappedResult(g_hFile, pOverlap, &NumberOfBytesTransferred, 1) )
		return 0;
	result = GetLastError();
	if ( result == 0xE0000109 )
		return ERROR_TIMEOUT;
	return result;
}
DWORD sub_100055D0(DWORD dwArg, DWORD dwParam)
{
	int dwIn = 0; 
	char byIn;
	OVERLAPPED *pOverlap; 
	DWORD result;
	DWORD NumberOfBytesTransferred;
	BYTE InBuffer[24]; 

	byIn = 0;
	NumberOfBytesTransferred = 0;
	switch ( dwParam )
	{
	case 8:
	case 9:
	case 10:
	case 11:
		dwIn = 1;
		break;
	case 17:
	case 18:
	case 19:
		byIn = dwIn - 16;
		dwIn = 0;
		break;
	default:
		break;
	}
	*(DWORD*)InBuffer = dwIn;
	*(DWORD*)(InBuffer+4) = dwArg;
	InBuffer[12] = byIn;
	pOverlap = sub_100065B0();
	if ( !pOverlap )
		return ERROR_NO_SYSTEM_RESOURCES;
	DeviceIoControl(g_hFile, 0xEA60A05C, InBuffer, 0x18, 0, 0, 0, pOverlap);
	if ( GetOverlappedResult(g_hFile, pOverlap, &NumberOfBytesTransferred, 1) )
		return 0;
	result = GetLastError();
	if ( result == 0xE0000109 )
		return ERROR_TIMEOUT;
	return result;
}
DWORD sub_100056A0(LPVOID lpOutBuffer, DWORD dwParam)
{
	int dwIn = 0; 
	char byIn;
	OVERLAPPED *pOverlap; 
	DWORD result;
	DWORD NumberOfBytesTransferred;
	BYTE InBuffer[24]; 

	byIn = 0;
	NumberOfBytesTransferred = 0;
	switch ( dwParam )
	{
	case 8:
	case 9:
	case 10:
	case 11:
		dwIn = 1;
		break;
	case 17:
	case 18:
	case 19:
		byIn = dwIn - 16;
		dwIn = 0;
		break;
	default:
		break;
	}
	*(DWORD*)InBuffer = dwIn;
	InBuffer[12] = byIn;
	pOverlap = sub_100065B0();
	if ( !pOverlap )
		return ERROR_NO_SYSTEM_RESOURCES;
	DeviceIoControl(g_hFile, 0xEA60E058, InBuffer, 0x18, lpOutBuffer, 4, 0, pOverlap);
	if ( GetOverlappedResult(g_hFile, pOverlap, &NumberOfBytesTransferred, 1) )
		return 0;
	result = GetLastError();
	if ( result == 0xE0000109 )
		return ERROR_TIMEOUT;
	return result;
}
DWORD sub_10006140(LPVOID lpOutBuffer)
{	
	OVERLAPPED *pOverlap;
	DWORD result; 
	DWORD NumberOfBytesTransferred; 

	NumberOfBytesTransferred = 0;
	pOverlap = sub_100065B0();
	if ( !pOverlap )
		return ERROR_NO_SYSTEM_RESOURCES;
	DeviceIoControl(g_hFile, 0xEA6062CC, 0, 0, lpOutBuffer, 4, 0, pOverlap);
	if ( GetOverlappedResult(g_hFile, pOverlap, &NumberOfBytesTransferred, 1) )
		return 0;
	result = GetLastError();
	if ( result == 0xE0000109 )
		return ERROR_TIMEOUT;
	return result;
}
DWORD sub_10006050(char InBuffer, DWORD dwParam)
{	
	OVERLAPPED *poverlap; 	
	DWORD result; 
	DWORD NumberOfBytesTransferred; 
	DWORD dwIOCode;

	NumberOfBytesTransferred = 0;
	poverlap = sub_100065B0();

	if ( !poverlap )
		return ERROR_NO_SYSTEM_RESOURCES;
	if (dwParam == 0)
	{
		dwIOCode = 0xEA60A2C0 + 4;
	}
	else 
		dwIOCode = 0xEA60A2C0;
	DeviceIoControl(g_hFile, dwIOCode, &InBuffer, 4, 0, 0, 0, poverlap);
	if ( GetOverlappedResult(g_hFile, poverlap, &NumberOfBytesTransferred, 1) )
		return 0;
	result = GetLastError();
	if ( result == 0xE0000109 )
		return ERROR_TIMEOUT;
	return result;
}
DWORD sub_100060D0(LPVOID lpOutBuffer)
{	
	OVERLAPPED *pOverlap;
	DWORD result; 
	DWORD NumberOfBytesTransferred; 

	NumberOfBytesTransferred = 0;
	pOverlap = sub_100065B0();
	if ( !pOverlap )
		return ERROR_NO_SYSTEM_RESOURCES;
	DeviceIoControl(g_hFile, 0xEA6062C8, 0, 0, lpOutBuffer, 4, 0, pOverlap);
	if ( GetOverlappedResult(g_hFile, pOverlap, &NumberOfBytesTransferred, 1) )
		return 0;
	result = GetLastError();
	if ( result == 0xE0000109 )
		return ERROR_TIMEOUT;
	return result;
}
DWORD sub_100061B0(DWORD InBuffer, DWORD dwMilliseconds)
{
	OVERLAPPED *pOverlap; 
	DWORD result; 
	DWORD NumberOfBytesTransferred; 


	NumberOfBytesTransferred = 0;
	pOverlap = sub_100065B0();
	if ( !pOverlap )
		return ERROR_NO_SYSTEM_RESOURCES;//0x5AA; //ERROR_NO_SYSTEM_RESOURCES
	DeviceIoControl(g_hFile, 0xEA60A018, &InBuffer, 4, 0, 0, 0, pOverlap);
	if ( !GetOverlappedResult(g_hFile, pOverlap, &NumberOfBytesTransferred, 1) )
	{
		result = GetLastError();		
		if ( result == 0xE0000109 )
			return ERROR_TIMEOUT;//0x5B4;
		if (result)
		{
			return result;
		}
	}
	Sleep(dwMilliseconds);
	InBuffer = 0;
	pOverlap = sub_100065B0();	
	if ( pOverlap )
	{
		DeviceIoControl(g_hFile, 0xEA60A018, &InBuffer, 4u, 0, 0, 0, pOverlap);
		if ( !GetOverlappedResult(g_hFile, pOverlap, &NumberOfBytesTransferred, 1) )
			GetLastError();
	}
	return result;
}
//////////////////////////////////////////////////////////////////////////
int sub_10004D40(rsize_t dwArg1, int dwArg2, SHORT dwArg3, DWORD *pdwDest, PDWORD pdwArg5)
{
	int result; 
	VOID *lpMem; 
	DWORD *pdwTmp1; 
	DWORD dwRet2; 
	char dwOut; 
	DWORD dwOut2; 
	DWORD dwTmp1[6]; 


	result = 87;

	dwOut = 0;
	if ( pdwDest )
	{
		result = sub_10005760((PDWORD)&dwArg2, (PBYTE)&dwOut);
		if ( !result )
		{
			dwOut2 = 0;
			lpMem = (char *)HeapAlloc(g_hHeap_1001FE9C, 8, dwArg1 + 12);
			pdwTmp1 = (PDWORD)lpMem;
			if ( lpMem )
			{
				dwTmp1[0] = dwArg2;
				dwTmp1[1] = dwArg3;
				dwTmp1[2] = 1;
				dwTmp1[3] = dwOut;
				dwTmp1[4] = dwArg1;
				dwTmp1[5] = 0;
				
				dwRet2 = sub_10006910(g_hFile, 0xEA606044, &dwTmp1, 24, lpMem, dwArg1 + 12, &dwOut2);
				if ( dwRet2 )
				{
					if ( dwArg2 != dwArg2 )
					{
						sub_10004E80(dwArg2, 255, 0, 0, 0, 1);
						ReleaseMutex(g_hMutex_1001FEB0);
					}
				}
				else
				{
					dwRet2 = sub_10006CC0(pdwTmp1[0]);
					if ( !dwRet2 )
					{
						if ( pdwArg5 )
							*pdwArg5 = pdwTmp1[2];
						if ( pdwTmp1[2] != dwArg1 )
							dwRet2 = 30;
						memcpy_s(pdwDest, dwArg1, (PBYTE)pdwTmp1 + 12, pdwTmp1[2]);
					}
				}
				HeapFree(g_hHeap_1001FE9C, 0, pdwTmp1);
				return dwRet2;
			}
			else
			{
				return result;
			}
		}
	}
	return result;
}

DWORD sub_10005760(DWORD* pdwArg, BYTE* pbyArg)
{
	BYTE byVal; 
	DWORD dwVal; 
	int nCnt; 
	HANDLE hf; 
	OVERLAPPED *Value; 
	HANDLE hevent;	
	char by_29;
	char Source[4]; 
	DWORD dwRet; 
	DWORD dwres;
	DWORD NumberOfBytesTransferred;
	int InBuffer[3]; 


	*pbyArg = 0;
	if (*pdwArg  > 17)
	{
		*pbyArg = *(BYTE*)pdwArg - 16;
		*pdwArg = 0;
		return 0;
	}
	switch ( *pdwArg - 8 )
	{
	case 0:
		byVal = 1;
		dwVal = 0x70;
	case 1:
		byVal = 2;
		dwVal = 0x70;
	case 2:		
		byVal = 4;
		dwVal = 0x70;
	case 3:
		byVal = 8;
		dwVal = 0x70;
	case 4:
		byVal = 1;
		dwVal = 0x72;
	case 5:
		byVal = 2;
		dwVal = 0x72;
	case 6:
		byVal = 4;
		dwVal = 0x72;		
	case 7:
		byVal = 8;
		dwVal = 0x72;
	default:
		return 0;
	}
	nCnt = 0;	
	dwres = 0;
	by_29 = 3;
	Source[0] = 7;
	Source[1] = byVal;
	Source[2] = 0x7A;
	if ( g_hMutex_1001FEB0 )
		WaitForSingleObject(g_hMutex_1001FEB0, 0xFFFFFFFF);
	dwRet = sub_10004E80(1, (WORD)dwVal, Source, 3, &dwres, 0);//sub_10004E80
	hf = g_hFile;
	if ( dwRet )
	{		
		NumberOfBytesTransferred = 0;
		InBuffer[0] = 1;
		Value = (OVERLAPPED *)sub_100065B0();
		if ( Value )
		{
			DeviceIoControl(hf, 0xEA60E050, InBuffer, 0x18, 0, 0, 0, Value);
			if ( !GetOverlappedResult(hf, Value, &NumberOfBytesTransferred, 1) )
				GetLastError();
			ReleaseMutex(g_hMutex_1001FEB0);
			return dwRet;
		}			
	}
	Source[0] = 9;
	do
	{
		if ( dwRet )	break;
		dwRet = sub_10004FB0(1, 1, (WORD)dwVal, Source, 1, &dwres, &by_29, &NumberOfBytesTransferred, 0);//sub_10004FB0
		if ( by_29 != 4 ) 	break;
		++nCnt;
	}
	while ( nCnt < 3 );

	NumberOfBytesTransferred = 0;
	InBuffer[0] = 1;
	Value = (OVERLAPPED *)TlsGetValue(g_dwTlsIndex_1001F01C);
	if ( !Value )
	{
		Value = (OVERLAPPED *)HeapAlloc(g_hHeap_1001FE9C, 8, 0x14);
		if ( Value )
		{
			Value->Internal = 0;
			Value->InternalHigh = 0;
			Value->Offset = 0;
			Value->OffsetHigh = 0;
			Value->hEvent = 0;
			hevent = CreateEventW(0, 0, 0, 0);
			Value->hEvent = hevent;
			if (!hevent)
			{
				HeapFree(g_hHeap_1001FE9C, 0, Value);
			}
			else
			{
				TlsSetValue(g_dwTlsIndex_1001F01C, Value);	
				DeviceIoControl(hf, 0xEA60E050, InBuffer, 0x18, 0, 0, 0, Value);
				if ( !GetOverlappedResult(hf, Value, &NumberOfBytesTransferred, 1) )
					GetLastError();
			}
		}
	}
	else
	{
		DeviceIoControl(hf, 0xEA60E050, InBuffer, 0x18, 0, 0, 0, Value);
		if ( !GetOverlappedResult(hf, Value, &NumberOfBytesTransferred, 1) )
			GetLastError();
	}

	if ( dwRet ) return dwRet;
	if ( by_29 == 1 )
	{		
		*pdwArg = 1;
	}
	else
	{
		dwRet = 0xE0000108;
	}
	return dwRet;
}

DWORD sub_10004E80(DWORD a1, WORD a2, void *Source, DWORD dwSizeSrc, PDWORD a5, DWORD a6)
{
	DWORD result;
	DWORD dwSize;
	BYTE* pAlloc;
	DWORD dwsubret; 
	BYTE byVal; 
	DWORD dwSavea1; 
	DEVOUT_0C devout;
	DWORD dwBytesReturn = 0;

	dwSavea1 = a1;
	byVal = 0;
	result = sub_10005760(&a1, &byVal);
	dwSize = 0;

	if ( !result )
	{
		memset(&devout, 0, sizeof(DEVOUT_0C));
		if ( Source )
			dwSize = dwSizeSrc;
		pAlloc = (BYTE*)HeapAlloc(g_hHeap_1001FE9C, 8, dwSize + 0x18);
		if ( pAlloc )
		{
			*(DWORD*)pAlloc = a1;
			*(WORD*)(pAlloc+4) = a2;
			*(DWORD*)(pAlloc+0x8) = a6;
			*(BYTE*)(pAlloc+0xC) = byVal;
			*(DWORD*)(pAlloc+0x10) = dwSize;

			if ( Source )
				memcpy_s(pAlloc + 0x18, dwSize + 0x18, Source, dwSize);
			dwsubret = sub_10006910(g_hFile, 0xEA60A040, pAlloc, dwSize + 0x18, &devout, 0xC, &dwBytesReturn);
			if ( dwsubret )
			{
				if ( dwSavea1 != a1 )
				{
					sub_10004E80(a1, 255, 0, 0, 0, 1);
					ReleaseMutex(g_hMutex_1001FEB0);
				}
			}
			else
			{
				dwsubret = sub_10006CC0(devout.nErrCode_0);
				if ( a5 )
					*a5 = devout.nResult_4;
			}
			HeapFree(g_hHeap_1001FE9C, 0, pAlloc);
			return dwsubret;
		}
		else
		{
			return result;
		}
	}
	return result;
}
DWORD sub_10004FB0(DWORD dwArg1, DWORD dwArg2, WORD wArg3, void *Source, DWORD SrcSize, DWORD* pdwArg6, void* Dest,PDWORD pdwArg8,  int nArg9)
{

	DWORD dwRet; 
	BYTE *pAlloc;
	BYTE byVal;
	DWORD dwBytesReturned; 
	int dwtmp; 
	dwtmp = dwArg2;
	byVal = 0;
	if ( !Dest )
		return sub_10004E80(dwArg2, wArg3, Source, SrcSize, pdwArg6, 1);
	dwRet = sub_10005760(&dwArg2, &byVal);
	if (dwRet) return dwRet;
	DWORD dwTail = (SrcSize + 3) & 0xFFFFFFFC;
	DWORD dwAllocSize = dwTail + dwArg1 + 0x24;
	pAlloc = (BYTE*)HeapAlloc(g_hHeap_1001FE9C, 8, dwAllocSize);
	if (!pAlloc)
	{
		return dwRet;
	}

	dwBytesReturned = 0;
	if ( Source )
	{
		memcpy_s(pAlloc + 0x18, SrcSize, Source, SrcSize);
		*(DWORD*)(pAlloc + 0x10) =  SrcSize;
	}
	else
	{
		*(DWORD*)(pAlloc + 0x10) =  0;
	}
	*(DWORD*)pAlloc = dwArg2;
	*(WORD*)(pAlloc+4) = wArg3;
	*(DWORD*)(pAlloc+0x8) = nArg9;
	*(BYTE*)(pAlloc+0xC) = byVal;
	*(DWORD*)(pAlloc+0x14) = dwArg1;

	dwRet = sub_10006910(g_hFile,0xEA60E048,	pAlloc, dwAllocSize, pAlloc, dwAllocSize, &dwBytesReturned);
	if ( dwRet )
	{
		if ( dwtmp != dwArg2 )
		{
			sub_10004E80(dwArg2, 255, 0, 0, 0, 1);
			ReleaseMutex(g_hMutex_1001FEB0);
		}
	}
	else
	{
		DWORD* pInfo = (DWORD*)(pAlloc+0x18+dwTail);
		dwRet = sub_10006CC0(*(DWORD*)pInfo);
		if ( !dwRet )
		{			
			if (*(PDWORD )(pInfo + 4) == SrcSize )
			{
				if ( *(PDWORD )(pInfo + 8) != dwArg1 )
					dwRet = 0x1E;
			}
			else
			{
				dwRet = 0x1D;
			}
			if ( pdwArg6 )
				*(PDWORD )pdwArg6 = *(PDWORD )(pInfo + 4);
			if ( pdwArg8 )
				*pdwArg8 = *(PDWORD )(pInfo + 8);
			memcpy_s(Dest, dwArg1, pAlloc+dwTail+0x24, *(PDWORD )(pInfo + 8));
		}
	}
	HeapFree(g_hHeap_1001FE9C, 0, pAlloc);
	return dwRet;
}

DWORD sub_10006CC0(DWORD dwParam)
{
	DWORD dwRet; 

	dwRet = 0x54F;
	switch ( dwParam )
	{
	case 3:
		dwRet = 0xE000010A;
		break;
	case 4:
		dwRet = 0x1D;
		break;
	case 5:
		dwRet = 0x1E7;
		break;
	case 6:
		dwRet = 0xAA;
		break;
	case 7:
		dwRet = 0;
		break;
	case 8:
		dwRet = 0x5B4;
		break;
	case 9:
		dwRet = 0x4C7;
		break;
	case 0xA:
		dwRet = 0x32;
		break;
	default:
		return dwRet;
	}
	return dwRet;
}

int sub_100052C0(int nSizeDest, int a2, WORD a3, WORD a4, int a5, void *pDest)
{
	DWORD dwAllocSize; 
	BYTE *pAlloc;
	DWORD dwRes;
	BYTE by_9; 
	DWORD NumberOfBytesTransferred; 
	int tmpa2; 

	dwRes = 0x57;
	tmpa2 = a2;
	by_9 = 0;
	if ( !pDest ) return dwRes;
	dwRes = sub_10005760((DWORD*)&a2, &by_9);
	if (dwRes) return dwRes;
	dwAllocSize = 4 + 0x24 + nSizeDest;
	pAlloc = (BYTE*)HeapAlloc(g_hHeap_1001FE9C, 8, dwAllocSize);
	if (!pAlloc) return dwRes;

	*(DWORD*)pAlloc = a2;
	*(WORD*)(pAlloc + 4) = a3;
	*(DWORD*)(pAlloc + 8) = 1;
	*(BYTE*)(pAlloc+0xC) = by_9;
	*(PDWORD )(pAlloc + 0x10) = 1;
	*(PDWORD )(pAlloc + 0x14) = nSizeDest;
	NumberOfBytesTransferred = 0;
	if ( a5 == 1 )
	{			
		*(PDWORD )(pAlloc + 0x10) = 2;
		*(BYTE *)(pAlloc + 0x18) = a4>>8;
		*(BYTE *)(pAlloc + 0x19) = a4 & 0xFF;
	}
	else
	{
		*(BYTE *)(pAlloc + 0x18) = a4 & 0xFF;
	}
	dwRes = sub_10006910(g_hFile, 0xEA60E048, pAlloc, dwAllocSize, pAlloc, dwAllocSize, &NumberOfBytesTransferred);//sub_10006910
	if ( dwRes )
	{
		if ( tmpa2 != a2 )
		{
			
			sub_10004E80(a2, 255, 0, 0, 0, 1);
			ReleaseMutex(g_hMutex_1001FEB0);
		}
	}
	else
	{
		dwRes = sub_10006CC0(*(DWORD*)(pAlloc+0x1C));
		if ( !dwRes )
		{
			memcpy_s(pDest, nSizeDest, pAlloc + 0x28, *(DWORD*)(pAlloc+0x24));
			if ( nSizeDest != *(PDWORD )(pAlloc + 0x24) )
				dwRes = 30;
		}
	}
	HeapFree(g_hHeap_1001FE9C, 0, pAlloc);
	return dwRes;
}

int sub_10005160(DWORD dwlen, DWORD a2, DWORD a3, WORD a4, WORD a5, void *Source)
{
	DWORD dwRet; 
	int dwAllocSize; 
	BYTE *pAlloc; 
	BYTE *pSub; 
	BYTE byVal; 
	DWORD dwBytesReturn; 
	DWORD tmpa3; 
	DEVOUT_0C devout; 

	dwRet = 0x57;
	tmpa3 = a3;
	byVal = 0;
	if (!Source) return dwRet;

	dwRet = sub_10005760(&a3, &byVal);
	if (dwRet) return dwRet;
	dwBytesReturn = 0;
	memset(&devout, 0, sizeof(DEVOUT_0C));
	if (a2 != 0)
	{
		dwAllocSize = 1 + 1 + dwlen + 24;
	}
	else dwAllocSize = 1 + dwlen + 24;

	pAlloc = (BYTE *)HeapAlloc(g_hHeap_1001FE9C, 8, dwAllocSize);
	if (!pAlloc) return dwRet;

	*(PDWORD )pAlloc = a3;
	*(PWORD)(pAlloc + 4) = a4;
	*(PDWORD )(pAlloc + 8) = 1;
	*(BYTE *)(pAlloc + 0xC) = byVal;
	*(PDWORD )(pAlloc + 0x10) = dwlen + 1;
	*(PDWORD )(pAlloc + 0x14) = 0;

	if ( a2 == 1 )
	{
		*(PDWORD )(pAlloc + 0x10) = dwlen + 2;
		*(BYTE *)(pAlloc + 0x18) = a5>>8;
		*(BYTE *)(pAlloc + 0x19) = a5 & 0xFF;
		pSub = pAlloc + 0x1A;
	}
	else
	{
		*(BYTE *)(pAlloc + 0x18) = a5 & 0xFF;
		pSub = pAlloc + 0x19;
	}
	memcpy_s(pSub, dwAllocSize, Source, dwlen);
	dwRet = sub_10006910(g_hFile, 0xEA60A040, pAlloc, dwAllocSize, &devout, 0xC, &dwBytesReturn);
	if ( dwRet )
	{
		if ( tmpa3 != a3 )
		{
			sub_10004E80(a3, 255, 0, 0, 0, 1);
			ReleaseMutex(g_hMutex_1001FEB0);
		}
	}
	else
	{
		dwRet = sub_10006CC0(devout.nErrCode_0);
	}
	HeapFree(g_hHeap_1001FE9C, 0, pAlloc);
	return dwRet;
}

int sub_10009720(DWORD dwArg1, DWORD *pdwArg2)
{
	wchar_t *pszTmp; 
	wchar_t *pwTmp2; 
	DWORD i; 
	DWORD dwOut; 
	int dwRetCode; 
	DWORD RequiredSize;
	LPVOID lpMem; 
	size_t Count; 
	WCHAR Filename[264]; 
	OSVERSIONINFOW VersionInformation; 

	dwOut = 0;
	dwRetCode = 87;
	WaitForSingleObject(g_hMutex_1001FE94, 0xFFFFFFFF);
	VersionInformation.dwOSVersionInfoSize = 0x114;
	GetVersionExW(&VersionInformation);

	if ( pdwArg2 )
	{
		dwRetCode = 110;
		if ( VersionInformation.dwPlatformId == 2 )
		{
			Filename[0] = 0;
			GetModuleFileNameW(g_hModule_1001FE5C, Filename, 264);
			pszTmp = wcsrchr(Filename, '\\');
			if ( !pszTmp )
				pszTmp = wcsrchr(Filename, '//');
			pszTmp = pszTmp + 1;
			Count = 260 - ((size_t)pszTmp - (size_t)Filename);
			wcsncpy(pszTmp, L"kbsp.inf", Count);

			if ( dwArg1 )
			{
				dwRetCode = sub_100091E0(Filename, (BOOL*)&dwOut);
			}
			else
			{
				sub_10006B30();
				dwRetCode = sub_10009330(Filename, 0, (int*)&dwOut);
			}
			*pdwArg2 = dwOut;
			RequiredSize = 0;
			*(pszTmp - 1) = NULL; 
			if ( SetupGetInfFileListW(Filename, INF_STYLE_WIN4, 0, 0, &RequiredSize) )
			{
				lpMem = HeapAlloc(g_hHeap_1001FE9C, 8, 2 * RequiredSize);
				if ( lpMem )
				{
					pwTmp2 = (wchar_t *)lpMem;
					SetupGetInfFileListW(Filename, INF_STYLE_WIN4, (PWSTR)lpMem, RequiredSize, 0);
					*(pszTmp - 1) = '\\';
					for ( i = wcslen(pwTmp2); i; i = wcslen(pwTmp2) )
					{
						if ( _wcsicmp(pwTmp2, L"kbsp.inf") )
						{
							wcsncpy(pszTmp, pwTmp2, Count);
							sub_10009330(Filename, dwArg1, (int*)&dwOut);
							if ( !*pdwArg2 )
								*pdwArg2 = dwOut;
						}
						pwTmp2 += i + 1;
					}
					HeapFree(g_hHeap_1001FE9C, 0, lpMem);
				}
			}
		}
	}
	ReleaseMutex(g_hMutex_1001FE94);
	return dwRetCode;
}
///////////////////////////////0215///////////////////////////////////////////
DWORD	sub_10006E30()
{
	CSmbus_Def* pCSmbus_Def = new CSmbus_Def();
	pCSmbus_Def->m_dw1C = 0;
	pCSmbus_Def->m_funcstr20 = 0;
	pCSmbus_Def->m_lp24 = 0;
	return (DWORD)pCSmbus_Def;

}
LPVOID	sub_10009E70()
{
	CGpioDefaultProxy* pCGpioDefaultProxy = new CGpioDefaultProxy();
	pCGpioDefaultProxy->m_hHandle = g_hFile;
	return pCGpioDefaultProxy;
}
LPVOID sub_1000A710()
{

	HANDLE hHandle; 
	if ( sub_10006AC0((DWORD*)&hHandle, L"topcliffgpio") )
		return 0;
	hHandle = 0;
	if ( sub_10006980(&hHandle, (GUID *)&g_ClassGuid_1001AAA0) )
		return 0;
	CGpioDefaultProxy* pClass = new CGpioDefaultProxy();
	pClass->m_hHandle = hHandle;
	return pClass;

}
DWORD sub_10007DD0(DWORD dwArg1)
{
	CW83627DHGP* pW83627DHGP = (CW83627DHGP*)sub_1000AC60((WORD)dwArg1);
	CSuperIo* pSuperIo = dynamic_cast<CSuperIo*>((CSensor*)pW83627DHGP);
	return (DWORD)pSuperIo;
}
DWORD sub_1000C5A0(DWORD dwArg1)
{
	CAmdBrazos* pAmdBrazos = new CAmdBrazos();
	return (DWORD)pAmdBrazos;
}
DWORD sub_1000BDE0(DWORD dwArg1)
{
	BYTE byRet;
	if ( !g_pCSmbus_Def_1001FEA0 )
		return 0;

	byRet = 0;
	if ( ((CSmbus_Def*)g_pCSmbus_Def_1001FEA0)->sub_1000AA90(7, (BYTE)dwArg1, 254, &byRet, 1) )
		return 0;
	if ( byRet != 0xC3 )
		return 0;

	byRet = 0;
	if ( ((CSmbus_Def*)g_pCSmbus_Def_1001FEA0)->sub_1000AA90(7, (BYTE)dwArg1, 253, &byRet, 1) || byRet != 80 )
		return 0;

	CNCT7802* pNCT802 = new CNCT7802();
	if(pNCT802)
	{
		pNCT802->m_pSmbus_Def04 = (CSmbus_Def*)g_pCSmbus_Def_1001FEA0;
		pNCT802->m_by08 = (BYTE)dwArg1;
		if(pNCT802->sub_1000BEB0())
			return (DWORD)pNCT802;
		delete pNCT802;
		return NULL;

	}
	else  return NULL;

}
DWORD sub_1000AE10(DWORD dwArg1)
{

	BYTE byRet; 
	byRet = 0;
	if ( !g_pCSmbus_Def_1001FEA0 )
		return 0;

	if(((CSmbus_Def*)g_pCSmbus_Def_1001FEA0)->sub_1000AA90(7, (BYTE)dwArg1, 254, &byRet, 1) || byRet != 92)
		return 0;


	CW83L771Ax* pW83L771Ax = new CW83L771Ax();
	if(pW83L771Ax)
	{
		pW83L771Ax->m_pSmbus_Def4 = (CSmbus_Def*)g_pCSmbus_Def_1001FEA0;
		pW83L771Ax->m_by08 = (BYTE)dwArg1;
	}
	if(!pW83L771Ax) return 0;
	if(pW83L771Ax->sub_1000BEB0())
		return (DWORD)pW83L771Ax;
	delete pW83L771Ax;
	return 0;
}
DWORD sub_1000BBA0(DWORD dwArg1)
{

	BYTE byRet1; 
	if ( !g_pCSmbus_Def_1001FEA0 )
		return 0;

	byRet1 = 0;
	if(((CSmbus_Def*)g_pCSmbus_Def_1001FEA0)->sub_1000AA90(7, (BYTE)dwArg1, 62, &byRet1, 1)|| byRet1 != 65
		||((CSmbus_Def*)g_pCSmbus_Def_1001FEA0)->sub_1000AA90(7, (BYTE)dwArg1, 63, &byRet1, 1) || (byRet1 & 0xF0) != 96 )
	{
		return 0;
	}

	CAdt7490* pAdt7490 = new CAdt7490();
	if(pAdt7490)
	{
		pAdt7490->m_pSmbus_Def0C = (CSmbus_Def*)g_pCSmbus_Def_1001FEA0; 
		pAdt7490->m_by04 = (BYTE)dwArg1;
		pAdt7490->m_dw08 = 0;
		pAdt7490->m_dw10 = 0;
		pAdt7490->m_dw14 = 0;
		pAdt7490->m_by18 = 0;
		pAdt7490->m_dw1C = 0;
		if(pAdt7490->sub_1000BC80()) 
			return (DWORD)pAdt7490;
		delete pAdt7490; return NULL;
	}
	else return NULL;

}
DWORD sub_1000BAA0(DWORD dwArg1)
{

	BYTE byRet; 
	if ( !g_pCSmbus_Def_1001FEA0 )
		return 0;
	byRet = 0;
	if(((CSmbus_Def*)g_pCSmbus_Def_1001FEA0)->sub_1000AA90(7, (BYTE)dwArg1, 62, &byRet, 1) || byRet != 65 
		||((CSmbus_Def*)g_pCSmbus_Def_1001FEA0)->sub_1000AA90(7, (BYTE)dwArg1, 61, &byRet, 1) ||  byRet != 117)
	{
		return 0;
	}

	CAdt7475* pAdt7475 = new CAdt7475();
	pAdt7475->m_by04 = (BYTE)dwArg1;
	pAdt7475->m_dw08 = 0;
	pAdt7475->m_pSmbus_Def0C = (CSmbus_Def*)g_pCSmbus_Def_1001FEA0;
	pAdt7475->m_dw10 = 0;
	pAdt7475->m_dw14 = 0;
	pAdt7475->m_by18 = 0;
	pAdt7475->m_dw1C = 0;

	if ( !pAdt7475 )
		return NULL;

	if(pAdt7475->sub_1000B1E0())

		return (DWORD)pAdt7475;
	delete pAdt7475;
	return 0;

}

DWORD MySetupDiGetDeviceRegistryProperty_1000CB20(HDEVINFO DeviceInfoSet,PSP_DEVINFO_DATA DeviceInfoData,DWORD Property,PBYTE PropertyBuffer,
	DWORD PropertyBufferSize, PDWORD  RequiredSize)
{
	DWORD result; 

	if ( SetupDiGetDeviceRegistryPropertyW(	DeviceInfoSet,	DeviceInfoData,	Property,0,	PropertyBuffer,	PropertyBufferSize,	RequiredSize) )
	{
		return 0;
	}
	result = GetLastError();
	if ( result == ERROR_INSUFFICIENT_BUFFER )
		*RequiredSize *= 2;
	return result;
}
DWORD MySetupDiGetDeviceRegistryProperty_1000CB70(HDEVINFO DeviceInfoSet,PSP_DEVINFO_DATA DeviceInfoData,DWORD Property,PBYTE PropertyBuffer)
{
	if ( SetupDiGetDeviceRegistryPropertyW(DeviceInfoSet, DeviceInfoData, Property, 0, PropertyBuffer, 4, 0) )
		return 0;
	else
		return GetLastError();
}

