#include "stdafx.h"
#include "AmdBrazos.h"


CAmdBrazos::CAmdBrazos()
{
}


CAmdBrazos::~CAmdBrazos()
{
}


void CAmdBrazos::sub_1000CBD0()
{
}


void CAmdBrazos::sub_1000BEB0()
{
}
DWORD CAmdBrazos::sub_1000B290()
{
	return 4;
}

DWORD CAmdBrazos::sub_100081C0(DWORD i)
{
	return 1;
}


void CAmdBrazos::sub_10008200()
{
}


void CAmdBrazos::sub_10008250()
{
}


void CAmdBrazos::sub_100082B0()
{
}


void CAmdBrazos::sub_10008300()
{
}


void CAmdBrazos::sub_10008350()
{
}


void CAmdBrazos::sub_100083A0()
{
}


void CAmdBrazos::sub_1000C590()
{
}


void CAmdBrazos::sub_1000C5C0()
{
}


DWORD CAmdBrazos::_JidaVgaSetContrastEnable()
{
	return 1;
}


void CAmdBrazos::sub_1000C640()
{
}


void CAmdBrazos::_JidaVoltageSetLimits()
{
}


void CAmdBrazos::sub_1000C670()
{
}


void CAmdBrazos::sub_1000C600()
{
}


void CAmdBrazos::sub_1000C690()
{
}


DWORD CAmdBrazos::sub_10009DF0()
{
	return 1;
}
