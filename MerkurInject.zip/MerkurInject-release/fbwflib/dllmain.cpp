﻿// dllmain.cpp : Defines the entry point for the DLL application.
#include "pch.h"
#include <Windows.h>
#include <combaseapi.h>  // For CoUninitialize
#include <cstring>       // For memset

int __stdcall FbwfGetMemoryUsage(DWORD* outUsage)
{
	return false;
}

//for showing as fbwf is disabled.
BOOL __stdcall FbwfIsFilterEnabled(int *a1, int *a2)
{
	*a1 = 1;
	*a2 = 1;
	return FALSE;
}

int __stdcall FbwfSetCacheThreshold(int a1)
{
	return 0;
}

BOOL FbwfEnableFilter()
{
	return FALSE;
}

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     )
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}

