#!/usr/bin/env python3
"""Offline 12-digit license code generator (must match TimeLicense.cpp).
The game saves the license file next to the executable: dialog\\time.io
"""
import hashlib
import struct
import sys


def generate_code(machine_id_8: int, yymm: int) -> int:
    s = f"MerkurTLv1|{machine_id_8:08d}|{yymm % 10000:04d}".encode("ascii")
    h = hashlib.sha256(s).digest()
    v = struct.unpack("<Q", h[:8])[0] ^ struct.unpack("<Q", h[8:16])[0]
    return v % 10**12


def main() -> None:
    if len(sys.argv) != 3:
        print("Usage: license_keygen.py <machine_id_8_digits> <YYMM>", file=sys.stderr)
        print("Example: license_keygen.py 12345678 2604", file=sys.stderr)
        sys.exit(2)
    mid = int(sys.argv[1], 10)
    yymm = int(sys.argv[2], 10)
    if mid < 0 or mid > 99999999:
        print("machine id must be 0..99999999", file=sys.stderr)
        sys.exit(1)
    code = generate_code(mid, yymm)
    print(f"{code:012d}")


if __name__ == "__main__":
    main()
