// Offline utilities: duration license (matches tools/license_keygen.py / TimeLicense.cpp)
// and 15-value mmcode bet sequence (matches ADPInterface CryptoCard/mmcode.cpp).

#define NOMINMAX
#include <Windows.h>
#include <bcrypt.h>

#include <algorithm>
#include <cctype>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <random>
#include <string>
#include <vector>

#pragma comment(lib, "bcrypt.lib")

namespace {

bool Sha256Raw(const void* data, ULONG len, uint8_t out32[32]) {
    BCRYPT_ALG_HANDLE alg = nullptr;
    if (!BCRYPT_SUCCESS(BCryptOpenAlgorithmProvider(&alg, BCRYPT_SHA256_ALGORITHM, nullptr, 0)))
        return false;
    DWORD cb = 0;
    DWORD objLen = 0;
    if (!BCRYPT_SUCCESS(BCryptGetProperty(alg, BCRYPT_OBJECT_LENGTH, (PUCHAR)&objLen, sizeof(objLen), &cb, 0))) {
        BCryptCloseAlgorithmProvider(alg, 0);
        return false;
    }
    std::vector<UCHAR> obj(objLen);
    BCRYPT_HASH_HANDLE h = nullptr;
    if (!BCRYPT_SUCCESS(BCryptCreateHash(alg, &h, obj.data(), objLen, nullptr, 0, 0))) {
        BCryptCloseAlgorithmProvider(alg, 0);
        return false;
    }
    bool ok = BCRYPT_SUCCESS(BCryptHashData(h, (PUCHAR)data, len, 0))
        && BCRYPT_SUCCESS(BCryptFinishHash(h, out32, 32, 0));
    BCryptDestroyHash(h);
    BCryptCloseAlgorithmProvider(alg, 0);
    return ok;
}

// Same as TimeLicense::GenerateLicenseCode / license_keygen.py
bool GenerateLicenseCode(uint32_t machineId8, uint32_t yymm, uint64_t* outCode) {
    char buf[64];
    sprintf_s(buf, "MerkurTLv1|%08u|%04u", machineId8, yymm % 10000u);
    uint8_t h[32];
    if (!Sha256Raw(buf, (ULONG)strlen(buf), h))
        return false;
    uint64_t v = 0;
    memcpy(&v, h, sizeof(v));
    uint64_t v2 = 0;
    memcpy(&v2, h + 8, sizeof(v2));
    v ^= v2;
    *outCode = v % 1000000000000ULL;
    return true;
}

// Same as mmcode.cpp generate_fixed_values + mmcode_generate seeding
std::vector<uint8_t> GenerateMmcodeForDate(int year, int month, int day) {
    unsigned int seed = static_cast<unsigned int>(year * 10000 + month * 100 + day);
    std::mt19937 rng(seed);
    std::vector<uint8_t> values;
    values.reserve(15);
    values.insert(values.end(), 5, 20);
    values.insert(values.end(), 5, 40);
    values.insert(values.end(), 5, 100);
    std::shuffle(values.begin(), values.end(), rng);
    return values;
}

void PrintUsage() {
    std::cerr
        << "Usage:\n"
        << "  Keygen license <machine_id_8_digits> <YYMM>\n"
        << "      12-digit duration code (same as tools/license_keygen.py).\n"
        << "  Keygen mmcode <YYYY-MM-DD> | <YYYYMMDD>\n"
        << "      15 bet values (20/40/100) in order for that calendar date.\n";
}

bool ParseYymm(const char* s, uint32_t* out) {
    char* end = nullptr;
    unsigned long v = strtoul(s, &end, 10);
    if (!end || *end != '\0' || v > 99999999UL)
        return false;
    *out = static_cast<uint32_t>(v);
    return true;
}

bool ParseMachineId(const char* s, uint32_t* out) {
    char* end = nullptr;
    unsigned long v = strtoul(s, &end, 10);
    if (!end || *end != '\0' || v > 99999999UL)
        return false;
    *out = static_cast<uint32_t>(v);
    return true;
}

bool ParseUint2(const char* p, int* v) {
    if (!std::isdigit(static_cast<unsigned char>(p[0])) || !std::isdigit(static_cast<unsigned char>(p[1])))
        return false;
    *v = (p[0] - '0') * 10 + (p[1] - '0');
    return true;
}

bool ParseUint4(const char* p, int* v) {
    for (int i = 0; i < 4; ++i) {
        if (!std::isdigit(static_cast<unsigned char>(p[i])))
            return false;
    }
    *v = (p[0] - '0') * 1000 + (p[1] - '0') * 100 + (p[2] - '0') * 10 + (p[3] - '0');
    return true;
}

bool ParseDateArg(const std::string& arg, int* y, int* m, int* d) {
    if (arg.size() == 8) {
        for (char c : arg) {
            if (!std::isdigit(static_cast<unsigned char>(c)))
                return false;
        }
        return ParseUint4(arg.data(), y) && ParseUint2(arg.data() + 4, m) && ParseUint2(arg.data() + 6, d);
    }
    if (arg.size() == 10 && arg[4] == '-' && arg[7] == '-') {
        return ParseUint4(arg.data(), y) && ParseUint2(arg.data() + 5, m) && ParseUint2(arg.data() + 8, d);
    }
    return false;
}

bool ValidYmd(int year, int month, int day) {
    if (month < 1 || month > 12 || day < 1 || day > 31)
        return false;
    static const int mdays[] = { 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
    if (day > mdays[month - 1])
        return false;
    if (month == 2 && day == 29) {
        bool leap = (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
        if (!leap)
            return false;
    }
    return true;
}

} // namespace

int main(int argc, char* argv[]) {
    if (argc < 2) {
        PrintUsage();
        return 2;
    }

    const std::string cmd = argv[1];

    if (cmd == "license") {
        if (argc != 4) {
            PrintUsage();
            return 2;
        }
        uint32_t mid = 0, yymm = 0;
        if (!ParseMachineId(argv[2], &mid) || !ParseYymm(argv[3], &yymm)) {
            std::cerr << "machine_id and YYMM must be decimal, machine_id 0..99999999\n";
            return 1;
        }
        uint64_t code = 0;
        if (!GenerateLicenseCode(mid, yymm, &code)) {
            std::cerr << "SHA-256 failed\n";
            return 1;
        }
        char out[16];
        sprintf_s(out, "%012llu", static_cast<unsigned long long>(code));
        std::cout << out << '\n';
        return 0;
    }

    if (cmd == "mmcode") {
        if (argc != 3) {
            PrintUsage();
            return 2;
        }
        int y = 0, m = 0, d = 0;
        if (!ParseDateArg(argv[2], &y, &m, &d) || !ValidYmd(y, m, d)) {
            std::cerr << "Invalid date; use YYYY-MM-DD or YYYYMMDD\n";
            return 1;
        }
        std::vector<uint8_t> seq = GenerateMmcodeForDate(y, m, d);
        for (size_t i = 0; i < seq.size(); ++i) {
            if (i)
                std::cout << ' ';
            std::cout << static_cast<int>(seq[i]);
        }
        std::cout << '\n';
        return 0;
    }

    PrintUsage();
    return 2;
}
