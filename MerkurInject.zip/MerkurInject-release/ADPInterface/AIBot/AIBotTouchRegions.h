#pragma once
#include <Windows.h>

// Duplicated from StateMachine.cpp touch regions (LB/RT corners) for synthetic taps.

#define AIBOT_CardGamble_half_LB_x_reel   0x02
#define AIBOT_CardGamble_half_LB_x_pos    0xD9
#define AIBOT_CardGamble_half_LB_y_row    0x00
#define AIBOT_CardGamble_half_LB_y_pos    0xCC
#define AIBOT_CardGamble_half_RT_x_reel   0x03
#define AIBOT_CardGamble_half_RT_x_pos    0x2B
#define AIBOT_CardGamble_half_RT_y_row    0x00
#define AIBOT_CardGamble_half_RT_y_pos    0xF4

#define AIBOT_CardGamble_risiko_LB_x_reel   0x02
#define AIBOT_CardGamble_risiko_LB_x_pos    0xD7
#define AIBOT_CardGamble_risiko_LB_y_row    0x00
#define AIBOT_CardGamble_risiko_LB_y_pos    0x95
#define AIBOT_CardGamble_risiko_RT_x_reel   0x03
#define AIBOT_CardGamble_risiko_RT_x_pos    0x2B
#define AIBOT_CardGamble_risiko_RT_y_row    0x00
#define AIBOT_CardGamble_risiko_RT_y_pos    0xBD

#define AIBOT_CardGamble_black_LB_x_reel   0x02
#define AIBOT_CardGamble_black_LB_x_pos    0x2B
#define AIBOT_CardGamble_black_LB_y_row    0x00
#define AIBOT_CardGamble_black_LB_y_pos    0x9C
#define AIBOT_CardGamble_black_RT_x_reel   0x02
#define AIBOT_CardGamble_black_RT_x_pos    0x84
#define AIBOT_CardGamble_black_RT_y_row    0x00
#define AIBOT_CardGamble_black_RT_y_pos    0xF3

#define AIBOT_CardGamble_red_LB_x_reel   0x01
#define AIBOT_CardGamble_red_LB_x_pos    0xA8
#define AIBOT_CardGamble_red_LB_y_row    0x00
#define AIBOT_CardGamble_red_LB_y_pos    0x9B
#define AIBOT_CardGamble_red_RT_x_reel   0x02
#define AIBOT_CardGamble_red_RT_x_pos    0x02
#define AIBOT_CardGamble_red_RT_y_row    0x00
#define AIBOT_CardGamble_red_RT_y_pos    0xF3

#define AIBOT_Risiko_card_LB_x_reel   0x03
#define AIBOT_Risiko_card_LB_x_pos    0x13
#define AIBOT_Risiko_card_LB_y_row    0x00
#define AIBOT_Risiko_card_LB_y_pos    0x9a
#define AIBOT_Risiko_card_RT_x_reel   0x03
#define AIBOT_Risiko_card_RT_x_pos    0x67
#define AIBOT_Risiko_card_RT_y_row    0x00
#define AIBOT_Risiko_card_RT_y_pos    0xc1

#define AIBOT_Risiko_down_LB_x_reel   0x02
#define AIBOT_Risiko_down_LB_x_pos    0x47
#define AIBOT_Risiko_down_LB_y_row    0x00
#define AIBOT_Risiko_down_LB_y_pos    0x99
#define AIBOT_Risiko_down_RT_x_reel   0x02
#define AIBOT_Risiko_down_RT_x_pos    0x9A
#define AIBOT_Risiko_down_RT_y_row    0x00
#define AIBOT_Risiko_down_RT_y_pos    0xc2

#define AIBOT_Magic_1000_LB_x_reel   0x01
#define AIBOT_Magic_1000_LB_x_pos    0x11
#define AIBOT_Magic_1000_LB_y_row    0x00
#define AIBOT_Magic_1000_LB_y_pos    0xC7
#define AIBOT_Magic_1000_RT_x_reel   0x02
#define AIBOT_Magic_1000_RT_x_pos    0xAA
#define AIBOT_Magic_1000_RT_y_row    0x01
#define AIBOT_Magic_1000_RT_y_pos    0x26

#define AIBOT_Magic_AG_LB_x_reel   0x01
#define AIBOT_Magic_AG_LB_x_pos    0x11
#define AIBOT_Magic_AG_LB_y_row    0x01
#define AIBOT_Magic_AG_LB_y_pos    0x5E
#define AIBOT_Magic_AG_RT_x_reel   0x02
#define AIBOT_Magic_AG_RT_x_pos    0xAA
#define AIBOT_Magic_AG_RT_y_row    0x01
#define AIBOT_Magic_AG_RT_y_pos    0xC6

#define AIBOT_LosFrootos_betup_LB_x_reel   0x02
#define AIBOT_LosFrootos_betup_LB_x_pos    0x4E
#define AIBOT_LosFrootos_betup_LB_y_row    0x00
#define AIBOT_LosFrootos_betup_LB_y_pos    0xD0
#define AIBOT_LosFrootos_betup_RT_x_reel   0x02
#define AIBOT_LosFrootos_betup_RT_x_pos    0x6F
#define AIBOT_LosFrootos_betup_RT_y_row    0x00
#define AIBOT_LosFrootos_betup_RT_y_pos    0xE6

#define AIBOT_LosFrootos_betdown_LB_x_reel   0x01
#define AIBOT_LosFrootos_betdown_LB_x_pos    0x56
#define AIBOT_LosFrootos_betdown_LB_y_row    0x00
#define AIBOT_LosFrootos_betdown_LB_y_pos    0xCD
#define AIBOT_LosFrootos_betdown_RT_x_reel   0x01
#define AIBOT_LosFrootos_betdown_RT_x_pos    0x77
#define AIBOT_LosFrootos_betdown_RT_y_row    0x00
#define AIBOT_LosFrootos_betdown_RT_y_pos    0xE6

#define AIBOT_LosFrootos_close_LB_x_reel   0x01
#define AIBOT_LosFrootos_close_LB_x_pos    0x3D
#define AIBOT_LosFrootos_close_LB_y_row    0x01
#define AIBOT_LosFrootos_close_LB_y_pos    0x0D
#define AIBOT_LosFrootos_close_RT_x_reel   0x01
#define AIBOT_LosFrootos_close_RT_x_pos    0x93
#define AIBOT_LosFrootos_close_RT_y_row    0x01
#define AIBOT_LosFrootos_close_RT_y_pos    0x3A

#define AIBOT_LosFrootos_go_LB_x_reel   0x02
#define AIBOT_LosFrootos_go_LB_x_pos    0x2F
#define AIBOT_LosFrootos_go_LB_y_row    0x01
#define AIBOT_LosFrootos_go_LB_y_pos    0x0B
#define AIBOT_LosFrootos_go_RT_x_reel   0x02
#define AIBOT_LosFrootos_go_RT_x_pos    0x85
#define AIBOT_LosFrootos_go_RT_y_row    0x01
#define AIBOT_LosFrootos_go_RT_y_pos    0x3C

#define AIBOT_Pharos_betup_LB_x_reel 0x02
#define AIBOT_Pharos_betup_LB_x_pos 0x3F
#define AIBOT_Pharos_betup_LB_y_row 0x00
#define AIBOT_Pharos_betup_LB_y_pos 0xC1
#define AIBOT_Pharos_betup_RT_x_reel 0x02
#define AIBOT_Pharos_betup_RT_x_pos 0x92
#define AIBOT_Pharos_betup_RT_y_row 0x01
#define AIBOT_Pharos_betup_RT_y_pos 0x44

#define AIBOT_Pharos_betdown_LB_x_reel 0x01
#define AIBOT_Pharos_betdown_LB_x_pos 0x3A
#define AIBOT_Pharos_betdown_LB_y_row 0x00
#define AIBOT_Pharos_betdown_LB_y_pos 0xC1
#define AIBOT_Pharos_betdown_RT_x_reel 0x01
#define AIBOT_Pharos_betdown_RT_x_pos 0x81
#define AIBOT_Pharos_betdown_RT_y_row 0x00
#define AIBOT_Pharos_betdown_RT_y_pos 0xF3

#define AIBOT_Pharos_close_LB_x_reel 0x01
#define AIBOT_Pharos_close_LB_x_pos 0x2C
#define AIBOT_Pharos_close_LB_y_row 0x01
#define AIBOT_Pharos_close_LB_y_pos 0x07
#define AIBOT_Pharos_close_RT_x_reel 0x01
#define AIBOT_Pharos_close_RT_x_pos 0xA7
#define AIBOT_Pharos_close_RT_y_row 0x01
#define AIBOT_Pharos_close_RT_y_pos 0x42

#define AIBOT_Pharos_go_LB_x_reel 0x02
#define AIBOT_Pharos_go_LB_x_pos 0x1A
#define AIBOT_Pharos_go_LB_y_row 0x01
#define AIBOT_Pharos_go_LB_y_pos 0x07
#define AIBOT_Pharos_go_RT_x_reel 0x02
#define AIBOT_Pharos_go_RT_x_pos 0x93
#define AIBOT_Pharos_go_RT_y_row 0x01
#define AIBOT_Pharos_go_RT_y_pos 0x42

#define AIBOT_Dragon_SIEGFR_LB_x_reel   0x01
#define AIBOT_Dragon_SIEGFR_LB_x_pos    0xAA
#define AIBOT_Dragon_SIEGFR_LB_y_row    0x01
#define AIBOT_Dragon_SIEGFR_LB_y_pos    0x84
#define AIBOT_Dragon_SIEGFR_RT_x_reel   0x02
#define AIBOT_Dragon_SIEGFR_RT_x_pos    0x17
#define AIBOT_Dragon_SIEGFR_RT_y_row    0x01
#define AIBOT_Dragon_SIEGFR_RT_y_pos    0xE8

#define AIBOT_Dragon_HAGEN_LB_x_reel   0x01
#define AIBOT_Dragon_HAGEN_LB_x_pos    0xB0
#define AIBOT_Dragon_HAGEN_LB_y_row    0x01
#define AIBOT_Dragon_HAGEN_LB_y_pos    0x1B
#define AIBOT_Dragon_HAGEN_RT_x_reel   0x02
#define AIBOT_Dragon_HAGEN_RT_x_pos    0x15
#define AIBOT_Dragon_HAGEN_RT_y_row    0x01
#define AIBOT_Dragon_HAGEN_RT_y_pos    0x78

#define AIBOT_Dragon_SCHATZ_LB_x_reel   0x01
#define AIBOT_Dragon_SCHATZ_LB_x_pos    0x20
#define AIBOT_Dragon_SCHATZ_LB_y_row    0x01
#define AIBOT_Dragon_SCHATZ_LB_y_pos    0x7A
#define AIBOT_Dragon_SCHATZ_RT_x_reel   0x01
#define AIBOT_Dragon_SCHATZ_RT_x_pos    0x7F
#define AIBOT_Dragon_SCHATZ_RT_y_row    0x01
#define AIBOT_Dragon_SCHATZ_RT_y_pos    0xD6

#define AIBOT_Dragon_SCHWER_LB_x_reel   0x02
#define AIBOT_Dragon_SCHWER_LB_x_pos    0x41
#define AIBOT_Dragon_SCHWER_LB_y_row    0x01
#define AIBOT_Dragon_SCHWER_LB_y_pos    0x7C
#define AIBOT_Dragon_SCHWER_RT_x_reel   0x02
#define AIBOT_Dragon_SCHWER_RT_x_pos    0x9E
#define AIBOT_Dragon_SCHWER_RT_y_row    0x01
#define AIBOT_Dragon_SCHWER_RT_y_pos    0xDA

#define AIBOT_Dragon_A_LB_x_reel   0x01
#define AIBOT_Dragon_A_LB_x_pos    0x21
#define AIBOT_Dragon_A_LB_y_row    0x01
#define AIBOT_Dragon_A_LB_y_pos    0x10
#define AIBOT_Dragon_A_RT_x_reel   0x01
#define AIBOT_Dragon_A_RT_x_pos    0x77
#define AIBOT_Dragon_A_RT_y_row    0x01
#define AIBOT_Dragon_A_RT_y_pos    0x66

#define AIBOT_Dragon_K_LB_x_reel   0x02
#define AIBOT_Dragon_K_LB_x_pos    0x44
#define AIBOT_Dragon_K_LB_y_row    0x01
#define AIBOT_Dragon_K_LB_y_pos    0x10
#define AIBOT_Dragon_K_RT_x_reel   0x02
#define AIBOT_Dragon_K_RT_x_pos    0x93
#define AIBOT_Dragon_K_RT_y_row    0x01
#define AIBOT_Dragon_K_RT_y_pos    0x6A

#define AIBOT_Dragon_Q_LB_x_reel   0x01
#define AIBOT_Dragon_Q_LB_x_pos    0x31
#define AIBOT_Dragon_Q_LB_y_row    0x00
#define AIBOT_Dragon_Q_LB_y_pos    0xB6
#define AIBOT_Dragon_Q_RT_x_reel   0x01
#define AIBOT_Dragon_Q_RT_x_pos    0x77
#define AIBOT_Dragon_Q_RT_y_row    0x01
#define AIBOT_Dragon_Q_RT_y_pos    0x06

#define AIBOT_Dragon_J_LB_x_reel   0x01
#define AIBOT_Dragon_J_LB_x_pos    0xBD
#define AIBOT_Dragon_J_LB_y_row    0x00
#define AIBOT_Dragon_J_LB_y_pos    0xBE
#define AIBOT_Dragon_J_RT_x_reel   0x02
#define AIBOT_Dragon_J_RT_x_pos    0x08
#define AIBOT_Dragon_J_RT_y_row    0x01
#define AIBOT_Dragon_J_RT_y_pos    0x12

#define AIBOT_Dragon_10_LB_x_reel   0x02
#define AIBOT_Dragon_10_LB_x_pos    0x45
#define AIBOT_Dragon_10_LB_y_row    0x00
#define AIBOT_Dragon_10_LB_y_pos    0xB5
#define AIBOT_Dragon_10_RT_x_reel   0x02
#define AIBOT_Dragon_10_RT_x_pos    0x9A
#define AIBOT_Dragon_10_RT_y_row    0x01
#define AIBOT_Dragon_10_RT_y_pos    0x07
