#pragma once

#include <atomic>

void AIBot_RunStrategyTick(std::atomic<bool>& stopRequested);
void AIBot_ResetPayoutSession();
