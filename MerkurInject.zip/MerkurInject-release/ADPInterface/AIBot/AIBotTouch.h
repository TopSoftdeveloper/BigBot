#pragma once

#include <Windows.h>

void AIBot_TapBox(UINT8 lb_reel, UINT8 lb_x, UINT8 lb_row, UINT8 lb_y,
	UINT8 rt_reel, UINT8 rt_x, UINT8 rt_row, UINT8 rt_y);

void AIBot_TapChangeWinLine(UINT16 gameId);
