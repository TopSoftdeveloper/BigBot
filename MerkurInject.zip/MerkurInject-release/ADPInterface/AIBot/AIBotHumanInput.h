#pragma once

// Synthetic keyboard: SendInput → low-level keyboard hook → CryptoCard::HandleNumpadAction (same as physical numpad).
void AIBot_HumanBetChange();
void AIBot_HumanMaxBet();
void AIBot_HumanSpin();
void AIBot_HumanFastSpin();
void AIBot_HumanToggleAutoSpin();
void AIBot_HumanReturnToMenu();
void AIBot_HumanNumpad1();
// Same as user pressing numpad * three times (opens payout dialog).
void AIBot_HumanPayoutHotkey();
