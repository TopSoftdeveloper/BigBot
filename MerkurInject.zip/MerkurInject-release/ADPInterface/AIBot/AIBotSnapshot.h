#pragma once

#include <Windows.h>

struct AIBotSnapshot {
	int status = 0;
	UINT16 gameId = 0;
	UINT32 bankBit = 0;
	UINT32 spinBetBit = 0;
	UINT32 bonusCoin = 0;
	BOOL freeMode = FALSE;
	BOOL multoGo = FALSE;
	BOOL autoSpin = FALSE;
	BOOL cardGambleOpen = FALSE;
	BOOL cardGambleFinished = FALSE;
	BOOL cardGambleSwapEnable = FALSE;
	UINT32 cardGambleLevel = 0;
	BOOL risikoOpen = FALSE;
	BOOL risikoFinished = FALSE;
	double sessionRTP = 0.0;
	double targetRTP = 0.0;
	double totalBet = 0.0;
	double totalWin = 0.0;
	double playDbCredit = 0.0;
	double mainBookBet = 0.0;
	double mainBookWin = 0.0;
	int betStep = 0;
	int betCount = 0;
	UINT16 currentBetBit = 0;
	int winLine = 0;
	BOOL inGame = FALSE;
	BOOL reelGameValid = FALSE;
};

void AIBot_FillSnapshot(AIBotSnapshot& out);
