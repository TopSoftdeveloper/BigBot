#include "stdafx.h"
#include "AIBotTouch.h"
#include "AIBotInput.h"
#include "CryptoCard/StateMachine.h"
#include "CryptoCard/Game/ReelGame.h"

// Cabinet touch / pointer: routes through StateMachine::MousePressed (same as physical panel coordinates).

static UINT8 MidUint8(UINT8 a, UINT8 b)
{
	return static_cast<UINT8>((static_cast<unsigned>(a) + static_cast<unsigned>(b)) / 2u);
}

void AIBot_TapBox(UINT8 lb_reel, UINT8 lb_x, UINT8 lb_row, UINT8 lb_y,
	UINT8 rt_reel, UINT8 rt_x, UINT8 rt_row, UINT8 rt_y)
{
	MousePosition a{};
	a.x.region = lb_reel;
	a.x.pos = lb_x;
	a.y.region = lb_row;
	a.y.pos = lb_y;
	MousePosition b{};
	b.x.region = rt_reel;
	b.x.pos = rt_x;
	b.y.region = rt_row;
	b.y.pos = rt_y;

	UINT8 mx_reel = lb_reel;
	UINT8 mx_pos = lb_x;
	if (lb_reel == rt_reel) {
		mx_pos = MidUint8(lb_x, rt_x);
	}
	else if (lb_reel < rt_reel) {
		mx_reel = lb_reel;
		{
			int t = static_cast<int>(lb_x) + 24;
			mx_pos = static_cast<UINT8>(t > 255 ? 255 : t);
		}
	}
	else {
		mx_reel = rt_reel;
		{
			int t = static_cast<int>(rt_x) - 8;
			mx_pos = static_cast<UINT8>(t < 1 ? 1 : t);
		}
	}

	UINT8 my_row = lb_row;
	UINT8 my_pos = lb_y;
	if (lb_row == rt_row) {
		my_pos = MidUint8(lb_y, rt_y);
	}
	else if (lb_row < rt_row) {
		my_row = lb_row;
		{
			int t = static_cast<int>(lb_y) + 24;
			my_pos = static_cast<UINT8>(t > 255 ? 255 : t);
		}
	}
	else {
		my_row = rt_row;
		{
			int t = static_cast<int>(rt_y) - 8;
			my_pos = static_cast<UINT8>(t < 1 ? 1 : t);
		}
	}

	MousePosition tap{};
	tap.x.region = mx_reel;
	tap.x.pos = mx_pos;
	tap.y.region = my_row;
	tap.y.pos = my_pos;

	if (!IsMouseWithin(tap, a, b)) {
		tap.x.region = lb_reel;
		tap.x.pos = lb_x;
		tap.y.region = lb_row;
		tap.y.pos = lb_y;
	}

	g_StateMachine.MousePressed(tap.x.region, tap.x.pos, tap.y.region, tap.y.pos);
	AIBot_PauseAfterAction();
}

void AIBot_TapChangeWinLine(UINT16 gameId)
{
	switch (gameId) {
	case GOC_RgTotemChiefPlus:
		AIBot_TapBox(0x03, 0x26, 0x02, 0x16, 0x03, 0x62, 0x02, 0x50);
		break;
	case GOC_RgPyramidsDeluxe:
		AIBot_TapBox(0x03, 0x13, 0x02, 0x18, 0x03, 0x4E, 0x02, 0x52);
		break;
	case GOC_RgMultiSevenWild:
		AIBot_TapBox(0x02, 0xFA, 0x02, 0x1C, 0x03, 0x46, 0x02, 0x52);
		break;
	case GOC_RgMagicMirrorDeluxe2:
		AIBot_TapBox(0x03, 0x28, 0x02, 0x18, 0x03, 0x62, 0x02, 0x52);
		break;
	case GOC_RgKongsTemple:
		AIBot_TapBox(0x03, 0x26, 0x02, 0x17, 0x03, 0x62, 0x02, 0x50);
		break;
	case GOC_RgIndianRuby:
		AIBot_TapBox(0x03, 0x27, 0x02, 0x18, 0x03, 0x62, 0x02, 0x4F);
		break;
	case GOC_RgGongHei:
		AIBot_TapBox(0x03, 0x28, 0x02, 0x17, 0x03, 0x61, 0x02, 0x50);
		break;
	case GOC_RgEyeOfHorus:
		AIBot_TapBox(0x03, 0x28, 0x02, 0x16, 0x03, 0x61, 0x02, 0x50);
		break;
	case GOC_RgConvertusAurum:
		AIBot_TapBox(0x03, 0x28, 0x02, 0x17, 0x03, 0x61, 0x02, 0x50);
		break;
	case GOC_RgBookOfFire:
		AIBot_TapBox(0x03, 0x25, 0x02, 0x16, 0x03, 0x62, 0x02, 0x50);
		break;
	default:
		break;
	}
}
