#pragma once

#include <Windows.h>
#include <string>

UINT16 AIBot_ResolveGameGoc(const std::string& playDbGameName);
