#pragma once

void AIBot_Start();
void AIBot_Stop();
bool AIBot_IsRunning();

// Set before triggering payout (3x *); PayoutDlgProc consumes and auto-completes payout.
void AIBot_RequestAutoPayout();
bool AIBot_TakeAutoPayoutRequest();
void AIBot_CancelAutoPayoutRequest();
bool AIBot_IsAutoPayoutPending();
