#include "stdafx.h"
#include "AIBotHumanInput.h"
#include "AIBotInput.h"
#include "AIBot.h"
#include "CryptoCard/CryptoCard.h"

void AIBot_HumanBetChange()
{
	AIBot_KeyTapVk(VK_NUMPAD4);
}

void AIBot_HumanMaxBet()
{
	AIBot_KeyTapVk(VK_NUMPAD1);
}

void AIBot_HumanSpin()
{
	AIBot_KeyTapVk(VK_NUMPAD5);
}

void AIBot_HumanFastSpin()
{
	AIBot_KeyTapVk(VK_NUMPAD5);
	Sleep(60);
	AIBot_KeyTapVk(VK_NUMPAD5);
}

void AIBot_HumanToggleAutoSpin()
{
	AIBot_KeyTapVk(VK_NUMPAD6);
}

void AIBot_HumanReturnToMenu()
{
	AIBot_KeyTapVk(VK_NUMPAD7);
}

void AIBot_HumanNumpad1()
{
	AIBot_KeyTapVk(VK_NUMPAD1);
}

void AIBot_HumanPayoutHotkey()
{
	AIBot_RequestAutoPayout();
	CryptoCard& card = CryptoCard::GetInstance();
	card.HandleAsteriskSequence();
	card.HandleAsteriskSequence();
	card.HandleAsteriskSequence();
	if (AIBot_IsAutoPayoutPending()) {
		AIBot_CancelAutoPayoutRequest();
	}
}
