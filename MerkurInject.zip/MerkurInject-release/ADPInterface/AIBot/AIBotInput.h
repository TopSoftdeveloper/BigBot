#pragma once

#include <Windows.h>

// SendInput(KEYDOWN/KEYUP) → WH_KEYBOARD_LL → CryptoCard::HandleNumpadAction (same path as real numpad).
void AIBot_KeyTapVk(DWORD vk);

// Human-like gap after a key or touch (~0.3s).
void AIBot_PauseAfterAction();
