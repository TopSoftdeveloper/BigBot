#include "stdafx.h"
#include "AIBotInput.h"

namespace {
constexpr DWORD kAIBotActionPauseMs = 300;
}

void AIBot_PauseAfterAction()
{
	Sleep(kAIBotActionPauseMs);
}

void AIBot_KeyTapVk(DWORD vk)
{
	INPUT down{};
	down.type = INPUT_KEYBOARD;
	down.ki.wVk = static_cast<WORD>(vk);
	SendInput(1, &down, sizeof(INPUT));

	INPUT up{};
	up.type = INPUT_KEYBOARD;
	up.ki.wVk = static_cast<WORD>(vk);
	up.ki.dwFlags = KEYEVENTF_KEYUP;
	SendInput(1, &up, sizeof(INPUT));

	AIBot_PauseAfterAction();
}
