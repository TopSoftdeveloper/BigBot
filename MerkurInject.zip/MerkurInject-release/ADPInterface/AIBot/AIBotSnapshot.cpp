#include "stdafx.h"
#include "AIBotSnapshot.h"
#include "CryptoCard/StateMachine.h"
#include "CryptoCard/PlayDB.h"
#include "CryptoCard/Game/ReelGame.h"

extern std::atomic<double> gTotalWin;
extern std::atomic<double> gTotalBet;
extern double gTargetRTP;

void AIBot_FillSnapshot(AIBotSnapshot& out)
{
	out.status = g_StateMachine.GetStatus();
	out.gameId = g_StateMachine.m_nGameID;
	out.bankBit = g_StateMachine.m_nBankBit;
	out.spinBetBit = g_StateMachine.m_nSpinBetBit;
	out.bonusCoin = g_StateMachine.m_nBonusBit.coin;
	out.freeMode = g_StateMachine.m_bFreeMode;
	out.multoGo = g_StateMachine.m_bMultoGo;
	out.autoSpin = g_StateMachine.m_bAutoSpin;
	out.cardGambleOpen = g_StateMachine.m_CardGamble.bOpen;
	out.cardGambleFinished = g_StateMachine.m_CardGamble.bFinished;
	out.cardGambleSwapEnable = g_StateMachine.m_CardGamble.bSwapEnable;
	out.cardGambleLevel = g_StateMachine.m_CardGamble.nRisikoLevel;
	out.risikoOpen = g_StateMachine.m_Risiko.bOpen;
	out.risikoFinished = g_StateMachine.m_Risiko.bFinished;
	out.targetRTP = gTargetRTP;
	out.totalBet = gTotalBet.load();
	out.totalWin = gTotalWin.load();
	if (out.totalBet > 0.0) {
		out.sessionRTP = out.totalWin / out.totalBet;
	}
	else {
		out.sessionRTP = 0.0;
	}

	PlayDB& db = PlayDB::GetInstance();
	out.playDbCredit = db.GetGameCreditData();
	db.GetMainBookTotalBetandWin(out.mainBookBet, out.mainBookWin);

	out.reelGameValid = (g_ReelGame != nullptr);
	out.inGame = (out.status >= STATUS_PendingSpin);
	if (g_ReelGame) {
		out.betStep = g_ReelGame->BetStep();
		out.betCount = static_cast<int>(g_ReelGame->Bets().size());
		out.currentBetBit = g_ReelGame->BetBit();
		out.winLine = g_ReelGame->GetWinLine();
	}
	else {
		out.betStep = 0;
		out.betCount = 0;
		out.currentBetBit = 0;
		out.winLine = 0;
	}
}
