#include "stdafx.h"
#include "AIBotGameCatalog.h"
#include "CryptoCard/Game/ReelGame.h"

UINT16 AIBot_ResolveGameGoc(const std::string& name)
{
	if (name == "RgLosFrootos") return GOC_RgLosFrootos;
	if (name == "RgEyeOfHorus") return GOC_RgEyeOfHorus;
	if (name == "RgGongHei") return GOC_RgGongHei;
	if (name == "RgMultiWild243") return GOC_RgMultiWild243;
	if (name == "RgPyramidsDeluxe") return GOC_RgPyramidsDeluxe;
	if (name == "RgGoldCup") return GOC_RgGoldCup;
	if (name == "RgMagicMirrorDeluxe2") return GOC_RgMagicMirrorDeluxe2;
	if (name == "RgKongsTemple") return GOC_RgKongsTemple;
	if (name == "RgMultiSevenWild") return GOC_RgMultiSevenWild;
	if (name == "RgDoppelBuch") return GOC_RgDoubleBook;
	if (name == "RgElToreroMG") return GOC_RgElToreroMG;
	if (name == "RgFruitinator") return GOC_RgFruitinator;
	if (name == "RgHotFrootastic") return GOC_RgHotFrootastic;
	if (name == "RgTripleTripleChance") return GOC_RgTripleTripleChance;
	if (name == "RgMerkurMagnus") return GOC_RgMerkurMagnus;
	if (name == "RgTotemChiefPlus") return GOC_RgTotemChiefPlus;
	if (name == "RgJokersCap") return GOC_RgJokersCap;
	if (name == "RgBlazingStar") return GOC_RgBlazingSun;
	if (name == "RgDragonsTreasure") return GOC_RgDragonsTreas;
	if (name == "RgBookOfFire") return GOC_RgBookOfFire;
	if (name == "RgExtraWild") return GOC_RgExtraWild;
	if (name == "RgCairoCasino") return GOC_RgCairoCasino;
	if (name == "RgRisingLiner") return GOC_RgRisingLiner;
	if (name == "RgKeyOfTheNile") return GOC_RgKeyOfTheNile;
	if (name == "RgPyramidOfPower") return GOC_RgPyramidOfPower;
	if (name == "RgConvertusAurum") return GOC_RgConvertusAurum;
	if (name == "RgGladiators") return GOC_RgGl;
	if (name == "RgLegacyOfFire") return GOC_RgLegacyOfFire;
	if (name == "RgIndianRuby") return GOC_RgIndianRuby;
	if (name == "RgLuckyPharaoh") return GOC_RgPharosGoldBase;
	return 0;
}
