#include "stdafx.h"
#include "AIBot.h"
#include "AIBotStrategy.h"
#include "AIBotSnapshot.h"
#include "AIBotTouch.h"
#include "AIBotTouchRegions.h"
#include "AIBotHumanInput.h"
#include "AIBotInput.h"
#include "AIBotGameCatalog.h"
#include "Utils.h"
#include "CryptoCard/CryptoCard.h"
#include "CryptoCard/KomProtocol.h"
#include "CryptoCard/StateMachine.h"
#include "CryptoCard/PlayDB.h"
#include "CryptoCard/Game/ReelGame.h"
#include <atomic>
#include <limits>
#include <string>

UINT32 g_sessionInsertedCredits = 0;
bool g_payoutPending = false;

namespace {

constexpr UINT32 kChargeAmount = 10000;
constexpr double kPayoutProfitFraction = 0.5;
constexpr DWORD kLobbyAfterGameTransitionMs = 7000;
constexpr DWORD kPayoutAfterActionMs = 1200;
constexpr UINT64 kLobbyCooldownMs = 2000;
constexpr UINT64 kActionCooldownMs = 320;
// Spin() in these states runs MoveBonus / free-game flow (same as player pressing GO after a win).
constexpr UINT64 kWinCollectCooldownMs = 280;

UINT64 g_lastActionMs = 0;
UINT64 g_lastLobbyMs = 0;
UINT64 g_lastFastSpinMs = 0;
UINT64 g_lastBetShuffleMs = 0;
UINT64 g_lastAutospinToggleMs = 0;
UINT64 g_lastWinLinePickMs = 0;
UINT64 g_gameSessionStartMs = 0;
UINT32 g_spinsThisSession = 0;
int s_wasInLobby = 1;
int s_prevAIBotStatus = -1;

int RandomMod(int maxExclusive)
{
	if (maxExclusive <= 0) {
		return 0;
	}
	const UINT64 span = 100000000ULL; // 10000 * 10000 (myRandom base squared)
	const UINT64 limit = span - (span % static_cast<UINT64>(maxExclusive));
	UINT64 v = 0;
	do {
		v = static_cast<UINT64>(myRandom()) * 10000ULL + static_cast<UINT64>(myRandom());
	} while (v >= limit);
	return static_cast<int>(v % static_cast<UINT64>(maxExclusive));
}

bool CooldownReady(UINT64 now, UINT64& last, UINT64 cd)
{
	if (now - last < cd) {
		return false;
	}
	last = now;
	return true;
}

void RecordBotCreditInsert(UINT32 amount)
{
	if (amount > 0) {
		g_sessionInsertedCredits += amount;
	}
}

void BotChargeCredit(UINT32 amount)
{
	g_StateMachine.ChargeCredit(amount);
	RecordBotCreditInsert(amount);
}

bool PayoutThresholdReached(const AIBotSnapshot& s)
{
	if (g_sessionInsertedCredits == 0) {
		return false;
	}
	const double target = static_cast<double>(g_sessionInsertedCredits) * (1.0 + kPayoutProfitFraction);
	return s.playDbCredit >= target;
}

bool MaybeManagePayout(AIBotSnapshot& s, UINT64 now)
{
	if (!PayoutThresholdReached(s)) {
		g_payoutPending = false;
		return false;
	}

	g_payoutPending = true;

	KomProtocol* kom = CryptoCard::GetInstance().GetKomProtocol();
	const bool inGameRunState = (kom && kom->mRunState == RUNSTATE_GAME);
	const bool inGameStatus = (s.status != STATUS_Lobby);

	if (inGameRunState || inGameStatus) {
		if (s.autoSpin && now - g_lastActionMs >= kActionCooldownMs) {
			g_lastActionMs = now;
			AIBot_HumanToggleAutoSpin();
		}
		else if (now - g_lastActionMs >= kActionCooldownMs) {
			g_lastActionMs = now;
			AIBot_HumanReturnToMenu();
		}
		return true;
	}

	if (now - g_lastActionMs < kActionCooldownMs) {
		return true;
	}

	g_lastActionMs = now;
	g_payoutPending = false;
	AIBot_HumanPayoutHotkey();
	if (!AIBot_IsAutoPayoutPending()) {
		g_sessionInsertedCredits = 0;
	}
	AIBot_PauseAfterAction();
	Sleep(kPayoutAfterActionMs);
	return true;
}

void UpdateSessionOnSnapshot(const AIBotSnapshot& s, UINT64 now)
{
	if (s.status == STATUS_Lobby) {
		s_wasInLobby = 1;
		return;
	}
	if (s_wasInLobby) {
		g_gameSessionStartMs = now;
		g_spinsThisSession = 0;
		s_wasInLobby = 0;
	}
}

bool MaybeRequestExitToLobby(const AIBotSnapshot& s, UINT64 now)
{
	if (s.status != STATUS_PendingSpin) {
		return false;
	}
	if (s.freeMode || s.multoGo) {
		return false;
	}
	UINT32 minSpins = 8 + static_cast<UINT32>(RandomMod(40));
	UINT64 minHeld = 35000 + static_cast<UINT64>(RandomMod(130000));
	const bool stale = (g_spinsThisSession >= minSpins) || ((now - g_gameSessionStartMs) >= minHeld);
	if (!stale) {
		return false;
	}
	if (s.autoSpin) {
		if (now - g_lastActionMs >= kActionCooldownMs) {
			g_lastActionMs = now;
			AIBot_HumanToggleAutoSpin();
		}
		return true;
	}
	if (now - g_lastActionMs < kActionCooldownMs) {
		return true;
	}
	g_lastActionMs = now;
	AIBot_HumanReturnToMenu();
	return true;
}

bool MaybePeriodicBetShuffle(const AIBotSnapshot& s, UINT64 now)
{
	if (!s.reelGameValid || s.freeMode || s.multoGo) {
		return false;
	}
	if (s.cardGambleOpen || s.risikoOpen) {
		return false;
	}
	const UINT64 interval = 4000 + static_cast<UINT64>(RandomMod(10000));
	if (now - g_lastBetShuffleMs < interval) {
		return false;
	}
	if (now - g_lastActionMs < kActionCooldownMs) {
		return false;
	}

	myVector<UINT16> bets = g_ReelGame->Bets();
	const int n = static_cast<int>(bets.size());
	if (n <= 0) {
		return false;
	}

	int maxAff = -1;
	for (int i = 0; i < n; ++i) {
		if (AT(bets, i) <= s.bankBit) {
			maxAff = i;
		}
	}
	if (maxAff < 0) {
		return false;
	}

	const int cur = g_ReelGame->BetStep();
	const int tgt = RandomMod(maxAff + 1);
	const int steps = (tgt - cur + n) % n;

	const bool aggressiveRtp = (s.totalBet <= 0.0) || (s.sessionRTP + 0.02 < s.targetRTP);

	if (steps == 0) {
		if (aggressiveRtp && cur < maxAff && RandomMod(100) < 12) {
			g_lastBetShuffleMs = now;
			g_lastActionMs = now;
			AIBot_HumanMaxBet();
			return true;
		}
		return false;
	}

	int chunk = steps;
	if (chunk > 8) {
		chunk = 8;
	}

	g_lastBetShuffleMs = now;
	g_lastActionMs = now;
	for (int i = 0; i < chunk; ++i) {
		AIBot_HumanBetChange();
	}
	return true;
}

void MaybeRandomAutospinToggle(const AIBotSnapshot& s, UINT64 now)
{
	if (!s.reelGameValid || s.freeMode || s.multoGo) {
		return;
	}
	if (s.cardGambleOpen || s.risikoOpen) {
		return;
	}
	if (now - g_lastAutospinToggleMs < 5000) {
		return;
	}
	if (RandomMod(200) != 0) {
		return;
	}
	if (now - g_lastActionMs < kActionCooldownMs) {
		return;
	}
	g_lastAutospinToggleMs = now;
	g_lastActionMs = now;
	AIBot_HumanToggleAutoSpin();
}

void HandleSpinRunning(UINT64 now)
{
	if (now - g_lastFastSpinMs < 220) {
		return;
	}
	if (RandomMod(100) >= 30) {
		return;
	}
	g_lastFastSpinMs = now;
	AIBot_HumanFastSpin();
}

bool AIBot_GameHasChangeLineUi(UINT16 gameId)
{
	switch (gameId) {
	case GOC_RgTotemChiefPlus:
	case GOC_RgPyramidsDeluxe:
	case GOC_RgMultiSevenWild:
	case GOC_RgMagicMirrorDeluxe2:
	case GOC_RgKongsTemple:
	case GOC_RgIndianRuby:
	case GOC_RgGongHei:
	case GOC_RgEyeOfHorus:
	case GOC_RgConvertusAurum:
	case GOC_RgBookOfFire:
		return true;
	default:
		return false;
	}
}

void MaybeRandomWinLineToggle(const AIBotSnapshot& s, UINT64 now)
{
	if (!s.reelGameValid || s.freeMode || s.multoGo) {
		return;
	}
	if (s.cardGambleOpen || s.risikoOpen) {
		return;
	}
	if (!AIBot_GameHasChangeLineUi(s.gameId)) {
		return;
	}
	if (s.winLine != 5 && s.winLine != 10) {
		return;
	}
	if (now - g_lastWinLinePickMs < 7000 + static_cast<UINT64>(RandomMod(11000))) {
		return;
	}
	g_lastWinLinePickMs = now;

	const int want = (RandomMod(100) < 45) ? 10 : 5;
	if (s.winLine == want) {
		return;
	}
	if (now - g_lastActionMs < kActionCooldownMs) {
		return;
	}
	g_lastActionMs = now;
	AIBot_TapChangeWinLine(s.gameId);
}

bool WantAggressiveRTP(const AIBotSnapshot& s)
{
	if (s.totalBet <= 0.0) {
		return true;
	}
	return s.sessionRTP + 0.02 < s.targetRTP;
}

void TapDragonSymbolPick()
{
	int r = RandomMod(100);
	int pick = 0;
	if (r < 18) pick = 0;
	else if (r < 36) pick = 1;
	else if (r < 54) pick = 2;
	else if (r < 63) pick = 3;
	else if (r < 72) pick = 4;
	else if (r < 81) pick = 5;
	else if (r < 90) pick = 6;
	else if (r < 95) pick = 7;
	else pick = 8;

	switch (pick) {
	case 0:
		AIBot_TapBox(AIBOT_Dragon_SIEGFR_LB_x_reel, AIBOT_Dragon_SIEGFR_LB_x_pos, AIBOT_Dragon_SIEGFR_LB_y_row, AIBOT_Dragon_SIEGFR_LB_y_pos,
			AIBOT_Dragon_SIEGFR_RT_x_reel, AIBOT_Dragon_SIEGFR_RT_x_pos, AIBOT_Dragon_SIEGFR_RT_y_row, AIBOT_Dragon_SIEGFR_RT_y_pos);
		break;
	case 1:
		AIBot_TapBox(AIBOT_Dragon_HAGEN_LB_x_reel, AIBOT_Dragon_HAGEN_LB_x_pos, AIBOT_Dragon_HAGEN_LB_y_row, AIBOT_Dragon_HAGEN_LB_y_pos,
			AIBOT_Dragon_HAGEN_RT_x_reel, AIBOT_Dragon_HAGEN_RT_x_pos, AIBOT_Dragon_HAGEN_RT_y_row, AIBOT_Dragon_HAGEN_RT_y_pos);
		break;
	case 2:
		AIBot_TapBox(AIBOT_Dragon_SCHATZ_LB_x_reel, AIBOT_Dragon_SCHATZ_LB_x_pos, AIBOT_Dragon_SCHATZ_LB_y_row, AIBOT_Dragon_SCHATZ_LB_y_pos,
			AIBOT_Dragon_SCHATZ_RT_x_reel, AIBOT_Dragon_SCHATZ_RT_x_pos, AIBOT_Dragon_SCHATZ_RT_y_row, AIBOT_Dragon_SCHATZ_RT_y_pos);
		break;
	case 3:
		AIBot_TapBox(AIBOT_Dragon_SCHWER_LB_x_reel, AIBOT_Dragon_SCHWER_LB_x_pos, AIBOT_Dragon_SCHWER_LB_y_row, AIBOT_Dragon_SCHWER_LB_y_pos,
			AIBOT_Dragon_SCHWER_RT_x_reel, AIBOT_Dragon_SCHWER_RT_x_pos, AIBOT_Dragon_SCHWER_RT_y_row, AIBOT_Dragon_SCHWER_RT_y_pos);
		break;
	case 4:
		AIBot_TapBox(AIBOT_Dragon_A_LB_x_reel, AIBOT_Dragon_A_LB_x_pos, AIBOT_Dragon_A_LB_y_row, AIBOT_Dragon_A_LB_y_pos,
			AIBOT_Dragon_A_RT_x_reel, AIBOT_Dragon_A_RT_x_pos, AIBOT_Dragon_A_RT_y_row, AIBOT_Dragon_A_RT_y_pos);
		break;
	case 5:
		AIBot_TapBox(AIBOT_Dragon_K_LB_x_reel, AIBOT_Dragon_K_LB_x_pos, AIBOT_Dragon_K_LB_y_row, AIBOT_Dragon_K_LB_y_pos,
			AIBOT_Dragon_K_RT_x_reel, AIBOT_Dragon_K_RT_x_pos, AIBOT_Dragon_K_RT_y_row, AIBOT_Dragon_K_RT_y_pos);
		break;
	case 6:
		AIBot_TapBox(AIBOT_Dragon_Q_LB_x_reel, AIBOT_Dragon_Q_LB_x_pos, AIBOT_Dragon_Q_LB_y_row, AIBOT_Dragon_Q_LB_y_pos,
			AIBOT_Dragon_Q_RT_x_reel, AIBOT_Dragon_Q_RT_x_pos, AIBOT_Dragon_Q_RT_y_row, AIBOT_Dragon_Q_RT_y_pos);
		break;
	case 7:
		AIBot_TapBox(AIBOT_Dragon_J_LB_x_reel, AIBOT_Dragon_J_LB_x_pos, AIBOT_Dragon_J_LB_y_row, AIBOT_Dragon_J_LB_y_pos,
			AIBOT_Dragon_J_RT_x_reel, AIBOT_Dragon_J_RT_x_pos, AIBOT_Dragon_J_RT_y_row, AIBOT_Dragon_J_RT_y_pos);
		break;
	default:
		AIBot_TapBox(AIBOT_Dragon_10_LB_x_reel, AIBOT_Dragon_10_LB_x_pos, AIBOT_Dragon_10_LB_y_row, AIBOT_Dragon_10_LB_y_pos,
			AIBOT_Dragon_10_RT_x_reel, AIBOT_Dragon_10_RT_x_pos, AIBOT_Dragon_10_RT_y_row, AIBOT_Dragon_10_RT_y_pos);
		break;
	}
}

void HandleLobby(AIBotSnapshot& s, UINT64 now)
{
	if (s.playDbCredit < 200) {
		if (now - g_lastActionMs >= kActionCooldownMs) {
			g_lastActionMs = now;
			BotChargeCredit(kChargeAmount);
			AIBot_PauseAfterAction();
		}
		return;
	}
	if (now - g_lastLobbyMs < kLobbyCooldownMs) {
		return;
	}
	g_lastLobbyMs = now;

	PlayDB& db = PlayDB::GetInstance();
	const int n = db.GetGameCount();
	if (n <= 0) {
		return;
	}
	const int start = RandomMod(n);
	for (int tries = 0; tries < n; ++tries) {
		const int idx = (start + tries) % n;
		const std::string name = db.GetGameName(idx);
		const UINT16 goc = AIBot_ResolveGameGoc(name);
		if (goc == 0) {
			continue;
		}
		if (g_StateMachine.RunGame(goc) != 0) {
			continue;
		}
		KomProtocol* kom = CryptoCard::GetInstance().GetKomProtocol();
		if (kom) {
			kom->mRunState = RUNSTATE_GAME;
		}
		Sleep(kLobbyAfterGameTransitionMs);
		g_lastActionMs = current_time_ms();
		return;
	}
}

bool TryAdjustBet(AIBotSnapshot& s, UINT64 now)
{
	if (!s.reelGameValid) {
		return false;
	}
	if (s.freeMode || s.multoGo) {
		return false;
	}
	const UINT16 bet = g_ReelGame->BetBit();
	if (bet <= s.bankBit) {
		return false;
	}
	if (now - g_lastActionMs < kActionCooldownMs) {
		return false;
	}
	g_lastActionMs = now;
	AIBot_HumanBetChange();
	return true;
}

void HandlePendingSpin(AIBotSnapshot& s, UINT64 now)
{
	if (s.cardGambleOpen || s.risikoOpen) {
		return;
	}
	if (!s.reelGameValid) {
		return;
	}
	UINT16 needBet = g_ReelGame->BetBit();
	if (s.multoGo) {
		needBet = 0;
	}
	if (!s.freeMode && needBet > s.bankBit) {
		// Match lobby: inject when PlayDB credit is low. Also if bank is empty but a spin costs
		// credits, top up (otherwise we never call ChargeCredit outside STATUS_Lobby).
		const bool needTopUp = (s.playDbCredit < 200) || (s.bankBit == 0 && needBet > 0);
		if (needTopUp && now - g_lastActionMs >= kActionCooldownMs) {
			g_lastActionMs = now;
			BotChargeCredit(kChargeAmount);
			AIBot_PauseAfterAction();
		}
		return;
	}
	if (TryAdjustBet(s, now)) {
		return;
	}
	if (MaybeRequestExitToLobby(s, now)) {
		return;
	}
	if (MaybePeriodicBetShuffle(s, now)) {
		return;
	}
	MaybeRandomWinLineToggle(s, now);
	MaybeRandomAutospinToggle(s, now);
	if (s.autoSpin) {
		return;
	}
	if (now - g_lastActionMs < kActionCooldownMs) {
		return;
	}
	g_lastActionMs = now;
	++g_spinsThisSession;
	AIBot_HumanSpin();
}

void HandleRisikoCardGamble(AIBotSnapshot& s, UINT64 now)
{
	if (!CooldownReady(now, g_lastActionMs, kActionCooldownMs)) {
		return;
	}
	if (s.autoSpin) {
		AIBot_HumanToggleAutoSpin();
		return;
	}

	const bool aggressive = WantAggressiveRTP(s);

	if (s.cardGambleOpen && !s.cardGambleFinished && !s.cardGambleSwapEnable) {
		return;
	}

	int collectChance = 24;
	if (!aggressive) {
		collectChance += 22;
	}
	if (s.cardGambleOpen && s.cardGambleLevel > 2000) {
		collectChance += 14;
	}
	if (s.risikoOpen && !s.cardGambleOpen && s.bonusCoin > 8000) {
		collectChance += 10;
	}
	if (collectChance > 92) {
		collectChance = 92;
	}
	if (RandomMod(100) < collectChance) {
		AIBot_HumanSpin();
		return;
	}

	if (RandomMod(100) < 44) {
		AIBot_HumanBetChange();
		return;
	}

	if (RandomMod(100) < 36) {
		AIBot_HumanNumpad1();
		return;
	}

	if (s.cardGambleOpen && !s.cardGambleFinished) {
		if (aggressive && s.cardGambleLevel >= 40 && RandomMod(100) < 40) {
			AIBot_TapBox(AIBOT_CardGamble_risiko_LB_x_reel, AIBOT_CardGamble_risiko_LB_x_pos, AIBOT_CardGamble_risiko_LB_y_row, AIBOT_CardGamble_risiko_LB_y_pos,
				AIBOT_CardGamble_risiko_RT_x_reel, AIBOT_CardGamble_risiko_RT_x_pos, AIBOT_CardGamble_risiko_RT_y_row, AIBOT_CardGamble_risiko_RT_y_pos);
			return;
		}
		if (!aggressive && s.cardGambleLevel > 80 && RandomMod(100) < 55) {
			AIBot_TapBox(AIBOT_CardGamble_risiko_LB_x_reel, AIBOT_CardGamble_risiko_LB_x_pos, AIBOT_CardGamble_risiko_LB_y_row, AIBOT_CardGamble_risiko_LB_y_pos,
				AIBOT_CardGamble_risiko_RT_x_reel, AIBOT_CardGamble_risiko_RT_x_pos, AIBOT_CardGamble_risiko_RT_y_row, AIBOT_CardGamble_risiko_RT_y_pos);
			return;
		}
		if (s.cardGambleLevel >= 20 && aggressive && RandomMod(100) < 25) {
			AIBot_TapBox(AIBOT_CardGamble_half_LB_x_reel, AIBOT_CardGamble_half_LB_x_pos, AIBOT_CardGamble_half_LB_y_row, AIBOT_CardGamble_half_LB_y_pos,
				AIBOT_CardGamble_half_RT_x_reel, AIBOT_CardGamble_half_RT_x_pos, AIBOT_CardGamble_half_RT_y_row, AIBOT_CardGamble_half_RT_y_pos);
			return;
		}
		if (RandomMod(2)) {
			AIBot_TapBox(AIBOT_CardGamble_red_LB_x_reel, AIBOT_CardGamble_red_LB_x_pos, AIBOT_CardGamble_red_LB_y_row, AIBOT_CardGamble_red_LB_y_pos,
				AIBOT_CardGamble_red_RT_x_reel, AIBOT_CardGamble_red_RT_x_pos, AIBOT_CardGamble_red_RT_y_row, AIBOT_CardGamble_red_RT_y_pos);
		}
		else {
			AIBot_TapBox(AIBOT_CardGamble_black_LB_x_reel, AIBOT_CardGamble_black_LB_x_pos, AIBOT_CardGamble_black_LB_y_row, AIBOT_CardGamble_black_LB_y_pos,
				AIBOT_CardGamble_black_RT_x_reel, AIBOT_CardGamble_black_RT_x_pos, AIBOT_CardGamble_black_RT_y_row, AIBOT_CardGamble_black_RT_y_pos);
		}
		return;
	}

	if (s.risikoOpen && !s.risikoFinished && s.bonusCoin < 14000) {
		if (!aggressive && RandomMod(100) < 60) {
			AIBot_TapBox(AIBOT_Risiko_card_LB_x_reel, AIBOT_Risiko_card_LB_x_pos, AIBOT_Risiko_card_LB_y_row, AIBOT_Risiko_card_LB_y_pos,
				AIBOT_Risiko_card_RT_x_reel, AIBOT_Risiko_card_RT_x_pos, AIBOT_Risiko_card_RT_y_row, AIBOT_Risiko_card_RT_y_pos);
			return;
		}
		if (aggressive && g_StateMachine.rsk_downable() && RandomMod(100) < 50) {
			AIBot_TapBox(AIBOT_Risiko_down_LB_x_reel, AIBOT_Risiko_down_LB_x_pos, AIBOT_Risiko_down_LB_y_row, AIBOT_Risiko_down_LB_y_pos,
				AIBOT_Risiko_down_RT_x_reel, AIBOT_Risiko_down_RT_x_pos, AIBOT_Risiko_down_RT_y_row, AIBOT_Risiko_down_RT_y_pos);
			return;
		}
		if (g_StateMachine.rsk_downable() && RandomMod(100) < 35) {
			AIBot_TapBox(AIBOT_Risiko_down_LB_x_reel, AIBOT_Risiko_down_LB_x_pos, AIBOT_Risiko_down_LB_y_row, AIBOT_Risiko_down_LB_y_pos,
				AIBOT_Risiko_down_RT_x_reel, AIBOT_Risiko_down_RT_x_pos, AIBOT_Risiko_down_RT_y_row, AIBOT_Risiko_down_RT_y_pos);
			return;
		}
		AIBot_TapBox(AIBOT_Risiko_card_LB_x_reel, AIBOT_Risiko_card_LB_x_pos, AIBOT_Risiko_card_LB_y_row, AIBOT_Risiko_card_LB_y_pos,
			AIBOT_Risiko_card_RT_x_reel, AIBOT_Risiko_card_RT_x_pos, AIBOT_Risiko_card_RT_y_row, AIBOT_Risiko_card_RT_y_pos);
	}
}

void HandlePostWinBonusSound(AIBotSnapshot& s, UINT64 now)
{
	// Los Frootos / Lucky Pharaoh: pressing GO (numpad) during PlayingBonusSound runs MoveBonus and
	// banks the win before StopPlayingBonusSound can open the power-spin (PendingMultiGo) flow.
	if (s.reelGameValid && (s.gameId == GOC_RgLosFrootos || s.gameId == GOC_RgPharosGoldBase)
		&& s.status == STATUS_PlayingBonusSound && g_ReelGame->CanMultiGo()) {
		return;
	}
	if (now - g_lastActionMs < kWinCollectCooldownMs) {
		return;
	}
	if (s.autoSpin) {
		g_lastActionMs = now;
		AIBot_HumanToggleAutoSpin();
		return;
	}
	if (s.multoGo) {
		g_lastActionMs = now;
		AIBot_HumanSpin();
		return;
	}

	const int pick = RandomMod(100);
	g_lastActionMs = now;
	if (pick < 50) {
		AIBot_HumanSpin();
		return;
	}
	if (pick < 75) {
		AIBot_HumanBetChange();
		return;
	}
	AIBot_HumanNumpad1();
}

void HandlePendingMultiGo(AIBotSnapshot& s, UINT64 now)
{
	if (!CooldownReady(now, g_lastActionMs, kActionCooldownMs)) {
		return;
	}
	bool aggressive = WantAggressiveRTP(s);
	bool los = (s.gameId == GOC_RgLosFrootos);
	bool pharos = (s.gameId == GOC_RgPharosGoldBase);

	if (los) {
		if (aggressive && s.bonusCoin > 500 && RandomMod(100) < 45) {
			AIBot_TapBox(AIBOT_LosFrootos_betup_LB_x_reel, AIBOT_LosFrootos_betup_LB_x_pos, AIBOT_LosFrootos_betup_LB_y_row, AIBOT_LosFrootos_betup_LB_y_pos,
				AIBOT_LosFrootos_betup_RT_x_reel, AIBOT_LosFrootos_betup_RT_x_pos, AIBOT_LosFrootos_betup_RT_y_row, AIBOT_LosFrootos_betup_RT_y_pos);
			return;
		}
		if (!aggressive && RandomMod(100) < 30) {
			AIBot_TapBox(AIBOT_LosFrootos_betdown_LB_x_reel, AIBOT_LosFrootos_betdown_LB_x_pos, AIBOT_LosFrootos_betdown_LB_y_row, AIBOT_LosFrootos_betdown_LB_y_pos,
				AIBOT_LosFrootos_betdown_RT_x_reel, AIBOT_LosFrootos_betdown_RT_x_pos, AIBOT_LosFrootos_betdown_RT_y_row, AIBOT_LosFrootos_betdown_RT_y_pos);
			return;
		}
		AIBot_TapBox(AIBOT_LosFrootos_go_LB_x_reel, AIBOT_LosFrootos_go_LB_x_pos, AIBOT_LosFrootos_go_LB_y_row, AIBOT_LosFrootos_go_LB_y_pos,
			AIBOT_LosFrootos_go_RT_x_reel, AIBOT_LosFrootos_go_RT_x_pos, AIBOT_LosFrootos_go_RT_y_row, AIBOT_LosFrootos_go_RT_y_pos);
		return;
	}
	if (pharos) {
		if (aggressive && s.bonusCoin > 500 && RandomMod(100) < 45) {
			AIBot_TapBox(AIBOT_Pharos_betup_LB_x_reel, AIBOT_Pharos_betup_LB_x_pos, AIBOT_Pharos_betup_LB_y_row, AIBOT_Pharos_betup_LB_y_pos,
				AIBOT_Pharos_betup_RT_x_reel, AIBOT_Pharos_betup_RT_x_pos, AIBOT_Pharos_betup_RT_y_row, AIBOT_Pharos_betup_RT_y_pos);
			return;
		}
		if (!aggressive && RandomMod(100) < 30) {
			AIBot_TapBox(AIBOT_Pharos_betdown_LB_x_reel, AIBOT_Pharos_betdown_LB_x_pos, AIBOT_Pharos_betdown_LB_y_row, AIBOT_Pharos_betdown_LB_y_pos,
				AIBOT_Pharos_betdown_RT_x_reel, AIBOT_Pharos_betdown_RT_x_pos, AIBOT_Pharos_betdown_RT_y_row, AIBOT_Pharos_betdown_RT_y_pos);
			return;
		}
		AIBot_TapBox(AIBOT_Pharos_go_LB_x_reel, AIBOT_Pharos_go_LB_x_pos, AIBOT_Pharos_go_LB_y_row, AIBOT_Pharos_go_LB_y_pos,
			AIBOT_Pharos_go_RT_x_reel, AIBOT_Pharos_go_RT_x_pos, AIBOT_Pharos_go_RT_y_row, AIBOT_Pharos_go_RT_y_pos);
	}
}

} // namespace

void AIBot_ResetPayoutSession()
{
	g_sessionInsertedCredits = 0;
	g_payoutPending = false;
}

void AIBot_RunStrategyTick(std::atomic<bool>& stopRequested)
{
	if (stopRequested.load()) {
		return;
	}
	AIBotSnapshot s{};
	AIBot_FillSnapshot(s);
	const int prevSmStatus = s_prevAIBotStatus;
	if (s.status == STATUS_PendingMultiGo && prevSmStatus != STATUS_PendingMultiGo
		&& (s.gameId == GOC_RgLosFrootos || s.gameId == GOC_RgPharosGoldBase)) {
		g_StateMachine.InitCache();
	}
	s_prevAIBotStatus = s.status;

	if (s.status == STATUS_Lobby && prevSmStatus != STATUS_Lobby && prevSmStatus != -1) {
		Sleep(kLobbyAfterGameTransitionMs);
		g_lastActionMs = current_time_ms();
		g_lastLobbyMs = current_time_ms();
	}

	UINT64 now = current_time_ms();
	UpdateSessionOnSnapshot(s, now);

	if (MaybeManagePayout(s, now)) {
		return;
	}

	if (s.status == STATUS_Lobby) {
		HandleLobby(s, now);
		return;
	}

	if (s.status == STATUS_SpinRunning) {
		HandleSpinRunning(now);
		return;
	}

	if (s.status == STATUS_Risiko) {
		HandleRisikoCardGamble(s, now);
		return;
	}

	if (s.status == STATUS_WaitMouseAction && s.gameId == GOC_RgDragonsTreas) {
		if (CooldownReady(now, g_lastActionMs, kActionCooldownMs)) {
			TapDragonSymbolPick();
		}
		return;
	}

	if (s.status == STATUS_PendingMultiGo) {
		HandlePendingMultiGo(s, now);
		return;
	}

	if (s.status == STATUS_MagicGame) {
		if (CooldownReady(now, g_lastActionMs, kActionCooldownMs)) {
			if (WantAggressiveRTP(s)) {
				AIBot_TapBox(AIBOT_Magic_AG_LB_x_reel, AIBOT_Magic_AG_LB_x_pos, AIBOT_Magic_AG_LB_y_row, AIBOT_Magic_AG_LB_y_pos,
					AIBOT_Magic_AG_RT_x_reel, AIBOT_Magic_AG_RT_x_pos, AIBOT_Magic_AG_RT_y_row, AIBOT_Magic_AG_RT_y_pos);
			}
			else {
				AIBot_TapBox(AIBOT_Magic_1000_LB_x_reel, AIBOT_Magic_1000_LB_x_pos, AIBOT_Magic_1000_LB_y_row, AIBOT_Magic_1000_LB_y_pos,
					AIBOT_Magic_1000_RT_x_reel, AIBOT_Magic_1000_RT_x_pos, AIBOT_Magic_1000_RT_y_row, AIBOT_Magic_1000_RT_y_pos);
			}
		}
		return;
	}

	if (s.status == STATUS_PendingSpin || s.status == STATUS_PendingSpinAndGo) {
		HandlePendingSpin(s, now);
		return;
	}

	if (s.status == STATUS_PlayingBonusSound || s.status == STATUS_WaitActionBonusSound) {
		HandlePostWinBonusSound(s, now);
		return;
	}
}
