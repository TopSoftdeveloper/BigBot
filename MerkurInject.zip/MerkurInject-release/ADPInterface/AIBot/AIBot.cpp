#include "stdafx.h"
#include "AIBot.h"
#include "AIBotStrategy.h"
#include <atomic>
#include <thread>

static std::atomic<bool> g_botStop{ true };
static std::atomic<bool> g_botThreadActive{ false };
static std::atomic<bool> g_autoPayoutRequested{ false };
static std::thread g_botThread;

void AIBot_RequestAutoPayout()
{
	g_autoPayoutRequested.store(true);
}

bool AIBot_TakeAutoPayoutRequest()
{
	return g_autoPayoutRequested.exchange(false);
}

void AIBot_CancelAutoPayoutRequest()
{
	g_autoPayoutRequested.store(false);
}

bool AIBot_IsAutoPayoutPending()
{
	return g_autoPayoutRequested.load();
}

static void AIBotThreadProc()
{
	while (!g_botStop.load()) {
		AIBot_RunStrategyTick(g_botStop);
		Sleep(75);
	}
	g_botThreadActive.store(false);
}

void AIBot_Start()
{
	if (g_botThreadActive.load()) {
		return;
	}
	AIBot_ResetPayoutSession();
	AIBot_CancelAutoPayoutRequest();
	g_botStop.store(false);
	g_botThreadActive.store(true);
	if (g_botThread.joinable()) {
		g_botThread.join();
	}
	g_botThread = std::thread(AIBotThreadProc);
	g_botThread.detach();
}

void AIBot_Stop()
{
	g_botStop.store(true);
	for (int i = 0; i < 80 && g_botThreadActive.load(); ++i) {
		Sleep(25);
	}
}

bool AIBot_IsRunning()
{
	return g_botThreadActive.load() && !g_botStop.load();
}
