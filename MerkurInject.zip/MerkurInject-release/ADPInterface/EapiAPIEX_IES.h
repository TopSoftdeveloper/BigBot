#pragma once
#include "GlobalVar.h"
#include "..\\import_header\\EAPI_IES.h"
class CEapiAPIEX_IES// public CUniAPI
{
public:
	CEapiAPIEX_IES(void);
	~CEapiAPIEX_IES(void);
	
	
	void sub_10006E90();// CONSTRULCTOR
	//int		sub_1000B430();// CUniAPI_constructor
	DWORD m_dw04;
	DWORD m_dw08;
	infoStructure* m_pInfoStart;
	infoStructure* m_pInfoLast;
	HMODULE m_hModEAPI_IES;
	DWORD m_dw18;
public:
	virtual HANDLE	sub_10007E40(BOOL flag);// deconstructor(bool flag)
 	virtual void	sub_10006F60();// deconstructor
	virtual DWORD 	sub_10006240();
	virtual int  	sub_10006FF0(ArrayStr* pArrayStr);
	virtual DWORD 	sub_10007EF0();
	virtual BOOL  	sub_10006330(BYTE bFlag, DWORD dwVal);
	virtual BOOL 	sub_10006390(BYTE bFlag, BYTE bRet);
	virtual BOOL 	sub_10006490(BYTE bFlag, int nCmd, PBYTE pbRet);
	virtual BOOL 	sub_10006410(BYTE bFlag, DWORD dwCmd1, DWORD nCmd2);
	virtual BOOL 	sub_100062C0(char bFlag, char bRet);
	virtual BOOL 	sub_10006500(int nCode, StructSize13 stCmd);
	virtual BOOL 	sub_10006700(DWORD64* pdwRet);
	virtual int 	sub_10003550();
	virtual BOOL 	sub_10006810();
	virtual BOOL	sub_10006630(BYTE* pbRet);
	virtual BOOL	sub_100066B0(BYTE nCode);
	virtual int		sub_10006610(BYTE* bCode);
	virtual int		sub_10006620();
	virtual BOOL 	sub_10006850(DWORD* pdwCode);
	virtual BOOL	sub_10003660(double* arg_0, int* arg_4);
	virtual BOOL	sub_10004550(BYTE* arg_0);
	virtual int		sub_10007B00(BYTE* arg_0);
	virtual BOOL	GetVCPFeatureAndVCPFeatureReply_10006970(DWORD* dwCurVal, int nNum);
	virtual BOOL	SetVCPFeature_10006A80(DWORD* pdwNewVal, int nNum);
	virtual BOOL	GetVCPFeatureAndVCPFeatureReply_10006B70(DWORD* pdwCurVal, int nNum);
	virtual BOOL	SetVCPFeature_10005070(DWORD* pdwNewVal, int nNum);
	virtual BOOL	sub_10003720(BYTE byVal, BYTE* bySrc, BYTE byLen);
 	virtual BOOL	sub_10006C80(DWORD* pdwParam);
// 	sub_100051F0 retn 0
	virtual DWORD	retn0_100051F0();
	virtual BOOL	SetVCPFeature_10005200(int nNum, BYTE bVCPCode, DWORD* pdwNewVal);
	virtual	BOOL	GetVCPFeatureAndVCPFeatureReply_10003850(int nArgNum, BYTE bVCPCode, DWORD* pdwCurrentVal, DWORD* dwMaxVal);
	virtual BOOL	SaveCurrentSettings_10006D60(int nNum);
	virtual DWORD	sub_100061D0();
};
