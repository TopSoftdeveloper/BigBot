#include "StdAfx.h"
#include "KontronAPI.h"
#include "GlobalVar.h"
//#include "..\\import_header\\Jida.h"

CKontronAPI::CKontronAPI(void)
{
}

CKontronAPI::~CKontronAPI(void)
{
}
// LPFnU_V JidaDllInitialize = (LPFnU_V)GetProcAddress(hJida, "JidaDllInitialize");
// LPFnU_V JidaDllIsAvailable = (LPFnU_V)GetProcAddress(hJida, "JidaDllIsAvailable");
// LPFnV_D JidaI2CCount = (LPFnV_D)GetProcAddress(hJida, "JidaI2CCount");
// LPFnU_D JidaDllInstall = (LPFnU_D)GetProcAddress(hJida, "JidaDllInstall");	
// LPFnU_DDDD JidaBoardOpenW = (LPFnU_DDDD)GetProcAddress(hJida, "JidaBoardOpenW");
// LPFnU_DDDDD JidaWDogSetConfig = (LPFnU_DDDDD)GetProcAddress(hJida, "JidaWDogSetConfig");
// LPFnU_DD JidaI2CIsAvailable = (LPFnU_DD)GetProcAddress(hJida, "JidaI2CIsAvailable");
// LPFnU_DD JidaWDogDisable = (LPFnU_DD)GetProcAddress(hJida, "JidaWDogDisable");
// LPFnU_DD JidaWDogTrigger = (LPFnU_DD)GetProcAddress(hJida, "JidaWDogTrigger");
// LPFnU_DD JidaVgaSetBacklight = (LPFnU_DD)GetProcAddress(hJida, "JidaVgaSetBacklight");
// LPFnU_DD JidaVgaSetContrast = (LPFnU_DD)GetProcAddress(hJida, "JidaVgaSetContrast");
// LPFnV_D JidaBoardClose = (LPFnV_D)GetProcAddress(hJida, "JidaBoardClose");
// LPFnU_V JidaDllUninitialize = (LPFnU_V)GetProcAddress(hJida, "JidaDllUninitialize");
// LPFnV_V JidaDllGetVersion = (LPFnV_V)GetProcAddress(hJida, "JidaDllGetVersion");
// LPFnU_DD JidaBoardGetInfoW = (LPFnU_DD)GetProcAddress(hJida, "JidaBoardGetInfoW");
// LPFnU_DDDPD JidaI2CRead = (LPFnU_DDDPD)GetProcAddress(hJida, "JidaI2CRead");
// LPFnU_DDDPD JidaI2CWrite = (LPFnU_DDDPD)GetProcAddress(hJida, "JidaI2CWrite");
// LPFnU_DDPP JidaTemperatureGetCurrent = (LPFnU_DDPP)GetProcAddress(hJida, "JidaTemperatureGetCurrent");
// LPFnU_DDP JidaTemperatureGetInfo = (LPFnU_DDP)GetProcAddress(hJida, "JidaTemperatureGetInfo");
// LPFnU_D JidaTemperatureCount = (LPFnU_D)GetProcAddress(hJida, "JidaTemperatureCount");
// LPFnU_DP JidaVgaGetBacklight = (LPFnU_DP)GetProcAddress(hJida, "JidaVgaGetBacklight");
// LPFnU_DP JidaVgaGetContrast = (LPFnU_DP)GetProcAddress(hJida, "JidaVgaGetContrast");

int CKontronAPI::JidaInit_1000AB30()//sub_1000AB30
{
	m_dw10 = 0;
	m_dw0C = 0;
	if (!JidaDllInitialize())
	{
		if (!JidaDllInstall(1)) return 0;
		if (!JidaDllInitialize()) return 0;
	}
	if (!JidaDllIsAvailable()) return 0;
	if (!JidaBoardOpenW(L"CPU", 0, 0, (DWORD*)&m_dw10)) return 0;
	JidaI2CCount(m_dw10);
	if (!m_dw10) return 0;
	return JidaI2CIsAvailable(m_dw10, m_dw0C)!=0;
}
void CKontronAPI::JidaClose_1000AAD0()
{
	if (m_dw10)
	{
		JidaBoardClose(m_dw10);
	}
	JidaDllUninitialize();
	//sub_1000B410

}
HANDLE 	CKontronAPI::sub_10009630(BOOL bFlag)
{
	JidaClose_1000AAD0();
	if (bFlag)
	{
		delete this;
	}
	return this;
}
void CKontronAPI::sub_1000AB00()
{	
	if (!m_dw10)
	{
		JidaBoardClose(m_dw10);
		m_dw10 = (FUNCSTRUC14*)-1;
		m_dw0C = -1;
		JidaDllUninitialize();
	}	
}
void CKontronAPI::j_Jida_2()
{
	JidaDllGetVersion();
}
BOOL CKontronAPI::JidaBoardGetInfo_1000B270(ArrayStr* pArrStr)
{
	m_dw0C = m_dw08;
	m_dw10 = m_dw04;
	KontronInfo* pKontronInfo = new KontronInfo;
	memset(pKontronInfo, 0, sizeof(KontronInfo));//1D0  464
	pKontronInfo->nSize = 464;
	if(!JidaBoardGetInfoW((DWORD)m_dw04, (PDWORD)pKontronInfo)) return FALSE;
	wcscpy_s(pArrStr->wszStr_04, 0x20, pKontronInfo->wszStr28);
	FormatStrW_100052F0(pArrStr->wszStr_44, 0x20u, L"%d.%d", pKontronInfo->byValC8, pKontronInfo->byValC9);
	wcscpy_s(pArrStr->wszStr_C4, 0x20, L"KONTRON");
	FormatStrW_100052F0(pArrStr->wszStr_84, 0x20, L"%02X %02X", pKontronInfo->byValCA, pKontronInfo->byValCB);
	wcscpy_s(pArrStr->wszStr_110, 0x20, pKontronInfo->wszStr2);
	pArrStr->byBuf[0] = pKontronInfo->byBuf88[6];
	pArrStr->byBuf[1] = pKontronInfo->byBuf88[2];
	pArrStr->byBuf[2] = pKontronInfo->byBuf88[0];
	pArrStr->byBuf[3] = pKontronInfo->byBuf88[1];
	pArrStr->byBuf[4] = pKontronInfo->byBuf88[8];
	pArrStr->byBuf[5] = pKontronInfo->byBuf88[10];
	pArrStr->byBuf[6] = pKontronInfo->byBuf88[22];
	pArrStr->byBuf[7] = pKontronInfo->byBuf88[18];
	pArrStr->byBuf[8] = pKontronInfo->byBuf88[16];
	pArrStr->byBuf[9] = pKontronInfo->byBuf88[17];
	pArrStr->byBuf[10] = pKontronInfo->byBuf88[24];
	pArrStr->byBuf[11] = pKontronInfo->byBuf88[26];
	return TRUE;
}
BOOL CKontronAPI::sub_1000ABB0()
{
	m_dw10 = m_dw04;
	m_dw0C = m_dw08;
	JidaI2CCount(m_dw04);
	if (m_dw10)
	{
		if(JidaI2CIsAvailable(m_dw10, m_dw0C)) return TRUE;		
	}
	return FALSE;
}
BOOL CKontronAPI::sub_1000AC40(BYTE bFlag, BYTE* pBuf)
{

	m_dw10 = m_dw04;
	m_dw0C = m_dw08;
	if (JidaI2CRead(m_dw04, m_dw08, bFlag|1, (PDWORD)pBuf, 1))
	{
		return TRUE;
	}
	return FALSE;
}
BOOL CKontronAPI::sub_1000AC70(BYTE bFlag, DWORD dwArg)
{
	if (bFlag != 0x36) return FALSE;
	m_dw10 = m_dw04;
	m_dw0C = m_dw08;
	if (JidaI2CWrite(m_dw04, m_dw08, 0x36, &dwArg, 1))
	{
		return TRUE;
	}

	return FALSE;
}
BOOL CKontronAPI::sub_1000ACF0(BYTE bFlag, DWORD nMode, BYTE* pBuf)
{
	if (bFlag != 0x36) return FALSE;
	m_dw10 = m_dw04;
	m_dw0C = m_dw08;
	if (JidaI2CWrite(m_dw04, m_dw08, 0x36, pBuf, nMode))
	{
		return TRUE;
	}
	return FALSE;
}
BOOL CKontronAPI::sub_1000ACB0(BYTE bFlag, int nMode, BYTE* pBuf)
{	
	m_dw10 = m_dw04;
	m_dw0C = m_dw08;
	if (bFlag >= 0x7E) return FALSE;
	if (JidaI2CRead(m_dw04, m_dw08, bFlag|1, (PDWORD)pBuf, nMode))
	{
		return TRUE;
	}
	return FALSE;
}
BOOL CKontronAPI::sub_1000AC00(BYTE bFlag, DWORD dwArg)
{	
	m_dw0C = m_dw08;
	m_dw10 = m_dw04;
	if (dwArg == 2) return FALSE;
	if (JidaI2CWrite(m_dw04, m_dw08, bFlag&0xFE, &dwArg, 1))
	{
		return TRUE;
	}
	return FALSE;
}
BOOL CKontronAPI::sub_1000AD30(int nMode, BYTE* pBuf)
{
	m_dw0C = m_dw08;
	m_dw10 = m_dw04;
	WORD wTmp = *(WORD*)pBuf;
	wTmp = (wTmp % 1000) % 100;
	BYTE byBuf[8];
	byBuf[0] = pBuf[12];
	byBuf[1] = pBuf[10];
	byBuf[2] = pBuf[8];
	byBuf[3] = pBuf[4];
	byBuf[4] = pBuf[6];
	byBuf[5] = pBuf[2];
	byBuf[6] = (BYTE)wTmp;
	if (JidaI2CWrite(m_dw04, m_dw08, 0x20, byBuf, nMode))
	{
		return TRUE;
	}
	return FALSE;
}
BOOL CKontronAPI:: sub_1000AEC0(DWORD* pData)
{
	m_dw10 = m_dw04;
	if (JidaWDogSetConfig(m_dw04, 0, pData[0], pData[1], 0))
	{
		return TRUE;
	}
	return FALSE;
}
BOOL CKontronAPI::sub_1000AEF0()
{
	m_dw10 = m_dw04;
	if (JidaWDogDisable(m_dw04, 0))
	{
		return TRUE;
	}
	return FALSE;
}
BOOL CKontronAPI::sub_10009650()
{
	return FALSE;
}

BOOL CKontronAPI::sub_1000AF10()
{
	m_dw10 = m_dw04;
	if (JidaWDogTrigger(m_dw04, 0))
	{
		return TRUE;
	}
	return FALSE;
}
BOOL CKontronAPI::sub_10007EF0()
{
	return TRUE;
}
BOOL CKontronAPI::sub_1000AE60(BYTE* pbyArg)
{
	m_dw10 = m_dw04;
	BYTE bytmp = 0; 
	if ( !JidaVgaGetBacklight(m_dw04, (PDWORD)&bytmp) ) return FALSE;
	pbyArg[0] = bytmp;
	return TRUE;
}
BOOL CKontronAPI::sub_1000AEA0(BYTE byArg)
{
	m_dw10 = m_dw04;
	if ( JidaVgaSetBacklight(m_dw04, (DWORD)byArg) ) return TRUE;
	return FALSE;
}
BOOL CKontronAPI::sub_1000AE00(BYTE* pbyArg)
{
	m_dw10 = m_dw04;
	BYTE bytmp = 0; 
	if ( !JidaVgaGetContrast((int)m_dw04, (int)&bytmp) ) return FALSE;
	pbyArg[0] = bytmp;
	return TRUE;
}
BOOL CKontronAPI::sub_1000AE40(BYTE byArg)
{
	m_dw10 = m_dw04;
	if ( JidaVgaSetContrast((int)m_dw04, (DWORD)byArg) ) return TRUE;
	return FALSE;
}
BOOL CKontronAPI::sub_1000AF30(DWORD* pData)
{
	m_dw10 = m_dw04;
	DWORD dwVar2C[11];
	TEMPINFO_28* tempinfo = new TEMPINFO_28;

	memset(dwVar2C, 0, sizeof(dwVar2C));
	memset(tempinfo, 0, sizeof(TEMPINFO_28));
	dwVar2C[0] = 0x2C;// sizeof dwVar2C
	int nCnt = JidaTemperatureCount(m_dw04);
	tempinfo->nCntTempeature_24 = nCnt;
	if (nCnt <= 0) return FALSE;
	int n = 0;
	BOOL bRet = 0;
	for (n = 0; n < nCnt; n++)
	{
		if(!JidaTemperatureGetInfo(m_dw10, n, dwVar2C)) continue;
		switch ( dwVar2C[1] )
		{
		case 0:
			if ( JidaTemperatureGetCurrent(m_dw10, n, (DWORD*)&tempinfo->n_4, (PDWORD)&tempinfo) ) 			
			{
				if ( !tempinfo->n_8)
				{
					if ( tempinfo->n_0 == 1 )
						pData[0] = tempinfo->n_4  / 1000;
					else
						pData[0] = 0;
					tempinfo->n_8 = 1;
				}
				bRet = TRUE;
			}
			else bRet = FALSE;	
		case 2:
			if ( JidaTemperatureGetCurrent(m_dw10, n, (DWORD*)&tempinfo->n_4, (PDWORD)&tempinfo) ) 		
			{
				if ( !tempinfo->n_10 )
				{
					if ( tempinfo->n_0 == 1 )
						pData[3] = tempinfo->n_4  / 1000;
					else
						pData[3] = 0;
					tempinfo->n_10 = 1;
					
				}
				bRet = TRUE;
			}
			else bRet = FALSE;
		case 3:
			if ( JidaTemperatureGetCurrent(m_dw10, n, (DWORD*)&tempinfo->n_4, (PDWORD)&tempinfo) ) 
			{
				if ( !tempinfo->n_c )
				{
					if ( tempinfo->n_0 == 1 )
						pData[1] = tempinfo->n_4  / 1000;
					else
						pData[1] = 0;
					tempinfo->n_c = 1;				
				}
				bRet = TRUE;
			}
			else bRet = FALSE;
		case 4:
			if ( JidaTemperatureGetCurrent(m_dw10, n, &tempinfo->n_4, (PDWORD)&tempinfo) ) 
			{
				if ( !tempinfo->n_14 )
				{
					if ( tempinfo->n_0 == 1 )
						pData[4] = tempinfo->n_4  / 1000;
					else
						pData[4] = 0;
					tempinfo->n_14 = 1;				
				}
				bRet = TRUE;
			}
			else bRet = FALSE;			
		case 5:
			if ( JidaTemperatureGetCurrent(m_dw10, n, &tempinfo->n_4, (PDWORD)&tempinfo) )
			{
				if ( !tempinfo->n_18 )
				{
					if ( tempinfo->n_0 == 1 )
						pData[5] = tempinfo->n_4  / 1000;
					else
						pData[5] = 0;
					tempinfo->n_18 = 1;				
				}
				bRet = TRUE;
			}
			else  bRet = FALSE;			
		case 6:
			if ( JidaTemperatureGetCurrent(m_dw10, n, &tempinfo->n_4, (PDWORD)&tempinfo) ) 
			{
				if ( !tempinfo->n_1c )
				{
					if ( tempinfo->n_0 == 1 )
						pData[6] = tempinfo->n_4  / 1000;
					else
						pData[6] = 0;
					tempinfo->n_1c = 1;				
				}
				bRet = TRUE;
			}
			else  bRet = FALSE;			
		default:
			if ( JidaTemperatureGetCurrent(m_dw10, n, &tempinfo->n_4, (PDWORD)&tempinfo) ) 
			{
				if ( !tempinfo->n_20 )
				{
					if ( tempinfo->n_0 == 1 )
						pData[9] = tempinfo->n_4  / 1000;
					else
						pData[9] = 0;
					tempinfo->n_20 = 1;				
				}
				bRet = TRUE;
			}
			else bRet = FALSE;			
		}
	}
	return bRet;
}