﻿#pragma once
#include "GlobalVar.h"
#include "..\\import_header\\Cgos.h"
class CongaAPI
{
public:
	CongaAPI(void);
	~CongaAPI(void);
	
	DWORD m_dw04;
	DWORD m_dw08;
	DWORD m_dw0C;
	DWORD m_dw10;
public:

	void sub_10001090(BOOL bFlag);
	void BoardClose_100010D0();
	DWORD j_CgosLibGetVersion();
	BOOL BoardGetInfoW_100017B0(ArrayStr* pArrStr);
	BOOL I2CCount_10001170();
	DWORD I2CRead_10001210(DWORD arg_0, DWORD arg_4);
	DWORD I2CWrite_10001250(BYTE arg_0, BYTE arg_4);
	DWORD I2CWrite_100012E0(BYTE arg_0, DWORD arg_4, DWORD arg_8);
	DWORD I2CRead_10001290(BYTE arg_0, DWORD arg_4, DWORD arg_8);
	DWORD I2CWrite_100011C0(BYTE arg_0, BYTE arg_4);
	DWORD I2CWrite_10001320(DWORD arg_0, BYTE* pBuf);
	BOOL WDogSetConfig_100014F0(WORD* arg_0);
	BOOL WDogDisable_10001520();
	BOOL sub_10009650();
	BOOL WDogTrigger_10001540();
	DWORD VgaCount_10001410();
	BOOL VgaGetBacklight_10001490(DWORD* arg_0);
	BOOL VgaSetBackLight_100014D0(DWORD arg_0);
	BOOL VgaGetContrast_10001430(DWORD* arg_0);
	BOOL VgaSetContrast_10001470(DWORD arg_0);
	BOOL TemperatureGetInfo_10001560(DWORD* arg_0);
	int CgosInit_10001100();//0x54
};
