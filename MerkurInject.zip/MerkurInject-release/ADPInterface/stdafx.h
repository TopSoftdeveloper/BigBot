// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"

#define WIN32_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers
//#define _DEBUG
// Windows Header Files:
#include <windows.h>
#include <map>
#include <windef.h>
#include "resource.h"

#define MAX_GAME_COUNT 70
#define ISMAIL_RELEASE

#ifdef ISMAIL_RELEASE
	#define ENABLE_LOGS 0
	#define MMCODE_BY_SUNNY
	#define TOPMOSTWINDOW_ACTIVE
	//#define BIGBET_ACTIVE
	//#define VARIANTBC_ACTIVE
	//#define AIBOT_ACTIVE
	// When defined, PlayDB::ResetGameSettings appends high bet steps per game (see PlayDB.cpp BIGBET helpers).
	//#define BIGBET_ACTIVE
	//#define SHOW_GAME_CURSOR
	//#define MMCODE_ACTIVE
	//#define TEST_WILD
	//#define TEST_RTP_RANDOM_FALLBACK
#else
	#define ENABLE_LOGS 1
	#define MMCODE_BY_SUNNY
	//#define VARIANTBC_ACTIVE
	#define SHOW_GAME_CURSOR
	//#define BIGBET_ACTIVE
	//#define TOPMOSTWINDOW_ACTIVE
	#define AIBOT_ACTIVE
	//#define MMCODE_ACTIVE
	//#define TEST_WILD
	//	#define TEST_RTP_RANDOM_FALLBACK
#endif

// Extra high bet entries appended in BIGBET_ACTIVE (count must match each game's #ifdef push_backs on that vector).
#ifdef BIGBET_ACTIVE
#define BIGBET_BETSTEP_EXTRA_COUNT 2   // typical: +500,+1000 or +200,+500
#else
#define BIGBET_BETSTEP_EXTRA_COUNT 0
#endif

#ifndef MERKUR_APP_VERSION_BASE
#define MERKUR_APP_VERSION_BASE L"v1.3.12"
#endif

// Application version (shown on Control / Mainbook / Subbook password screens). Bump per release.
// The suffix advertises which variants are available in this build:
//   - "-abc" when VARIANTBC_ACTIVE is defined (Variant A/B/C selectable)
//   - "-a"   when VARIANTBC_ACTIVE is not defined (Variant A only)
#ifdef VARIANTBC_ACTIVE
#define MERKUR_APP_VERSION_SUFFIX L"-abc"
#else
#define MERKUR_APP_VERSION_SUFFIX L"-a"
#endif

#ifndef MERKUR_APP_VERSION_STRING
#define MERKUR_APP_VERSION_STRING MERKUR_APP_VERSION_BASE MERKUR_APP_VERSION_SUFFIX
#endif

// TODO: reference additional headers your program requires here
