#pragma once
#ifndef __HOOK_H__
#define __HOOK_H__
#include <windows.h>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <sstream>
#define VIRTUALHANDLE6 (HANDLE)0x123
#define VIRTUALHANDLE7 (HANDLE)0x125
#define VIRTUALHANDLE7AGAIN (HANDLE)0x126
#define VIRTUALSRAMHANDLE (HANDLE)0x124

typedef HANDLE(WINAPI* OriginalCreateFileW)(
	LPCWSTR lpFileName,
	DWORD dwDesiredAccess,
	DWORD dwShareMode,
	LPSECURITY_ATTRIBUTES lpSecurityAttributes,
	DWORD dwCreationDisposition,
	DWORD dwFlagsAndAttributes,
	HANDLE hTemplateFile
	);
extern OriginalCreateFileW originalCreateFileW;

typedef BOOL(WINAPI* OriginalSetCommState)(
	HANDLE hFile,
	LPDCB lpDCB
	);
extern OriginalSetCommState originalSetCommState;

typedef BOOL(WINAPI* OriginalGetCommState)(
	HANDLE hFile,
	LPDCB lpDCB
	);
extern OriginalGetCommState originalGetCommState;

typedef BOOL(WINAPI* OriginalSetCommTimeouts)(
	HANDLE hFile,
	LPCOMMTIMEOUTS lpCommTimeouts
	);
extern OriginalSetCommTimeouts originalSetCommTimeouts;

typedef BOOL(WINAPI* OriginalWriteFile)(
	HANDLE hFile,
	LPCVOID lpBuffer,
	DWORD nNumberOfBytesToWrite,
	LPDWORD lpNumberOfBytesWritten,
	LPOVERLAPPED lpOverlapped
	);
extern OriginalWriteFile originalWriteFile;

typedef BOOL(WINAPI* OriginalReadFile)(
	HANDLE hFile,
	LPVOID lpBuffer,
	DWORD nNumberOfBytesToRead,
	LPDWORD lpNumberOfBytesRead,
	LPOVERLAPPED lpOverlapped
	);
extern OriginalReadFile originalReadFile;

typedef BOOL(WINAPI* OriginalGetDefaultCommConfigW)(
	LPCWSTR lpszName,
	LPCOMMCONFIG lpCC,
	LPDWORD lpdwSize
	);
extern OriginalGetDefaultCommConfigW originalGetDefaultCommConfigW;

typedef BOOL(WINAPI* OriginalGetCommProperties)(
	HANDLE hFile,
	LPCOMMPROP lpCommProp
	);
extern OriginalGetCommProperties originalGetCommProperties;

typedef BOOL(WINAPI* OriginalSetupComm)(
	HANDLE hFile,
	DWORD dwInQueue,
	DWORD dwOutQueue
	);
extern OriginalSetupComm originalSetupComm;

typedef BOOL(WINAPI* OriginalWaitCommEvent)(
	HANDLE hFile,
	LPDWORD lpEvtMask,
	LPOVERLAPPED lpOverlapped
	);
extern OriginalWaitCommEvent originalWaitCommEvent;

typedef BOOL(WINAPI* OriginalGetOverlappedResult)(
	HANDLE hFile,
	LPOVERLAPPED lpOverlapped,
	LPDWORD lpNumberOfBytesTransferred,
	BOOL bWait
	);

extern OriginalGetOverlappedResult originalGetOverlappedResult;

typedef BOOL(WINAPI* OriginalClearCommError)(
	HANDLE hFile,
	LPDWORD lpErrors,
	LPCOMSTAT lpStat
	);
extern OriginalClearCommError originalClearCommError;

typedef int (WINAPI* OriginalShowCursor)(BOOL bShow);
extern OriginalShowCursor originalShowCursor;

typedef BOOL(WINAPI* OriginalSetForegroundWindow)(HWND hWnd);
extern OriginalSetForegroundWindow originalSetForegroundWindow;

typedef BOOL(WINAPI* OriginalDeviceIoControl)(
	HANDLE hDevice,
	DWORD dwIoControlCode,
	LPVOID lpInBuffer,
	DWORD nInBufferSize,
	LPVOID lpOutBuffer,
	DWORD nOutBufferSize,
	LPDWORD lpBytesReturned,
	LPOVERLAPPED lpOverlapped
	);
extern OriginalDeviceIoControl originalDeviceIoControl;

typedef LSTATUS(WINAPI* RegQueryValueExW_t)(
	HKEY, LPCWSTR, LPDWORD, LPDWORD, LPBYTE, LPDWORD
	);

extern RegQueryValueExW_t originalRegQueryValueExW;

typedef DWORD(WINAPI* WaitForSingleObject_t)(HANDLE, DWORD);
extern WaitForSingleObject_t originalWaitForSingleObject;

typedef VOID(WINAPI* EnterCriticalSection_t)(LPCRITICAL_SECTION);
extern EnterCriticalSection_t originalEnterCriticalSection;

HANDLE WINAPI HookedCreateFileW(
	LPCWSTR lpFileName,
	DWORD dwDesiredAccess,
	DWORD dwShareMode,
	LPSECURITY_ATTRIBUTES lpSecurityAttributes,
	DWORD dwCreationDisposition,
	DWORD dwFlagsAndAttributes,
	HANDLE hTemplateFile
);

BOOL WINAPI HookedSetCommState(
	HANDLE hFile,
	LPDCB lpDCB
);

BOOL WINAPI HookedGetCommState(
	HANDLE hFile,
	LPDCB lpDCB
);


BOOL WINAPI HookedSetCommTimeouts(
	HANDLE hFile,
	LPCOMMTIMEOUTS lpCommTimeouts
);

BOOL WINAPI HookedWriteFile(
	HANDLE hFile,
	LPCVOID lpBuffer,
	DWORD nNumberOfBytesToWrite,
	LPDWORD lpNumberOfBytesWritten,
	LPOVERLAPPED lpOverlapped
);

BOOL WINAPI HookedReadFile(
	HANDLE hFile,
	LPVOID lpBuffer,
	DWORD nNumberOfBytesToRead,
	LPDWORD lpNumberOfBytesRead,
	LPOVERLAPPED lpOverlapped
);

BOOL WINAPI HookedGetDefaultCommConfigW(
	LPCWSTR lpszName,
	LPCOMMCONFIG lpCC,
	LPDWORD lpdwSize
);

BOOL WINAPI HookedGetCommProperties(
	HANDLE hFile,
	LPCOMMPROP lpCommProp
);

BOOL WINAPI HookedSetupComm(
	HANDLE hFile,
	DWORD dwInQueue,
	DWORD dwOutQueue
);

BOOL WINAPI HookedWaitCommEvent(
	HANDLE hFile,
	LPDWORD lpEvtMask,
	LPOVERLAPPED lpOverlapped
);

BOOL WINAPI HookedGetOverlappedResult(
	HANDLE hFile,
	LPOVERLAPPED lpOverlapped,
	LPDWORD lpNumberOfBytesTransferred,
	BOOL bWait
);

BOOL WINAPI HookedClearCommError(
	HANDLE hFile,
	LPDWORD lpErrors,
	LPCOMSTAT lpStat
);

int WINAPI HookedShowCursor(BOOL bShow);

BOOL WINAPI HookedSetForegroundWindow(HWND hWnd);

BOOL WINAPI HookedDeviceIoControl(
	HANDLE hDevice,
	DWORD dwIoControlCode,
	LPVOID lpInBuffer,
	DWORD nInBufferSize,
	LPVOID lpOutBuffer,
	DWORD nOutBufferSize,
	LPDWORD lpBytesReturned,
	LPOVERLAPPED lpOverlapped
);

LSTATUS WINAPI HookedRegQueryValueExW(
	HKEY hKey,
	LPCWSTR lpValueName,
	LPDWORD lpReserved,
	LPDWORD lpType,
	LPBYTE lpData,
	LPDWORD lpcbData
);

DWORD WINAPI HookedWaitForSingleObject(HANDLE hHandle, DWORD dwMilliseconds);

VOID WINAPI HookedEnterCriticalSection(LPCRITICAL_SECTION lpCriticalSection);
#endif