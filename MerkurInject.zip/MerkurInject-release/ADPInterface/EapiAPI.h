#pragma once
#include "GlobalVar.h"
class CEapiAPI//public CUniAPI
{
public:
	CEapiAPI(void);
	~CEapiAPI(void);
	
	DWORD m_dw04;
	DWORD m_dw08;
	HANDLE m_dw0C;
	
public:

	virtual HANDLE 	sub_10002660(bool fFlag);
	virtual void 	sub_10002690(void);
	virtual int		sub_100026C0(void);
	virtual int		sub_100029F0(ArrayStr* pArryStr);
	virtual int  	sub_10007EF0();
	virtual int  	sub_10002720(bool flag, int nVal);
	virtual int  	sub_10002750(BYTE bCode, char a2);
    virtual int  	sub_100027C0(BYTE bCode, int nLen, char a3);
	virtual int  	sub_10002780(bool flag, int arg_4, int arg_8);
	virtual int  	sub_100026E0(BYTE bCode, char arg_4);
	virtual int  	sub_100027F0(BYTE bCode, StructSize13 stIn);
	virtual int  	sub_10002920(DWORD64* ret);
	virtual BOOL  	sub_10002970();
	virtual int 	sub_10009650(){return 0;};
	
	virtual BOOL		sub_100028D0(BYTE& ret);
	virtual BOOL	 	sub_10002900(int ret);
	virtual BOOL	 	sub_100028C0(BYTE& ret){ret = 0; return TRUE;};
	virtual BOOL	 	sub_1000B420(BYTE& ret){return TRUE;};
	virtual BOOL	 	sub_10002980(StructSize24 stVal);
	virtual int EapiInit_100026A0();
};
