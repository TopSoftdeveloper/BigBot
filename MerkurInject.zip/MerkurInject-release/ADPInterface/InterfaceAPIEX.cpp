#include "StdAfx.h"
#include "InterfaceAPIEX.h"
#include "CUniAPIEx.h"
#include "GlobalVar.h"
#include "EapiAPIEX_IES.h"
#include "EapiAPIEX_ADV.h"
#include "EapiAPIEX_DFI.h"
#include "EapiAPIEX_MSC.h"
#include "stdio.h"


CInterfaceAPIEX::CInterfaceAPIEX(void)
{
	m_dw0C= 0;
	m_dw10 = 0;
	m_hClass14 = 0;
}

CInterfaceAPIEX::~CInterfaceAPIEX(void)
{
}
int FormatStrA_100086A0(BYTE* pBuf, int nsize, char* szFormat, ...)
{
	va_list va; // [esp+1Ch] [ebp+14h] BYREF

	va_start(va, szFormat);
	memset(pBuf, 0, nsize);
	return _vsnprintf_s((char*)pBuf, nsize, 0xFFFFFFFF, szFormat, va);

}
bool FormatStrW_100052F0(WCHAR* wszBuf, int nsize, WCHAR* wszFormat, ...)
{
	int nret = 0;
	va_list va;
	va_start(va, wszFormat);
	memset(wszFormat, 0, nsize);
	nret = _vsnwprintf_s(wszBuf, nsize, 0xFFFFFFFF, wszFormat, va);
	if ((nret <= nsize) && nret >= 0)
	{
		return TRUE;
	}
	return FALSE;
}

BYTE g_pby_1001F848[0x40];
WCHAR g_pwsz_1001F788[0x20];
WCHAR g_pwsz_1001F7C8[0x40];
BYTE* g_psz_1001F888;
WORD g_pwsz_1001FBA8[32];
BYTE g_psz_1001FBE8[32];
DWORD CInterfaceAPIEX::sub_10009850(DWORD dwArg)
{
	HMODULE hMod;
	g_psz_1001F888 = new BYTE[0x20];
	hMod = LoadLibraryW(L"EApi_MSC.dll");
	DWORD dwSize = 0x20;
	DWORD dwRet = 0;
	DWORD dwtmp;
	int i = 0;
	if (!hMod) 
	{
		*(DWORD*)dwArg = 0;
		dwRet = 2010;
		//goto LABEL_32;
	}
	else
	{
		LPEApiLibInitialize EApiLibInitialize = (LPEApiLibInitialize)GetProcAddress(hMod, "_EApiLibInitialize@0");
		if (EApiLibInitialize)
		{
			dwtmp = EApiLibInitialize();
			if ( dwtmp && dwtmp != -2 )
			{
				dwRet = 2001;
				*(DWORD *)dwArg = 0;
				//goto LABEL_32;
			}
			else
			{
				LPEApiBoardGetStringA BoardGetStringA = (LPEApiBoardGetStringA)GetProcAddress(hMod, "_EApiBoardGetStringA@12");

				if (!BoardGetStringA)
				{
					dwRet = 0;
					*(DWORD *)dwArg = 0;
					//goto LABEL_32;
				}
				else{
				dwtmp = BoardGetStringA(0, (LPVOID)g_psz_1001F888, &dwSize);
				if (!dwtmp)
				{
					memset(g_pby_1001F848, 0, 0x40);
					FormatStrA_100086A0(g_pby_1001F848, 0x40, "%s", (char*)g_psz_1001F888);
					int nStrLen = strlen((char*)g_pby_1001F848);//v11
					dwSize = nStrLen;
					//MultiByteToWideChar(CP_ACP, 0, g_pby_1001F848, -1, g_pwsz_1001F7C8, 0x40)
					memset(g_pwsz_1001F7C8, 0,0x80);

					for ( i = 0; i < (int)dwSize; i++)
					{
						BYTE bytmp = g_pby_1001F848[i];
						if ( bytmp == 0x20 && (g_pby_1001F848[i+1] == 0x20 || !g_pby_1001F848[i+1] ) )
							break;
						g_pwsz_1001F7C8[i] = (WCHAR)g_pby_1001F848[i];
					}

					FormatStrW_100052F0(g_pwsz_1001F788, 0x20, (wchar_t *)L"%s", (wchar_t*)g_pwsz_1001F7C8);

					if ( !wcscmp(g_pwsz_1001F7C8, L"MSC Vertriebs GmbH") )
					{
						*(DWORD *)dwArg = 4;
						dwRet = 2000;
						//goto LABEL_32;
					}
					else
					{
						*(DWORD *)dwArg = 0;
						dwRet = 2010;
					}

				}
				else if (dwtmp == 0xFFFFF9FF)// -1537
				{
					delete[] g_psz_1001F888;
					g_psz_1001F888 = new BYTE[dwSize];
					memset(g_psz_1001F888, 0, dwSize);
					if (!BoardGetStringA(0, (LPVOID)g_psz_1001F888, &dwSize))
					{
						memset(g_pby_1001F848, 0, 0x40);
						memset(g_pwsz_1001F7C8, 0, 0x40);
						FormatStrA_100086A0(g_pby_1001F848, 0x40, "%s", (char*)g_psz_1001F888);
						int nStrLen1 = strlen((char*)g_pby_1001F848);//v11
						dwSize = nStrLen1;					
						memset((PBYTE)g_pwsz_1001F7C8, 0,0x80);

						for ( i = 0; i < (int)dwSize; i++)
						{
							BYTE bytmp = g_pby_1001F848[i];
							if ( bytmp == 0x20 && (g_pby_1001F848[i+1] == 0x20 || !g_pby_1001F848[i+1] ) )
								break;
							g_pwsz_1001F7C8[i] = (WCHAR)g_pby_1001F848[i];
						}
						FormatStrW_100052F0(g_pwsz_1001F788, 0x20, (wchar_t *)L"%s", (wchar_t*)g_pwsz_1001F7C8);
						if ( !wcscmp(g_pwsz_1001F7C8, L"MSC") )
						{
							*(DWORD *)dwArg = 4;
							dwRet = 2000;
							//goto LABEL_32;
						}
						else
						{
							*(DWORD *)dwArg = 0;
							dwRet = 2010;
							//goto LABEL_32;
						}
					}
					else///loc_10009B2B
					{
						*(DWORD *)dwArg = 0;
						dwRet = 2010;
					}

				}
				else
				{
					*(DWORD *)dwArg = 0;
				}
				}
			}
		}
		else ///10009b45
		{
			dwRet = 2001;
			*(DWORD *)dwArg = 0;			
		}
	}
	if ( g_psz_1001F888 ) delete[] g_psz_1001F888;
	if ( dwRet != 2001 && dwRet != 2010 )
	{
		LPEApiLibUnInitialize LPUninitial = (LPEApiLibUnInitialize)GetProcAddress(hMod, "_EApiLibUnInitialize@0");
		if ( LPUninitial )LPUninitial();
		FreeLibrary(hMod);
	}
	return dwRet;
}
DWORD CInterfaceAPIEX::sub_10009BB0(DWORD dwArg)
{
	HMODULE hMod;
	g_psz_1001F888 = new BYTE[0x20];
	hMod = LoadLibraryW(L"EApi_ADV.dll");
	DWORD dwSize = 0x20;
	DWORD dwRet = 0;
	DWORD dwtmp;
	int i = 0;
	if (!hMod) 
	{
		*(DWORD*)dwArg = 0;
		dwRet = 2010;
		//goto LABEL_32;
	}
	else
	{
		LPEApiLibInitialize EApiLibInitialize = (LPEApiLibInitialize)GetProcAddress(hMod, "_EApiLibInitialize@0");
		if (EApiLibInitialize)
		{
			dwtmp = EApiLibInitialize();
			if ( dwtmp && dwtmp != -2 )
			{
				dwRet = 2001;
				*(DWORD *)dwArg = 0;
				//goto LABEL_32;
			}
			else
			{
				LPEApiBoardGetStringA BoardGetStringA = (LPEApiBoardGetStringA)GetProcAddress(hMod, "_EApiBoardGetStringA@12");

				if (!BoardGetStringA)
				{
					dwRet = 0;
					*(DWORD *)dwArg = 0;
					//goto LABEL_32;
				}
				else{
					dwtmp = BoardGetStringA(0, (LPVOID)g_psz_1001F888, &dwSize);
					if (!dwtmp)
					{
						memset(g_pby_1001F848, 0, 0x40);
						FormatStrA_100086A0(g_pby_1001F848, 0x40, "%s", (char*)g_psz_1001F888);
						int nStrLen = strlen((char*)g_pby_1001F848);//v11
						dwSize = nStrLen;
						//MultiByteToWideChar(CP_ACP, 0, g_pby_1001F848, -1, g_pwsz_1001F7C8, 0x40)
						memset(g_pwsz_1001F7C8, 0,0x80);

						for ( i = 0; i < (int)dwSize; i++)
						{
							BYTE bytmp = g_pby_1001F848[i];
							if ( bytmp == 0x20 && (g_pby_1001F848[i+1] == 0x20 || !g_pby_1001F848[i+1] ) )
								break;
							g_pwsz_1001F7C8[i] = (WCHAR)g_pby_1001F848[i];
						}

						FormatStrW_100052F0(g_pwsz_1001F788, 0x20, (wchar_t *)L"%s", (wchar_t*)g_pwsz_1001F7C8);

						if ( !wcscmp(g_pwsz_1001F7C8, L"Advantech") )
						{
							*(DWORD *)dwArg = 3;
							dwRet = 2000;
							//goto LABEL_32;
						}
						else
						{
							*(DWORD *)dwArg = 0;
							dwRet = 2010;
						}

					}
					else if (dwtmp == 0xFFFFF9FF)// -1537
					{
						delete[] g_psz_1001F888;
						g_psz_1001F888 = new BYTE[dwSize];
						memset(g_psz_1001F888, 0, dwSize);
						if (!BoardGetStringA(0, (LPVOID)g_psz_1001F888, &dwSize))
						{
							memset(g_pby_1001F848, 0, 0x40);
							memset(g_pwsz_1001F7C8, 0, 0x40);
							FormatStrA_100086A0(g_pby_1001F848, 0x40, "%s", (char*)g_psz_1001F888);
							int nStrLen1 = strlen((char*)g_pby_1001F848);//v11
							dwSize = nStrLen1;					
							memset((PBYTE)g_pwsz_1001F7C8, 0,0x80);

							for ( i = 0; i < (int)dwSize; i++)
							{
								BYTE bytmp = g_pby_1001F848[i];
								if ( bytmp == 0x20 && (g_pby_1001F848[i+1] == 0x20 || !g_pby_1001F848[i+1] ) )
									break;
								g_pwsz_1001F7C8[i] = (WCHAR)g_pby_1001F848[i];
							}
							FormatStrW_100052F0(g_pwsz_1001F788, 0x20, (wchar_t *)L"%s", (wchar_t*)g_pwsz_1001F7C8);
							if ( !wcscmp(g_pwsz_1001F7C8, L"ADVANTECH") )
							{
								*(DWORD *)dwArg = 3;
								dwRet = 2000;
								//goto LABEL_32;
							}
							else
							{
								*(DWORD *)dwArg = 0;
								dwRet = 2010;
								//goto LABEL_32;
							}
						}
						else///loc_10009B2B
						{
							*(DWORD *)dwArg = 0;
							dwRet = 2010;
						}

					}
					else
					{
						*(DWORD *)dwArg = 0;
					}
				}
			}
		}
		else ///10009b45
		{
			dwRet = 2001;
			*(DWORD *)dwArg = 0;			
		}
	}
	if ( g_psz_1001F888 ) delete[] g_psz_1001F888;
	if ( dwRet != 2001 && dwRet != 2010 )
	{
		LPEApiLibUnInitialize LPUninitial = (LPEApiLibUnInitialize)GetProcAddress(hMod, "_EApiLibUnInitialize@0");
		if ( LPUninitial )LPUninitial();
		FreeLibrary(hMod);
	}
	return dwRet;
}
DWORD CInterfaceAPIEX::sub_10009F10(DWORD dwArg)
{
	HMODULE hMod;
	g_psz_1001F888 = new BYTE[0x20];
	hMod = LoadLibraryW(L"EApi_IES.dll");
	DWORD dwSize = 0x20;
	DWORD dwRet = 0;
	DWORD dwtmp;
	int i = 0;
	if (!hMod) 
	{
		*(DWORD*)dwArg = 0;
		dwRet = 2010;
		//goto LABEL_32;
	}
	else
	{
		LPEApiLibInitialize EApiLibInitialize = (LPEApiLibInitialize)GetProcAddress(hMod, "_EApiLibInitialize@0");
		if (EApiLibInitialize)
		{
			dwtmp = EApiLibInitialize();
			if ( dwtmp && dwtmp != -2 )
			{
				dwRet = 2001;
				*(DWORD *)dwArg = 0;
				//goto LABEL_32;
			}
			else
			{
				LPEApiBoardGetStringA BoardGetStringA = (LPEApiBoardGetStringA)GetProcAddress(hMod, "_EApiBoardGetStringA@12");

				if (!BoardGetStringA)
				{
					dwRet = 0;
					*(DWORD *)dwArg = 0;
					//goto LABEL_32;
				}
				else{
					dwtmp = BoardGetStringA(0, (LPVOID)g_psz_1001F888, &dwSize);
					if (!dwtmp)
					{
						memset(g_pby_1001F848, 0, 0x40);
						FormatStrA_100086A0(g_pby_1001F848, 0x40, "%s", (char*)g_psz_1001F888);
						int nStrLen = strlen((char*)g_pby_1001F848);//v11
						dwSize = nStrLen;
						//MultiByteToWideChar(CP_ACP, 0, g_pby_1001F848, -1, g_pwsz_1001F7C8, 0x40)
						memset(g_pwsz_1001F7C8, 0,0x80);

						for ( i = 0; i < (int)dwSize; i++)
						{
							BYTE bytmp = g_pby_1001F848[i];
							if ( bytmp == 0x20 && (g_pby_1001F848[i+1] == 0x20 || !g_pby_1001F848[i+1] ) )
								break;
							g_pwsz_1001F7C8[i] = (WCHAR)g_pby_1001F848[i];
						}

						FormatStrW_100052F0(g_pwsz_1001F788, 0x20, (wchar_t *)L"%s", (wchar_t*)g_pwsz_1001F7C8);

						if ( !wcscmp(g_pwsz_1001F7C8, L"ies") )
						{
							*(DWORD *)dwArg = 2;
							dwRet = 2000;
							//goto LABEL_32;
						}
						else
						{
							*(DWORD *)dwArg = 0;
							dwRet = 2010;
						}

					}
					else if (dwtmp == 0xFFFFF9FF)// -1537
					{
						delete[] g_psz_1001F888;
						g_psz_1001F888 = new BYTE[dwSize];
						memset(g_psz_1001F888, 0, dwSize);
						if (!BoardGetStringA(0, (LPVOID)g_psz_1001F888, &dwSize))
						{
							memset(g_pby_1001F848, 0, 0x40);
							memset(g_pwsz_1001F7C8, 0, 0x40);
							FormatStrA_100086A0(g_pby_1001F848, 0x40, "%s", (char*)g_psz_1001F888);
							int nStrLen1 = strlen((char*)g_pby_1001F848);//v11
							dwSize = nStrLen1;					
							memset((PBYTE)g_pwsz_1001F7C8, 0,0x80);

							for ( i = 0; i < (int)dwSize; i++)
							{
								BYTE bytmp = g_pby_1001F848[i];
								if ( bytmp == 0x20 && (g_pby_1001F848[i+1] == 0x20 || !g_pby_1001F848[i+1] ) )
									break;
								g_pwsz_1001F7C8[i] = (WCHAR)g_pby_1001F848[i];
							}
							FormatStrW_100052F0(g_pwsz_1001F788, 0x20, (wchar_t *)L"%s", (wchar_t*)g_pwsz_1001F7C8);
							if ( !wcscmp(g_pwsz_1001F7C8, L"ies") )
							{
								*(DWORD *)dwArg = 2;
								dwRet = 2000;
								//goto LABEL_32;
							}
							else
							{
								*(DWORD *)dwArg = 0;
								dwRet = 2010;
								//goto LABEL_32;
							}
						}
						else///loc_10009B2B
						{
							*(DWORD *)dwArg = 0;
							dwRet = 2010;
						}

					}
					else
					{
						*(DWORD *)dwArg = 0;
					}
				}
			}
		}
		else ///10009b45
		{
			dwRet = 2001;
			*(DWORD *)dwArg = 0;			
		}
	}
	if ( g_psz_1001F888 ) delete[] g_psz_1001F888;
	if ( dwRet != 2001 && dwRet != 2010 )
	{
		LPEApiLibUnInitialize LPUninitial = (LPEApiLibUnInitialize)GetProcAddress(hMod, "_EApiLibUnInitialize@0");
		if ( LPUninitial )LPUninitial();
		FreeLibrary(hMod);
	}
	return dwRet;

}
DWORD CInterfaceAPIEX::sub_1000A270(DWORD dwArg)
{
	HMODULE hMod;
	g_psz_1001F888 = new BYTE[0x20];
	hMod = LoadLibraryW(L"EApi_DFI.dll");
	DWORD dwSize = 0x20;
	DWORD dwRet = 0;
	DWORD dwtmp;
	int i = 0;
	if (!hMod) 
	{
		*(DWORD*)dwArg = 0;
		dwRet = 2010;
		//goto LABEL_32;
	}
	else
	{
		LPEApiLibInitialize EApiLibInitialize = (LPEApiLibInitialize)GetProcAddress(hMod, "_EApiLibInitialize@0");
		if (EApiLibInitialize)
		{
			dwtmp = EApiLibInitialize();
			if ( dwtmp && dwtmp != -2 )
			{
				dwRet = 2001;
				*(DWORD *)dwArg = 0;
				//goto LABEL_32;
			}
			else
			{
				LPEApiBoardGetStringA BoardGetStringA = (LPEApiBoardGetStringA)GetProcAddress(hMod, "_EApiBoardGetStringA@12");

				if (!BoardGetStringA)
				{
					dwRet = 0;
					*(DWORD *)dwArg = 0;
					//goto LABEL_32;
				}
				else{
					dwtmp = BoardGetStringA(0, (LPVOID)g_psz_1001F888, &dwSize);
					if (!dwtmp)
					{
						memset(g_pby_1001F848, 0, 0x40);
						FormatStrA_100086A0(g_pby_1001F848, 0x40, "%s", (char*)g_psz_1001F888);
						int nStrLen = strlen((char*)g_pby_1001F848);//v11
						dwSize = nStrLen;
						//MultiByteToWideChar(CP_ACP, 0, g_pby_1001F848, -1, g_pwsz_1001F7C8, 0x40)
						memset(g_pwsz_1001F7C8, 0,0x80);

						for ( i = 0; i < (int)dwSize; i++)
						{
							BYTE bytmp = g_pby_1001F848[i];
							if ( bytmp == 0x20 && (g_pby_1001F848[i+1] == 0x20 || !g_pby_1001F848[i+1] ) )
								break;
							g_pwsz_1001F7C8[i] = (WCHAR)g_pby_1001F848[i];
						}

						FormatStrW_100052F0(g_pwsz_1001F788, 0x20, (wchar_t *)L"%s", (wchar_t*)g_pwsz_1001F7C8);

						if ( !wcscmp(g_pwsz_1001F7C8, L"DFI Inc.") )
						{
							*(DWORD *)dwArg = 5;
							dwRet = 2000;
							//goto LABEL_32;
						}
						else
						{
							*(DWORD *)dwArg = 0;
							dwRet = 2010;
						}

					}
					else if (dwtmp == 0xFFFFF9FF)// -1537
					{
						delete[] g_psz_1001F888;
						g_psz_1001F888 = new BYTE[dwSize];
						memset(g_psz_1001F888, 0, dwSize);
						if (!BoardGetStringA(0, (LPVOID)g_psz_1001F888, &dwSize))
						{
							memset(g_pby_1001F848, 0, 0x40);
							memset(g_pwsz_1001F7C8, 0, 0x40);
							FormatStrA_100086A0(g_pby_1001F848, 0x40, "%s", (char*)g_psz_1001F888);
							int nStrLen1 = strlen((char*)g_pby_1001F848);//v11
							dwSize = nStrLen1;					
							memset((PBYTE)g_pwsz_1001F7C8, 0,0x80);

							for ( i = 0; i < (int)dwSize; i++)
							{
								BYTE bytmp = g_pby_1001F848[i];
								if ( bytmp == 0x20 && (g_pby_1001F848[i+1] == 0x20 || !g_pby_1001F848[i+1] ) )
									break;
								g_pwsz_1001F7C8[i] = (WCHAR)g_pby_1001F848[i];
							}
							FormatStrW_100052F0(g_pwsz_1001F788, 0x20, (wchar_t *)L"%s", (wchar_t*)g_pwsz_1001F7C8);
							if ( !wcscmp(g_pwsz_1001F7C8, L"DFI Inc.") )
							{
								*(DWORD *)dwArg = 5;
								dwRet = 2000;
								//goto LABEL_32;
							}
							else
							{
								*(DWORD *)dwArg = 0;
								dwRet = 2010;
								//goto LABEL_32;
							}
						}
						else///loc_10009B2B
						{
							*(DWORD *)dwArg = 0;
							dwRet = 2010;
						}

					}
					else
					{
						*(DWORD *)dwArg = 0;
					}
				}
			}
		}
		else ///10009b45
		{
			dwRet = 2001;
			*(DWORD *)dwArg = 0;			
		}
	}
	if ( g_psz_1001F888 ) delete[] g_psz_1001F888;
	if ( dwRet != 2001 && dwRet != 2010 )
	{
		LPEApiLibUnInitialize LPUninitial = (LPEApiLibUnInitialize)GetProcAddress(hMod, "_EApiLibUnInitialize@0");
		if ( LPUninitial )LPUninitial();
		FreeLibrary(hMod);
	}
	return dwRet;

}
DWORD CInterfaceAPIEX::sub_1000A5D0(DWORD dwVar)
{
	int i = 0;
	DWORD dwVar4 = 0;
	DWORD dwebx = dwVar;
	DWORD dwRet = sub_10009850(dwebx);
	if (*(DWORD*)dwebx != 0) return dwRet;
	dwRet = sub_10009BB0(dwebx);
	if (*(DWORD*)dwebx != 0) return dwRet;
	dwRet = sub_10009F10(dwebx);
	if (*(DWORD*)dwebx != 0) return dwRet;
	dwRet = sub_1000A270(dwebx);
	if (*(DWORD*)dwebx != 0) return dwRet;

	LPFnU_V EAPI_1 = (LPFnU_V)GetProcAddress(hEAPI, "EAPI_1");
	EAPI_1();

	if (dwRet) return 2001;
	for (i = 0; i < 32; i++)
	{
		g_psz_1001FBE8[i] = 0;
		g_pwsz_1001FBA8[i] = 0;
	}
	dwVar4 = 0x20;

	LPFnD_DDD EAPI_3 = (LPFnD_DDD)GetProcAddress(hEAPI, "EAPI_3");

	dwRet = EAPI_3(0, (DWORD)g_psz_1001FBE8, (DWORD)&dwVar4);
	if (dwRet) return dwRet;
	if ( dwVar4 > 0 )
	{
		do
		{
			if ( dwRet >= 32 )
				break;
			*((WORD *)g_pwsz_1001FBA8 + dwRet) = *((BYTE *)g_psz_1001FBE8 + dwRet);
			++dwRet;
		}
		while ( dwRet < 32 );
	}
	if ( !wcscmp((WCHAR*)g_pwsz_1001FBA8, L"Congatec") )
	{			
		*(DWORD *)dwVar = 1;
		return 2000;
	}
	if ( !wcscmp((WCHAR*)g_pwsz_1001FBA8, L"ies ") )
	{			
		*(DWORD *)dwVar = 2;
		return 2000;
	}
	if ( !wcscmp((WCHAR*)g_pwsz_1001FBA8, L"DFI") )
	{			
		*(DWORD *)dwVar = 5;
		return 2000;
	}
	*(DWORD *)dwVar = 0;
	return 2000;
}
HANDLE CInterfaceAPIEX::ApiEXInit_1000A7E0()
{
	CUniAPIEx *pCUniAPIEx = new CUniAPIEx;
	DWORD dwVar14 = 0;
	if (pCUniAPIEx->GetTemperatur((unsigned int*)&dwVar14))
	{		
		CUniAPIEx *pCUniAPIEx2 = new CUniAPIEx;
		if (pCUniAPIEx2)
		{
			m_hClass14 = pCUniAPIEx2;
			pCUniAPIEx2->m_dw04 = pCUniAPIEx->m_dw14;
			pCUniAPIEx2->m_dw08 = pCUniAPIEx->m_dw18;
			delete pCUniAPIEx;
			return pCUniAPIEx2;
		}
		return 0;
	}
	//}
	else
	{
		DWORD dwRet = 0;
#if 0
		sub_1000A5D0((DWORD)&dwVar14);
#endif
		dwVar14 = 2;
		if (dwVar14 == 2)
		{
			CEapiAPIEX_IES* pEapiEX = new CEapiAPIEX_IES;
			dwRet = pEapiEX->sub_100061D0();
			if (!dwRet) return 0;
			CEapiAPIEX_IES* pEapiEX2 = new CEapiAPIEX_IES;
			delete pEapiEX;
			m_hClass14 = pEapiEX2;
			pEapiEX2->m_dw04 = 0;
			pEapiEX2->m_dw08 = 0;
			return pEapiEX2;
		}
		else if (dwVar14 == 3)
		{
			CEapiAPIEX_ADV* pEapiEXADV = new CEapiAPIEX_ADV;
			dwRet = pEapiEXADV->sub_10002EC0();
			if (!dwRet) return 0;
			CEapiAPIEX_ADV* pEapiEXADV2 = new CEapiAPIEX_ADV;
			delete pEapiEXADV;
			m_hClass14 = pEapiEXADV2;
			pEapiEXADV2->m_dw04 = 0;
			pEapiEXADV2->m_dw08 = 0;
			return pEapiEXADV2;
		}
		else if (dwVar14 == 4)
		{
			CEapiAPIEX_MSC* pEapiEXMSC = new CEapiAPIEX_MSC;
			dwRet = pEapiEXMSC->sub_10007E60();
			if (!dwRet) return 0;
			CEapiAPIEX_MSC* pEapiEXMSC2 = new CEapiAPIEX_MSC;
			delete pEapiEXMSC;
			m_hClass14 = pEapiEXMSC2;
			pEapiEXMSC2->m_dw04 = 0;
			pEapiEXMSC2->m_dw08 = 0;
			return pEapiEXMSC2;
		}
		else if (dwVar14 == 5)
		{
			CEapiAPIEX_DFI* pEapiEXDFI = new CEapiAPIEX_DFI;
			dwRet = pEapiEXDFI->sub_100048F0();
			if (!dwRet) return 0;
			CEapiAPIEX_DFI* pEapiEXDFI2 = new CEapiAPIEX_DFI;
			delete pEapiEXDFI;
			m_hClass14 = pEapiEXDFI2;
			pEapiEXDFI2->m_dw04 = 0;
			pEapiEXDFI2->m_dw08 = 0;
			return pEapiEXDFI2;
		}
   }
   
	return m_hClass14;
}