#include "StdAfx.h"
#include "EapiAPIEX_ADV.h"
#include "GlobalVar.h"
#include "stdlib.h"
#include "PhysicalMonitorEnumerationAPI.h"
#include "LowLevelMonitorConfigurationAPI.h"
#pragma comment (lib, "dxva2.lib")
DWORD g_dword_1001F52C;

BOOL CALLBACK fnEnumProc_10004730( HMONITOR hMonitor,  // handle to display monitor
						   HDC hDC,     // handle to monitor DC
						   LPRECT rect, // monitor intersection rectangle
						   LPARAM dwData )      // data????????
{
	myMonitorInfo myMonInfo; 
	myMonInfo.hdc = hDC;
	myMonInfo.hMonitor = hMonitor;
	myMonInfo.rect.left = rect->left;
	myMonInfo.rect.top = rect->top;
	myMonInfo.rect.right = rect->right;
	myMonInfo.rect.bottom = rect->bottom;

	g_dword_1001F52C = dwData;	
	myMonInfo.nInfo = 0;
	myMonInfo.nInfoFlag = 0;
	addNewDisplayInfoToList(dwData, &myMonInfo);
	return 1;
}
CEapiAPIEX_ADV::CEapiAPIEX_ADV(void)//  sub_100047C0
{
	infoStructure* pInfoStr;
	pInfoStr = new infoStructure;
	pInfoStr->nMonIdx = -1;
	pInfoStr->next = 0;
	myMonitorInfo* pMyMonInfo;
	pMyMonInfo = new myMonitorInfo;// malloc(544); 0x220
	pInfoStr->myMoninfo = pMyMonInfo;
	memset(pMyMonInfo, 0, sizeof(myMonitorInfo));
	m_pInfoStart = pInfoStr;
	m_pInfoLast = pInfoStr;
	int nNumMonitor = GetSystemMetrics(SM_CMONITORS);
	MONITORINFOEXW moninfo;
	moninfo.cbSize = 104;
	m_pInfoLast->nMonIdx = 0;	
	m_pInfoLast->myMoninfo->nInfo = 0;

	EnumDisplayMonitors(0,0,fnEnumProc_10004730, (LPARAM)m_pInfoLast);

	m_pInfoLast = m_pInfoLast->next;
	if(m_pInfoLast->nMonIdx <= nNumMonitor)
	{
		HMONITOR hMonitor;
		while(1)
		{
			hMonitor = m_pInfoLast->myMoninfo->hMonitor;
			GetMonitorInfoW(hMonitor, &moninfo);
			wcscpy_s(m_pInfoLast->myMoninfo->wszDevice, 0xFF, moninfo.szDevice);
			m_pInfoLast->myMoninfo->nInfoFlag = moninfo.dwFlags;
			m_pInfoLast = m_pInfoLast->next;
			if (!m_pInfoLast) break;	
			if (m_pInfoLast->nMonIdx > nNumMonitor) break;
		}
	}
	m_hMod14 = 0;
}

CEapiAPIEX_ADV::~CEapiAPIEX_ADV(void)
{
}
//typedef UINT (__thiscall* LPEApiLibInitialize)( VOID );
//typedef VOID (__thiscall* LPEApiLibUnInitialize)( VOID );
LPEApiLibInitialize g_lpfnEApiLibInitialADV = 0;
LPEApiLibUnInitialize g_lpfnEApiLibUnInitializeADV = 0;


void CEapiAPIEX_ADV::sub_100087A0()
{
	//DWORD dweax = m_pInfoStr0C;
	m_pInfoLast = m_pInfoStart;
	if (m_pInfoStart->nMonIdx == 0)
	{
		infoStructure* pNextInfo;
		infoStructure* pCurrInfo;
		infoStructure* pPrevInfo;
		pCurrInfo = m_pInfoStart;
		while(1)
		{		
			pNextInfo = pCurrInfo->next;
			pPrevInfo = pCurrInfo;
			if (pNextInfo)
			{
				while(1)
				{
					pPrevInfo = pCurrInfo;
					pCurrInfo = pNextInfo;
					pNextInfo = pCurrInfo->next;					
					if(pNextInfo == 0) break;
				}
			}
			if(pCurrInfo->nMonIdx == 0) break;
			delete pCurrInfo;
			pPrevInfo->next = 0;
			pCurrInfo = m_pInfoStart;
			pNextInfo = pCurrInfo;
			m_pInfoLast = pCurrInfo;
			if (pNextInfo->nMonIdx != 0) break; 
		}
	}
	delete m_pInfoStart;
	m_dw18 = -1;
	if (m_hMod14)
	{
		g_lpfnEApiLibUnInitializeADV = (LPEApiLibUnInitialize)GetProcAddress(m_hMod14, "_EApiLibUnInitialize@0");
		if ((DWORD)g_lpfnEApiLibUnInitializeADV)
		{
			g_lpfnEApiLibUnInitializeADV();
		}
	}
	if (m_hMod14)
	{
		FreeLibrary(m_hMod14);
	}
	m_hMod14 = NULL;
}

BOOL CEapiAPIEX_ADV::SusiI2CWrite_100031D0(BYTE byVal, DWORD arg_4, DWORD arg_8)
{
	HMODULE hMod; 	
	if ( byVal != 0x36 )	return 0;
	hMod = m_hMod14;
	if ( !hMod )
	{
		hMod = LoadLibraryW(L"EApi_ADV.dll");
		m_hMod14 = hMod;
	}
	LPFnD_BDD SusiI2CWrite = (LPFnD_BDD)GetProcAddress(hMod, "_SusiI2CWrite@12");
	return (SusiI2CWrite && SusiI2CWrite(0x36, arg_8, arg_4) == 0);
}


BOOL CEapiAPIEX_ADV::GetVCPFeatureAndVCPFeatureReply_10006970(DWORD* dwCurVal, DWORD nNum)
{
	BOOL bRet = FALSE;

	DWORD pdwNumberOfPhysicalMonitors; 
	DWORD pdwCurrentValue; 
	DWORD pdwMaximumValue; 

	pdwCurrentValue = 0;
	pdwMaximumValue = 0;
	pdwNumberOfPhysicalMonitors = 0;
	int SystemMetrics = GetSystemMetrics(SM_CMONITORS);

	if (nNum > 0 && nNum <= SystemMetrics )
	{
		m_pInfoLast = m_pInfoStart;
		m_pInfoLast = m_pInfoStart->next;
		if ( m_pInfoLast->nMonIdx <= SystemMetrics )
		{
			while (1)
			{
				if (nNum == m_pInfoLast->nMonIdx)
				{
					if (GetNumberOfPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, &pdwNumberOfPhysicalMonitors))
					{
						LPPHYSICAL_MONITOR phymonitor =  new PHYSICAL_MONITOR[pdwNumberOfPhysicalMonitors];
						if (phymonitor)
						{
							if (GetPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, pdwNumberOfPhysicalMonitors, phymonitor))
							{
								if (GetVCPFeatureAndVCPFeatureReply(phymonitor[0].hPhysicalMonitor, 0x12, NULL, &pdwCurrentValue,&pdwMaximumValue))
								{
									*dwCurVal = pdwCurrentValue;
									bRet = TRUE;
								}
								else
									GetLastError();

								DestroyPhysicalMonitors(pdwNumberOfPhysicalMonitors, phymonitor);
								delete[] phymonitor;
							}

						}
					}
					return bRet;

				}
				m_pInfoLast = m_pInfoLast->next;
				if (m_pInfoLast == 0 || m_pInfoLast->nMonIdx > SystemMetrics)
				{
					return 0;
				}
			}
		}
	}
	return 0;
}
BOOL CEapiAPIEX_ADV::SetVCPFeature_10006A80(DWORD* pdwNewVal, DWORD nNum)
{
	BOOL bRet = FALSE;

	DWORD pdwNumberOfPhysicalMonitors;
	DWORD dwCurrentValue; 
	DWORD dwMaximumValue; 

	dwCurrentValue = 0;
	dwMaximumValue = 0;
	pdwNumberOfPhysicalMonitors = 0;
	int SystemMetrics = GetSystemMetrics(SM_CMONITORS);

	if (nNum > 0 && nNum <= SystemMetrics )
	{
		m_pInfoLast = m_pInfoStart;
		m_pInfoLast = m_pInfoStart->next;
		if ( m_pInfoLast->nMonIdx <= SystemMetrics )
		{
			while (1)
			{
				if (nNum == m_pInfoLast->nMonIdx)
				{
					if (GetNumberOfPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, &pdwNumberOfPhysicalMonitors))
					{
						LPPHYSICAL_MONITOR phymonitor =  new PHYSICAL_MONITOR[pdwNumberOfPhysicalMonitors];
						if (phymonitor)
						{
							if (GetPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, pdwNumberOfPhysicalMonitors, phymonitor))
							{
								if (SetVCPFeature(phymonitor[0].hPhysicalMonitor, 0x12, *pdwNewVal))
								{
									bRet = TRUE;
								}
								else
									GetLastError();

								DestroyPhysicalMonitors(pdwNumberOfPhysicalMonitors, phymonitor);
								delete[] phymonitor;
							}

						}
					}
					return bRet;

				}
				m_pInfoLast = m_pInfoLast->next;
				if (m_pInfoLast == 0 || m_pInfoLast->nMonIdx > SystemMetrics)
				{
					return 0;
				}
			}
		}
	}
	return 0;
}

BOOL CEapiAPIEX_ADV::GetVCPFeatureAndVCPFeatureReply_10006B70(DWORD* pdwCurVal, int nNum)
{
	BOOL bRet = FALSE;

	DWORD pdwNumberOfPhysicalMonitors; 
	DWORD pdwCurrentValue; 
	DWORD pdwMaximumValue; 

	pdwCurrentValue = 0;
	pdwMaximumValue = 0;
	pdwNumberOfPhysicalMonitors = 0;
	int SystemMetrics = GetSystemMetrics(SM_CMONITORS);

	if (nNum > 0 && nNum <= SystemMetrics )
	{
		m_pInfoLast = m_pInfoStart;
		m_pInfoLast = m_pInfoStart->next;
		if ( m_pInfoLast->nMonIdx <= SystemMetrics )
		{
			while (1)
			{
				if (nNum == m_pInfoLast->nMonIdx)
				{
					if (GetNumberOfPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, &pdwNumberOfPhysicalMonitors))
					{
						LPPHYSICAL_MONITOR phymonitor =  new PHYSICAL_MONITOR[pdwNumberOfPhysicalMonitors];
						if (phymonitor)
						{
							if (GetPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, pdwNumberOfPhysicalMonitors, phymonitor))
							{
								if (GetVCPFeatureAndVCPFeatureReply(phymonitor[0].hPhysicalMonitor, 0x10, NULL, &pdwCurrentValue,&pdwMaximumValue))
								{
									*pdwCurVal = pdwCurrentValue;
									bRet = TRUE;
								}
								else
									GetLastError();

								DestroyPhysicalMonitors(pdwNumberOfPhysicalMonitors, phymonitor);
								delete[] phymonitor;
							}

						}
					}
					return bRet;

				}
				m_pInfoLast = m_pInfoLast->next;
				if (m_pInfoLast == 0 || m_pInfoLast->nMonIdx > SystemMetrics)
				{
					return 0;
				}
			}
		}
	}
	return 0;
}
BOOL CEapiAPIEX_ADV::SetVCPFeature_10005070(DWORD* pdwNewVal, DWORD nNum)
{
	BOOL bRet = FALSE;
	DWORD pdwNumberOfPhysicalMonitors; 
	DWORD pdwCurrentValue; 
	DWORD pdwMaximumValue; 

	pdwCurrentValue = 0;
	pdwMaximumValue = 0;
	pdwNumberOfPhysicalMonitors = 0;
	int SystemMetrics = GetSystemMetrics(SM_CMONITORS);

	if (nNum > 0 && nNum <= SystemMetrics )
	{
		m_pInfoLast = m_pInfoStart;
		m_pInfoLast = m_pInfoStart->next;
		if ( m_pInfoLast->nMonIdx <= SystemMetrics )
		{
			while (1)
			{
				if (nNum == m_pInfoLast->nMonIdx)
				{
					if (GetNumberOfPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, &pdwNumberOfPhysicalMonitors))
					{
						LPPHYSICAL_MONITOR phymonitor =  new PHYSICAL_MONITOR[pdwNumberOfPhysicalMonitors];
						if (phymonitor)
						{
							if (GetPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, pdwNumberOfPhysicalMonitors, phymonitor))
							{
								if (SetVCPFeature(phymonitor[0].hPhysicalMonitor, 0x10, *pdwNewVal))
								{
									bRet = TRUE;
								}
								else
									GetLastError();

								DestroyPhysicalMonitors(pdwNumberOfPhysicalMonitors, phymonitor);
								delete[] phymonitor;
							}

						}
					}
					return bRet;

				}
				m_pInfoLast = m_pInfoLast->next;
				if (m_pInfoLast == 0 || m_pInfoLast->nMonIdx > SystemMetrics)
				{
					return 0;
				}
			}
		}
	}
	return 0;
}
BOOL CEapiAPIEX_ADV::sub_10003720(BYTE byVal, BYTE* bySrc, BYTE byLen)
{
	BYTE byBuf[32]; 	
	memset(byBuf, 0, sizeof(byBuf));
	byBuf[0] = byVal;
	memcpy(byBuf, bySrc, byLen);
	if (SusiI2CWrite_100031D0(0x36, byLen + 1, (DWORD)byBuf) == 1) return TRUE;
	else return FALSE;
}
BOOL CEapiAPIEX_ADV::SetVCPFeature_10005200(int nNum, BYTE bVCPCode, DWORD* pdwNewVal)
{
	BOOL bRet = FALSE;
	DWORD pdwNumberOfPhysicalMonitors;
	DWORD pdwCurrentValue; 
	DWORD pdwMaximumValue; 

	pdwCurrentValue = 0;
	pdwMaximumValue = 0;
	pdwNumberOfPhysicalMonitors = 0;
	int SystemMetrics = GetSystemMetrics(SM_CMONITORS);

	if (nNum > 0 && nNum <= SystemMetrics )
	{
		m_pInfoLast = m_pInfoStart;
		m_pInfoLast = m_pInfoStart->next;
		if ( m_pInfoLast->nMonIdx <= SystemMetrics )
		{
			while (1)
			{
				if (nNum == m_pInfoLast->nMonIdx)
				{
					if (GetNumberOfPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, &pdwNumberOfPhysicalMonitors))
					{
						LPPHYSICAL_MONITOR phymonitor =  new PHYSICAL_MONITOR[pdwNumberOfPhysicalMonitors];
						if (phymonitor)
						{
							if (GetPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, pdwNumberOfPhysicalMonitors, phymonitor))
							{
								if (SetVCPFeature(phymonitor[0].hPhysicalMonitor, bVCPCode, *pdwNewVal))
								{
									bRet = TRUE;
								}
								else
									GetLastError();
								DestroyPhysicalMonitors(pdwNumberOfPhysicalMonitors, phymonitor);
								delete[] phymonitor;
							}

						}
					}
					return bRet;
				}
				m_pInfoLast = m_pInfoLast->next;
				if (m_pInfoLast == 0 || m_pInfoLast->nMonIdx > SystemMetrics)
				{
					return 0;
				}
			}
		}
	}
	return 0;
}
BOOL CEapiAPIEX_ADV::GetVCPFeatureAndVCPFeatureReply_10003850(int nArgNum, BYTE bVCPCode, DWORD* pdwCurrentVal, DWORD* dwMaxVal)
{
	BOOL bRet = FALSE;
	DWORD dwCurrentValue;
	DWORD dwMaximumValue;	
	DWORD dwNumOfPhyMonitors = 0; 
	int nSystemMetrics = GetSystemMetrics(SM_CMONITORS);

	if (nArgNum > 0 && nArgNum <= nSystemMetrics )
	{
		m_pInfoLast = m_pInfoStart;
		m_pInfoLast = m_pInfoStart->next;
		if ( m_pInfoLast->nMonIdx <= nSystemMetrics )
		{
			while (1)
			{
				if (nArgNum == m_pInfoLast->nMonIdx)
				{
					if (GetNumberOfPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, &dwNumOfPhyMonitors))
					{
						LPPHYSICAL_MONITOR phymonitor =  new PHYSICAL_MONITOR[dwNumOfPhyMonitors];//(LPPHYSICAL_MONITOR)malloc(dwNumOfPhyMonitors*sizeof(PHYSICAL_MONITOR));
						if (phymonitor)
						{
							if (GetPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, dwNumOfPhyMonitors, phymonitor))
							{
								if (GetVCPFeatureAndVCPFeatureReply(phymonitor[0].hPhysicalMonitor, bVCPCode, NULL, &dwCurrentValue,&dwMaximumValue))
								{
									*pdwCurrentVal = dwCurrentValue;
									*dwMaxVal = dwMaximumValue;
									bRet = TRUE;
								}
								else
									GetLastError();

								DestroyPhysicalMonitors(dwNumOfPhyMonitors, phymonitor);
								delete[] phymonitor;
							}
						}
					}
					return bRet;
				}
				m_pInfoLast = m_pInfoLast->next;
				if (m_pInfoLast == 0 || m_pInfoLast->nMonIdx > nSystemMetrics)
				{
					return 0;
				}
			}
		}
	}
	return 0;
}


BOOL CEapiAPIEX_ADV::SaveCurrentSettings_10006D60(int nNum)
{
	BOOL bRet = FALSE; 	
	PHYSICAL_MONITOR* pPhyMonitor; 
	DWORD dwNumPhyMonitors = 0; 
	int nSystemMetrics = GetSystemMetrics(SM_CMONITORS);
	if (!nNum) return FALSE;
	if ( nNum <= nSystemMetrics )
	{		
		m_pInfoLast = m_pInfoStart->next;
		if ( m_pInfoLast->nMonIdx <= nSystemMetrics )
		{
			while ( 1 )
			{				
				if ( nNum == m_pInfoLast->nMonIdx ) break;
				m_pInfoLast = m_pInfoLast->next;
				if ( !m_pInfoLast || m_pInfoLast->nMonIdx > nSystemMetrics) return FALSE;
			}
			if ( GetNumberOfPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, &dwNumPhyMonitors) )
			{
				pPhyMonitor = new PHYSICAL_MONITOR[dwNumPhyMonitors] ;
				if ( pPhyMonitor )
				{
					if ( GetPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, dwNumPhyMonitors,	pPhyMonitor) )
					{
						if ( SaveCurrentSettings(pPhyMonitor->hPhysicalMonitor) )
							bRet = TRUE;
						else
							GetLastError();
					}
					DestroyPhysicalMonitors(dwNumPhyMonitors, pPhyMonitor);
					delete[] pPhyMonitor;
				}
			}
		}
	}
	return bRet;
}
DWORD CEapiAPIEX_ADV::sub_10002EC0()
{
	HMODULE hMod; 
	m_dw18 = 0;
	if (!m_hMod14)
	{
		hMod = LoadLibraryW(L"EApi_ADV.dll");
		m_hMod14 = hMod;
	}
	if (!hMod) return 0;
	g_lpfnEApiLibInitialADV = (LPEApiLibInitialize)GetProcAddress(hMod, "_EApiLibInitialize@0");
	DWORD dwRet;
	if ((DWORD)g_lpfnEApiLibInitialADV == 0)
	{
		sub_100087A0();
		return 0;	
	}
	dwRet = (DWORD)g_lpfnEApiLibInitialADV();
	if (!dwRet) return 2000;
	sub_100087A0();
	return 0;
}