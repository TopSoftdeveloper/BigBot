#include "StdAfx.h"
#include "EapiAPI.h"
#include "GlobalVar.h"
#include <malloc.h>

LPFnU_V EAPI_1 = (LPFnU_V)GetProcAddress(hEAPI, "EAPI_1");
LPEAPI_13 EAPI_13 = (LPEAPI_13)GetProcAddress(hEAPI, "EAPI_13");
LPEAPI_42 EAPI_42 = (LPEAPI_42)GetProcAddress(hEAPI, "EAPI_42");
LPEAPI_4 EAPI_4 = (LPEAPI_4)GetProcAddress(hEAPI, "EAPI_4");
LPEAPI_10 EAPI_10 = (LPEAPI_10)GetProcAddress(hEAPI, "EAPI_10");
LPFnU_V_2 EAPI_2 = (LPFnU_V_2)GetProcAddress(hEAPI, "EAPI_2");
LPEAPI_51 EAPI_51 = (LPEAPI_51)GetProcAddress(hEAPI, "EAPI_51");
LPEAPI_52 EAPI_52 = (LPEAPI_52)GetProcAddress(hEAPI, "EAPI_52");
LPEAPI_3 EAPI_3 = (LPEAPI_3)GetProcAddress(hEAPI, "EAPI_3");



CEapiAPI::CEapiAPI(void)
{
}

CEapiAPI::~CEapiAPI(void)
{
}

 HANDLE 	CEapiAPI::sub_10002660(bool fFlag)
 {
	 
	EAPI_2((HANDLE)this);
	if(fFlag) delete this;
	return this;
	

 }

void CEapiAPI::sub_10002690(void)
{
	m_dw0C = INVALID_HANDLE_VALUE;
}

int	CEapiAPI::sub_100026C0(void)
{
	int ret = 0;
	 
	//int eax = LPEAPI_4((0, &var_4);
	return ((EAPI_4(0, &ret) == 0)? ret:0);

}
// wchar_t a2_C4[32];
int	CEapiAPI::sub_100029F0(ArrayStr* pAarryStr)
{
	size_t nLen = 16;
	DWORD edx = 0;
	
	PBYTE pbStr = NULL;
	pbStr = (PBYTE)malloc(16);
	memset(pbStr, 0, nLen);
	
	int ret = EAPI_3(0, pbStr, &nLen);

	if(ret == 0)
	{
		
		for(int i = 0, j = 0; i < (int)nLen; i++,j++)
		{
			if(j >= 32) break;
				pAarryStr->wszStr_C4[i] = pbStr[j];
		}
	}
	else if(ret == 0xFFFFF9FF)
	{
		free(pbStr);
		pbStr = (PBYTE)malloc(nLen);
		if(!EAPI_3(1, pbStr, &nLen))
		{
			for(int i = 0, j = 0; i < (int)nLen; i++,j++)
			{
				if(j >= 32) break;
				
				pAarryStr->wszStr_C4[i] = pbStr[j];
			}
		}
	}
	else if(ret == 0xFFFFFCFF)
	{
		wcscpy_s((wchar_t *)(pAarryStr->wszStr_C4), 32, L"UNSUPPORTED");
	}
	else{
		FormatStrW_100052F0((wchar_t *)(pAarryStr->wszStr_C4), 32, L"EC %u", ret);
	}

	nLen = strlen((const char*)pbStr);
	memset(pbStr, 0, nLen);
	ret = EAPI_3(1, pbStr, &nLen);
	if(ret == 0)
	{
		for(int i = 0, j = 0; i < (int)nLen; i++,j++)
		{
			if(j >= 32) break;
		
			pAarryStr->wszStr_04[i] = pbStr[j];
		}
	}
	
	else if(ret == 0xFFFFF9FF)
	{
		free(pbStr);
		pbStr = (PBYTE)malloc(nLen);
		if(!EAPI_3(1, pbStr, &nLen))
		{
			for(int i = 0, j = 0; i < (int)nLen; i++,j++)
			{
				if(j >= 32) break;
				
				pAarryStr->wszStr_04[i] = pbStr[j];
			}
		}
	}
	else if(ret == 0xFFFFFCFF)
	{
		wcscpy_s((wchar_t *)(pAarryStr->wszStr_04), 32, L"UNSUPPORTED");
	}
	else{
		FormatStrW_100052F0((wchar_t *)(pAarryStr->wszStr_04), 32, L"EC %u", ret);
	}

	nLen = strlen((const char*)pbStr);
	memset(pbStr, 0, nLen);
	ret = EAPI_3(3, pbStr, &nLen);
	if(ret == 0)
	{
		for(int i =0, j= 0; i < (int)nLen; i++, j++)
		{
			if(j >= 32) break;
			pAarryStr->wszStr_110[i] = pbStr[j];
		}
	}
	
	else if(ret == 0xFFFFF9FF)
	{
		free(pbStr);
		pbStr = (PBYTE)malloc(nLen);
		if(!EAPI_3(3, pbStr, &nLen))
		{
			for(int i =0, j= 0; i < (int)nLen; i++, j++)
			{
				if(j >= 32) break;
				pAarryStr->wszStr_110[i] = pbStr[j];
			}
		}
	}
	else if(ret == 0xFFFFFCFF)
	{
		wcscpy_s((wchar_t *)(pAarryStr->wszStr_110), 32, L"UNSUPPORTED");
	}
	else{
		FormatStrW_100052F0((wchar_t *)(pAarryStr->wszStr_110), 32, L"EC %u", ret);
	}
//
	nLen = strlen((const char*)pbStr);
	memset(pbStr, 0, nLen);
	ret = EAPI_3(4, pbStr, &nLen);
	if(ret == 0)
	{
		for(int i =0, j= 0; i < (int)nLen; i++, j++)
		{
			if(j >= 32) break;
			pAarryStr->wszStr_84[i] = pbStr[j];
		}
	}
	
	else if(ret == 0xFFFFF9FF)
	{
		free(pbStr);
		pbStr = (PBYTE)malloc(nLen);
		if(!EAPI_3(4, pbStr, &nLen))
		{
			for(int i =0, j= 0; i < (int)nLen; i++, j++)
			{
				if(j >= 32) break;
				pAarryStr->wszStr_84[i] = pbStr[j];
			}
		}
	}
	else if(ret == 0xFFFFFCFF)
	{
		wcscpy_s((wchar_t *)(pAarryStr->wszStr_84), 32, L"UNSUPPORTED");
	}
	else{
		FormatStrW_100052F0((wchar_t *)(pAarryStr->wszStr_84), 32, L"EC %u", ret);
	}

	return 1;

}
int CEapiAPI::EapiInit_100026A0()//sub_100026A0
{
	
	m_dw0C = NULL;
	return (EAPI_1() != 0) + 2000;
}

int CEapiAPI::sub_10007EF0()
{
	return 1;
}
int  	CEapiAPI::sub_10002720(bool flag, int nVal)
{
	
	 return EAPI_52(0, flag|1, 0x40000000, nVal, 1, 1) == 0;
}
int  	CEapiAPI::sub_10002750(BYTE bCode, char bRet)
{
	int result; 
	
	if ( bCode == 54 )
		result = (EAPI_51(0, 54, 0x40000000, &bRet, 1) == 0);
	else
		result = 0;
	return result;
}
int  	CEapiAPI::sub_100027C0(BYTE bCode, int nLen, char bRet)
{
	int result; 
	
	if ( bCode == 54 )
		return  (EAPI_51(0, 54, 0x40000000, &bRet, nLen) == 0);
	else
		return 0;
	return result;
}
int  	CEapiAPI::sub_10002780(bool flag, int nCmd, int nCode)
{
	
	if(nCmd > 0x7E) return 0;
	
	return (EAPI_52(0, flag|1, 0x40000000, nCode, nCmd, nCmd) == 0);
}
int  	CEapiAPI::sub_100026E0(BYTE bCode, char bCmd)
{
	if(bCmd == 2) return 0;
	
	return (EAPI_51(0, bCode&0xFE, 0x40000000, &bCmd, 1) == 0);
}

int  	CEapiAPI::sub_100027F0(BYTE flag, StructSize13 stIn)
{
	
	return (EAPI_51(0, 32, 0x40000000, (char*)&(stIn.bCode), flag) == 0);
}

int  	CEapiAPI::sub_10002920(DWORD64* pdwRet)
{
	int nParam1 = 0, nParam2 = 0, nParam3 = 0;

	if(EAPI_10(&nParam1, &nParam2, &nParam3)) return 0;
	*(DWORD*)((PDWORD)pdwRet + 4) = nParam1;
	*(DWORD*)(pdwRet) = nParam2;
	return 1;
}

BOOL  	CEapiAPI::sub_10002970()
{
	return (EAPI_13() == 0);
}

BOOL	CEapiAPI::sub_100028D0(BYTE& bRet)
{
	int ret;
	if(EAPI_42(0, &ret)) return FALSE;
	bRet = (BYTE)ret;
	return TRUE;
}
BOOL	 CEapiAPI::sub_10002900(int ret)
{
	ret = (BYTE)ret;
	return (EAPI_42(0, &ret)==0);
}
BOOL	 CEapiAPI::sub_10002980(StructSize24 stVal)
{
	int temp = 0;
	int ret = EAPI_4(0x20000, &temp);
	stVal.dwValue_0 = ((ret == 0) ? temp:0);

	ret = EAPI_4(0x20001, &temp);
	stVal.dwValue_14 = ((ret == 0) ? temp:0);

	ret = EAPI_4(0x20002, &temp);
	stVal.dwValue_4 = ((ret == 0) ? temp:0);
	return TRUE;

}
