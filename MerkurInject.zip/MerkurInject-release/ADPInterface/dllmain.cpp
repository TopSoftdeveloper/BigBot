// dllmain.cpp : Defines the entry point for the DLL application.
#include "stdafx.h"
#include "InterfaceAPI.h"
#include "InterfaceAPIEX.h"
#include <tchar.h>
#include "GlobalVar.h"
#include "ADPInterface.h"
#include "detours.h"
#include "Hook.h"
#include "Utils.h"

#pragma comment(lib, "lib\\x86\\detours.lib")

HMODULE hCgos;
HMODULE hEAPI;
HMODULE hJida;
HINSTANCE g_hInst = nullptr;

BOOL LoadCgosImportFunctions()
{
#if 0

	CgosLibGetLastError = (LPFnU_V)GetProcAddress(hCgos, "CgosLibGetLastError");
	CgosI2CWrite = (LPFnU_DDDDD)GetProcAddress(hCgos, "CgosI2CWrite");
	CgosI2CRead = (LPFnU_DDDDD)GetProcAddress(hCgos, "CgosI2CRead");
	CgosWDogSetConfig = (LPFnU_DDDDD)GetProcAddress(hCgos, "CgosWDogSetConfig");
	CgosWDogDisable = (LPFnU_DD)GetProcAddress(hCgos, "CgosWDogDisable");
	CgosWDogTrigger = (LPFnU_DD)GetProcAddress(hCgos, "CgosWDogTrigger");
	CgosVgaCount = (LPFnU_D)GetProcAddress(hCgos, "CgosVgaCount");
	CgosVgaGetBacklight = (LPFnD_DDD)GetProcAddress(hCgos, "CgosVgaGetBacklight");
	CgosVgaSetBacklight = (LPFnD_DDD)GetProcAddress(hCgos, "CgosVgaSetBacklight");
	CgosVgaGetContrast = (LPFnD_DDD)GetProcAddress(hCgos, "CgosVgaGetContrast");
	CgosVgaSetContrast = (LPFnD_DDD)GetProcAddress(hCgos, "CgosVgaSetContrast");
	CgosTemperatureCount = (LPFnU_D)GetProcAddress(hCgos, "CgosTemperatureCount");
	CgosTemperatureGetCurrent = (LPFnU_DDDD)GetProcAddress(hCgos, "CgosTemperatureGetCurrent");
	CgosTemperatureGetInfo = (LPFnU_DDD)GetProcAddress(hCgos, "CgosTemperatureGetInfo");
	CgosLibInitialize = (LPFnU_V)GetProcAddress(hCgos, "CgosLibInitialize");
	CgosLibUninitialize = (LPFnV_V)GetProcAddress(hCgos, "CgosLibUninitialize");
	CgosLibInstall = (LPFnU_D)GetProcAddress(hCgos, "CgosLibInstall");
	CgosLibIsAvailable = (LPFnU_V)GetProcAddress(hCgos, "CgosLibIsAvailable");
	CgosBoardOpen = (LPFnU_DDDD)GetProcAddress(hCgos, "CgosBoardOpen");
	CgosBoardClose = (LPFnU_D)GetProcAddress(hCgos, "CgosBoardClose");
	CgosLibGetVersion = (LPFnU_V)GetProcAddress(hCgos, "CgosLibGetVersion");
	CgosBoardGetInfoW = (LPFnU_DD)GetProcAddress(hCgos, "CgosBoardGetInfoW");
	CgosI2CCount = (LPFnV_D)GetProcAddress(hCgos, "CgosI2CCount");
	CgosI2CIsAvailable = (LPFnU_DD)GetProcAddress(hCgos, "CgosI2CIsAvailable");
	CgosBoardGetBootCounter  = (LPFnU_DD)GetProcAddress(hCgos, "CgosBoardGetBootCounter");
	CgosBoardGetRunningTimeMeter = (LPFnU_DD)GetProcAddress(hCgos, "CgosBoardGetRunningTimeMeter");
	CgosFanCount = (LPFnU_D)GetProcAddress(hCgos, "CgosFanCount");
	CgosFanGetInfo = (LPFnD_DDD)GetProcAddress(hCgos, "CgosFanGetInfo");
	CgosFanGetCurrent = (LPFnU_DDDD)GetProcAddress(hCgos, "CgosFanGetCurrent");
	return (CgosFanGetCurrent!=0);

#endif
	return 0;
}

BOOL InstallHook(LPCSTR dll, LPCSTR function, LPVOID* originalFunction, LPVOID hookedFunction)
{
	HMODULE module = GetModuleHandleA(dll);
	*originalFunction = (LPVOID)GetProcAddress(module, function);

	if (*originalFunction)
	{
		DetourAttach(originalFunction, hookedFunction);
		return true;
	}

	return false;
}

void patchbytes()
{
	DWORD dwGameAddress = (DWORD)GetModuleHandleA("game.exe");

	//Disable checksum check at GraficEngineDx9::InitGameEngine
	Patch(dwGameAddress + 0xD469F, "\x90\x90\x90\x90\x90\x90", 6);
	
	//Disable checksum check at GrafengiDx9GamesAdpM::InitGameEngine
	Patch(dwGameAddress + 0x84325C, "\xEB\x0B", 2);

	//Disable comexpress check

	
	//Bypass ErrorDetection in GraficEngine
	//Patch(dwGameAddress + 0x3Cff17, "\x90\x90", 2);
	//Patch(dwGameAddress + 0x3D2FFC, "\xEB\x10", 2);

	//Disable to reopen com7
	Patch(dwGameAddress + 0x3D45D1, "\xE9\xF1\x00\x00\x00", 5);
	Patch(dwGameAddress + 0x3D45D6, "\x90", 1);

	Patch(dwGameAddress + 0x4EE08, "\x90\x90", 2);

	//Disable for D3D11 EndScene (error that happens after 30 mins)
	Patch(dwGameAddress + 0xE582E, "\xEB", 1);

	//Bypass machine key check
	Patch(dwGameAddress + 0x91BA53, "\xE9\x87\x00", 3);

}

void hook() {
	DetourTransactionBegin();
	DetourUpdateThread(GetCurrentThread());

	InstallHook("kernel32.dll", "CreateFileW", (LPVOID*)& originalCreateFileW, HookedCreateFileW);
	InstallHook("kernel32.dll", "GetDefaultCommConfigW", (LPVOID*)& originalGetDefaultCommConfigW, HookedGetDefaultCommConfigW);
	InstallHook("kernel32.dll", "GetCommProperties", (LPVOID*)& originalGetCommProperties, HookedGetCommProperties);
	InstallHook("kernel32.dll", "SetupComm", (LPVOID*)& originalSetupComm, HookedSetupComm);
	InstallHook("kernel32.dll", "WaitCommEvent", (LPVOID*)& originalWaitCommEvent, HookedWaitCommEvent);
	InstallHook("kernel32.dll", "GetOverlappedResult", (LPVOID*)& originalGetOverlappedResult, HookedGetOverlappedResult);
	InstallHook("kernel32.dll", "ClearCommError", (LPVOID*)& originalClearCommError, HookedClearCommError);
	InstallHook("kernel32.dll", "WaitForSingleObject", (LPVOID*)& originalWaitForSingleObject,HookedWaitForSingleObject);

	InstallHook("kernel32.dll", "GetCommState", (LPVOID*)& originalGetCommState, HookedGetCommState);
	InstallHook("kernel32.dll", "SetCommState", (LPVOID*)& originalSetCommState, HookedSetCommState);
	InstallHook("kernel32.dll", "SetCommTimeouts", (LPVOID*)& originalSetCommTimeouts, HookedSetCommTimeouts);
	InstallHook("kernel32.dll", "WriteFile", (LPVOID*)& originalWriteFile, HookedWriteFile);
	InstallHook("kernel32.dll", "ReadFile", (LPVOID*)& originalReadFile, HookedReadFile);

	InstallHook("user32.dll", "ShowCursor", (LPVOID*)& originalShowCursor, HookedShowCursor);
	InstallHook("user32.dll", "SetForegroundWindow", (LPVOID*)& originalSetForegroundWindow, HookedSetForegroundWindow);

	InstallHook("advapi32.dll", "RegQueryValueExW", (LPVOID*)& originalRegQueryValueExW, HookedRegQueryValueExW);
	InstallHook("kernel32.dll", "DeviceIoControl", (LPVOID*)& originalDeviceIoControl, HookedDeviceIoControl);
	//InstallHook("kernel32.dll", "EnterCriticalSection",	(LPVOID*)& originalEnterCriticalSection, HookedEnterCriticalSection);
	DetourTransactionCommit();

}

BOOL APIENTRY DllMain( HINSTANCE  hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
					 )
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		{
		g_hInst = hModule;
		hook();
		patchbytes();
		break;
		}
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
	case DLL_PROCESS_DETACH:
		break;
	}
	return TRUE;
}


ADPINTERFACE_API HANDLE GetADPInterface()
{	
	CInterfaceAPI cApi;
	HANDLE val = cApi.ApiInit_100096B0();//
	//CUniAPI pUniAPI;//???????
	return val;
}
ADPINTERFACE_API HANDLE GetADPInterfaceEX()
{	
	CInterfaceAPIEX cApi;
	HANDLE val = cApi.ApiEXInit_1000A7E0();//
	//CUniAPI pUniAPI;
	return val;
}