#pragma once
#include "GlobalVar.h"
class CEapiAPIEX_ADV
{
public:
	CEapiAPIEX_ADV(void);
	~CEapiAPIEX_ADV(void);
	

	DWORD m_dw04;
	DWORD m_dw08;
	infoStructure* m_pInfoStart;
	infoStructure* m_pInfoLast;
	HMODULE m_hMod14;
	DWORD m_dw18;

// 	sub_100048D0
	virtual void sub_100087A0();
// 	sub_10002F30
// 	sub_10003A40
// 	sub_10007EF0
// 	sub_10003060
// 	sub_100030C0
	virtual BOOL SusiI2CWrite_100031D0(BYTE byVal, DWORD arg_4, DWORD arg_8);
// 	sub_10003140
// 	sub_10002FB0
// 	sub_10003230
// 	sub_10003400
// 	sub_100034D0
// 	sub_10003550
// 	sub_10003510
// 	sub_10003550
// 	sub_10003330
// 	sub_100033B0
// 	sub_10006610
// 	sub_10006620
// 	sub_10003560
// 	sub_10003660
// 	sub_10004550
// 	sub_10004630
	virtual BOOL GetVCPFeatureAndVCPFeatureReply_10006970(DWORD* arg_0, DWORD arg_4);
	virtual BOOL SetVCPFeature_10006A80(DWORD* pdwNewVal, DWORD nNum);
	virtual BOOL GetVCPFeatureAndVCPFeatureReply_10006B70(DWORD* pdwCurVal, int nNum);
	virtual BOOL SetVCPFeature_10005070(DWORD* pdwNewVal, DWORD nNum);
	virtual BOOL sub_10003720(BYTE byVal, BYTE* bySrc, BYTE byLen);
// 	sub_100037C0
// 	sub_100051F0
// 	sub_100051F0
	virtual BOOL SetVCPFeature_10005200(int nNum, BYTE bVCPCode, DWORD* pdwNewVal);
	virtual	BOOL GetVCPFeatureAndVCPFeatureReply_10003850(int nArgNum, BYTE bVCPCode, DWORD* pdwCurrentVal, DWORD* dwMaxVal);
	virtual BOOL SaveCurrentSettings_10006D60(int nNum);
	virtual DWORD sub_10002EC0();
};
