#include "stdafx.h"
#include "SharedMutex.h"
#include "Utils.h"

HANDLE g_hMapFile;
HANDLE g_hsharedMapFile;
SharedMemoryData* g_sharedData = NULL;
SharedMemoryData* g_openedsharedData = NULL;

void initSharedMemory()
{
	g_hMapFile = CreateFileMappingA(INVALID_HANDLE_VALUE, NULL, PAGE_READWRITE, 0, sizeof(SharedMemoryData), "SharedDataMemory");
	if (g_hMapFile == NULL) {
		//WriteToFile(__FUNCTION__);
		//WriteToFile("SharedDataMemory error");
		// Handle shared memory creation error
		return ;
	}

	g_sharedData = (SharedMemoryData*)MapViewOfFile(g_hMapFile, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(SharedMemoryData));
	if (g_sharedData == NULL) {
		//WriteToFile(__FUNCTION__);
		//WriteToFile("MapViewOfFile error");
		// Handle shared memory mapping error
		CloseHandle(g_hMapFile);
		return ;
	}

	g_sharedData->addedCredit = 0;
	g_sharedData->mutex = CreateMutexA(NULL, FALSE, "SharedDataMutex");
}

void openSharedMemory()
{
	g_hsharedMapFile = OpenFileMappingA(
		FILE_MAP_ALL_ACCESS,
		FALSE,
		"SharedDataMemory");

	if (g_hsharedMapFile == NULL) {
		//WriteToFile(__FUNCTION__);
		//WriteToFile("OpenFileMapping error");
		return;
	}

	// Map a view of the file mapping into the address space of the current process
	g_openedsharedData = (SharedMemoryData*)MapViewOfFile(
		g_hsharedMapFile,
		FILE_MAP_ALL_ACCESS,
		0,
		0,
		sizeof(SharedMemoryData));
}

void writeCreditData(int credit)
{
	//WriteToFile(__FUNCTION__);
	//WaitForSingleObject(g_openedsharedData->mutex, INFINITE);
	if (g_openedsharedData != NULL)
	{
		g_openedsharedData->addedCredit = credit;
	}
	//ReleaseMutex(g_openedsharedData->mutex);
}

//void releaseSharedMemory()
//{
//	UnmapViewOfFile(g_openedsharedData);
//	CloseHandle(g_hMapFile);
//}


/* One Monitor Logic*/
HANDLE g_hMonitorMapFile = NULL;
MonitorSharedMemoryData* g_sharedMonitorData = NULL;
HANDLE g_hMutex = NULL;

BOOL MonitorInitSharedMemory()
{
    DebugPrintf(" Creating MonitorInitSharedMemory\n");
    // Create file mapping
    g_hMonitorMapFile = CreateFileMappingA(
        INVALID_HANDLE_VALUE,   // Use paging file
        NULL,                    // Default security
        PAGE_READWRITE,          // Read/write access
        0,                       // High-order DWORD of size
        sizeof(MonitorSharedMemoryData), // Low-order DWORD of size
        "OneMonitorMemory");     // Name of mapping object

    if (g_hMonitorMapFile == NULL) {
        DebugPrintf(" Creating MonitorInitSharedMemory failed\n");
        return FALSE;
    }

    // Check if the file mapping already existed
    BOOL bAlreadyExists = (GetLastError() == ERROR_ALREADY_EXISTS);

    // Map view of file into address space
    g_sharedMonitorData = (MonitorSharedMemoryData*)MapViewOfFile(
        g_hMonitorMapFile,              // Handle to map object
        FILE_MAP_ALL_ACCESS,     // Read/write permission
        0,
        0,
        sizeof(MonitorSharedMemoryData));

    if (g_sharedMonitorData == NULL) {
        DebugPrintf(" MapViewOfFile failed\n");
        CloseHandle(g_hMonitorMapFile);
        g_hMonitorMapFile = NULL;
        return FALSE;
    }

    // Initialize shared data if we created it (not if it already existed)
    if (!bAlreadyExists) {
        // Create mutex
        g_hMutex = CreateMutexA(
            NULL,                 // Default security attributes
            FALSE,                // Initially not owned
            "OneMonitorMutex");   // Named mutex

        if (g_hMutex == NULL) {
            UnmapViewOfFile(g_sharedMonitorData);
            CloseHandle(g_hMonitorMapFile);
            g_hMonitorMapFile = NULL;
            g_sharedMonitorData = NULL;
            return FALSE;
        }

        // Initialize shared data
        g_sharedMonitorData->message[0] = '\0';
    }
    else {
        // If already exists, just open the mutex
        g_hMutex = OpenMutexA(MUTEX_ALL_ACCESS, FALSE, "OneMonitorMutex");
        if (g_hMutex == NULL) {
            UnmapViewOfFile(g_sharedMonitorData);
            CloseHandle(g_hMonitorMapFile);
            g_hMonitorMapFile = NULL;
            g_sharedMonitorData = NULL;
            return FALSE;
        }
    }

    return TRUE;
}

void MonitorReleaseSharedMemory()
{
    if (g_sharedMonitorData != NULL) {
        UnmapViewOfFile(g_sharedMonitorData);
        g_sharedMonitorData = NULL;
    }

    if (g_hMonitorMapFile != NULL) {
        CloseHandle(g_hMonitorMapFile);
        g_hMonitorMapFile = NULL;
    }

    if (g_hMutex != NULL) {
        CloseHandle(g_hMutex);
        g_hMutex = NULL;
    }
}

// Send message to ScreenMirror application
BOOL SendMessageToMirror(const char* message)
{
    if (g_sharedMonitorData == NULL || g_hMutex == NULL) {
        return FALSE;
    }

    if (message == NULL || strlen(message) == 0) {
        return FALSE;
    }
    
    DebugPrintf(" Writing SendMessageToMirror\n");

    // Wait for mutex
    DWORD dwWaitResult = WaitForSingleObject(g_hMutex, INFINITE);
    if (dwWaitResult == WAIT_OBJECT_0) {
        // Copy message to shared memory
        strncpy_s(g_sharedMonitorData->message, MAX_MESSAGE_LENGTH, message, _TRUNCATE);

        // Release mutex
        ReleaseMutex(g_hMutex);
        return TRUE;
    }

    return FALSE;
}



