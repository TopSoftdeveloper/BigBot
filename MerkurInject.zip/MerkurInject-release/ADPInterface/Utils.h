#pragma once
#ifndef __UTIL_H__
#define __UTIL_H__

#include <windows.h>
#include <cstdio>
#include "Game.h"
#include <random>
#include <thread>

enum class LogTag : uint8_t {
	General = 0,
	Status,
	RTP,
	Risiko,
	CardGamble,
	DB,
	Hook,
	Fingerprint
};

const char* LogTagToString(LogTag tag);

void DebugPrintf(const char* fmt, ...);
void DebugPrintfW(const wchar_t* fmt, ...);
void DebugPrintfT(LogTag tag, const char* fmt, ...);
void DebugPrintfWT(LogTag tag, const wchar_t* fmt, ...);
void DebugHexDump(const void* data, size_t size);
uint16_t CalcChecksum(uint32_t version);
void Patch(DWORD dwBaseAddress, char* szData, int iSize);
BYTE  GetRandomByte(BYTE modules);
UINT64 current_time_ms();

void LoadGrafficObjList();
void RunStateMachine();
void LeftClickAt(int x, int y, int delayMs);

/** Ensure THREAD_PRIORITY_NORMAL for worker threads created by this DLL. */
void SetCurrentThreadPriorityNormal();
void SetCurrentThreadPriorityHigh();

/** Activate Power saver and set idle timeouts to never via powercfg.exe (no console window). */
void SetWindowsPowerSaveMode();

/** Keep captured game window (CryptoCard::gmainWindow) topmost. */
void KeepGameWindowTopmostTick();

#endif
