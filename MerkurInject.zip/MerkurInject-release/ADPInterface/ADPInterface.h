// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the ADPINTERFACE_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// ADPINTERFACE_API functions as being imported from a DLL, whereas this DLL sees symbols
// defined with this macro as being exported.
#ifdef ADPINTERFACE_EXPORTS
#define ADPINTERFACE_API __declspec(dllexport)
#else
#define ADPINTERFACE_API __declspec(dllimport)
#endif

ADPINTERFACE_API HANDLE GetADPInterface();
ADPINTERFACE_API HANDLE GetADPInterfaceEX();