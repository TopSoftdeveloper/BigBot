#include "StdAfx.h"
#include "CUniAPIEx.h"
#include "GlobalVar.h"
#include "PhysicalMonitorEnumerationAPI.h"
#include "LowLevelMonitorConfigurationAPI.h"
#include "Utils.h"
#include <cwchar> // for wcsncpy

#pragma comment (lib, "dxva2.lib")

DWORD g_dword_1001F460;
// LPFnU_V CgosLibInitialize = (LPFnU_V)GetProcAddress(hCgos, "CgosLibInitialize");
// LPFnV_V CgosLibUninitialize = (LPFnV_V)GetProcAddress(hCgos, "CgosLibUninitialize");
// LPFnU_D CgosLibInstall = (LPFnU_D)GetProcAddress(hCgos, "CgosLibInstall");
// LPFnU_V CgosLibGetLastError = (LPFnU_V)GetProcAddress(hCgos, "CgosLibGetLastError");
// LPFnU_DDDD CgosBoardOpen = (LPFnU_DDDD)GetProcAddress(hCgos, "CgosBoardOpen");
// LPFnU_V CgosLibIsAvailable = (LPFnU_V)GetProcAddress(hCgos, "CgosLibIsAvailable");
void addNewDisplayInfoToList(DWORD dwParam, myMonitorInfo* newMonInfo)///100020E0
{
	infoStructure* lastMoninfo = (infoStructure*)dwParam;
	infoStructure *infoNew; // ebx@3
	myMonitorInfo *newMoninfo; // eax@3

	//lastMoninfo = dwParam;
	while (lastMoninfo->next)
	{
		lastMoninfo = lastMoninfo->next;
	}
	infoNew = new infoStructure;
	newMoninfo = new myMonitorInfo;
	memset(newMoninfo, 0, sizeof(myMonitorInfo));
	infoNew->myMoninfo = newMonInfo;
	memcpy(infoNew->myMoninfo, newMonInfo, 0x220);

	infoNew->nMonIdx = lastMoninfo->nMonIdx + 1;
	infoNew->myMoninfo->nInfo = lastMoninfo->nMonIdx +1;
	infoNew->next = lastMoninfo->next;
	lastMoninfo->next = infoNew;
}


BOOL CALLBACK fn_EnumProc( HMONITOR hMonitor,  // handle to display monitor    fnEnumProc_10002490
					  HDC hDC,     // handle to monitor DC
					  LPRECT rect, // monitor intersection rectangle
					  LPARAM dwData )      // data????????
{	
	myMonitorInfo myMonInfo; 
	myMonInfo.hdc = hDC;
	myMonInfo.hMonitor = hMonitor;
	myMonInfo.rect.left = rect->left;
	myMonInfo.rect.top = rect->top;
	myMonInfo.rect.right = rect->right;
	myMonInfo.rect.bottom = rect->bottom;
	g_dword_1001F460 = dwData;
	myMonInfo.nInfo = 0;
	myMonInfo.nInfoFlag = 0;
	addNewDisplayInfoToList(dwData, &myMonInfo);
	return 1;
}

CUniAPIEx::CUniAPIEx(void) // sub_10002520
{	
	infoStructure* pInfoStr;
	pInfoStr = new infoStructure;
	pInfoStr->nMonIdx = -1;
	pInfoStr->next = NULL;
	myMonitorInfo* pMyMonInfo;
	pMyMonInfo = new myMonitorInfo;// malloc(544); 0x220
	pInfoStr->myMoninfo = pMyMonInfo;
	memset(pMyMonInfo, 0, sizeof(myMonitorInfo));
	this->m_pInfoStart = pInfoStr;
	this->m_pInfoLast = pInfoStr;
	int nNumMonitor = GetSystemMetrics(SM_CMONITORS);
	MONITORINFOEXW moninfo;
	moninfo.cbSize = 104;
	this->m_pInfoLast->nMonIdx = 0;	
	this->m_pInfoLast->myMoninfo->nInfo = 0;

	EnumDisplayMonitors(0,0,fn_EnumProc, (LPARAM)this->m_pInfoLast);
	
	m_pInfoLast = m_pInfoLast->next;
	if(m_pInfoLast->nMonIdx <= nNumMonitor)
	{
		HMONITOR hMonitor;
		while(1)
		{
			hMonitor = m_pInfoLast->myMoninfo->hMonitor;
			GetMonitorInfoW(hMonitor, &moninfo);
			wcscpy_s(m_pInfoLast->myMoninfo->wszDevice, 0xFF, moninfo.szDevice);
			m_pInfoLast->myMoninfo->nInfoFlag = moninfo.dwFlags;
			m_pInfoLast = m_pInfoLast->next;
			if (!m_pInfoLast) break;	
			if (m_pInfoLast->nMonIdx > nNumMonitor) break;
		}
	}
}

//LPFnU_D CgosBoardClose = (LPFnU_D)GetProcAddress(hCgos, "CgosBoardClose");
CUniAPIEx::~CUniAPIEx()
{
	DebugPrintf(__FUNCDNAME__);
}
void CUniAPIEx::Close()
{
	DebugPrintf(__FUNCDNAME__);
}
unsigned int CUniAPIEx::GetVersionNumber()
{
	DebugPrintf(__FUNCDNAME__);
	return 0x01020304; // Example version number;
}
unsigned int CUniAPIEx::GetBoardInfo(CUNIBOARDINFO* pInfo)
{
	DebugPrintf(__FUNCDNAME__);
	if (!pInfo) return 1; // Null check

	pInfo->dwSize = sizeof(CUNIBOARDINFO);

	// Fill fixed string values
	std::wcsncpy(pInfo->szHWPlatform, L"Merkur-Board-X1", 32);
	std::wcsncpy(pInfo->szHWRevision, L"Rev-1.2", 32);
	std::wcsncpy(pInfo->szBIOSVersion, L"BIOS-v2.7.8", 32);
	std::wcsncpy(pInfo->szManufacturer, L"Merkur GmbH", 32);
	std::wcsncpy(pInfo->szSerialNumber, L"SN-0626-2025-A1", 32);

	// Get current local time
	SYSTEMTIME sysTime;
	GetLocalTime(&sysTime);

	// Fill manufacture date
	pInfo->stManufacturDate.Day = static_cast<unsigned __int8>(sysTime.wDay);
	pInfo->stManufacturDate.Month = static_cast<unsigned __int8>(sysTime.wMonth);
	pInfo->stManufacturDate.Year = static_cast<unsigned __int16>(sysTime.wYear);
	pInfo->stManufacturDate.Hour = static_cast<unsigned __int8>(sysTime.wHour);
	pInfo->stManufacturDate.Minute = static_cast<unsigned __int8>(sysTime.wMinute);

	// Same for maintenance time (or use different logic if needed)
	pInfo->stMaintenanceTime = pInfo->stManufacturDate;
	return TRUE;
}
int CUniAPIEx::I2CConfig()
{
	DebugPrintf(__FUNCDNAME__);
	return TRUE;

}
int CUniAPIEx::I2CReadByte(unsigned __int8, unsigned __int8*)
{
	DebugPrintf(__FUNCDNAME__);
	return TRUE;
}
int CUniAPIEx::I2CWriteByte(unsigned __int8, unsigned __int8)
{
	DebugPrintf(__FUNCDNAME__);
	return TRUE;
}
int CUniAPIEx::I2CWriteStr(unsigned __int8, unsigned int, unsigned __int8*)
{
	DebugPrintf(__FUNCDNAME__);
	return TRUE;
}
int CUniAPIEx::I2CReadStr(unsigned __int8, unsigned int, unsigned __int8*)
{
	DebugPrintf(__FUNCDNAME__);
	return TRUE;
}
int CUniAPIEx::I2CWriteCommand(unsigned __int8, unsigned __int8)
{
	DebugPrintf(__FUNCDNAME__);
	return TRUE;
}
int CUniAPIEx::I2CWriteTime(unsigned int, _SYSTEMTIME*)
{
	DebugPrintf(__FUNCDNAME__);
	return TRUE;
}
int CUniAPIEx::WatchDogConfig(CUNIWDCONFIG*)
{
	DebugPrintf(__FUNCDNAME__);
	return TRUE;
}
int CUniAPIEx::WatchDogStop()
{
	DebugPrintf(__FUNCDNAME__);
	return TRUE;
}
int CUniAPIEx::WatchDogGetStatus()
{
	DebugPrintf(__FUNCDNAME__);
	return TRUE;
}
int CUniAPIEx::WatchDogTrigger()
{
	DebugPrintf(__FUNCDNAME__);
	return TRUE;
}
int CUniAPIEx::VgaConfig()
{
	DebugPrintf(__FUNCDNAME__);
	return TRUE;
}
int CUniAPIEx::VgaGetBacklight(unsigned __int8*)
{
	DebugPrintf(__FUNCDNAME__);
	return TRUE;
}
int CUniAPIEx::VgaSetBacklight(unsigned __int8)
{
	DebugPrintf(__FUNCDNAME__);
	return TRUE;
}
int CUniAPIEx::VgaGetContrast(unsigned __int8*)
{
	DebugPrintf(__FUNCDNAME__);
	return TRUE;
}
int CUniAPIEx::VgaSetContrast(unsigned __int8)
{
	DebugPrintf(__FUNCDNAME__);
	return TRUE;
}
int CUniAPIEx::GetTemperatur(unsigned int* pTemp)
{
	DebugPrintf(__FUNCDNAME__);
	if (!pTemp) return -1; // null check
	*pTemp = 42; // dummy safe temperature (in Celsius)
	return TRUE;
}
int CUniAPIEx::GetBatteryVol(long double* doBatSpg, unsigned int* dwBatteryBal )
{
	DebugPrintf(__FUNCDNAME__);
	*doBatSpg = 9999.0f;
	return TRUE;
}
int CUniAPIEx::GetBootCtrlVer(CBOOTCTRLINFO*)
{
	DebugPrintf(__FUNCDNAME__);
	return TRUE;
}
int CUniAPIEx::GetExtendBoardInfo(CUNIEXTENDBOARDINFO*)
{
	DebugPrintf(__FUNCDNAME__);
	return TRUE;
}
int CUniAPIEx::GetContrast(unsigned int* a, unsigned int b)
{
	*a = 27;
	DebugPrintf(__FUNCDNAME__);
	return TRUE;
}
int CUniAPIEx::SetContrast(unsigned int*, unsigned int)
{
	DebugPrintf(__FUNCDNAME__);
	return TRUE;
}
int CUniAPIEx::GetBrightness(unsigned int* a, unsigned int b)
{
	*a = 50;
	DebugPrintf(__FUNCDNAME__);
	return TRUE;
}
int CUniAPIEx::SetBrightness(unsigned int*, unsigned int)
{
	DebugPrintf(__FUNCDNAME__);
	return TRUE;
}
int CUniAPIEx::SendAudioCfgData(unsigned __int8, unsigned __int8*, unsigned __int8)
{
	DebugPrintf(__FUNCDNAME__);
	return TRUE;
}
int CUniAPIEx::GetFanInfo(CUNIEXTENDFANINFO*)
{
	DebugPrintf(__FUNCDNAME__);
	return TRUE;
}
int CUniAPIEx::WriteEEPROM(unsigned __int8*, unsigned int, unsigned int)
{
	DebugPrintf(__FUNCDNAME__);
	return TRUE;
}
int CUniAPIEx::ReadEEPROM(unsigned __int8*, unsigned int, unsigned int)
{
	DebugPrintf(__FUNCDNAME__);
	return TRUE;
}
int CUniAPIEx::SendVCPSets(unsigned int displayId, unsigned __int8 vcpCode, unsigned int* value)
{
	DebugPrintf(__FUNCDNAME__);
	if (!value) return -1;

	// Step 1: Get monitor handle
	HMONITOR hMonitor = MonitorFromWindow(nullptr, MONITOR_DEFAULTTOPRIMARY);
	if (!hMonitor) return -2;

	DWORD numMonitors = 0;
	if (!GetNumberOfPhysicalMonitorsFromHMONITOR(hMonitor, &numMonitors) || numMonitors == 0)
		return -3;

	// Step 2: Get physical monitor handles
	LPPHYSICAL_MONITOR physicalMonitors = new PHYSICAL_MONITOR[numMonitors];
	if (!GetPhysicalMonitorsFromHMONITOR(hMonitor, numMonitors, physicalMonitors)) {
		delete[] physicalMonitors;
		return -4;
	}

	// Step 3: Set the VCP value (e.g., brightness)
	BOOL success = SetVCPFeature(
		physicalMonitors[displayId].hPhysicalMonitor,
		vcpCode,
		*value
	);

	// Step 4: Cleanup
	DestroyPhysicalMonitors(numMonitors, physicalMonitors);
	delete[] physicalMonitors;

	return success ? 0 : -5;
}
int CUniAPIEx::GetVCPSets(unsigned int displayId, unsigned __int8 vcpCode, unsigned int* currentValue, unsigned int* maxValue)
{
	DebugPrintf(__FUNCDNAME__);
	if (!currentValue || !maxValue) return -1;

	// Step 1: Get monitor handle from displayId (simplified: use primary display)
	HMONITOR hMonitor = MonitorFromWindow(nullptr, MONITOR_DEFAULTTOPRIMARY);
	if (!hMonitor) return -2;

	DWORD numMonitors = 0;
	if (!GetNumberOfPhysicalMonitorsFromHMONITOR(hMonitor, &numMonitors) || numMonitors == 0)
		return -3;

	// Step 2: Allocate and retrieve monitor handles
	LPPHYSICAL_MONITOR physicalMonitors = new PHYSICAL_MONITOR[numMonitors];
	if (!GetPhysicalMonitorsFromHMONITOR(hMonitor, numMonitors, physicalMonitors)) {
		delete[] physicalMonitors;
		return -4;
	}

	// Step 3: Query the VCP code
	DWORD curr = 0, max = 0;
	BOOL success = GetVCPFeatureAndVCPFeatureReply(
		physicalMonitors[displayId].hPhysicalMonitor,
		vcpCode,
		nullptr,
		&curr,
		&max
	);

	if (success) {
		*currentValue = static_cast<unsigned int>(curr);
		*maxValue = static_cast<unsigned int>(max);
	}
	else {
		*currentValue = *maxValue = 0;
	}

	// Step 4: Cleanup
	DestroyPhysicalMonitors(numMonitors, physicalMonitors);
	delete[] physicalMonitors;

	return success ? 0 : -5;
}
int CUniAPIEx::SaveTFTSettings(unsigned int)
{
	DebugPrintf(__FUNCDNAME__);
	return TRUE;
}