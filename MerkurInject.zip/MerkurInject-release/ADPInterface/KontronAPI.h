#pragma once
#include "GlobalVar.h"
#include "..\\import_header\\Jida.h"
class CKontronAPI
{
public:
	CKontronAPI(void);
	~CKontronAPI(void);
	
	FUNCSTRUC14* m_dw04;
	DWORD m_dw08;
	DWORD m_dw0C;
	FUNCSTRUC14* m_dw10;
	void CKontronAPI::JidaClose_1000AAD0();
	virtual HANDLE 	sub_10009630(BOOL bFlag);	
	virtual void sub_1000AB00();
    virtual void j_Jida_2();
	virtual BOOL JidaBoardGetInfo_1000B270(ArrayStr* pArrStr);
	virtual BOOL sub_1000ABB0();
	virtual BOOL sub_1000AC40(BYTE bFlag, BYTE* pBuf);
	virtual BOOL sub_1000AC70(BYTE bFlag, DWORD dwArg);
	virtual BOOL sub_1000ACF0(BYTE bFlag, DWORD nMode, BYTE* pBuf);
	virtual BOOL sub_1000ACB0(BYTE bFlag, int nMode, BYTE* pBuf);
	virtual BOOL sub_1000AC00(BYTE bFlag, DWORD dwArg);
	virtual BOOL sub_1000AD30(int nMode, BYTE* pBuf);
	virtual BOOL sub_1000AEC0(DWORD* pData);
	virtual BOOL sub_1000AEF0();
	virtual BOOL sub_10009650();
	virtual BOOL sub_1000AF10();
	virtual BOOL sub_10007EF0();
	virtual BOOL sub_1000AE60(BYTE* pbyArg);
	virtual BOOL sub_1000AEA0(BYTE byArg);
	virtual BOOL sub_1000AE00(BYTE* pbyArg);
	virtual BOOL sub_1000AE40(BYTE byArg);
	virtual BOOL sub_1000AF30(DWORD* dwArg);
	virtual int JidaInit_1000AB30();
};
