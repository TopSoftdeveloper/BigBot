#pragma once
//#include "stdafx.h"
//#include <windows.h>
/*#include <windef.h>*/
/*#include <WTypes.h>*/
typedef struct tagmyMonitorInfo // 0x220
{
	int nInfo;
	int nInfoFlag;
	HMONITOR hMonitor;
	RECT rect;	
	HDC hdc;
	WCHAR wszDevice[256];
} myMonitorInfo, *LPmyMonitorInfo;

typedef struct taginfoStructure // 0xC
{
	int nMonIdx;
	taginfoStructure* next;
	myMonitorInfo* myMoninfo;
} infoStructure, *LPinfoStructure;
typedef struct tagTEMPINFO_28 // size 0x28;  sub_1000AF30 
{
	int n_0;
	DWORD n_4;
	int n_8;
	int n_c;
	int n_10;
	int n_14;
	int n_18;
	int n_1c;
	int n_20;
	int nCntTempeature_24;
} TEMPINFO_28, *LPTEMPINFO_28;

typedef struct tagKontronInfo // 0x1D0  464
{
	int nSize;
	int nStru_4;
	BYTE lpBy_8[0x20];	
	WCHAR wszStr28[32]; //0x28
	BYTE lpBy_68[0x20];//0x68
	BYTE byBuf88[32];//0x88
	WCHAR wszStr2[16];//0xA8
	BYTE byValC8;  //0xC8
	BYTE byValC9;  
	BYTE byValCA;
	BYTE byValCB;
	//0xCC
	BYTE byBuf_CC[0x104];
} KontronInfo, *LPKontronInfo;
typedef struct tagArrayStr // 1000B270 param
{
	int nSize;
	WCHAR wszStr_04[32];//04
	WCHAR wszStr_44[32];//0x44
	WCHAR wszStr_84[32];//0x84
	WCHAR wszStr_C4[32];//0xC4	
	BYTE byBuf[12];////0x104
	WCHAR wszStr_110[32];//0x110
} ArrayStr, *LPArrayStr;


typedef struct tagCGOSINFO130{
	int nLen_0;
	int n_4;
	BYTE lpBy_8[0x20];
	WCHAR wsz_28[0x20];
	WCHAR wsz_68[0x10];
	BYTE byBuf88[32];//0x88
	WCHAR lpW_A8[0x10];
	char ch_C8;
	char ch_C9;
	BYTE byValCA;
	BYTE byValCB;
	BYTE lpW_CC[0x64];	
}CGOSINFO130, *LPCGOSINFO130;

typedef struct tagStructSize13{
	WORD nVal_0;
	WORD nVal_2;
	WORD wVal_4;
	WORD wVal_6;
	WORD wVal_8;
	WORD wVal_A;
	BYTE bCode;

} StructSize13, *LPStructSize13;

typedef struct tagStructSize24{
	DWORD dwValue_0;
	DWORD dwValue_4;
	DWORD dwValue_8[12];
	DWORD dwValue_14;
} StructSize24, *LPStructSize24;

//extern BYTE g_psz_1001FBE8[32];
//extern WORD g_pwsz_1001FBA8[32];

//extern PVOID g_psz_1001F888;
extern DWORD g_dword_1001F460;
extern void addNewDisplayInfoToList(DWORD dwParam, myMonitorInfo* newMonInfo);
extern int FormatStrA_100086A0(BYTE* pBuf, int nsize, char* szFormat, ...);
extern bool FormatStrW_100052F0(WCHAR* wszBuf, int nsize, WCHAR* wszFormat, ...);
extern LPinfoStructure sub_10006E50(infoStructure* pInfo);

/*///////////////////////////////////////////////////////////////
Cgos.dll, EAPI.dll, Jida.dll 

#define DllImport   __declspec( dllimport )
DllImport UINT CgosLibInitialize();
DllImport void CgosLibUninitialize();
DllImport UINT CgosLibIsAvailable();
DllImport UINT CgosLibInstall(DWORD dwVal);
DllImport void CgosLibGetLastError();
DllImport UINT CgosBoardOpen(DWORD, DWORD,DWORD, DWORD);

DllImport UINT EAPI_1();
DllImport DWORD EAPI_3(DWORD, BYTE*, DWORD);
DllImport UINT Jida_3();
DllImport UINT Jida_40(DWORD);
DllImport UINT Jida_5();
DllImport UINT Jida_29(DWORD);
DllImport UINT Jida_56(WCHAR*, DWORD, DWORD, DWORD);
DllImport UINT Jida_30(DWORD, DWORD);

///////////////////////////////////////////////////////////////*/
extern HMODULE hCgos;
extern HMODULE hEAPI;
extern HMODULE hJida;

typedef UINT (__stdcall* LPFnU_V)(VOID);
typedef VOID (__stdcall* LPFnV_V)(VOID);
typedef UINT (__stdcall* LPFnU_D)(DWORD);
typedef VOID (__stdcall* LPFnV_D)(DWORD);
typedef UINT (__stdcall* LPFnU_DDDD)(DWORD, DWORD, DWORD, DWORD);
typedef UINT (__stdcall* LPFnU_DDD)(DWORD, DWORD, DWORD);

typedef UINT (__stdcall* LPFnU_DDDDD)(DWORD, DWORD, DWORD, DWORD, DWORD);
typedef UINT (__stdcall* LPFnU_DDDPD)(DWORD, DWORD, DWORD, LPVOID, DWORD);
typedef DWORD (__stdcall* LPFnD_DDD)(DWORD, DWORD, DWORD);
typedef UINT (__stdcall* LPFnU_DD)(DWORD, DWORD);
typedef UINT (__stdcall* LPFnU_DDPP)(DWORD, DWORD, LPVOID, LPVOID);
typedef UINT (__stdcall* LPFnU_DDP)(DWORD, DWORD, LPVOID);
typedef UINT (__stdcall* LPFnU_DP)(DWORD, LPVOID);
typedef UINT (__stdcall* LPFnU_PP)(LPVOID, LPVOID);
typedef DWORD (__stdcall* LPFnD_BDD)(BYTE, DWORD, DWORD);

typedef UINT (__stdcall* LPFnU_V_2) (HANDLE hParam);
typedef UINT (__stdcall* LPEAPI_3) (int flag, PBYTE pbStr, size_t* nLen);
typedef UINT (__stdcall* LPEAPI_51) (bool flag, BYTE bCode, DWORD arg_8, char* arg_C, int arg_10);
typedef UINT (__stdcall* LPEAPI_52) (int arg_0, bool flag, DWORD arg_8, int arg_C, int arg_10, int arg_14);
typedef UINT (__stdcall* LPEAPI_10) (LPVOID arg_0, LPVOID arg_4, LPVOID arg_8);
typedef UINT (__stdcall* LPEAPI_13) ();
typedef UINT (__stdcall* LPEAPI_42) (bool flag, int* arg_4);

typedef UINT (__stdcall* LPEAPI_4) (DWORD dwCode, int* ret);
// define functions is called in CEapiAPIEx class.

// typedef UINT (__thiscall* LPEApiLibInitialize)( VOID );
// typedef VOID (__thiscall* LPEApiLibUnInitialize)( VOID );
// extern LPEApiLibInitialize g_lpfnEApiLibInitialize = 0;
// extern LPEApiLibUnInitialize g_lpfnEApiLibUnInitialize = 0;
//typedef UINT (__thiscall* LPEApiLibInitial)( LPVOID );
//extern LPEApiLibInitial g_lpfnEApiLibInitialADV = 0;

typedef UINT (__stdcall* LPEApiLibInitialize)( VOID );
typedef VOID (__stdcall* LPEApiLibUnInitialize)( VOID );
typedef DWORD (__stdcall* LPEApiBoardGetStringA)( DWORD, LPVOID, LPDWORD );
typedef DWORD (__stdcall* LPEApiBoardGetValue)( DWORD, LPVOID );
typedef DWORD (__stdcall* LP_EApiBoardGetValue)( DWORD, LPVOID );
typedef DWORD (__stdcall* LPEApiI2CReadTransfer)( DWORD, int, int, int, DWORD, DWORD);
typedef DWORD (__stdcall* LPEApiI2CWriteTransfer)( DWORD, int, int, PCHAR, int);
typedef DWORD (__stdcall* LPEApiWDogGetCap)( DWORD*, DWORD*, DWORD*);
typedef DWORD (__stdcall* LPEApiWDogTrigger)( );
typedef DWORD (__stdcall* LPEApiVgaGetBacklightBrightness)(DWORD, BYTE* );
typedef DWORD (__stdcall* LPEApiVgaSetBacklightBrightness)(DWORD, BYTE );
typedef int (__stdcall* LPIsInpOutDriverOpen)();
typedef int (__stdcall* LPOut32)(int , int);
typedef int (__stdcall* LPInp32)(int);


#if 0
extern LPFnU_V CgosLibGetLastError;
extern LPFnU_DDDDD CgosI2CWrite;
extern LPFnU_DDDDD CgosI2CRead;
extern LPFnU_DDDDD CgosWDogSetConfig;
extern LPFnU_DD CgosWDogDisable;
extern LPFnU_DD CgosWDogTrigger;
extern LPFnU_D CgosVgaCount;
extern LPFnD_DDD CgosVgaGetBacklight;
extern LPFnD_DDD CgosVgaSetBacklight;
extern LPFnD_DDD CgosVgaGetContrast;
extern LPFnD_DDD CgosVgaSetContrast;
extern LPFnU_D CgosTemperatureCount;
extern LPFnU_DDDD CgosTemperatureGetCurrent;
extern LPFnU_DDD CgosTemperatureGetInfo ;
extern LPFnU_V CgosLibInitialize;
extern LPFnV_V CgosLibUninitialize;
extern LPFnU_D CgosLibInstall;
extern LPFnU_V CgosLibIsAvailable;
extern LPFnU_DDDD CgosBoardOpen;
extern LPFnU_D CgosBoardClose;
extern LPFnU_V CgosLibGetVersion;
extern LPFnU_DD CgosBoardGetInfoW;
extern LPFnV_D CgosI2CCount;
extern LPFnU_DD CgosI2CIsAvailable;
extern LPFnU_DD CgosBoardGetBootCounter;
extern LPFnU_DD CgosBoardGetRunningTimeMeter;
extern LPFnU_D CgosFanCount;
extern LPFnD_DDD CgosFanGetInfo;
extern LPFnU_DDDD CgosFanGetCurrent;

#endif