#pragma once

class OneMonitorManipulation
{
public:
	// Get the singleton instance
	static OneMonitorManipulation& GetInstance();

	// Initialize one monitor activation
	void InitOneMonitorActivation();

	// Prevent copying
	OneMonitorManipulation(const OneMonitorManipulation&) = delete;
	OneMonitorManipulation& operator=(const OneMonitorManipulation&) = delete;

    void ShowMirrorWindow();
    void HideMirrorWindow();
    void ToggleMirrorWindow();
    void AutoSwitchMirrorWindow(int coin, bool upgraded);

	bool IsMirrorWindowVisible() const { return m_bIsMirrorWindowVisible; }
private:
	// Private constructor for singleton pattern
	OneMonitorManipulation() : m_bHasVirtualMonitor(false), m_bIsMirrorWindowVisible(false) {}
	~OneMonitorManipulation() = default;

	// Check if virtual monitor exists by checking display adapter driver names
	void CheckForVirtualMonitor();

	// Private member to indicate if virtual monitor exists
	bool m_bHasVirtualMonitor;

    bool m_bIsMirrorWindowVisible;
};