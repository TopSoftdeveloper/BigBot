#include "StdAfx.h"
#include "CongaAPI.h"
#include "GlobalVar.h"
#include <stdlib.h>
#if 0
LPFnU_V CgosLibGetLastError ;
LPFnU_DDDDD CgosI2CWrite ;
LPFnU_DDDDD CgosI2CRead ;
LPFnU_DDDDD CgosWDogSetConfig;
LPFnU_DD CgosWDogDisable ;
LPFnU_DD CgosWDogTrigger ;
LPFnU_D CgosVgaCount;
LPFnD_DDD CgosVgaGetBacklight;
LPFnD_DDD CgosVgaSetBacklight;
LPFnD_DDD CgosVgaGetContrast;
LPFnD_DDD CgosVgaSetContrast;
LPFnU_D CgosTemperatureCount ;
LPFnU_DDDD CgosTemperatureGetCurrent;
LPFnU_DDD CgosTemperatureGetInfo;
LPFnU_V CgosLibInitialize ;
LPFnV_V CgosLibUninitialize;
LPFnU_D CgosLibInstall ;
LPFnU_V CgosLibIsAvailable;
LPFnU_DDDD CgosBoardOpen ;
LPFnU_D CgosBoardClose;
LPFnU_V CgosLibGetVersion;
LPFnU_DD CgosBoardGetInfoW;
LPFnV_D CgosI2CCount ;
LPFnU_DD CgosI2CIsAvailable;
LPFnU_DD CgosBoardGetBootCounter;
LPFnU_DD CgosBoardGetRunningTimeMeter;
LPFnU_D CgosFanCount;
LPFnD_DDD CgosFanGetInfo;
LPFnU_DDDD CgosFanGetCurrent;
#endif
CongaAPI::CongaAPI(void)
{
	
}

CongaAPI::~CongaAPI(void)
{
}

void CongaAPI::sub_10001090(BOOL bFlag)
{
	if (m_dw0C) {
		CgosBoardClose(m_dw0C);
	}
	if (bFlag) {
		delete this;
	}
}
void CongaAPI::BoardClose_100010D0() 
{
	if (m_dw0C)
	{

		CgosBoardClose(m_dw0C);
		m_dw0C = 0xFFFFFFFF;
		m_dw10 = 0xFFFFFFFF;
	}
}
DWORD CongaAPI::j_CgosLibGetVersion()
{
	
	return CgosLibGetVersion();
}
BOOL CongaAPI::BoardGetInfoW_100017B0(ArrayStr* pArrStr)
{
	CGOSINFO130 infoCgos;

	memset(&infoCgos, 0, sizeof(CGOSINFO130));

	m_dw0C = m_dw04;
	infoCgos.nLen_0 = 0x130;
	infoCgos.n_4 = 0;

	if (CgosBoardGetInfoW(m_dw04, &infoCgos)) 
	{
		wcscpy_s(pArrStr->wszStr_04, 0x20, infoCgos.wsz_28);
		FormatStrW_100052F0(pArrStr->wszStr_44, 0x20, L"%c.%c", infoCgos.ch_C8, infoCgos.ch_C9);
		wcscpy_s(pArrStr->wszStr_C4, 0x20, L"CONGATEC");

		pArrStr->byBuf[0] = infoCgos.byBuf88[6];
		pArrStr->byBuf[1] = infoCgos.byBuf88[2];
		pArrStr->byBuf[2] = infoCgos.byBuf88[0];
		pArrStr->byBuf[3] = infoCgos.byBuf88[1];
		pArrStr->byBuf[4] = infoCgos.byBuf88[8];
		pArrStr->byBuf[5] = infoCgos.byBuf88[10];
		pArrStr->byBuf[6] = infoCgos.byBuf88[22];
		pArrStr->byBuf[7] = infoCgos.byBuf88[18];
		pArrStr->byBuf[8] = infoCgos.byBuf88[16];
		pArrStr->byBuf[9] = infoCgos.byBuf88[17];
		pArrStr->byBuf[10] = infoCgos.byBuf88[24];
		pArrStr->byBuf[11] = infoCgos.byBuf88[26];

		FormatStrW_100052F0(pArrStr->wszStr_84, 0x20, (wchar_t *)L"%02X %02X", infoCgos.byValCA, infoCgos.byValCB);
		wcscpy_s(pArrStr->wszStr_110, 0x20, infoCgos.lpW_A8);
		return 1;
	} else 
	{
		
		return CgosLibGetLastError();
	}

}
BOOL CongaAPI::I2CCount_10001170()
{
	m_dw0C = m_dw04;
	m_dw10 = m_dw08;

	CgosI2CCount(m_dw04);

	if ( m_dw0C )
		return CgosI2CIsAvailable(m_dw0C, m_dw10) != 0;
	else
		return 0;
}
DWORD CongaAPI::I2CRead_10001210(DWORD arg_0, DWORD arg_4)
{
	
	if (CgosI2CRead(m_dw04, m_dw08, arg_0 | 1, (int*)arg_4, 1))
	{
		return 1;
	}
	else {
		
		return CgosLibGetLastError();
	}

}
DWORD CongaAPI::I2CWrite_10001250(BYTE arg_0, BYTE arg_4)
{
	if (arg_0 == 0x36) 
	{

		if (CgosI2CWrite(m_dw04, m_dw08, 0x36, (int*)&arg_4, 1))
		{
			return 1;
		}
		else
		{
			
			return CgosLibGetLastError();
		}
	}
	return 0;
}
DWORD CongaAPI::I2CWrite_100012E0(BYTE arg_0, DWORD arg_4, DWORD arg_8)
{
	if (arg_0 == 0x36) 
	{
		m_dw0C = m_dw04;
		m_dw10 = m_dw08;

		if (CgosI2CWrite(m_dw04, m_dw08, 0x36, (int*)arg_8, arg_4))
		{
			return 1;
		}
		else
		{

			return CgosLibGetLastError();
		}
	}
	return 0;
}
DWORD CongaAPI::I2CRead_10001290(BYTE arg_0, DWORD arg_4, DWORD arg_8)
{
	m_dw0C = m_dw04;
	m_dw10 = m_dw08;

	if (arg_4 == 0x7E) 
	{

		if (CgosI2CRead(m_dw04, m_dw08, arg_0 | 1, (int*)arg_8, arg_4))
		{
			return 1;
		}
		else
		{

			return CgosLibGetLastError();
		}
	}
	return 0;
}
DWORD CongaAPI::I2CWrite_100011C0(BYTE arg_0, BYTE arg_4)
{
	m_dw0C = m_dw04;
	m_dw10 = m_dw08;
	if (arg_4 == 2)
	{

		if (CgosI2CWrite(m_dw04, m_dw08, arg_0 & 0xFE, (int*)&arg_4, 1))
		{
			return 1;
		}
		else
		{

			return CgosLibGetLastError();
		}
	}
	return 0;
}
DWORD CongaAPI::I2CWrite_10001320(DWORD arg_0, BYTE* pBuf)
{
	m_dw10 = m_dw08;
	m_dw0C = m_dw04;

	WORD wTmp = *(WORD*)pBuf;
	wTmp = (wTmp % 1000) % 100;
	BYTE byBuf[8];
	byBuf[0] = pBuf[12];
	byBuf[1] = pBuf[10];
	byBuf[2] = pBuf[8];
	byBuf[3] = pBuf[4];
	byBuf[4] = pBuf[6];
	byBuf[5] = pBuf[2];
	byBuf[6] = (BYTE)wTmp;

	if (CgosI2CWrite(m_dw04, m_dw08, 0x20, (int*)byBuf, arg_0))
	{
		return 1;
	}
	else
	{
		return CgosLibGetLastError();
	}
}
BOOL CongaAPI::WDogSetConfig_100014F0(WORD* arg_0)
{
	m_dw10 = m_dw08;
	
	return CgosWDogSetConfig(m_dw0C, 0, *arg_0, arg_0[2], 0) != 0;
}
BOOL CongaAPI::WDogDisable_10001520()
{
	m_dw0C = m_dw04;
	
	return CgosWDogDisable(m_dw04, 0) != 0;
}
BOOL CongaAPI::sub_10009650()
{
	return 0;
}
BOOL CongaAPI::WDogTrigger_10001540()
{
	m_dw0C= m_dw04;
	
	return CgosWDogTrigger(m_dw04, 0) != 0;
}
DWORD CongaAPI::VgaCount_10001410()
{
	m_dw0C= m_dw04;
	
	CgosVgaCount(m_dw04);
	return 1;
}
BOOL CongaAPI::VgaGetBacklight_10001490(DWORD* arg_0)
{
	m_dw0C = m_dw04;
	DWORD v4 = 0;


	if ( CgosVgaGetBacklight(m_dw04, 0, &v4) )
	{
		*arg_0 = v4;
		return 1;
	}
	else
	{
		CgosLibGetLastError();
		return 0;
	}
}
BOOL CongaAPI::VgaSetBackLight_100014D0(DWORD arg_0)
{
	m_dw0C = m_dw04;
	
	return CgosVgaSetBacklight(m_dw04, 0, arg_0) != 0;
}
BOOL CongaAPI::VgaGetContrast_10001430(DWORD* arg_0)
{
	m_dw0C = m_dw04;
	DWORD v4 = 0;
	
	if ( CgosVgaGetContrast(m_dw04, 0, &v4) )
	{
		*arg_0 = v4;
		return 1;
	}
	else
	{
		CgosLibGetLastError();
		return 0;
	}
}
BOOL CongaAPI::VgaSetContrast_10001470(DWORD arg_0)
{
	m_dw0C = m_dw04;
	
	return CgosVgaSetContrast(m_dw0C, 0, arg_0) != 0;
}
BOOL CongaAPI::TemperatureGetInfo_10001560(DWORD* arg_0)
{
	BOOL bRet = FALSE;
	m_dw0C = m_dw04;
	
	DWORD var_38[14];
	memset(var_38 + 4, 0, 40);
	var_38[0] = 0;
	var_38[1] = 0;
	var_38[2] = CgosTemperatureCount(m_dw04);
	var_38[3] = 0x2C;
	

	if (var_38[2] > 0)
	{		

		for (DWORD i = 0; i < var_38[2]; i++)
		{
			if (CgosTemperatureGetInfo(m_dw0C, i, (int*)(var_38 + 3)))
			{
				switch (var_38[4])
				{
				case 0x50000:
					if (CgosTemperatureGetCurrent(m_dw0C, i, var_38, (var_38 + 1)))
					{
						arg_0[4] = var_38[0] / 1000;
						bRet = TRUE;
					} 
					else
						bRet = FALSE;
					break;
				case 0x10000:
					if (CgosTemperatureGetCurrent(m_dw0C, i, var_38, (var_38 + 1)))
					{
						arg_0[0] = var_38[0] / 1000;
						bRet = TRUE;
					} 
					else
						bRet = FALSE;
					break;
				case 0x30000:
					if (CgosTemperatureGetCurrent(m_dw0C, i,var_38, (var_38 + 1)))
					{
						arg_0[3] = var_38[0] / 1000;
						bRet = TRUE;
					} 
					else
						bRet = FALSE;
					break;
				case 0x40000:
					if (CgosTemperatureGetCurrent(m_dw0C, i, var_38, (var_38 + 1)))
					{
						arg_0[1] = var_38[0] / 1000;
						bRet = TRUE;
					} 
					else
						bRet = FALSE;
					break;
				case 0x60000:
					if (CgosTemperatureGetCurrent(m_dw0C, i, var_38, (var_38 + 1)))
					{
						arg_0[5] = var_38[0] / 1000;
						bRet = TRUE;
					} 
					else
						bRet = FALSE;
					break;
				case 0x70000:
					if (CgosTemperatureGetCurrent(m_dw0C, i, var_38, (var_38 + 1)))
					{
						arg_0[6] = var_38[0] / 1000;
						bRet = TRUE;
					} 
					else
						bRet = FALSE;
					break;
				default:
					if (CgosTemperatureGetCurrent(m_dw0C, i, var_38, (var_38 + 1)))
					{
						arg_0[9] = var_38[0] / 1000;
						bRet = TRUE;
					}
					break;

				}
			}
			else
				return FALSE;
		}
		

	}
	return bRet;
}
int CongaAPI::CgosInit_10001100()//sub_10001100
{
	m_dw0C = 0;
	m_dw10 = 0;


	if ( !CgosLibInitialize())
	{
		CgosLibUninitialize();
		m_dw0C = 0;
		if(!CgosLibInstall(1))
		{
			if(!CgosLibInstall(0)) return 0;
		}
		if(!CgosLibInitialize()) return 0;
	}
	if(!CgosLibIsAvailable())
	{
		CgosLibGetLastError();
		return 0;
	}
	return CgosBoardOpen(0, 0, 0, &m_dw0C) != 0;
}