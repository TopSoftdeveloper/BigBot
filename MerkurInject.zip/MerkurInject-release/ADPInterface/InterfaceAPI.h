#pragma once

class CInterfaceAPI
{
public:
	CInterfaceAPI(void);
	HANDLE ApiInit_100096B0();
	~CInterfaceAPI(void);
	DWORD m_dw0C;
	DWORD m_dw10;
	HANDLE m_hClassInst14;

    virtual HANDLE SameConstruct_10009680(BOOL bFlag);
	/*all return 0; 
// 	nullsub_2
// 	sub_10009650 return 0;
// 	sub_1000B450
// 	sub_10009650
// 	sub_1000B440
// 	sub_1000B440
// 	sub_100051F0
// 	sub_100051F0
// 	sub_1000B440
// 	sub_1000B440
// 	sub_1000B450
// 	sub_10009650
// 	sub_10009650
// 	sub_10009650
// 	sub_10009650
// 	sub_1000B450
// 	sub_1000B450
// 	sub_1000B450
// 	sub_1000B450
// 	sub_1000B450
*/
};
