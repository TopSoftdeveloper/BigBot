
// compile with: g++ -std=c++17 -O2 random_values.cpp -o random_values
#include "stdafx.h"
#include <iostream>
#include <vector>
#include <random>
#include <algorithm>
#include <cstdlib>
#include <chrono>
#include <string>
#include "mmcode.h"
#include "PlayDB.h"

#define MMCODE_LEN (15)
#define MMCODE_string "mmcode"
MMCodeStatus g_MMCodeStatus;

void mmcode_init() {
    time_t tick = PlayDB::GetInstance().GetMMcodeDate();
    std::tm savedTm = {};
    bool hasSavedDate = false;
    if (tick != 0) {
        std::tm* saved = std::localtime(&tick);
        if (saved != nullptr) {
            savedTm = *saved; // copy because localtime uses shared static storage
            hasSavedDate = true;
        }
    }

    std::time_t t = std::time(nullptr);
    std::tm nowTm = {};
    std::tm* now = std::localtime(&t);
    if (now != nullptr) {
        nowTm = *now;
    }

    if (hasSavedDate &&
        savedTm.tm_year == nowTm.tm_year &&
        savedTm.tm_mon == nowTm.tm_mon &&
        savedTm.tm_mday == nowTm.tm_mday) {
        g_MMCodeStatus.year = nowTm.tm_year + 1900;
        g_MMCodeStatus.month = nowTm.tm_mon + 1;
        g_MMCodeStatus.day = nowTm.tm_mday;
        g_MMCodeStatus.enable = true;
    }
    else {
        g_MMCodeStatus.year = 0;
        g_MMCodeStatus.month = 0;
        g_MMCodeStatus.day = 0;
        g_MMCodeStatus.enable = false;    
    }
    g_MMCodeStatus.matchStep = 0;

    g_MMCodeStatus.active = false;
    g_MMCodeStatus.activeString = "";
    g_MMCodeStatus.activeFromMouseHotspot = false;
}

bool mmcode_get_active_status() {
    if (mmcode_get_enable_status()) {
        return g_MMCodeStatus.active;
    }
    return false;
}

void mmcode_set_deactive() {
    if (g_MMCodeStatus.activeFromMouseHotspot) {
        g_MMCodeStatus.year = 0;
        g_MMCodeStatus.month = 0;
        g_MMCodeStatus.day = 0;
        g_MMCodeStatus.enable = false;
        g_MMCodeStatus.matchStep = 0;
        g_MMCodeStatus.activeFromMouseHotspot = false;
        PlayDB::GetInstance().ClearMMcodeDate();
    }
    g_MMCodeStatus.active = false;
    g_MMCodeStatus.activeString = "";
}

void mmcode_active_go(char c, bool fromMouseHotspot) {
    if (mmcode_get_enable_status() == false) {
        return;
    }
    // Exit early if already active
    if (g_MMCodeStatus.active) {
        return;
    }    
    const std::string base = MMCODE_string; // Expected target string
    // Append the new character to the in-progress match
    g_MMCodeStatus.activeString += c;
    // If current string is longer than expected, reset
    if (g_MMCodeStatus.activeString.length() > base.length()) {
        g_MMCodeStatus.activeString = "";
        return;
    }
    // Check if the current input matches the beginning of the target string
    if (g_MMCodeStatus.activeString != base.substr(0, g_MMCodeStatus.activeString.length())) {
        g_MMCodeStatus.activeString = "";
        return;
    }
    
    // If full match is achieved, mark as active and reset
    if (g_MMCodeStatus.activeString.length() == base.length()) {
        g_MMCodeStatus.active = true;
        g_MMCodeStatus.activeFromMouseHotspot = fromMouseHotspot;
        g_MMCodeStatus.activeString = "";
        PlayDB::GetInstance().AddMMCodeCount();
    }
}

bool mmcode_get_enable_status() {
#ifdef MMCODE_ACTIVE
    return true;
#endif
    if (g_MMCodeStatus.enable == false) {
        return false;
    }

    std::time_t t = std::time(nullptr);
    std::tm* now = std::localtime(&t);

    if (g_MMCodeStatus.year != (now->tm_year + 1900) ||
        g_MMCodeStatus.month != (now->tm_mon + 1) ||
        g_MMCodeStatus.day != now->tm_mday) {
        mmcode_init();
        return false;
    }
    return true;
}

void mmcode_enable_go(uint8_t betval) {
#ifdef MMCODE_ACTIVE
    return; // In forced mode, disable bet serial sequence input.
#endif
    if (g_MMCodeStatus.enable) {
        return;
    }
    myVector<uint8_t> v = mmcode_generate();
    if (g_MMCodeStatus.matchStep >= v.size()) {
        return;
    }
    if (AT(v, g_MMCodeStatus.matchStep) != betval) {
        g_MMCodeStatus.matchStep = 0;
        return;
    }
    g_MMCodeStatus.matchStep++;
    if (g_MMCodeStatus.matchStep >= MMCODE_LEN) {
        std::time_t t = std::time(nullptr);
        std::tm* now = std::localtime(&t);

        g_MMCodeStatus.year = now->tm_year + 1900;
        g_MMCodeStatus.month = now->tm_mon + 1;
        g_MMCodeStatus.day = now->tm_mday;
        g_MMCodeStatus.enable = true;
        g_MMCodeStatus.matchStep = 0;

        PlayDB::GetInstance().SetMMcodeDate();
    }
}

myVector<uint8_t> generate_fixed_values(std::mt19937& rng) {
    myVector<uint8_t> values;
    values.reserve(15);

    values.insert(values.end(), 5, 20);
    values.insert(values.end(), 5, 40);
    values.insert(values.end(), 5, 100);

    std::shuffle(values.begin(), values.end(), rng);
    return values;
}

myVector<uint8_t> mmcode_generate() {
    std::time_t t = std::time(nullptr);
    std::tm* now = std::localtime(&t);

    int year = now->tm_year + 1900;
    int month = now->tm_mon + 1;
    int day = now->tm_mday;

    // Simple seed based on input date
    unsigned int seed = static_cast<unsigned int>(year * 10000 + month * 100 + day);
    std::mt19937 rng(seed);
    myVector<uint8_t> result = generate_fixed_values(rng);
    return result;
}
