#include "stdafx.h"
#include "RgJokersCap.h"

#define RgJokersCap_cap "JCAPJC"
#define RgJokersCap_joker "JOKEJC"

RgJokersCap::RgJokersCap() {
    m_nReel = 5;
    m_nWinLine = 10;
    m_nMaxMatch = 5;
    m_nBetStep = 0;

    m_strGameName = "RgJokersCap";

    myVector<UINT16> m_vecBetSteps_tmp;
    m_vecBetSteps_tmp.push_back(5);
    m_vecBetSteps_tmp.push_back(10);
    m_vecBetSteps_tmp.push_back(20);
    m_vecBetSteps_tmp.push_back(30);
    m_vecBetSteps_tmp.push_back(40);
    m_vecBetSteps_tmp.push_back(50);
    m_vecBetSteps_tmp.push_back(60);
    m_vecBetSteps_tmp.push_back(80);
    m_vecBetSteps_tmp.push_back(100);
    m_vecBetSteps_tmp.push_back(150);
    m_vecBetSteps_tmp.push_back(200);
#ifdef BIGBET_ACTIVE
    m_vecBetSteps_tmp.push_back(500);
    m_vecBetSteps_tmp.push_back(1000);
#endif
    LoadBets();

    m_vecSymbols.push_back("KINGJC");
    m_vecSymbols.push_back("PRINJC");
    m_vecSymbols.push_back("HORSJC");
    m_vecSymbols.push_back("FALCJC");
    m_vecSymbols.push_back("RACEJC");
    m_vecSymbols.push_back("RKINJC");
    m_vecSymbols.push_back("RQUEJC");
    m_vecSymbols.push_back("RJACJC");
    m_vecSymbols.push_back("RTENJC");
    m_vecSymbols.push_back("JOKEJC");
    m_vecSymbols.push_back("JCAPJC");

    m_mapSymbolMinMatch["KINGJC"] = 3;
    m_mapSymbolMinMatch["PRINJC"] = 3;
    m_mapSymbolMinMatch["HORSJC"] = 3;
    m_mapSymbolMinMatch["FALCJC"] = 3;
    m_mapSymbolMinMatch["RACEJC"] = 3;
    m_mapSymbolMinMatch["RKINJC"] = 3;
    m_mapSymbolMinMatch["RQUEJC"] = 3;
    m_mapSymbolMinMatch["RJACJC"] = 3;
    m_mapSymbolMinMatch["RTENJC"] = 3;
    m_mapSymbolMinMatch["JOKEJC"] = 2;

    m_mapSymbolMeterGoc["JOKEJC"] = "JCJoker$x";
    m_mapSymbolMeterGoc["KINGJC"] = "JCKing$x";
    m_mapSymbolMeterGoc["PRINJC"] = "JCPrincess$x";
    m_mapSymbolMeterGoc["HORSJC"] = "JCHorse$x";
    m_mapSymbolMeterGoc["FALCJC"] = "JCFalcon$x";
    m_mapSymbolMeterGoc["RACEJC"] = "JC_AK_$x";
    m_mapSymbolMeterGoc["RKINJC"] = "JC_AK_$x";
    m_mapSymbolMeterGoc["RQUEJC"] = "JC_QJT_$x";
    m_mapSymbolMeterGoc["RJACJC"] = "JC_QJT_$x";
    m_mapSymbolMeterGoc["RTENJC"] = "JC_QJT_$x";

    m_vecWinLines.push_back("WinL1JC");
    m_vecWinLines.push_back("WinL2JC");
    m_vecWinLines.push_back("WinL3JC");
    m_vecWinLines.push_back("WinL4JC");
    m_vecWinLines.push_back("WinL5JC");
    m_vecWinLines.push_back("WinL6JC");
    m_vecWinLines.push_back("WinL7JC");
    m_vecWinLines.push_back("WinL8JC");
    m_vecWinLines.push_back("WinL9JC");
    m_vecWinLines.push_back("WinL10JC");
    m_vecWinLines.push_back("WinScatJC");

    m_vecLineSounds.push_back(SMP_JC_Win10Part_1);
    m_vecLineSounds.push_back(SMP_JC_Win10Part_2);
    m_vecLineSounds.push_back(SMP_JC_Win10Part_3);
    m_vecLineSounds.push_back(SMP_JC_Win10Part_4);
    m_vecLineSounds.push_back(SMP_JC_Win10Part_5);
    m_vecLineSounds.push_back(SMP_JC_Win10Part_6);
    m_vecLineSounds.push_back(SMP_JC_Win10Part_7);
    m_vecLineSounds.push_back(SMP_JC_Win10Part_8);
    m_vecLineSounds.push_back(SMP_JC_Win10Part_9);
    m_vecLineSounds.push_back(SMP_JC_Win10Part_10);

    m_vecWinSounds.push_back(SMP_JC_WinVeryTiny);
    m_vecWinSounds.push_back(SMP_JC_WinTiny);
    m_vecWinSounds.push_back(SMP_JC_WinVerySmall);
    m_vecWinSounds.push_back(SMP_JC_WinSmall);
    m_vecWinSounds.push_back(SMP_JC_WinMedium);
    m_vecWinSounds.push_back(SMP_JC_WinBig);
    m_vecWinSounds.push_back(SMP_JC_WinHuge);
    m_vecWinSounds.push_back(SMP_JC_WinTop);
        
    m_vecReelStripPlan.push_back("Walz1AJC");
    m_vecReelStripPlan.push_back("Walz1BJC");
    m_vecReelStripPlan.push_back("Walz1CJC");
    m_vecReelStripPlan.push_back("Walz1DJC");

    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));

    char* jcReelStrip[] = {
        "FALCJC,RTENJC,RJACJC,RQUEJC,RTENJC,KINGJC,RJACJC,RQUEJC,FALCJC,RTENJC,RJACJC,HORSJC,RKINJC,RQUEJC,KINGJC,RACEJC,RQUEJC,FALCJC,RTENJC,RJACJC,KINGJC,RKINJC,HORSJC,RQUEJC,RACEJC,FALCJC,RJACJC,RTENJC,RKINJC,RJACJC,FALCJC,RQUEJC,RJACJC,RKINJC,RTENJC,FALCJC,RJACJC,RQUEJC,FALCJC,RTENJC,RJACJC,HORSJC,RKINJC,RQUEJC,PRINJC,RACEJC,RQUEJC,FALCJC,RTENJC,RJACJC,KINGJC,RKINJC,HORSJC,RQUEJC,RACEJC,FALCJC,RJACJC,JOKEJC,RKINJC,RQUEJC",
        "RACEJC,RTENJC,HORSJC,RKINJC,RACEJC,RTENJC,RKINJC,PRINJC,RQUEJC,HORSJC,RJACJC,RTENJC,FALCJC,RKINJC,RTENJC,HORSJC,RKINJC,RACEJC,FALCJC,RJACJC,RKINJC,HORSJC,RACEJC,RTENJC,PRINJC,RQUEJC,RACEJC,RKINJC,RTENJC,PRINJC,RACEJC,RKINJC,KINGJC,RTENJC,RQUEJC,RKINJC,RTENJC,PRINJC,RKINJC,HORSJC,RACEJC,RQUEJC,FALCJC,RJACJC,RTENJC,HORSJC,RKINJC,RACEJC,FALCJC,RJACJC,RKINJC,HORSJC,RACEJC,RTENJC,PRINJC,RQUEJC,RACEJC,JOKEJC,RTENJC,PRINJC",
        "PRINJC,RQUEJC,HORSJC,RJACJC,RKINJC,KINGJC,RACEJC,RTENJC,RQUEJC,RACEJC,HORSJC,RKINJC,JCAPJC,PRINJC,RTENJC,FALCJC,RJACJC,RTENJC,RQUEJC,RACEJC,HORSJC,RTENJC,KINGJC,RJACJC,RQUEJC,FALCJC,RJACJC,RTENJC,RQUEJC,RACEJC,PRINJC,RQUEJC,HORSJC,RJACJC,RKINJC,KINGJC,RACEJC,RTENJC,RJACJC,RKINJC,PRINJC,RTENJC,JCAPJC,HORSJC,RKINJC,FALCJC,RJACJC,RTENJC,RQUEJC,RACEJC,HORSJC,RTENJC,KINGJC,RJACJC,RQUEJC,FALCJC,RJACJC,JOKEJC,RQUEJC,RACEJC",
        "RTENJC,RACEJC,HORSJC,RQUEJC,RACEJC,HORSJC,RJACJC,RQUEJC,KINGJC,RJACJC,RKINJC,FALCJC,RJACJC,RQUEJC,RACEJC,HORSJC,RKINJC,JOKEJC,RQUEJC,PRINJC,RTENJC,RACEJC,RQUEJC,PRINJC,RKINJC,HORSJC,RJACJC,RQUEJC,KINGJC,RJACJC,RKINJC,FALCJC,RJACJC,RQUEJC,RACEJC,HORSJC,RKINJC,JOKEJC,RQUEJC,PRINJC",
        "FALCJC,RJACJC,RTENJC,KINGJC,RQUEJC,FALCJC,PRINJC,RACEJC,RTENJC,HORSJC,RKINJC,RACEJC,KINGJC,RQUEJC,FALCJC,RJACJC,RQUEJC,RTENJC,RJACJC,RKINJC,FALCJC,RJACJC,RTENJC,KINGJC,RJACJC,RKINJC,PRINJC,RACEJC,RTENJC,HORSJC,RKINJC,RACEJC,KINGJC,RQUEJC,FALCJC,RJACJC,RQUEJC,JOKEJC,RJACJC,RKINJC",

        "FALCJC,RTENJC,RJACJC,RQUEJC,RTENJC,KINGJC,RJACJC,RQUEJC,FALCJC,RTENJC,RJACJC,HORSJC,RKINJC,RQUEJC,PRINJC,RACEJC,RQUEJC,FALCJC,RTENJC,RJACJC,PRINJC,RKINJC,HORSJC,RQUEJC,RKINJC,FALCJC,RJACJC,RTENJC,RKINJC,RJACJC,FALCJC,RQUEJC,RJACJC,RKINJC,RTENJC,FALCJC,RJACJC,RQUEJC,FALCJC,RTENJC,RJACJC,HORSJC,RKINJC,RQUEJC,PRINJC,RACEJC,RQUEJC,FALCJC,RTENJC,RJACJC,PRINJC,RKINJC,HORSJC,RQUEJC,RKINJC,FALCJC,RJACJC,JOKEJC,RKINJC,RQUEJC",
        "RACEJC,RTENJC,FALCJC,RKINJC,RACEJC,RTENJC,RKINJC,PRINJC,RQUEJC,HORSJC,RJACJC,RTENJC,FALCJC,RKINJC,RTENJC,HORSJC,RKINJC,RACEJC,FALCJC,RQUEJC,RKINJC,PRINJC,RACEJC,RTENJC,FALCJC,RQUEJC,RACEJC,RKINJC,RTENJC,PRINJC,RACEJC,RKINJC,KINGJC,RTENJC,RQUEJC,RKINJC,RTENJC,FALCJC,RKINJC,PRINJC,RACEJC,RQUEJC,FALCJC,RJACJC,RTENJC,HORSJC,RKINJC,RACEJC,FALCJC,RQUEJC,RKINJC,HORSJC,RACEJC,RTENJC,PRINJC,RQUEJC,RACEJC,JOKEJC,RTENJC,PRINJC",
        "KINGJC,RQUEJC,HORSJC,RACEJC,RJACJC,KINGJC,RACEJC,RTENJC,RJACJC,RACEJC,HORSJC,RKINJC,RACEJC,PRINJC,RTENJC,FALCJC,RJACJC,JOKEJC,RQUEJC,RACEJC,HORSJC,RTENJC,KINGJC,RJACJC,RQUEJC,FALCJC,RJACJC,JOKEJC,RQUEJC,RACEJC,KINGJC,RJACJC,HORSJC,RACEJC,RJACJC,KINGJC,RACEJC,RTENJC,RJACJC,RACEJC,PRINJC,RTENJC,RACEJC,HORSJC,RKINJC,FALCJC,RJACJC,JOKEJC,RQUEJC,RACEJC,HORSJC,RTENJC,KINGJC,RJACJC,RQUEJC,FALCJC,RJACJC,JOKEJC,RQUEJC,RACEJC",
        "RTENJC,RACEJC,HORSJC,RQUEJC,RACEJC,HORSJC,RJACJC,RQUEJC,KINGJC,RJACJC,RKINJC,FALCJC,RJACJC,RQUEJC,RACEJC,HORSJC,RKINJC,JOKEJC,RQUEJC,PRINJC,RTENJC,RACEJC,RQUEJC,PRINJC,RKINJC,HORSJC,RJACJC,RQUEJC,KINGJC,RJACJC,RKINJC,FALCJC,RJACJC,RQUEJC,RACEJC,HORSJC,RKINJC,JOKEJC,RQUEJC,PRINJC",
        "FALCJC,RJACJC,RTENJC,KINGJC,RQUEJC,FALCJC,PRINJC,RACEJC,RTENJC,HORSJC,RKINJC,RACEJC,KINGJC,RQUEJC,FALCJC,RJACJC,RQUEJC,RTENJC,RJACJC,RKINJC,FALCJC,RJACJC,RTENJC,KINGJC,RJACJC,RKINJC,PRINJC,RACEJC,RTENJC,HORSJC,RKINJC,RACEJC,KINGJC,RQUEJC,FALCJC,RJACJC,RQUEJC,JOKEJC,RJACJC,RKINJC",

        "FALCJC,RTENJC,RJACJC,RQUEJC,RTENJC,KINGJC,RJACJC,RQUEJC,FALCJC,RTENJC,RJACJC,HORSJC,RKINJC,RQUEJC,KINGJC,RACEJC,RQUEJC,HORSJC,RTENJC,RJACJC,KINGJC,RKINJC,HORSJC,RQUEJC,RACEJC,HORSJC,RJACJC,RTENJC,RKINJC,RJACJC,HORSJC,RQUEJC,RJACJC,RACEJC,RTENJC,HORSJC,RJACJC,RQUEJC,FALCJC,RTENJC,RJACJC,HORSJC,RACEJC,RQUEJC,PRINJC,RACEJC,RQUEJC,HORSJC,RTENJC,RJACJC,KINGJC,RACEJC,HORSJC,RQUEJC,RACEJC,FALCJC,RJACJC,JOKEJC,RKINJC,RQUEJC",
        "RACEJC,RTENJC,HORSJC,RKINJC,RACEJC,RTENJC,RKINJC,KINGJC,RJACJC,HORSJC,RJACJC,RTENJC,FALCJC,RKINJC,RTENJC,HORSJC,RKINJC,RACEJC,FALCJC,RJACJC,RKINJC,HORSJC,RACEJC,RTENJC,PRINJC,RQUEJC,RACEJC,RKINJC,RTENJC,PRINJC,RACEJC,RKINJC,KINGJC,RTENJC,RJACJC,RKINJC,RTENJC,KINGJC,RKINJC,HORSJC,RACEJC,RQUEJC,FALCJC,RJACJC,RTENJC,HORSJC,RKINJC,RACEJC,FALCJC,RJACJC,RKINJC,HORSJC,RACEJC,RTENJC,KINGJC,RQUEJC,RACEJC,JOKEJC,RTENJC,PRINJC",
        "PRINJC,RQUEJC,FALCJC,RJACJC,RKINJC,KINGJC,RACEJC,RTENJC,RKINJC,RQUEJC,HORSJC,RKINJC,RACEJC,PRINJC,RTENJC,FALCJC,RJACJC,RTENJC,RQUEJC,RKINJC,FALCJC,RTENJC,KINGJC,RJACJC,RQUEJC,FALCJC,RJACJC,RTENJC,RQUEJC,RACEJC,PRINJC,RQUEJC,FALCJC,RJACJC,RKINJC,PRINJC,RKINJC,RTENJC,RJACJC,RKINJC,PRINJC,RTENJC,RACEJC,HORSJC,RKINJC,FALCJC,RJACJC,RTENJC,RQUEJC,RACEJC,FALCJC,RTENJC,PRINJC,RJACJC,RQUEJC,FALCJC,RJACJC,JOKEJC,RQUEJC,RACEJC",
        "RTENJC,RACEJC,HORSJC,RQUEJC,RACEJC,HORSJC,RJACJC,RQUEJC,KINGJC,RJACJC,RKINJC,FALCJC,RJACJC,RQUEJC,RACEJC,HORSJC,RKINJC,RJACJC,RQUEJC,PRINJC,RTENJC,RACEJC,RQUEJC,PRINJC,RKINJC,HORSJC,RJACJC,RQUEJC,KINGJC,RJACJC,RKINJC,FALCJC,RJACJC,RQUEJC,RACEJC,HORSJC,RKINJC,JOKEJC,RQUEJC,PRINJC",
        "FALCJC,RJACJC,RTENJC,KINGJC,RQUEJC,FALCJC,PRINJC,RACEJC,RTENJC,HORSJC,RKINJC,RACEJC,KINGJC,RQUEJC,FALCJC,RJACJC,RQUEJC,RTENJC,RJACJC,RKINJC,FALCJC,RJACJC,RTENJC,KINGJC,RJACJC,RKINJC,PRINJC,RACEJC,RTENJC,HORSJC,RKINJC,RACEJC,KINGJC,RQUEJC,FALCJC,RJACJC,RQUEJC,JOKEJC,RJACJC,RKINJC",

        "FALCJC,RTENJC,RJACJC,RQUEJC,RTENJC,KINGJC,RJACJC,RQUEJC,FALCJC,RTENJC,RJACJC,RQUEJC,RKINJC,RACEJC,HORSJC,RKINJC,RQUEJC,PRINJC,RACEJC,RQUEJC,FALCJC,RTENJC,RJACJC,PRINJC,RKINJC,HORSJC,RQUEJC,RKINJC,FALCJC,RJACJC,JOKEJC,RKINJC,RQUEJC",
        "RACEJC,FALCJC,RQUEJC,RKINJC,PRINJC,RACEJC,RTENJC,FALCJC,RQUEJC,RACEJC,RKINJC,RTENJC,PRINJC,RACEJC,RKINJC,KINGJC,RTENJC,RQUEJC,RKINJC,RTENJC,FALCJC,RKINJC,PRINJC,RACEJC,RQUEJC,FALCJC,RJACJC,RTENJC,HORSJC,RKINJC,RACEJC,FALCJC,RQUEJC,RKINJC,HORSJC,RACEJC,RTENJC,PRINJC,RQUEJC,RACEJC,JOKEJC,RTENJC,PRINJC",
        "KINGJC,RACEJC,RTENJC,RJACJC,RACEJC,HORSJC,RKINJC,JCAPJC,PRINJC,RTENJC,FALCJC,RJACJC,JOKEJC,RQUEJC,RACEJC,HORSJC,RTENJC,KINGJC,RJACJC,RQUEJC,FALCJC,RJACJC,JOKEJC,RQUEJC,RACEJC,KINGJC,RJACJC,HORSJC,RACEJC,RJACJC,KINGJC,RACEJC,RTENJC,RJACJC,RACEJC,PRINJC,RTENJC,JCAPJC,HORSJC,RKINJC,FALCJC,RJACJC,JOKEJC,RQUEJC,RACEJC,HORSJC,RTENJC,KINGJC,RJACJC,RQUEJC,FALCJC,RJACJC,JOKEJC,RQUEJC,RACEJC",
        "RTENJC,RACEJC,RQUEJC,PRINJC,RKINJC,HORSJC,RJACJC,RQUEJC,KINGJC,RJACJC,RKINJC,FALCJC,RJACJC,RQUEJC,RACEJC,HORSJC,RKINJC,JOKEJC,RQUEJC,PRINJC",
        "FALCJC,RJACJC,RTENJC,KINGJC,RQUEJC,FALCJC,RJACJC,RQUEJC,RTENJC,RJACJC,RKINJC,FALCJC,RJACJC,RTENJC,KINGJC,RJACJC,RKINJC,PRINJC,RACEJC,RTENJC,HORSJC,RKINJC,RACEJC,KINGJC,RQUEJC,FALCJC,RJACJC,RQUEJC,JOKEJC,RJACJC,RKINJC",
    };

    int idx = 0;
    for (int i = 0; i < m_vecReelStripPlan.size(); i++) {
        ReelSet set;
        for (int j = 0; j < m_nReel; j++) {
            ReelStrip strip;
            std::stringstream ss(jcReelStrip[idx]);
            std::string item;
            while (std::getline(ss, item, ',')) {
                strip.push_back(item);
            }
            set.push_back(strip);
            idx++;
        }
        m_vecReelStripSets.push_back(set);
    }

    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_tmp;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        int n = (i <= 1) ? 1 : (AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 1));
        std::map<std::string, std::map<UINT8, BONUS>> perSym;
        std::map<UINT8, BONUS> e;
        e[3].coin = n * 5; e[3].ag = 0;
        e[4].coin = n * 20; e[4].ag = 0;
        e[5].coin = n * 100; e[5].ag = 0;
        perSym["RTENJC"] = e;
        e.clear();

        e[3].coin = n * 5; e[3].ag = 0;
        e[4].coin = n * 20; e[4].ag = 0;
        e[5].coin = n * 100; e[5].ag = 0;
        perSym["RJACJC"] = e;
        e.clear();

        e[3].coin = n * 5; e[3].ag = 0;
        e[4].coin = n * 20; e[4].ag = 0;
        e[5].coin = n * 100; e[5].ag = 0;
        perSym["RQUEJC"] = e;
        e.clear();

        e[3].coin = n * 10; e[3].ag = 0;
        e[4].coin = n * 50; e[4].ag = 0;
        e[5].coin = n * 200; e[5].ag = 0;
        perSym["RKINJC"] = e;
        e.clear();

        e[3].coin = n * 10; e[3].ag = 0;
        e[4].coin = n * 50; e[4].ag = 0;
        e[5].coin = n * 200; e[5].ag = 0;
        perSym["RACEJC"] = e;
        e.clear();

        e[3].coin = n * 10; e[3].ag = 0;
        e[4].coin = n * 100; e[4].ag = 0;
        e[5].coin = n * 250; e[5].ag = 0;
        perSym["FALCJC"] = e;
        e.clear();

        e[3].coin = n * 10; e[3].ag = 0;
        e[4].coin = n * 100; e[4].ag = 0;
        e[5].coin = n * 250; e[5].ag = 0;
        perSym["HORSJC"] = e;
        e.clear();

        e[3].coin = n * 20; e[3].ag = 0;
        e[4].coin = n * 150; e[4].ag = 0;
        e[5].coin = n * 500; e[5].ag = 0;
        perSym["PRINJC"] = e;
        e.clear();

        e[3].coin = n * 50; e[3].ag = 0;
        e[4].coin = n * 250; e[4].ag = 0;
        e[5].coin = n * 1000; e[5].ag = 0;
        perSym["KINGJC"] = e;
        e.clear();

        e[2].coin = n * 10; e[2].ag = 0;
        e[3].coin = n * 100; e[3].ag = 0;
        e[4].coin = n * 500; e[4].ag = 0;
        e[5].coin = n * 2000; e[5].ag = 0;
        perSym["JOKEJC"] = e;
        e.clear();

        m_Bonus_tmp[i] = perSym;
    }

    int nSavedBetVal = 10;
    int _line = 0;
    string data;
    PlayDB::GetInstance().LoadCheckPoint(m_strGameName, nSavedBetVal, _line, m_strCheckPoint);
    if (nSavedBetVal == -1) {
        nSavedBetVal = 10;
    }

    BOOL start = FALSE;
    idx = 0;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_tmp, i) < AT(m_vecBetSteps, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps, idx) == nSavedBetVal) {
            m_nBetStep = idx;
        }

        m_Bonus[idx++] = m_Bonus_tmp[i];
        if (AT(m_vecBetSteps_tmp, i) == AT(m_vecBetSteps, m_vecBetSteps.size() - 1)) {
            break;
        }
    }

    m_vecBetSteps_05.clear();
    m_vecBetSteps_10.clear();
    PrintAllBonus();
}

UINT16 RgJokersCap::Run() {
    /*m_nCurrentReelPlan = myRandom() % m_vecReelStripPlan.size();*/
    if (myRandom() % 2 == 0) {
        m_nCurrentReelPlan = 0;
    }
    else {
        m_nCurrentReelPlan = 3;
    }
    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));
    return m_shCurrentReelStrip;
}

UINT8 RgJokersCap::CardCount(std::string card) {
    int n = 0;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int col = 0; col < m_nReel; col++) {
        int k = 0;
        for (; k < 3; k++) {
            std::string s = AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k);
            if (s == card) {
                n++;
            }
        }
    }
    return n;
}

myVector<UINT8> RgJokersCap::Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) {
    myVector<UINT8> result;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    
    BOOL mmcode = FALSE;
    if (bTest == FALSE) {
        mmcode = mmcode_get_active_status();
    }
    if (bTest == TRUE || mmcode == TRUE) {
        std::string matchSymbol = AT(m_vecSymbols, myRandom() % (m_vecSymbols.size() - 2));
        int line = (myRandom() % (BetBit() == 5 ? 5 : 10));
        int weight = 1 + (myRandom() % 5);

        if (mmcode) {
            mmcode_set_deactive();
            weight = m_nMaxMatch;
            matchSymbol = RgJokersCap_joker;
        }
        for (int i = 0; i < m_nReel; i++) {
            ReelStrip reelStrip = AT(reelSet, i);
            int len = reelStrip.size() - 3;

            int valid_i[0x100];
            int valid_count = 0;
            for (int j = 0; j <= len; j++) {
                if (weight > i) {
                    if (matchSymbol == AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                else {
                    if (matchSymbol != AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
            }
            if (valid_count > 0) {
                int rand_index = myRandom() % valid_count;
                int chosen_i = valid_i[rand_index];
                result.push_back(chosen_i + 1);
            }
            else {
                result.push_back((myRandom() % (len - 1)) + 1);
            }
        }
        // force cap wild
        if ((myRandom() % 100) < 30 && weight >= 3) {
            // force wild
            ReelStrip reelStrip = AT(reelSet, 2);
            for (int j = 0; j < reelStrip.size(); j++) {
                if (AT(reelStrip, j) == RgJokersCap_cap) {
                    AT(result, 2) = j - (myRandom() % 3) + 1;
                    break;
                }
            }
        }
        m_vWinResult.clear();
        m_vWinResult = result;
        Choose2SymbolsToConvert();
    }
    else {
        result = _result;
        //AT(result, 0) = 57;
        //AT(result, 1) = 58;
        //AT(result, 2) = 12;
        //AT(result, 3) = 18;
        //AT(result, 4) = 37;

        m_vWinResult.clear();
        m_vWinResult = result;

        m_strSymbol_0 = AT(m_vecSymbols, AT(m_vWinResult, 5));
        m_strSymbol_1 = AT(m_vecSymbols, AT(m_vWinResult, 6));

        //m_strSymbol_0 = "RKINJC";
        //m_strSymbol_1 = "PRINJC";
    }

    normalMeter = 0;
    maxMeter = 0;
    UINT32 totalBonus = 0;
    for (int i = 0; i < (BetBit() == 5 ? 5 : 10); i++) {
        int maxWinBonus = 0;
        UINT16 maxWinMeter = 0;
        int maxWinWeight = 0;
        std::string maxWinSymbol = "";

        int j = 1;
        UINT16 meter = ((UINT16)1 << (2 - g_match_lines_10_5[i][0]));
        std::string firstSymbol = AT(AT(reelSet, 0), AT(result, 0) - 1 + g_match_lines_10_5[i][0]);
        if (IsWild(firstSymbol)) {
            firstSymbol = RgJokersCap_joker;
        }        
        for (; j < m_nMaxMatch; j++) {
            std::string prev_symbol = AT(AT(reelSet, j - 1), AT(result, j - 1) - 1 + g_match_lines_10_5[i][j - 1]);
            if (IsWild(prev_symbol)) {
                prev_symbol = RgJokersCap_joker;
            }
            std::string cur_symbol = AT(AT(reelSet, j), AT(result, j) - 1 + g_match_lines_10_5[i][j]);
            if (IsWild(cur_symbol)) {
                cur_symbol = RgJokersCap_joker;
            }
            if (IsWild(firstSymbol)) { // wild
                firstSymbol = cur_symbol;
            }
            if (firstSymbol == cur_symbol || IsWild(cur_symbol)) {
                meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));

                UINT32 bo = m_Bonus[BetStep()][firstSymbol][j + 1].coin + m_Bonus[BetStep()][firstSymbol][j + 1].ag * 1000;
                if (maxWinBonus < bo) {
                    maxWinBonus = bo;
                    maxWinMeter = meter;
                    maxWinSymbol = firstSymbol;
                    maxWinWeight = j + 1;
                }
                continue;
            }
            break;
        }

        if (j < m_mapSymbolMinMatch[maxWinSymbol] || m_mapSymbolMinMatch[maxWinSymbol] == 0) {
            continue;
        }

        // monitor 2 meter
        std::string meterStr = m_mapSymbolMeterGoc[maxWinSymbol];
        size_t pos = meterStr.find('$');
        if (pos != std::string::npos) {
            meterStr = meterStr.replace(pos, 1, std::to_string(maxWinWeight));
        }

        WinMeter e;
        e.line = i;
        e.meter = maxWinMeter;
        e.meter2 = g_GrafficObjList.Str2GOCID(meterStr);
        e.symbol = maxWinSymbol;
        e.weight = maxWinWeight;
        e.start = 0;
        e.bonus = m_Bonus[BetStep()][maxWinSymbol][maxWinWeight];
        e.sound = MAX_SOUND_IDS;

        totalBonus += e.bonus.coin;

        if (e.meter2 != -1) {
            meters.push_back(e);
        }
        if (j == m_nMaxMatch) {
            maxMeter |= meter;
        }
        else {
            normalMeter |= meter;
        }
    }

    //int nJoker = CardCount(RgJokersCap_joker);
    //if (nJoker >= 3) {
    //    // not match Joker 5, and Joker match contains other match
    //    if (Joker5Matched == 0 && maxJokerMatchCount < nJoker) {
    //        UINT16 meter = 0;
    //        for (int i = 0; i < 3; i++) {
    //            for (int col = 0; col < m_nReel; col++) {
    //                std::string cur_symbol = AT(AT(reelSet, col), AT(result, col) - 1 + i);
    //                if (cur_symbol == RgJokersCap_joker) {
    //                    meter |= ((UINT16)1 << (3 * col + (2 - i)));
    //                }
    //            }
    //        }

    //        WinMeter e;
    //        e.line = 10;
    //        e.meter = meter;
    //        e.meter2 = g_GrafficObjList.Str2GOCID("JCJoker" + std::to_string(nJoker) + "x");
    //        e.symbol = RgJokersCap_joker;
    //        e.weight = nJoker;
    //        e.start = 0;
    //        e.bonus = m_Bonus[BetStep()][RgJokersCap_joker][nJoker];
    //        e.sound = MAX_SOUND_IDS;

    //        normalMeter |= meter;
    //        totalBonus += e.bonus.coin;

    //        meters.push_back(e);
    //    }
    //}

    m_vWinMeters = meters;
    if (bTest == FALSE) {
        
        updateCheckPoint();
    }
    if (totalBonus > 0) {
        BonusSound = getSoundByID(WinSound(totalBonus));
    }
    return m_vWinResult;
}

std::pair<std::string, std::string> RgJokersCap::getTwoRandomSymbols(const myVector<std::string>& symbols) {
    size_t size = symbols.size();
    
    std::random_device rd;
    std::mt19937 rng(rd());
    std::uniform_int_distribution<int> dist(0, size - 1);
    
    int idx1 = dist(rng);
    int idx2;

    do {
        idx2 = dist(rng);
    } while (idx2 == idx1);

    return { AT(symbols, idx1), AT(symbols, idx2) };
}

myVector<InterruptPacketData> RgJokersCap::InterruptAfterSpin() {
    myVector<InterruptPacketData> packets;

    if (CardCount(RgJokersCap_cap) == 0) {
        return packets;
    }
    UINT16 goc0 = g_GrafficObjList.Str2GOCID(m_strSymbol_0);
    UINT16 goc1 = g_GrafficObjList.Str2GOCID(m_strSymbol_1);

    packets.push_back({
        0,
        8300,
        {
            0x06, 0x9f, 0x29, 0x01, 0x02, 0x31, 0x00, 0x04, 0x00, 0x9f, 0x29, 0xce, 
            static_cast<BYTE>(goc0 & 0xFF), static_cast<BYTE>((goc0 >> 8) & 0xFF),
            static_cast<BYTE>(goc1 & 0xFF), static_cast<BYTE>((goc1 >> 8) & 0xFF), 0x04
        }
        });
    return packets;
}


BOOL RgJokersCap::IsWild(std::string card) {
    if (CardCount(RgJokersCap_cap) == 0) {
        if (card == RgJokersCap_cap || card == RgJokersCap_joker) {
            return TRUE;
        }
        return FALSE;
    }
    if (card == RgJokersCap_cap || card == RgJokersCap_joker || card == m_strSymbol_0 || card == m_strSymbol_1) {
        return TRUE;
    }
    return FALSE;
}

void RgJokersCap::Choose2SymbolsToConvert() {
    if (CardCount(RgJokersCap_cap) == 0) {
        m_vWinResult.push_back(0);
        m_vWinResult.push_back(0);
        return;
    }
    // select 2 exist symbols
    myVector<std::string> vecExistSymbols;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int col = 0; col < m_nReel; col++) {
        int k = 0;
        for (; k < 3; k++) {
            std::string s = AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k);
            if (s == RgJokersCap_cap || s == RgJokersCap_joker) {
                continue;
            }
            if (std::find(vecExistSymbols.begin(), vecExistSymbols.end(), s) == vecExistSymbols.end()) {
                vecExistSymbols.push_back(s);
            }
        }
    }

    std::pair<std::string, std::string> result = getTwoRandomSymbols(vecExistSymbols);

    {
        auto it = std::find(m_vecSymbols.begin(), m_vecSymbols.end(), result.first);
        m_vWinResult.push_back(static_cast<BYTE>(std::distance(m_vecSymbols.begin(), it)));
    }
    {
        auto it = std::find(m_vecSymbols.begin(), m_vecSymbols.end(), result.second);
        m_vWinResult.push_back(static_cast<BYTE>(std::distance(m_vecSymbols.begin(), it)));
    }

    m_strSymbol_0 = result.first;
    m_strSymbol_1 = result.second;
}

bool RgJokersCap::RTP_force_bigWin() {
    return (myRandom() % 80 == 0); // 1.2%
}

int RgJokersCap::LineSwapDelay(int WinIdx) {
    return 700;
}
