#include "stdafx.h"
#include "RgGl.h"

#define RgGl_wild "glGladiator"
RgGl::RgGl() {
    m_nReel = 5;
    m_nWinLine = 5;
    m_nMaxMatch = 5;
    m_nBetStep = 0;

    m_strGameName = "RgGladiators";

    myVector<UINT16> m_vecBetSteps_tmp;
    m_vecBetSteps_tmp.push_back(5);
    m_vecBetSteps_tmp.push_back(10);
    m_vecBetSteps_tmp.push_back(20);
    m_vecBetSteps_tmp.push_back(30);
    m_vecBetSteps_tmp.push_back(40);
    m_vecBetSteps_tmp.push_back(50);
    m_vecBetSteps_tmp.push_back(60);
    m_vecBetSteps_tmp.push_back(80);
    m_vecBetSteps_tmp.push_back(100);
#ifdef BIGBET_ACTIVE
    m_vecBetSteps_tmp.push_back(200);
    m_vecBetSteps_tmp.push_back(500);
#endif
    LoadBets();

    m_vecSymbols.push_back("glBueste");
    m_vecSymbols.push_back("glLoewe");
    m_vecSymbols.push_back("glWagen");
    m_vecSymbols.push_back("glHelm");
    m_vecSymbols.push_back("glAxt");
    m_vecSymbols.push_back("glAs");
    m_vecSymbols.push_back("glKoenig");
    m_vecSymbols.push_back("glQueen");
    m_vecSymbols.push_back("glBube");
    m_vecSymbols.push_back("glZehn");
    m_vecSymbols.push_back("gl_Neun");
    m_vecSymbols.push_back("glGladiator");

    m_mapSymbolMinMatch["glBueste"] = 3;
    m_mapSymbolMinMatch["glLoewe"] = 3;
    m_mapSymbolMinMatch["glWagen"] = 3;
    m_mapSymbolMinMatch["glHelm"] = 3;
    m_mapSymbolMinMatch["glAxt"] = 3;
    m_mapSymbolMinMatch["glAs"] = 3;
    m_mapSymbolMinMatch["glKoenig"] = 3;
    m_mapSymbolMinMatch["glQueen"] = 3;
    m_mapSymbolMinMatch["glBube"] = 3;
    m_mapSymbolMinMatch["glZehn"] = 3;
    m_mapSymbolMinMatch["gl_Neun"] = 3;

    //m_mapSymbolMeterGoc["gocuFussbaler"] = "gocuFuss$x";

    m_vecWinLines.push_back("WinL1Gl");
    m_vecWinLines.push_back("WinL2Gl");
    m_vecWinLines.push_back("WinL3Gl");
    m_vecWinLines.push_back("WinL4Gl");
    m_vecWinLines.push_back("WinL5Gl");
    
    m_vecLineSounds.push_back(SMP_gl_alllines1);
    m_vecLineSounds.push_back(SMP_gl_alllines2);
    m_vecLineSounds.push_back(SMP_gl_alllines3);
    m_vecLineSounds.push_back(SMP_gl_alllines4);
    m_vecLineSounds.push_back(SMP_gl_alllines5);

    m_vecWinSounds.push_back(SMP_gl_wintiny);
    m_vecWinSounds.push_back(SMP_gl_winverysmall);
    m_vecWinSounds.push_back(SMP_gl_winsmall);
    m_vecWinSounds.push_back(SMP_gl_winsmedium);
    m_vecWinSounds.push_back(SMP_gl_winbig);
    m_vecWinSounds.push_back(SMP_gl_winhuge);
           
    m_vecReelStripPlan.push_back("Walze1GL");
    
    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));

    char* glReelStrip[] = {
        "glKoenig,glKoenig,glKoenig,glHelm,gl_Neun,gl_Neun,gl_Neun,glBueste,glQueen,glQueen,glQueen,glLoewe,glZehn,glZehn,glZehn,gl_Neun,gl_Neun,glZehn,glZehn,glAxt,glBube,glBube,glBube,glWagen,glAs,glAs,glAs",
        "glGladiator,glAs,glAs,glAs,glWagen,glBube,glBube,glBube,glAxt,glZehn,glZehn,glZehn,glLoewe,glQueen,glQueen,glQueen,glBueste,gl_Neun,gl_Neun,gl_Neun,glHelm,glKoenig,glKoenig,glKoenig",
        "glGladiator,glAs,glAs,glAs,glAs,glWagen,glWagen,glBube,glBube,glBube,glAxt,glAxt,glAxt,glZehn,glZehn,glZehn,gl_Neun,gl_Neun,gl_Neun,glZehn,glZehn,glZehn,glLoewe,glLoewe,glQueen,glQueen,glBube,glBube,glQueen,glQueen,glQueen,glBueste,gl_Neun,gl_Neun,gl_Neun,glHelm,glHelm,glHelm,glKoenig,glKoenig,glKoenig,glKoenig",
        "glGladiator,glAs,glAs,glAs,glAs,glWagen,glWagen,glBube,glBube,glBube,glAxt,glAxt,glAxt,glZehn,glZehn,glZehn,gl_Neun,gl_Neun,gl_Neun,glZehn,glZehn,glZehn,glLoewe,glLoewe,glQueen,glQueen,glBube,glBube,glQueen,glQueen,glQueen,glBueste,glBueste,gl_Neun,gl_Neun,gl_Neun,glHelm,glHelm,glHelm,glKoenig,glKoenig,glKoenig,glKoenig",
        "glAs,glAs,glAs,glAs,glAs,glWagen,glWagen,glWagen,glBube,glBube,glBube,glBube,glBube,glBube,glBube,glAxt,glAxt,glAxt,glAxt,glZehn,glZehn,glZehn,glZehn,glZehn,glZehn,glZehn,glZehn,glZehn,glLoewe,glLoewe,glLoewe,glQueen,glQueen,glQueen,glQueen,glQueen,glQueen,glQueen,glBueste,glBueste,gl_Neun,gl_Neun,gl_Neun,gl_Neun,gl_Neun,gl_Neun,gl_Neun,gl_Neun,gl_Neun,glHelm,glHelm,glHelm,glHelm,glKoenig,glKoenig,glKoenig,glKoenig,glKoenig",
    };

    int idx = 0;
    for (int i = 0; i < m_vecReelStripPlan.size(); i++) {
        ReelSet set;
        for (int j = 0; j < m_nReel; j++) {
            ReelStrip strip;
            std::stringstream ss(glReelStrip[idx]);
            std::string item;
            while (std::getline(ss, item, ',')) {
                strip.push_back(item);
            }
            set.push_back(strip);
            idx++;
        }
        m_vecReelStripSets.push_back(set);
    }

    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_tmp;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        std::map<std::string, std::map<UINT8, BONUS>> perSym;
        std::map<UINT8, BONUS> e;
        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 30; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[5].ag = 0;
        perSym["gl_Neun"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 30; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[5].ag = 0;
        perSym["glZehn"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 15; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 40; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 150; e[5].ag = 0;
        perSym["glBube"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 15; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 40; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 150; e[5].ag = 0;
        perSym["glQueen"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 60; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 200; e[5].ag = 0;
        perSym["glKoenig"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 60; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 200; e[5].ag = 0;
        perSym["glAs"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 25; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 500; e[5].ag = 0;
        perSym["glAxt"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 25; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 500; e[5].ag = 0;
        perSym["glHelm"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 30; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 200; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 1500; e[5].ag = 0;
        perSym["glWagen"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 30; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 200; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 1500; e[5].ag = 0;
        perSym["glLoewe"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 250; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 2500; e[5].ag = 0;
        perSym["glBueste"] = e;
        e.clear();

        m_Bonus_tmp[i] = perSym;
    }

    int nSavedBetVal = 10;
    int _line = 0;
    string data;
    PlayDB::GetInstance().LoadCheckPoint(m_strGameName, nSavedBetVal, _line, m_strCheckPoint);
    if (nSavedBetVal == -1) {
        nSavedBetVal = 10;
    }

    BOOL start = FALSE;
    idx = 0;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_tmp, i) < AT(m_vecBetSteps, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps, idx) == nSavedBetVal) {
            m_nBetStep = idx;
        }

        m_Bonus[idx++] = m_Bonus_tmp[i];
        if (AT(m_vecBetSteps_tmp, i) == AT(m_vecBetSteps, m_vecBetSteps.size() - 1)) {
            break;
        }
    }
    m_vecBetSteps_05.clear();
    m_vecBetSteps_10.clear();
    PrintAllBonus();
}

UINT16 RgGl::Run() {
    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));
    return m_shCurrentReelStrip;
}

myVector<UINT8> RgGl::Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) {
    myVector<UINT8> result;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);

    BOOL mmcode = FALSE;
    if (bTest == FALSE) {
        mmcode = mmcode_get_active_status();
    }
    if (bTest == TRUE || mmcode == TRUE) {
        // avoid wild card
        std::string matchSymbol = AT(m_vecSymbols, myRandom() % (m_vecSymbols.size() - 1));
        int line = (myRandom() % m_nWinLine);
        int weight = 1 + (myRandom() % 5);
        if (mmcode) {
            mmcode_set_deactive();
            weight = m_nMaxMatch;
            matchSymbol = "glWagen";
        }
        for (int i = 0; i < m_nReel; i++) {
            ReelStrip reelStrip = AT(reelSet, i);
            int len = reelStrip.size() - 3;

            int valid_i[0x100];
            int valid_count = 0;
            for (int j = 1; j < len - 1; j++) {
                if (weight > i) {
                    if (matchSymbol == AT(reelStrip, (j + g_match_lines_10_5[line][i]))) {
                        valid_i[valid_count++] = j;
                    }
                }
                else {
                    if (matchSymbol != AT(reelStrip, (j + g_match_lines_10_5[line][i]))) {
                        valid_i[valid_count++] = j;
                    }
                }
            }
            if (valid_count > 0) {
                int rand_index = myRandom() % valid_count;
                int chosen_i = valid_i[rand_index];
                result.push_back(chosen_i + 1);
            }
            else {
                result.push_back((myRandom() % (len - 1)) + 1);
            }
        }
        if ((myRandom() % 100) <= 70 && weight >= 3) {
            int reel = 1 + (myRandom() % 3);
            ReelStrip reelStrip = AT(reelSet, reel);
            int temp[] = { 1, 0 };
            AT(result, reel) = temp[myRandom() % 2];
        }
    }
    else {
        result = _result;
    }
    m_vWinResult = result;

    normalMeter = 0;
    maxMeter = 0;
    UINT32 totalBonus = 0;
    for (int i = 0; i < m_nWinLine; i++) {
        int j = 1;
        UINT16 meter = ((UINT16)1 << (2 - g_match_lines_10_5[i][0]));

        ReelStrip reelStrip0 = AT(reelSet, 0);
        std::string firstSymbol = AT(reelStrip0, ((AT(result, 0) + g_match_lines_10_5[i][0]) == 0 ? reelStrip0.size() : (AT(result, 0) + g_match_lines_10_5[i][0])) - 1);

        for (; j < m_nMaxMatch; j++) {
            ReelStrip reelStripj_1 = AT(reelSet, j - 1);
            ReelStrip reelStripj = AT(reelSet, j);
            std::string prev_symbol = AT(reelStripj_1, ((AT(result, j - 1) + g_match_lines_10_5[i][j - 1]) == 0 ? reelStripj_1.size() : (AT(result, j - 1) + g_match_lines_10_5[i][j - 1])) - 1);
            std::string cur_symbol = AT(reelStripj, ((AT(result, j) + g_match_lines_10_5[i][j]) == 0 ? reelStripj.size() : (AT(result, j) + g_match_lines_10_5[i][j])) - 1);

            if (WildcountInCol(j, result)) {
                meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
                continue;
            }

            if (firstSymbol == cur_symbol) {
                meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
                continue;
            }
            break;
        }

        if (j < m_mapSymbolMinMatch[firstSymbol] || m_mapSymbolMinMatch[firstSymbol] == 0) {
            continue;
        }
        std::map<std::string, UINT16> mapMeter2;
        mapMeter2["glBueste5"] = 0x01;
        mapMeter2["glBueste4"] = 0x02;
        mapMeter2["glBueste3"] = 0x03;
        mapMeter2["glLoewe5"] = 0x04;
        mapMeter2["glLoewe4"] = 0x05;
        mapMeter2["glLoewe3"] = 0x06;
        mapMeter2["glHelm5"] = 0x07;
        mapMeter2["glHelm4"] = 0x08;
        mapMeter2["glHelm3"] = 0x09;
        mapMeter2["glAxt5"] = 0x07;
        mapMeter2["glAxt4"] = 0x08;
        mapMeter2["glAxt3"] = 0x09;
        mapMeter2["glWagen5"] = 0x0a;
        mapMeter2["glWagen4"] = 0x0b;
        mapMeter2["glWagen3"] = 0x0c;
        mapMeter2["glAs5"] = 0x0d;
        mapMeter2["glAs4"] = 0x0e;
        mapMeter2["glAs3"] = 0x0f;
        mapMeter2["glKoenig5"] = 0x0d;
        mapMeter2["glKoenig4"] = 0x0e;
        mapMeter2["glKoenig3"] = 0x0f;
        mapMeter2["glQueen5"] = 0x10;
        mapMeter2["glQueen4"] = 0x11;
        mapMeter2["glQueen3"] = 0x12;
        mapMeter2["glBube5"] = 0x10;
        mapMeter2["glBube4"] = 0x11;
        mapMeter2["glBube3"] = 0x12;
        mapMeter2["glZehn5"] = 0x13;
        mapMeter2["glZehn4"] = 0x14;
        mapMeter2["glZehn3"] = 0x15;
        mapMeter2["gl_Neun5"] = 0x13;
        mapMeter2["gl_Neun4"] = 0x14;
        mapMeter2["gl_Neun3"] = 0x15;

        // monitor 2 meter
        WinMeter e;
        e.line = i;
        e.meter = meter;
        e.meter2 = mapMeter2[firstSymbol + std::to_string(j)];
        e.symbol = firstSymbol;
        e.weight = j;
        e.start = 0;
        e.bonus = m_Bonus[BetStep()][firstSymbol][j];
        e.sound = MAX_SOUND_IDS;

        totalBonus += e.bonus.coin;

        if (e.meter2 != -1) {
            meters.push_back(e);
        }
        if (j == m_nMaxMatch) {
            maxMeter |= meter;
        }
        else {
            normalMeter |= meter;
        }
    }
    if (bTest == FALSE) {
        updateCheckPoint();
    }
    m_vWinMeters = meters;
    if (totalBonus > 0) {
        BonusSound = getSoundByID(WinSound(totalBonus));
    }
    return result;
}

BOOL RgGl::WildcountInCol(UINT8 col, myVector<UINT8> result) {
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    // check wild symbol
    int k = 0;
    for (; k < 3; k++) {
        ReelStrip reelStrip = AT(reelSet, col);
        std::string s = AT(reelStrip, ((AT(result, col) + k) == 0 ? reelStrip.size() : (AT(result, col) + k)) - 1);
        if (s == RgGl_wild) {
            return TRUE;
        }
    }
    return FALSE;
}

UINT8 RgGl::Wildcount() {
    UINT8 n = 0;
    for (int i = 0; i < m_nReel; i++) {
        if (WildcountInCol(i, m_vWinResult)) {
            n++;
        }
    }
    return n;
}

int nnn = 0;
myVector<InterruptPacketData> RgGl::InterruptAfterSpin() {
    myVector<InterruptPacketData> packets;

    if (m_vWinMeters.size() > 0 && Wildcount() > 0) {

        ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);

        UINT8 reel_1 = 0;
        UINT8 reel_2 = 0;
        UINT8 reel_3 = 0;

        myVector<UINT16> maskMap;
        maskMap.push_back(0x0038);
        maskMap.push_back(0x01C0);
        maskMap.push_back(0x0E00);

        UINT16 mask = 0;

        for (int col = 1; col <= 3; col++) {
            ReelStrip reelStrip = AT(reelSet, col);
            for (int k = 0; k < 3; k++) {
                
                std::string symbol = AT(reelStrip, ((AT(m_vWinResult, col) + k) == 0 ? reelStrip.size() : (AT(m_vWinResult, col) + k)) - 1);
                if (symbol == RgGl_wild) {
                    if (col == 1) {
                        reel_1 = 2 - k;
                    }
                    if (col == 2) {
                        reel_2 = 2 - k;
                    }
                    if (col == 3) {
                        reel_3 = 2 - k;
                    }
                    mask |= AT(maskMap, col - 1);
                    break;
                }
            }
        }

        packets.push_back({
            0,
            2000,
            {0x01, 0x02, 0x31, 0x00, 0x08, 0x00, 0x37, 0x22, 0xb4, 0x01, static_cast<BYTE>(mask & 0xFF), static_cast<BYTE>((mask >> 8) & 0xFF),
            0x00, reel_1, reel_2, reel_3, 0x00, 0x04} });
    }

    return packets;
}

UINT16 RgGl::SpinTime_MS() {
    return 2200;
}

int RgGl::LineSwapDelay(int WinIdx) {
    return 900;
}

myVector<UINT8> RgGl::ShowTotalWinLines(myVector<WinMeter> SpinMeters) {
    myVector<uint8_t> packet = {
        0x06, 0x30, 0x59, 0x01, 0x02, 0x31, 0x00,
        0x0F, 0x00,  // Placeholder for length 
        0x0F, 0x11, // GameID
        0x9C, 0x19, 0x01
    };
    myVector<UINT8> TotalMatch;
    for (int i = 0; i < SpinMeters.size(); i++) {
        TotalMatch.push_back(AT(SpinMeters, i).line);
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter >> 8) & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter2 & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter2 >> 8) & 0xFF));
    }
    if (TotalMatch.size() < 10) {
        myVector<UINT8> _;
        return _;
    }
    UINT16 pktLen = 1 + (TotalMatch.size() / 5) * 7;
    AT(packet, 7) = static_cast<BYTE>(pktLen & 0xFF);
    AT(packet, 8) = static_cast<BYTE>((pktLen >> 8) & 0xFF);
    AT(packet, 9) = static_cast<BYTE>(m_nGameID & 0xFF);
    AT(packet, 10) = static_cast<BYTE>((m_nGameID >> 8) & 0xFF);
    int entryCount = static_cast<int>(TotalMatch.size() / 5);
    for (int i = 0; i < entryCount; ++i) {
        packet.push_back(AT(TotalMatch, i * 5 + 0)); // Line
        packet.push_back(AT(TotalMatch, i * 5 + 1)); // Meter low byte
        packet.push_back(AT(TotalMatch, i * 5 + 2)); // Meter high byte
        packet.push_back(AT(TotalMatch, i * 5 + 3)); // Meter2 low byte
        packet.push_back(AT(TotalMatch, i * 5 + 4)); // Meter2 high byte
        packet.push_back(0x01);      // Status or flag 1
        packet.push_back(0x01);      // Status or flag 2
    }
    // Mark the end of the packet
    packet.back() = 0x04;
    return packet;
}
