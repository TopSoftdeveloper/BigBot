#pragma once

#include "ReelGame.h"

class RgGoldCup : public ReelGame
{
public:
	myVector<WinMeter> m_vWinMeters;


	RgGoldCup::RgGoldCup();

	BOOL WildcountInCol(UINT8 col, myVector<UINT8> result);

	UINT8 Wildcount() override;
	myVector<UINT8> Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& WinSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) override;

	myVector<InterruptPacketData> InterruptAfterSpin() override;
	myVector<UINT8> ShowTotalWinLines(myVector<WinMeter> SpinMeters) override;
	bool RTP_force_bigWin() override;
};
