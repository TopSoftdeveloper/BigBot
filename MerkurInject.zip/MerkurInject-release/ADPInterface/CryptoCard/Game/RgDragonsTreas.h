#pragma once

#include "ReelGame.h"

class RgDragonsTreas : public ReelGame
{
public:
	UINT8 m_nFreeModeTotalSpin;
	UINT8 m_nFreeModeGoneSpin;
	BONUS m_nFreeModeTotalBonus;
	BOOL m_bFreeMode;
	std::string m_strSelectedcard;

	myVector<WinMeter> m_vWinMeters;

	std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_FreeModeBonus;
	std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_BonusCp;
public:
	RgDragonsTreas::RgDragonsTreas();
	UINT8 CardCount(std::string card);
	UINT8 CardNumInCol(int col, std::string card);
	BOOL DragonInCol(int col);

	myVector<InterruptPacketData> SelectSymbol(std::string symbol) override;

	UINT16 Run() override;
	myVector<UINT8> Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& WinSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) override;
	UINT16 LineSound(UINT Line, std::string symbol, UINT8 weight) override;
	UINT16 RgDragonsTreas::SpinTime_MS() override;
	int LineSwapDelay(int WinIdx) override;

	BOOL CanFreeMode() override;
	myVector<InterruptPacketData> EnterFreeGame(std::string) override;
	myVector<InterruptPacketData> InterruptBeforeSpin() override;
	myVector<InterruptPacketData> InterruptAfterMoveBonus(BOOL& EndFree) override;

	myVector<UINT8> ShowTotalWinLines(myVector<WinMeter> SpinMeters) override;

	bool RTP_force_bigWin() override;
	BOOL SelectedableReelsInFreeGame(myVector<UINT8> result) override;

	void updateCheckPoint() override;
};
