#pragma once

#include "ReelGame.h"

class RgConvertusAurum : public ReelGame
{
public:

	myVector<UINT8> m_vForceMatchInFree;

	UINT8 m_nFreeModeTotalSpin;
	UINT8 m_nFreeModeGoneSpin;
	BONUS m_nFreeModeTotalBonus;
	BOOL m_bFreeMode;

	myVector<WinMeter> m_vWinMeters;

	RgConvertusAurum::RgConvertusAurum();

	UINT8 CardCount(std::string card);
	BOOL CauldRonInCol(int col);
	UINT8 CardNumInCol(int col, std::string card);
	UINT8 NumberOfScatter();
	BOOL NumberInCol(int col);
	BOOL Convertable();
	std::string ConvertedSymbol(std::string card);

	UINT16 Run() override;
	myVector<UINT8> Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& WinSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) override;
	UINT16 SpinTime_MS() override;
	int LineSwapDelay(int WinIdx) override;

	BOOL CanFreeMode() override;
	myVector<InterruptPacketData> EnterFreeGame(std::string) override;
	myVector<InterruptPacketData> InterruptAfterSpin() override;
    myVector<InterruptPacketData> InterruptBeforeSpin() override;
    myVector<InterruptPacketData> InterruptAfterMoveBonus(BOOL& EndFree) override;

	myVector<InterruptPacketData> MousePressed(MousePosition p) override;
	myVector<UINT8> ShowTotalWinLines(myVector<WinMeter> SpinMeters) override;

	BOOL SelectedableReelsInFreeGame(myVector<UINT8> result) override;

	void ChangeReelStrip(UINT16 NewReelPlan) override;
	void updateCheckPoint() override;
};
