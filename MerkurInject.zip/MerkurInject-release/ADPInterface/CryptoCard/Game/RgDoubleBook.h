#pragma once

#include "ReelGame.h"

#define RgDoubleBook_MODE_single	(0)
#define RgDoubleBook_MODE_double	(1)

class RgDoubleBook : public ReelGame
{
public:
	UINT m_nMode;

	std::string m_strSelected_0;
	std::string m_strSelected_1;

	UINT8 m_nFreeModeTotalSpin;
	UINT8 m_nFreeModeGoneSpin;
	BONUS m_nFreeModeTotalBonus;
	BOOL m_bFreeMode;

	myVector<UINT16> m_vecBetSteps_s;
	myVector<UINT16> m_vecBetSteps_d;

	std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_s;
	std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_d;

	myVector<WinMeter> m_vWinMeters;
public:
	RgDoubleBook::RgDoubleBook();

	UINT8 CardCount(std::string card);
	BOOL BookInCol(int col);
	UINT8 CardNumInCol(int col, std::string card);

	void Convert1stSymbol(int weight, int symbolToconvert, BONUS& totalBonus, myVector<WinMeter>& meters);
	void Convert2ndSymbol(int weight, int symbolToconvert, BONUS& totalBonus, myVector<WinMeter>& meters, BOOL firstEnable);

	UINT16 Run() override;
	UINT16 MagicCount() override;
	UINT16 SpinTime_MS() override;
	myVector<UINT8> Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& WinSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) override;
	int LineSwapDelay(int WinIdx) override;
	BOOL CanFreeMode() override;
	myVector<InterruptPacketData> EnterFreeGame(std::string) override;
	myVector<InterruptPacketData> InterruptBeforeSpin() override;
	myVector<InterruptPacketData> InterruptAfterMoveBonus(BOOL& EndFree) override;

	myVector<InterruptPacketData> MousePressed(MousePosition p) override;
	myVector<UINT8> ShowTotalWinLines(myVector<WinMeter> SpinMeters) override;
	bool RTP_force_bigWin() override;

	BOOL SelectedableReelsInFreeGame(myVector<UINT8> result) override;
	void ChangeReelStrip(UINT16 NewReelPlan) override;

	UINT GameMode() override;
	void updateCheckPoint() override;
};
