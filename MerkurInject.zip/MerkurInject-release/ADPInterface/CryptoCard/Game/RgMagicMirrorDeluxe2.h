#pragma once

#include "ReelGame.h"

class RgMagicMirrorDeluxe2 : public ReelGame
{
public:
	UINT8 m_nFreeModeTotalSpin;
	UINT8 m_nFreeModeGoneSpin;
	BONUS m_nFreeModeTotalBonus;
	BOOL m_bFreeMode;
	std::string m_strSelectedcard;
	myVector<std::string> m_vSelectableSymbols;

	std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_BonusFree_05;
	std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_BonusFree_10;
	std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_BonusCp;

    myVector<WinMeter> m_vWinMeters;
	std::map<std::string, UINT16> m_vWinLineSounds;

	RgMagicMirrorDeluxe2::RgMagicMirrorDeluxe2();

    UINT8 CardCount(std::string card);
    BOOL DragonInCol(int col);
    UINT8 CardNumInCol(int col, std::string card);

	UINT8 CardNumInCol(int col, std::string card, myVector<UINT8> result);

	UINT16 Run() override;
    myVector<UINT8> Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& WinSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) override;
	UINT16 LineSound(UINT Line, std::string symbol, UINT8 weight) override;
	int LineSwapDelay(int WinIdx) override;
	UINT16 SpinTime_MS() override;
	UINT16 MagicCount() override;
	BOOL CanFreeMode() override;
	myVector<InterruptPacketData> EnterFreeGame(std::string) override;
	myVector<InterruptPacketData> InterruptBeforeSpin() override;
	myVector<InterruptPacketData> InterruptAfterMoveBonus(BOOL& EndFree) override;

	myVector<InterruptPacketData> MousePressed(MousePosition p) override;
	myVector<UINT8> ShowTotalWinLines(myVector<WinMeter> SpinMeters) override;

	BOOL SelectedableReelsInFreeGame(myVector<UINT8> result) override;

	void ChangeReelStrip(UINT16 NewReelPlan) override;
	bool RTP_force_bigWin() override;

	void updateCheckPoint() override;
};
