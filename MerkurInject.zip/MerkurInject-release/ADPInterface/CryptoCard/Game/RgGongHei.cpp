#include "stdafx.h"
#include "RgGongHei.h"

#define RgGongHei_MP_ChangeLine_LB_x_reel   0x03
#define RgGongHei_MP_ChangeLine_LB_x_pos    0x28
#define RgGongHei_MP_ChangeLine_LB_y_row    0x02
#define RgGongHei_MP_ChangeLine_LB_y_pos    0x17
#define RgGongHei_MP_ChangeLine_RT_x_reel   0x03
#define RgGongHei_MP_ChangeLine_RT_x_pos    0x61
#define RgGongHei_MP_ChangeLine_RT_y_row    0x02
#define RgGongHei_MP_ChangeLine_RT_y_pos    0x50

#define RgGongHei_scatter "gowTEMPLE__"
#define RgGongHei_wild "gowCAISHEN_"

myVector<std::string> GOW_convert_sorting = { "gowORANGES_", "gowCOINS___", "gowLANTERN_", "gowVASE____", "gowPENDANT_" };
RgGongHei::RgGongHei() {
    m_nReel = 5;
    m_nWinLine = 5;
    m_nMaxMatch = 5;
    m_nBetStep = 0;

    m_strGameName = "RgGongHei";

    m_bFreeMode = FALSE;

    myVector<UINT16> m_vecBetSteps_05_tmp;
    myVector<UINT16> m_vecBetSteps_10_tmp;
    m_vecBetSteps_05_tmp.push_back(5);
    m_vecBetSteps_05_tmp.push_back(10);
    m_vecBetSteps_05_tmp.push_back(15);
    m_vecBetSteps_05_tmp.push_back(20);
    m_vecBetSteps_05_tmp.push_back(25);
    m_vecBetSteps_05_tmp.push_back(30);
    m_vecBetSteps_05_tmp.push_back(40);
    m_vecBetSteps_05_tmp.push_back(50);
    m_vecBetSteps_05_tmp.push_back(60);
    m_vecBetSteps_05_tmp.push_back(80);
    m_vecBetSteps_05_tmp.push_back(100);

    m_vecBetSteps_10_tmp.push_back(10);
    m_vecBetSteps_10_tmp.push_back(20);
    m_vecBetSteps_10_tmp.push_back(30);
    m_vecBetSteps_10_tmp.push_back(40);
    m_vecBetSteps_10_tmp.push_back(50);
    m_vecBetSteps_10_tmp.push_back(60);
    m_vecBetSteps_10_tmp.push_back(80);
    m_vecBetSteps_10_tmp.push_back(100);
    m_vecBetSteps_10_tmp.push_back(120);
    m_vecBetSteps_10_tmp.push_back(160);
    m_vecBetSteps_10_tmp.push_back(200);

#ifdef BIGBET_ACTIVE
    m_vecBetSteps_05_tmp.push_back(200);
    m_vecBetSteps_05_tmp.push_back(500);
    m_vecBetSteps_10_tmp.push_back(400);
    m_vecBetSteps_10_tmp.push_back(1000);
#endif
    LoadBets();

    m_vecBetSteps = m_vecBetSteps_05;

    m_vecSymbols.push_back("gowTREASURE");
    m_vecSymbols.push_back("gowPENDANT_");
    m_vecSymbols.push_back("gowVASE____");
    m_vecSymbols.push_back("gowLANTERN_");
    m_vecSymbols.push_back("gowCOINS___");
    m_vecSymbols.push_back("gowORANGES_");
    m_vecSymbols.push_back("gowA_______");
    m_vecSymbols.push_back("gowK_______");
    m_vecSymbols.push_back("gowQ_______");
    m_vecSymbols.push_back("gowJ_______");
    m_vecSymbols.push_back("gowCAISHEN_");
    m_vecSymbols.push_back("gowTEMPLE__");

    m_mapSymbolMinMatch["gowJ_______"] = 3;
    m_mapSymbolMinMatch["gowQ_______"] = 3;
    m_mapSymbolMinMatch["gowK_______"] = 3;
    m_mapSymbolMinMatch["gowA_______"] = 3;
    m_mapSymbolMinMatch["gowORANGES_"] = 3;
    m_mapSymbolMinMatch["gowCOINS___"] = 3;
    m_mapSymbolMinMatch["gowLANTERN_"] = 3;
    m_mapSymbolMinMatch["gowVASE____"] = 3;
    m_mapSymbolMinMatch["gowPENDANT_"] = 3;
    m_mapSymbolMinMatch["gowTREASURE"] = 3;
    m_mapSymbolMinMatch["gowTEMPLE__"] = 3;

    m_mapSymbolMeterGoc["gowJ_______"] = "gowAKQJ$x";
    m_mapSymbolMeterGoc["gowQ_______"] = "gowAKQJ$x";
    m_mapSymbolMeterGoc["gowK_______"] = "gowAKQJ$x";
    m_mapSymbolMeterGoc["gowA_______"] = "gowAKQJ$x";
    m_mapSymbolMeterGoc["gowORANGES_"] = "gowOranges$x";
    m_mapSymbolMeterGoc["gowCOINS___"] = "gowCoins$x";
    m_mapSymbolMeterGoc["gowLANTERN_"] = "gowLantern$x";
    m_mapSymbolMeterGoc["gowVASE____"] = "gowVase$x";
    m_mapSymbolMeterGoc["gowPENDANT_"] = "gowPendant$x";
    m_mapSymbolMeterGoc["gowTREASURE"] = "gowTreasure$x";
    m_mapSymbolMeterGoc["gowTEMPLE__"] = "gowTemple$x";

    m_vecWinLines.push_back("gowWinline1");
    m_vecWinLines.push_back("gowWinline2");
    m_vecWinLines.push_back("gowWinline3");
    m_vecWinLines.push_back("gowWinline4");
    m_vecWinLines.push_back("gowWinline5");
    m_vecWinLines.push_back("gowWinline6");
    m_vecWinLines.push_back("gowWinline7");
    m_vecWinLines.push_back("gowWinline8");
    m_vecWinLines.push_back("gowWinline9");
    m_vecWinLines.push_back("gowWinline10");
    m_vecWinLines.push_back("gowWinlineScat");

    m_vecLineSounds.push_back(SMP_GoWWinStep1);
    m_vecLineSounds.push_back(SMP_GoWWinStep2);
    m_vecLineSounds.push_back(SMP_GoWWinStep3);
    m_vecLineSounds.push_back(SMP_GoWWinStep4);
    m_vecLineSounds.push_back(SMP_GoWWinStep5);
    m_vecLineSounds.push_back(SMP_GoWWinStep6);
    m_vecLineSounds.push_back(SMP_GoWWinStep7);
    m_vecLineSounds.push_back(SMP_GoWWinStep8);
    m_vecLineSounds.push_back(SMP_GoWWinStep9);
    m_vecLineSounds.push_back(SMP_GoWWinStep10);

    //m_vecWinSounds.push_back(SMP_GoWWin1);
    m_vecWinSounds.push_back(SMP_GoWWin2);
    m_vecWinSounds.push_back(SMP_GoWWin3);
    m_vecWinSounds.push_back(SMP_GoWWin4);
    m_vecWinSounds.push_back(SMP_GoWWin5);
    m_vecWinSounds.push_back(SMP_GoWWin6);
    m_vecWinSounds.push_back(SMP_GoWWin7);
    m_vecWinSounds.push_back(SMP_GoWWin8);
    m_vecWinSounds.push_back(SMP_GoWWin9);
    m_vecWinSounds.push_back(SMP_GoWWin10);
    
    m_vecReelStripPlan.push_back("0");
    m_vecReelStripPlan.push_back("1");
    m_vecReelStripPlan.push_back("2");
    m_vecReelStripPlan.push_back("3");
    m_vecReelStripPlan.push_back("4");
    m_vecReelStripPlan.push_back("5");
    m_vecReelStripPlan.push_back("6");
    m_vecReelStripPlan.push_back("7");
    m_vecReelStripPlan.push_back("8");
    m_vecReelStripPlan.push_back("9");
    m_vecReelStripPlan.push_back("10");
    m_vecReelStripPlan.push_back("11");
    m_vecReelStripPlan.push_back("12");
    m_vecReelStripPlan.push_back("13");

    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));

    char* gowReelStrip[] = {
        "gowK_______,gowK_______,gowTREASURE,gowK_______,gowK_______,gowK_______,gowORANGES_,gowORANGES_,gowORANGES_,gowA_______,gowA_______,gowTEMPLE__,gowA_______,gowA_______,gowCOINS___,gowCOINS___,gowCOINS___,gowJ_______,gowJ_______,gowJ_______,gowTREASURE,gowJ_______,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_,gowQ_______,gowQ_______,gowLANTERN_,gowLANTERN_,gowK_______,gowK_______,gowTEMPLE__,gowK_______,gowK_______,gowK_______,gowVASE____,gowVASE____,gowQ_______,gowQ_______,gowPENDANT_,gowPENDANT_,gowA_______,gowA_______,gowA_______,gowCOINS___,gowCOINS___,gowQ_______,gowQ_______,gowORANGES_,gowORANGES_,gowJ_______,gowJ_______,gowJ_______,gowVASE____,gowVASE____,gowQ_______,gowQ_______,gowPENDANT_,gowPENDANT_",
        "gowA_______,gowA_______,gowA_______,gowORANGES_,gowORANGES_,gowK_______,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_,gowJ_______,gowJ_______,gowJ_______,gowTREASURE,gowJ_______,gowJ_______,gowCOINS___,gowCOINS___,gowQ_______,gowQ_______,gowQ_______,gowTEMPLE__,gowQ_______,gowQ_______,gowORANGES_,gowORANGES_,gowK_______,gowK_______,gowTEMPLE__,gowK_______,gowK_______,gowK_______,gowVASE____,gowVASE____,gowVASE____,gowA_______,gowA_______,gowLANTERN_,gowLANTERN_,gowQ_______,gowQ_______,gowQ_______,gowORANGES_,gowORANGES_,gowA_______,gowA_______,gowA_______,gowCOINS___,gowCOINS___,gowCOINS___,gowJ_______,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_",
        "gowA_______,gowA_______,gowA_______,gowCOINS___,gowCOINS___,gowK_______,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_,gowJ_______,gowJ_______,gowJ_______,gowTREASURE,gowJ_______,gowJ_______,gowCOINS___,gowCOINS___,gowQ_______,gowQ_______,gowQ_______,gowTEMPLE__,gowQ_______,gowQ_______,gowCOINS___,gowCOINS___,gowK_______,gowK_______,gowTEMPLE__,gowK_______,gowK_______,gowK_______,gowVASE____,gowVASE____,gowVASE____,gowA_______,gowA_______,gowLANTERN_,gowLANTERN_,gowQ_______,gowQ_______,gowQ_______,gowCOINS___,gowCOINS___,gowA_______,gowA_______,gowA_______,gowCOINS___,gowCOINS___,gowCOINS___,gowJ_______,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_",
        "gowA_______,gowA_______,gowA_______,gowLANTERN_,gowLANTERN_,gowK_______,gowK_______,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_,gowJ_______,gowJ_______,gowJ_______,gowTREASURE,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_,gowQ_______,gowQ_______,gowQ_______,gowTEMPLE__,gowQ_______,gowQ_______,gowLANTERN_,gowLANTERN_,gowK_______,gowK_______,gowK_______,gowK_______,gowVASE____,gowVASE____,gowVASE____,gowA_______,gowA_______,gowLANTERN_,gowLANTERN_,gowQ_______,gowQ_______,gowQ_______,gowLANTERN_,gowLANTERN_,gowA_______,gowA_______,gowA_______,gowLANTERN_,gowLANTERN_,gowLANTERN_,gowJ_______,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_",
        "gowA_______,gowA_______,gowPENDANT_,gowA_______,gowA_______,gowVASE____,gowK_______,gowK_______,gowVASE____,gowK_______,gowK_______,gowVASE____,gowJ_______,gowJ_______,gowVASE____,gowJ_______,gowJ_______,gowVASE____,gowVASE____,gowQ_______,gowQ_______,gowTEMPLE__,gowQ_______,gowQ_______,gowVASE____,gowVASE____,gowK_______,gowK_______,gowTREASURE,gowK_______,gowK_______,gowVASE____,gowQ_______,gowQ_______,gowPENDANT_,gowA_______,gowA_______,gowVASE____,gowVASE____,gowQ_______,gowQ_______,gowVASE____,gowVASE____,gowA_______,gowA_______,gowVASE____,gowVASE____,gowJ_______,gowJ_______,gowVASE____,gowJ_______,gowJ_______,gowVASE____,gowVASE____",
        "gowA_______,gowA_______,gowPENDANT_,gowA_______,gowA_______,gowPENDANT_,gowK_______,gowK_______,gowPENDANT_,gowK_______,gowK_______,gowPENDANT_,gowJ_______,gowJ_______,gowPENDANT_,gowJ_______,gowJ_______,gowPENDANT_,gowPENDANT_,gowQ_______,gowQ_______,gowTEMPLE__,gowQ_______,gowQ_______,gowPENDANT_,gowPENDANT_,gowK_______,gowK_______,gowTREASURE,gowK_______,gowK_______,gowPENDANT_,gowQ_______,gowQ_______,gowPENDANT_,gowA_______,gowA_______,gowPENDANT_,gowPENDANT_,gowQ_______,gowQ_______,gowPENDANT_,gowPENDANT_,gowA_______,gowA_______,gowPENDANT_,gowPENDANT_,gowJ_______,gowJ_______,gowPENDANT_,gowJ_______,gowJ_______,gowPENDANT_,gowPENDANT_",
        "gowA_______,gowA_______,gowTREASURE,gowA_______,gowA_______,gowTREASURE,gowK_______,gowK_______,gowTREASURE,gowK_______,gowK_______,gowTREASURE,gowJ_______,gowJ_______,gowTREASURE,gowJ_______,gowJ_______,gowTREASURE,gowTREASURE,gowQ_______,gowQ_______,gowTEMPLE__,gowQ_______,gowQ_______,gowTREASURE,gowTREASURE,gowK_______,gowK_______,gowTREASURE,gowK_______,gowK_______,gowTREASURE,gowQ_______,gowQ_______,gowTREASURE,gowA_______,gowA_______,gowTREASURE,gowTREASURE,gowQ_______,gowQ_______,gowTREASURE,gowTREASURE,gowA_______,gowA_______,gowTREASURE,gowTREASURE,gowJ_______,gowJ_______,gowTREASURE,gowJ_______,gowJ_______,gowTREASURE,gowTREASURE",
        "gowK_______,gowK_______,gowTREASURE,gowK_______,gowK_______,gowK_______,gowORANGES_,gowORANGES_,gowA_______,gowA_______,gowA_______,gowTEMPLE__,gowA_______,gowA_______,gowCOINS___,gowCOINS___,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_,gowLANTERN_,gowQ_______,gowCOINS___,gowCOINS___,gowQ_______,gowQ_______,gowORANGES_,gowORANGES_,gowJ_______,gowJ_______,gowTEMPLE__,gowJ_______,gowVASE____,gowVASE____,gowQ_______,gowQ_______,gowPENDANT_,gowPENDANT_",
        "gowK_______,gowK_______,gowTREASURE,gowK_______,gowK_______,gowK_______,gowORANGES_,gowORANGES_,gowA_______,gowA_______,gowA_______,gowTEMPLE__,gowA_______,gowA_______,gowCOINS___,gowCOINS___,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_,gowLANTERN_,gowQ_______,gowQ_______,gowCOINS___,gowCOINS___,gowQ_______,gowQ_______,gowORANGES_,gowORANGES_,gowJ_______,gowJ_______,gowJ_______,gowVASE____,gowVASE____,gowQ_______,gowQ_______,gowPENDANT_,gowPENDANT_",
        "gowK_______,gowK_______,gowTREASURE,gowK_______,gowK_______,gowK_______,gowCOINS___,gowCOINS___,gowA_______,gowA_______,gowA_______,gowTEMPLE__,gowA_______,gowA_______,gowCOINS___,gowCOINS___,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_,gowLANTERN_,gowQ_______,gowQ_______,gowCOINS___,gowCOINS___,gowQ_______,gowQ_______,gowCOINS___,gowCOINS___,gowJ_______,gowJ_______,gowJ_______,gowVASE____,gowVASE____,gowQ_______,gowQ_______,gowPENDANT_,gowPENDANT_",
        "gowK_______,gowK_______,gowTREASURE,gowK_______,gowK_______,gowK_______,gowLANTERN_,gowLANTERN_,gowA_______,gowA_______,gowA_______,gowTEMPLE__,gowA_______,gowA_______,gowLANTERN_,gowLANTERN_,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_,gowLANTERN_,gowQ_______,gowQ_______,gowLANTERN_,gowLANTERN_,gowQ_______,gowQ_______,gowLANTERN_,gowLANTERN_,gowJ_______,gowJ_______,gowJ_______,gowVASE____,gowVASE____,gowQ_______,gowQ_______,gowPENDANT_,gowPENDANT_",
        "gowK_______,gowK_______,gowTREASURE,gowK_______,gowK_______,gowK_______,gowVASE____,gowVASE____,gowA_______,gowA_______,gowA_______,gowTEMPLE__,gowA_______,gowA_______,gowVASE____,gowVASE____,gowJ_______,gowJ_______,gowVASE____,gowVASE____,gowVASE____,gowQ_______,gowQ_______,gowVASE____,gowVASE____,gowQ_______,gowQ_______,gowVASE____,gowVASE____,gowJ_______,gowJ_______,gowJ_______,gowVASE____,gowVASE____,gowQ_______,gowQ_______,gowPENDANT_,gowPENDANT_",
        "gowK_______,gowK_______,gowTREASURE,gowK_______,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_,gowA_______,gowA_______,gowA_______,gowTEMPLE__,gowA_______,gowA_______,gowPENDANT_,gowPENDANT_,gowJ_______,gowJ_______,gowPENDANT_,gowPENDANT_,gowPENDANT_,gowQ_______,gowQ_______,gowPENDANT_,gowPENDANT_,gowQ_______,gowQ_______,gowPENDANT_,gowPENDANT_,gowJ_______,gowJ_______,gowJ_______,gowPENDANT_,gowPENDANT_,gowQ_______,gowQ_______,gowPENDANT_,gowPENDANT_",
        "gowK_______,gowK_______,gowTREASURE,gowK_______,gowK_______,gowK_______,gowTREASURE,gowTREASURE,gowA_______,gowA_______,gowA_______,gowTEMPLE__,gowA_______,gowA_______,gowTREASURE,gowTREASURE,gowJ_______,gowJ_______,gowTREASURE,gowTREASURE,gowTREASURE,gowQ_______,gowQ_______,gowTREASURE,gowTREASURE,gowQ_______,gowQ_______,gowTREASURE,gowTREASURE,gowJ_______,gowJ_______,gowJ_______,gowTREASURE,gowTREASURE,gowQ_______,gowQ_______,gowTREASURE,gowTREASURE",

        "gowA_______,gowA_______,gowA_______,gowCOINS___,gowCOINS___,gowQ_______,gowQ_______,gowTEMPLE__,gowQ_______,gowQ_______,gowQ_______,gowVASE____,gowVASE____,gowK_______,gowK_______,gowTEMPLE__,gowK_______,gowK_______,gowCOINS___,gowCOINS___,gowJ_______,gowJ_______,gowPENDANT_,gowPENDANT_,gowQ_______,gowQ_______,gowTREASURE,gowQ_______,gowQ_______,gowCOINS___,gowCOINS___,gowK_______,gowK_______,gowLANTERN_,gowLANTERN_,gowA_______,gowA_______,gowTREASURE,gowA_______,gowA_______,gowA_______,gowORANGES_,gowORANGES_,gowORANGES_,gowJ_______,gowJ_______,gowTEMPLE__,gowJ_______,gowJ_______,gowCAISHEN_,gowK_______,gowK_______,gowORANGES_,gowORANGES_,gowA_______,gowA_______,gowLANTERN_,gowLANTERN_,gowJ_______,gowJ_______,gowJ_______,gowVASE____,gowVASE____",
        "gowA_______,gowA_______,gowCAISHEN_,gowK_______,gowK_______,gowK_______,gowTEMPLE__,gowK_______,gowK_______,gowORANGES_,gowORANGES_,gowORANGES_,gowQ_______,gowQ_______,gowCAISHEN_,gowJ_______,gowJ_______,gowJ_______,gowTEMPLE__,gowJ_______,gowJ_______,gowCOINS___,gowCOINS___,gowCOINS___,gowA_______,gowA_______,gowLANTERN_,gowLANTERN_,gowA_______,gowA_______,gowPENDANT_,gowPENDANT_,gowK_______,gowK_______,gowK_______,gowCAISHEN_,gowJ_______,gowJ_______,gowJ_______,gowORANGES_,gowORANGES_,gowORANGES_,gowA_______,gowA_______,gowCOINS___,gowCOINS___,gowQ_______,gowQ_______,gowTREASURE,gowQ_______,gowQ_______,gowLANTERN_,gowLANTERN_,gowQ_______,gowQ_______,gowVASE____,gowVASE____,gowVASE____",
        "gowA_______,gowA_______,gowCAISHEN_,gowK_______,gowK_______,gowK_______,gowTEMPLE__,gowK_______,gowK_______,gowCOINS___,gowCOINS___,gowQ_______,gowQ_______,gowQ_______,gowCAISHEN_,gowJ_______,gowJ_______,gowJ_______,gowCOINS___,gowCOINS___,gowA_______,gowA_______,gowLANTERN_,gowLANTERN_,gowA_______,gowA_______,gowPENDANT_,gowPENDANT_,gowK_______,gowK_______,gowK_______,gowCOINS___,gowCOINS___,gowJ_______,gowJ_______,gowJ_______,gowCOINS___,gowCOINS___,gowCOINS___,gowA_______,gowA_______,gowCOINS___,gowCOINS___,gowQ_______,gowQ_______,gowQ_______,gowTREASURE,gowQ_______,gowQ_______,gowLANTERN_,gowLANTERN_,gowJ_______,gowJ_______,gowVASE____,gowVASE____,gowVASE____",
        "gowA_______,gowA_______,gowA_______,gowCAISHEN_,gowK_______,gowK_______,gowK_______,gowTEMPLE__,gowK_______,gowK_______,gowK_______,gowLANTERN_,gowLANTERN_,gowQ_______,gowQ_______,gowQ_______,gowLANTERN_,gowLANTERN_,gowJ_______,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_,gowA_______,gowA_______,gowA_______,gowPENDANT_,gowPENDANT_,gowK_______,gowK_______,gowK_______,gowLANTERN_,gowLANTERN_,gowJ_______,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_,gowLANTERN_,gowA_______,gowA_______,gowLANTERN_,gowLANTERN_,gowQ_______,gowQ_______,gowQ_______,gowTREASURE,gowQ_______,gowQ_______,gowLANTERN_,gowLANTERN_,gowJ_______,gowJ_______,gowVASE____,gowVASE____,gowK_______,gowK_______,gowK_______,gowK_______,gowLANTERN_,gowLANTERN_,gowQ_______,gowQ_______,gowQ_______,gowLANTERN_,gowLANTERN_,gowA_______,gowA_______,gowA_______,gowLANTERN_,gowLANTERN_,gowJ_______,gowJ_______,gowJ_______,gowVASE____,gowVASE____,gowA_______,gowA_______,gowPENDANT_,gowPENDANT_,gowK_______,gowK_______,gowK_______,gowLANTERN_,gowLANTERN_,gowJ_______,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_,gowLANTERN_,gowA_______,gowA_______,gowA_______,gowLANTERN_,gowLANTERN_,gowQ_______,gowQ_______,gowQ_______,gowTREASURE,gowQ_______,gowQ_______,gowLANTERN_,gowLANTERN_,gowJ_______,gowJ_______,gowVASE____,gowVASE____",
        "gowA_______,gowA_______,gowCAISHEN_,gowK_______,gowK_______,gowTEMPLE__,gowK_______,gowK_______,gowVASE____,gowQ_______,gowQ_______,gowTREASURE,gowQ_______,gowQ_______,gowVASE____,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_,gowJ_______,gowJ_______,gowVASE____,gowA_______,gowA_______,gowVASE____,gowA_______,gowA_______,gowVASE____,gowVASE____,gowK_______,gowK_______,gowVASE____,gowVASE____,gowJ_______,gowJ_______,gowTREASURE,gowJ_______,gowJ_______,gowVASE____,gowVASE____,gowA_______,gowA_______,gowVASE____,gowVASE____,gowQ_______,gowQ_______,gowVASE____,gowQ_______,gowQ_______,gowVASE____,gowVASE____,gowJ_______,gowJ_______,gowVASE____,gowVASE____,gowK_______,gowK_______,gowVASE____,gowK_______,gowK_______,gowVASE____,gowVASE____,gowQ_______,gowQ_______,gowPENDANT_,gowA_______,gowA_______,gowVASE____,gowVASE____,gowJ_______,gowJ_______,gowVASE____,gowA_______,gowA_______,gowVASE____,gowVASE____,gowK_______,gowK_______,gowPENDANT_,gowK_______,gowK_______,gowVASE____,gowJ_______,gowJ_______,gowVASE____,gowJ_______,gowJ_______,gowVASE____,gowVASE____,gowA_______,gowA_______,gowVASE____,gowA_______,gowA_______,gowVASE____,gowQ_______,gowQ_______,gowVASE____,gowQ_______,gowQ_______,gowVASE____,gowQ_______,gowQ_______,gowVASE____,gowVASE____,gowJ_______,gowJ_______,gowVASE____",
        "gowA_______,gowA_______,gowCAISHEN_,gowK_______,gowK_______,gowTEMPLE__,gowK_______,gowK_______,gowPENDANT_,gowQ_______,gowQ_______,gowTREASURE,gowQ_______,gowQ_______,gowPENDANT_,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_,gowJ_______,gowJ_______,gowPENDANT_,gowA_______,gowA_______,gowPENDANT_,gowA_______,gowA_______,gowPENDANT_,gowPENDANT_,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_,gowJ_______,gowJ_______,gowTREASURE,gowJ_______,gowJ_______,gowPENDANT_,gowPENDANT_,gowA_______,gowA_______,gowPENDANT_,gowPENDANT_,gowQ_______,gowQ_______,gowPENDANT_,gowQ_______,gowQ_______,gowPENDANT_,gowPENDANT_,gowJ_______,gowJ_______,gowPENDANT_,gowPENDANT_,gowK_______,gowK_______,gowPENDANT_,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_,gowQ_______,gowQ_______,gowPENDANT_,gowA_______,gowA_______,gowPENDANT_,gowPENDANT_,gowJ_______,gowJ_______,gowPENDANT_,gowA_______,gowA_______,gowPENDANT_,gowPENDANT_,gowK_______,gowK_______,gowPENDANT_,gowK_______,gowK_______,gowPENDANT_,gowJ_______,gowJ_______,gowPENDANT_,gowJ_______,gowJ_______,gowPENDANT_,gowPENDANT_,gowA_______,gowA_______,gowPENDANT_,gowA_______,gowA_______,gowPENDANT_,gowQ_______,gowQ_______,gowPENDANT_,gowQ_______,gowQ_______,gowPENDANT_,gowQ_______,gowQ_______,gowPENDANT_,gowPENDANT_,gowJ_______,gowJ_______,gowPENDANT_",
        "gowA_______,gowA_______,gowCAISHEN_,gowK_______,gowK_______,gowTEMPLE__,gowK_______,gowK_______,gowTREASURE,gowQ_______,gowQ_______,gowTREASURE,gowQ_______,gowQ_______,gowTREASURE,gowK_______,gowK_______,gowTREASURE,gowTREASURE,gowJ_______,gowJ_______,gowTREASURE,gowA_______,gowA_______,gowTREASURE,gowA_______,gowA_______,gowTREASURE,gowTREASURE,gowK_______,gowK_______,gowTREASURE,gowTREASURE,gowJ_______,gowJ_______,gowTREASURE,gowJ_______,gowJ_______,gowTREASURE,gowTREASURE,gowA_______,gowA_______,gowTREASURE,gowTREASURE,gowQ_______,gowQ_______,gowTREASURE,gowQ_______,gowQ_______,gowTREASURE,gowTREASURE,gowJ_______,gowJ_______,gowTREASURE,gowTREASURE,gowK_______,gowK_______,gowTREASURE,gowK_______,gowK_______,gowTREASURE,gowTREASURE,gowQ_______,gowQ_______,gowTREASURE,gowA_______,gowA_______,gowTREASURE,gowTREASURE,gowJ_______,gowJ_______,gowTREASURE,gowA_______,gowA_______,gowTREASURE,gowTREASURE,gowK_______,gowK_______,gowTREASURE,gowK_______,gowK_______,gowTREASURE,gowJ_______,gowJ_______,gowTREASURE,gowJ_______,gowJ_______,gowTREASURE,gowTREASURE,gowA_______,gowA_______,gowTREASURE,gowA_______,gowA_______,gowTREASURE,gowQ_______,gowQ_______,gowTREASURE,gowQ_______,gowQ_______,gowTREASURE,gowQ_______,gowQ_______,gowTREASURE,gowTREASURE,gowJ_______,gowJ_______,gowTREASURE",
        "gowA_______,gowTREASURE,gowA_______,gowA_______,gowCOINS___,gowCOINS___,gowQ_______,gowQ_______,gowTEMPLE__,gowQ_______,gowQ_______,gowQ_______,gowVASE____,gowVASE____,gowK_______,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_,gowJ_______,gowLANTERN_,gowLANTERN_,gowJ_______,gowJ_______,gowCAISHEN_,gowK_______,gowK_______,gowORANGES_,gowORANGES_,gowA_______,gowA_______,gowLANTERN_,gowLANTERN_,gowJ_______,gowJ_______,gowCOINS___,gowCOINS___",
        "gowQ_______,gowCAISHEN_,gowA_______,gowA_______,gowTREASURE,gowA_______,gowA_______,gowCOINS___,gowCOINS___,gowQ_______,gowQ_______,gowTEMPLE__,gowQ_______,gowQ_______,gowVASE____,gowVASE____,gowK_______,gowK_______,gowCAISHEN_,gowJ_______,gowJ_______,gowPENDANT_,gowPENDANT_,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_,gowJ_______,gowJ_______,gowCAISHEN_,gowK_______,gowK_______,gowORANGES_,gowORANGES_,gowA_______,gowA_______,gowLANTERN_,gowLANTERN_,gowJ_______,gowJ_______,gowCOINS___,gowCOINS___,gowQ_______",
        "gowQ_______,gowCAISHEN_,gowA_______,gowA_______,gowTREASURE,gowA_______,gowA_______,gowCOINS___,gowCOINS___,gowQ_______,gowQ_______,gowTEMPLE__,gowQ_______,gowQ_______,gowVASE____,gowVASE____,gowK_______,gowK_______,gowCAISHEN_,gowJ_______,gowJ_______,gowPENDANT_,gowPENDANT_,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_,gowJ_______,gowJ_______,gowCAISHEN_,gowK_______,gowK_______,gowCOINS___,gowCOINS___,gowA_______,gowA_______,gowLANTERN_,gowLANTERN_,gowJ_______,gowJ_______,gowCOINS___,gowCOINS___,gowQ_______",
        "gowQ_______,gowCAISHEN_,gowA_______,gowA_______,gowTREASURE,gowA_______,gowA_______,gowLANTERN_,gowLANTERN_,gowQ_______,gowQ_______,gowTEMPLE__,gowQ_______,gowQ_______,gowVASE____,gowVASE____,gowK_______,gowK_______,gowCAISHEN_,gowJ_______,gowJ_______,gowPENDANT_,gowPENDANT_,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_,gowJ_______,gowJ_______,gowCAISHEN_,gowK_______,gowK_______,gowLANTERN_,gowLANTERN_,gowA_______,gowA_______,gowLANTERN_,gowLANTERN_,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_,gowQ_______",
        "gowQ_______,gowCAISHEN_,gowA_______,gowA_______,gowTREASURE,gowA_______,gowA_______,gowVASE____,gowVASE____,gowQ_______,gowQ_______,gowTEMPLE__,gowQ_______,gowQ_______,gowVASE____,gowVASE____,gowK_______,gowK_______,gowCAISHEN_,gowJ_______,gowJ_______,gowPENDANT_,gowPENDANT_,gowJ_______,gowJ_______,gowVASE____,gowVASE____,gowJ_______,gowJ_______,gowCAISHEN_,gowK_______,gowK_______,gowVASE____,gowVASE____,gowA_______,gowA_______,gowVASE____,gowVASE____,gowJ_______,gowJ_______,gowVASE____,gowVASE____,gowQ_______",
        "gowQ_______,gowCAISHEN_,gowA_______,gowA_______,gowTREASURE,gowA_______,gowA_______,gowPENDANT_,gowPENDANT_,gowQ_______,gowQ_______,gowTEMPLE__,gowQ_______,gowQ_______,gowPENDANT_,gowPENDANT_,gowK_______,gowK_______,gowCAISHEN_,gowJ_______,gowJ_______,gowPENDANT_,gowPENDANT_,gowJ_______,gowJ_______,gowPENDANT_,gowPENDANT_,gowJ_______,gowJ_______,gowCAISHEN_,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_,gowA_______,gowA_______,gowPENDANT_,gowPENDANT_,gowJ_______,gowJ_______,gowPENDANT_,gowPENDANT_,gowQ_______",
        "gowQ_______,gowCAISHEN_,gowA_______,gowA_______,gowTREASURE,gowA_______,gowA_______,gowTREASURE,gowTREASURE,gowQ_______,gowQ_______,gowTEMPLE__,gowQ_______,gowQ_______,gowTREASURE,gowTREASURE,gowK_______,gowK_______,gowCAISHEN_,gowJ_______,gowJ_______,gowTREASURE,gowTREASURE,gowJ_______,gowJ_______,gowTREASURE,gowTREASURE,gowJ_______,gowJ_______,gowCAISHEN_,gowK_______,gowK_______,gowTREASURE,gowTREASURE,gowA_______,gowA_______,gowTREASURE,gowTREASURE,gowJ_______,gowJ_______,gowTREASURE,gowTREASURE,gowQ_______",

        "gowQ_______,gowQ_______,gowCAISHEN_,gowJ_______,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_,gowA_______,gowA_______,gowTEMPLE__,gowA_______,gowA_______,gowCOINS___,gowCOINS___,gowJ_______,gowJ_______,gowJ_______,gowTREASURE,gowA_______,gowA_______,gowA_______,gowORANGES_,gowORANGES_,gowORANGES_,gowQ_______,gowQ_______,gowTEMPLE__,gowQ_______,gowQ_______,gowQ_______,gowVASE____,gowVASE____,gowJ_______,gowJ_______,gowJ_______,gowCOINS___,gowCOINS___,gowCOINS___,gowA_______,gowA_______,gowLANTERN_,gowLANTERN_,gowK_______,gowK_______,gowTREASURE,gowK_______,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_,gowQ_______,gowQ_______,gowVASE____,gowVASE____,gowK_______,gowK_______,gowK_______,gowORANGES_,gowORANGES_",
        "gowQ_______,gowQ_______,gowCAISHEN_,gowK_______,gowK_______,gowCOINS___,gowCOINS___,gowCOINS___,gowQ_______,gowQ_______,gowTEMPLE__,gowQ_______,gowQ_______,gowLANTERN_,gowLANTERN_,gowJ_______,gowJ_______,gowJ_______,gowCAISHEN_,gowA_______,gowA_______,gowORANGES_,gowORANGES_,gowJ_______,gowJ_______,gowTREASURE,gowJ_______,gowJ_______,gowJ_______,gowCAISHEN_,gowQ_______,gowQ_______,gowCOINS___,gowCOINS___,gowK_______,gowK_______,gowORANGES_,gowORANGES_,gowA_______,gowA_______,gowTEMPLE__,gowA_______,gowA_______,gowVASE____,gowVASE____,gowVASE____,gowK_______,gowK_______,gowLANTERN_,gowLANTERN_,gowA_______,gowA_______,gowPENDANT_,gowPENDANT_,gowK_______,gowK_______,gowORANGES_,gowORANGES_",
        "gowQ_______,gowQ_______,gowCAISHEN_,gowK_______,gowK_______,gowK_______,gowCOINS___,gowCOINS___,gowCOINS___,gowQ_______,gowQ_______,gowTEMPLE__,gowQ_______,gowQ_______,gowLANTERN_,gowLANTERN_,gowJ_______,gowJ_______,gowJ_______,gowCAISHEN_,gowA_______,gowA_______,gowCOINS___,gowCOINS___,gowJ_______,gowJ_______,gowTREASURE,gowJ_______,gowJ_______,gowJ_______,gowCOINS___,gowCOINS___,gowK_______,gowK_______,gowK_______,gowCOINS___,gowCOINS___,gowA_______,gowA_______,gowTEMPLE__,gowA_______,gowA_______,gowVASE____,gowVASE____,gowVASE____,gowQ_______,gowQ_______,gowLANTERN_,gowLANTERN_,gowA_______,gowA_______,gowPENDANT_,gowPENDANT_,gowK_______,gowK_______,gowCOINS___,gowCOINS___",
        "gowQ_______,gowQ_______,gowCAISHEN_,gowA_______,gowA_______,gowA_______,gowLANTERN_,gowLANTERN_,gowLANTERN_,gowQ_______,gowQ_______,gowQ_______,gowLANTERN_,gowLANTERN_,gowJ_______,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_,gowJ_______,gowJ_______,gowTREASURE,gowJ_______,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_,gowK_______,gowK_______,gowK_______,gowLANTERN_,gowLANTERN_,gowA_______,gowA_______,gowA_______,gowTEMPLE__,gowA_______,gowA_______,gowVASE____,gowVASE____,gowVASE____,gowK_______,gowK_______,gowK_______,gowLANTERN_,gowLANTERN_,gowQ_______,gowQ_______,gowQ_______,gowPENDANT_,gowPENDANT_,gowK_______,gowK_______,gowLANTERN_,gowLANTERN_",
        "gowQ_______,gowQ_______,gowCAISHEN_,gowA_______,gowA_______,gowVASE____,gowVASE____,gowQ_______,gowQ_______,gowVASE____,gowJ_______,gowJ_______,gowVASE____,gowVASE____,gowJ_______,gowJ_______,gowVASE____,gowQ_______,gowQ_______,gowVASE____,gowVASE____,gowJ_______,gowJ_______,gowVASE____,gowVASE____,gowK_______,gowK_______,gowVASE____,gowVASE____,gowA_______,gowA_______,gowTEMPLE__,gowA_______,gowA_______,gowTREASURE,gowA_______,gowA_______,gowVASE____,gowVASE____,gowK_______,gowK_______,gowVASE____,gowVASE____,gowQ_______,gowQ_______,gowPENDANT_,gowK_______,gowK_______,gowVASE____,gowVASE____,gowK_______,gowK_______,gowPENDANT_,gowJ_______,gowJ_______",
        "gowQ_______,gowQ_______,gowCAISHEN_,gowA_______,gowA_______,gowPENDANT_,gowPENDANT_,gowQ_______,gowQ_______,gowPENDANT_,gowJ_______,gowJ_______,gowPENDANT_,gowJ_______,gowPENDANT_,gowJ_______,gowJ_______,gowPENDANT_,gowQ_______,gowQ_______,gowPENDANT_,gowPENDANT_,gowJ_______,gowJ_______,gowPENDANT_,gowPENDANT_,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_,gowA_______,gowA_______,gowTEMPLE__,gowA_______,gowA_______,gowTREASURE,gowA_______,gowA_______,gowPENDANT_,gowPENDANT_,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_,gowQ_______,gowQ_______,gowPENDANT_,gowK_______,gowK_______,gowTREASURE,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_,gowA_______,gowA_______,gowPENDANT_,gowQ_______,gowPENDANT_,gowQ_______,gowQ_______,gowPENDANT_,gowK_______,gowK_______,gowPENDANT_,gowQ_______,gowQ_______,gowPENDANT_,gowPENDANT_,gowJ_______,gowJ_______,gowPENDANT_,gowJ_______,gowPENDANT_,gowJ_______,gowJ_______,gowPENDANT_,gowJ_______,gowJ_______,gowPENDANT_,gowPENDANT_,gowK_______,gowK_______,gowPENDANT_,gowK_______,gowK_______,gowPENDANT_,gowK_______,gowK_______,gowPENDANT_,gowA_______,gowA_______,gowPENDANT_,gowQ_______,gowQ_______,gowPENDANT_,gowQ_______,gowPENDANT_,gowPENDANT_,gowA_______,gowA_______,gowPENDANT_,gowJ_______,gowJ_______,gowPENDANT_,gowPENDANT_,gowA_______,gowA_______",
        "gowQ_______,gowQ_______,gowCAISHEN_,gowA_______,gowA_______,gowTREASURE,gowTREASURE,gowQ_______,gowQ_______,gowTREASURE,gowJ_______,gowJ_______,gowTREASURE,gowJ_______,gowTREASURE,gowJ_______,gowJ_______,gowTREASURE,gowQ_______,gowQ_______,gowTREASURE,gowTREASURE,gowJ_______,gowJ_______,gowTREASURE,gowTREASURE,gowK_______,gowK_______,gowTREASURE,gowTREASURE,gowA_______,gowA_______,gowTEMPLE__,gowA_______,gowA_______,gowTREASURE,gowA_______,gowA_______,gowTREASURE,gowTREASURE,gowK_______,gowK_______,gowTREASURE,gowTREASURE,gowQ_______,gowQ_______,gowTREASURE,gowK_______,gowK_______,gowTREASURE,gowK_______,gowK_______,gowTREASURE,gowTREASURE,gowA_______,gowA_______,gowTREASURE,gowQ_______,gowTREASURE,gowQ_______,gowQ_______,gowTREASURE,gowK_______,gowK_______,gowTREASURE,gowQ_______,gowQ_______,gowTREASURE,gowTREASURE,gowJ_______,gowJ_______,gowTREASURE,gowJ_______,gowTREASURE,gowJ_______,gowJ_______,gowTREASURE,gowJ_______,gowJ_______,gowTREASURE,gowTREASURE,gowK_______,gowK_______,gowTREASURE,gowK_______,gowK_______,gowTREASURE,gowK_______,gowK_______,gowTREASURE,gowA_______,gowA_______,gowTREASURE,gowQ_______,gowQ_______,gowTREASURE,gowQ_______,gowTREASURE,gowTREASURE,gowA_______,gowA_______,gowTREASURE,gowJ_______,gowJ_______,gowTREASURE,gowTREASURE,gowA_______,gowA_______",
        "gowQ_______,gowQ_______,gowCAISHEN_,gowJ_______,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_,gowA_______,gowA_______,gowTEMPLE__,gowA_______,gowCOINS___,gowCOINS___,gowJ_______,gowJ_______,gowORANGES_,gowORANGES_,gowA_______,gowA_______,gowLANTERN_,gowLANTERN_,gowK_______,gowK_______,gowTREASURE,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_,gowQ_______,gowQ_______,gowVASE____,gowVASE____,gowK_______,gowK_______,gowORANGES_,gowORANGES_",
        "gowQ_______,gowQ_______,gowCAISHEN_,gowJ_______,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_,gowA_______,gowA_______,gowTEMPLE__,gowA_______,gowA_______,gowCOINS___,gowCOINS___,gowJ_______,gowJ_______,gowCAISHEN_,gowQ_______,gowQ_______,gowORANGES_,gowORANGES_,gowA_______,gowA_______,gowLANTERN_,gowLANTERN_,gowK_______,gowK_______,gowTREASURE,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_,gowQ_______,gowQ_______,gowVASE____,gowVASE____,gowK_______,gowK_______,gowORANGES_,gowORANGES_",
        "gowQ_______,gowQ_______,gowCAISHEN_,gowJ_______,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_,gowA_______,gowA_______,gowTEMPLE__,gowA_______,gowA_______,gowCOINS___,gowCOINS___,gowJ_______,gowJ_______,gowCAISHEN_,gowQ_______,gowQ_______,gowCOINS___,gowCOINS___,gowA_______,gowA_______,gowLANTERN_,gowLANTERN_,gowK_______,gowK_______,gowTREASURE,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_,gowQ_______,gowQ_______,gowVASE____,gowVASE____,gowK_______,gowK_______,gowCOINS___,gowCOINS___",
        "gowQ_______,gowQ_______,gowCAISHEN_,gowJ_______,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_,gowA_______,gowA_______,gowTEMPLE__,gowA_______,gowA_______,gowLANTERN_,gowLANTERN_,gowJ_______,gowJ_______,gowCAISHEN_,gowQ_______,gowQ_______,gowLANTERN_,gowLANTERN_,gowA_______,gowA_______,gowLANTERN_,gowLANTERN_,gowK_______,gowK_______,gowTREASURE,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_,gowQ_______,gowQ_______,gowVASE____,gowVASE____,gowK_______,gowK_______,gowLANTERN_,gowLANTERN_",
        "gowQ_______,gowQ_______,gowCAISHEN_,gowJ_______,gowJ_______,gowJ_______,gowVASE____,gowVASE____,gowA_______,gowA_______,gowTEMPLE__,gowA_______,gowA_______,gowVASE____,gowVASE____,gowJ_______,gowJ_______,gowCAISHEN_,gowQ_______,gowQ_______,gowVASE____,gowVASE____,gowA_______,gowA_______,gowVASE____,gowVASE____,gowK_______,gowK_______,gowTREASURE,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_,gowQ_______,gowQ_______,gowVASE____,gowVASE____,gowK_______,gowK_______,gowVASE____,gowVASE____",
        "gowQ_______,gowQ_______,gowCAISHEN_,gowJ_______,gowJ_______,gowJ_______,gowPENDANT_,gowPENDANT_,gowA_______,gowA_______,gowTEMPLE__,gowA_______,gowA_______,gowPENDANT_,gowPENDANT_,gowJ_______,gowJ_______,gowCAISHEN_,gowQ_______,gowQ_______,gowPENDANT_,gowPENDANT_,gowA_______,gowA_______,gowPENDANT_,gowPENDANT_,gowK_______,gowK_______,gowTREASURE,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_,gowQ_______,gowQ_______,gowPENDANT_,gowPENDANT_,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_",
        "gowQ_______,gowQ_______,gowCAISHEN_,gowJ_______,gowJ_______,gowJ_______,gowTREASURE,gowTREASURE,gowA_______,gowA_______,gowTEMPLE__,gowA_______,gowA_______,gowTREASURE,gowTREASURE,gowJ_______,gowJ_______,gowCAISHEN_,gowQ_______,gowQ_______,gowTREASURE,gowTREASURE,gowA_______,gowA_______,gowTREASURE,gowTREASURE,gowK_______,gowK_______,gowTREASURE,gowK_______,gowK_______,gowTREASURE,gowTREASURE,gowQ_______,gowQ_______,gowTREASURE,gowTREASURE,gowK_______,gowK_______,gowTREASURE,gowTREASURE",

        "gowA_______,gowA_______,gowCAISHEN_,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_,gowQ_______,gowQ_______,gowCOINS___,gowCOINS___,gowCOINS___,gowJ_______,gowJ_______,gowTEMPLE__,gowJ_______,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_,gowK_______,gowK_______,gowCOINS___,gowCOINS___,gowA_______,gowA_______,gowTREASURE,gowA_______,gowA_______,gowVASE____,gowVASE____,gowQ_______,gowQ_______,gowQ_______,gowORANGES_,gowORANGES_,gowK_______,gowK_______,gowTREASURE,gowK_______,gowK_______,gowVASE____,gowVASE____,gowA_______,gowA_______,gowA_______,gowORANGES_,gowORANGES_,gowQ_______,gowQ_______,gowTEMPLE__,gowQ_______,gowQ_______,gowORANGES_,gowORANGES_,gowJ_______,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_",
        "gowJ_______,gowJ_______,gowJ_______,gowCAISHEN_,gowK_______,gowK_______,gowTEMPLE__,gowK_______,gowK_______,gowCOINS___,gowCOINS___,gowCOINS___,gowJ_______,gowJ_______,gowTEMPLE__,gowJ_______,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_,gowQ_______,gowQ_______,gowQ_______,gowPENDANT_,gowPENDANT_,gowA_______,gowA_______,gowA_______,gowCAISHEN_,gowQ_______,gowQ_______,gowQ_______,gowORANGES_,gowORANGES_,gowORANGES_,gowA_______,gowA_______,gowLANTERN_,gowLANTERN_,gowQ_______,gowQ_______,gowVASE____,gowVASE____,gowVASE____,gowK_______,gowK_______,gowTREASURE,gowK_______,gowK_______,gowORANGES_,gowORANGES_,gowORANGES_,gowA_______,gowA_______,gowA_______,gowCOINS___,gowCOINS___",
        "gowJ_______,gowJ_______,gowJ_______,gowCAISHEN_,gowK_______,gowK_______,gowK_______,gowCOINS___,gowCOINS___,gowQ_______,gowQ_______,gowPENDANT_,gowPENDANT_,gowJ_______,gowJ_______,gowTEMPLE__,gowJ_______,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_,gowQ_______,gowQ_______,gowQ_______,gowCOINS___,gowCOINS___,gowA_______,gowA_______,gowA_______,gowCOINS___,gowCOINS___,gowA_______,gowA_______,gowLANTERN_,gowLANTERN_,gowQ_______,gowQ_______,gowQ_______,gowVASE____,gowVASE____,gowVASE____,gowK_______,gowK_______,gowTREASURE,gowK_______,gowK_______,gowK_______,gowCOINS___,gowCOINS___,gowCOINS___,gowA_______,gowA_______,gowA_______,gowCOINS___,gowCOINS___",
        "gowJ_______,gowJ_______,gowJ_______,gowCAISHEN_,gowK_______,gowK_______,gowK_______,gowLANTERN_,gowLANTERN_,gowQ_______,gowQ_______,gowPENDANT_,gowPENDANT_,gowJ_______,gowJ_______,gowTEMPLE__,gowJ_______,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_,gowQ_______,gowQ_______,gowQ_______,gowLANTERN_,gowLANTERN_,gowA_______,gowA_______,gowA_______,gowLANTERN_,gowLANTERN_,gowA_______,gowA_______,gowLANTERN_,gowLANTERN_,gowQ_______,gowQ_______,gowQ_______,gowVASE____,gowVASE____,gowVASE____,gowK_______,gowK_______,gowTREASURE,gowK_______,gowK_______,gowK_______,gowLANTERN_,gowLANTERN_,gowLANTERN_,gowA_______,gowA_______,gowA_______,gowLANTERN_,gowLANTERN_",
        "gowA_______,gowJ_______,gowJ_______,gowCAISHEN_,gowK_______,gowK_______,gowVASE____,gowVASE____,gowQ_______,gowQ_______,gowVASE____,gowJ_______,gowJ_______,gowPENDANT_,gowJ_______,gowJ_______,gowTEMPLE__,gowJ_______,gowJ_______,gowVASE____,gowVASE____,gowQ_______,gowQ_______,gowVASE____,gowVASE____,gowA_______,gowA_______,gowTREASURE,gowA_______,gowA_______,gowVASE____,gowVASE____,gowQ_______,gowQ_______,gowVASE____,gowQ_______,gowQ_______,gowVASE____,gowK_______,gowK_______,gowVASE____,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_,gowK_______,gowK_______,gowVASE____,gowA_______,gowA_______,gowVASE____,gowA_______,gowA_______,gowVASE____,gowVASE____,gowJ_______,gowJ_______,gowTREASURE,gowJ_______,gowJ_______,gowVASE____,gowVASE____,gowQ_______,gowQ_______,gowVASE____,gowJ_______,gowJ_______,gowVASE____,gowJ_______,gowJ_______,gowVASE____,gowVASE____,gowQ_______,gowQ_______,gowVASE____,gowVASE____,gowA_______,gowA_______,gowPENDANT_,gowA_______,gowA_______,gowVASE____,gowQ_______,gowQ_______,gowVASE____,gowQ_______,gowQ_______,gowVASE____,gowVASE____,gowK_______,gowK_______,gowVASE____,gowK_______,gowK_______,gowVASE____,gowVASE____,gowK_______,gowK_______,gowVASE____,gowK_______,gowK_______,gowVASE____,gowVASE____,gowA_______,gowA_______,gowVASE____,gowVASE____,gowA_______",
        "gowA_______,gowJ_______,gowJ_______,gowCAISHEN_,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_,gowQ_______,gowQ_______,gowPENDANT_,gowJ_______,gowJ_______,gowPENDANT_,gowJ_______,gowJ_______,gowTEMPLE__,gowJ_______,gowJ_______,gowPENDANT_,gowPENDANT_,gowQ_______,gowQ_______,gowPENDANT_,gowPENDANT_,gowA_______,gowA_______,gowTREASURE,gowA_______,gowA_______,gowPENDANT_,gowPENDANT_,gowQ_______,gowQ_______,gowPENDANT_,gowQ_______,gowQ_______,gowPENDANT_,gowK_______,gowK_______,gowPENDANT_,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_,gowK_______,gowK_______,gowPENDANT_,gowA_______,gowA_______,gowPENDANT_,gowA_______,gowA_______,gowPENDANT_,gowPENDANT_,gowJ_______,gowJ_______,gowTREASURE,gowJ_______,gowJ_______,gowPENDANT_,gowPENDANT_,gowQ_______,gowQ_______,gowPENDANT_,gowJ_______,gowJ_______,gowPENDANT_,gowJ_______,gowJ_______,gowPENDANT_,gowPENDANT_,gowQ_______,gowQ_______,gowPENDANT_,gowPENDANT_,gowA_______,gowA_______,gowPENDANT_,gowA_______,gowA_______,gowPENDANT_,gowQ_______,gowQ_______,gowPENDANT_,gowQ_______,gowQ_______,gowPENDANT_,gowPENDANT_,gowK_______,gowK_______,gowPENDANT_,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_,gowK_______,gowK_______,gowPENDANT_,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_,gowA_______,gowA_______,gowPENDANT_,gowPENDANT_,gowA_______",
        "gowA_______,gowJ_______,gowJ_______,gowCAISHEN_,gowK_______,gowK_______,gowTREASURE,gowTREASURE,gowQ_______,gowQ_______,gowTREASURE,gowJ_______,gowJ_______,gowTREASURE,gowJ_______,gowJ_______,gowTEMPLE__,gowJ_______,gowJ_______,gowTREASURE,gowTREASURE,gowQ_______,gowQ_______,gowTREASURE,gowTREASURE,gowA_______,gowA_______,gowTREASURE,gowA_______,gowA_______,gowTREASURE,gowTREASURE,gowQ_______,gowQ_______,gowTREASURE,gowQ_______,gowQ_______,gowTREASURE,gowK_______,gowK_______,gowTREASURE,gowK_______,gowK_______,gowTREASURE,gowTREASURE,gowK_______,gowK_______,gowTREASURE,gowA_______,gowA_______,gowTREASURE,gowA_______,gowA_______,gowTREASURE,gowTREASURE,gowJ_______,gowJ_______,gowTREASURE,gowJ_______,gowJ_______,gowTREASURE,gowTREASURE,gowQ_______,gowQ_______,gowTREASURE,gowJ_______,gowJ_______,gowTREASURE,gowJ_______,gowJ_______,gowTREASURE,gowTREASURE,gowQ_______,gowQ_______,gowTREASURE,gowTREASURE,gowA_______,gowA_______,gowTREASURE,gowA_______,gowA_______,gowTREASURE,gowQ_______,gowQ_______,gowTREASURE,gowQ_______,gowQ_______,gowTREASURE,gowTREASURE,gowK_______,gowK_______,gowTREASURE,gowK_______,gowK_______,gowTREASURE,gowTREASURE,gowK_______,gowK_______,gowTREASURE,gowK_______,gowK_______,gowTREASURE,gowTREASURE,gowA_______,gowA_______,gowTREASURE,gowTREASURE,gowA_______",
        "gowA_______,gowA_______,gowCAISHEN_,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_,gowQ_______,gowQ_______,gowCOINS___,gowCOINS___,gowJ_______,gowJ_______,gowCOINS___,gowCOINS___,gowJ_______,gowJ_______,gowTREASURE,gowK_______,gowK_______,gowVASE____,gowVASE____,gowA_______,gowA_______,gowA_______,gowORANGES_,gowORANGES_,gowQ_______,gowTEMPLE__,gowQ_______,gowQ_______,gowORANGES_,gowORANGES_,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_",
        "gowA_______,gowA_______,gowCAISHEN_,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_,gowQ_______,gowQ_______,gowCOINS___,gowCOINS___,gowJ_______,gowJ_______,gowTREASURE,gowJ_______,gowJ_______,gowCAISHEN_,gowK_______,gowK_______,gowCOINS___,gowCOINS___,gowK_______,gowK_______,gowVASE____,gowVASE____,gowA_______,gowA_______,gowA_______,gowORANGES_,gowORANGES_,gowQ_______,gowQ_______,gowTEMPLE__,gowQ_______,gowQ_______,gowORANGES_,gowORANGES_,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_",
        "gowA_______,gowA_______,gowCAISHEN_,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_,gowQ_______,gowQ_______,gowCOINS___,gowCOINS___,gowJ_______,gowJ_______,gowTREASURE,gowK_______,gowK_______,gowCAISHEN_,gowJ_______,gowJ_______,gowCOINS___,gowCOINS___,gowK_______,gowK_______,gowVASE____,gowVASE____,gowA_______,gowA_______,gowA_______,gowCOINS___,gowCOINS___,gowQ_______,gowQ_______,gowTEMPLE__,gowQ_______,gowQ_______,gowCOINS___,gowCOINS___,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_",
        "gowA_______,gowA_______,gowCAISHEN_,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_,gowQ_______,gowQ_______,gowLANTERN_,gowLANTERN_,gowJ_______,gowJ_______,gowTREASURE,gowK_______,gowK_______,gowCAISHEN_,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_,gowK_______,gowK_______,gowVASE____,gowVASE____,gowA_______,gowA_______,gowA_______,gowLANTERN_,gowLANTERN_,gowQ_______,gowQ_______,gowTEMPLE__,gowQ_______,gowQ_______,gowLANTERN_,gowLANTERN_,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_",
        "gowA_______,gowA_______,gowCAISHEN_,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_,gowQ_______,gowQ_______,gowVASE____,gowVASE____,gowJ_______,gowJ_______,gowTREASURE,gowJ_______,gowJ_______,gowCAISHEN_,gowK_______,gowK_______,gowVASE____,gowVASE____,gowK_______,gowK_______,gowVASE____,gowVASE____,gowA_______,gowA_______,gowA_______,gowVASE____,gowVASE____,gowQ_______,gowQ_______,gowTEMPLE__,gowQ_______,gowQ_______,gowVASE____,gowVASE____,gowJ_______,gowJ_______,gowVASE____,gowVASE____",
        "gowA_______,gowA_______,gowCAISHEN_,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_,gowQ_______,gowQ_______,gowPENDANT_,gowPENDANT_,gowJ_______,gowJ_______,gowTREASURE,gowK_______,gowK_______,gowCAISHEN_,gowJ_______,gowJ_______,gowPENDANT_,gowPENDANT_,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_,gowA_______,gowA_______,gowA_______,gowPENDANT_,gowPENDANT_,gowQ_______,gowQ_______,gowTEMPLE__,gowQ_______,gowQ_______,gowPENDANT_,gowPENDANT_,gowJ_______,gowJ_______,gowPENDANT_,gowPENDANT_",
        "gowA_______,gowA_______,gowCAISHEN_,gowK_______,gowK_______,gowTREASURE,gowTREASURE,gowQ_______,gowQ_______,gowTREASURE,gowTREASURE,gowJ_______,gowJ_______,gowTREASURE,gowK_______,gowK_______,gowCAISHEN_,gowJ_______,gowJ_______,gowTREASURE,gowTREASURE,gowK_______,gowK_______,gowTREASURE,gowTREASURE,gowA_______,gowA_______,gowA_______,gowTREASURE,gowTREASURE,gowQ_______,gowQ_______,gowTEMPLE__,gowQ_______,gowQ_______,gowTREASURE,gowTREASURE,gowJ_______,gowJ_______,gowTREASURE,gowTREASURE",

        "gowQ_______,gowQ_______,gowTREASURE,gowQ_______,gowQ_______,gowLANTERN_,gowLANTERN_,gowJ_______,gowJ_______,gowTEMPLE__,gowJ_______,gowJ_______,gowCOINS___,gowCOINS___,gowCOINS___,gowA_______,gowA_______,gowTEMPLE__,gowA_______,gowA_______,gowA_______,gowORANGES_,gowORANGES_,gowORANGES_,gowJ_______,gowJ_______,gowJ_______,gowVASE____,gowVASE____,gowK_______,gowK_______,gowTREASURE,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_,gowQ_______,gowQ_______,gowCOINS___,gowCOINS___,gowA_______,gowA_______,gowA_______,gowPENDANT_,gowPENDANT_,gowK_______,gowK_______,gowK_______,gowORANGES_,gowORANGES_,gowORANGES_,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_,gowQ_______,gowQ_______,gowQ_______,gowVASE____,gowVASE____",
        "gowQ_______,gowQ_______,gowTREASURE,gowQ_______,gowQ_______,gowQ_______,gowLANTERN_,gowLANTERN_,gowK_______,gowK_______,gowK_______,gowTEMPLE__,gowK_______,gowK_______,gowCOINS___,gowCOINS___,gowCOINS___,gowJ_______,gowJ_______,gowORANGES_,gowORANGES_,gowJ_______,gowJ_______,gowVASE____,gowVASE____,gowA_______,gowA_______,gowTEMPLE__,gowA_______,gowA_______,gowA_______,gowCOINS___,gowCOINS___,gowQ_______,gowQ_______,gowQ_______,gowORANGES_,gowORANGES_,gowA_______,gowA_______,gowA_______,gowPENDANT_,gowPENDANT_,gowJ_______,gowJ_______,gowVASE____,gowK_______,gowK_______,gowK_______,gowORANGES_,gowORANGES_,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_",
        "gowQ_______,gowQ_______,gowTREASURE,gowQ_______,gowQ_______,gowQ_______,gowLANTERN_,gowLANTERN_,gowK_______,gowK_______,gowK_______,gowTEMPLE__,gowK_______,gowK_______,gowCOINS___,gowCOINS___,gowCOINS___,gowJ_______,gowJ_______,gowCOINS___,gowCOINS___,gowJ_______,gowJ_______,gowVASE____,gowVASE____,gowA_______,gowA_______,gowTEMPLE__,gowA_______,gowA_______,gowA_______,gowCOINS___,gowCOINS___,gowQ_______,gowQ_______,gowQ_______,gowCOINS___,gowCOINS___,gowA_______,gowA_______,gowA_______,gowPENDANT_,gowPENDANT_,gowJ_______,gowJ_______,gowVASE____,gowK_______,gowK_______,gowK_______,gowCOINS___,gowCOINS___,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_",
        "gowQ_______,gowQ_______,gowTREASURE,gowQ_______,gowQ_______,gowQ_______,gowLANTERN_,gowLANTERN_,gowK_______,gowK_______,gowK_______,gowLANTERN_,gowLANTERN_,gowLANTERN_,gowK_______,gowK_______,gowLANTERN_,gowLANTERN_,gowJ_______,gowJ_______,gowJ_______,gowVASE____,gowVASE____,gowA_______,gowA_______,gowTEMPLE__,gowA_______,gowA_______,gowA_______,gowLANTERN_,gowLANTERN_,gowQ_______,gowQ_______,gowQ_______,gowLANTERN_,gowLANTERN_,gowA_______,gowA_______,gowA_______,gowPENDANT_,gowPENDANT_,gowJ_______,gowJ_______,gowVASE____,gowK_______,gowK_______,gowK_______,gowLANTERN_,gowLANTERN_,gowJ_______,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_",
        "gowQ_______,gowQ_______,gowTREASURE,gowQ_______,gowQ_______,gowVASE____,gowVASE____,gowK_______,gowK_______,gowPENDANT_,gowK_______,gowK_______,gowVASE____,gowJ_______,gowJ_______,gowVASE____,gowVASE____,gowQ_______,gowQ_______,gowVASE____,gowVASE____,gowA_______,gowA_______,gowTEMPLE__,gowA_______,gowA_______,gowVASE____,gowQ_______,gowQ_______,gowVASE____,gowVASE____,gowA_______,gowA_______,gowPENDANT_,gowA_______,gowA_______,gowVASE____,gowJ_______,gowJ_______,gowVASE____,gowVASE____,gowK_______,gowK_______,gowVASE____,gowK_______,gowK_______,gowVASE____,gowVASE____,gowJ_______,gowJ_______,gowVASE____,gowJ_______,gowJ_______,gowVASE____",
        "gowQ_______,gowQ_______,gowTREASURE,gowQ_______,gowQ_______,gowPENDANT_,gowPENDANT_,gowK_______,gowK_______,gowPENDANT_,gowK_______,gowK_______,gowPENDANT_,gowJ_______,gowJ_______,gowPENDANT_,gowPENDANT_,gowQ_______,gowQ_______,gowPENDANT_,gowPENDANT_,gowA_______,gowA_______,gowTEMPLE__,gowA_______,gowA_______,gowPENDANT_,gowQ_______,gowQ_______,gowPENDANT_,gowPENDANT_,gowA_______,gowA_______,gowPENDANT_,gowA_______,gowA_______,gowPENDANT_,gowJ_______,gowJ_______,gowPENDANT_,gowPENDANT_,gowK_______,gowK_______,gowPENDANT_,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_,gowJ_______,gowJ_______,gowPENDANT_,gowJ_______,gowJ_______,gowPENDANT_",
        "gowQ_______,gowQ_______,gowTREASURE,gowQ_______,gowQ_______,gowTREASURE,gowTREASURE,gowK_______,gowK_______,gowTREASURE,gowK_______,gowK_______,gowTREASURE,gowJ_______,gowJ_______,gowTREASURE,gowTREASURE,gowQ_______,gowQ_______,gowTREASURE,gowTREASURE,gowA_______,gowA_______,gowTEMPLE__,gowA_______,gowA_______,gowTREASURE,gowQ_______,gowQ_______,gowTREASURE,gowTREASURE,gowA_______,gowA_______,gowTREASURE,gowA_______,gowA_______,gowTREASURE,gowJ_______,gowJ_______,gowTREASURE,gowTREASURE,gowK_______,gowK_______,gowTREASURE,gowK_______,gowK_______,gowTREASURE,gowTREASURE,gowJ_______,gowJ_______,gowTREASURE,gowJ_______,gowJ_______,gowTREASURE",
        "gowQ_______,gowQ_______,gowTREASURE,gowQ_______,gowQ_______,gowLANTERN_,gowLANTERN_,gowJ_______,gowJ_______,gowTEMPLE__,gowJ_______,gowJ_______,gowCOINS___,gowCOINS___,gowA_______,gowA_______,gowTEMPLE__,gowA_______,gowA_______,gowCOINS___,gowCOINS___,gowA_______,gowA_______,gowPENDANT_,gowPENDANT_,gowK_______,gowK_______,gowORANGES_,gowORANGES_,gowORANGES_,gowQ_______,gowQ_______,gowLANTERN_,gowLANTERN_,gowK_______,gowK_______,gowVASE____,gowVASE____",
        "gowQ_______,gowQ_______,gowTREASURE,gowQ_______,gowQ_______,gowLANTERN_,gowLANTERN_,gowJ_______,gowJ_______,gowTEMPLE__,gowJ_______,gowJ_______,gowCOINS___,gowCOINS___,gowA_______,gowA_______,gowCOINS___,gowCOINS___,gowA_______,gowA_______,gowPENDANT_,gowPENDANT_,gowK_______,gowK_______,gowORANGES_,gowORANGES_,gowORANGES_,gowA_______,gowA_______,gowLANTERN_,gowLANTERN_,gowK_______,gowK_______,gowVASE____,gowVASE____",
        "gowQ_______,gowQ_______,gowTREASURE,gowQ_______,gowQ_______,gowLANTERN_,gowLANTERN_,gowJ_______,gowJ_______,gowTEMPLE__,gowJ_______,gowJ_______,gowCOINS___,gowCOINS___,gowA_______,gowA_______,gowCOINS___,gowCOINS___,gowA_______,gowA_______,gowPENDANT_,gowPENDANT_,gowK_______,gowK_______,gowCOINS___,gowCOINS___,gowCOINS___,gowA_______,gowA_______,gowLANTERN_,gowLANTERN_,gowK_______,gowK_______,gowVASE____,gowVASE____",
        "gowQ_______,gowQ_______,gowTREASURE,gowQ_______,gowQ_______,gowLANTERN_,gowLANTERN_,gowJ_______,gowJ_______,gowTEMPLE__,gowJ_______,gowJ_______,gowLANTERN_,gowLANTERN_,gowA_______,gowA_______,gowLANTERN_,gowLANTERN_,gowA_______,gowA_______,gowPENDANT_,gowPENDANT_,gowK_______,gowK_______,gowLANTERN_,gowLANTERN_,gowLANTERN_,gowA_______,gowA_______,gowLANTERN_,gowLANTERN_,gowK_______,gowK_______,gowVASE____,gowVASE____",
        "gowQ_______,gowQ_______,gowTREASURE,gowQ_______,gowQ_______,gowVASE____,gowVASE____,gowJ_______,gowJ_______,gowTEMPLE__,gowJ_______,gowJ_______,gowVASE____,gowVASE____,gowA_______,gowA_______,gowVASE____,gowVASE____,gowA_______,gowA_______,gowPENDANT_,gowPENDANT_,gowK_______,gowK_______,gowVASE____,gowVASE____,gowVASE____,gowA_______,gowA_______,gowVASE____,gowVASE____,gowK_______,gowK_______,gowVASE____,gowVASE____",
        "gowQ_______,gowQ_______,gowTREASURE,gowQ_______,gowQ_______,gowPENDANT_,gowPENDANT_,gowJ_______,gowJ_______,gowTEMPLE__,gowJ_______,gowJ_______,gowPENDANT_,gowPENDANT_,gowA_______,gowA_______,gowPENDANT_,gowPENDANT_,gowA_______,gowA_______,gowPENDANT_,gowPENDANT_,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_,gowPENDANT_,gowA_______,gowA_______,gowPENDANT_,gowPENDANT_,gowK_______,gowK_______,gowPENDANT_,gowPENDANT_",
        "gowQ_______,gowQ_______,gowTREASURE,gowQ_______,gowQ_______,gowTREASURE,gowTREASURE,gowJ_______,gowJ_______,gowTEMPLE__,gowJ_______,gowJ_______,gowTREASURE,gowTREASURE,gowA_______,gowA_______,gowTREASURE,gowTREASURE,gowA_______,gowA_______,gowTREASURE,gowTREASURE,gowK_______,gowK_______,gowTREASURE,gowTREASURE,gowTREASURE,gowA_______,gowA_______,gowTREASURE,gowTREASURE,gowK_______,gowK_______,gowTREASURE,gowTREASURE",
    };

    for (int i = 0; i < m_vecReelStripPlan.size(); i++) {
        ReelSet set;
        for (int j = 0; j < m_nReel; j++) {
            ReelStrip strip;
            std::stringstream ss(gowReelStrip[j * m_vecReelStripPlan.size() + i]);
            std::string item;
            while (std::getline(ss, item, ',')) {
                strip.push_back(item);
            }
            set.push_back(strip);
        }
        m_vecReelStripSets.push_back(set);
    }

    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_05_tmp;
    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_10_tmp;
    for (int i = 0; i < m_vecBetSteps_05_tmp.size(); i++) {
        std::map<std::string, std::map<UINT8, BONUS>> perSym;
        std::map<UINT8, BONUS> e;
        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[5].ag = 0;
        perSym["gowJ_______"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[5].ag = 0;
        perSym["gowQ_______"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[5].ag = 0;
        perSym["gowK_______"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[5].ag = 0;
        perSym["gowA_______"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 50; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 200; e[5].ag = 0;
        perSym["gowORANGES_"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 50; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 200; e[5].ag = 0;
        perSym["gowCOINS___"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 250; e[5].ag = 0;
        perSym["gowLANTERN_"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 125; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 300; e[5].ag = 0;
        perSym["gowVASE____"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 50; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 200; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 400; e[5].ag = 0;
        perSym["gowPENDANT_"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 250; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 500; e[5].ag = 0;
        perSym["gowTREASURE"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 250; e[5].ag = 0;
        perSym["gowTEMPLE__"] = e;
        e.clear();

        m_Bonus_05_tmp[i] = perSym;
    }
    m_Bonus_05_tmp[10]["gowTREASURE"][5].coin = 0; m_Bonus_05_tmp[10]["gowTREASURE"][5].ag = 10;    //100
    m_Bonus_05_tmp[11]["gowTREASURE"][5].coin = 0; m_Bonus_05_tmp[11]["gowTREASURE"][5].ag = 20;    //200
    m_Bonus_05_tmp[11]["gowTREASURE"][4].coin = 0; m_Bonus_05_tmp[11]["gowTREASURE"][4].ag = 10;
    m_Bonus_05_tmp[11]["gowTEMPLE__"][5].coin = 0; m_Bonus_05_tmp[11]["gowTEMPLE__"][5].ag = 10;
    m_Bonus_05_tmp[11]["gowPENDANT_"][5].coin = 0; m_Bonus_05_tmp[11]["gowPENDANT_"][5].ag = 16;
    m_Bonus_05_tmp[11]["gowVASE____"][5].coin = 0; m_Bonus_05_tmp[11]["gowVASE____"][5].ag = 12;
    m_Bonus_05_tmp[11]["gowLANTERN_"][5].coin = 0; m_Bonus_05_tmp[11]["gowLANTERN_"][5].ag = 10;
    m_Bonus_05_tmp[12]["gowTREASURE"][5].coin = 0; m_Bonus_05_tmp[12]["gowTREASURE"][5].ag = 50;    //500
    m_Bonus_05_tmp[12]["gowTREASURE"][4].coin = 0; m_Bonus_05_tmp[12]["gowTREASURE"][4].ag = 25;
    m_Bonus_05_tmp[12]["gowTREASURE"][3].coin = 0; m_Bonus_05_tmp[12]["gowTREASURE"][3].ag = 10;
    m_Bonus_05_tmp[12]["gowTEMPLE__"][5].coin = 0; m_Bonus_05_tmp[12]["gowTEMPLE__"][5].ag = 25;
    m_Bonus_05_tmp[12]["gowTEMPLE__"][4].coin = 0; m_Bonus_05_tmp[12]["gowTEMPLE__"][4].ag = 10;
    m_Bonus_05_tmp[12]["gowPENDANT_"][5].coin = 0; m_Bonus_05_tmp[12]["gowPENDANT_"][5].ag = 40;
    m_Bonus_05_tmp[12]["gowPENDANT_"][4].coin = 0; m_Bonus_05_tmp[12]["gowPENDANT_"][4].ag = 20;
    m_Bonus_05_tmp[12]["gowVASE____"][5].coin = 0; m_Bonus_05_tmp[12]["gowVASE____"][5].ag = 30;
    m_Bonus_05_tmp[12]["gowVASE____"][4].coin = 500; m_Bonus_05_tmp[12]["gowVASE____"][4].ag = 12;
    m_Bonus_05_tmp[12]["gowLANTERN_"][5].coin = 0; m_Bonus_05_tmp[12]["gowLANTERN_"][5].ag = 25;
    m_Bonus_05_tmp[12]["gowLANTERN_"][4].coin = 0; m_Bonus_05_tmp[12]["gowLANTERN_"][4].ag = 10;
    m_Bonus_05_tmp[12]["gowCOINS___"][5].coin = 0; m_Bonus_05_tmp[12]["gowCOINS___"][5].ag = 20;
    m_Bonus_05_tmp[12]["gowORANGES_"][5].coin = 0; m_Bonus_05_tmp[12]["gowORANGES_"][5].ag = 20;
    m_Bonus_05_tmp[12]["gowJ_______"][5].coin = 0; m_Bonus_05_tmp[12]["gowJ_______"][5].ag = 10;
    m_Bonus_05_tmp[12]["gowQ_______"][5].coin = 0; m_Bonus_05_tmp[12]["gowQ_______"][5].ag = 10;
    m_Bonus_05_tmp[12]["gowK_______"][5].coin = 0; m_Bonus_05_tmp[12]["gowK_______"][5].ag = 10;
    m_Bonus_05_tmp[12]["gowA_______"][5].coin = 0; m_Bonus_05_tmp[12]["gowA_______"][5].ag = 10;

    m_Bonus_10_tmp = m_Bonus_05_tmp;
    for (int i = 0; i < m_vecBetSteps_10_tmp.size(); i++) {
        m_Bonus_10_tmp[i]["gowTEMPLE__"][3].coin *= 2;
        m_Bonus_10_tmp[i]["gowTEMPLE__"][4].coin *= 2;
        m_Bonus_10_tmp[i]["gowTEMPLE__"][5].coin *= 2;
    }
    m_Bonus_10_tmp[10]["gowTEMPLE__"][5].coin = 0; m_Bonus_10_tmp[10]["gowTEMPLE__"][5].ag = 10;
    m_Bonus_10_tmp[11]["gowTEMPLE__"][5].coin = 0; m_Bonus_10_tmp[11]["gowTEMPLE__"][5].ag = 20;
    m_Bonus_10_tmp[12]["gowTEMPLE__"][5].coin = 0; m_Bonus_10_tmp[12]["gowTEMPLE__"][5].ag = 50;
    m_Bonus_10_tmp[12]["gowTEMPLE__"][4].coin = 0; m_Bonus_10_tmp[12]["gowTEMPLE__"][4].ag = 20;
    

    int nSavedBetVal = 10;
    string data;
    PlayDB::GetInstance().LoadCheckPoint(m_strGameName, nSavedBetVal, m_nWinLine, m_strCheckPoint);
    if (nSavedBetVal == -1) {
        nSavedBetVal = 10;
    }
    if (m_nWinLine == -1) {
        m_nWinLine = 5;
    }

    BOOL start = FALSE;
    int idx = 0;
    for (int i = 0; i < m_vecBetSteps_05_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_05_tmp, i) < AT(m_vecBetSteps_05, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps_05, idx) == nSavedBetVal && m_nWinLine == 5) {
            m_nBetStep = idx;
        }

        m_Bonus_05[idx++] = m_Bonus_05_tmp[i];
        if (AT(m_vecBetSteps_05_tmp, i) == AT(m_vecBetSteps_05, m_vecBetSteps_05.size() - 1)) {
            break;
        }
    }
    start = FALSE;
    idx = 0;
    for (int i = 0; i < m_vecBetSteps_10_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_10_tmp, i) < AT(m_vecBetSteps_10, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps_10, idx) == nSavedBetVal && m_nWinLine == 10) {
            m_nBetStep = idx;
        }

        m_Bonus_10[idx++] = m_Bonus_10_tmp[i];
        if (AT(m_vecBetSteps_10_tmp, i) == AT(m_vecBetSteps_10, m_vecBetSteps_10.size() - 1)) {
            break;
        }
    }

    m_Bonus = (m_nWinLine == 5 ? m_Bonus_05 : m_Bonus_10);
    m_vecBetSteps = (m_nWinLine == 5 ? m_vecBetSteps_05 : m_vecBetSteps_10);
    PrintAllBonus();
}

UINT16 RgGongHei::Run() {
    m_nCurrentReelPlan = myRandom() % 2;
    m_shCurrentReelStrip = static_cast<uint16_t>(std::stoi(AT(m_vecReelStripPlan, m_nCurrentReelPlan)));
    return m_shCurrentReelStrip;
}

void RgGongHei::ChangeReelStrip(UINT16 NewReelPlan) {
    m_nCurrentReelPlan = NewReelPlan;
    m_shCurrentReelStrip = static_cast<uint16_t>(std::stoi(AT(m_vecReelStripPlan, m_nCurrentReelPlan)));
}

myVector<UINT8> RgGongHei::Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) {
    m_nMagicCount = 0;
    m_bPrevSpinMatchedActive = FALSE;
    myVector<UINT8> result;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);

    if (bTest) {
        std::string matchSymbol = AT(m_vecSymbols, myRandom() % (m_vecSymbols.size() - 2));
        int line = (myRandom() % m_nWinLine);
        int weight = 1 + (myRandom() % 5);

        BOOL bForceFree = (myRandom() % 10 == 0);
        for (int i = 0; i < m_nReel; i++) {
            ReelStrip reelStrip = AT(reelSet, i);
            int len = reelStrip.size() - 3;

            int valid_i[0x100];
            int valid_count = 0;
            myVector<int> freeSymbols;
            for (int j = 0; j <= len; j++) {
                if (weight > i) {
                    if (matchSymbol == AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                else {
                    if (matchSymbol != AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                if (AT(reelStrip, j) == RgGongHei_scatter && m_bFreeMode == FALSE) {
                    freeSymbols.push_back(j);
                }
            }
            if (valid_count > 0) {
                int rand_index = myRandom() % valid_count;
                int chosen_i = valid_i[rand_index];
                result.push_back(chosen_i + 1);
            }
            else {
                result.push_back((myRandom() % (len - 1)) + 1);
            }
            {
                int pool[5] = { 0, 1, 2, 3, 4 };
                auto v = pickRandom2or3(pool, 5, 3);
                if (bForceFree && m_bFreeMode == FALSE && freeSymbols.size() > 0 && std::find(v.begin(), v.end(), i) != v.end()) {
                    AT(result, result.size() - 1) =
                        AT(freeSymbols, myRandom() % freeSymbols.size()) - (myRandom() % 3) + 1;
                }
            }
        }
    }
    else {
        result = _result;

        BOOL mmcode = mmcode_get_active_status();
        if (mmcode) {
            mmcode_set_deactive();
            if (m_bFreeMode == FALSE) {
                for (int j = 0; j < 5; j ++) {
                    myVector<int> candidateIndices;
                    for (int i = 2; i < AT(reelSet, j).size() - 3; ++i) {
                        if (j%2 == 0 && AT(AT(reelSet, j), i) == RgGongHei_scatter) {
                            int offset = myRandom() % 3;
                            int selectedIndex = i - 2 + offset;
                            candidateIndices.push_back(selectedIndex);
                        }
                        if (j%2 == 1 && AT(AT(reelSet, j), i) != RgGongHei_scatter
                                    && AT(AT(reelSet, j), i-2) != RgGongHei_scatter
                                    && AT(AT(reelSet, j), i-1) != RgGongHei_scatter
                                    && AT(AT(reelSet, j), i+1) != RgGongHei_scatter
                                    && AT(AT(reelSet, j), i+2) != RgGongHei_scatter) {
                            int offset = myRandom() % 3;
                            int selectedIndex = i - 2 + offset;
                            candidateIndices.push_back(selectedIndex);
                        }
                    }
                    if (!candidateIndices.empty()) {
#ifdef BIGBET_ACTIVE
                        int chosenIndex = AT(candidateIndices, (candidateIndices.size()<3?myRandom() % candidateIndices.size():myRandom() % 3));
#else
                        int chosenIndex = AT(candidateIndices, myRandom() % candidateIndices.size());
#endif
                        AT(result, j) = chosenIndex + 1;
                    }
                }
            }
        }
    }

    m_vWinResult = result;

    normalMeter = 0;
    maxMeter = 0;
    BONUS totalBonus = {0, 0};
    int maxTempleMatchCount = 0;
    int Temple5Matched = 0;
    for (int i = 0; i < m_nWinLine; i++) {
        int j = 1;
        UINT16 meter = ((UINT16)1 << (2 - g_match_lines_10_5[i][0]));
        std::string firstSymbol = AT(AT(reelSet, 0), AT(result, 0) - 1 + g_match_lines_10_5[i][0]);
        maxTempleMatchCount = 0;

        for (; j < m_nMaxMatch; j++) {
            std::string prev_symbol = AT(AT(reelSet, j - 1), AT(result, j - 1) - 1 + g_match_lines_10_5[i][j - 1]);
            std::string cur_symbol = AT(AT(reelSet, j), AT(result, j) - 1 + g_match_lines_10_5[i][j]);

            if (WildcountInCol(j, result)) {
                meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
                continue;
            }
            if (firstSymbol == RgGongHei_wild) {
                firstSymbol = cur_symbol;
            }
            if (firstSymbol == cur_symbol) {
                meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
                continue;
            }
            break;
        }
        if (j < m_mapSymbolMinMatch[firstSymbol] || m_mapSymbolMinMatch[firstSymbol] == 0) {
            continue;
        }
        if (firstSymbol == RgGongHei_scatter) {
            Temple5Matched = 1;
        }
        // monitor 2 meter
        std::string meterStr = m_mapSymbolMeterGoc[firstSymbol];
        size_t pos = meterStr.find('$');
        if (pos != std::string::npos) {
            meterStr = meterStr.replace(pos, 1, std::to_string(j));
        }

        WinMeter e;
        e.line = i;
        e.meter = meter;
        e.meter2 = g_GrafficObjList.Str2GOCID(meterStr);
        e.symbol = firstSymbol;
        e.weight = j;
        e.start = 0;
        e.bonus = m_Bonus[BetStep()][firstSymbol][j];
        e.sound = MAX_SOUND_IDS;

        totalBonus.coin += e.bonus.coin;
        totalBonus.ag += e.bonus.ag;

        if (e.meter2 != -1) {
            meters.push_back(e);
        }
        if (j == m_nMaxMatch) {
            maxMeter |= meter;
        }
        else {
            normalMeter |= meter;
        }

        if (bTest == FALSE) {
            m_bPrevSpinMatchedActive = TRUE;
        }
    }

    int nTemple = CardCount(RgGongHei_scatter);
    if (nTemple >= 3) {
        bCanFreeMode = TRUE;

        // not match Temple 5, and Temple match contains other match
        if (Temple5Matched == 0 && maxTempleMatchCount < nTemple) {
            UINT16 meter = 0;
            for (int i = 0; i < 3; i++) {
                for (int col = 0; col < m_nReel; col++) {
                    std::string cur_symbol = AT(AT(reelSet, col), AT(result, col) - 1 + i);
                    if (cur_symbol == RgGongHei_scatter) {
                        meter |= ((UINT16)1 << (3 * col + (2 - i)));
                    }
                }
            }
            WinMeter e;
            e.line = 10;
            e.meter = meter;
            e.meter2 = g_GrafficObjList.Str2GOCID("gowTemple" + std::to_string(nTemple) + "x");
            e.symbol = RgGongHei_scatter;
            e.weight = nTemple;
            e.start = 0;
            e.bonus = m_Bonus[BetStep()][RgGongHei_scatter][nTemple];
            e.sound = MAX_SOUND_IDS;

            normalMeter |= meter;
            totalBonus.coin += e.bonus.coin;
            totalBonus.ag += e.bonus.ag;

            meters.push_back(e);
            if (bTest == FALSE) {
                m_bPrevSpinMatchedActive = TRUE;
            }
        }
    }
    m_vWinMeters = meters;
    m_nMagicCount = totalBonus.ag;
    if (bTest == FALSE) {
        updateCheckPoint();

        if (totalBonus.coin > 0 || totalBonus.ag > 0) {
            if (m_bFreeMode) {
                m_nFreeModeTotalBonus.coin += totalBonus.coin;
                m_nFreeModeTotalBonus.ag += totalBonus.ag;
            }
            BonusSound = getSoundByID(WinSound(totalBonus.coin + totalBonus.ag * 1000));
        }
    }
    return result;
}

BOOL RgGongHei::WildcountInCol(UINT8 col, myVector<UINT8> result) {
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    // check wild symbol
    int k = 0;
    for (; k < 3; k++) {
        std::string s = AT(AT(reelSet, col), AT(result, col) - 1 + k);
        if (s == RgGongHei_wild) {
            return TRUE;
        }
    }
    return FALSE;
}

UINT8 RgGongHei::Wildcount() {
    UINT8 n = 0;
    for (int i = 0; i < m_nReel; i++) {
        if (WildcountInCol(i, m_vWinResult)) {
            n++;
        }
    }
    return n;
}

UINT8 RgGongHei::ScatterCount() {
    return CardCount(RgGongHei_scatter);
}


UINT8 RgGongHei::CardCount(std::string card) {
    int n = 0;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int col = 0; col < m_nReel; col++) {
        if (WildcountInCol(col, m_vWinResult)) {
            continue;
        }
        int k = 0;
        for (; k < 3; k++) {
            std::string s = AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k);
            if (s == card) {
                n++;
            }
        }
    }
    return n;
}

UINT8 RgGongHei::NumberOfScatter(myVector<UINT8> result) {
    UINT8 n = 0;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int col = 0; col < m_nReel; col++) {
        int k = 0;
        for (; k < 3; k++) {
            std::string s = AT(AT(reelSet, col), AT(result, col) - 1 + k);
            if (s == RgGongHei_scatter) {
                n++;
            }
        }
    }
    return n;
}

UINT16 RgGongHei::SpinTime_MS() {
    if (CardCount(RgGongHei_scatter) >= 3) {
        return 4500;
    }
    if (CardCount(RgGongHei_scatter) == 2 && TempleInCol(4) == FALSE) {
        return 4500;
    }
    return 2200;
}

BOOL RgGongHei::TempleInCol(int col) {
    return CardNumInCol(col, RgGongHei_scatter);
}

UINT8 RgGongHei::CardNumInCol(int col, std::string card) {
    int n = 0;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int k = 0; k < 3; k++) {
        std::string s = AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k);
        if (s == card) {
            n++;
        }
    }
    return n;
}

BOOL RgGongHei::CanFreeMode() {
    if (CardCount(RgGongHei_scatter) >= 3) {
        return TRUE;
    }
    return FALSE;
}

myVector<InterruptPacketData> RgGongHei::InterruptBeforeSpin() {
    myVector<InterruptPacketData> packets;
    if (!m_bFreeMode) {
        return packets;
    }
    m_nFreeModeGoneSpin++;
    updateCheckPoint();

    UINT8 gone = (m_nFreeModeGoneSpin ? m_nFreeModeGoneSpin : 1);

    // display total & remain free spin count
    packets.push_back({
        0,
        0,
        {
            0x01, 0x02, 0x30, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), gone, 0x00, m_nFreeModeTotalSpin, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa5, 0x04
        }
        });
    return packets;
}

myVector<InterruptPacketData> RgGongHei::InterruptAfterMoveBonus(BOOL& EndFree) {
    UINT8 nWildCnt = Wildcount();
    UINT8 nScatterCnt = ScatterCount();

    UINT8 plusCnt = 0;
    if (nWildCnt > 0) {
        plusCnt = 1;
    }
    if (nScatterCnt >= 3) {
        plusCnt += 12;
    }
    m_nFreeModeTotalSpin += plusCnt;

    myVector<InterruptPacketData> packets;
    if (m_nFreeModeGoneSpin >= m_nFreeModeTotalSpin) {
        EndFree = TRUE;
        m_bFreeMode = FALSE;
        ChangeReelStrip(myRandom() % 2);
        packets.push_back({
            0,
            0,
            {0x01, 0x02, 0x30, 0x00, 0xd7, 0x24, 0x00, 0x00, 
            static_cast<BYTE>(m_nFreeModeTotalBonus.coin & 0xFF), 
            static_cast<BYTE>((m_nFreeModeTotalBonus.coin >> 8) & 0xFF), 
            static_cast<BYTE>((m_nFreeModeTotalBonus.coin >> 16) & 0xFF),
            static_cast<BYTE>((m_nFreeModeTotalBonus.coin >> 24) & 0xFF),            
            0x10, 0x00, 0xab, 0x04} });        
        packets.push_back({
            0,
            0,
            {0x01, 0x02, 0x30, 0x00, 0xd7, 0x24, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa4, 0x04} });
        packets.push_back({
            0,
            2000,
            {0x01, 0x02, 0x31, 0x00, 0x0a, 0x00, 0x25, 0x53, 0x11, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04, 0x03, 0x00, 0x04} });

        updateCheckPoint();
        return packets;
    }
    EndFree = FALSE;

    UINT8 nConvertable = GOW_convert_sorting.size() - m_nConvertedInFreeMode;
    UINT8 c = min(nConvertable, nWildCnt);

    if (plusCnt > 0) {
        UINT32 delay = 2000;
        if (nScatterCnt >= 3) {
            delay = 7500;
        }
        // show 1 more freespin
        packets.push_back({
            0,
            delay,
            {0x06, 0xd7, 0x24, 0x01, 0x02, 0x30, 0x00, 0xd7, 0x24, plusCnt, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa6, 0x04} });
    }
    if (c > 0) {
        UINT16 convertingDelay = c * 6000;
        for (int i = 0; i < c; i++) {
            if (CardCount(AT(GOW_convert_sorting, m_nConvertedInFreeMode + i)) > 0) {
                convertingDelay += 3000;
            }            
        }
        if ((m_nConvertedInFreeMode + c) >= GOW_convert_sorting.size()) {
            convertingDelay += 3000;
        }
        // convert -->       
        packets.push_back({
            0,
            0,
            {0x01, 0x02, 0x31, 0x00, 0x02, 0x00, 0xd0, 0x58, 0x06, 0x00, 0x01, 0x04} });
        packets.push_back({
            0,
            0,
            {0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0xd7, 0x24, 0x02, 0x00, 0x04} });
        packets.push_back({
            0,
            convertingDelay,
            {0x01, 0x02, 0x28, 0x00, 0xd7, 0x24, 0x01, 0x00, 0x00, 0x00, 0x04} });
        // <-- convert

        m_nConvertedInFreeMode += c;
        // change reelstrip to avoid converted symbol
        ChangeReelStrip(8 + m_nConvertedInFreeMode);        
    }

    //m_nFreeModeGoneSpin++;
    updateCheckPoint();

    return packets;
}

myVector<InterruptPacketData> RgGongHei::EnterFreeGame(std::string check) {
    m_bFreeMode = TRUE;
    m_nFreeModeTotalSpin = 12;
    m_nFreeModeGoneSpin = 0;
    m_nFreeModeTotalBonus = {0, 0};
    m_nConvertedInFreeMode = 0;

    myVector<InterruptPacketData> packets;
    if (check != "") {
        myVector<int> values = ParseCheckPoint(check, "F", 5);
        if (values.size() == 5) {
            m_nConvertedInFreeMode = AT(values, 0);
            m_nFreeModeTotalSpin = AT(values, 1);
            m_nFreeModeGoneSpin = AT(values, 2);
            m_nFreeModeTotalBonus.coin = AT(values, 3);
            m_nFreeModeTotalBonus.ag = AT(values, 4);

            UINT8 gone = (m_nFreeModeGoneSpin ? m_nFreeModeGoneSpin : 1);
            packets.push_back({
                0,
                0,
                {0x01, 0x02, 0x30, 0x00, 0xd7, 0x24, gone, 0x00, m_nFreeModeTotalSpin, 0x00, m_nConvertedInFreeMode, 0x00, 0x00, 0x00, 0xa3, 0x04} });
            return packets;
        }
    }
    else {
        updateCheckPoint();
    }
    packets.push_back({
        0,
        6000,{0x01, 0x02, 0x30, 0x00, 0xd7, 0x24, 0x0c, 0x00, 0x01, 0x00, 0x0c, 0x00, 0x0c, 0x00, 0xa6, 0x04} });
    return packets;
}

int RgGongHei::LineSwapDelay(int WinIdx) {
    return 500;
}

UINT16 RgGongHei::MagicCount() {
    if (m_bFreeMode) {
        return 0;
    }
    else {
        return m_nMagicCount;
    }
}

myVector<InterruptPacketData> RgGongHei::MousePressed(MousePosition p) {
    myVector<InterruptPacketData> packets;

    MousePosition a{
       {RgGongHei_MP_ChangeLine_LB_x_reel, RgGongHei_MP_ChangeLine_LB_x_pos },
       {RgGongHei_MP_ChangeLine_LB_y_row, RgGongHei_MP_ChangeLine_LB_y_pos }
    };
    MousePosition b{
        {RgGongHei_MP_ChangeLine_RT_x_reel, RgGongHei_MP_ChangeLine_RT_x_pos },
        {RgGongHei_MP_ChangeLine_RT_y_row, RgGongHei_MP_ChangeLine_RT_y_pos }
    };
    if (IsMouseWithin(p, a, b)) {
        m_nWinLine = (m_nWinLine == 5) ? 10 : 5;
        if (m_bPrevSpinMatchedActive) {
            // hide win lines
            packets.push_back({ 0, 0, {0x01, 0x02, 0x31, 0x00, 0x01, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x02, 0x00, 0x04} });
            m_bPrevSpinMatchedActive = FALSE;
        }
        UINT16 newBetValue = 0;
        if (m_nWinLine == 5) {
            m_Bonus = m_Bonus_05;
            m_vecBetSteps = m_vecBetSteps_05;
            newBetValue = AT(m_vecBetSteps_10, m_nBetStep) / 2;
            // lines
            packets.push_back({ 0, 0, {0x01, 0x02, 0x31, 0x00, 0x04, 0x00,
                static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x9d, 0x1f, 0x00, 0x00, 0x00, 0x04} });
        }
        else {
            m_Bonus = m_Bonus_10;
            m_vecBetSteps = m_vecBetSteps_10;
            newBetValue = AT(m_vecBetSteps_05, m_nBetStep) * 2;
            // lines
            packets.push_back({ 0, 0, {0x01, 0x02, 0x31, 0x00, 0x04, 0x00, static_cast<BYTE>(m_nGameID & 0xFF),
                static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x9d, 0xff, 0x03, 0x00, 0x00, 0x04} });
        }
        BOOL flag = FALSE;
        for (int i = 0; i < m_vecBetSteps.size(); i++) {
            if (AT(m_vecBetSteps, i) == newBetValue) {
                m_nBetStep = i;
                flag = TRUE;
                break;
            }
        }
        if (flag == FALSE) {
            m_nBetStep = 0;
        }
        // play button sound
        packets.push_back({ 0, 0, {0x01, 0x02, 0x34, 0x00, 0xf7, 0x00, 0x04} });
        // change line button
        packets.push_back({ 0, 0, {0x01, 0x02, 0x28, 0x00,
            static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), static_cast<BYTE>(m_nWinLine), 0x00, 0x00, 0x00, 0x04} });
        // set bet
        UINT16 bet = AT(m_vecBetSteps, m_nBetStep) / 5;
        packets.push_back({ 0, 0, {0x01, 0x02, 0x30, 0x00, 0x25, 0x53, 
            static_cast<BYTE>(bet & 0xFF), static_cast<BYTE>((bet >> 8) & 0xFF),  
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04, 0x04} });
    }
    return packets;
}

myVector<UINT8> RgGongHei::ShowTotalWinLines(myVector<WinMeter> SpinMeters) {
    myVector<uint8_t> packet = {
        0x06, 0x30, 0x59, 0x01, 0x02, 0x31, 0x00,
        0x0F, 0x00,  // Placeholder for length 
        0x0F, 0x11, // GameID
        0x9C, 0x19, 0x01
    };
    myVector<UINT8> TotalMatch;
    for (int i = 0; i < SpinMeters.size(); i++) {
        if (AT(SpinMeters, i).line == 0xFF) { // clear after convert action
            TotalMatch.clear();
            continue;
        }
        TotalMatch.push_back(AT(SpinMeters, i).line);
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter >> 8) & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter2 & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter2 >> 8) & 0xFF));
    }
    if (TotalMatch.size() < 10) {
        myVector<UINT8> _;
        return _;
    }
    UINT16 pktLen = 1 + (TotalMatch.size() / 5) * 7;
    AT(packet, 7) = static_cast<BYTE>(pktLen & 0xFF);
    AT(packet, 8) = static_cast<BYTE>((pktLen >> 8) & 0xFF);
    AT(packet, 9) = static_cast<BYTE>(m_nGameID & 0xFF);
    AT(packet, 10) = static_cast<BYTE>((m_nGameID >> 8) & 0xFF);
    int entryCount = static_cast<int>(TotalMatch.size() / 5);
    for (int i = 0; i < entryCount; ++i) {
        packet.push_back(AT(TotalMatch, i * 5 + 0)); // Line
        packet.push_back(AT(TotalMatch, i * 5 + 1)); // Meter low byte
        packet.push_back(AT(TotalMatch, i * 5 + 2)); // Meter high byte
        packet.push_back(AT(TotalMatch, i * 5 + 3)); // Meter2 low byte
        packet.push_back(AT(TotalMatch, i * 5 + 4)); // Meter2 high byte
        packet.push_back(0x01);      // Status or flag 1
        packet.push_back(0x01);      // Status or flag 2
    }
    // Mark the end of the packet
    packet.back() = 0x04;
    return packet;
}

BOOL RgGongHei::SelectedableReelsInFreeGame(myVector<UINT8> result) {

    if (m_bFreeMode == FALSE) {
        return TRUE;
    }

    //in 25%, discard wild symbol
    if (myRandom() % 100 < 25)
    {
        UINT8 n = 0;
        for (int i = 0; i < m_nReel; i++) {
            if (WildcountInCol(i, result)) {
                n++;
            }
        }

        if (n != 0)
            return FALSE;
    }

    myVector<UINT8> cp = m_vWinResult;
    m_vWinResult = result;
    int n = CardCount(RgGongHei_scatter);
    m_vWinResult = cp;
    if (n >= 3) {
        return FALSE;
    }
    return TRUE;
}

BOOL RgGongHei::NoFunInFreeMode() {
    return TRUE;
}

void RgGongHei::updateCheckPoint() {
    std::ostringstream oss;
    oss << " P" << m_nCurrentReelPlan
        << " B"
        << static_cast<int>(AT(m_vWinResult, 0)) << ":"
        << static_cast<int>(AT(m_vWinResult, 1)) << ":"
        << static_cast<int>(AT(m_vWinResult, 2)) << ":"
        << static_cast<int>(AT(m_vWinResult, 3)) << ":"
        << static_cast<int>(AT(m_vWinResult, 4)) << " ";

    if (m_bFreeMode) {
        oss << " F"
            << static_cast<int>(m_nConvertedInFreeMode) << ":"
            << static_cast<int>(m_nFreeModeTotalSpin) << ":"
            << static_cast<int>(m_nFreeModeGoneSpin) << ":"
            << static_cast<int>(m_nFreeModeTotalBonus.coin) << ":"
            << static_cast<int>(m_nFreeModeTotalBonus.ag) << " ";
    }
    m_strCheckPoint = oss.str();
}