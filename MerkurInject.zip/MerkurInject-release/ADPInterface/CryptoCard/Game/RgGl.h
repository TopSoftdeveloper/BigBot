#pragma once

#include "ReelGame.h"

class RgGl : public ReelGame
{
public:
	myVector<WinMeter> m_vWinMeters;

	RgGl::RgGl();
	BOOL WildcountInCol(UINT8 col, myVector<UINT8> result);

	UINT8 Wildcount() override;
	UINT16 Run() override;
	myVector<UINT8> Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& WinSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) override;
	myVector<InterruptPacketData> InterruptAfterSpin() override;
	UINT16 SpinTime_MS() override;
	int LineSwapDelay(int WinIdx) override;
	myVector<UINT8> ShowTotalWinLines(myVector<WinMeter> SpinMeters) override;
};
