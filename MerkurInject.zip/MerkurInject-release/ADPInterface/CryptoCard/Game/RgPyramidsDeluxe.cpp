#include "stdafx.h"
#include "RgPyramidsDeluxe.h"

#define RgPyramidsDeluxe_MP_ChangeLine_LB_x_reel   0x03
#define RgPyramidsDeluxe_MP_ChangeLine_LB_x_pos    0x13
#define RgPyramidsDeluxe_MP_ChangeLine_LB_y_row    0x02
#define RgPyramidsDeluxe_MP_ChangeLine_LB_y_pos    0x18
#define RgPyramidsDeluxe_MP_ChangeLine_RT_x_reel   0x03
#define RgPyramidsDeluxe_MP_ChangeLine_RT_x_pos    0x4E
#define RgPyramidsDeluxe_MP_ChangeLine_RT_y_row    0x02
#define RgPyramidsDeluxe_MP_ChangeLine_RT_y_pos    0x52

#define RgPyramidsDeluxe_wild       "PYR_SPHINX__"
#define RgPyramidsDeluxe_pyramid    "PYR_PYRAMID_"
#define RgPyramidsDeluxe_f_pyramid  "PYR_FPYRAMID"

RgPyramidsDeluxe::RgPyramidsDeluxe() {
    m_nReel = 5;
    m_nWinLine = 5;
    m_nMaxMatch = 5;
    m_nBetStep = 0;

    m_strGameName = "RgPyramidsDeluxe";

    m_bFreeMode = FALSE;

    myVector<UINT16> m_vecBetSteps_05_tmp;
    myVector<UINT16> m_vecBetSteps_10_tmp;

    m_vecBetSteps_05_tmp.push_back(5);
    m_vecBetSteps_05_tmp.push_back(10);
    m_vecBetSteps_05_tmp.push_back(15);
    m_vecBetSteps_05_tmp.push_back(20);
    m_vecBetSteps_05_tmp.push_back(25);
    m_vecBetSteps_05_tmp.push_back(30);
    m_vecBetSteps_05_tmp.push_back(40);
    m_vecBetSteps_05_tmp.push_back(50);
    m_vecBetSteps_05_tmp.push_back(60);
    m_vecBetSteps_05_tmp.push_back(80);
    m_vecBetSteps_05_tmp.push_back(100);

    m_vecBetSteps_10_tmp.push_back(10);
    m_vecBetSteps_10_tmp.push_back(20);
    m_vecBetSteps_10_tmp.push_back(30);
    m_vecBetSteps_10_tmp.push_back(40);
    m_vecBetSteps_10_tmp.push_back(50);
    m_vecBetSteps_10_tmp.push_back(60);
    m_vecBetSteps_10_tmp.push_back(80);
    m_vecBetSteps_10_tmp.push_back(100);
    m_vecBetSteps_10_tmp.push_back(120);
    m_vecBetSteps_10_tmp.push_back(160);
    m_vecBetSteps_10_tmp.push_back(200);
#ifdef BIGBET_ACTIVE
    m_vecBetSteps_05_tmp.push_back(200);
    m_vecBetSteps_05_tmp.push_back(500);
    m_vecBetSteps_10_tmp.push_back(400);
    m_vecBetSteps_10_tmp.push_back(1000);
#endif
    LoadBets();
    m_vecBetSteps = m_vecBetSteps_05;

    m_vecSymbols.push_back("PYR_TEN_____");
    m_vecSymbols.push_back("PYR_J_______");
    m_vecSymbols.push_back("PYR_Q_______");
    m_vecSymbols.push_back("PYR_K_______");
    m_vecSymbols.push_back("PYR_A_______");
    m_vecSymbols.push_back("PYR_FLOWER__");
    m_vecSymbols.push_back("PYR_SCARAB__");
    m_vecSymbols.push_back("PYR_EYE_____");
    m_vecSymbols.push_back("PYR_SPHINX__");
    m_vecSymbols.push_back("PYR_PYRAMID_");
    m_vecSymbols.push_back("PYR_FPYRAMID");

    m_mapSymbolMinMatch["PYR_TEN_____"] = 3;
    m_mapSymbolMinMatch["PYR_J_______"] = 3;
    m_mapSymbolMinMatch["PYR_Q_______"] = 3;
    m_mapSymbolMinMatch["PYR_K_______"] = 3;
    m_mapSymbolMinMatch["PYR_A_______"] = 3;
    m_mapSymbolMinMatch["PYR_FLOWER__"] = 2;
    m_mapSymbolMinMatch["PYR_SCARAB__"] = 2;
    m_mapSymbolMinMatch["PYR_EYE_____"] = 2;
    m_mapSymbolMinMatch["PYR_SPHINX__"] = 2;

    m_mapSymbolMeterGoc["PYR_TEN_____"] = "PYR_WM_JT_$x";
    m_mapSymbolMeterGoc["PYR_J_______"] = "PYR_WM_JT_$x";
    m_mapSymbolMeterGoc["PYR_Q_______"] = "PYR_WM_KQ_$x";
    m_mapSymbolMeterGoc["PYR_K_______"] = "PYR_WM_KQ_$x";
    m_mapSymbolMeterGoc["PYR_A_______"] = "PYR_WM_A_$x";
    m_mapSymbolMeterGoc["PYR_FLOWER__"] = "PYR_WM_FLO_$x";
    m_mapSymbolMeterGoc["PYR_SCARAB__"] = "PYR_WM_SCA_$x";
    m_mapSymbolMeterGoc["PYR_EYE_____"] = "PYR_WM_EYE_$x";
    m_mapSymbolMeterGoc["PYR_SPHINX__"] = "PYR_WM_SPH_$x";

    m_vecWinLines.push_back("PYR_WINL1");
    m_vecWinLines.push_back("PYR_WINL2");
    m_vecWinLines.push_back("PYR_WINL3");
    m_vecWinLines.push_back("PYR_WINL4");
    m_vecWinLines.push_back("PYR_WINL5");
    m_vecWinLines.push_back("PYR_WINL6");
    m_vecWinLines.push_back("PYR_WINL7");
    m_vecWinLines.push_back("PYR_WINL8");
    m_vecWinLines.push_back("PYR_WINL9");
    m_vecWinLines.push_back("PYR_WINL10");

    m_vecLineSounds.push_back(SMP_PyrWinstep1);
    m_vecLineSounds.push_back(SMP_PyrWinstep2);
    m_vecLineSounds.push_back(SMP_PyrWinstep3);
    m_vecLineSounds.push_back(SMP_PyrWinstep4);
    m_vecLineSounds.push_back(SMP_PyrWinstep5);
    m_vecLineSounds.push_back(SMP_PyrWinstep6);
    m_vecLineSounds.push_back(SMP_PyrWinstep7);
    m_vecLineSounds.push_back(SMP_PyrWinstep8);
    m_vecLineSounds.push_back(SMP_PyrWinstep9);
    m_vecLineSounds.push_back(SMP_PyrWinstep10);

    m_vecWinSounds.push_back(SMP_PyrWin1);
    m_vecWinSounds.push_back(SMP_PyrWin2);
    m_vecWinSounds.push_back(SMP_PyrWin3);
    m_vecWinSounds.push_back(SMP_PyrWin4);
    m_vecWinSounds.push_back(SMP_PyrWin5);
    m_vecWinSounds.push_back(SMP_PyrWin6);
    m_vecWinSounds.push_back(SMP_PyrWin7);
    m_vecWinSounds.push_back(SMP_PyrWin8);
    m_vecWinSounds.push_back(SMP_PyrWin9);
    m_vecWinSounds.push_back(SMP_PyrWin10);

    m_vecReelStripPlan.push_back("0");
    m_vecReelStripPlan.push_back("1");
    m_vecReelStripPlan.push_back("2");
    m_vecReelStripPlan.push_back("3");
    m_vecReelStripPlan.push_back("4");
    m_vecReelStripPlan.push_back("5");

    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));
    
    char* pyrReelStrip[] = {
        "PYR_SPHINX__,PYR_A_______,PYR_Q_______,PYR_TEN_____,PYR_SCARAB__,PYR_K_______,PYR_J_______,PYR_TEN_____,PYR_PYRAMID_,PYR_A_______,PYR_TEN_____,PYR_Q_______,PYR_SCARAB__,PYR_A_______,PYR_Q_______,PYR_TEN_____,PYR_EYE_____,PYR_K_______,PYR_A_______,PYR_J_______,PYR_PYRAMID_,PYR_K_______,PYR_Q_______,PYR_TEN_____,PYR_FLOWER__,PYR_A_______,PYR_J_______,PYR_TEN_____",
        "PYR_SPHINX__,PYR_Q_______,PYR_A_______,PYR_TEN_____,PYR_SCARAB__,PYR_K_______,PYR_A_______,PYR_TEN_____,PYR_PYRAMID_,PYR_Q_______,PYR_TEN_____,PYR_A_______,PYR_SCARAB__,PYR_Q_______,PYR_TEN_____,PYR_A_______,PYR_EYE_____,PYR_J_______,PYR_Q_______,PYR_PYRAMID_,PYR_TEN_____,PYR_J_______,PYR_FLOWER__,PYR_A_______,PYR_K_______,PYR_PYRAMID_,PYR_A_______,PYR_TEN_____",
        "PYR_SPHINX__,PYR_A_______,PYR_Q_______,PYR_J_______,PYR_SCARAB__,PYR_K_______,PYR_A_______,PYR_TEN_____,PYR_FPYRAMID,PYR_A_______,PYR_TEN_____,PYR_J_______,PYR_EYE_____,PYR_K_______,PYR_Q_______,PYR_J_______,PYR_FPYRAMID,PYR_A_______,PYR_J_______,PYR_Q_______,PYR_FLOWER__,PYR_K_______,PYR_A_______,PYR_TEN_____",
        "PYR_SPHINX__,PYR_A_______,PYR_TEN_____,PYR_EYE_____,PYR_Q_______,PYR_J_______,PYR_PYRAMID_,PYR_K_______,PYR_TEN_____,PYR_SCARAB__,PYR_Q_______,PYR_K_______,PYR_FLOWER__,PYR_A_______,PYR_J_______",
        "PYR_SPHINX__,PYR_A_______,PYR_TEN_____,PYR_EYE_____,PYR_Q_______,PYR_J_______,PYR_PYRAMID_,PYR_K_______,PYR_TEN_____,PYR_SCARAB__,PYR_Q_______,PYR_K_______,PYR_FLOWER__,PYR_A_______,PYR_J_______",
        "PYR_SPHINX__,PYR_A_______,PYR_TEN_____,PYR_EYE_____,PYR_Q_______,PYR_J_______,PYR_FPYRAMID,PYR_K_______,PYR_TEN_____,PYR_SCARAB__,PYR_Q_______,PYR_K_______,PYR_FLOWER__,PYR_A_______,PYR_J_______",

        "PYR_SPHINX__,PYR_K_______,PYR_TEN_____,PYR_J_______,PYR_A_______,PYR_FLOWER__,PYR_J_______,PYR_K_______,PYR_TEN_____,PYR_Q_______,PYR_A_______,PYR_EYE_____,PYR_J_______,PYR_K_______,PYR_TEN_____,PYR_Q_______,PYR_SCARAB__,PYR_A_______,PYR_J_______,PYR_K_______,PYR_TEN_____,PYR_Q_______,PYR_FLOWER__,PYR_A_______,PYR_J_______,PYR_K_______,PYR_TEN_____,PYR_Q_______",
        "PYR_SPHINX__,PYR_J_______,PYR_K_______,PYR_A_______,PYR_J_______,PYR_FLOWER__,PYR_TEN_____,PYR_J_______,PYR_Q_______,PYR_K_______,PYR_A_______,PYR_EYE_____,PYR_TEN_____,PYR_K_______,PYR_J_______,PYR_TEN_____,PYR_SCARAB__,PYR_K_______,PYR_TEN_____,PYR_A_______,PYR_K_______,PYR_J_______,PYR_FLOWER__,PYR_A_______,PYR_TEN_____,PYR_J_______,PYR_Q_______,PYR_K_______",
        "PYR_SPHINX__,PYR_J_______,PYR_K_______,PYR_A_______,PYR_FLOWER__,PYR_Q_______,PYR_TEN_____,PYR_K_______,PYR_SCARAB__,PYR_J_______,PYR_Q_______,PYR_EYE_____,PYR_TEN_____,PYR_J_______,PYR_K_______,PYR_TEN_____,PYR_SCARAB__,PYR_Q_______,PYR_TEN_____,PYR_A_______,PYR_J_______,PYR_FLOWER__,PYR_A_______,PYR_Q_______",
        "PYR_SPHINX__,PYR_J_______,PYR_Q_______,PYR_SCARAB__,PYR_TEN_____,PYR_K_______,PYR_EYE_____,PYR_A_______,PYR_K_______,PYR_FLOWER__,PYR_A_______,PYR_J_______,PYR_TEN_____,PYR_Q_______",
        "PYR_SPHINX__,PYR_J_______,PYR_Q_______,PYR_SCARAB__,PYR_TEN_____,PYR_K_______,PYR_EYE_____,PYR_A_______,PYR_K_______,PYR_FLOWER__,PYR_A_______,PYR_J_______,PYR_TEN_____,PYR_Q_______",
        "PYR_SPHINX__,PYR_J_______,PYR_Q_______,PYR_SCARAB__,PYR_TEN_____,PYR_K_______,PYR_EYE_____,PYR_A_______,PYR_K_______,PYR_FLOWER__,PYR_A_______,PYR_J_______,PYR_TEN_____,PYR_Q_______",

        "PYR_SPHINX__,PYR_K_______,PYR_J_______,PYR_PYRAMID_,PYR_K_______,PYR_J_______,PYR_A_______,PYR_FLOWER__,PYR_J_______,PYR_K_______,PYR_EYE_____,PYR_TEN_____,PYR_J_______,PYR_K_______,PYR_SCARAB__,PYR_Q_______,PYR_TEN_____,PYR_PYRAMID_,PYR_K_______,PYR_J_______,PYR_A_______,PYR_FLOWER__,PYR_K_______,PYR_Q_______,PYR_EYE_____,PYR_J_______,PYR_A_______,PYR_TEN_____",
        "PYR_SPHINX__,PYR_J_______,PYR_TEN_____,PYR_FLOWER__,PYR_J_______,PYR_A_______,PYR_Q_______,PYR_PYRAMID_,PYR_K_______,PYR_J_______,PYR_EYE_____,PYR_TEN_____,PYR_K_______,PYR_J_______,PYR_SCARAB__,PYR_TEN_____,PYR_Q_______,PYR_PYRAMID_,PYR_J_______,PYR_A_______,PYR_Q_______,PYR_FLOWER__,PYR_K_______,PYR_Q_______,PYR_EYE_____,PYR_J_______,PYR_TEN_____,PYR_Q_______",
        "PYR_SPHINX__,PYR_J_______,PYR_K_______,PYR_FLOWER__,PYR_Q_______,PYR_J_______,PYR_FPYRAMID,PYR_K_______,PYR_J_______,PYR_EYE_____,PYR_TEN_____,PYR_K_______,PYR_SCARAB__,PYR_Q_______,PYR_TEN_____,PYR_FPYRAMID,PYR_A_______,PYR_TEN_____,PYR_FLOWER__,PYR_Q_______,PYR_K_______,PYR_EYE_____,PYR_TEN_____,PYR_A_______",
        "PYR_SPHINX__,PYR_K_______,PYR_J_______,PYR_FLOWER__,PYR_Q_______,PYR_TEN_____,PYR_PYRAMID_,PYR_J_______,PYR_A_______,PYR_EYE_____,PYR_K_______,PYR_Q_______,PYR_SCARAB__,PYR_A_______,PYR_TEN_____",
        "PYR_SPHINX__,PYR_K_______,PYR_J_______,PYR_FLOWER__,PYR_Q_______,PYR_TEN_____,PYR_PYRAMID_,PYR_J_______,PYR_A_______,PYR_EYE_____,PYR_K_______,PYR_Q_______,PYR_SCARAB__,PYR_A_______,PYR_TEN_____",
        "PYR_SPHINX__,PYR_K_______,PYR_J_______,PYR_FLOWER__,PYR_Q_______,PYR_TEN_____,PYR_FPYRAMID,PYR_J_______,PYR_A_______,PYR_EYE_____,PYR_K_______,PYR_Q_______,PYR_SCARAB__,PYR_A_______,PYR_TEN_____",

        "PYR_SPHINX__,PYR_Q_______,PYR_J_______,PYR_EYE_____,PYR_TEN_____,PYR_J_______,PYR_FLOWER__,PYR_Q_______,PYR_TEN_____,PYR_SCARAB__,PYR_J_______,PYR_Q_______,PYR_TEN_____,PYR_SPHINX__,PYR_K_______,PYR_Q_______,PYR_SCARAB__,PYR_J_______,PYR_A_______,PYR_FLOWER__,PYR_TEN_____,PYR_K_______,PYR_EYE_____,PYR_Q_______,PYR_J_______,PYR_SCARAB__,PYR_TEN_____,PYR_A_______",
        "PYR_SPHINX__,PYR_K_______,PYR_J_______,PYR_SCARAB__,PYR_TEN_____,PYR_FLOWER__,PYR_Q_______,PYR_TEN_____,PYR_FLOWER__,PYR_J_______,PYR_SCARAB__,PYR_Q_______,PYR_TEN_____,PYR_SCARAB__,PYR_Q_______,PYR_FLOWER__,PYR_A_______,PYR_K_______,PYR_FLOWER__,PYR_Q_______,PYR_EYE_____,PYR_K_______,PYR_SCARAB__,PYR_J_______,PYR_FLOWER__,PYR_A_______,PYR_SCARAB__,PYR_Q_______",
        "PYR_SPHINX__,PYR_Q_______,PYR_J_______,PYR_EYE_____,PYR_TEN_____,PYR_J_______,PYR_FLOWER__,PYR_TEN_____,PYR_K_______,PYR_SCARAB__,PYR_J_______,PYR_TEN_____,PYR_SPHINX__,PYR_K_______,PYR_Q_______,PYR_SCARAB__,PYR_J_______,PYR_A_______,PYR_FLOWER__,PYR_TEN_____,PYR_J_______,PYR_FLOWER__,PYR_TEN_____,PYR_A_______",
        "PYR_SPHINX__,PYR_Q_______,PYR_A_______,PYR_FLOWER__,PYR_J_______,PYR_K_______,PYR_EYE_____,PYR_TEN_____,PYR_Q_______,PYR_SCARAB__,PYR_A_______,PYR_J_______,PYR_TEN_____,PYR_K_______",
        "PYR_SPHINX__,PYR_Q_______,PYR_A_______,PYR_FLOWER__,PYR_J_______,PYR_K_______,PYR_EYE_____,PYR_TEN_____,PYR_Q_______,PYR_SCARAB__,PYR_A_______,PYR_J_______,PYR_TEN_____,PYR_K_______",
        "PYR_SPHINX__,PYR_Q_______,PYR_A_______,PYR_FLOWER__,PYR_J_______,PYR_K_______,PYR_EYE_____,PYR_TEN_____,PYR_Q_______,PYR_SCARAB__,PYR_A_______,PYR_J_______,PYR_TEN_____,PYR_K_______",

        "PYR_SPHINX__,PYR_TEN_____,PYR_J_______,PYR_PYRAMID_,PYR_Q_______,PYR_TEN_____,PYR_EYE_____,PYR_J_______,PYR_K_______,PYR_SCARAB__,PYR_Q_______,PYR_TEN_____,PYR_FLOWER__,PYR_A_______,PYR_K_______,PYR_J_______,PYR_SCARAB__,PYR_TEN_____,PYR_Q_______,PYR_PYRAMID_,PYR_A_______,PYR_J_______,PYR_EYE_____,PYR_K_______,PYR_TEN_____,PYR_FLOWER__,PYR_J_______,PYR_Q_______",
        "PYR_SPHINX__,PYR_K_______,PYR_J_______,PYR_PYRAMID_,PYR_K_______,PYR_TEN_____,PYR_FLOWER__,PYR_J_______,PYR_K_______,PYR_SCARAB__,PYR_Q_______,PYR_J_______,PYR_FLOWER__,PYR_TEN_____,PYR_A_______,PYR_EYE_____,PYR_J_______,PYR_K_______,PYR_FLOWER__,PYR_Q_______,PYR_A_______,PYR_PYRAMID_,PYR_J_______,PYR_K_______,PYR_TEN_____,PYR_FLOWER__,PYR_K_______,PYR_A_______",
        "PYR_SPHINX__,PYR_TEN_____,PYR_J_______,PYR_FPYRAMID,PYR_Q_______,PYR_TEN_____,PYR_EYE_____,PYR_J_______,PYR_K_______,PYR_SCARAB__,PYR_A_______,PYR_K_______,PYR_SCARAB__,PYR_Q_______,PYR_A_______,PYR_FPYRAMID,PYR_TEN_____,PYR_K_______,PYR_FLOWER__,PYR_TEN_____,PYR_Q_______,PYR_FPYRAMID,PYR_K_______,PYR_Q_______,PYR_J_______",
        "PYR_SPHINX__,PYR_TEN_____,PYR_K_______,PYR_EYE_____,PYR_Q_______,PYR_J_______,PYR_PYRAMID_,PYR_A_______,PYR_TEN_____,PYR_FLOWER__,PYR_K_______,PYR_J_______,PYR_SCARAB__,PYR_A_______,PYR_Q_______",
        "PYR_SPHINX__,PYR_TEN_____,PYR_K_______,PYR_EYE_____,PYR_Q_______,PYR_J_______,PYR_PYRAMID_,PYR_A_______,PYR_TEN_____,PYR_FLOWER__,PYR_K_______,PYR_J_______,PYR_SCARAB__,PYR_A_______,PYR_Q_______",
        "PYR_SPHINX__,PYR_TEN_____,PYR_K_______,PYR_EYE_____,PYR_Q_______,PYR_J_______,PYR_FPYRAMID,PYR_A_______,PYR_TEN_____,PYR_FLOWER__,PYR_K_______,PYR_J_______,PYR_SCARAB__,PYR_A_______,PYR_Q_______",
    };

    for (int i = 0; i < m_vecReelStripPlan.size(); i++) {
        ReelSet set;
        for (int j = 0; j < m_nReel; j++) {
            ReelStrip strip;
            std::stringstream ss(pyrReelStrip[j * m_vecReelStripPlan.size() + i]);
            std::string item;
            while (std::getline(ss, item, ',')) {
                strip.push_back(item);
            }
            set.push_back(strip);
        }
        m_vecReelStripSets.push_back(set);
    }

    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_05_tmp;
    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_10_tmp;
    for (int i = 0; i < m_vecBetSteps_05_tmp.size(); i++) {
        std::map<std::string, std::map<UINT8, BONUS>> perSym;
        std::map<UINT8, BONUS> e;
        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[5].ag = 0;
        perSym["PYR_TEN_____"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[5].ag = 0;
        perSym["PYR_J_______"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 40; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 150; e[5].ag = 0;
        perSym["PYR_Q_______"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 40; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 150; e[5].ag = 0;
        perSym["PYR_K_______"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 50; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 200; e[5].ag = 0;
        perSym["PYR_A_______"] = e;
        e.clear();

        e[2].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[2].ag = 0;
        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 75; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 250; e[5].ag = 0;
        perSym["PYR_FLOWER__"] = e;
        e.clear();

        e[2].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[2].ag = 0;
        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 25; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 500; e[5].ag = 0;
        perSym["PYR_SCARAB__"] = e;
        e.clear();

        e[2].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[2].ag = 0;
        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 50; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 200; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 1000; e[5].ag = 0;
        perSym["PYR_EYE_____"] = e;
        e.clear();

        e[2].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 10; e[2].ag = 0;
        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 1000; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5000; e[5].ag = 0;
        perSym["PYR_SPHINX__"] = e;
        e.clear();

        m_Bonus_05_tmp[i] = perSym;
    }
    m_Bonus_05_tmp[m_vecBetSteps_05_tmp.size() - 1 - BIGBET_BETSTEP_EXTRA_COUNT]["PYR_SPHINX__"][5].coin = 0; m_Bonus_05_tmp[m_vecBetSteps_05_tmp.size() - 1 - BIGBET_BETSTEP_EXTRA_COUNT]["PYR_SPHINX__"][5].ag = 100;
    m_Bonus_10_tmp = m_Bonus_05_tmp;

    int nSavedBetVal = 10;
    string data;
    PlayDB::GetInstance().LoadCheckPoint(m_strGameName, nSavedBetVal, m_nWinLine, m_strCheckPoint);
    if (nSavedBetVal == -1) {
        nSavedBetVal = 10;
    }
    if (m_nWinLine == -1) {
        m_nWinLine = 5;
    }

    BOOL start = FALSE;
    int idx = 0;
    for (int i = 0; i < m_vecBetSteps_05_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_05_tmp, i) < AT(m_vecBetSteps_05, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps_05, idx) == nSavedBetVal && m_nWinLine == 5) {
            m_nBetStep = idx;
        }

        m_Bonus_05[idx++] = m_Bonus_05_tmp[i];
        if (AT(m_vecBetSteps_05_tmp, i) == AT(m_vecBetSteps_05, m_vecBetSteps_05.size() - 1)) {
            break;
        }
    }
    start = FALSE;
    idx = 0;
    for (int i = 0; i < m_vecBetSteps_10_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_10_tmp, i) < AT(m_vecBetSteps_10, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps_10, idx) == nSavedBetVal && m_nWinLine == 10) {
            m_nBetStep = idx;
        }

        m_Bonus_10[idx++] = m_Bonus_10_tmp[i];
        if (AT(m_vecBetSteps_10_tmp, i) == AT(m_vecBetSteps_10, m_vecBetSteps_10.size() - 1)) {
            break;
        }
    }
    m_Bonus = (m_nWinLine == 5 ? m_Bonus_05 : m_Bonus_10);
    m_vecBetSteps = (m_nWinLine == 5 ? m_vecBetSteps_05 : m_vecBetSteps_10);
    PrintAllBonus();
}

UINT16 RgPyramidsDeluxe::Run() {
    // reelstrip
    // 0, 1, 3, 4 -> for normal mode
    // 2, 5 -> for free mode
    myVector<int> v{0, 1, 3, 4};
    
    m_nCurrentReelPlan = AT(v, myRandom() % v.size());
#ifdef TEST_FREE_MODE
    m_nCurrentReelPlan = 0;
#endif
    m_shCurrentReelStrip = static_cast<uint16_t>(std::stoi(AT(m_vecReelStripPlan, m_nCurrentReelPlan)));
    return m_shCurrentReelStrip;
}

void RgPyramidsDeluxe::ChangeReelStrip(UINT16 NewReelPlan) {
    m_nCurrentReelPlan = NewReelPlan;
    m_shCurrentReelStrip = static_cast<uint16_t>(std::stoi(AT(m_vecReelStripPlan, m_nCurrentReelPlan)));
}


int RgPyramidsDeluxe::LineSwapDelay(int WinIdx) {
    return 500;
}

myVector<UINT8> RgPyramidsDeluxe::Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) {
    m_nMagicCount = 0;
    m_bPrevSpinMatchedActive = FALSE;
    myVector<UINT8> result;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);

    if (bTest) {
        std::string matchSymbol = AT(m_vecSymbols, myRandom() % (m_vecSymbols.size() - 2));
        int line = (myRandom() % m_nWinLine);
        int weight = 1 + (myRandom() % 5);

        BOOL bForceFree = (myRandom() % 10 == 0);
        for (int i = 0; i < m_nReel; i++) {
            ReelStrip reelStrip = AT(reelSet, i);
            int len = reelStrip.size() - 3;

            int valid_i[0x100];
            int valid_count = 0;

            myVector<int> freeSymbols;
            for (int j = 0; j <= len; j++) {
                if (weight > i) {
                    if (matchSymbol == AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                else {
                    if (matchSymbol != AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                if (AT(reelStrip, j) == RgPyramidsDeluxe_pyramid && m_bFreeMode == FALSE) {
                    freeSymbols.push_back(j);
                }
            }
            if (valid_count > 0) {
                int rand_index = myRandom() % valid_count;
                int chosen_i = valid_i[rand_index];
                result.push_back(chosen_i + 1);
            }
            else {
                result.push_back((myRandom() % (len - 1)) + 1);
            }
            {
                int pool[5] = { 0, 2, 4 };
                auto v = pickRandom2or3(pool, 3, 3);
                if (bForceFree && m_bFreeMode == FALSE && freeSymbols.size() > 0 && std::find(v.begin(), v.end(), i) != v.end()) {
                    AT(result, result.size() - 1) =
                        AT(freeSymbols, myRandom() % freeSymbols.size()) - (myRandom() % 2) + 1;
                }
            }
        }
    }
    else {
        result = _result;

        BOOL mmcode = mmcode_get_active_status();
        if (mmcode) {
            mmcode_set_deactive();
            if (m_bFreeMode == FALSE) {
                for (int j = 0; j < 5; j ++) {
                    myVector<int> candidateIndices;
                    for (int i = 2; i < AT(reelSet, j).size() - 3; ++i) {
                        if (j%2 == 0 && AT(AT(reelSet, j), i) == RgPyramidsDeluxe_pyramid) {
                            int offset = myRandom() % 3;
                            int selectedIndex = i - 2 + offset;
                            candidateIndices.push_back(selectedIndex);
                        }
                        if (j%2 == 1 && AT(AT(reelSet, j), i) != RgPyramidsDeluxe_pyramid
                                    && AT(AT(reelSet, j), i-2) != RgPyramidsDeluxe_pyramid
                                    && AT(AT(reelSet, j), i-1) != RgPyramidsDeluxe_pyramid
                                    && AT(AT(reelSet, j), i+1) != RgPyramidsDeluxe_pyramid
                                    && AT(AT(reelSet, j), i+2) != RgPyramidsDeluxe_pyramid) {
                            int offset = myRandom() % 3;
                            int selectedIndex = i - 2 + offset;
                            candidateIndices.push_back(selectedIndex);
                        }
                    }
                    if (!candidateIndices.empty()) {
#ifdef BIGBET_ACTIVE
                        int chosenIndex = AT(candidateIndices, (candidateIndices.size()<3?myRandom() % candidateIndices.size():myRandom() % 3));
#else
                        int chosenIndex = AT(candidateIndices, myRandom() % candidateIndices.size());
#endif
                        AT(result, j) = chosenIndex + 1;
                    }
                }
            }
        }
    }

    m_vWinResult = result;

    normalMeter = 0;
    maxMeter = 0;
    BONUS totalBonus = {0, 0};
    for (int i = 0; i < m_nWinLine; i++) {
        int j = 1;
        UINT16 meter = ((UINT16)1 << (2 - g_match_lines_10_5[i][0]));
        std::string firstSymbol = AT(AT(reelSet, 0), AT(result, 0) - 1 + g_match_lines_10_5[i][0]);

        int maxWinBonus = 0;
        UINT16 maxWinMeter = 0;
        int maxWinWeight = 0;
        std::string maxWinSymbol = "";
        for (; j < m_nMaxMatch; j++) {
            std::string prev_symbol = AT(AT(reelSet, j - 1), AT(result, j - 1) - 1 + g_match_lines_10_5[i][j - 1]);
            std::string cur_symbol = AT(AT(reelSet, j), AT(result, j) - 1 + g_match_lines_10_5[i][j]);

            if ((firstSymbol == RgPyramidsDeluxe_wild || firstSymbol == RgPyramidsDeluxe_f_pyramid /*in freemode*/) && cur_symbol != RgPyramidsDeluxe_f_pyramid) {
                firstSymbol = cur_symbol;
            }
            if (firstSymbol == cur_symbol || cur_symbol == RgPyramidsDeluxe_wild || cur_symbol == RgPyramidsDeluxe_f_pyramid) {
                meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));

                UINT32 bo = m_Bonus[BetStep()][firstSymbol][j + 1].coin + m_Bonus[BetStep()][firstSymbol][j + 1].ag * 1000;
                if (maxWinBonus < bo) {
                    maxWinBonus = bo;
                    maxWinMeter = meter;
                    maxWinSymbol = firstSymbol;
                    maxWinWeight = j + 1;
                }
                continue;
            }
            break;
        }
        if (j < m_mapSymbolMinMatch[maxWinSymbol] || m_mapSymbolMinMatch[maxWinSymbol] == 0) {
            continue;
        }
        // monitor 2 meter
        std::string meterStr = m_mapSymbolMeterGoc[maxWinSymbol];
        size_t pos = meterStr.find('$');
        if (pos != std::string::npos) {
            meterStr = meterStr.replace(pos, 1, std::to_string(maxWinWeight));
        }

        WinMeter e;
        e.line = i;
        e.meter = maxWinMeter;
        e.meter2 = g_GrafficObjList.Str2GOCID(meterStr);
        e.symbol = maxWinSymbol;
        e.weight = maxWinWeight;
        e.start = 0;
        e.bonus = m_Bonus[BetStep()][maxWinSymbol][maxWinWeight];
        e.sound = MAX_SOUND_IDS;

        totalBonus.coin += e.bonus.coin;
        totalBonus.ag += e.bonus.ag;

        if (e.meter2 != -1) {
            meters.push_back(e);
        }
        if (j == m_nMaxMatch) {
            maxMeter |= meter;
        }
        else {
            normalMeter |= meter;
        }

        if (bTest == FALSE) {
            m_bPrevSpinMatchedActive = TRUE;
        }
    }

    // impossible in freemode because of reelstrip
    int nPyramid = CardCount(RgPyramidsDeluxe_pyramid);
    if (nPyramid >= 3) {
        bCanFreeMode = TRUE;

        UINT16 meter = 0;
        for (int i = 0; i < 3; i++) {
            for (int col = 0; col < m_nReel; col++) {
                std::string cur_symbol = AT(AT(reelSet, col), AT(result, col) - 1 + i);
                if (cur_symbol == RgPyramidsDeluxe_pyramid) {
                    meter |= ((UINT16)1 << (3 * col + (2 - i)));
                }
            }
        }

        WinMeter e;
        e.line = 10;
        e.meter = meter;
        e.meter2 = 0;
        e.symbol = RgPyramidsDeluxe_pyramid;
        e.weight = nPyramid;
        e.start = 0;
        e.bonus = {0, 0};
        e.sound = MAX_SOUND_IDS;

        normalMeter |= meter;
        meters.push_back(e);

        if (bTest == FALSE) {
            m_bPrevSpinMatchedActive = TRUE;
        }
    }
    m_vWinMeters = meters;
    m_nMagicCount = totalBonus.ag;
    if (bTest == FALSE) {
        updateCheckPoint();

        if (totalBonus.coin > 0 || totalBonus.ag > 0) {
            if (m_bFreeMode) {
                m_nFreeModeTotalBonus.coin += totalBonus.coin;
                m_nFreeModeTotalBonus.ag += totalBonus.ag;
            }
            BonusSound = getSoundByID(WinSound(totalBonus.coin + totalBonus.ag * 1000));
        }
        else {
            BonusSound.duration = 0;
            BonusSound.soundID = MAX_SOUND_IDS;
        }
    }
    return result;
}

UINT8 RgPyramidsDeluxe::CardCount(std::string card) {
    int n = 0;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int col = 0; col < m_nReel; col++) {
        int k = 0;
        for (; k < 3; k++) {
            std::string s = AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k);
            if (s == card) {
                n++;
            }
        }
    }
    return n;
}

UINT16 RgPyramidsDeluxe::SpinTime_MS() {
    UINT8 n = NumberOfScatter();
    if (n >= 3) {
        return 4000;
    }
    else if (n == 2 && NumberInCol(4) == FALSE) {
        return 4000;
    }
    return 2300;
}

UINT8 RgPyramidsDeluxe::NumberOfScatter() {
    UINT8 n = 0;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int col = 0; col < m_nReel; col++) {
        int k = 0;
        for (; k < 3; k++) {
            std::string s = AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k);
            if (s == RgPyramidsDeluxe_pyramid || s == RgPyramidsDeluxe_f_pyramid) {
                n++;
            }
        }
    }
    return n;
}

BOOL RgPyramidsDeluxe::NumberInCol(int col) {
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int k = 0; k < 3; k++) {
        std::string s = AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k);
        if (s == RgPyramidsDeluxe_pyramid || s == RgPyramidsDeluxe_f_pyramid) {
            return TRUE;
        }
    }
    return FALSE;
}

BOOL RgPyramidsDeluxe::CanFreeMode() {
    if (CardCount(RgPyramidsDeluxe_pyramid) >= 3) {
        return TRUE;
    }
    return FALSE;
}

void RgPyramidsDeluxe::ChangeReelStrip(BOOL forFreeMode) {
    myVector<int> v;
    if (forFreeMode) {
        v.push_back(2);
        v.push_back(5);
    }
    else {
        v.push_back(0);
        v.push_back(1);
        v.push_back(3);
        v.push_back(4);
    }
    m_nCurrentReelPlan = AT(v, myRandom() % v.size());
    m_shCurrentReelStrip = static_cast<uint16_t>(std::stoi(AT(m_vecReelStripPlan, m_nCurrentReelPlan)));
}

myVector<InterruptPacketData> RgPyramidsDeluxe::EnterFreeGame(std::string check) {
    m_bFreeMode = TRUE;
    m_nFreeModeTotalSpin = 10;
    m_nFreeModeGoneSpin = 0;
    m_nFreeModeTotalBonus = {0, 0};

    myVector<InterruptPacketData> packets;
    if (check != "") {
        myVector<int> values = ParseCheckPoint(check, "F", 4);
        if (values.size() == 4) {
            m_nFreeModeTotalSpin = AT(values, 0);
            m_nFreeModeGoneSpin = AT(values, 1);
            m_nFreeModeTotalBonus.coin = AT(values, 2);
            m_nFreeModeTotalBonus.ag = AT(values, 3);

            UINT8 gone = (m_nFreeModeGoneSpin ? m_nFreeModeGoneSpin : 1);
            packets.push_back({
                   0, 0,
                   {0x01, 0x02, 0x30, 0x00, 0x10, 0x09, gone, 0x00, m_nFreeModeTotalSpin, 0x00, 0x00, 0x00, 0x0a, 0x00, 0xa3, 0x04} });
            return packets;
        }
    }
    else {
        updateCheckPoint();
    }
    // change reelstrip    
    ChangeReelStrip(TRUE);

    // show freemode intro dialog
    packets.push_back({
        0,
        4500,
        {0x01, 0x02, 0x30, 0x00, 0x10, 0x09, 0x0a, 0x00, 0x01, 0x00, 0x0a, 0x00, 0x0a, 0x00, 0xa6, 0x04} });
    return packets;
}

myVector<InterruptPacketData> RgPyramidsDeluxe::InterruptBeforeSpin() {
    myVector<InterruptPacketData> packets;
    if (!m_bFreeMode) {
        return packets;
    }
    m_nFreeModeGoneSpin++;
    updateCheckPoint();

    UINT8 gone = (m_nFreeModeGoneSpin ? m_nFreeModeGoneSpin : 1);

    // display total & remain free spin count
    packets.push_back({
        0,
        0,
        {
            0x01, 0x02, 0x30, 0x00, 0x10, 0x09, gone, 0x00, m_nFreeModeTotalSpin, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa5, 0x04
        }
        });
    return packets;
}

myVector<InterruptPacketData> RgPyramidsDeluxe::InterruptAfterMoveBonus(BOOL& EndFree) {
    myVector<InterruptPacketData> packets;
    if (m_nFreeModeGoneSpin >= m_nFreeModeTotalSpin) {
        EndFree = TRUE;
        m_bFreeMode = FALSE;

        // change reelstrip
        ChangeReelStrip(FALSE);

        // show result dialog, when run spin it closes
        packets.push_back({
             0,
             0,
             {0x01, 0x02, 0x30, 0x00, 0x10, 0x09, 0x00, 0x00, 
             static_cast<BYTE>(m_nFreeModeTotalBonus.coin & 0xFF), 
             static_cast<BYTE>((m_nFreeModeTotalBonus.coin >> 8) & 0xFF), 
             static_cast<BYTE>((m_nFreeModeTotalBonus.coin >> 16) & 0xFF),
             static_cast<BYTE>((m_nFreeModeTotalBonus.coin >> 24) & 0xFF),
             0x0a, 0x00, 0xab, 0x04} });

        // return background
        packets.push_back({
             0,
             2000,
             {0x01, 0x02, 0x30, 0x00, 0x10, 0x09, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa4, 0x04} });

        // hide result dialog
        packets.push_back({
             0,
             0,
             {0x01, 0x02, 0x30, 0x00, 0x10, 0x09, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xac, 0x04} });
        updateCheckPoint();

        return packets;
    }
    EndFree = FALSE;
    //m_nFreeModeGoneSpin++;
    updateCheckPoint();
    return packets;
}

UINT16 RgPyramidsDeluxe::MagicCount() {
    if (m_bFreeMode) {
        return 0;
    }
    else {
        return m_nMagicCount;
    }
}

myVector<InterruptPacketData> RgPyramidsDeluxe::MousePressed(MousePosition p) {
    myVector<InterruptPacketData> packets;

    MousePosition a{
       {RgPyramidsDeluxe_MP_ChangeLine_LB_x_reel, RgPyramidsDeluxe_MP_ChangeLine_LB_x_pos },
       {RgPyramidsDeluxe_MP_ChangeLine_LB_y_row, RgPyramidsDeluxe_MP_ChangeLine_LB_y_pos }
    };
    MousePosition b{
        {RgPyramidsDeluxe_MP_ChangeLine_RT_x_reel, RgPyramidsDeluxe_MP_ChangeLine_RT_x_pos },
        {RgPyramidsDeluxe_MP_ChangeLine_RT_y_row, RgPyramidsDeluxe_MP_ChangeLine_RT_y_pos }
    };
    if (IsMouseWithin(p, a, b)) {
        m_nWinLine = (m_nWinLine == 5) ? 10 : 5;
        if (m_bPrevSpinMatchedActive) {
            // hide win lines
            packets.push_back({ 0, 0, {0x01, 0x02, 0x31, 0x00, 0x01, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x02, 0x00, 0x04} });
            m_bPrevSpinMatchedActive = FALSE;
        }
        UINT16 newBetValue = 0;
        if (m_nWinLine == 5) {
            m_Bonus = m_Bonus_05;
            m_vecBetSteps = m_vecBetSteps_05;
            newBetValue = AT(m_vecBetSteps_10, m_nBetStep) / 2;
            // lines
            packets.push_back({ 0, 0, {0x01, 0x02, 0x31, 0x00, 0x04, 0x00,
                static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x9d, 0x1f, 0x00, 0x00, 0x00, 0x04} });
        }
        else {
            m_Bonus = m_Bonus_10;
            m_vecBetSteps = m_vecBetSteps_10;
            newBetValue = AT(m_vecBetSteps_05, m_nBetStep) * 2;
            // lines
            packets.push_back({ 0, 0, {0x01, 0x02, 0x31, 0x00, 0x04, 0x00, static_cast<BYTE>(m_nGameID & 0xFF),
                static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x9d, 0xff, 0x03, 0x00, 0x00, 0x04} });
        }
        BOOL flag = FALSE;
        for (int i = 0; i < m_vecBetSteps.size(); i++) {
            if (AT(m_vecBetSteps, i) == newBetValue) {
                m_nBetStep = i;
                flag = TRUE;
                break;
            }
        }
        if (flag == FALSE) {
            m_nBetStep = 0;
        }
        // play button sound
        packets.push_back({ 0, 0, {0x01, 0x02, 0x34, 0x00, 0xf7, 0x00, 0x04} });
        // change line button
        packets.push_back({ 0, 0, {0x01, 0x02, 0x28, 0x00,
            static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), static_cast<BYTE>(m_nWinLine), 0x00, 0x00, 0x00, 0x04} });
        // set bet
        UINT16 bet = AT(m_vecBetSteps, m_nBetStep) / 5;
        packets.push_back({ 0, 0, {0x01, 0x02, 0x30, 0x00, 0x25, 0x53, 
            static_cast<BYTE>(bet & 0xFF), static_cast<BYTE>((bet >> 8) & 0xFF), 
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04, 0x04} });
    }
    return packets;
}

myVector<UINT8> RgPyramidsDeluxe::ShowTotalWinLines(myVector<WinMeter> SpinMeters) {
    myVector<uint8_t> packet = {
        0x06, 0x30, 0x59, 0x01, 0x02, 0x31, 0x00,
        0x0F, 0x00,  // Placeholder for length 
        0x0F, 0x11, // GameID
        0x9C, 0x19, 0x01
    };
    myVector<UINT8> TotalMatch;
    for (int i = 0; i < SpinMeters.size(); i++) {
        if (AT(SpinMeters, i).line == 0xFF) { // clear after convert action
            TotalMatch.clear();
            continue;
        }
        TotalMatch.push_back(AT(SpinMeters, i).line);
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter >> 8) & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter2 & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter2 >> 8) & 0xFF));
    }
    if (TotalMatch.size() < 10) {
        myVector<UINT8> _;
        return _;
    }
    UINT16 pktLen = 1 + (TotalMatch.size() / 5) * 7;
    AT(packet, 7) = static_cast<BYTE>(pktLen & 0xFF);
    AT(packet, 8) = static_cast<BYTE>((pktLen >> 8) & 0xFF);
    AT(packet, 9) = static_cast<BYTE>(m_nGameID & 0xFF);
    AT(packet, 10) = static_cast<BYTE>((m_nGameID >> 8) & 0xFF);
    int entryCount = static_cast<int>(TotalMatch.size() / 5);
    for (int i = 0; i < entryCount; ++i) {
        packet.push_back(AT(TotalMatch, i * 5 + 0)); // Line
        packet.push_back(AT(TotalMatch, i * 5 + 1)); // Meter low byte
        packet.push_back(AT(TotalMatch, i * 5 + 2)); // Meter high byte
        packet.push_back(AT(TotalMatch, i * 5 + 3)); // Meter2 low byte
        packet.push_back(AT(TotalMatch, i * 5 + 4)); // Meter2 high byte
        packet.push_back(0x01);      // Status or flag 1
        packet.push_back(0x01);      // Status or flag 2
    }
    // Mark the end of the packet
    packet.back() = 0x04;
    return packet;
}

bool RgPyramidsDeluxe::RTP_force_bigWin() {
    return (myRandom() % 70 == 0); // 1.4%
}

BOOL RgPyramidsDeluxe::SelectedableReelsInFreeGame(myVector<UINT8> result) {
    if (m_bFreeMode == FALSE) {
        return TRUE;
    }
    myVector<UINT8> cp = m_vWinResult;
    m_vWinResult = result;
    int n = CardCount(RgPyramidsDeluxe_pyramid);
    int n1 = CardCount(RgPyramidsDeluxe_f_pyramid);
    m_vWinResult = cp;
    if (n >= 3 || n1 >= 3) {
        return FALSE;
    }
    return TRUE;
}

BOOL RgPyramidsDeluxe::NoFunInFreeMode() {
    return TRUE;
}


void RgPyramidsDeluxe::updateCheckPoint() {
    std::ostringstream oss;
    oss << " P" << m_nCurrentReelPlan
        << " B"
        << static_cast<int>(AT(m_vWinResult, 0)) << ":"
        << static_cast<int>(AT(m_vWinResult, 1)) << ":"
        << static_cast<int>(AT(m_vWinResult, 2)) << ":"
        << static_cast<int>(AT(m_vWinResult, 3)) << ":"
        << static_cast<int>(AT(m_vWinResult, 4)) << " ";

    if (m_bFreeMode) {
        oss << " F"
            << static_cast<int>(m_nFreeModeTotalSpin) << ":"
            << static_cast<int>(m_nFreeModeGoneSpin) << ":"
            << static_cast<int>(m_nFreeModeTotalBonus.coin) << ":"
            << static_cast<int>(m_nFreeModeTotalBonus.ag) << " ";
    }
    m_strCheckPoint = oss.str();
}