#pragma once

#include "ReelGame.h"
#include "RgPharosGold1.h"
#include "RgPharosGold2.h"
#include "RgPharosGold3.h"
#include "RgPharosGold4.h"

class RgPharosGoldBase : public ReelGame
{
public:
	UINT8 m_nMultiGoTotalCount;
	UINT8 m_nMultiGoGone;
	UINT8 m_nMultiLoop;

	RgPharosGold1 m_PS1;
	RgPharosGold2 m_PS2;
	RgPharosGold3 m_PS3;
	RgPharosGold4 m_PS4;

	myVector<UINT8> m_vPSPlans;

	myVector<WinMeter> m_vWinMeters;

	RgPharosGoldBase::RgPharosGoldBase();
	UINT16 GetTotalBonus();

	UINT16 Run() override;
	int LineSwapDelay(int WinIdx) override;
	UINT16 LineSound(UINT Line, std::string symbol, UINT8 weight) override;
	myVector<UINT16> CurrentReelStrip() override;
	myVector<UINT8> Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) override;
	void MultiGoGoneAndRemain(UINT8& gone, UINT8& total, UINT8& loop) override;
	myVector<InterruptPacketData> InterruptBeforeSpin() override;

	BOOL CanMultiGo() override;
	myVector<InterruptPacketData> EnterMultiGo(UINT32& bonusErfolg, BOOL bIitMultiBet) override;
	myVector<InterruptPacketData> CloseMultiGo(UINT32& bonusErfolg, BOOL force) override;
	myVector<InterruptPacketData> BetUpMultiGo(UINT32& bonusErfolg) override;
	myVector<InterruptPacketData> BetDownMultiGo(UINT32& bonusErfolg) override;
	UINT16 MiltiGoBet() override;
	UINT8 MultiGoBetStep() override;
	void SetMultiGoBetStep(UINT8 newStep) override;
	BOOL GetMultiGoEnable() override;
	void SetMultiGoEnable(BOOL status) override;
	void GetMultiGoReelPlanIdx(int& p0, int& p1, int& p2, int& p3) override;
	void SetMultiGoReelPlanIdx(int p0, int p1, int p2, int p3) override;

	myVector<InterruptPacketData> InterruptAfterSpin() override;

	myVector<UINT8> ShowTotalWinLines(myVector<WinMeter> SpinMeters) override;

	void ChangeReelStrip(UINT16 NewReelPlan) override;
};
