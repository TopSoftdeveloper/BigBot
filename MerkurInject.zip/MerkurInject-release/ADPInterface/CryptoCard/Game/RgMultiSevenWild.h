#pragma once

#include "ReelGame.h"

class RgMultiSevenWild : public ReelGame
{
public:
	int m_nMaxWinWeight; // used for matched wild or not

	RgMultiSevenWild::RgMultiSevenWild();

	int LineSwapDelay(int WinIdx) override;
	myVector<UINT8> Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& WinSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) override;
	BOOL PlayBonusSoundAfterWinLine() override;
	myVector<InterruptPacketData> InterruptAfterSpin() override;
	UINT8 Wildcount() override;
	UINT16 SpinTime_MS() override;
	UINT16 MagicCount() override;
	BOOL stopAllSoundBeforeMove() override;
	myVector<InterruptPacketData> MousePressed(MousePosition p) override;

	BOOL WildcountInCol(UINT8 col);
	myVector<UINT8> ShowTotalWinLines(myVector<WinMeter> SpinMeters) override;

	bool RTP_force_bigWin() override;
};
