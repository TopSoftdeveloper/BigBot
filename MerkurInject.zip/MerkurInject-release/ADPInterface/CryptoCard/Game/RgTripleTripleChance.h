#pragma once

#include "ReelGame.h"

class RgTripleTripleChance : public ReelGame
{
public:
	BOOL m_bFreeMode;
	UINT8 m_nFreeModeTotalSpin;
	UINT8 m_nFreeModeGoneSpin;

	std::map<std::string, UINT16> m_mapLineSounds;
	myVector<WinMeter> m_vWinMeters;

	RgTripleTripleChance::RgTripleTripleChance();
	BOOL CanRewin();

	UINT16 WinSound(UINT32 totalBonus) override;
	UINT16 LineSound(UINT Line, std::string symbol, UINT8 weight) override;
	int LineSwapDelay(int WinIdx) override;
	BOOL stopAllSoundBeforeMove() override;
	UINT16 SpinTime_MS() override;
	UINT16 Run() override;
	myVector<UINT8> Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& WinSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) override;

	BOOL CanFreeMode() override;
    myVector<InterruptPacketData> EnterFreeGame(std::string) override;
    myVector<InterruptPacketData> InterruptAfterMoveBonus(BOOL& EndFree) override;
	myVector<InterruptPacketData> InterruptAfterSpin() override;

	myVector<UINT8> ShowTotalWinLines(myVector<WinMeter> SpinMeters) override;
	void ChangeReelStrip(UINT16 NewReelPlan) override;


	myVector<InterruptPacketData> InterruptBeforeRisiko() override;
	myVector<InterruptPacketData> InterruptBeforeSpin() override;

	void updateCheckPoint() override;
};
