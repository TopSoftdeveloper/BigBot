#include "stdafx.h"
#include "RgKongsTemple.h"
#include <bitset>

#define RgKongsTemple_MP_ChangeLine_LB_x_reel   0x03
#define RgKongsTemple_MP_ChangeLine_LB_x_pos    0x26
#define RgKongsTemple_MP_ChangeLine_LB_y_row    0x02
#define RgKongsTemple_MP_ChangeLine_LB_y_pos    0x17
#define RgKongsTemple_MP_ChangeLine_RT_x_reel   0x03
#define RgKongsTemple_MP_ChangeLine_RT_x_pos    0x62
#define RgKongsTemple_MP_ChangeLine_RT_y_row    0x02
#define RgKongsTemple_MP_ChangeLine_RT_y_pos    0x50

#define RgKongsTemple_scatter "gorTEMPLE__"

myVector<int> g_RgKongsTemple_ReelsForBase = { 0, 1, 4 };
myVector<int> g_RgKongsTemple_ReelsForFree = { 2, 3, 5 };
RgKongsTemple::RgKongsTemple() {
    m_nReel = 5;
    m_nWinLine = 5;
    m_nMaxMatch = 5;
    m_nBetStep = 0;

    m_strGameName = "RgKongsTemple";

    m_bFreeMode = FALSE;

    myVector<UINT16> m_vecBetSteps_05_tmp;
    myVector<UINT16> m_vecBetSteps_10_tmp;

    m_vecBetSteps_05_tmp.push_back(5);
    m_vecBetSteps_05_tmp.push_back(10);
    m_vecBetSteps_05_tmp.push_back(20);
    m_vecBetSteps_05_tmp.push_back(30);
    m_vecBetSteps_05_tmp.push_back(40);
    m_vecBetSteps_05_tmp.push_back(50);
    m_vecBetSteps_05_tmp.push_back(60);
    m_vecBetSteps_05_tmp.push_back(80);
    m_vecBetSteps_05_tmp.push_back(100);

    m_vecBetSteps_10_tmp.push_back(10);
    m_vecBetSteps_10_tmp.push_back(20);
    m_vecBetSteps_10_tmp.push_back(40);
    m_vecBetSteps_10_tmp.push_back(60);
    m_vecBetSteps_10_tmp.push_back(80);
    m_vecBetSteps_10_tmp.push_back(100);
    m_vecBetSteps_10_tmp.push_back(120);
    m_vecBetSteps_10_tmp.push_back(160);
    m_vecBetSteps_10_tmp.push_back(200);
#ifdef BIGBET_ACTIVE
    m_vecBetSteps_05_tmp.push_back(200);
    m_vecBetSteps_05_tmp.push_back(500);
    m_vecBetSteps_10_tmp.push_back(400);
    m_vecBetSteps_10_tmp.push_back(1000);
#endif
    LoadBets();

    m_vecBetSteps = m_vecBetSteps_05;

    m_vecSymbols.push_back("gorNINE____");
    m_vecSymbols.push_back("gorTEN_____");
    m_vecSymbols.push_back("gorJ_______");
    m_vecSymbols.push_back("gorQ_______");
    m_vecSymbols.push_back("gorK_______");
    m_vecSymbols.push_back("gorA_______");
    m_vecSymbols.push_back("gorFLOWER__");
    m_vecSymbols.push_back("gorFRUIT___");
    m_vecSymbols.push_back("gorFROG____");
    m_vecSymbols.push_back("gorSTATUE__");
    m_vecSymbols.push_back("gorCHEST___");

    m_vecSymbols.push_back("gorTEMPLE__");
    m_vecSymbols.push_back("gorGORILLA_");
    m_vecSymbols.push_back("gorGORILLAA");
    m_vecSymbols.push_back("gorGORILLAB");
    m_vecSymbols.push_back("gorGORILLAC");
    m_vecSymbols.push_back("gorGORILLAD");
    m_vecSymbols.push_back("gorGORILLAE");

    m_mapSymbolMinMatch["gorNINE____"] = 3;
    m_mapSymbolMinMatch["gorTEN_____"] = 3;
    m_mapSymbolMinMatch["gorJ_______"] = 3;
    m_mapSymbolMinMatch["gorQ_______"] = 3;
    m_mapSymbolMinMatch["gorK_______"] = 3;
    m_mapSymbolMinMatch["gorA_______"] = 3;
    m_mapSymbolMinMatch["gorFLOWER__"] = 2;
    m_mapSymbolMinMatch["gorFRUIT___"] = 2;
    m_mapSymbolMinMatch["gorFROG____"] = 3;
    m_mapSymbolMinMatch["gorSTATUE__"] = 3;
    m_mapSymbolMinMatch["gorCHEST___"] = 3;

    m_mapSymbolMeterGoc["gorNINE____"] = "gorAKQJTN$x";
    m_mapSymbolMeterGoc["gorTEN_____"] = "gorAKQJTN$x";
    m_mapSymbolMeterGoc["gorJ_______"] = "gorAKQJTN$x";
    m_mapSymbolMeterGoc["gorQ_______"] = "gorAKQJTN$x";
    m_mapSymbolMeterGoc["gorK_______"] = "gorAKQJTN$x";
    m_mapSymbolMeterGoc["gorA_______"] = "gorAKQJTN$x";
    m_mapSymbolMeterGoc["gorFLOWER__"] = "gorFruFlo$x";
    m_mapSymbolMeterGoc["gorFRUIT___"] = "gorFruFlo$x";
    m_mapSymbolMeterGoc["gorFROG____"] = "gorFrog$x";
    m_mapSymbolMeterGoc["gorSTATUE__"] = "gorStatue$x";
    m_mapSymbolMeterGoc["gorCHEST___"] = "gorChest$x";

    m_vecWinLines.push_back("gorWinline1");
    m_vecWinLines.push_back("gorWinline2");
    m_vecWinLines.push_back("gorWinline3");
    m_vecWinLines.push_back("gorWinline4");
    m_vecWinLines.push_back("gorWinline5");
    m_vecWinLines.push_back("gorWinline6");
    m_vecWinLines.push_back("gorWinline7");
    m_vecWinLines.push_back("gorWinline8");
    m_vecWinLines.push_back("gorWinline9");
    m_vecWinLines.push_back("gorWinline10");
    m_vecWinLines.push_back("gorWinlineScat");

    m_vecLineSounds.push_back(SMP_GorWinStep1);
    m_vecLineSounds.push_back(SMP_GorWinStep2);
    m_vecLineSounds.push_back(SMP_GorWinStep3);
    m_vecLineSounds.push_back(SMP_GorWinStep4);
    m_vecLineSounds.push_back(SMP_GorWinStep5);
    m_vecLineSounds.push_back(SMP_GorWinStep6);
    m_vecLineSounds.push_back(SMP_GorWinStep7);
    m_vecLineSounds.push_back(SMP_GorWinStep8);
    m_vecLineSounds.push_back(SMP_GorWinStep9);
    m_vecLineSounds.push_back(SMP_GorWinStep10);

    m_vecWinSounds.push_back(SMP_GorWin1);
    m_vecWinSounds.push_back(SMP_GorWin2);
    m_vecWinSounds.push_back(SMP_GorWin3);
    m_vecWinSounds.push_back(SMP_GorWin4);
    m_vecWinSounds.push_back(SMP_GorWin5);
    m_vecWinSounds.push_back(SMP_GorWin6);
    m_vecWinSounds.push_back(SMP_GorWin7);
    m_vecWinSounds.push_back(SMP_GorWin8);
    m_vecWinSounds.push_back(SMP_GorWin9);
    m_vecWinSounds.push_back(SMP_GorWin10);

    m_vecReelStripPlan.push_back("0");
    m_vecReelStripPlan.push_back("1");
    m_vecReelStripPlan.push_back("2");
    m_vecReelStripPlan.push_back("3");
    m_vecReelStripPlan.push_back("4");
    m_vecReelStripPlan.push_back("5");
    
    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));

    char* gorReelStrip[] = {
        "gorCHEST___,gorA_______,gorTEN_____,gorFRUIT___,gorFRUIT___,gorNINE____,gorTEN_____,gorFLOWER__,gorFLOWER__,gorFLOWER__,gorA_______,gorJ_______,gorFROG____,gorNINE____,gorTEN_____,gorSTATUE__,gorJ_______,gorQ_______,gorTEN_____,gorFRUIT___,gorFRUIT___,gorK_______,gorTEN_____,gorA_______,gorTEMPLE__,gorQ_______,gorJ_______,gorK_______,gorNINE____,gorQ_______,gorJ_______,gorK_______,gorFROG____,gorJ_______,gorA_______,gorTEN_____",
        "gorCHEST___,gorK_______,gorNINE____,gorFLOWER__,gorFLOWER__,gorTEN_____,gorNINE____,gorFRUIT___,gorFRUIT___,gorFRUIT___,gorK_______,gorQ_______,gorFROG____,gorTEN_____,gorNINE____,gorSTATUE__,gorQ_______,gorJ_______,gorNINE____,gorFLOWER__,gorFLOWER__,gorA_______,gorNINE____,gorK_______,gorTEMPLE__,gorJ_______,gorQ_______,gorA_______,gorTEN_____,gorJ_______,gorQ_______,gorA_______,gorFROG____,gorQ_______,gorK_______,gorNINE____",
        "gorFLOWER__,gorFLOWER__,gorFLOWER__,gorTEN_____,gorNINE____,gorFROG____,gorA_______,gorNINE____,gorQ_______,gorK_______,gorCHEST___,gorJ_______,gorFRUIT___,gorFRUIT___,gorA_______,gorQ_______,gorSTATUE__,gorTEN_____,gorFLOWER__,gorFLOWER__,gorK_______,gorA_______,gorTEMPLE__,gorNINE____,gorQ_______,gorFRUIT___,gorFRUIT___,gorJ_______,gorFROG____,gorNINE____,gorK_______,gorTEN_____,gorTEMPLE__,gorJ_______,gorA_______",
        "gorFRUIT___,gorFRUIT___,gorFRUIT___,gorNINE____,gorTEN_____,gorFROG____,gorK_______,gorTEN_____,gorJ_______,gorA_______,gorCHEST___,gorQ_______,gorFLOWER__,gorFLOWER__,gorK_______,gorJ_______,gorSTATUE__,gorNINE____,gorFRUIT___,gorFRUIT___,gorA_______,gorK_______,gorTEMPLE__,gorTEN_____,gorJ_______,gorFLOWER__,gorFLOWER__,gorQ_______,gorFROG____,gorTEN_____,gorA_______,gorNINE____,gorTEMPLE__,gorQ_______,gorK_______",
        "gorCHEST___,gorA_______,gorQ_______,gorSTATUE__,gorNINE____,gorTEN_____,gorFROG____,gorK_______,gorJ_______,gorFRUIT___,gorFRUIT___,gorFRUIT___,gorA_______,gorJ_______,gorTEMPLE__,gorQ_______,gorK_______,gorFROG____,gorTEN_____,gorNINE____,gorFLOWER__,gorFLOWER__,gorFLOWER__,gorA_______,gorK_______,gorTEMPLE__,gorJ_______,gorQ_______,gorFRUIT___,gorFRUIT___,gorTEN_____,gorNINE____,gorFLOWER__,gorFLOWER__,gorK_______,gorJ_______",
        "gorCHEST___,gorA_______,gorQ_______,gorSTATUE__,gorNINE____,gorTEN_____,gorFROG____,gorK_______,gorJ_______,gorFRUIT___,gorFRUIT___,gorFRUIT___,gorA_______,gorJ_______,gorTEMPLE__,gorQ_______,gorK_______,gorFROG____,gorTEN_____,gorNINE____,gorFLOWER__,gorFLOWER__,gorFLOWER__,gorA_______,gorK_______,gorTEMPLE__,gorJ_______,gorQ_______,gorFRUIT___,gorFRUIT___,gorTEN_____,gorNINE____,gorFLOWER__,gorFLOWER__,gorK_______,gorJ_______",

        "gorJ_______,gorQ_______,gorGORILLA_,gorJ_______,gorQ_______,gorTEN_____,gorA_______,gorFRUIT___,gorFRUIT___,gorFRUIT___,gorK_______,gorQ_______,gorSTATUE__,gorA_______,gorNINE____,gorTEMPLE__,gorTEN_____,gorNINE____,gorFROG____,gorK_______,gorA_______,gorNINE____,gorK_______,gorQ_______,gorJ_______,gorGORILLA_,gorQ_______,gorJ_______,gorTEN_____,gorCHEST___,gorNINE____,gorK_______,gorFLOWER__,gorFLOWER__,gorFLOWER__,gorNINE____,gorA_______,gorCHEST___,gorNINE____,gorK_______,gorQ_______,gorFROG____",
        "gorQ_______,gorJ_______,gorGORILLA_,gorQ_______,gorJ_______,gorNINE____,gorK_______,gorFLOWER__,gorFLOWER__,gorFLOWER__,gorA_______,gorJ_______,gorSTATUE__,gorK_______,gorTEN_____,gorTEMPLE__,gorNINE____,gorTEN_____,gorFROG____,gorA_______,gorK_______,gorTEN_____,gorA_______,gorJ_______,gorQ_______,gorGORILLA_,gorJ_______,gorQ_______,gorNINE____,gorCHEST___,gorTEN_____,gorA_______,gorFRUIT___,gorFRUIT___,gorFRUIT___,gorTEN_____,gorK_______,gorCHEST___,gorTEN_____,gorA_______,gorJ_______,gorFROG____",
        "gorFLOWER__,gorFLOWER__,gorFLOWER__,gorJ_______,gorQ_______,gorGORILLAD,gorGORILLAE,gorJ_______,gorQ_______,gorTEMPLE__,gorTEN_____,gorA_______,gorGORILLAD,gorGORILLAE,gorTEN_____,gorA_______,gorFROG____,gorNINE____,gorJ_______,gorFRUIT___,gorFRUIT___,gorQ_______,gorK_______,gorFLOWER__,gorFLOWER__,gorFLOWER__,gorQ_______,gorA_______,gorTEN_____,gorGORILLAA,gorGORILLAB,gorGORILLAC,gorA_______,gorTEN_____,gorCHEST___,gorQ_______,gorK_______,gorFROG____,gorNINE____,gorJ_______,gorQ_______,gorTEMPLE__,gorK_______,gorNINE____,gorSTATUE__,gorJ_______,gorNINE____",
        "gorFRUIT___,gorFRUIT___,gorFRUIT___,gorQ_______,gorJ_______,gorGORILLAD,gorGORILLAE,gorQ_______,gorJ_______,gorTEMPLE__,gorNINE____,gorK_______,gorGORILLAD,gorGORILLAE,gorNINE____,gorK_______,gorFROG____,gorTEN_____,gorQ_______,gorFLOWER__,gorFLOWER__,gorJ_______,gorA_______,gorFRUIT___,gorFRUIT___,gorFRUIT___,gorJ_______,gorK_______,gorNINE____,gorGORILLAA,gorGORILLAB,gorGORILLAC,gorK_______,gorNINE____,gorCHEST___,gorJ_______,gorA_______,gorFROG____,gorTEN_____,gorQ_______,gorJ_______,gorTEMPLE__,gorA_______,gorTEN_____,gorSTATUE__,gorQ_______,gorTEN_____",
        "gorQ_______,gorA_______,gorGORILLA_,gorTEN_____,gorNINE____,gorCHEST___,gorJ_______,gorK_______,gorGORILLA_,gorJ_______,gorA_______,gorFRUIT___,gorFRUIT___,gorFRUIT___,gorK_______,gorQ_______,gorGORILLA_,gorNINE____,gorTEN_____,gorFLOWER__,gorFLOWER__,gorFLOWER__,gorK_______,gorA_______,gorSTATUE__,gorQ_______,gorJ_______,gorFROG____,gorTEN_____,gorNINE____,gorTEMPLE__,gorJ_______,gorK_______,gorGORILLA_,gorNINE____,gorQ_______,gorFRUIT___,gorFRUIT___,gorTEN_____,gorA_______,gorFLOWER__,gorFLOWER__,gorNINE____,gorA_______,gorTEMPLE__,gorTEN_____,gorQ_______,gorFROG____",
        "gorQ_______,gorA_______,gorGORILLAA,gorGORILLAB,gorGORILLAC,gorTEN_____,gorNINE____,gorCHEST___,gorJ_______,gorK_______,gorFRUIT___,gorFRUIT___,gorFRUIT___,gorK_______,gorQ_______,gorNINE____,gorTEN_____,gorFLOWER__,gorFLOWER__,gorFLOWER__,gorK_______,gorA_______,gorSTATUE__,gorQ_______,gorJ_______,gorFROG____,gorTEN_____,gorNINE____,gorTEMPLE__,gorJ_______,gorK_______,gorGORILLAD,gorGORILLAE,gorNINE____,gorQ_______,gorA_______,gorJ_______,gorFRUIT___,gorFRUIT___,gorTEN_____,gorA_______,gorFLOWER__,gorFLOWER__,gorNINE____,gorA_______,gorTEMPLE__,gorTEN_____,gorQ_______,gorFROG____",

        "gorA_______,gorNINE____,gorGORILLA_,gorA_______,gorNINE____,gorQ_______,gorK_______,gorFLOWER__,gorFLOWER__,gorFLOWER__,gorNINE____,gorJ_______,gorFRUIT___,gorFRUIT___,gorTEN_____,gorJ_______,gorK_______,gorFROG____,gorQ_______,gorK_______,gorA_______,gorTEMPLE__,gorTEN_____,gorQ_______,gorSTATUE__,gorNINE____,gorA_______,gorGORILLA_,gorNINE____,gorA_______,gorJ_______,gorCHEST___,gorNINE____,gorTEN_____,gorK_______,gorFLOWER__,gorFLOWER__,gorQ_______,gorK_______,gorJ_______,gorFROG____,gorQ_______,gorK_______,gorA_______,gorTEMPLE__,gorTEN_____,gorK_______,gorSTATUE__",
        "gorK_______,gorTEN_____,gorGORILLA_,gorK_______,gorTEN_____,gorJ_______,gorA_______,gorFRUIT___,gorFRUIT___,gorFRUIT___,gorTEN_____,gorQ_______,gorFLOWER__,gorFLOWER__,gorNINE____,gorQ_______,gorA_______,gorFROG____,gorJ_______,gorA_______,gorK_______,gorTEMPLE__,gorNINE____,gorJ_______,gorSTATUE__,gorTEN_____,gorK_______,gorGORILLA_,gorTEN_____,gorK_______,gorQ_______,gorCHEST___,gorTEN_____,gorNINE____,gorA_______,gorFRUIT___,gorFRUIT___,gorJ_______,gorA_______,gorQ_______,gorFROG____,gorJ_______,gorA_______,gorK_______,gorTEMPLE__,gorNINE____,gorA_______,gorSTATUE__",
        "gorQ_______,gorNINE____,gorSTATUE__,gorK_______,gorQ_______,gorFRUIT___,gorFRUIT___,gorFRUIT___,gorNINE____,gorA_______,gorGORILLAD,gorGORILLAE,gorNINE____,gorA_______,gorTEMPLE__,gorK_______,gorTEN_____,gorCHEST___,gorQ_______,gorTEN_____,gorFRUIT___,gorFRUIT___,gorFRUIT___,gorK_______,gorJ_______,gorGORILLAA,gorGORILLAB,gorGORILLAC,gorK_______,gorJ_______,gorSTATUE__,gorTEN_____,gorQ_______,gorFLOWER__,gorFLOWER__,gorJ_______,gorK_______,gorGORILLAD,gorGORILLAE,gorJ_______,gorK_______,gorFROG____,gorA_______,gorTEN_____,gorTEMPLE__,gorA_______,gorJ_______,gorFROG____",
        "gorJ_______,gorTEN_____,gorSTATUE__,gorA_______,gorJ_______,gorFLOWER__,gorFLOWER__,gorFLOWER__,gorTEN_____,gorK_______,gorGORILLAD,gorGORILLAE,gorTEN_____,gorK_______,gorTEMPLE__,gorA_______,gorNINE____,gorCHEST___,gorJ_______,gorNINE____,gorFLOWER__,gorFLOWER__,gorFLOWER__,gorA_______,gorQ_______,gorGORILLAA,gorGORILLAB,gorGORILLAC,gorA_______,gorQ_______,gorSTATUE__,gorNINE____,gorJ_______,gorFRUIT___,gorFRUIT___,gorQ_______,gorA_______,gorGORILLAD,gorGORILLAE,gorQ_______,gorA_______,gorFROG____,gorK_______,gorNINE____,gorTEMPLE__,gorK_______,gorQ_______,gorFROG____",
        "gorQ_______,gorA_______,gorGORILLA_,gorTEN_____,gorNINE____,gorCHEST___,gorJ_______,gorK_______,gorGORILLA_,gorJ_______,gorA_______,gorFRUIT___,gorFRUIT___,gorFRUIT___,gorK_______,gorQ_______,gorGORILLA_,gorNINE____,gorTEN_____,gorFLOWER__,gorFLOWER__,gorFLOWER__,gorK_______,gorA_______,gorSTATUE__,gorQ_______,gorJ_______,gorFROG____,gorTEN_____,gorNINE____,gorTEMPLE__,gorJ_______,gorK_______,gorGORILLA_,gorNINE____,gorQ_______,gorFRUIT___,gorFRUIT___,gorTEN_____,gorA_______,gorFLOWER__,gorFLOWER__,gorNINE____,gorA_______,gorTEMPLE__,gorTEN_____,gorQ_______,gorFROG____",
        "gorQ_______,gorA_______,gorGORILLAA,gorGORILLAB,gorGORILLAC,gorTEN_____,gorNINE____,gorCHEST___,gorJ_______,gorK_______,gorFRUIT___,gorFRUIT___,gorFRUIT___,gorK_______,gorQ_______,gorNINE____,gorTEN_____,gorFLOWER__,gorFLOWER__,gorFLOWER__,gorK_______,gorA_______,gorSTATUE__,gorQ_______,gorJ_______,gorFROG____,gorTEN_____,gorNINE____,gorTEMPLE__,gorJ_______,gorK_______,gorGORILLAD,gorGORILLAE,gorNINE____,gorQ_______,gorA_______,gorJ_______,gorFRUIT___,gorFRUIT___,gorTEN_____,gorA_______,gorFLOWER__,gorFLOWER__,gorNINE____,gorA_______,gorTEMPLE__,gorTEN_____,gorQ_______,gorFROG____",

        "gorTEN_____,gorK_______,gorGORILLA_,gorTEN_____,gorK_______,gorFRUIT___,gorFRUIT___,gorFRUIT___,gorNINE____,gorA_______,gorSTATUE__,gorQ_______,gorNINE____,gorTEMPLE__,gorA_______,gorJ_______,gorFROG____,gorQ_______,gorK_______,gorNINE____,gorQ_______,gorSTATUE__,gorJ_______,gorNINE____,gorA_______,gorQ_______,gorFROG____,gorK_______,gorTEN_____,gorGORILLA_,gorK_______,gorTEN_____,gorFLOWER__,gorFLOWER__,gorA_______,gorNINE____,gorQ_______,gorCHEST___,gorJ_______",
        "gorNINE____,gorA_______,gorGORILLA_,gorNINE____,gorA_______,gorFLOWER__,gorFLOWER__,gorFLOWER__,gorTEN_____,gorK_______,gorSTATUE__,gorJ_______,gorTEN_____,gorTEMPLE__,gorK_______,gorQ_______,gorFROG____,gorJ_______,gorA_______,gorTEN_____,gorJ_______,gorSTATUE__,gorQ_______,gorTEN_____,gorK_______,gorJ_______,gorFROG____,gorA_______,gorNINE____,gorGORILLA_,gorA_______,gorNINE____,gorFRUIT___,gorFRUIT___,gorK_______,gorTEN_____,gorJ_______,gorCHEST___,gorQ_______",
        "gorTEN_____,gorK_______,gorQ_______,gorTEN_____,gorFROG____,gorK_______,gorTEN_____,gorGORILLAD,gorGORILLAE,gorK_______,gorTEN_____,gorTEMPLE__,gorJ_______,gorQ_______,gorSTATUE__,gorJ_______,gorK_______,gorQ_______,gorFLOWER__,gorFLOWER__,gorFLOWER__,gorJ_______,gorNINE____,gorQ_______,gorGORILLAA,gorGORILLAB,gorGORILLAC,gorNINE____,gorQ_______,gorFROG____,gorTEN_____,gorA_______,gorJ_______,gorFRUIT___,gorFRUIT___,gorFRUIT___,gorTEN_____,gorJ_______,gorSTATUE__,gorK_______,gorA_______,gorCHEST___,gorTEN_____,gorJ_______,gorFRUIT___,gorFRUIT___",
        "gorNINE____,gorA_______,gorJ_______,gorNINE____,gorFROG____,gorA_______,gorNINE____,gorGORILLAD,gorGORILLAE,gorA_______,gorNINE____,gorTEMPLE__,gorQ_______,gorJ_______,gorSTATUE__,gorQ_______,gorA_______,gorJ_______,gorFRUIT___,gorFRUIT___,gorFRUIT___,gorQ_______,gorTEN_____,gorJ_______,gorGORILLAA,gorGORILLAB,gorGORILLAC,gorTEN_____,gorJ_______,gorFROG____,gorNINE____,gorK_______,gorQ_______,gorFLOWER__,gorFLOWER__,gorFLOWER__,gorNINE____,gorQ_______,gorSTATUE__,gorA_______,gorK_______,gorCHEST___,gorNINE____,gorQ_______,gorFLOWER__,gorFLOWER__",
        "gorQ_______,gorA_______,gorGORILLA_,gorTEN_____,gorNINE____,gorCHEST___,gorJ_______,gorK_______,gorGORILLA_,gorJ_______,gorA_______,gorFRUIT___,gorFRUIT___,gorFRUIT___,gorK_______,gorQ_______,gorGORILLA_,gorNINE____,gorTEN_____,gorFLOWER__,gorFLOWER__,gorFLOWER__,gorK_______,gorA_______,gorSTATUE__,gorQ_______,gorJ_______,gorFROG____,gorTEN_____,gorNINE____,gorTEMPLE__,gorJ_______,gorK_______,gorGORILLA_,gorNINE____,gorQ_______,gorFRUIT___,gorFRUIT___,gorTEN_____,gorA_______,gorFLOWER__,gorFLOWER__,gorNINE____,gorA_______,gorTEMPLE__,gorTEN_____,gorQ_______,gorFROG____",
        "gorQ_______,gorA_______,gorGORILLAA,gorGORILLAB,gorGORILLAC,gorTEN_____,gorNINE____,gorCHEST___,gorJ_______,gorK_______,gorFRUIT___,gorFRUIT___,gorFRUIT___,gorK_______,gorQ_______,gorNINE____,gorTEN_____,gorFLOWER__,gorFLOWER__,gorFLOWER__,gorK_______,gorA_______,gorSTATUE__,gorQ_______,gorJ_______,gorFROG____,gorTEN_____,gorNINE____,gorTEMPLE__,gorJ_______,gorK_______,gorGORILLAD,gorGORILLAE,gorNINE____,gorQ_______,gorA_______,gorJ_______,gorFRUIT___,gorFRUIT___,gorTEN_____,gorA_______,gorFLOWER__,gorFLOWER__,gorNINE____,gorA_______,gorTEMPLE__,gorTEN_____,gorQ_______,gorFROG____",

        "gorCHEST___,gorTEN_____,gorA_______,gorSTATUE__,gorNINE____,gorQ_______,gorFRUIT___,gorFRUIT___,gorFRUIT___,gorK_______,gorJ_______,gorFROG____,gorNINE____,gorA_______,gorSTATUE__,gorQ_______,gorJ_______,gorTEN_____,gorFLOWER__,gorFLOWER__,gorFLOWER__,gorTEN_____,gorA_______,gorJ_______,gorQ_______,gorTEMPLE__,gorK_______,gorTEN_____,gorQ_______,gorJ_______,gorFROG____,gorK_______,gorA_______,gorNINE____,gorK_______",
        "gorCHEST___,gorNINE____,gorK_______,gorSTATUE__,gorTEN_____,gorJ_______,gorFLOWER__,gorFLOWER__,gorFLOWER__,gorA_______,gorQ_______,gorFROG____,gorTEN_____,gorK_______,gorSTATUE__,gorJ_______,gorQ_______,gorNINE____,gorFRUIT___,gorFRUIT___,gorFRUIT___,gorNINE____,gorK_______,gorQ_______,gorJ_______,gorTEMPLE__,gorA_______,gorNINE____,gorJ_______,gorQ_______,gorFROG____,gorA_______,gorK_______,gorTEN_____,gorA_______",
        "gorCHEST___,gorTEN_____,gorNINE____,gorFROG____,gorA_______,gorSTATUE__,gorNINE____,gorTEN_____,gorFROG____,gorNINE____,gorTEN_____,gorSTATUE__,gorQ_______,gorA_______,gorFRUIT___,gorFRUIT___,gorFRUIT___,gorK_______,gorQ_______,gorTEMPLE__,gorTEN_____,gorNINE____,gorFRUIT___,gorFRUIT___,gorFRUIT___,gorJ_______,gorK_______,gorFLOWER__,gorFLOWER__,gorTEN_____,gorK_______,gorFROG____,gorJ_______,gorA_______,gorFLOWER__,gorFLOWER__,gorJ_______,gorQ_______",
        "gorCHEST___,gorNINE____,gorTEN_____,gorFROG____,gorK_______,gorSTATUE__,gorTEN_____,gorNINE____,gorFROG____,gorTEN_____,gorNINE____,gorSTATUE__,gorJ_______,gorK_______,gorFLOWER__,gorFLOWER__,gorFLOWER__,gorA_______,gorJ_______,gorTEMPLE__,gorNINE____,gorTEN_____,gorFLOWER__,gorFLOWER__,gorFLOWER__,gorQ_______,gorA_______,gorFRUIT___,gorFRUIT___,gorNINE____,gorA_______,gorFROG____,gorQ_______,gorK_______,gorFRUIT___,gorFRUIT___,gorQ_______,gorJ_______",
        "gorCHEST___,gorA_______,gorQ_______,gorSTATUE__,gorNINE____,gorTEN_____,gorFROG____,gorK_______,gorJ_______,gorFRUIT___,gorFRUIT___,gorFRUIT___,gorA_______,gorJ_______,gorTEMPLE__,gorQ_______,gorK_______,gorFROG____,gorTEN_____,gorNINE____,gorFLOWER__,gorFLOWER__,gorFLOWER__,gorA_______,gorK_______,gorTEMPLE__,gorJ_______,gorQ_______,gorFRUIT___,gorFRUIT___,gorTEN_____,gorNINE____,gorFLOWER__,gorFLOWER__,gorK_______,gorJ_______",
        "gorCHEST___,gorA_______,gorQ_______,gorSTATUE__,gorNINE____,gorTEN_____,gorFROG____,gorK_______,gorJ_______,gorFRUIT___,gorFRUIT___,gorFRUIT___,gorA_______,gorJ_______,gorTEMPLE__,gorQ_______,gorK_______,gorFROG____,gorTEN_____,gorNINE____,gorFLOWER__,gorFLOWER__,gorFLOWER__,gorA_______,gorK_______,gorTEMPLE__,gorJ_______,gorQ_______,gorFRUIT___,gorFRUIT___,gorTEN_____,gorNINE____,gorFLOWER__,gorFLOWER__,gorK_______,gorJ_______",
    };

    for (int i = 0; i < m_vecReelStripPlan.size(); i++) {
        ReelSet set;
        for (int j = 0; j < m_nReel; j++) {
            ReelStrip strip;
            std::stringstream ss(gorReelStrip[j * m_vecReelStripPlan.size() + i]);
            std::string item;
            while (std::getline(ss, item, ',')) {
                strip.push_back(item);
            }
            set.push_back(strip);
        }
        m_vecReelStripSets.push_back(set);
    }

    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_05_tmp;
    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_10_tmp;

    for (int i = 0; i < m_vecBetSteps_05_tmp.size(); i++) {
        std::map<std::string, std::map<UINT8, BONUS>> perSym;
        std::map<UINT8, BONUS> e;
        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 15; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 50; e[5].ag = 0;
        perSym["gorNINE____"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 15; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 50; e[5].ag = 0;
        perSym["gorTEN_____"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 15; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 50; e[5].ag = 0;
        perSym["gorJ_______"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 15; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 50; e[5].ag = 0;
        perSym["gorQ_______"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 15; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 50; e[5].ag = 0;
        perSym["gorK_______"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 15; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 50; e[5].ag = 0;
        perSym["gorA_______"] = e;
        e.clear();

        e[2].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 2; e[2].ag = 0;
        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 40; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 150; e[5].ag = 0;
        perSym["gorFLOWER__"] = e;
        e.clear();

        e[2].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 2; e[2].ag = 0;
        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 40; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 150; e[5].ag = 0;
        perSym["gorFRUIT___"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 75; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 250; e[5].ag = 0;
        perSym["gorFROG____"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 50; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 200; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 1000; e[5].ag = 0;
        perSym["gorSTATUE__"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 75; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 250; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 2000; e[5].ag = 0;
        perSym["gorCHEST___"] = e;
        e.clear();

        m_Bonus_05_tmp[i] = perSym;
    }

    m_Bonus_05_tmp[3]["gorCHEST___"][5].coin = 0; m_Bonus_05_tmp[3]["gorCHEST___"][5].ag = 12; // 30
    m_Bonus_05_tmp[4]["gorCHEST___"][5].coin = 0; m_Bonus_05_tmp[4]["gorCHEST___"][5].ag = 16; // 40
    m_Bonus_05_tmp[5]["gorCHEST___"][5].coin = 0; m_Bonus_05_tmp[5]["gorCHEST___"][5].ag = 20; // 50
    m_Bonus_05_tmp[5]["gorSTATUE__"][5].coin = 0; m_Bonus_05_tmp[5]["gorSTATUE__"][5].ag = 10;

    m_Bonus_05_tmp[6]["gorCHEST___"][5].coin = 0; m_Bonus_05_tmp[6]["gorCHEST___"][5].ag = 24; // 60
    m_Bonus_05_tmp[6]["gorSTATUE__"][5].coin = 0; m_Bonus_05_tmp[6]["gorSTATUE__"][5].ag = 12;

    m_Bonus_05_tmp[7]["gorCHEST___"][5].coin = 0; m_Bonus_05_tmp[7]["gorCHEST___"][5].ag = 32; // 80
    m_Bonus_05_tmp[7]["gorSTATUE__"][5].coin = 0; m_Bonus_05_tmp[7]["gorSTATUE__"][5].ag = 16;

    m_Bonus_05_tmp[8]["gorCHEST___"][5].coin = 0; m_Bonus_05_tmp[8]["gorCHEST___"][5].ag = 40; // 100
    m_Bonus_05_tmp[8]["gorSTATUE__"][5].coin = 0; m_Bonus_05_tmp[8]["gorSTATUE__"][5].ag = 20;
    m_Bonus_05_tmp[8]["gorFLOWER__"][5].coin = 0; m_Bonus_05_tmp[8]["gorFLOWER__"][5].ag = 3;
    m_Bonus_05_tmp[8]["gorFRUIT___"][5].coin = 0; m_Bonus_05_tmp[8]["gorFRUIT___"][5].ag = 3;

    m_Bonus_05_tmp[9]["gorCHEST___"][5].coin = 0; m_Bonus_05_tmp[9]["gorCHEST___"][5].ag = 80; // 200
    m_Bonus_05_tmp[9]["gorCHEST___"][4].coin = 0; m_Bonus_05_tmp[9]["gorCHEST___"][4].ag = 10; 
    m_Bonus_05_tmp[9]["gorSTATUE__"][5].coin = 0; m_Bonus_05_tmp[9]["gorSTATUE__"][5].ag = 40;
    m_Bonus_05_tmp[9]["gorFROG____"][5].coin = 0; m_Bonus_05_tmp[9]["gorFROG____"][5].ag = 10;
    m_Bonus_05_tmp[9]["gorFLOWER__"][5].coin = 0; m_Bonus_05_tmp[9]["gorFLOWER__"][5].ag = 6;
    m_Bonus_05_tmp[9]["gorFRUIT___"][5].coin = 0; m_Bonus_05_tmp[9]["gorFRUIT___"][5].ag = 6;
    
    m_Bonus_05_tmp[10]["gorCHEST___"][5].coin = 0; m_Bonus_05_tmp[10]["gorCHEST___"][5].ag = 100; // 500
    m_Bonus_05_tmp[10]["gorCHEST___"][4].coin = 0; m_Bonus_05_tmp[10]["gorCHEST___"][4].ag = 25; 
    m_Bonus_05_tmp[10]["gorSTATUE__"][5].coin = 0; m_Bonus_05_tmp[10]["gorSTATUE__"][5].ag = 100;
    m_Bonus_05_tmp[10]["gorSTATUE__"][4].coin = 0; m_Bonus_05_tmp[10]["gorSTATUE__"][4].ag = 20;
    m_Bonus_05_tmp[10]["gorFROG____"][5].coin = 0; m_Bonus_05_tmp[10]["gorFROG____"][5].ag = 25;
    m_Bonus_05_tmp[10]["gorFLOWER__"][5].coin = 0; m_Bonus_05_tmp[10]["gorFLOWER__"][5].ag = 15;
    m_Bonus_05_tmp[10]["gorFRUIT___"][5].coin = 0; m_Bonus_05_tmp[10]["gorFRUIT___"][5].ag = 15;
    m_Bonus_05_tmp[10]["gorFLOWER__"][4].coin = 0; m_Bonus_05_tmp[10]["gorFLOWER__"][4].ag = 4;
    m_Bonus_05_tmp[10]["gorFRUIT___"][4].coin = 0; m_Bonus_05_tmp[10]["gorFRUIT___"][4].ag = 4;
    m_Bonus_10_tmp = m_Bonus_05_tmp;

    int nSavedBetVal = 10;
    string data;
    PlayDB::GetInstance().LoadCheckPoint(m_strGameName, nSavedBetVal, m_nWinLine, m_strCheckPoint);
    if (nSavedBetVal == -1) {
        nSavedBetVal = 10;
    }
    if (m_nWinLine == -1) {
        m_nWinLine = 5;
    }

    BOOL start = FALSE;
    int idx = 0;
    for (int i = 0; i < m_vecBetSteps_05_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_05_tmp, i) < AT(m_vecBetSteps_05, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps_05, idx) == nSavedBetVal && m_nWinLine == 5) {
            m_nBetStep = idx;
        }

        m_Bonus_05[idx++] = m_Bonus_05_tmp[i];
        if (AT(m_vecBetSteps_05_tmp, i) == AT(m_vecBetSteps_05, m_vecBetSteps_05.size() - 1)) {
            break;
        }
    }
    start = FALSE;
    idx = 0;
    for (int i = 0; i < m_vecBetSteps_10_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_10_tmp, i) < AT(m_vecBetSteps_10, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps_10, idx) == nSavedBetVal && m_nWinLine == 10) {
            m_nBetStep = idx;
        }

        m_Bonus_10[idx++] = m_Bonus_10_tmp[i];
        if (AT(m_vecBetSteps_10_tmp, i) == AT(m_vecBetSteps_10, m_vecBetSteps_10.size() - 1)) {
            break;
        }
    }
    m_Bonus = (m_nWinLine == 5 ? m_Bonus_05 : m_Bonus_10);
    m_vecBetSteps = (m_nWinLine == 5 ? m_vecBetSteps_05 : m_vecBetSteps_10);

    PrintAllBonus();
}

UINT16 RgKongsTemple::Run() {
    m_nCurrentReelPlan = AT(g_RgKongsTemple_ReelsForBase, myRandom() % g_RgKongsTemple_ReelsForBase.size());
#ifdef TEST_FREE_MODE
    m_nCurrentReelPlan = 0;
#endif
    m_shCurrentReelStrip = static_cast<uint16_t>(std::stoi(AT(m_vecReelStripPlan, m_nCurrentReelPlan)));
    return m_shCurrentReelStrip;
}

void RgKongsTemple::ChangeReelStrip(UINT16 NewReelPlan) {
    m_nCurrentReelPlan = NewReelPlan;
    m_shCurrentReelStrip = static_cast<uint16_t>(std::stoi(AT(m_vecReelStripPlan, m_nCurrentReelPlan)));
}


myVector<UINT8> RgKongsTemple::Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) {
    m_nMagicCount = 0;
    m_bPrevSpinMatchedActive = FALSE;

    myVector<UINT8> result;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);

    if (bTest) {
        std::string matchSymbol = AT(m_vecSymbols, myRandom() % (m_vecSymbols.size() - 7));
        int line = (myRandom() % m_nWinLine);
        int weight = 1 + (myRandom() % 5);

        BOOL bForceFree = (myRandom() % 10 == 0);
        for (int i = 0; i < m_nReel; i++) {
            ReelStrip reelStrip = AT(reelSet, i);
            int len = reelStrip.size() - 3;

            int valid_i[0x100];
            int valid_count = 0;
            myVector<int> freeSymbols;
            for (int j = 0; j <= len; j++) {
                if (weight > i) {
                    if (matchSymbol == AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                else {
                    if (matchSymbol != AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                if (AT(reelStrip, j) == RgKongsTemple_scatter && m_bFreeMode == FALSE) {
                    freeSymbols.push_back(j);
                }
            }
            if (valid_count > 0) {
                int rand_index = myRandom() % valid_count;
                int chosen_i = valid_i[rand_index];
                result.push_back(chosen_i + 1);
            }
            else {
                result.push_back((myRandom() % (len - 1)) + 1);
            }
            {
                int pool[5] = { 0, 1, 2, 3, 4 };
                auto v = pickRandom2or3(pool, 5, 3);
                if (bForceFree && m_bFreeMode == FALSE && freeSymbols.size() > 0 && std::find(v.begin(), v.end(), i) != v.end()) {
                    AT(result, result.size() - 1) =
                        AT(freeSymbols, myRandom() % freeSymbols.size()) - (myRandom() % 3) + 1;
                }
            }
        }
    }
    else {
        result = _result;

        BOOL mmcode = mmcode_get_active_status();
        if (mmcode) {
            mmcode_set_deactive();
            if (m_bFreeMode == FALSE) {
                for (int j = 0; j < 5; j ++) {
                    myVector<int> candidateIndices;
                    for (int i = 2; i < AT(reelSet, j).size() - 3; ++i) {
                        if (j%2 == 0 && AT(AT(reelSet, j), i) == RgKongsTemple_scatter) {
                            int offset = myRandom() % 3;
                            int selectedIndex = i - 2 + offset;
                            candidateIndices.push_back(selectedIndex);
                        }
                        if (j%2 == 1 && AT(AT(reelSet, j), i) != RgKongsTemple_scatter
                                    && AT(AT(reelSet, j), i-2) != RgKongsTemple_scatter
                                    && AT(AT(reelSet, j), i-1) != RgKongsTemple_scatter
                                    && AT(AT(reelSet, j), i+1) != RgKongsTemple_scatter
                                    && AT(AT(reelSet, j), i+2) != RgKongsTemple_scatter) {
                            int offset = myRandom() % 3;
                            int selectedIndex = i - 2 + offset;
                            candidateIndices.push_back(selectedIndex);
                        }
                    }
                    if (!candidateIndices.empty()) {
#ifdef BIGBET_ACTIVE
                        int chosenIndex = AT(candidateIndices, (candidateIndices.size()<3?myRandom() % candidateIndices.size():myRandom() % 3));
#else
                        int chosenIndex = AT(candidateIndices, myRandom() % candidateIndices.size());
#endif
                        AT(result, j) = chosenIndex + 1;
                    }
                }
            }
        }
    }
    m_vWinResult = result;

    normalMeter = 0;
    maxMeter = 0;
    BONUS totalBonus = {0, 0};
    for (int i = 0; i < m_nWinLine; i++) {
        int j = 1;
        UINT16 meter = ((UINT16)1 << (2 - g_match_lines_10_5[i][0]));

        std::string firstSymbol = AT(AT(reelSet, 0), AT(result, 0) - 1 + g_match_lines_10_5[i][0]);
        for (; j < m_nMaxMatch; j++) {
            std::string prev_symbol = AT(AT(reelSet, j - 1), AT(result, j - 1) - 1 + g_match_lines_10_5[i][j - 1]);
            std::string cur_symbol = AT(AT(reelSet, j), AT(result, j) - 1 + g_match_lines_10_5[i][j]);

            if (IsWild(firstSymbol)) {
                firstSymbol = cur_symbol;
            }
            if (firstSymbol == cur_symbol || IsWild(cur_symbol)) {
                meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
                continue;
            }
            break;
        }

        if (j < m_mapSymbolMinMatch[firstSymbol] || m_mapSymbolMinMatch[firstSymbol] == 0) {
            continue;
        }

        // monitor 2 meter
        std::string meterStr = m_mapSymbolMeterGoc[firstSymbol];
        size_t pos = meterStr.find('$');
        if (pos != std::string::npos) {
            meterStr = meterStr.replace(pos, 1, std::to_string(j));
        }

        WinMeter e;
        e.line = i;
        e.meter = meter;
        e.meter2 = g_GrafficObjList.Str2GOCID(meterStr);
        e.symbol = firstSymbol;
        e.weight = j;
        e.start = 0;
        e.bonus.coin = m_Bonus[BetStep()][firstSymbol][j].coin * MultiFactor();
        e.bonus.ag = m_Bonus[BetStep()][firstSymbol][j].ag * MultiFactor();
        e.sound = MAX_SOUND_IDS;

        totalBonus.coin += e.bonus.coin;
        totalBonus.ag += e.bonus.ag;

        meters.push_back(e);        
        if (j == m_nMaxMatch) {
            maxMeter |= meter;
        }
        else {
            normalMeter |= meter;
        }
        if (bTest == FALSE) {
            m_bPrevSpinMatchedActive = TRUE;
        }
    }
    int nScatter = CardCount(RgKongsTemple_scatter);
    if (nScatter >= 3) {
        bCanFreeMode = TRUE;

        UINT16 meter = 0;
        for (int i = 0; i < 3; i++) {
            for (int col = 0; col < m_nReel; col++) {
                std::string cur_symbol = AT(AT(reelSet, col), AT(result, col) - 1 + i);
                if (cur_symbol == RgKongsTemple_scatter) {
                    meter |= ((UINT16)1 << (3 * col + (2 - i)));
                }
            }
        }

        WinMeter e;
        e.line = 10;
        e.meter = meter;
        e.meter2 = 0;
        e.symbol = RgKongsTemple_scatter;
        e.weight = nScatter;
        e.start = 0;
        e.bonus = {0, 0};
        e.sound = MAX_SOUND_IDS;

        normalMeter |= meter;
        meters.push_back(e);
        if (bTest == FALSE) {
            m_bPrevSpinMatchedActive = TRUE;
        }
    }
    m_vWinMeters = meters;
    m_nMagicCount = totalBonus.ag;
    if (bTest == FALSE) {
        updateCheckPoint();

        if (totalBonus.coin > 0 || totalBonus.ag > 0) {
            if (m_bFreeMode) {
                m_nFreeModeTotalBonus.coin += totalBonus.coin;
                m_nFreeModeTotalBonus.ag += totalBonus.ag;
            }
            BonusSound = getSoundByID(WinSound(totalBonus.coin + totalBonus.ag * 1000));
        }
        else {
            BonusSound.duration = 0;
            BonusSound.soundID = MAX_SOUND_IDS;
        }
    }
    return result;
}

BOOL RgKongsTemple::IsWild(std::string card) {
    if (card == "gorGORILLA_" ||
        card == "gorGORILLAA" ||
        card == "gorGORILLAB" ||
        card == "gorGORILLAC" ||
        card == "gorGORILLAD" ||
        card == "gorGORILLAE") {
        return TRUE;
    }
    return FALSE;
}

UINT16 RgKongsTemple::SpinTime_MS() {
    if (CardCount(RgKongsTemple_scatter) >= 3) {
        return 2500;
    }
    if (CardCount(RgKongsTemple_scatter) == 2 && TempleInCol(4) == FALSE) {
        return 2500;
    }
    return 2000;
}

int RgKongsTemple::LineSwapDelay(int WinIdx) {
    return 500;
}

UINT8 RgKongsTemple::GorCount() {
    const myVector<std::string> gorillaSymbols = {
        "gorGORILLA_", "gorGORILLAA", "gorGORILLAB",
        "gorGORILLAC", "gorGORILLAD", "gorGORILLAE"
    };
    UINT8 total = 0;
    for (int col = 0; col < 5; ++col) {
        for (const auto& symbol : gorillaSymbols) {
            if (CardNumInCol(col, symbol)) {
                ++total;
                break;
            }
        }
    }
    return total;
}

UINT8 RgKongsTemple::CardCount(std::string card) {
    int n = 0;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int col = 0; col < m_nReel; col++) {        
        int k = 0;
        for (; k < 3; k++) {
            std::string s = AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k);
            if (s == card) {
                n++;
            }
        }
    }
    return n;
}

UINT8 RgKongsTemple::MultiFactor() {
    int nGor = GorCount();
    nGor = min(nGor, 3);

    const UINT8 freeModeMultipliers[] = { 2, 4, 6, 8 };
    const UINT8 baseModeMultipliers[] = { 1, 2, 3, 4 };

    return m_bFreeMode ? freeModeMultipliers[nGor] : baseModeMultipliers[nGor];
}

BOOL RgKongsTemple::TempleInCol(int col) {
    return CardNumInCol(col, RgKongsTemple_scatter);
}

UINT8 RgKongsTemple::CardNumInCol(int col, std::string card) {
    int n = 0;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int k = 0; k < 3; k++) {
        std::string s = AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k);
        if (s == card) {
            n++;
        }
    }
    return n;
}

myVector<InterruptPacketData> RgKongsTemple::InterruptAfterSpin() {
    myVector<InterruptPacketData> packets;
    int nGor = GorCount();
    UINT8 nMulti = MultiFactor();
    if (nGor > 0 || m_bFreeMode) {
        UINT16 mask = 0;
        for (int i = 0; i < m_vWinMeters.size(); i++) {
            if (AT(m_vWinMeters, i).line < 10) { // avoid scatter match
                mask |= AT(m_vWinMeters, i).meter;
            }
        }
        int bitCount = std::bitset<16>(mask).count();
        if (bitCount > 0) {
            UINT16 delay = bitCount * 280;
            if (nGor >= 3 && m_bFreeMode) { // show x8 on top
                delay += 1800;
            }
            packets.push_back({
                0,
                delay,
                {0x01, 0x02, 0x28, 0x00, 0xde, 0x2c, 0x01, 0x00, 0x00, 0x00, 0x04} });
        }
    }
    return packets;
}

BOOL RgKongsTemple::CanFreeMode() {
    if (CardCount(RgKongsTemple_scatter) >= 3) {
        return TRUE;
    }    
    return FALSE;
}

myVector<InterruptPacketData> RgKongsTemple::EnterFreeGame(std::string check) {
    int n = 3;
    if (check == "") {
        n = CardCount(RgKongsTemple_scatter);
    }
    m_bFreeMode = TRUE;
    m_nFreeModeTotalSpin = 15;
    switch (n)
    {
    case 4:
        m_nFreeModeTotalSpin = 20;
        break;
    case 5:
        m_nFreeModeTotalSpin = 25;
        break;
    default:
        break;
    }
    m_nFreeModeGoneSpin = 0;
    m_nFreeModeTotalBonus = {0, 0};


    myVector<InterruptPacketData> packets;
    if (check != "") {
        myVector<int> values = ParseCheckPoint(check, "F", 4);
        if (values.size() == 4) {
            m_nFreeModeTotalSpin = AT(values, 0);
            m_nFreeModeGoneSpin = AT(values, 1);
            m_nFreeModeTotalBonus.coin = AT(values, 2);
            m_nFreeModeTotalBonus.ag = AT(values, 3);

            UINT8 gone = (m_nFreeModeGoneSpin ? m_nFreeModeGoneSpin : 1);
            packets.push_back({
                0, 0,
                {0x01, 0x02, 0x30, 0x00, 0xde, 0x2c, gone, 0x00, m_nFreeModeTotalSpin, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa3, 0x04} });
            return packets;
        }
    }
    else {
        updateCheckPoint();
    }

    // show freemode dialog
    packets.push_back({
        0, 6000,
        {0x01, 0x02, 0x30, 0x00, 0xde, 0x2c, 0x00, 0x00, m_nFreeModeGoneSpin, 0x00, m_nFreeModeTotalSpin, 0x00, 0x00, 0x00, 0xa6, 0x04} });
    // convert to freemode
    /*packets.push_back({
        0, 0,
        {0x01, 0x02, 0x30, 0x00, 0xde, 0x2c, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa8, 0x04} });*/
    packets.push_back({
        0, 6000,
        {0x01, 0x02, 0x28, 0x00, 0xde, 0x2c, 0x03, 0x00, 0x00, 0x00, 0x04} });
    
    // change reelstrip
    ChangeReelStrip(AT(g_RgKongsTemple_ReelsForFree, myRandom() % g_RgKongsTemple_ReelsForFree.size()));
    return packets;
}

myVector<InterruptPacketData> RgKongsTemple::InterruptBeforeSpin() {
    myVector<InterruptPacketData> packets;
    if (!m_bFreeMode) {
        return packets;
    }
    m_nFreeModeGoneSpin++;
    updateCheckPoint();

    UINT8 gone = (m_nFreeModeGoneSpin ? m_nFreeModeGoneSpin : 1);
    // display total & remain free spin count
    packets.push_back({
        0,
        0,
        {
            0x01, 0x02, 0x30, 0x00, 0xde, 0x2c, gone, 0x00, m_nFreeModeTotalSpin, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa5, 0x04
        }
        });    
    return packets;
}

myVector<InterruptPacketData> RgKongsTemple::InterruptAfterMoveBonus(BOOL& EndFree) {
    myVector<InterruptPacketData> packets;
    if (m_nFreeModeGoneSpin >= m_nFreeModeTotalSpin) {
        EndFree = TRUE;
        m_bFreeMode = FALSE;

        ChangeReelStrip(AT(g_RgKongsTemple_ReelsForBase, myRandom() % g_RgKongsTemple_ReelsForBase.size()));
        // return to main game
        packets.push_back({
            0,
            0,
            {0x01, 0x02, 0x30, 0x00, 0xde, 0x2c, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa4, 0x04} });
        // show freemode result dialog and return to main game
        packets.push_back({
            0,
            3000,
            {0x06, 0xde, 0x2c, 0x01, 0x02, 0x30, 0x00, 0xde, 0x2c, 0x00, 0x00, 
            static_cast<BYTE>(m_nFreeModeTotalBonus.coin & 0xFF), 
            static_cast<BYTE>((m_nFreeModeTotalBonus.coin >> 8) & 0xFF), 
            static_cast<BYTE>((m_nFreeModeTotalBonus.coin >> 16) & 0xFF),
            static_cast<BYTE>((m_nFreeModeTotalBonus.coin >> 24) & 0xFF),
            0x0f, 0x00, 0xab, 0x04} });

        updateCheckPoint();
        return packets;
    }
    EndFree = FALSE;
    //m_nFreeModeGoneSpin++;
    updateCheckPoint();

    return packets;
}

UINT16 RgKongsTemple::MagicCount() {
    if (m_bFreeMode) {
        return 0;
    }
    else {
        return m_nMagicCount;
    }
}

myVector<InterruptPacketData> RgKongsTemple::MousePressed(MousePosition p) {
    myVector<InterruptPacketData> packets;

    MousePosition a{
       {RgKongsTemple_MP_ChangeLine_LB_x_reel, RgKongsTemple_MP_ChangeLine_LB_x_pos },
       {RgKongsTemple_MP_ChangeLine_LB_y_row, RgKongsTemple_MP_ChangeLine_LB_y_pos }
    };
    MousePosition b{
        {RgKongsTemple_MP_ChangeLine_RT_x_reel, RgKongsTemple_MP_ChangeLine_RT_x_pos },
        {RgKongsTemple_MP_ChangeLine_RT_y_row, RgKongsTemple_MP_ChangeLine_RT_y_pos }
    };
    if (IsMouseWithin(p, a, b)) {
        m_nWinLine = (m_nWinLine == 5) ? 10 : 5;
        if (m_bPrevSpinMatchedActive) {
            // hide win lines
            packets.push_back({ 0, 0, {0x01, 0x02, 0x31, 0x00, 0x01, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x02, 0x00, 0x04} });
            m_bPrevSpinMatchedActive = FALSE;
        }
        UINT16 newBetValue = 0;
        if (m_nWinLine == 5) {
            m_Bonus = m_Bonus_05;
            m_vecBetSteps = m_vecBetSteps_05;
            newBetValue = AT(m_vecBetSteps_10, m_nBetStep) / 2;
            // lines
            packets.push_back({ 0, 0, {0x01, 0x02, 0x31, 0x00, 0x04, 0x00,
                static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x9d, 0x1f, 0x00, 0x00, 0x00, 0x04} });
        }
        else {
            m_Bonus = m_Bonus_10;
            m_vecBetSteps = m_vecBetSteps_10;
            newBetValue = AT(m_vecBetSteps_05, m_nBetStep) * 2;
            // lines
            packets.push_back({ 0, 0, {0x01, 0x02, 0x31, 0x00, 0x04, 0x00, static_cast<BYTE>(m_nGameID & 0xFF),
                static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x9d, 0xff, 0x03, 0x00, 0x00, 0x04} });
        }
        BOOL flag = FALSE;
        for (int i = 0; i < m_vecBetSteps.size(); i++) {
            if (AT(m_vecBetSteps, i) == newBetValue) {
                m_nBetStep = i;
                flag = TRUE;
                break;
            }
        }
        if (flag == FALSE) {
            m_nBetStep = 0;
        }
        // play button sound
        packets.push_back({ 0, 0, {0x01, 0x02, 0x34, 0x00, 0xf7, 0x00, 0x04} });
        // change line button
        packets.push_back({ 0, 0, {0x01, 0x02, 0x28, 0x00,
            static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), static_cast<BYTE>(m_nWinLine), 0x00, 0x00, 0x00, 0x04} });
        // set bet
        UINT16 bet = AT(m_vecBetSteps, m_nBetStep) / 5;
        packets.push_back({ 0, 0, {0x01, 0x02, 0x30, 0x00, 0x25, 0x53, 
            static_cast<BYTE>(bet & 0xFF), static_cast<BYTE>((bet >> 8) & 0xFF), 
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04, 0x04} });
    }
    return packets;
}

myVector<UINT8> RgKongsTemple::ShowTotalWinLines(myVector<WinMeter> SpinMeters) {
    myVector<uint8_t> packet = {
        0x06, 0x30, 0x59, 0x01, 0x02, 0x31, 0x00,
        0x0F, 0x00,  // Placeholder for length 
        0x0F, 0x11, // GameID
        0x9C, 0x19, 0x01
    };
    myVector<UINT8> TotalMatch;
    for (int i = 0; i < SpinMeters.size(); i++) {
        if (AT(SpinMeters, i).line == 0xFF) { // clear after convert action
            TotalMatch.clear();
            continue;
        }
        TotalMatch.push_back(AT(SpinMeters, i).line);
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter >> 8) & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter2 & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter2 >> 8) & 0xFF));
    }
    if (TotalMatch.size() < 10) {
        myVector<UINT8> _;
        return _;
    }
    UINT16 pktLen = 1 + (TotalMatch.size() / 5) * 7;
    AT(packet, 7) = static_cast<BYTE>(pktLen & 0xFF);
    AT(packet, 8) = static_cast<BYTE>((pktLen >> 8) & 0xFF);
    AT(packet, 9) = static_cast<BYTE>(m_nGameID & 0xFF);
    AT(packet, 10) = static_cast<BYTE>((m_nGameID >> 8) & 0xFF);
    int entryCount = static_cast<int>(TotalMatch.size() / 5);
    for (int i = 0; i < entryCount; ++i) {
        packet.push_back(AT(TotalMatch, i * 5 + 0)); // Line
        packet.push_back(AT(TotalMatch, i * 5 + 1)); // Meter low byte
        packet.push_back(AT(TotalMatch, i * 5 + 2)); // Meter high byte
        packet.push_back(AT(TotalMatch, i * 5 + 3)); // Meter2 low byte
        packet.push_back(AT(TotalMatch, i * 5 + 4)); // Meter2 high byte
        packet.push_back(0x01);      // Status or flag 1
        packet.push_back(0x01);      // Status or flag 2
    }
    // Mark the end of the packet
    packet.back() = 0x04;
    return packet;
}


BOOL RgKongsTemple::SelectedableReelsInFreeGame(myVector<UINT8> result) {
    if (m_bFreeMode == FALSE) {
        return TRUE;
    }
    myVector<UINT8> cp = m_vWinResult;
    m_vWinResult = result;
    int n = CardCount(RgKongsTemple_scatter);
    m_vWinResult = cp;
    if (n >= 3) {
        return FALSE;
    }
    return TRUE;
}

BOOL RgKongsTemple::NoFunInFreeMode() {
    return TRUE;
}

void RgKongsTemple::updateCheckPoint() {
    std::ostringstream oss;
    oss << " P" << m_nCurrentReelPlan
        << " B"
        << static_cast<int>(AT(m_vWinResult, 0)) << ":"
        << static_cast<int>(AT(m_vWinResult, 1)) << ":"
        << static_cast<int>(AT(m_vWinResult, 2)) << ":"
        << static_cast<int>(AT(m_vWinResult, 3)) << ":"
        << static_cast<int>(AT(m_vWinResult, 4)) << " ";

    if (m_bFreeMode) {
        oss << " F"
            << static_cast<int>(m_nFreeModeTotalSpin) << ":"
            << static_cast<int>(m_nFreeModeGoneSpin) << ":"
            << static_cast<int>(m_nFreeModeTotalBonus.coin) << ":"
            << static_cast<int>(m_nFreeModeTotalBonus.ag) << " ";
    }
    m_strCheckPoint = oss.str();
}