#pragma once

#include "ReelGame.h"

class RgExtraWild : public ReelGame
{
public:
	myVector<WinMeter> m_vWinMeters;
	std::map<UINT8, UINT8> m_mapWildMatch;

	RgExtraWild::RgExtraWild();

	UINT16 Run() override;
	myVector<UINT8> Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& WinSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) override;
	int LineSwapDelay(int WinIdx) override;
	myVector<InterruptPacketData> InterruptAfterSpin() override;

	myVector<UINT8> ShowTotalWinLines(myVector<WinMeter> SpinMeters) override;
	virtual myVector<InterruptPacketData> InterruptBeforeRisiko() override;
	myVector<InterruptPacketData> InterruptBeforeSpin() override;
};
