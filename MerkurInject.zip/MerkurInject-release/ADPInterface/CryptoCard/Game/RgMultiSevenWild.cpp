#include "stdafx.h"
#include "RgMultiSevenWild.h"

#define RgMultiSevenWild_MP_ChangeLine_LB_x_reel   0x02
#define RgMultiSevenWild_MP_ChangeLine_LB_x_pos    0xFA
#define RgMultiSevenWild_MP_ChangeLine_LB_y_row    0x02
#define RgMultiSevenWild_MP_ChangeLine_LB_y_pos    0x1C
#define RgMultiSevenWild_MP_ChangeLine_RT_x_reel   0x03
#define RgMultiSevenWild_MP_ChangeLine_RT_x_pos    0x46
#define RgMultiSevenWild_MP_ChangeLine_RT_y_row    0x02
#define RgMultiSevenWild_MP_ChangeLine_RT_y_pos    0x52

#define RgMultiSevenWild_wild "m7wSieben"

RgMultiSevenWild::RgMultiSevenWild() {
    m_nReel = 5;
    m_nWinLine = 5;
    m_nMaxMatch = 5;
    m_nBetStep = 0;

    m_strGameName = "RgMultiSevenWild";

    myVector<UINT16> m_vecBetSteps_05_tmp;
    myVector<UINT16> m_vecBetSteps_10_tmp;

    m_vecBetSteps_05_tmp.push_back(5);
    m_vecBetSteps_05_tmp.push_back(10);
    m_vecBetSteps_05_tmp.push_back(20);
    m_vecBetSteps_05_tmp.push_back(30);
    m_vecBetSteps_05_tmp.push_back(40);
    m_vecBetSteps_05_tmp.push_back(50);
    m_vecBetSteps_05_tmp.push_back(60);
    m_vecBetSteps_05_tmp.push_back(80);
    m_vecBetSteps_05_tmp.push_back(100);
    m_vecBetSteps_05_tmp.push_back(150);
    m_vecBetSteps_05_tmp.push_back(200);

    m_vecBetSteps_10_tmp.push_back(10);
    m_vecBetSteps_10_tmp.push_back(20);
    m_vecBetSteps_10_tmp.push_back(40);
    m_vecBetSteps_10_tmp.push_back(60);
    m_vecBetSteps_10_tmp.push_back(80);
    m_vecBetSteps_10_tmp.push_back(100);
    m_vecBetSteps_10_tmp.push_back(120);
    m_vecBetSteps_10_tmp.push_back(160);
    m_vecBetSteps_10_tmp.push_back(200);
    m_vecBetSteps_10_tmp.push_back(300);
    m_vecBetSteps_10_tmp.push_back(400);
#ifdef BIGBET_ACTIVE
    m_vecBetSteps_05_tmp.push_back(500);
    m_vecBetSteps_05_tmp.push_back(1000);
    m_vecBetSteps_10_tmp.push_back(1000);
    m_vecBetSteps_10_tmp.push_back(2000);
#endif
    LoadBets();

    m_vecBetSteps = m_vecBetSteps_05;

    m_vecSymbols.push_back("m7wSieben");
    m_vecSymbols.push_back("m7wMelone");
    m_vecSymbols.push_back("m7wTraube");
    m_vecSymbols.push_back("m7wPflaume");
    m_vecSymbols.push_back("m7wOrange");
    m_vecSymbols.push_back("m7wZitrone");
    m_vecSymbols.push_back("m7wKirsche");

    m_mapSymbolMinMatch["m7wMelone"] = 3;
    m_mapSymbolMinMatch["m7wTraube"] = 3;
    m_mapSymbolMinMatch["m7wPflaume"] = 3;
    m_mapSymbolMinMatch["m7wOrange"] = 3;
    m_mapSymbolMinMatch["m7wZitrone"] = 3;
    m_mapSymbolMinMatch["m7wKirsche"] = 3;

    m_vecWinLines.push_back("WinL1M7W");
    m_vecWinLines.push_back("WinL2M7W");
    m_vecWinLines.push_back("WinL3M7W");
    m_vecWinLines.push_back("WinL4M7W");
    m_vecWinLines.push_back("WinL5M7W");
    m_vecWinLines.push_back("WinL6M7W");
    m_vecWinLines.push_back("WinL7M7W");
    m_vecWinLines.push_back("WinL8M7W");
    m_vecWinLines.push_back("WinL9M7W");
    m_vecWinLines.push_back("WinL10M7W");

    //m_vecLineSounds.push_back(SMP_BS_Win5Part_1); // no line sound   

    m_vecWinSounds.push_back(SMP_musw_wild1_3e);
    m_vecWinSounds.push_back(SMP_musw_wild1_41e);
    m_vecWinSounds.push_back(SMP_musw_wild1_442e);
    m_vecWinSounds.push_back(SMP_musw_wild2_43e);

    m_vecReelStripPlan.push_back("Walze1M7W");
    m_vecReelStripPlan.push_back("Walze1M7W_DEMO"); // be needed estimate
    
    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));

    char* cfrtReelStrip[] = {
        "m7wOrange,m7wOrange,m7wOrange,m7wOrange,m7wOrange,m7wTraube,m7wTraube,m7wTraube,m7wTraube,m7wPflaume,m7wPflaume,m7wPflaume,m7wPflaume,m7wZitrone,m7wZitrone,m7wZitrone,m7wZitrone,m7wZitrone,m7wKirsche,m7wKirsche,m7wKirsche,m7wKirsche,m7wKirsche,m7wMelone,m7wMelone,m7wMelone,m7wPflaume,m7wPflaume,m7wPflaume,m7wPflaume,m7wTraube,m7wTraube,m7wTraube,m7wTraube,m7wOrange,m7wOrange,m7wOrange,m7wOrange,m7wMelone,m7wMelone,m7wMelone,m7wZitrone,m7wZitrone,m7wZitrone,m7wZitrone,m7wZitrone,m7wKirsche,m7wKirsche,m7wKirsche,m7wKirsche,m7wKirsche,m7wZitrone,m7wZitrone,m7wZitrone,m7wZitrone,m7wZitrone,m7wSieben",
        "m7wPflaume,m7wPflaume,m7wPflaume,m7wPflaume,m7wZitrone,m7wZitrone,m7wZitrone,m7wZitrone,m7wPflaume,m7wPflaume,m7wPflaume,m7wPflaume,m7wPflaume,m7wPflaume,m7wOrange,m7wOrange,m7wOrange,m7wOrange,m7wPflaume,m7wPflaume,m7wPflaume,m7wPflaume,m7wOrange,m7wOrange,m7wOrange,m7wOrange,m7wOrange,m7wKirsche,m7wKirsche,m7wKirsche,m7wKirsche,m7wKirsche,m7wSieben,m7wMelone,m7wMelone,m7wMelone,m7wMelone,m7wKirsche,m7wKirsche,m7wKirsche,m7wKirsche,m7wKirsche,m7wZitrone,m7wZitrone,m7wZitrone,m7wZitrone,m7wTraube,m7wTraube,m7wTraube,m7wTraube,m7wOrange,m7wOrange,m7wOrange,m7wOrange,m7wOrange,m7wKirsche,m7wKirsche,m7wKirsche,m7wKirsche,m7wKirsche",
        "m7wZitrone,m7wZitrone,m7wZitrone,m7wZitrone,m7wTraube,m7wTraube,m7wTraube,m7wTraube,m7wOrange,m7wOrange,m7wOrange,m7wOrange,m7wOrange,m7wTraube,m7wTraube,m7wTraube,m7wTraube,m7wTraube,m7wKirsche,m7wKirsche,m7wKirsche,m7wKirsche,m7wKirsche,m7wOrange,m7wOrange,m7wOrange,m7wOrange,m7wKirsche,m7wKirsche,m7wKirsche,m7wKirsche,m7wKirsche,m7wMelone,m7wMelone,m7wMelone,m7wOrange,m7wOrange,m7wOrange,m7wOrange,m7wOrange,m7wKirsche,m7wKirsche,m7wKirsche,m7wKirsche,m7wKirsche,m7wSieben,m7wZitrone,m7wZitrone,m7wZitrone,m7wZitrone,m7wZitrone,m7wTraube,m7wTraube,m7wTraube,m7wTraube,m7wTraube,m7wPflaume,m7wPflaume,m7wPflaume,m7wPflaume",
        "m7wMelone,m7wMelone,m7wMelone,m7wTraube,m7wTraube,m7wTraube,m7wTraube,m7wZitrone,m7wZitrone,m7wZitrone,m7wZitrone,m7wTraube,m7wTraube,m7wTraube,m7wTraube,m7wZitrone,m7wZitrone,m7wZitrone,m7wZitrone,m7wPflaume,m7wPflaume,m7wPflaume,m7wPflaume,m7wTraube,m7wTraube,m7wTraube,m7wTraube,m7wPflaume,m7wPflaume,m7wPflaume,m7wPflaume,m7wOrange,m7wOrange,m7wOrange,m7wOrange,m7wOrange,m7wSieben,m7wMelone,m7wMelone,m7wMelone,m7wMelone,m7wPflaume,m7wPflaume,m7wPflaume,m7wPflaume,m7wKirsche,m7wKirsche,m7wKirsche,m7wKirsche,m7wZitrone,m7wZitrone,m7wZitrone,m7wZitrone",
        "m7wKirsche,m7wKirsche,m7wKirsche,m7wKirsche,m7wOrange,m7wOrange,m7wOrange,m7wOrange,m7wKirsche,m7wKirsche,m7wKirsche,m7wKirsche,m7wKirsche,m7wZitrone,m7wZitrone,m7wZitrone,m7wZitrone,m7wMelone,m7wMelone,m7wMelone,m7wZitrone,m7wZitrone,m7wZitrone,m7wZitrone,m7wZitrone,m7wMelone,m7wMelone,m7wMelone,m7wZitrone,m7wZitrone,m7wZitrone,m7wZitrone,m7wZitrone,m7wSieben,m7wOrange,m7wOrange,m7wOrange,m7wOrange,m7wOrange,m7wPflaume,m7wPflaume,m7wPflaume,m7wPflaume,m7wKirsche,m7wKirsche,m7wKirsche,m7wKirsche,m7wKirsche,m7wTraube,m7wTraube,m7wTraube,m7wTraube,m7wOrange,m7wOrange,m7wOrange,m7wOrang",

        "m7wPflaume,m7wPflaume,m7wPflaume,m7wTraube,m7wTraube,m7wTraube,m7wOrange,m7wOrange,m7wOrange,m7wOrange,m7wMelone,m7wMelone,m7wMelone,m7wKirsche,m7wKirsche,m7wKirsche,m7wKirsche,m7wZitrone,m7wZitrone,m7wZitrone,m7wZitrone,m7wSieben",
        "m7wOrange,m7wOrange,m7wOrange,m7wOrange,m7wPflaume,m7wPflaume,m7wPflaume,m7wMelone,m7wMelone,m7wMelone,m7wZitrone,m7wZitrone,m7wZitrone,m7wZitrone,m7wKirsche,m7wKirsche,m7wKirsche,m7wKirsche,m7wSieben,m7wTraube,m7wTraube,m7wTraube",
        "m7wKirsche,m7wKirsche,m7wKirsche,m7wKirsche,m7wMelone,m7wMelone,m7wMelone,m7wTraube,m7wTraube,m7wTraube,m7wSieben,m7wOrange,m7wOrange,m7wOrange,m7wOrange,m7wPflaume,m7wPflaume,m7wPflaume,m7wZitrone,m7wZitrone,m7wZitrone,m7wZitrone",
        "m7wOrange,m7wOrange,m7wOrange,m7wOrange,m7wPflaume,m7wPflaume,m7wPflaume,m7wMelone,m7wMelone,m7wMelone,m7wZitrone,m7wZitrone,m7wZitrone,m7wZitrone,m7wKirsche,m7wKirsche,m7wKirsche,m7wKirsche,m7wSieben,m7wTraube,m7wTraube,m7wTraube",
        "m7wPflaume,m7wPflaume,m7wPflaume,m7wTraube,m7wTraube,m7wTraube,m7wOrange,m7wOrange,m7wOrange,m7wOrange,m7wMelone,m7wMelone,m7wMelone,m7wKirsche,m7wKirsche,m7wKirsche,m7wKirsche,m7wZitrone,m7wZitrone,m7wZitrone,m7wZitrone,m7wSieben",
    };

    int idx = 0;
    for (int i = 0; i < m_vecReelStripPlan.size(); i++) {
        ReelSet set;
        for (int j = 0; j < m_nReel; j++) {
            ReelStrip strip;
            std::stringstream ss(cfrtReelStrip[idx]);
            std::string item;
            while (std::getline(ss, item, ',')) {
                strip.push_back(item);
            }
            set.push_back(strip);
            idx++;
        }
        m_vecReelStripSets.push_back(set);
    }
        
    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_05_tmp;
    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_10_tmp;

    for (int i = 0; i < m_vecBetSteps_05_tmp.size(); i++) {
        std::map<std::string, std::map<UINT8, BONUS>> perSym;
        std::map<UINT8, BONUS> e;
        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 50; e[5].ag = 0;
        perSym["m7wKirsche"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 50; e[5].ag = 0;
        perSym["m7wZitrone"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[5].ag = 0;
        perSym["m7wOrange"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 40; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[5].ag = 0;
        perSym["m7wPflaume"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 40; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 200; e[5].ag = 0;
        perSym["m7wTraube"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 50; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 500; e[5].ag = 0;
        perSym["m7wMelone"] = e;
        e.clear();

        m_Bonus_05_tmp[i] = perSym;
    }

    m_Bonus_05_tmp[5]["m7wMelone"][5].coin = 0; m_Bonus_05_tmp[5]["m7wMelone"][5].ag = 5; // 50
    m_Bonus_05_tmp[6]["m7wMelone"][5].coin = 0; m_Bonus_05_tmp[6]["m7wMelone"][5].ag = 6; // 60
    m_Bonus_05_tmp[7]["m7wMelone"][5].coin = 0; m_Bonus_05_tmp[7]["m7wMelone"][5].ag = 8; // 80
    m_Bonus_05_tmp[8]["m7wMelone"][5].coin = 0; m_Bonus_05_tmp[8]["m7wMelone"][5].ag = 10; // 100
    m_Bonus_05_tmp[9]["m7wMelone"][5].coin = 0; m_Bonus_05_tmp[9]["m7wMelone"][5].ag = 15; // 150
    m_Bonus_05_tmp[9]["m7wTraube"][5].coin = 0; m_Bonus_05_tmp[9]["m7wTraube"][5].ag = 6;
    m_Bonus_05_tmp[10]["m7wMelone"][5].coin = 0; m_Bonus_05_tmp[10]["m7wMelone"][5].ag = 20; // 200
    m_Bonus_05_tmp[10]["m7wTraube"][5].coin = 0; m_Bonus_05_tmp[10]["m7wTraube"][5].ag = 8;
    m_Bonus_05_tmp[11]["m7wMelone"][5].coin = 0; m_Bonus_05_tmp[11]["m7wMelone"][5].ag = 50; // 500
    m_Bonus_05_tmp[11]["m7wMelone"][4].coin = 0; m_Bonus_05_tmp[11]["m7wMelone"][4].ag = 5; 
    m_Bonus_05_tmp[11]["m7wTraube"][5].coin = 0; m_Bonus_05_tmp[11]["m7wTraube"][5].ag = 20;
    m_Bonus_05_tmp[11]["m7wPflaume"][5].coin = 0; m_Bonus_05_tmp[11]["m7wPflaume"][5].ag = 10;
    m_Bonus_05_tmp[11]["m7wOrange"][5].coin = 0; m_Bonus_05_tmp[11]["m7wOrange"][5].ag = 10;
    m_Bonus_05_tmp[11]["m7wZitrone"][5].coin = 0; m_Bonus_05_tmp[11]["m7wZitrone"][5].ag = 5;
    m_Bonus_05_tmp[11]["m7wKirsche"][5].coin = 0; m_Bonus_05_tmp[11]["m7wKirsche"][5].ag = 5;
    m_Bonus_05_tmp[12]["m7wMelone"][5].coin = 0; m_Bonus_05_tmp[12]["m7wMelone"][5].ag = 100; // 1000
    m_Bonus_05_tmp[12]["m7wMelone"][4].coin = 0; m_Bonus_05_tmp[12]["m7wMelone"][4].ag = 10; 
    m_Bonus_05_tmp[12]["m7wTraube"][5].coin = 0; m_Bonus_05_tmp[12]["m7wTraube"][5].ag = 40;
    m_Bonus_05_tmp[12]["m7wTraube"][4].coin = 0; m_Bonus_05_tmp[12]["m7wTraube"][4].ag = 8;
    m_Bonus_05_tmp[12]["m7wPflaume"][5].coin = 0; m_Bonus_05_tmp[12]["m7wPflaume"][5].ag = 20;
    m_Bonus_05_tmp[12]["m7wPflaume"][4].coin = 0; m_Bonus_05_tmp[12]["m7wPflaume"][4].ag = 8;
    m_Bonus_05_tmp[12]["m7wOrange"][5].coin = 0; m_Bonus_05_tmp[12]["m7wOrange"][5].ag = 20;
    m_Bonus_05_tmp[12]["m7wZitrone"][5].coin = 0; m_Bonus_05_tmp[12]["m7wZitrone"][5].ag = 10;
    m_Bonus_05_tmp[12]["m7wKirsche"][5].coin = 0; m_Bonus_05_tmp[12]["m7wKirsche"][5].ag = 10;
    
    m_Bonus_10_tmp = m_Bonus_05_tmp;

    int nSavedBetVal = 10;
    string data;
    PlayDB::GetInstance().LoadCheckPoint(m_strGameName, nSavedBetVal, m_nWinLine, m_strCheckPoint);
    if (nSavedBetVal == -1) {
        nSavedBetVal = 10;
    }
    if (m_nWinLine == -1) {
        m_nWinLine = 5;
    }

    BOOL start = FALSE;
    idx = 0;
    for (int i = 0; i < m_vecBetSteps_05_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_05_tmp, i) < AT(m_vecBetSteps_05, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps_05, idx) == nSavedBetVal && m_nWinLine == 5) {
            m_nBetStep = idx;
        }

        m_Bonus_05[idx++] = m_Bonus_05_tmp[i];
        if (AT(m_vecBetSteps_05_tmp, i) == AT(m_vecBetSteps_05, m_vecBetSteps_05.size() - 1)) {
            break;
        }
    }
    start = FALSE;
    idx = 0;
    for (int i = 0; i < m_vecBetSteps_10_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_10_tmp, i) < AT(m_vecBetSteps_10, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps_10, idx) == nSavedBetVal && m_nWinLine == 10) {
            m_nBetStep = idx;
        }

        m_Bonus_10[idx++] = m_Bonus_10_tmp[i];
        if (AT(m_vecBetSteps_10_tmp, i) == AT(m_vecBetSteps_10, m_vecBetSteps_10.size() - 1)) {
            break;
        }
    }
    m_Bonus = (m_nWinLine == 5 ? m_Bonus_05 : m_Bonus_10);
    m_vecBetSteps = (m_nWinLine == 5 ? m_vecBetSteps_05 : m_vecBetSteps_10);
    PrintAllBonus();
}


BOOL RgMultiSevenWild::stopAllSoundBeforeMove() {
    return TRUE;
}

myVector<UINT8> RgMultiSevenWild::Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) {
    m_nMagicCount = 0;
    m_bPrevSpinMatchedActive = FALSE;
    m_nMaxWinWeight = 0;

    myVector<UINT8> result;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    BOOL mmcode = FALSE;
    if (bTest == FALSE) {
        mmcode = mmcode_get_active_status();
    }
    if (bTest == TRUE || mmcode == TRUE) {
        // avoid wild card (7)
        std::string matchSymbol = AT(m_vecSymbols, (myRandom() % (m_vecSymbols.size() - 1)) + 1);
        int line = (myRandom() % m_nWinLine);
        int weight = 1 + (myRandom() % 5);

        if (mmcode) {
            mmcode_set_deactive();
            weight = m_nMaxMatch;
            matchSymbol = "m7wMelone";
        }
        for (int i = 0; i < m_nReel; i++) {
            ReelStrip reelStrip = AT(reelSet, i);
            int len = reelStrip.size() - 3;

            int valid_i[0x100];
            int valid_count = 0;
            for (int j = 0; j <= len; j++) {
                if (weight > i) {
                    if (matchSymbol == AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                else {
                    if (matchSymbol != AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
            }
            if (valid_count > 0) {
                int rand_index = myRandom() % valid_count;
                int chosen_i = valid_i[rand_index];
                result.push_back(chosen_i + 1);
            }
            else {
                result.push_back((myRandom() % (len - 1)) + 1);
            }
        }

        if ((myRandom() % 3) == 0 && mmcode == FALSE) {
            int reel = 1 + (myRandom() % 3);
            ReelStrip reelStrip = AT(reelSet, reel);
            for (int i = 3; i < reelStrip.size() - 2; i++) {
                if (AT(reelStrip, i) == RgMultiSevenWild_wild) {
                    AT(result, reel) = i - (myRandom() % 3) + 1;
                    break;
                }
            }
        }
    }
    else {
        result = _result;
    }

#ifdef TEST_WILDCARD
    result.clear();
    result.push_back(1);
    result.push_back(31);
    result.push_back(45);
    result.push_back(1);
    result.push_back(32);
#endif

    std::map<std::string, UINT16> meter2Map;
    meter2Map["m7wKirschex3"] = 0x13;
    meter2Map["m7wKirschex4"] = 0x12;
    meter2Map["m7wKirschex5"] = 0x11;
    meter2Map["m7wZitronex3"] = 0x10;
    meter2Map["m7wZitronex4"] = 0x0f;
    meter2Map["m7wZitronex5"] = 0x0e;
    meter2Map["m7wOrangex3"] = 0x0d;
    meter2Map["m7wOrangex4"] = 0x0c;
    meter2Map["m7wOrangex5"] = 0x0b;
    meter2Map["m7wPflaumex3"] = 0x0a;
    meter2Map["m7wPflaumex4"] = 0x09;
    meter2Map["m7wPflaumex5"] = 0x08;
    meter2Map["m7wTraubex3"] = 0x07;
    meter2Map["m7wTraubex4"] = 0x06;
    meter2Map["m7wTraubex5"] = 0x05;
    meter2Map["m7wMelonex3"] = 0x04;
    meter2Map["m7wMelonex4"] = 0x03;
    meter2Map["m7wMelonex5"] = 0x02;
    meter2Map["m7wSiebenx5"] = 0x01;

    // ag
    //if (!bTest) {
    //    TEST_REEL5_SYMBOLS(result, 24, 34, 33, 1, 18);
    //}
    m_vWinResult = result;

    normalMeter = 0;
    maxMeter = 0;
    BONUS totalBonus = {0, 0};
    for (int i = 0; i < m_nWinLine; i++) {
        int j = 1;
        UINT16 meter = ((UINT16)1 << (2 - g_match_lines_10_5[i][0]));

        std::string firstSymbol = AT(AT(reelSet, 0), AT(result, 0) - 1 + g_match_lines_10_5[i][0]);

        for (; j < m_nMaxMatch; j++) {
            std::string prev_symbol = AT(AT(reelSet, j - 1), AT(result, j - 1) - 1 + g_match_lines_10_5[i][j - 1]);
            std::string cur_symbol = AT(AT(reelSet, j), AT(result, j) - 1 + g_match_lines_10_5[i][j]);

            if (WildcountInCol(j)) {
                meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
                continue;
            }

            if (firstSymbol == RgMultiSevenWild_wild) { // scatter
                firstSymbol = cur_symbol;
            }

            if (firstSymbol == cur_symbol) {
                meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
                continue;
            }
            break;
        }

        if (j < m_mapSymbolMinMatch[firstSymbol] || m_mapSymbolMinMatch[firstSymbol] == 0) {
            continue;
        }
        
        // monitor 2 meter
        WinMeter e;
        e.line = i;
        e.meter = meter;
        e.meter2 = meter2Map[firstSymbol + "x" + std::to_string(j)];
        e.symbol = firstSymbol;
        e.weight = j;
        e.start = 0;
        e.bonus = m_Bonus[BetStep()][firstSymbol][j];
        e.sound = MAX_SOUND_IDS;

        m_nMaxWinWeight = max(j, m_nMaxWinWeight);

        totalBonus.coin += e.bonus.coin;
        totalBonus.ag += e.bonus.ag;

        if (e.meter2 != -1) {
            meters.push_back(e);
        }
        if (j == m_nMaxMatch) {
            maxMeter |= meter;
        }
        else {
            normalMeter |= meter;
        }

        if (bTest == FALSE) {
            m_bPrevSpinMatchedActive = TRUE;
        }
    }
    m_nMagicCount = totalBonus.ag;
    if (bTest == FALSE) {
        m_vWinResult = result;
        updateCheckPoint();
    }
    if (totalBonus.coin > 0 || totalBonus.ag > 0) {
        BonusSound = getSoundByID(WinSound(totalBonus.coin + totalBonus.ag * 1000));
    }
    return result;
}

BOOL RgMultiSevenWild::PlayBonusSoundAfterWinLine() {
    return TRUE;
}

int RgMultiSevenWild::LineSwapDelay(int WinIdx) {
    return 400;
}

BOOL RgMultiSevenWild::WildcountInCol(UINT8 col) {
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    // check wild symbol
    int k = 0;
    for (; k < 3; k++) {
        std::string s = AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k);
        if (s == RgMultiSevenWild_wild) {
            return TRUE;
        }
    }
    return FALSE;
}

UINT8 RgMultiSevenWild::Wildcount() {
    UINT8 n = 0;
    for (int i = 0; i < m_nReel; i++) {
        if (WildcountInCol(i)) {
            n++;
        }
    }
    return n;
}

UINT16 RgMultiSevenWild::SpinTime_MS() {
    return 2500;
}

myVector<InterruptPacketData> RgMultiSevenWild::InterruptAfterSpin() {
    myVector<InterruptPacketData> packets;
    
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    int offset = 0;

    UINT16 wildMask = 0;
    for (int col = 0; col < m_nReel; col++) {
        for (int k = 2; k >= 0; k--) {
            std::string symbol = AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k);
            if (symbol == RgMultiSevenWild_wild) {
                wildMask |= (1 << offset);
            }
            offset++;
        }
    }
    if (wildMask > 0) {
        // span wild card (7)        
        //0x01, 0x02, 0x30, 0x00, 0x5a, 0x34, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xb4, 0x04 // 1 top
        //0x01, 0x02, 0x30, 0x00, 0x5a, 0x34, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xb4, 0x04 // 1 middle
        //0x01, 0x02, 0x30, 0x00, 0x5a, 0x34, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xb4, 0x04 // 1 bottom
        //0x01, 0x02, 0x30, 0x00, 0x5a, 0x34, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xb4, 0x04 // 2 top
        //0x01, 0x02, 0x30, 0x00, 0x5a, 0x34, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xb4, 0x04 // 2 middle
        //0x01, 0x02, 0x30, 0x00, 0x5a, 0x34, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xb4, 0x04 // 2 bottom
        //0x01, 0x02, 0x30, 0x00, 0x5a, 0x34, 0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xb4, 0x04 // 3 top
        //0x01, 0x02, 0x30, 0x00, 0x5a, 0x34, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xb4, 0x04 // 3 middle
        //0x01, 0x02, 0x30, 0x00, 0x5a, 0x34, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xb4, 0x04 // 3 bottom
        //0x01, 0x02, 0x30, 0x00, 0x5a, 0x34, 0x00, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xb4, 0x04 // 4 top
        //0x01, 0x02, 0x30, 0x00, 0x5a, 0x34, 0x00, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xb4, 0x04 // 4 middle
        //0x01, 0x02, 0x30, 0x00, 0x5a, 0x34, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xb4, 0x04 // 4 bottom
        //0x01, 0x02, 0x30, 0x00, 0x5a, 0x34, 0x00, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xb4, 0x04 // 5 top
        //0x01, 0x02, 0x30, 0x00, 0x5a, 0x34, 0x00, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xb4, 0x04 // 5 middle
        //0x01, 0x02, 0x30, 0x00, 0x5a, 0x34, 0x00, 0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xb4, 0x04 // 5 bottom
        
        // expand wild card with ani
        UINT8 showAni = (m_nMaxWinWeight >= 3 ? 0x01 : 0x00);
        packets.push_back({
            0,
            2200,
            {
                0x01, 0x02, 0x30, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), static_cast<BYTE>(wildMask & 0xFF), static_cast<BYTE>((wildMask >> 8) & 0xFF), 0x00, 0x00, 0x00, 0x00, showAni, 0x00, 0xb4, 0x04
            }
            });
        
        // show multi wild border
        packets.push_back({
            0,
            0,
            {
                0x01, 0x02, 0x30, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xb5, 0x04
            }
            });

    }
    return packets;
}

UINT16 RgMultiSevenWild::MagicCount() {
    return m_nMagicCount;
}

myVector<InterruptPacketData> RgMultiSevenWild::MousePressed(MousePosition p) {
    myVector<InterruptPacketData> packets;

    MousePosition a{
       {RgMultiSevenWild_MP_ChangeLine_LB_x_reel, RgMultiSevenWild_MP_ChangeLine_LB_x_pos },
       {RgMultiSevenWild_MP_ChangeLine_LB_y_row, RgMultiSevenWild_MP_ChangeLine_LB_y_pos }
    };
    MousePosition b{
        {RgMultiSevenWild_MP_ChangeLine_RT_x_reel, RgMultiSevenWild_MP_ChangeLine_RT_x_pos },
        {RgMultiSevenWild_MP_ChangeLine_RT_y_row, RgMultiSevenWild_MP_ChangeLine_RT_y_pos }
    };
    if (IsMouseWithin(p, a, b)) {
        m_nWinLine = (m_nWinLine == 5) ? 10 : 5;
        if (m_bPrevSpinMatchedActive) {
            // hide win lines
            packets.push_back({ 0, 0, {0x01, 0x02, 0x31, 0x00, 0x01, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x02, 0x00, 0x04} });
            m_bPrevSpinMatchedActive = FALSE;
        }
        UINT16 newBetValue = 0;
        if (m_nWinLine == 5) {
            m_Bonus = m_Bonus_05;
            m_vecBetSteps = m_vecBetSteps_05;
            newBetValue = AT(m_vecBetSteps_10, m_nBetStep) / 2;
            // lines
            packets.push_back({ 0, 0, {0x01, 0x02, 0x31, 0x00, 0x04, 0x00,
                static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x9d, 0x1f, 0x00, 0x00, 0x00, 0x04} });
        }
        else {
            m_Bonus = m_Bonus_10;
            m_vecBetSteps = m_vecBetSteps_10;
            newBetValue = AT(m_vecBetSteps_05, m_nBetStep) * 2;
            // lines
            packets.push_back({ 0, 0, {0x01, 0x02, 0x31, 0x00, 0x04, 0x00, static_cast<BYTE>(m_nGameID & 0xFF),
                static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x9d, 0xff, 0x03, 0x00, 0x00, 0x04} });
        }
        BOOL flag = FALSE;
        for (int i = 0; i < m_vecBetSteps.size(); i++) {
            if (AT(m_vecBetSteps, i) == newBetValue) {
                m_nBetStep = i;
                flag = TRUE;
                break;
            }
        }
        if (flag == FALSE) {
            m_nBetStep = 0;
        }
        // play button sound
        packets.push_back({ 0, 0, {0x01, 0x02, 0x34, 0x00, 0xf7, 0x00, 0x04} });
        // change line button
        packets.push_back({ 0, 0, {0x01, 0x02, 0x28, 0x00,
            static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), static_cast<BYTE>(m_nWinLine), 0x00, 0x00, 0x00, 0x04} });
        // set bet
        UINT16 bet = AT(m_vecBetSteps, m_nBetStep) / 5;
        packets.push_back({ 0, 0, {0x01, 0x02, 0x30, 0x00, 0x25, 0x53, 
            static_cast<BYTE>(bet & 0xFF), static_cast<BYTE>((bet >> 8) & 0xFF), 
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04, 0x04} });
    }
    return packets;
}

myVector<UINT8> RgMultiSevenWild::ShowTotalWinLines(myVector<WinMeter> SpinMeters) {
    myVector<uint8_t> packet = {
        0x06, 0x30, 0x59, 0x01, 0x02, 0x31, 0x00,
        0x0F, 0x00,  // Placeholder for length 
        0x0F, 0x11, // GameID
        0x9C, 0x19, 0x01
    };
    myVector<UINT8> TotalMatch;
    for (int i = 0; i < SpinMeters.size(); i++) {
        if (AT(SpinMeters, i).line == 0xFF) { // clear after convert action
            TotalMatch.clear();
            continue;
        }
        TotalMatch.push_back(AT(SpinMeters, i).line);
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter >> 8) & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter2 & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter2 >> 8) & 0xFF));
    }
    if (TotalMatch.size() < 10) {
        myVector<UINT8> _;
        return _;
    }
    UINT16 pktLen = 1 + (TotalMatch.size() / 5) * 7;
    AT(packet, 7) = static_cast<BYTE>(pktLen & 0xFF);
    AT(packet, 8) = static_cast<BYTE>((pktLen >> 8) & 0xFF);
    AT(packet, 9) = static_cast<BYTE>(m_nGameID & 0xFF);
    AT(packet, 10) = static_cast<BYTE>((m_nGameID >> 8) & 0xFF);
    int entryCount = static_cast<int>(TotalMatch.size() / 5);
    for (int i = 0; i < entryCount; ++i) {
        packet.push_back(AT(TotalMatch, i * 5 + 0)); // Line
        packet.push_back(AT(TotalMatch, i * 5 + 1)); // Meter low byte
        packet.push_back(AT(TotalMatch, i * 5 + 2)); // Meter high byte
        packet.push_back(AT(TotalMatch, i * 5 + 3)); // Meter2 low byte
        packet.push_back(AT(TotalMatch, i * 5 + 4)); // Meter2 high byte
        packet.push_back(0x01);      // Status or flag 1
        packet.push_back(0x01);      // Status or flag 2
    }
    // Mark the end of the packet
    packet.back() = 0x04;
    return packet;
}

bool RgMultiSevenWild::RTP_force_bigWin() {
    return (myRandom() % 100 == 0); // 1%
}
