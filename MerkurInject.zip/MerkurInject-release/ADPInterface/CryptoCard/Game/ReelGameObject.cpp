#include "stdafx.h"

#include "RgFruitinator.h"
#include "RgBlazingStar.h"
#include "RgHotFrootastic.h"
#include "RgMerkurMagnus.h"
#include "RgEyeOfHorus.h"
#include "RgMultiSevenWild.h"
#include "RgElToreroMG.h"
#include "RgGoldCup.h"
#include "RgIndianRuby.h"
#include "RgDragonsTreas.h"
#include "RgMagicMirrorDeluxe2.h"
#include "RgDoubleBook.h"
#include "RgMultiWild243.h"
#include "RgJokersCap.h"
#include "RgGongHei.h"
#include "RgGl.h"
#include "RgTripleTripleChance.h"
#include "RgConvertusAurum.h"
#include "RgPyramidsDeluxe.h"
#include "RgBookOfFire.h"
#include "RgLegacyOfFire.h"
#include "RgExtraWild.h"
#include "RgRisingLiner.h"
#include "RgTotemChiefPlus.h"
#include "RgPyramidOfPower.h"
#include "RgKeyOfTheNile.h"
#include "RgKongsTemple.h"
#include "RgLosFrootos.h"
#include "RgPharosGoldBase.h"
#include "RgCairoCasino.h"

ReelGame* g_ReelGame = NULL;
ReelGame* g_ReelGameTmp = NULL;
ReelGame* CreateReelGameObject(UINT16 GameID) {
    ReelGame* tmp = NULL;
    if (GOC_RgFruitinator == GameID) {
        tmp = new RgFruitinator();
    }
    else if (GOC_RgBlazingSun == GameID) {
        tmp = new RgBlazingSun();
    }
    else if (GOC_RgHotFrootastic == GameID) {
        tmp = new RgHotFrootastic();
    }
    else if (GOC_RgMerkurMagnus == GameID) {
        tmp = new RgMerkurMagnus();
    }
    else if (GOC_RgEyeOfHorus == GameID) {
        tmp = new RgEyeOfHorus();
    }
    else if (GOC_RgMultiSevenWild == GameID) {
        tmp = new RgMultiSevenWild();
    }
    else if (GOC_RgElToreroMG == GameID) {
        tmp = new RgElToreroMG();
    }
    else if (GOC_RgGoldCup == GameID) {
        tmp = new RgGoldCup();
    }
    else if (GOC_RgIndianRuby == GameID) {
        tmp = new RgIndianRuby();
    }
    else if (GOC_RgDragonsTreas == GameID) {
        tmp = new RgDragonsTreas();
    }
    else if (GOC_RgMagicMirrorDeluxe2 == GameID) {
        tmp = new RgMagicMirrorDeluxe2();
    }
    else if (GOC_RgDoubleBook == GameID) {
        tmp = new RgDoubleBook();
    }
    else if (GOC_RgMultiWild243 == GameID) {
        tmp = new RgMultiWild243();
    }
    else if (GOC_RgJokersCap == GameID) {
        tmp = new RgJokersCap();
    }
    else if (GOC_RgGongHei == GameID) {
        tmp = new RgGongHei();
    }
    else if (GOC_RgGl == GameID) {
        tmp = new RgGl();
    }
    else if (GOC_RgTripleTripleChance == GameID) {
        tmp = new RgTripleTripleChance();
    }
    else if (GOC_RgConvertusAurum == GameID) {
        tmp = new RgConvertusAurum();
    }
    else if (GOC_RgPyramidsDeluxe == GameID) {
        tmp = new RgPyramidsDeluxe();
    }
    else if (GOC_RgBookOfFire == GameID) {
        tmp = new RgBookOfFire();
    }
    else if (GOC_RgLegacyOfFire == GameID) {
        tmp = new RgLegacyOfFire();
    }
    else if (GOC_RgExtraWild == GameID) {
        tmp = new RgExtraWild();
    }
    else if (GOC_RgRisingLiner == GameID) {
        tmp = new RgRisingLiner();
    }
    else if (GOC_RgTotemChiefPlus == GameID) {
        tmp = new RgTotemChiefPlus();
    }
    else if (GOC_RgPyramidOfPower == GameID) {
        tmp = new RgPyramidOfPower();
    }
    else if (GOC_RgKeyOfTheNile == GameID) {
        tmp = new RgKeyOfTheNile();
    }
    else if (GOC_RgKongsTemple == GameID) {
        tmp = new RgKongsTemple();
    }
    else if (GOC_RgLosFrootos == GameID) {
        tmp = new RgLosFrootos();
    }
    else if (GOC_RgCairoCasino == GameID) {
        tmp = new RgCairoCasino();
    }    
    else if (GOC_RgPharosGoldBase == GameID) {
        tmp = new RgPharosGoldBase();
    }
    
    if (tmp) {
        tmp->SetGameID(GameID);
    }
    return tmp;
}

UINT16 gReelGameGOCs[] = {
    2, // RgBookOfDead
    152, // RgPrinceOfDead
    319, // RgCrazyMoney
    392, // RgElementsOfCrime
    494, // RgWildCobra
    645, // RgCarnevaleVenezia
    706, // RgJFr
    752, // RgSpL
    792, // RgMawi
    945, // RgFrSl
    954, // RgBadlandsBounty
    1038, // RgBoombastic
    1214, // RgCairoCasino
    1307, // RgDragonsTreasII
    1412, // RgKaBoom
    1467, // RgKeyOfTheNile
    1624, // RgMovingMoments
    1713, // RgPrimalFearVideo
    1846, // RgSnowWolf
    1954, // RgFinalFrontier
    2096, // RgFIFI
    2146, // RgJestersFollies
    2202, // RgRaceToWin
    2264, // RgUpDownFruits
    2320, // RgPyramidsDeluxe
    2393, // RgSpinAWinner
    2508, // RgCatChing
    2684, // RgDarkTowers
    2920, // RgLosFrootos
    2921, // RgLosFrootosPS1
    2922, // RgLosFrootosPS2
    2923, // RgLosFrootosPS3
    2924, // RgLosFrootosPS4
    3073, // RgGCVampiresII
    3199, // RgGCElTorero
    3306, // RgAchilla
    3372, // RgAllesSpitze
    3441, // RgAlduinAndCeldor
    3630, // RgAllesSpitzeXL
    3694, // RgAmuTep
    3806, // RgAnuris
    3914, // RgBallarat
    4108, // RgTheBeamTeam
    4167, // RgBlackHole
    4367, // RgBlazingSun
    4368, // RgBlazingSun_p
    4369, // tri1RgBlazingSun
    4370, // tri2RgBlazingSun
    4456, // RgBonP
    4463, // RgBookOfFire
    4549, // RgBookOfLuxorWild
    4657, // RgBlazingSunMG
    4685, // RgBurningHeat
    4774, // RgCaptainStack
    4862, // RgCloneBonus
    5033, // RgRDr
    5051, // RgConvertusAurum
    5191, // RgCRU
    5339, // RgCSIDallas
    5354, // RgCyborgTowers
    5484, // RgDiscoFever
    5553, // RgDragonsFlame
    5635, // RgDoubleBook
    5780, // RgDiamondFruits
    5825, // RgDiamondWild
    5870, // RgHunterOfDragons
    6011, // RgDRI
    6071, // RgDragonsTreas
    6164, // RgDragonsTreasMG
    6204, // RgDoubleTripleChance
    6271, // RgEaglePeaks
    6440, // RgExtraLiner
    6485, // RgExtraLiner10L
    6517, // RgElephants
    6580, // RgElToreroMG
    6664, // RgEyeOfHorus
    6665, // RgEyeOfHorus_p
    6666, // tri1RgEyeOfHorus
    6667, // tri2RgEyeOfHorus
    6767, // RgEyeOfHorusMG
    6810, // RgExcaliburMG
    6988, // RgExtraWild
    7018, // RgExtraWildMG
    7081, // RgFireAndIce
    7155, // RgFruitinator
    7156, // RgFruitinator_p
    7157, // tri1RgFruitinator
    7158, // tri2RgFruitinator
    7205, // RgFruitinatorMG
    7236, // RgFruitinatorBreak
    7285, // RgFruitinatorPS
    7286, // RgFruitinatorPS1
    7287, // RgFruitinatorPS2
    7288, // RgFruitinatorPS3
    7289, // RgFruitinatorPS4
    7379, // RgFishinFrenzy
    7465, // RgForbiddenPrincess
    7575, // RgFruitsOfDesert
    7651, // RgFrutFlip
    7701, // RgFruitinatorGN
    7702, // RgFruitinatorGNFG
    7968, // RgWildFrog
    7975, // RgFruitopia
    8016, // RgFortuneSeekerMG
    8155, // RgGeniesCloud
    8231, // RgGoldenAnchor
    8256, // RgGoldenTemptation
    8327, // RgMagicLampOfHorus
    8468, // RgGoldAndGlory
    8539, // RgGhostSlider
    8671, // RgGingerJumpers
    8759, // RgGl
    8772, // RgGlMG
    8862, // RgGlPS
    8863, // RgGlPS_PS1
    8864, // RgGlPS_PS2
    8865, // RgGlPS_PS3
    8866, // RgGlPS_PS4
    8902, // RgGoldCup
    8903, // RgGoldCup_p
    8904, // tri1RgGoldCup
    8905, // tri2RgGoldCup
    8958, // RgGoldFrenzy
    9044, // RgGoldCupPS
    9045, // RgGCPS_1
    9046, // RgGCPS_2
    9047, // RgGCPS_3
    9048, // RgGCPS_4
    9274, // RgGoGa
    9312, // RgGoGaMG
    9313, // RgGoldOfPer
    9431, // RgGongHei
    9596, // RgGreenAmulet
    9686, // RgGreenfear
    9947, // RgHexenkesselVideo
    9991, // RgHoneyBee
    10063, // RgHotChiliPepper
    10064, // RgBonusHCP
    10141, // RgHotDragon
    10263, // RgHotFrootastic
    10305, // RgHyperFruits
    10384, // RgHoleyMoley
    10492, // RgRedSeven
    10526, // RgIndianRuby
    10598, // RgJackpotAngel
    10655, // RgJokersCap
    10737, // RgJokersCapPS
    10738, // RgJokersCapPS_1
    10739, // RgJokersCapPS_2
    10740, // RgJokersCapPS_3
    10741, // RgJokersCapPS_4
    10945, // RgJokernator
    11063, // RgKangarooIsland
    11128, // RgKaiserwetterVideo
    11201, // RgKingsTower
    11271, // RgKnightLife
    11356, // RgKnightLifeMG
    11405, // RgKnockOutWins
    11486, // RgKongsTemple
    11611, // RgLEDFruits
    11692, // RgLegacyOfFire
    11748, // RgLegendaryPalace
    11923, // RgLFa
    11937, // RgLuckyPharaohWild
    11938, // RgLuckyPharaohWild1
    11939, // RgLuckyPharaohWild2
    11940, // RgLuckyPharaohWild3
    11941, // RgLuckyPharaohWild4
    12215, // RgLostTemple
    12237, // RgMagicMirrorMG
    12501, // RgMerkurMagnus
    12515, // RgMerkurMagnusMG
    12543, // RgMergix
    12633, // RgMagicMirrorDeluxeMG
    12741, // RgMagicMirrorDeluxe2
    12839, // RgMagicMirrorWild
    12947, // RgMedusasEyes
    13018, // RgMermaidQueen
    13129, // RgMSl
    13144, // RgMagicTree
    13247, // RgMRM
    13402, // RgMultiSevenWild
    13471, // RgMultiDiamonds
    13483, // RgMultiFruits
    13580, // RgMultiMerkur
    13681, // RgMultiWild
    13682, // RgMultiWild_p
    13683, // tri1RgMultiWild
    13684, // tri2RgMultiWild
    13714, // RgMultiWild243
    13719, // RgMultiWild243PS
    13720, // RgMultiWild243PSPS1
    13721, // RgMultiWild243PSPS2
    13722, // RgMultiWild243PSPS3
    13723, // RgMultiWild243PSPS4
    13954, // RgMultiWildPS
    13955, // RgMultiWildPSPS1
    13956, // RgMultiWildPSPS2
    13957, // RgMultiWildPSPS3
    13958, // RgMultiWildPSPS4
    13968, // RgMysticDew
    14062, // RgNileLiner
    14252, // RgOdin
    14392, // RgPEx
    14407, // RgPharaohOfThebes
    14508, // RgPharosGoldBase
    14509, // RgPharosGold1
    14510, // RgPharosGold2
    14511, // RgPharosGold3
    14512, // RgPharosGold4
    14691, // RgPimpItUp
    14789, // RgPlanets
    14838, // RgPluenderPack
    14938, // RgPalOfPos
    15019, // RgPoolParty
    15116, // RgLieDetector
    15227, // RgPureWinsMore
    15316, // RgPyramidOfPower
    15387, // RgRaptorHunter
    15537, // RgRasputin
    15671, // RgRasputin5
    15871, // RgRisingLiner
    16007, // RgRr
    16021, // RgRrMG
    16022, // RgRussianQueen
    16193, // RgSup7Rel
    16220, // RgSafesChoice
    16290, // RgSalmonCatch
    16396, // Rg15Samurai
    16463, // RgSavannaStampede
    16549, // RgSciDonia
    16772, // RgSevensKraze
    16833, // RgSevensWild
    16885, // RgSevensWildStayAndWin
    17072, // RgShiningWolf
    17162, // RgSKS9
    17271, // RgSonnenkaefer
    17428, // RgSonnenzauber
    17499, // RgSpartaBase
    17500, // RgSparta1
    17501, // RgSparta2
    17502, // RgSparta3
    17503, // RgSparta4
    17504, // RgSparta5
    17505, // RgSparta6
    17679, // RgSuperBVideo
    17821, // RgSuperSubs
    17885, // RgSuperFrutta
    17937, // RgSuper7ReelsWild
    17986, // RgTripleChance
    18039, // RgTotemChiefPlus
    18095, // RgTeamAction
    18170, // RgTopFour
    18249, // RgTopFourAttack
    18344, // RgThaiFlower
    18489, // RgTHOP
    18513, // RgTHOP_MG
    18514, // RgThe80DaysTravel
    18657, // RgTripleSpinToWin
    18876, // RgTheThreeMusketeers
    18999, // RgTikTakCash
    19051, // RgTiwanaku
    19208, // RgTizona
    19209, // RgTizona_p
    19210, // tri1RgTizona
    19211, // tri2RgTizona
    19355, // RgTripleFlame
    19405, // RgTreasureHunt
    19533, // RgTriPiki
    19656, // RgTridentia
    19756, // RgTripleTripleChance
    19822, // RgUltra7Wild
    19948, // RgUpTo7
    20046, // RgVelvetLounge
    20129, // RgVampiresII
    20255, // RgVampireNight
    20370, // RgVoBa
    20479, // RgWestward
    20587, // RgWildBronco
    20634, // RgWishingWell
    20728, // RgWildSpirit
    20783, // RgWoop
    20933, // RgZentaurus
    21029, // RgZipper
};

BOOL IsReelGame(UINT16 goc) {
    for (int i = 0; i < sizeof(gReelGameGOCs) / sizeof(gReelGameGOCs[0]); i++) {
        if (goc == gReelGameGOCs[i]) {
            return TRUE;
        }
    }
    return FALSE;
}