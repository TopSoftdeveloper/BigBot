#include "stdafx.h"
#include "RgRisingLiner.h"

#define RgRisingLiner_wild "riliWILD___"
#define RgRisingLiner_top "riliHIGH1__"
RgRisingLiner::RgRisingLiner() {
    m_nReel = 5;
    m_nWinLine = 5;
    m_nMaxMatch = 5;
    m_nBetStep = 0;
    
    m_nWildPos = 0xFF;

    m_strGameName = "RgRisingLiner";

    myVector<UINT16> m_vecBetSteps_tmp;
    m_vecBetSteps_tmp.push_back(5);
    m_vecBetSteps_tmp.push_back(10);
    m_vecBetSteps_tmp.push_back(20);
    m_vecBetSteps_tmp.push_back(30);
    m_vecBetSteps_tmp.push_back(40);
    m_vecBetSteps_tmp.push_back(50);
    m_vecBetSteps_tmp.push_back(60);
    m_vecBetSteps_tmp.push_back(80);
    m_vecBetSteps_tmp.push_back(100);
    m_vecBetSteps_tmp.push_back(150);
    m_vecBetSteps_tmp.push_back(200);
#ifdef BIGBET_ACTIVE
    m_vecBetSteps_tmp.push_back(500);
    m_vecBetSteps_tmp.push_back(1000);
#endif
    LoadBets();

    m_vecSymbols.push_back("riliLOW1___");
    m_vecSymbols.push_back("riliLOW2___");
    m_vecSymbols.push_back("riliLOW3___");
    m_vecSymbols.push_back("riliLOW4___");
    m_vecSymbols.push_back("riliHIGH1__");
    m_vecSymbols.push_back("riliHIGH2__");
    m_vecSymbols.push_back("riliHIGH3__");
    m_vecSymbols.push_back("riliWILD___");

    m_mapSymbolMinMatch["riliLOW1___"] = 3;
    m_mapSymbolMinMatch["riliLOW2___"] = 3;
    m_mapSymbolMinMatch["riliLOW3___"] = 3;
    m_mapSymbolMinMatch["riliLOW4___"] = 3;
    m_mapSymbolMinMatch["riliHIGH1__"] = 3;
    m_mapSymbolMinMatch["riliHIGH2__"] = 3;
    m_mapSymbolMinMatch["riliHIGH3__"] = 3;

    m_mapSymbolMeterGoc["riliLOW1___"] = "riliLOW1_2_$x";
    m_mapSymbolMeterGoc["riliLOW2___"] = "riliLOW1_2_$x";
    m_mapSymbolMeterGoc["riliLOW3___"] = "riliLOW3_4_$x";
    m_mapSymbolMeterGoc["riliLOW4___"] = "riliLOW3_4_$x";
    m_mapSymbolMeterGoc["riliHIGH1__"] = "riliHIGH1_$x";
    m_mapSymbolMeterGoc["riliHIGH2__"] = "riliHIGH2_3_$x";
    m_mapSymbolMeterGoc["riliHIGH3__"] = "riliHIGH2_3_$x";

    m_vecWinLines.push_back("riliWinLine1");
    m_vecWinLines.push_back("riliWinLine2");
    m_vecWinLines.push_back("riliWinLine3");
    m_vecWinLines.push_back("riliWinLine4");
    m_vecWinLines.push_back("riliWinLine5");

    m_vecLineSounds.push_back(SMP_RILI_MW_1);
    m_vecLineSounds.push_back(SMP_RILI_MW_2);
    m_vecLineSounds.push_back(SMP_RILI_MW_3);
    m_vecLineSounds.push_back(SMP_RILI_MW_4);
    m_vecLineSounds.push_back(SMP_RILI_MW_5);

    m_vecWinSounds.push_back(SMP_RILI_R_SOUND_1);
    m_vecWinSounds.push_back(SMP_RILI_R_SOUND_2);
    m_vecWinSounds.push_back(SMP_RILI_R_SOUND_3);
    m_vecWinSounds.push_back(SMP_RILI_R_SOUND_4);
    m_vecWinSounds.push_back(SMP_RILI_W_SOUND_1);
    m_vecWinSounds.push_back(SMP_RILI_W_SOUND_2);
    m_vecWinSounds.push_back(SMP_RILI_W_SOUND_3);
    m_vecWinSounds.push_back(SMP_RILI_W_SOUND_4);
    m_vecWinSounds.push_back(SMP_RILI_W_SOUND_5);
    m_vecWinSounds.push_back(SMP_RILI_W_SOUND_6);
    m_vecWinSounds.push_back(SMP_RILI_W_SOUND_6_Opt2);
    m_vecWinSounds.push_back(SMP_RILI_W_SOUND_7_V3);

    m_vecReelStripPlan.push_back("0");
    //m_vecReelStripPlan.push_back("1");
    
    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));

    char* riliReelStrip[] = {
        "riliHIGH3__,riliHIGH3__,riliLOW2___,riliLOW2___,riliLOW2___,riliHIGH1__,riliHIGH1__,riliHIGH1__,riliLOW2___,riliLOW2___,riliLOW2___,riliLOW3___,riliLOW3___,riliLOW3___,riliLOW2___,riliLOW2___,riliLOW2___,riliHIGH1__,riliHIGH1__,riliHIGH1__,riliLOW4___,riliLOW4___,riliLOW4___,riliLOW1___,riliLOW1___,riliLOW1___,riliHIGH3__,riliHIGH3__,riliHIGH3__,riliLOW4___,riliLOW4___,riliLOW4___,riliHIGH3__,riliHIGH3__,riliHIGH3__,riliLOW4___,riliLOW4___,riliLOW4___,riliHIGH3__,riliHIGH3__,riliHIGH3__,riliLOW3___,riliLOW3___,riliLOW3___,riliHIGH3__,riliHIGH3__,riliHIGH3__,riliLOW4___,riliLOW4___,riliLOW4___,riliHIGH2__,riliHIGH2__,riliHIGH2__,riliLOW4___,riliLOW4___,riliLOW4___,riliLOW2___,riliLOW2___,riliLOW2___,riliHIGH3__",
        "riliHIGH2__,riliHIGH2__,riliHIGH2__,riliLOW2___,riliLOW2___,riliLOW2___,riliHIGH3__,riliHIGH3__,riliHIGH3__,riliLOW4___,riliLOW4___,riliLOW4___,riliLOW3___,riliLOW3___,riliLOW3___,riliLOW1___,riliLOW1___,riliLOW1___,riliLOW1___,riliHIGH2__,riliHIGH2__,riliHIGH2__,riliLOW1___,riliLOW1___,riliLOW1___,riliLOW2___,riliLOW2___,riliLOW2___,riliLOW3___,riliLOW3___,riliLOW3___,riliHIGH1__,riliHIGH1__,riliHIGH1__,riliLOW3___,riliLOW3___,riliLOW3___,riliHIGH2__,riliHIGH2__,riliHIGH2__,riliLOW4___,riliLOW4___,riliLOW4___,riliLOW1___,riliLOW1___,riliLOW1___,riliHIGH2__,riliHIGH2__,riliHIGH2__,riliLOW3___,riliLOW3___,riliLOW3___,riliLOW1___,riliLOW1___,riliLOW1___,riliLOW3___,riliLOW3___,riliLOW3___",
        "riliLOW4___,riliLOW4___,riliLOW1___,riliLOW1___,riliLOW1___,riliLOW2___,riliLOW2___,riliLOW2___,riliLOW4___,riliLOW4___,riliLOW4___,riliLOW3___,riliLOW3___,riliLOW3___,riliLOW1___,riliLOW1___,riliLOW1___,riliHIGH2__,riliHIGH2__,riliHIGH2__,riliLOW1___,riliLOW1___,riliLOW1___,riliHIGH3__,riliHIGH3__,riliHIGH3__,riliLOW4___,riliLOW4___,riliLOW4___,riliHIGH2__,riliHIGH2__,riliHIGH2__,riliLOW2___,riliLOW2___,riliLOW2___,riliLOW3___,riliLOW3___,riliLOW3___,riliLOW4___,riliLOW4___,riliLOW4___,riliHIGH3__,riliHIGH3__,riliHIGH3__,riliLOW2___,riliLOW2___,riliLOW2___,riliHIGH1__,riliHIGH1__,riliHIGH1__,riliLOW3___,riliLOW3___,riliLOW3___,riliHIGH1__,riliHIGH1__,riliHIGH1__,riliHIGH1__,riliLOW3___,riliLOW3___,riliLOW3___,riliHIGH1__,riliHIGH1__,riliHIGH1__,riliLOW4___",
        "riliLOW4___,riliLOW4___,riliLOW4___,riliLOW2___,riliLOW2___,riliLOW2___,riliLOW4___,riliLOW4___,riliLOW4___,riliLOW1___,riliLOW1___,riliLOW1___,riliHIGH1__,riliHIGH1__,riliHIGH1__,riliLOW2___,riliLOW2___,riliLOW2___,riliHIGH2__,riliHIGH2__,riliHIGH2__,riliLOW2___,riliLOW2___,riliLOW2___,riliLOW4___,riliLOW4___,riliLOW4___,riliHIGH3__,riliHIGH3__,riliHIGH3__,riliLOW3___,riliLOW3___,riliLOW3___,riliLOW2___,riliLOW2___,riliLOW2___,riliHIGH3__,riliHIGH3__,riliHIGH3__,riliLOW4___,riliLOW4___,riliLOW4___,riliLOW1___,riliLOW1___,riliLOW1___,riliHIGH3__,riliHIGH3__,riliHIGH3__,riliLOW3___,riliLOW3___,riliLOW3___,riliLOW2___,riliLOW2___,riliLOW2___,riliHIGH3__,riliHIGH3__,riliHIGH3__",
        "riliLOW3___,riliLOW3___,riliHIGH2__,riliHIGH2__,riliHIGH2__,riliLOW1___,riliLOW1___,riliLOW1___,riliHIGH1__,riliHIGH1__,riliHIGH1__,riliLOW3___,riliLOW3___,riliLOW3___,riliLOW2___,riliLOW2___,riliLOW2___,riliHIGH2__,riliHIGH2__,riliHIGH2__,riliLOW4___,riliLOW4___,riliLOW4___,riliLOW1___,riliLOW1___,riliLOW1___,riliHIGH2__,riliHIGH2__,riliHIGH2__,riliLOW3___,riliLOW3___,riliLOW3___,riliLOW1___,riliLOW1___,riliLOW1___,riliLOW4___,riliLOW4___,riliLOW4___,riliHIGH2__,riliHIGH2__,riliHIGH2__,riliLOW1___,riliLOW1___,riliLOW1___,riliHIGH1__,riliHIGH1__,riliHIGH1__,riliLOW1___,riliLOW1___,riliLOW1___,riliLOW1___,riliHIGH2__,riliHIGH2__,riliHIGH2__,riliLOW3___,riliLOW3___,riliLOW3___,riliHIGH3__,riliHIGH3__,riliHIGH3__,riliLOW3___,riliLOW3___",

        "riliHIGH3__,riliHIGH3__,riliLOW2___,riliLOW2___,riliLOW2___,riliHIGH1__,riliHIGH1__,riliHIGH1__,riliLOW2___,riliLOW2___,riliLOW2___,riliLOW3___",
        "riliHIGH2__,riliHIGH2__,riliHIGH2__,riliLOW2___,riliLOW2___,riliLOW2___,riliHIGH3__,riliHIGH3__,riliHIGH3__,riliLOW4___,riliLOW4___,riliLOW4___,riliLOW3___,riliLOW3___",
        "riliLOW4___,riliLOW4___,riliLOW1___,riliLOW1___,riliLOW1___,riliLOW2___,riliLOW2___,riliLOW2___,riliLOW4___,riliLOW4___,riliLOW4___,riliLOW3___",
        "riliLOW4___,riliLOW3___,riliLOW4___,riliLOW4___,riliLOW4___,riliLOW2___,riliLOW2___,riliLOW2___,riliLOW4___,riliLOW4___,riliLOW4___,riliLOW1___,riliLOW1___,riliLOW1___,riliHIGH1__,riliHIGH1__,riliHIGH1__,riliLOW2___",
        "riliHIGH1__,riliLOW2___,riliLOW3___,riliLOW3___,riliHIGH2__,riliHIGH2__,riliHIGH2__,riliLOW1___,riliLOW1___,riliLOW1___,riliHIGH1__,riliHIGH1__,riliHIGH1__,riliLOW3___",
    };

    int idx = 0;
    for (int i = 0; i < m_vecReelStripPlan.size(); i++) {
        ReelSet set;
        for (int j = 0; j < m_nReel; j++) {
            ReelStrip strip;
            std::stringstream ss(riliReelStrip[idx]);
            std::string item;
            while (std::getline(ss, item, ',')) {
                strip.push_back(item);
            }
            set.push_back(strip);
            idx++;
        }
        m_vecReelStripSets.push_back(set);
    }

    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_tmp;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        std::map<std::string, std::map<UINT8, BONUS>> perSym;
        std::map<UINT8, BONUS> e;
        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 40; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 200; e[5].ag = 0;
        perSym["riliLOW1___"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 40; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 200; e[5].ag = 0;
        perSym["riliLOW2___"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[5].ag = 0;
        perSym["riliLOW3___"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[5].ag = 0;
        perSym["riliLOW4___"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 1000; e[5].ag = 0;
        perSym["riliHIGH1__"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 60; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 500; e[5].ag = 0;
        perSym["riliHIGH2__"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 60; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 500; e[5].ag = 0;
        perSym["riliHIGH3__"] = e;
        e.clear();

        m_Bonus_tmp[i] = perSym;
    }

    int nSavedBetVal = 10;
    int _line = 0;
    string data;
    PlayDB::GetInstance().LoadCheckPoint(m_strGameName, nSavedBetVal, _line, m_strCheckPoint);
    if (nSavedBetVal == -1) {
        nSavedBetVal = 10;
    }

    BOOL start = FALSE;
    idx = 0;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_tmp, i) < AT(m_vecBetSteps, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps, idx) == nSavedBetVal) {
            m_nBetStep = idx;
        }

        m_Bonus[idx++] = m_Bonus_tmp[i];
        if (AT(m_vecBetSteps_tmp, i) == AT(m_vecBetSteps, m_vecBetSteps.size() - 1)) {
            break;
        }
    }

    m_vecBetSteps_05.clear();
    m_vecBetSteps_10.clear();
    PrintAllBonus();
}

UINT16 RgRisingLiner::Run() {
    m_nCurrentReelPlan = (myRandom() % m_vecReelStripPlan.size());
    //m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(m_vecReelStripPlan[m_nCurrentReelPlan]);
    m_shCurrentReelStrip = static_cast<uint16_t>(std::stoi(AT(m_vecReelStripPlan, m_nCurrentReelPlan)));
    return m_shCurrentReelStrip;
}

void RgRisingLiner::ChangeReelStrip(UINT16 NewReelPlan) {
    m_nCurrentReelPlan = NewReelPlan;
    m_shCurrentReelStrip = static_cast<uint16_t>(std::stoi(AT(m_vecReelStripPlan, m_nCurrentReelPlan)));
}


myVector<UINT8> RgRisingLiner::Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) {
    auto& playDB = PlayDB::GetInstance();
	const auto variant = playDB.GetGameVariant();

    m_nWildPos = ((myRandom() % 100) < 1) ? (1 + (myRandom() % 15)) : 0xFF;
    if (variant != PlayDB::GAME_VARIANT_A) {
        m_nWildPos = ((myRandom() % 200) < 1) ? (1 + (myRandom() % 15)) : 0xFF;
    }
#ifdef TEST_WILD
    m_nWildPos = (1 + (myRandom() % 15));
#endif
    myVector<UINT8> result;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);

    BOOL mmcode = FALSE;
    if (bTest == FALSE) {
        mmcode = mmcode_get_active_status();
    }
    if (bTest == TRUE || mmcode == TRUE) {
        std::string matchSymbol = AT(m_vecSymbols, myRandom() % (m_vecSymbols.size() - 1));
        int line = (myRandom() % m_nWinLine);
        int weight = 1;// +(myRandom() % 5);
        
        if (mmcode) {
            mmcode_set_deactive();
            weight = m_nMaxMatch;
            matchSymbol = RgRisingLiner_top;
        }
        for (int i = 0; i < m_nReel; i++) {
            ReelStrip reelStrip = AT(reelSet, i);
            int len = reelStrip.size() - 3;

            int valid_i[0x100];
            int valid_count = 0;
            for (int j = 0; j <= len; j++) {
                if (weight > i) {
                    if (matchSymbol == AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                else {
                    if (matchSymbol != AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
            }
            if (valid_count > 0) {
                int rand_index = myRandom() % valid_count;
                int chosen_i = valid_i[rand_index];
                result.push_back(chosen_i + 1);
            }
            else {
                result.push_back((myRandom() % (len - 1)) + 1);
            }
        }
    }
    else {
        result = _result;
    }
    normalMeter = 0;
    maxMeter = 0;
    UINT32 totalBonus = 0;
    for (int i = 0; i < m_nWinLine; i++) {
        int j = 1;
        UINT16 meter = ((UINT16)1 << (2 - g_match_lines_10_5[i][0]));
        std::string firstSymbol = AT(AT(reelSet, 0), AT(result, 0) - 1 + g_match_lines_10_5[i][0]);

        if (IsWild(0, 2 - g_match_lines_10_5[i][0])) {
            firstSymbol = RgRisingLiner_wild;
        }

        int nMatched = 1;
        for (; j < m_nMaxMatch; j++) {
            std::string prev_symbol = AT(AT(reelSet, j - 1), AT(result, j - 1) - 1 + g_match_lines_10_5[i][j - 1]);
            std::string cur_symbol = AT(AT(reelSet, j), AT(result, j) - 1 + g_match_lines_10_5[i][j]);

            if (IsWild(j - 1, 2 - g_match_lines_10_5[i][j - 1])) {
                prev_symbol = RgRisingLiner_wild;
            }
            if (IsWild(j, 2 - g_match_lines_10_5[i][j])) {
                cur_symbol = RgRisingLiner_wild;
            }

            if (firstSymbol == RgRisingLiner_wild) {
                firstSymbol = cur_symbol;
            }
            if (firstSymbol == cur_symbol || cur_symbol == RgRisingLiner_wild) {
                meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
                nMatched++;
                continue;
            }
            if (j >= 3) {
                if (nMatched == 4) { // choose from right or left to get higher value when wild in col 2
                    if (IsWild(1, 2 - g_match_lines_10_5[i][1]) &&
                        IsWild(2, 2 - g_match_lines_10_5[i][2]) &&
                        IsWild(3, 2 - g_match_lines_10_5[i][3])) {

                        std::string symbol0 = AT(AT(reelSet, 0), AT(result, 0) - 1 + g_match_lines_10_5[i][0]);
                        std::string symbol4 = AT(AT(reelSet, 4), AT(result, 4) - 1 + g_match_lines_10_5[i][4]);

                        if (m_Bonus[BetStep()][symbol0][4].coin >= m_Bonus[BetStep()][symbol4][4].coin) {
                            firstSymbol = symbol0;
                            meter = ((UINT16)1 << (3 * 0 + 2 - g_match_lines_10_5[i][0]));
                            meter |= ((UINT16)1 << (3 * 1 + 2 - g_match_lines_10_5[i][1]));
                            meter |= ((UINT16)1 << (3 * 2 + 2 - g_match_lines_10_5[i][2]));
                            meter |= ((UINT16)1 << (3 * 3 + 2 - g_match_lines_10_5[i][3]));                            
                        }
                        else {
                            firstSymbol = symbol4;
                            meter = ((UINT16)1 << (3 * 1 + 2 - g_match_lines_10_5[i][1]));
                            meter |= ((UINT16)1 << (3 * 2 + 2 - g_match_lines_10_5[i][2]));
                            meter |= ((UINT16)1 << (3 * 3 + 2 - g_match_lines_10_5[i][3]));
                            meter |= ((UINT16)1 << (3 * 4 + 2 - g_match_lines_10_5[i][4]));
                        }

                    }
                }
                break;
            }

            nMatched = 1;
            firstSymbol = cur_symbol;
            meter = ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
        }
        if (nMatched < m_mapSymbolMinMatch[firstSymbol]) {
            continue;
        }

        // monitor 2 meter
        std::string meterStr = m_mapSymbolMeterGoc[firstSymbol];
        size_t pos = meterStr.find('$');
        if (pos != std::string::npos) {
            meterStr = meterStr.replace(pos, 1, std::to_string(nMatched));
        }

        WinMeter e;
        e.line = i;
        e.meter = meter;
        e.meter2 = g_GrafficObjList.Str2GOCID(meterStr);
        e.symbol = firstSymbol;
        e.weight = nMatched;
        e.start = 0;
        e.bonus = m_Bonus[BetStep()][firstSymbol][nMatched];
        e.sound = MAX_SOUND_IDS;

        totalBonus += e.bonus.coin;

        if (e.meter2 != -1) {
            meters.push_back(e);
        }
        if (nMatched == m_nMaxMatch) {
            maxMeter |= meter;
        }
        else {
            normalMeter |= meter;
        }
    }
    if (bTest == FALSE) {
        m_vWinResult = result;
        updateCheckPoint();
    }
    if (totalBonus > 0) {
        BonusSound = getSoundByID(WinSound(totalBonus));
    }
    else {
        BonusSound.duration = 0;
        BonusSound.soundID = MAX_SOUND_IDS;
    }
    return result;
}

UINT16 RgRisingLiner::SpinTime_MS() {
    return 1800;
}

int RgRisingLiner::LineSwapDelay(int WinIdx) {
    return 700;
}

myVector<UINT8> RgRisingLiner::AdditionalParam() {
    m_vecAdditionalParam.clear();
    m_vecAdditionalParam.push_back(m_nWildPos);
    return m_vecAdditionalParam;
}

BOOL RgRisingLiner::IsWild(int reel, int row) {
    if (m_nWildPos < 1 || m_nWildPos > 15) {
        return FALSE;
    }
    int wildReel = ((m_nWildPos - 1) / 3);
    int wildRow = ((m_nWildPos - 1) % 3);

    if (abs(reel - wildReel) >= 2 || abs(row - wildRow) >= 2) {
        return FALSE;
    }
    return TRUE;
}

myVector<InterruptPacketData> RgRisingLiner::InterruptAfterSpin() {
    myVector<InterruptPacketData> packets;
    if (m_nWildPos != 0xFF) {
        // expand wild card
        packets.push_back({
               0,
               7000,
               {0x06, 0xff, 0x3d, 0x01, 0x02, 0x28, 0x00, 0xff, 0x3d, 0x00, 0x00, 0x00, 0x10, 0x04} });
    }
    return packets;
}

bool RgRisingLiner::RTP_force_bigWin() {
    return (myRandom() % 100 == 0); 
}
