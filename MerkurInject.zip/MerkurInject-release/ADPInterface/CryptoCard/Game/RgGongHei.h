#pragma once

#include "ReelGame.h"

class RgGongHei : public ReelGame
{
public:
    BOOL m_bFreeMode;
    UINT8 m_nFreeModeTotalSpin;
    UINT8 m_nFreeModeGoneSpin;
    BONUS m_nFreeModeTotalBonus;
    UINT8 m_nConvertedInFreeMode;

    myVector<WinMeter> m_vWinMeters;

	RgGongHei::RgGongHei();

    BOOL TempleInCol(int col);
    UINT8 CardNumInCol(int col, std::string card);
    BOOL WildcountInCol(UINT8 col, myVector<UINT8> result);
    UINT8 Wildcount();
    UINT8 ScatterCount();
    UINT8 CardCount(std::string card);
    UINT8 NumberOfScatter(myVector<UINT8> result);
    void ChangeReelStrip(UINT16 NewReelPlan) override;

	UINT16 Run() override;
	myVector<UINT8> Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& WinSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) override;
    UINT16 SpinTime_MS() override;
    int LineSwapDelay(int WinIdx) override;
    UINT16 MagicCount() override;
    BOOL CanFreeMode() override;
    myVector<InterruptPacketData> InterruptBeforeSpin() override;
    myVector<InterruptPacketData> InterruptAfterMoveBonus(BOOL& EndFree) override;
    myVector<InterruptPacketData> EnterFreeGame(std::string) override;

    myVector<InterruptPacketData> MousePressed(MousePosition p) override;
    myVector<UINT8> ShowTotalWinLines(myVector<WinMeter> SpinMeters) override;

    BOOL SelectedableReelsInFreeGame(myVector<UINT8> result) override;
    BOOL NoFunInFreeMode() override;

    void updateCheckPoint() override;
};
