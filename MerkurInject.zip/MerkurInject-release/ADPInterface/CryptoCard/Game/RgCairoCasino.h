#pragma once

#include "ReelGame.h"

class RgCairoCasino : public ReelGame
{
public:
	BOOL m_bFreeMode;
	BOOL m_bFreeModePenddingFinish;
	BONUS m_FreeModeBonus;

	myVector<UINT8> m_vFreeModeScatters;

	RgCairoCasino::RgCairoCasino();

	int m_nBetOffset;

	std::map<UINT8, UINT32> GetFreeModeBonus();

	UINT16 Run() override;
	myVector<UINT8> Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) override;
	UINT16 LineSound(UINT Line, std::string symbol, UINT8 weight) override;
	UINT16 MagicCount() override;


	BOOL RgCairoCasino::CanFreeMode() override;
	UINT8 CardCount(std::string card);
	myVector<InterruptPacketData> EnterFreeGame(std::string) override;
	myVector<InterruptPacketData> InterruptAfterSpin() override;
	myVector<InterruptPacketData> InterruptAfterMoveBonus(BOOL& EndFree) override;

	myVector<UINT8> ShowTotalWinLines(myVector<WinMeter> SpinMeters) override;

	void ChangeReelStrip(UINT16 NewReelPlan) override;
	void updateCheckPoint() override;
};
