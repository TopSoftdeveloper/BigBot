#include "stdafx.h"
#include "RgPharosGold3.h"
#include <set>

#define RgPharosGold3_trans "PHGOTrans_S"
RgPharosGold3::RgPharosGold3() {
    m_strGameName = "RgLuckyPharaoh";

    m_nReel = 5;
    m_nWinLine = 10;
    m_nMaxMatch = 5;
    m_nBetStep = 0;

    myVector<UINT16> m_vecBetSteps_tmp;
    m_vecBetSteps_tmp.push_back(10);
    m_vecBetSteps_tmp.push_back(20);
    m_vecBetSteps_tmp.push_back(30);
    m_vecBetSteps_tmp.push_back(40);
    m_vecBetSteps_tmp.push_back(50);
    m_vecBetSteps_tmp.push_back(60);
    m_vecBetSteps_tmp.push_back(80);
    m_vecBetSteps_tmp.push_back(100);
    m_vecBetSteps_tmp.push_back(150);
    m_vecBetSteps_tmp.push_back(200);
#ifdef BIGBET_ACTIVE
    m_vecBetSteps_tmp.push_back(500);
    m_vecBetSteps_tmp.push_back(1000);
#endif
    LoadBets();

    m_vecSymbols.push_back("PHGOHigh1_S");
    m_vecSymbols.push_back("PHGOHigh2_S");
    m_vecSymbols.push_back("PHGOHigh3_S");
    m_vecSymbols.push_back("PHGOHigh4_S");
    m_vecSymbols.push_back("PHGOLow1__S");
    m_vecSymbols.push_back("PHGOLow2__S");
    m_vecSymbols.push_back("PHGOLow3__S");
    m_vecSymbols.push_back("PHGOLow4__S");
    m_vecSymbols.push_back("PHGOLow5__S");

    m_mapSymbolMinMatch["PHGOHigh1_S"] = 3;
    m_mapSymbolMinMatch["PHGOHigh2_S"] = 3;
    m_mapSymbolMinMatch["PHGOHigh3_S"] = 3;
    m_mapSymbolMinMatch["PHGOHigh4_S"] = 3;
    m_mapSymbolMinMatch["PHGOLow1__S"] = 3;
    m_mapSymbolMinMatch["PHGOLow2__S"] = 3;
    m_mapSymbolMinMatch["PHGOLow3__S"] = 3;
    m_mapSymbolMinMatch["PHGOLow4__S"] = 3;
    m_mapSymbolMinMatch["PHGOLow5__S"] = 3;

    m_mapSymbolMeterGoc["PHGOHigh1_S"] = "PHGOHigh1_$x";
    m_mapSymbolMeterGoc["PHGOHigh2_S"] = "PHGOHigh2_$x";
    m_mapSymbolMeterGoc["PHGOHigh3_S"] = "PHGOHigh3_$x";
    m_mapSymbolMeterGoc["PHGOHigh4_S"] = "PHGOHigh4_$x";
    m_mapSymbolMeterGoc["PHGOLow1__S"] = "PHGOLow1_2_$x";
    m_mapSymbolMeterGoc["PHGOLow2__S"] = "PHGOLow1_2_$x";
    m_mapSymbolMeterGoc["PHGOLow3__S"] = "PHGOLow3_4_5_$x";
    m_mapSymbolMeterGoc["PHGOLow4__S"] = "PHGOLow3_4_5_$x";
    m_mapSymbolMeterGoc["PHGOLow5__S"] = "PHGOLow3_4_5_$x";

    m_vecWinLines.push_back("PHGOWinline1_3");
    m_vecWinLines.push_back("PHGOWinline2_3");
    m_vecWinLines.push_back("PHGOWinline3_3");
    m_vecWinLines.push_back("PHGOWinline4_3");
    m_vecWinLines.push_back("PHGOWinline5_3");
    m_vecWinLines.push_back("PHGOWinline6_3");
    m_vecWinLines.push_back("PHGOWinline7_3");
    m_vecWinLines.push_back("PHGOWinline8_3");
    m_vecWinLines.push_back("PHGOWinline9_3");
    m_vecWinLines.push_back("PHGOWinline10_3");

    m_vecReelStripPlan.push_back("0");
    //m_vecReelStripPlan.push_back("1");
    
    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));

    char* phgoReelStrip[] = {
        "PHGOLow1__S,PHGOLow1__S,PHGOLow1__S,PHGOLow1__S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOHigh2_S,PHGOHigh2_S,PHGOHigh2_S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOLow1__S,PHGOLow1__S,PHGOLow1__S,PHGOHigh3_S,PHGOHigh3_S,PHGOHigh3_S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOLow1__S,PHGOLow1__S,PHGOLow1__S,PHGOLow1__S,PHGOHigh2_S,PHGOHigh2_S,PHGOHigh2_S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOHigh2_S,PHGOHigh2_S,PHGOHigh2_S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOHigh3_S,PHGOHigh3_S,PHGOHigh3_S",
        "PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOHigh3_S,PHGOHigh3_S,PHGOHigh3_S,PHGOLow1__S,PHGOLow1__S,PHGOLow1__S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOHigh3_S,PHGOHigh3_S,PHGOHigh3_S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOHigh2_S,PHGOHigh2_S,PHGOHigh2_S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOHigh3_S,PHGOHigh3_S,PHGOHigh3_S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOLow1__S,PHGOLow1__S,PHGOLow1__S,PHGOHigh2_S,PHGOHigh2_S,PHGOHigh2_S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S",
        "PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOLow1__S,PHGOLow1__S,PHGOLow1__S,PHGOHigh2_S,PHGOHigh2_S,PHGOHigh2_S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOLow1__S,PHGOLow1__S,PHGOLow1__S,PHGOLow1__S,PHGOHigh2_S,PHGOHigh2_S,PHGOHigh2_S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOHigh3_S,PHGOHigh3_S,PHGOHigh3_S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOHigh2_S,PHGOHigh2_S,PHGOHigh2_S,PHGOLow1__S,PHGOLow1__S,PHGOLow1__S,PHGOLow1__S,PHGOHigh3_S,PHGOHigh3_S,PHGOHigh3_S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOHigh2_S,PHGOHigh2_S,PHGOHigh2_S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOHigh3_S,PHGOHigh3_S,PHGOHigh3_S",
        "PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOHigh3_S,PHGOHigh3_S,PHGOHigh3_S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOHigh2_S,PHGOHigh2_S,PHGOHigh2_S,PHGOLow1__S,PHGOLow1__S,PHGOLow1__S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOHigh3_S,PHGOHigh3_S,PHGOHigh3_S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOLow1__S,PHGOLow1__S,PHGOLow1__S,PHGOLow1__S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOHigh2_S,PHGOHigh2_S,PHGOHigh2_S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOLow1__S,PHGOLow1__S,PHGOLow1__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S",
        "PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOHigh2_S,PHGOHigh2_S,PHGOHigh2_S,PHGOLow1__S,PHGOLow1__S,PHGOLow1__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOHigh3_S,PHGOHigh3_S,PHGOHigh3_S,PHGOHigh3_S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOHigh2_S,PHGOHigh2_S,PHGOHigh2_S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOHigh3_S,PHGOHigh3_S,PHGOHigh3_S,PHGOHigh3_S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOHigh3_S,PHGOHigh3_S,PHGOHigh3_S,PHGOHigh3_S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOHigh2_S,PHGOHigh2_S,PHGOHigh2_S",

        //"PHGOLow1__S,PHGOLow1__S,PHGOLow1__S,PHGOLow1__S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOHigh2_S,PHGOHigh2_S,PHGOHigh2_S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOLow1__S,PHGOLow1__S,PHGOLow1__S,PHGOLow1__S,PHGOHigh3_S,PHGOHigh3_S,PHGOHigh3_S,PHGOHigh3_S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOLow1__S,PHGOLow1__S,PHGOLow1__S,PHGOLow1__S,PHGOHigh2_S,PHGOHigh2_S,PHGOHigh2_S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOHigh2_S,PHGOHigh2_S,PHGOHigh2_S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOHigh3_S,PHGOHigh3_S,PHGOHigh3_S",
        //"PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOHigh3_S,PHGOHigh3_S,PHGOHigh3_S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOHigh3_S,PHGOHigh3_S,PHGOHigh3_S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOHigh2_S,PHGOHigh2_S,PHGOHigh2_S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOHigh3_S,PHGOHigh3_S,PHGOHigh3_S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOLow1__S,PHGOLow1__S,PHGOLow1__S,PHGOHigh2_S,PHGOHigh2_S,PHGOHigh2_S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S",
        //"PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOLow1__S,PHGOLow1__S,PHGOLow1__S,PHGOLow1__S,PHGOHigh2_S,PHGOHigh2_S,PHGOHigh2_S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOLow1__S,PHGOLow1__S,PHGOLow1__S,PHGOLow1__S,PHGOHigh2_S,PHGOHigh2_S,PHGOHigh2_S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOHigh2_S,PHGOHigh2_S,PHGOHigh2_S,PHGOLow1__S,PHGOLow1__S,PHGOLow1__S,PHGOLow1__S,PHGOHigh3_S,PHGOHigh3_S,PHGOHigh3_S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOHigh2_S,PHGOHigh2_S,PHGOHigh2_S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOHigh3_S,PHGOHigh3_S,PHGOHigh3_S",
        //"PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOHigh3_S,PHGOHigh3_S,PHGOHigh3_S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOHigh2_S,PHGOHigh2_S,PHGOHigh2_S,PHGOLow1__S,PHGOLow1__S,PHGOLow1__S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOHigh3_S,PHGOHigh3_S,PHGOHigh3_S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOLow1__S,PHGOLow1__S,PHGOLow1__S,PHGOLow1__S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOHigh2_S,PHGOHigh2_S,PHGOHigh2_S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOLow1__S,PHGOLow1__S,PHGOLow1__S,PHGOLow1__S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S",
        //"PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOHigh2_S,PHGOHigh2_S,PHGOHigh2_S,PHGOLow1__S,PHGOLow1__S,PHGOLow1__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOHigh3_S,PHGOHigh3_S,PHGOHigh3_S,PHGOHigh3_S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOHigh2_S,PHGOHigh2_S,PHGOHigh2_S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOTrans_S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOLow2__S,PHGOHigh3_S,PHGOHigh3_S,PHGOHigh3_S,PHGOHigh3_S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow3__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOLow4__S,PHGOHigh3_S,PHGOHigh3_S,PHGOHigh3_S,PHGOHigh3_S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh1_S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOHigh4_S,PHGOLow5__S,PHGOLow5__S,PHGOLow5__S,PHGOHigh2_S,PHGOHigh2_S,PHGOHigh2_S",
    };

    int idx = 0;
    for (int i = 0; i < m_vecReelStripPlan.size(); i++) {
        ReelSet set;
        for (int j = 0; j < m_nReel; j++) {
            ReelStrip strip;
            std::stringstream ss(phgoReelStrip[idx]);
            std::string item;
            while (std::getline(ss, item, ',')) {
                strip.push_back(item);
            }
            set.push_back(strip);
            idx++;
        }
        m_vecReelStripSets.push_back(set);
    }

    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_tmp;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        std::map<std::string, std::map<UINT8, BONUS>> perSym;
        std::map<UINT8, BONUS> e;
        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 500; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5000; e[5].ag = 0;
        perSym["PHGOHigh1_S"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 70; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 200; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 400; e[5].ag = 0;
        perSym["PHGOHigh2_S"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 300; e[5].ag = 0;
        perSym["PHGOHigh3_S"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 300; e[5].ag = 0;
        perSym["PHGOHigh4_S"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 200; e[5].ag = 0;
        perSym["PHGOLow1__S"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 200; e[5].ag = 0;
        perSym["PHGOLow2__S"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 30; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[5].ag = 0;
        perSym["PHGOLow3__S"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 30; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[5].ag = 0;
        perSym["PHGOLow4__S"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 30; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[5].ag = 0;
        perSym["PHGOLow5__S"] = e;
        e.clear();

        m_Bonus_tmp[i] = perSym;
    }

    m_Bonus_tmp[0]["PHGOHigh1_S"][5].coin = 0; m_Bonus_tmp[0]["PHGOHigh1_S"][5].ag = 5;// 10
    m_Bonus_tmp[1]["PHGOHigh1_S"][5].coin = 0; m_Bonus_tmp[1]["PHGOHigh1_S"][5].ag = 10;// 20
    m_Bonus_tmp[2]["PHGOHigh1_S"][5].coin = 0; m_Bonus_tmp[2]["PHGOHigh1_S"][5].ag = 15;// 30
    m_Bonus_tmp[3]["PHGOHigh1_S"][5].coin = 0; m_Bonus_tmp[3]["PHGOHigh1_S"][5].ag = 20;// 40
    m_Bonus_tmp[4]["PHGOHigh1_S"][5].coin = 0; m_Bonus_tmp[4]["PHGOHigh1_S"][5].ag = 25;// 50
    m_Bonus_tmp[5]["PHGOHigh1_S"][5].coin = 0; m_Bonus_tmp[5]["PHGOHigh1_S"][5].ag = 30;// 60
    m_Bonus_tmp[5]["PHGOHigh1_S"][4].coin = 0; m_Bonus_tmp[5]["PHGOHigh1_S"][4].ag = 3;
    m_Bonus_tmp[6]["PHGOHigh1_S"][5].coin = 0; m_Bonus_tmp[6]["PHGOHigh1_S"][5].ag = 40;// 80
    m_Bonus_tmp[6]["PHGOHigh1_S"][4].coin = 0; m_Bonus_tmp[6]["PHGOHigh1_S"][4].ag = 4;
    m_Bonus_tmp[6]["PHGOHigh2_S"][5].coin = 200; m_Bonus_tmp[6]["PHGOHigh2_S"][5].ag = 3;
    m_Bonus_tmp[7]["PHGOHigh1_S"][5].coin = 0; m_Bonus_tmp[7]["PHGOHigh1_S"][5].ag = 50;// 100
    m_Bonus_tmp[7]["PHGOHigh1_S"][4].coin = 0; m_Bonus_tmp[7]["PHGOHigh1_S"][4].ag = 5;
    m_Bonus_tmp[7]["PHGOHigh2_S"][5].coin = 0; m_Bonus_tmp[7]["PHGOHigh2_S"][5].ag = 4;
    m_Bonus_tmp[7]["PHGOHigh3_S"][5].coin = 0; m_Bonus_tmp[7]["PHGOHigh3_S"][5].ag = 3;
    m_Bonus_tmp[7]["PHGOHigh4_S"][5].coin = 0; m_Bonus_tmp[7]["PHGOHigh4_S"][5].ag = 3;
    m_Bonus_tmp[8]["PHGOHigh1_S"][5].coin = 0; m_Bonus_tmp[8]["PHGOHigh1_S"][5].ag = 75;// 150
    m_Bonus_tmp[8]["PHGOHigh1_S"][4].coin = 500; m_Bonus_tmp[8]["PHGOHigh1_S"][4].ag = 7;
    m_Bonus_tmp[8]["PHGOHigh2_S"][5].coin = 0; m_Bonus_tmp[8]["PHGOHigh2_S"][5].ag = 6;
    m_Bonus_tmp[8]["PHGOHigh2_S"][4].coin = 0; m_Bonus_tmp[8]["PHGOHigh2_S"][4].ag = 3;
    m_Bonus_tmp[8]["PHGOHigh3_S"][5].coin = 500; m_Bonus_tmp[8]["PHGOHigh3_S"][5].ag = 4;
    m_Bonus_tmp[8]["PHGOHigh4_S"][5].coin = 500; m_Bonus_tmp[8]["PHGOHigh4_S"][5].ag = 4;
    m_Bonus_tmp[8]["PHGOLow1__S"][5].coin = 0; m_Bonus_tmp[8]["PHGOLow1__S"][5].ag = 3;
    m_Bonus_tmp[8]["PHGOLow2__S"][5].coin = 0; m_Bonus_tmp[8]["PHGOLow2__S"][5].ag = 3;
    m_Bonus_tmp[9]["PHGOHigh1_S"][5].coin = 0; m_Bonus_tmp[9]["PHGOHigh1_S"][5].ag = 100;// 200
    m_Bonus_tmp[9]["PHGOHigh1_S"][4].coin = 0; m_Bonus_tmp[9]["PHGOHigh1_S"][4].ag = 10;
    m_Bonus_tmp[9]["PHGOHigh2_S"][5].coin = 0; m_Bonus_tmp[9]["PHGOHigh2_S"][5].ag = 8;
    m_Bonus_tmp[9]["PHGOHigh2_S"][4].coin = 0; m_Bonus_tmp[9]["PHGOHigh2_S"][4].ag = 4;
    m_Bonus_tmp[9]["PHGOHigh3_S"][5].coin = 0; m_Bonus_tmp[9]["PHGOHigh3_S"][5].ag = 6;
    m_Bonus_tmp[9]["PHGOHigh4_S"][5].coin = 0; m_Bonus_tmp[9]["PHGOHigh4_S"][5].ag = 6;
    m_Bonus_tmp[9]["PHGOLow1__S"][5].coin = 0; m_Bonus_tmp[9]["PHGOLow1__S"][5].ag = 4;
    m_Bonus_tmp[9]["PHGOLow2__S"][5].coin = 0; m_Bonus_tmp[9]["PHGOLow2__S"][5].ag = 4;
    m_Bonus_tmp[10]["PHGOHigh1_S"][5].coin = 0; m_Bonus_tmp[10]["PHGOHigh1_S"][5].ag = 250;// 500
    m_Bonus_tmp[10]["PHGOHigh1_S"][4].coin = 0; m_Bonus_tmp[10]["PHGOHigh1_S"][4].ag = 25;
    m_Bonus_tmp[10]["PHGOHigh1_S"][3].coin = 0; m_Bonus_tmp[10]["PHGOHigh1_S"][3].ag = 5;
    m_Bonus_tmp[10]["PHGOHigh2_S"][5].coin = 0; m_Bonus_tmp[10]["PHGOHigh2_S"][5].ag = 20;
    m_Bonus_tmp[10]["PHGOHigh2_S"][4].coin = 0; m_Bonus_tmp[10]["PHGOHigh2_S"][4].ag = 10;
    m_Bonus_tmp[10]["PHGOHigh2_S"][3].coin = 0; m_Bonus_tmp[10]["PHGOHigh2_S"][3].ag = 4;
    m_Bonus_tmp[10]["PHGOHigh3_S"][5].coin = 0; m_Bonus_tmp[10]["PHGOHigh3_S"][5].ag = 15;
    m_Bonus_tmp[10]["PHGOHigh3_S"][4].coin = 0; m_Bonus_tmp[10]["PHGOHigh3_S"][4].ag = 5;
    m_Bonus_tmp[10]["PHGOHigh4_S"][5].coin = 0; m_Bonus_tmp[10]["PHGOHigh4_S"][5].ag = 15;
    m_Bonus_tmp[10]["PHGOHigh4_S"][4].coin = 0; m_Bonus_tmp[10]["PHGOHigh4_S"][4].ag = 5;
    m_Bonus_tmp[10]["PHGOLow1__S"][5].coin = 0; m_Bonus_tmp[10]["PHGOLow1__S"][5].ag = 10;
    m_Bonus_tmp[10]["PHGOLow2__S"][5].coin = 0; m_Bonus_tmp[10]["PHGOLow2__S"][5].ag = 10;
    m_Bonus_tmp[10]["PHGOLow3__S"][5].coin = 0; m_Bonus_tmp[10]["PHGOLow3__S"][5].ag = 5;
    m_Bonus_tmp[10]["PHGOLow4__S"][5].coin = 0; m_Bonus_tmp[10]["PHGOLow4__S"][5].ag = 5;
    m_Bonus_tmp[10]["PHGOLow5__S"][5].coin = 0; m_Bonus_tmp[10]["PHGOLow5__S"][5].ag = 5;
    m_Bonus_tmp[11]["PHGOHigh1_S"][5].coin = 0; m_Bonus_tmp[11]["PHGOHigh1_S"][5].ag = 500;// 1000
    m_Bonus_tmp[11]["PHGOHigh1_S"][4].coin = 0; m_Bonus_tmp[11]["PHGOHigh1_S"][4].ag = 50;
    m_Bonus_tmp[11]["PHGOHigh1_S"][3].coin = 0; m_Bonus_tmp[11]["PHGOHigh1_S"][3].ag = 10;
    m_Bonus_tmp[11]["PHGOHigh2_S"][5].coin = 0; m_Bonus_tmp[11]["PHGOHigh2_S"][5].ag = 40;
    m_Bonus_tmp[11]["PHGOHigh2_S"][4].coin = 0; m_Bonus_tmp[11]["PHGOHigh2_S"][4].ag = 20;
    m_Bonus_tmp[11]["PHGOHigh2_S"][3].coin = 0; m_Bonus_tmp[11]["PHGOHigh2_S"][3].ag = 7;
    m_Bonus_tmp[11]["PHGOHigh3_S"][5].coin = 0; m_Bonus_tmp[11]["PHGOHigh3_S"][5].ag = 30;
    m_Bonus_tmp[11]["PHGOHigh3_S"][4].coin = 0; m_Bonus_tmp[11]["PHGOHigh3_S"][4].ag = 10;
    m_Bonus_tmp[11]["PHGOHigh3_S"][3].coin = 0; m_Bonus_tmp[11]["PHGOHigh3_S"][3].ag = 5;
    m_Bonus_tmp[11]["PHGOHigh4_S"][5].coin = 0; m_Bonus_tmp[11]["PHGOHigh4_S"][5].ag = 30;
    m_Bonus_tmp[11]["PHGOHigh4_S"][4].coin = 0; m_Bonus_tmp[11]["PHGOHigh4_S"][4].ag = 10;
    m_Bonus_tmp[11]["PHGOHigh4_S"][3].coin = 0; m_Bonus_tmp[11]["PHGOHigh4_S"][3].ag = 5;
    m_Bonus_tmp[11]["PHGOLow1__S"][5].coin = 0; m_Bonus_tmp[11]["PHGOLow1__S"][5].ag = 20;
    m_Bonus_tmp[11]["PHGOLow2__S"][5].coin = 0; m_Bonus_tmp[11]["PHGOLow2__S"][5].ag = 20;
    m_Bonus_tmp[11]["PHGOLow1__S"][4].coin = 0; m_Bonus_tmp[11]["PHGOLow1__S"][4].ag = 5;
    m_Bonus_tmp[11]["PHGOLow2__S"][4].coin = 0; m_Bonus_tmp[11]["PHGOLow2__S"][4].ag = 5; 
    m_Bonus_tmp[11]["PHGOLow3__S"][5].coin = 0; m_Bonus_tmp[11]["PHGOLow3__S"][5].ag = 10;
    m_Bonus_tmp[11]["PHGOLow4__S"][5].coin = 0; m_Bonus_tmp[11]["PHGOLow4__S"][5].ag = 10;
    m_Bonus_tmp[11]["PHGOLow5__S"][5].coin = 0; m_Bonus_tmp[11]["PHGOLow5__S"][5].ag = 10;
    m_Bonus_tmp[11]["PHGOLow3__S"][4].coin = 0; m_Bonus_tmp[11]["PHGOLow3__S"][4].ag = 3;
    m_Bonus_tmp[11]["PHGOLow4__S"][4].coin = 0; m_Bonus_tmp[11]["PHGOLow4__S"][4].ag = 3;
    m_Bonus_tmp[11]["PHGOLow5__S"][4].coin = 0; m_Bonus_tmp[11]["PHGOLow5__S"][4].ag = 3;

    BOOL start = FALSE;
    idx = 0;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_tmp, i) < AT(m_vecBetSteps, 0)) {
                continue;
            }
            start = TRUE;
        }
        m_Bonus[idx++] = m_Bonus_tmp[i];
        if (AT(m_vecBetSteps_tmp, i) == AT(m_vecBetSteps, m_vecBetSteps.size() - 1)) {
            break;
        }
    }
}

UINT16 RgPharosGold3::Init(UINT8 betStep) {
    m_nBetStep = betStep;
    m_nCurrentReelPlan = 0; //(myRandom() % m_vecReelStripPlan.size());
    m_shCurrentReelStrip = static_cast<uint16_t>(std::stoi(AT(m_vecReelStripPlan, m_nCurrentReelPlan)));
    return m_shCurrentReelStrip;
}

void RgPharosGold3::ChangeReelStrip(UINT16 NewReelPlan) {
    m_nCurrentReelPlan = NewReelPlan;
    m_shCurrentReelStrip = static_cast<uint16_t>(std::stoi(AT(m_vecReelStripPlan, m_nCurrentReelPlan)));
}

myVector<UINT8> RgPharosGold3::Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode, BOOL match) {
    m_bPrevSpinMatchedActive = FALSE;

    myVector<UINT8> result;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);

    if (bTest) {
        std::string matchSymbol = AT(m_vecSymbols, myRandom() % (m_vecSymbols.size() - 1));
        int line = (myRandom() % m_nWinLine);
        int weight = 1 + (myRandom() % 5);

        if (match) {
            weight = 3 + (myRandom() % 3);
            myVector<std::string> tmp = { "PHGOLow1__S", "PHGOLow2__S", "PHGOLow3__S", "PHGOLow4__S", "PHGOLow5__S" };
            matchSymbol = AT(tmp, myRandom() % tmp.size());
        }
        else {
            weight = 1;
        }

        for (int i = 0; i < m_nReel; i++) {
            ReelStrip reelStrip = AT(reelSet, i);
            int len = reelStrip.size() - 3;

            int valid_i[0x100];
            int valid_count = 0;
            for (int j = 0; j <= len; j++) {
                if (weight > i) {
                    if (matchSymbol == AT(reelStrip, j + g_match_lines_RgPharosGoldBase[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                else {
                    if (matchSymbol != AT(reelStrip, j + g_match_lines_RgPharosGoldBase[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
            }
            if (valid_count > 0) {
                int rand_index = myRandom() % valid_count;
                int chosen_i = valid_i[rand_index];
                result.push_back(chosen_i + 1);
            }
            else {
                result.push_back((myRandom() % (len - 1)) + 1);
            }
        }
    }
    else {
        result = _result;
    }
    m_vWinResult = result;

    normalMeter = 0;
    maxMeter = 0;
    UINT32 totalBonus = 0;
    for (int i = 0; i < m_nWinLine; i++) {
        int j = 1;
        UINT16 meter = ((UINT16)1 << (2 - g_match_lines_RgPharosGoldBase[i][0]));
        std::string firstSymbol = AT(AT(reelSet, 0), AT(result, 0) - 1 + g_match_lines_RgPharosGoldBase[i][0]);

        int nMatched = 1;
        for (; j < m_nMaxMatch; j++) {
            std::string prev_symbol = AT(AT(reelSet, j - 1), AT(result, j - 1) - 1 + g_match_lines_RgPharosGoldBase[i][j - 1]);
            std::string cur_symbol = AT(AT(reelSet, j), AT(result, j) - 1 + g_match_lines_RgPharosGoldBase[i][j]);

            if (firstSymbol == cur_symbol) {
                meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_RgPharosGoldBase[i][j]));
                nMatched++;
                continue;
            }
            if (j >= 3) {
                break;
            }

            nMatched = 1;
            firstSymbol = cur_symbol;
            meter = ((UINT16)1 << (3 * j + 2 - g_match_lines_RgPharosGoldBase[i][j]));
        }
        if (nMatched < m_mapSymbolMinMatch[firstSymbol]) {
            continue;
        }

        // monitor 2 meter
        std::string meterStr = m_mapSymbolMeterGoc[firstSymbol];
        size_t pos = meterStr.find('$');
        if (pos != std::string::npos) {
            meterStr = meterStr.replace(pos, 1, std::to_string(nMatched));
        }

        WinMeter e;
        e.line = i;
        e.meter = meter;
        e.meter2 = g_GrafficObjList.Str2GOCID(meterStr);
        e.symbol = firstSymbol;
        e.weight = nMatched;
        e.start = 0;
        e.bonus = m_Bonus[BetStep()][firstSymbol][nMatched];
        e.sound = MAX_SOUND_IDS;

        e.gameId = GOC_RgPharosGold3;
        e.gamePlan = m_shCurrentReelStrip;
        e.psIdx = 0;

        totalBonus += e.bonus.coin;

        if (e.meter2 != -1) {
            meters.push_back(e);
        }
        if (nMatched == m_nMaxMatch) {
            maxMeter |= meter;
        }
        else {
            normalMeter |= meter;
        }
    }
    if (bTest == FALSE) {
        myVector<std::string> available;
        for (int i = 0; i < meters.size(); i++) {
            std::string sym = AT(meters, i).symbol;
            myVector<int> convertableReels;
            for (int reel = 0; reel < 5; reel++) {
                if (ReelIsTransable(reel, sym)) {
                    convertableReels.push_back(reel);
                    continue;
                }
                if (CardInCol(reel, sym)) {
                    convertableReels.clear();
                    break;
                }
            }
            if (convertableReels.size() < AT(meters, i).weight) {
                continue;
            }
            BOOL transable = true;
            for (int j = 1; j < convertableReels.size(); j++) {
                if ((AT(convertableReels, j) - AT(convertableReels, j - 1)) > 1) {
                    transable = false;
                    break;
                }
            }
            if (transable) {
                available.push_back(sym);
            }
        }
        m_TransSymbol = "";
        if (available.size()) {
            m_TransSymbol = AT(available, myRandom() % available.size());
        }
        m_bPrevSpinMatchedActive = TRUE;
    }
    return result;
}

UINT16 RgPharosGold3::GetTransSymbolGOC() {
    if (m_TransSymbol != "") {
        return g_GrafficObjList.Str2GOCID(m_TransSymbol);
    }
    return 0;
}

myVector<InterruptPacketData> RgPharosGold3::InterruptAfterSpin() {
    myVector<InterruptPacketData> pkt;
    if (m_TransSymbol != "") {
        UINT16 goc = g_GrafficObjList.Str2GOCID(m_TransSymbol);
        pkt.push_back({ 0, 0, {0x01, 0x02, 0x28, 0x00, 0xaf, 0x38, 0x01, 0x00,
            static_cast<BYTE>(goc & 0xFF), static_cast<BYTE>((goc >> 8) & 0xFF), 0x04, 0x06, 0xac, 0x38} });
    }
    return pkt;
}


UINT8 RgPharosGold3::CardCount(std::string card) {
    int n = 0;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int col = 0; col < m_nReel; col++) {
        for (int k = 0; k < 3; k++) {
            std::string s = AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k);
            if (s == card) {
                n++;
            }
        }
    }
    return n;
}

BOOL RgPharosGold3::ReelIsTransable(int reel, std::string card) {
    int n = 0;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    int col = reel;
    for (int k = 0; k < 3; k++) {
        std::string s = AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k);
        if (s == card) {
            n++;
        }
    }
    return ((n >= 2) && (AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + 1) == card));
}

BOOL RgPharosGold3::CardInCol(int reel, std::string card) {
    int n = 0;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    int col = reel;
    for (int k = 0; k < 3; k++) {
        std::string s = AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k);
        if (s == card) {
            n++;
        }
    }
    return !!n;
}
