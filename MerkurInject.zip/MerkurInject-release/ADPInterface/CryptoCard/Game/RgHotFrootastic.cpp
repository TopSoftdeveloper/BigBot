#include "stdafx.h"
#include "RgHotFrootastic.h"

#define RgHotFrootastic_top "HFT_SEVEN_"
RgHotFrootastic::RgHotFrootastic() {
    m_nReel = 5;
    m_nWinLine = 10;
    m_nMaxMatch = 5;
    m_nBetStep = 0;

    m_strGameName = "RgHotFrootastic";

    myVector<UINT16> m_vecBetSteps_tmp;
    m_vecBetSteps_tmp.push_back(10);
    m_vecBetSteps_tmp.push_back(20);
    m_vecBetSteps_tmp.push_back(30);
    m_vecBetSteps_tmp.push_back(40);
    m_vecBetSteps_tmp.push_back(50);
    m_vecBetSteps_tmp.push_back(60);
    m_vecBetSteps_tmp.push_back(80);
    m_vecBetSteps_tmp.push_back(100);
    m_vecBetSteps_tmp.push_back(150);
    m_vecBetSteps_tmp.push_back(200);
#ifdef BIGBET_ACTIVE
    m_vecBetSteps_tmp.push_back(500);
    m_vecBetSteps_tmp.push_back(1000);
#endif
    LoadBets();

    m_vecSymbols.push_back("HFT_SEVEN_");
    m_vecSymbols.push_back("HFT_BELL__");
    m_vecSymbols.push_back("HFT_MELON_");
    m_vecSymbols.push_back("HFT_PLUM__");
    m_vecSymbols.push_back("HFT_ORANGE");
    m_vecSymbols.push_back("HFT_LEMON_");
    m_vecSymbols.push_back("HFT_CHERRY");

    m_mapSymbolMinMatch["HFT_SEVEN_"] = 3;
    m_mapSymbolMinMatch["HFT_BELL__"] = 3;
    m_mapSymbolMinMatch["HFT_MELON_"] = 3;
    m_mapSymbolMinMatch["HFT_PLUM__"] = 3;
    m_mapSymbolMinMatch["HFT_ORANGE"] = 3;
    m_mapSymbolMinMatch["HFT_LEMON_"] = 3;
    m_mapSymbolMinMatch["HFT_CHERRY"] = 3;

    m_mapSymbolMeterGoc["HFT_SEVEN_"] = "hftSeven$x";
    m_mapSymbolMeterGoc["HFT_BELL__"] = "hftBell$x";
    m_mapSymbolMeterGoc["HFT_MELON_"] = "hftMelon$x";
    m_mapSymbolMeterGoc["HFT_PLUM__"] = "hftPlumOrange$x";
    m_mapSymbolMeterGoc["HFT_ORANGE"] = "hftPlumOrange$x";
    m_mapSymbolMeterGoc["HFT_LEMON_"] = "hftLemonChery$x";
    m_mapSymbolMeterGoc["HFT_CHERRY"] = "hftLemonChery$x";

    m_vecWinLines.push_back("hftWinline1");
    m_vecWinLines.push_back("hftWinline2");
    m_vecWinLines.push_back("hftWinline3");
    m_vecWinLines.push_back("hftWinline4");
    m_vecWinLines.push_back("hftWinline5");
    m_vecWinLines.push_back("hftWinline6");
    m_vecWinLines.push_back("hftWinline7");
    m_vecWinLines.push_back("hftWinline8");
    m_vecWinLines.push_back("hftWinline9");
    m_vecWinLines.push_back("hftWinline10");

    m_vecLineSounds.push_back(SMP_HFRT_Line);
    m_vecLineSounds.push_back(SMP_HFRT_Line);
    m_vecLineSounds.push_back(SMP_HFRT_Line);
    m_vecLineSounds.push_back(SMP_HFRT_Line);
    m_vecLineSounds.push_back(SMP_HFRT_Line);
    m_vecLineSounds.push_back(SMP_HFRT_Line);
    m_vecLineSounds.push_back(SMP_HFRT_Line);
    m_vecLineSounds.push_back(SMP_HFRT_Line);
    m_vecLineSounds.push_back(SMP_HFRT_Line);
    m_vecLineSounds.push_back(SMP_HFRT_Line);

    m_vecWinSounds.push_back(SMP_HFRT_Tiny);
    m_vecWinSounds.push_back(SMP_HFRT_Small);
    m_vecWinSounds.push_back(SMP_HFRT_Med);
    m_vecWinSounds.push_back(SMP_HFRT_Large);
    m_vecWinSounds.push_back(SMP_HFRT_Xlarg);
    m_vecWinSounds.push_back(SMP_HFRT_Huge);

    m_vecReelStripPlan.push_back("hftW1A");
    m_vecReelStripPlan.push_back("hftW1B");

    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));

    char* cfrtReelStrip[] = {
        "HFT_SEVEN_,HFT_PLUM__,HFT_PLUM__,HFT_PLUM__,HFT_MELON_,HFT_SEVEN_,HFT_MELON_,HFT_MELON_,HFT_LEMON_,HFT_LEMON_,HFT_CHERRY,HFT_CHERRY,HFT_CHERRY,HFT_LEMON_,HFT_LEMON_,HFT_LEMON_,HFT_BELL__,HFT_BELL__,HFT_ORANGE,HFT_BELL__,HFT_ORANGE,HFT_ORANGE,HFT_ORANGE,HFT_ORANGE,HFT_PLUM__",
        "HFT_SEVEN_,HFT_ORANGE,HFT_ORANGE,HFT_ORANGE,HFT_BELL__,HFT_BELL__,HFT_SEVEN_,HFT_BELL__,HFT_CHERRY,HFT_CHERRY,HFT_CHERRY,HFT_CHERRY,HFT_PLUM__,HFT_PLUM__,HFT_PLUM__,HFT_LEMON_,HFT_PLUM__,HFT_LEMON_,HFT_LEMON_,HFT_LEMON_,HFT_MELON_,HFT_LEMON_,HFT_MELON_,HFT_MELON_,HFT_ORANGE",
        "HFT_SEVEN_,HFT_LEMON_,HFT_CHERRY,HFT_LEMON_,HFT_CHERRY,HFT_CHERRY,HFT_ORANGE,HFT_ORANGE,HFT_ORANGE,HFT_SEVEN_,HFT_ORANGE,HFT_BELL__,HFT_BELL__,HFT_CHERRY,HFT_BELL__,HFT_LEMON_,HFT_LEMON_,HFT_LEMON_,HFT_MELON_,HFT_MELON_,HFT_PLUM__,HFT_MELON_,HFT_PLUM__,HFT_PLUM__,HFT_PLUM__",
        "HFT_SEVEN_,HFT_PLUM__,HFT_PLUM__,HFT_PLUM__,HFT_PLUM__,HFT_SEVEN_,HFT_PLUM__,HFT_ORANGE,HFT_ORANGE,HFT_ORANGE,HFT_MELON_,HFT_MELON_,HFT_CHERRY,HFT_CHERRY,HFT_CHERRY,HFT_LEMON_,HFT_CHERRY,HFT_LEMON_,HFT_LEMON_,HFT_LEMON_,HFT_ORANGE,HFT_ORANGE,HFT_BELL__,HFT_BELL__",
        "HFT_SEVEN_,HFT_PLUM__,HFT_PLUM__,HFT_LEMON_,HFT_LEMON_,HFT_LEMON_,HFT_BELL__,HFT_BELL__,HFT_ORANGE,HFT_ORANGE,HFT_ORANGE,HFT_MELON_,HFT_MELON_,HFT_PLUM__,HFT_PLUM__,HFT_PLUM__,HFT_LEMON_,HFT_SEVEN_,HFT_CHERRY,HFT_CHERRY,HFT_CHERRY,HFT_ORANGE,HFT_ORANGE",

        "HFT_PLUM__,HFT_PLUM__,HFT_PLUM__,HFT_MELON_,HFT_BELL__,HFT_LEMON_,HFT_LEMON_,HFT_LEMON_,HFT_SEVEN_,HFT_ORANGE,HFT_ORANGE,HFT_ORANGE,HFT_CHERRY,HFT_CHERRY,HFT_CHERRY",
        "HFT_PLUM__,HFT_PLUM__,HFT_PLUM__,HFT_MELON_,HFT_BELL__,HFT_LEMON_,HFT_LEMON_,HFT_LEMON_,HFT_SEVEN_,HFT_ORANGE,HFT_ORANGE,HFT_ORANGE,HFT_CHERRY,HFT_CHERRY,HFT_CHERRY",
        "HFT_PLUM__,HFT_PLUM__,HFT_PLUM__,HFT_MELON_,HFT_BELL__,HFT_LEMON_,HFT_LEMON_,HFT_LEMON_,HFT_SEVEN_,HFT_ORANGE,HFT_ORANGE,HFT_ORANGE,HFT_CHERRY,HFT_CHERRY,HFT_CHERRY",
        "HFT_PLUM__,HFT_PLUM__,HFT_PLUM__,HFT_MELON_,HFT_BELL__,HFT_LEMON_,HFT_LEMON_,HFT_LEMON_,HFT_SEVEN_,HFT_ORANGE,HFT_ORANGE,HFT_ORANGE,HFT_CHERRY,HFT_CHERRY,HFT_CHERRY",
        "HFT_PLUM__,HFT_PLUM__,HFT_PLUM__,HFT_MELON_,HFT_BELL__,HFT_LEMON_,HFT_LEMON_,HFT_LEMON_,HFT_SEVEN_,HFT_ORANGE,HFT_ORANGE,HFT_ORANGE,HFT_CHERRY,HFT_CHERRY,HFT_CHERRY",
    };

    int idx = 0;
    for (int i = 0; i < m_vecReelStripPlan.size(); i++) {
        ReelSet set;
        for (int j = 0; j < m_nReel; j++) {
            ReelStrip strip;
            std::stringstream ss(cfrtReelStrip[idx]);
            std::string item;
            while (std::getline(ss, item, ',')) {
                strip.push_back(item);
            }
            set.push_back(strip);
            idx++;
        }
        m_vecReelStripSets.push_back(set);
    }

    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_tmp;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        std::map<std::string, std::map<UINT8, BONUS>> perSym;
        std::map<UINT8, BONUS> e;
        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 200; e[5].ag = 0;
        perSym["HFT_CHERRY"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 200; e[5].ag = 0;
        perSym["HFT_LEMON_"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 200; e[5].ag = 0;
        perSym["HFT_ORANGE"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 200; e[5].ag = 0;
        perSym["HFT_PLUM__"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 200; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 500; e[5].ag = 0;
        perSym["HFT_MELON_"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 200; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 500; e[5].ag = 0;
        perSym["HFT_BELL__"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 1000; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5000; e[5].ag = 0;
        perSym["HFT_SEVEN_"] = e;
        e.clear();

        m_Bonus_tmp[i] = perSym;
    }
    m_Bonus_tmp[m_vecBetSteps_tmp.size() - 1 - BIGBET_BETSTEP_EXTRA_COUNT]["HFT_SEVEN_"][5].coin = 80000;

    int nSavedBetVal = 10;
    int _line = 0;
    string data;
    PlayDB::GetInstance().LoadCheckPoint(m_strGameName, nSavedBetVal, _line, m_strCheckPoint);
    if (nSavedBetVal == -1) {
        nSavedBetVal = 10;
    }

    BOOL start = FALSE;
    idx = 0;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_tmp, i) < AT(m_vecBetSteps, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps, idx) == nSavedBetVal) {
            m_nBetStep = idx;
        }

        m_Bonus[idx++] = m_Bonus_tmp[i];
        if (AT(m_vecBetSteps_tmp, i) == AT(m_vecBetSteps, m_vecBetSteps.size() - 1)) {
            break;
        }
    }

    m_vecBetSteps_05.clear();
    m_vecBetSteps_10.clear();
    PrintAllBonus();
}

myVector<UINT8> RgHotFrootastic::Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) {
    m_bPrevSpinMatchedActive = FALSE;

    myVector<UINT8> result;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);

    BOOL mmcode = FALSE;
    if (bTest == FALSE) {
        mmcode = mmcode_get_active_status();
    }
    if (bTest == TRUE || mmcode == TRUE) {
        std::string matchSymbol = AT(m_vecSymbols, myRandom() % m_vecSymbols.size());
        int line = (myRandom() % m_nWinLine);
        int weight = 1 + (myRandom() % 5);

        if (mmcode) {
            mmcode_set_deactive();
            weight = m_nMaxMatch;
            matchSymbol = RgHotFrootastic_top;
        }
        for (int i = 0; i < m_nReel; i++) {
            ReelStrip reelStrip = AT(reelSet, i);
            int len = reelStrip.size() - 3;

            int valid_i[0x100];
            int valid_count = 0;
            for (int j = 0; j <= len; j++) {
                if (weight > i) {
                    if (matchSymbol == AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                else {
                    if (matchSymbol != AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
            }
            if (valid_count > 0) {
                int rand_index = myRandom() % valid_count;
                int chosen_i = valid_i[rand_index];
                result.push_back(chosen_i + 1);
            }
            else {
                result.push_back((myRandom() % (len - 1)) + 1);
            }
        }
    }
    else {
        result = _result;
    }
    normalMeter = 0;
    maxMeter = 0;
    BONUS totalBonus = { 0, 0 };
    for (int i = 0; i < m_nWinLine; i++) {
        int j = 1;
        UINT16 meter = ((UINT16)1 << (2 - g_match_lines_10_5[i][0]));

        for (; j < m_nMaxMatch; j++) {
            if (AT(AT(reelSet, j - 1), AT(result, j - 1) - 1 + g_match_lines_10_5[i][j - 1]) == AT(AT(reelSet, j), AT(result, j) - 1 + g_match_lines_10_5[i][j])) {

                meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
                continue;
            }
            break;
        }
        std::string firstSymbol = AT(AT(reelSet, 0), AT(result, 0) - 1 + g_match_lines_10_5[i][0]);
        if (j < m_mapSymbolMinMatch[firstSymbol]) {
            continue;
        }

        // monitor 2 meter
        std::string meterStr = m_mapSymbolMeterGoc[firstSymbol];
        size_t pos = meterStr.find('$');
        if (pos != std::string::npos) {
            meterStr = meterStr.replace(pos, 1, std::to_string(j));
        }

        WinMeter e;
        e.line = i;
        e.meter = meter;
        e.meter2 = g_GrafficObjList.Str2GOCID(meterStr);
        e.symbol = firstSymbol;
        e.weight = j;
        e.start = 0;
        e.bonus = m_Bonus[BetStep()][firstSymbol][j];
        e.sound = MAX_SOUND_IDS;

        totalBonus.coin += e.bonus.coin;
        totalBonus.ag += e.bonus.ag;

        if (e.meter2 != -1) {
            meters.push_back(e);
        }
        if (j == m_nMaxMatch) {
            maxMeter |= meter;
        }
        else {
            normalMeter |= meter;
        }
        if (bTest == FALSE) {
            m_bPrevSpinMatchedActive = TRUE;
        }
    }
    if (bTest == FALSE) {
        m_vWinResult = result;
        updateCheckPoint();
    }
    if (bTest == FALSE) {
        if (totalBonus.coin > 0 || totalBonus.ag > 0) {
            BonusSound = getSoundByID(WinSound(totalBonus.coin + totalBonus.ag * 1000));
        }
        else {
            BonusSound.duration = 0;
            BonusSound.soundID = MAX_SOUND_IDS;
        }
    }
    return result;
}