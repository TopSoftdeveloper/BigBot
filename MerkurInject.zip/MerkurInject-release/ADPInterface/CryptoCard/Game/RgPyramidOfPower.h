#pragma once

#include "ReelGame.h"

class RgPyramidOfPower : public ReelGame
{
public:
	UINT8 m_nExtrWildReel;
	UINT8 m_nExtrWildRow;

	RgPyramidOfPower::RgPyramidOfPower();
	BOOL IsWild(int cur_reel, int cur_row);
	BOOL WildExist();
	void SetWildPos();

	UINT16 Run() override;
	myVector<UINT8> Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& WinSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) override;
	UINT16 SpinTime_MS() override;
	int LineSwapDelay(int WinIdx) override;

	myVector<UINT8> ShowTotalWinLines(myVector<WinMeter> SpinMeters) override;

	bool RTP_force_bigWin() override;
};
