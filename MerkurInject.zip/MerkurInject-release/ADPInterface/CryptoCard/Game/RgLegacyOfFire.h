#pragma once

#include "ReelGame.h"

class RgLegacyOfFire : public ReelGame
{
public:
	RgLegacyOfFire::RgLegacyOfFire();

	myVector<int> m_nForceMatchInFreeMode;

	UINT8 m_nFreeModeTotalSpin;
	UINT8 m_nFreeModeGoneSpin;
	BONUS m_nFreeModeTotalBonus;
	BOOL m_bFreeMode;
	UINT8 m_nCountToConvert;

	myVector<WinMeter> m_vWinMeters;
	std::map<std::string, UINT16> m_vWinLineSounds;

	UINT8 CardCount(std::string card);
	BOOL ScatterInCol(int col);
	UINT8 CardNumInCol(int col, std::string card);

	UINT16 Run() override;
	myVector<UINT8> Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& WinSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) override;
	UINT16 LineSound(UINT Line, std::string symbol, UINT8 weight) override;
	int LineSwapDelay(int WinIdx) override;
	UINT16 SpinTime_MS() override;
	BOOL CanFreeMode() override;
	myVector<InterruptPacketData> EnterFreeGame(std::string) override;
	myVector<InterruptPacketData> InterruptBeforeSpin() override;
	myVector<InterruptPacketData> InterruptAfterMoveBonus(BOOL& EndFree) override;
	myVector<InterruptPacketData> InterruptAfterSpin() override;

	myVector<UINT8> ShowTotalWinLines(myVector<WinMeter> SpinMeters) override;

	bool RTP_force_bigWin() override;
	BOOL SelectedableReelsInFreeGame(myVector<UINT8> result) override;

	void updateCheckPoint() override;
};
