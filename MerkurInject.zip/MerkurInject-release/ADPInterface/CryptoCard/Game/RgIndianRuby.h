#pragma once

#include "ReelGame.h"

class RgIndianRuby : public ReelGame
{
public:
	BOOL m_bFreeMode;
	myVector<UINT16> m_vecEWinSounds;
	myVector<Position> m_vEle;

	RgIndianRuby::RgIndianRuby();
	UINT8 CardCount(std::string card);
	void ChangeReelStrip(UINT16 NewReelPlan) override;
	BOOL IsEle(int col, int row);

	UINT16 Run() override;
	UINT16 SpinTime_MS() override;
	int LineSwapDelay(int WinIdx) override;
	UINT16 MagicCount() override;
	myVector<UINT8> Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& WinSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) override;
	BOOL CanFreeMode() override;
	myVector<InterruptPacketData> EnterFreeGame(std::string) override;
	myVector<InterruptPacketData> InterruptAfterMoveBonus(BOOL& EndFree) override;

	myVector<InterruptPacketData> MousePressed(MousePosition p) override;
	myVector<UINT8> ShowTotalWinLines(myVector<WinMeter> SpinMeters) override;

	bool RTP_force_bigWin();
	void updateCheckPoint() override;
};
