#include "stdafx.h"
#include "RgMultiWild243.h"

#define RgMultiWild243_wild "MUWI243SymWild"
#define RgMultiWild243_top "MUWI243SymSieben"
RgMultiWild243::RgMultiWild243() {
    m_nReel = 5;
    m_nWinLine = 243;
    m_nMaxMatch = 5;
    m_nBetStep = 0;

    m_strGameName = "RgMultiWild243";

    myVector<UINT16> m_vecBetSteps_tmp;
    m_vecBetSteps_tmp.push_back(10);
    m_vecBetSteps_tmp.push_back(20);
    m_vecBetSteps_tmp.push_back(30);
    m_vecBetSteps_tmp.push_back(40);
    m_vecBetSteps_tmp.push_back(50);
    m_vecBetSteps_tmp.push_back(60);
    m_vecBetSteps_tmp.push_back(80);
    m_vecBetSteps_tmp.push_back(100);
    m_vecBetSteps_tmp.push_back(150);
    m_vecBetSteps_tmp.push_back(200);
    m_vecBetSteps_tmp.push_back(300);
    m_vecBetSteps_tmp.push_back(400);
#ifdef BIGBET_ACTIVE
    //m_vecBetSteps_tmp.push_back(500);
    //m_vecBetSteps_tmp.push_back(1000);
    //m_vecBetSteps_tmp.push_back(2000);
#endif
    LoadBets();

    m_vecSymbols.push_back("MUWI243SymSieben");
    m_vecSymbols.push_back("MUWI243SymMelone");
    m_vecSymbols.push_back("MUWI243SymGlocke");
    m_vecSymbols.push_back("MUWI243SymTraube");
    m_vecSymbols.push_back("MUWI243SymPflaume");
    m_vecSymbols.push_back("MUWI243SymOrange");
    m_vecSymbols.push_back("MUWI243SymZitrone");
    m_vecSymbols.push_back("MUWI243SymKirsche");
    m_vecSymbols.push_back("MUWI243SymWild");

    m_mapSymbolMinMatch["MUWI243SymSieben"] = 3;
    m_mapSymbolMinMatch["MUWI243SymMelone"] = 3;
    m_mapSymbolMinMatch["MUWI243SymGlocke"] = 3;
    m_mapSymbolMinMatch["MUWI243SymTraube"] = 3;
    m_mapSymbolMinMatch["MUWI243SymPflaume"] = 3;
    m_mapSymbolMinMatch["MUWI243SymOrange"] = 3;
    m_mapSymbolMinMatch["MUWI243SymZitrone"] = 3;
    m_mapSymbolMinMatch["MUWI243SymKirsche"] = 3;

    m_vecWinLines.push_back("WinL1MUWI243");

    //m_vecLineSounds.push_back(SMP_BS_Win5Part_1);
    //m_vecWinSounds.push_back(SMP_BS_WinTiny);
           
    m_vecReelStripPlan.push_back("MUWI243WalzeA1");
    
    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));

    char* muwi243ReelStrip[] = {
        "MUWI243SymZitrone,MUWI243SymMelone,MUWI243SymTraube,MUWI243SymMelone,MUWI243SymMelone,MUWI243SymZitrone,MUWI243SymSieben,MUWI243SymZitrone,MUWI243SymPflaume,MUWI243SymSieben,MUWI243SymMelone,MUWI243SymKirsche,MUWI243SymGlocke,MUWI243SymMelone,MUWI243SymSieben,MUWI243SymOrange,MUWI243SymTraube,MUWI243SymKirsche,MUWI243SymKirsche,MUWI243SymMelone,MUWI243SymSieben,MUWI243SymTraube,MUWI243SymOrange,MUWI243SymPflaume,MUWI243SymKirsche,MUWI243SymMelone,MUWI243SymZitrone,MUWI243SymMelone,MUWI243SymTraube,MUWI243SymMelone,MUWI243SymTraube,MUWI243SymTraube,MUWI243SymPflaume,MUWI243SymGlocke,MUWI243SymSieben,MUWI243SymGlocke,MUWI243SymGlocke,MUWI243SymPflaume,MUWI243SymZitrone,MUWI243SymGlocke,MUWI243SymMelone,MUWI243SymSieben,MUWI243SymOrange,MUWI243SymKirsche,MUWI243SymMelone,MUWI243SymSieben,MUWI243SymTraube,MUWI243SymOrange,MUWI243SymOrange,MUWI243SymOrange,MUWI243SymPflaume,MUWI243SymTraube,MUWI243SymSieben,MUWI243SymPflaume,MUWI243SymTraube,MUWI243SymPflaume,MUWI243SymGlocke,MUWI243SymTraube,MUWI243SymZitrone,MUWI243SymOrange,MUWI243SymZitrone,MUWI243SymZitrone,MUWI243SymOrange,MUWI243SymMelone,MUWI243SymZitrone,MUWI243SymSieben,MUWI243SymZitrone,MUWI243SymPflaume,MUWI243SymSieben,MUWI243SymMelone,MUWI243SymKirsche,MUWI243SymPflaume,MUWI243SymPflaume,MUWI243SymGlocke,MUWI243SymSieben,MUWI243SymGlocke,MUWI243SymGlocke,MUWI243SymPflaume,MUWI243SymGlocke,MUWI243SymTraube,MUWI243SymZitrone,MUWI243SymOrange,MUWI243SymOrange,MUWI243SymZitrone,MUWI243SymSieben,MUWI243SymPflaume,MUWI243SymKirsche,MUWI243SymPflaume,MUWI243SymPflaume,MUWI243SymKirsche,MUWI243SymSieben,MUWI243SymGlocke,MUWI243SymTraube,MUWI243SymZitrone,MUWI243SymOrange,MUWI243SymPflaume,MUWI243SymTraube,MUWI243SymSieben,MUWI243SymPflaume,MUWI243SymTraube,MUWI243SymZitrone,MUWI243SymPflaume,MUWI243SymKirsche,MUWI243SymSieben,MUWI243SymGlocke,MUWI243SymTraube,MUWI243SymOrange,MUWI243SymZitrone,MUWI243SymSieben,MUWI243SymKirsche,MUWI243SymZitrone,MUWI243SymGlocke,MUWI243SymMelone,MUWI243SymSieben,MUWI243SymOrange,MUWI243SymZitrone,MUWI243SymMelone,MUWI243SymTraube,MUWI243SymMelone,MUWI243SymTraube,MUWI243SymTraube,MUWI243SymMelone,MUWI243SymPflaume,MUWI243SymZitrone,MUWI243SymMelone,MUWI243SymKirsche,MUWI243SymMelone,MUWI243SymSieben,MUWI243SymTraube,MUWI243SymOrange,MUWI243SymOrange,MUWI243SymOrange,MUWI243SymPflaume,MUWI243SymTraube,MUWI243SymSieben,MUWI243SymPflaume,MUWI243SymTraube,MUWI243SymPflaume,MUWI243SymOrange,MUWI243SymZitrone,MUWI243SymZitrone,MUWI243SymOrange,MUWI243SymMelone,MUWI243SymMelone,MUWI243SymZitrone,MUWI243SymSieben,MUWI243SymZitrone,MUWI243SymMelone,MUWI243SymSieben,MUWI243SymMelone,MUWI243SymKirsche,MUWI243SymPflaume,MUWI243SymPflaume,MUWI243SymGlocke,MUWI243SymSieben,MUWI243SymGlocke,MUWI243SymGlocke,MUWI243SymPflaume,MUWI243SymTraube,MUWI243SymOrange,MUWI243SymZitrone,MUWI243SymSieben,MUWI243SymPflaume,MUWI243SymKirsche,MUWI243SymPflaume,MUWI243SymPflaume,MUWI243SymKirsche,MUWI243SymSieben,MUWI243SymGlocke,MUWI243SymTraube,MUWI243SymZitrone,MUWI243SymOrange,MUWI243SymTraube,MUWI243SymZitrone,MUWI243SymTraube,MUWI243SymTraube,MUWI243SymKirsche,MUWI243SymMelone",
        "MUWI243SymZitrone,MUWI243SymOrange,MUWI243SymZitrone,MUWI243SymSieben,MUWI243SymKirsche,MUWI243SymOrange,MUWI243SymKirsche,MUWI243SymKirsche,MUWI243SymWild,MUWI243SymZitrone,MUWI243SymMelone,MUWI243SymWild,MUWI243SymTraube,MUWI243SymMelone,MUWI243SymTraube,MUWI243SymTraube,MUWI243SymMelone,MUWI243SymPflaume,MUWI243SymZitrone,MUWI243SymMelone,MUWI243SymKirsche,MUWI243SymMelone,MUWI243SymSieben,MUWI243SymTraube,MUWI243SymOrange,MUWI243SymOrange,MUWI243SymOrange,MUWI243SymPflaume,MUWI243SymTraube,MUWI243SymSieben,MUWI243SymPflaume,MUWI243SymTraube,MUWI243SymPflaume,MUWI243SymOrange,MUWI243SymZitrone,MUWI243SymZitrone,MUWI243SymOrange,MUWI243SymMelone,MUWI243SymMelone,MUWI243SymPflaume,MUWI243SymPflaume,MUWI243SymGlocke,MUWI243SymSieben,MUWI243SymGlocke,MUWI243SymGlocke,MUWI243SymPflaume,MUWI243SymTraube,MUWI243SymOrange,MUWI243SymZitrone,MUWI243SymSieben,MUWI243SymPflaume,MUWI243SymKirsche,MUWI243SymPflaume,MUWI243SymPflaume,MUWI243SymKirsche,MUWI243SymSieben,MUWI243SymGlocke,MUWI243SymTraube,MUWI243SymWild,MUWI243SymZitrone,MUWI243SymOrange,MUWI243SymTraube,MUWI243SymZitrone,MUWI243SymTraube,MUWI243SymTraube,MUWI243SymGlocke,MUWI243SymMelone,MUWI243SymZitrone,MUWI243SymSieben,MUWI243SymZitrone,MUWI243SymPflaume,MUWI243SymSieben,MUWI243SymMelone,MUWI243SymKirsche,MUWI243SymGlocke,MUWI243SymMelone,MUWI243SymWild,MUWI243SymSieben,MUWI243SymOrange,MUWI243SymTraube,MUWI243SymKirsche,MUWI243SymKirsche,MUWI243SymPflaume,MUWI243SymKirsche,MUWI243SymMelone,MUWI243SymZitrone,MUWI243SymMelone,MUWI243SymTraube,MUWI243SymMelone,MUWI243SymTraube,MUWI243SymTraube,MUWI243SymMelone,MUWI243SymPflaume,MUWI243SymZitrone,MUWI243SymMelone,MUWI243SymKirsche,MUWI243SymMelone,MUWI243SymSieben,MUWI243SymTraube,MUWI243SymOrange,MUWI243SymOrange,MUWI243SymOrange,MUWI243SymPflaume,MUWI243SymTraube,MUWI243SymSieben,MUWI243SymPflaume,MUWI243SymTraube,MUWI243SymPflaume,MUWI243SymOrange,MUWI243SymZitrone,MUWI243SymZitrone,MUWI243SymOrange,MUWI243SymMelone,MUWI243SymMelone,MUWI243SymPflaume,MUWI243SymPflaume,MUWI243SymGlocke,MUWI243SymSieben,MUWI243SymGlocke,MUWI243SymGlocke,MUWI243SymPflaume,MUWI243SymTraube,MUWI243SymOrange,MUWI243SymZitrone,MUWI243SymSieben,MUWI243SymPflaume,MUWI243SymKirsche,MUWI243SymPflaume,MUWI243SymPflaume,MUWI243SymKirsche,MUWI243SymSieben,MUWI243SymGlocke,MUWI243SymTraube,MUWI243SymZitrone,MUWI243SymOrange,MUWI243SymTraube,MUWI243SymZitrone,MUWI243SymTraube,MUWI243SymTraube,MUWI243SymGlocke,MUWI243SymMelone,MUWI243SymZitrone,MUWI243SymSieben,MUWI243SymZitrone,MUWI243SymPflaume,MUWI243SymSieben,MUWI243SymMelone,MUWI243SymKirsche,MUWI243SymGlocke,MUWI243SymMelone,MUWI243SymSieben,MUWI243SymOrange,MUWI243SymTraube,MUWI243SymKirsche,MUWI243SymKirsche,MUWI243SymPflaume,MUWI243SymKirsche,MUWI243SymMelone,MUWI243SymTraube,MUWI243SymTraube,MUWI243SymMelone,MUWI243SymTraube,MUWI243SymPflaume,MUWI243SymKirsche,MUWI243SymSieben,MUWI243SymTraube,MUWI243SymOrange,MUWI243SymOrange,MUWI243SymOrange,MUWI243SymPflaume,MUWI243SymTraube,MUWI243SymSieben,MUWI243SymTraube,MUWI243SymPflaume,MUWI243SymOrange,MUWI243SymZitrone,MUWI243SymZitrone,MUWI243SymOrange,MUWI243SymPflaume,MUWI243SymPflaume,MUWI243SymSieben,MUWI243SymGlocke,MUWI243SymPflaume,MUWI243SymOrange,MUWI243SymZitrone,MUWI243SymSieben,MUWI243SymKirsche,MUWI243SymKirsche,MUWI243SymSieben",
        "MUWI243SymKirsche,MUWI243SymSieben,MUWI243SymGlocke,MUWI243SymGlocke,MUWI243SymKirsche,MUWI243SymGlocke,MUWI243SymKirsche,MUWI243SymKirsche,MUWI243SymWild,MUWI243SymZitrone,MUWI243SymMelone,MUWI243SymWild,MUWI243SymTraube,MUWI243SymMelone,MUWI243SymTraube,MUWI243SymTraube,MUWI243SymMelone,MUWI243SymPflaume,MUWI243SymZitrone,MUWI243SymMelone,MUWI243SymKirsche,MUWI243SymMelone,MUWI243SymSieben,MUWI243SymTraube,MUWI243SymOrange,MUWI243SymOrange,MUWI243SymOrange,MUWI243SymPflaume,MUWI243SymTraube,MUWI243SymSieben,MUWI243SymPflaume,MUWI243SymTraube,MUWI243SymPflaume,MUWI243SymOrange,MUWI243SymZitrone,MUWI243SymZitrone,MUWI243SymOrange,MUWI243SymMelone,MUWI243SymMelone,MUWI243SymPflaume,MUWI243SymPflaume,MUWI243SymGlocke,MUWI243SymSieben,MUWI243SymGlocke,MUWI243SymGlocke,MUWI243SymPflaume,MUWI243SymTraube,MUWI243SymOrange,MUWI243SymZitrone,MUWI243SymSieben,MUWI243SymPflaume,MUWI243SymKirsche,MUWI243SymPflaume,MUWI243SymPflaume,MUWI243SymKirsche,MUWI243SymSieben,MUWI243SymGlocke,MUWI243SymTraube,MUWI243SymWild,MUWI243SymZitrone,MUWI243SymOrange,MUWI243SymTraube,MUWI243SymZitrone,MUWI243SymTraube,MUWI243SymTraube,MUWI243SymGlocke,MUWI243SymMelone,MUWI243SymZitrone,MUWI243SymSieben,MUWI243SymZitrone,MUWI243SymPflaume,MUWI243SymSieben,MUWI243SymMelone,MUWI243SymKirsche,MUWI243SymGlocke,MUWI243SymMelone,MUWI243SymWild,MUWI243SymSieben,MUWI243SymOrange,MUWI243SymTraube,MUWI243SymKirsche,MUWI243SymKirsche,MUWI243SymPflaume,MUWI243SymKirsche,MUWI243SymMelone,MUWI243SymWild,MUWI243SymZitrone,MUWI243SymMelone,MUWI243SymWild,MUWI243SymTraube,MUWI243SymMelone,MUWI243SymTraube,MUWI243SymTraube,MUWI243SymMelone,MUWI243SymPflaume,MUWI243SymZitrone,MUWI243SymMelone,MUWI243SymKirsche,MUWI243SymMelone,MUWI243SymSieben,MUWI243SymTraube,MUWI243SymOrange,MUWI243SymOrange,MUWI243SymOrange,MUWI243SymPflaume,MUWI243SymTraube,MUWI243SymSieben,MUWI243SymPflaume,MUWI243SymTraube,MUWI243SymPflaume,MUWI243SymOrange,MUWI243SymZitrone,MUWI243SymZitrone,MUWI243SymOrange,MUWI243SymMelone,MUWI243SymMelone,MUWI243SymPflaume,MUWI243SymPflaume,MUWI243SymGlocke,MUWI243SymSieben,MUWI243SymGlocke,MUWI243SymGlocke,MUWI243SymPflaume,MUWI243SymTraube,MUWI243SymOrange,MUWI243SymZitrone,MUWI243SymSieben,MUWI243SymPflaume,MUWI243SymKirsche,MUWI243SymPflaume,MUWI243SymPflaume,MUWI243SymKirsche,MUWI243SymSieben,MUWI243SymGlocke,MUWI243SymTraube,MUWI243SymWild,MUWI243SymZitrone,MUWI243SymOrange,MUWI243SymTraube,MUWI243SymZitrone,MUWI243SymTraube,MUWI243SymTraube,MUWI243SymGlocke,MUWI243SymMelone,MUWI243SymZitrone,MUWI243SymSieben,MUWI243SymZitrone,MUWI243SymPflaume,MUWI243SymSieben,MUWI243SymMelone,MUWI243SymKirsche,MUWI243SymGlocke,MUWI243SymMelone,MUWI243SymWild,MUWI243SymSieben,MUWI243SymOrange,MUWI243SymTraube,MUWI243SymKirsche,MUWI243SymKirsche,MUWI243SymPflaume,MUWI243SymKirsche,MUWI243SymMelone,MUWI243SymZitrone,MUWI243SymMelone,MUWI243SymTraube,MUWI243SymMelone,MUWI243SymTraube,MUWI243SymTraube,MUWI243SymMelone,MUWI243SymPflaume,MUWI243SymZitrone,MUWI243SymKirsche,MUWI243SymSieben,MUWI243SymTraube,MUWI243SymOrange,MUWI243SymOrange,MUWI243SymOrange,MUWI243SymPflaume,MUWI243SymTraube,MUWI243SymSieben,MUWI243SymPflaume,MUWI243SymZitrone,MUWI243SymZitrone,MUWI243SymGlocke,MUWI243SymSieben,MUWI243SymGlocke,MUWI243SymGlocke,MUWI243SymZitrone,MUWI243SymSieben,MUWI243SymKirsche",
        "MUWI243SymOrange,MUWI243SymZitrone,MUWI243SymSieben,MUWI243SymZitrone,MUWI243SymZitrone,MUWI243SymGlocke,MUWI243SymMelone,MUWI243SymZitrone,MUWI243SymWild,MUWI243SymZitrone,MUWI243SymMelone,MUWI243SymWild,MUWI243SymTraube,MUWI243SymMelone,MUWI243SymTraube,MUWI243SymTraube,MUWI243SymMelone,MUWI243SymPflaume,MUWI243SymZitrone,MUWI243SymMelone,MUWI243SymKirsche,MUWI243SymMelone,MUWI243SymSieben,MUWI243SymTraube,MUWI243SymOrange,MUWI243SymOrange,MUWI243SymOrange,MUWI243SymPflaume,MUWI243SymTraube,MUWI243SymSieben,MUWI243SymPflaume,MUWI243SymTraube,MUWI243SymPflaume,MUWI243SymOrange,MUWI243SymZitrone,MUWI243SymZitrone,MUWI243SymOrange,MUWI243SymMelone,MUWI243SymMelone,MUWI243SymPflaume,MUWI243SymPflaume,MUWI243SymGlocke,MUWI243SymSieben,MUWI243SymGlocke,MUWI243SymGlocke,MUWI243SymPflaume,MUWI243SymTraube,MUWI243SymOrange,MUWI243SymZitrone,MUWI243SymSieben,MUWI243SymPflaume,MUWI243SymKirsche,MUWI243SymPflaume,MUWI243SymPflaume,MUWI243SymKirsche,MUWI243SymSieben,MUWI243SymGlocke,MUWI243SymTraube,MUWI243SymWild,MUWI243SymZitrone,MUWI243SymOrange,MUWI243SymTraube,MUWI243SymZitrone,MUWI243SymTraube,MUWI243SymTraube,MUWI243SymGlocke,MUWI243SymMelone,MUWI243SymZitrone,MUWI243SymSieben,MUWI243SymZitrone,MUWI243SymPflaume,MUWI243SymSieben,MUWI243SymMelone,MUWI243SymKirsche,MUWI243SymGlocke,MUWI243SymMelone,MUWI243SymWild,MUWI243SymSieben,MUWI243SymOrange,MUWI243SymTraube,MUWI243SymKirsche,MUWI243SymKirsche,MUWI243SymPflaume,MUWI243SymKirsche,MUWI243SymMelone,MUWI243SymWild,MUWI243SymZitrone,MUWI243SymMelone,MUWI243SymWild,MUWI243SymTraube,MUWI243SymMelone,MUWI243SymTraube,MUWI243SymTraube,MUWI243SymMelone,MUWI243SymPflaume,MUWI243SymZitrone,MUWI243SymMelone,MUWI243SymKirsche,MUWI243SymMelone,MUWI243SymSieben,MUWI243SymTraube,MUWI243SymOrange,MUWI243SymOrange,MUWI243SymOrange,MUWI243SymPflaume,MUWI243SymTraube,MUWI243SymSieben,MUWI243SymPflaume,MUWI243SymTraube,MUWI243SymPflaume,MUWI243SymOrange,MUWI243SymZitrone,MUWI243SymZitrone,MUWI243SymOrange,MUWI243SymMelone,MUWI243SymMelone,MUWI243SymPflaume,MUWI243SymPflaume,MUWI243SymGlocke,MUWI243SymSieben,MUWI243SymGlocke,MUWI243SymGlocke,MUWI243SymPflaume,MUWI243SymTraube,MUWI243SymOrange,MUWI243SymZitrone,MUWI243SymSieben,MUWI243SymPflaume,MUWI243SymKirsche,MUWI243SymPflaume,MUWI243SymPflaume,MUWI243SymKirsche,MUWI243SymSieben,MUWI243SymGlocke,MUWI243SymTraube,MUWI243SymKirsche,MUWI243SymZitrone,MUWI243SymOrange,MUWI243SymTraube,MUWI243SymZitrone,MUWI243SymTraube,MUWI243SymTraube,MUWI243SymGlocke,MUWI243SymMelone,MUWI243SymZitrone,MUWI243SymSieben,MUWI243SymZitrone,MUWI243SymPflaume,MUWI243SymSieben,MUWI243SymMelone,MUWI243SymKirsche,MUWI243SymGlocke,MUWI243SymMelone,MUWI243SymKirsche,MUWI243SymSieben,MUWI243SymOrange,MUWI243SymTraube,MUWI243SymKirsche,MUWI243SymKirsche,MUWI243SymPflaume,MUWI243SymKirsche,MUWI243SymMelone,MUWI243SymKirsche,MUWI243SymZitrone,MUWI243SymMelone,MUWI243SymKirsche,MUWI243SymTraube,MUWI243SymMelone,MUWI243SymTraube,MUWI243SymTraube,MUWI243SymMelone,MUWI243SymGlocke,MUWI243SymZitrone,MUWI243SymMelone,MUWI243SymKirsche,MUWI243SymMelone,MUWI243SymSieben,MUWI243SymTraube,MUWI243SymOrange,MUWI243SymOrange,MUWI243SymOrange,MUWI243SymTraube,MUWI243SymSieben,MUWI243SymKirsche,MUWI243SymKirsche,MUWI243SymOrange,MUWI243SymZitrone,MUWI243SymZitrone,MUWI243SymOrange,MUWI243SymMelone,MUWI243SymMelone,MUWI243SymGlocke,MUWI243SymSieben,MUWI243SymGlocke,MUWI243SymGlocke,MUWI243SymMelone,MUWI243SymKirsche",
        "MUWI243SymZitrone,MUWI243SymMelone,MUWI243SymTraube,MUWI243SymMelone,MUWI243SymMelone,MUWI243SymZitrone,MUWI243SymSieben,MUWI243SymZitrone,MUWI243SymPflaume,MUWI243SymSieben,MUWI243SymMelone,MUWI243SymKirsche,MUWI243SymGlocke,MUWI243SymMelone,MUWI243SymSieben,MUWI243SymOrange,MUWI243SymTraube,MUWI243SymKirsche,MUWI243SymKirsche,MUWI243SymMelone,MUWI243SymSieben,MUWI243SymTraube,MUWI243SymOrange,MUWI243SymPflaume,MUWI243SymKirsche,MUWI243SymMelone,MUWI243SymZitrone,MUWI243SymMelone,MUWI243SymTraube,MUWI243SymMelone,MUWI243SymTraube,MUWI243SymTraube,MUWI243SymPflaume,MUWI243SymGlocke,MUWI243SymSieben,MUWI243SymGlocke,MUWI243SymGlocke,MUWI243SymPflaume,MUWI243SymZitrone,MUWI243SymGlocke,MUWI243SymMelone,MUWI243SymSieben,MUWI243SymOrange,MUWI243SymKirsche,MUWI243SymMelone,MUWI243SymSieben,MUWI243SymTraube,MUWI243SymOrange,MUWI243SymOrange,MUWI243SymOrange,MUWI243SymPflaume,MUWI243SymTraube,MUWI243SymSieben,MUWI243SymPflaume,MUWI243SymTraube,MUWI243SymPflaume,MUWI243SymGlocke,MUWI243SymTraube,MUWI243SymZitrone,MUWI243SymOrange,MUWI243SymZitrone,MUWI243SymZitrone,MUWI243SymOrange,MUWI243SymMelone,MUWI243SymZitrone,MUWI243SymSieben,MUWI243SymZitrone,MUWI243SymPflaume,MUWI243SymSieben,MUWI243SymMelone,MUWI243SymKirsche,MUWI243SymPflaume,MUWI243SymPflaume,MUWI243SymGlocke,MUWI243SymSieben,MUWI243SymGlocke,MUWI243SymGlocke,MUWI243SymPflaume,MUWI243SymGlocke,MUWI243SymTraube,MUWI243SymZitrone,MUWI243SymOrange,MUWI243SymOrange,MUWI243SymZitrone,MUWI243SymSieben,MUWI243SymPflaume,MUWI243SymKirsche,MUWI243SymPflaume,MUWI243SymPflaume,MUWI243SymKirsche,MUWI243SymSieben,MUWI243SymGlocke,MUWI243SymTraube,MUWI243SymZitrone,MUWI243SymOrange,MUWI243SymPflaume,MUWI243SymTraube,MUWI243SymSieben,MUWI243SymPflaume,MUWI243SymTraube,MUWI243SymZitrone,MUWI243SymPflaume,MUWI243SymKirsche,MUWI243SymSieben,MUWI243SymGlocke,MUWI243SymTraube,MUWI243SymOrange,MUWI243SymZitrone,MUWI243SymSieben,MUWI243SymKirsche,MUWI243SymZitrone,MUWI243SymGlocke,MUWI243SymMelone,MUWI243SymSieben,MUWI243SymOrange,MUWI243SymZitrone,MUWI243SymMelone,MUWI243SymTraube,MUWI243SymMelone,MUWI243SymTraube,MUWI243SymTraube,MUWI243SymMelone,MUWI243SymPflaume,MUWI243SymZitrone,MUWI243SymMelone,MUWI243SymKirsche,MUWI243SymMelone,MUWI243SymSieben,MUWI243SymTraube,MUWI243SymOrange,MUWI243SymOrange,MUWI243SymOrange,MUWI243SymPflaume,MUWI243SymTraube,MUWI243SymSieben,MUWI243SymPflaume,MUWI243SymTraube,MUWI243SymPflaume,MUWI243SymOrange,MUWI243SymZitrone,MUWI243SymZitrone,MUWI243SymOrange,MUWI243SymMelone,MUWI243SymMelone,MUWI243SymZitrone,MUWI243SymSieben,MUWI243SymZitrone,MUWI243SymMelone,MUWI243SymSieben,MUWI243SymMelone,MUWI243SymKirsche,MUWI243SymPflaume,MUWI243SymPflaume,MUWI243SymGlocke,MUWI243SymSieben,MUWI243SymGlocke,MUWI243SymGlocke,MUWI243SymPflaume,MUWI243SymTraube,MUWI243SymOrange,MUWI243SymZitrone,MUWI243SymSieben,MUWI243SymPflaume,MUWI243SymKirsche,MUWI243SymPflaume,MUWI243SymPflaume,MUWI243SymKirsche,MUWI243SymSieben,MUWI243SymGlocke,MUWI243SymTraube,MUWI243SymZitrone,MUWI243SymOrange,MUWI243SymTraube,MUWI243SymZitrone,MUWI243SymTraube,MUWI243SymTraube,MUWI243SymKirsche,MUWI243SymMelone",
    };

    int idx = 0;
    for (int i = 0; i < m_vecReelStripPlan.size(); i++) {
        ReelSet set;
        for (int j = 0; j < m_nReel; j++) {
            ReelStrip strip;
            std::stringstream ss(muwi243ReelStrip[idx]);
            std::string item;
            while (std::getline(ss, item, ',')) {
                strip.push_back(item);
            }
            set.push_back(strip);
            idx++;
        }
        m_vecReelStripSets.push_back(set);
    }

    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_tmp;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        std::map<std::string, std::map<UINT8, BONUS>> perSym;
        std::map<UINT8, BONUS> e;
        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 10; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 25; e[5].ag = 0;
        perSym["MUWI243SymKirsche"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[5].ag = 0;
        perSym["MUWI243SymZitrone"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[5].ag = 0;
        perSym["MUWI243SymOrange"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 25; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[5].ag = 0;
        perSym["MUWI243SymPflaume"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 25; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[5].ag = 0;
        perSym["MUWI243SymTraube"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 200; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 2000; e[5].ag = 0;
        perSym["MUWI243SymGlocke"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 30; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 300; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 3000; e[5].ag = 0;
        perSym["MUWI243SymMelone"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 80; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 800; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 8000; e[5].ag = 0;
        perSym["MUWI243SymSieben"] = e;
        e.clear();

        m_Bonus_tmp[i] = perSym;
    }

    m_Bonus_tmp[0]["MUWI243SymSieben"][5].coin = 0; m_Bonus_tmp[0]["MUWI243SymSieben"][5].ag = 8; // 10
    m_Bonus_tmp[1]["MUWI243SymSieben"][5].coin = 0; m_Bonus_tmp[1]["MUWI243SymSieben"][5].ag = 16; // 20
    m_Bonus_tmp[2]["MUWI243SymSieben"][5].coin = 0; m_Bonus_tmp[2]["MUWI243SymSieben"][5].ag = 24; // 30
    m_Bonus_tmp[3]["MUWI243SymSieben"][5].coin = 0; m_Bonus_tmp[3]["MUWI243SymSieben"][5].ag = 32; // 40
    m_Bonus_tmp[3]["MUWI243SymMelone"][5].coin = 0; m_Bonus_tmp[3]["MUWI243SymMelone"][5].ag = 12;
    m_Bonus_tmp[3]["MUWI243SymGlocke"][5].coin = 0; m_Bonus_tmp[3]["MUWI243SymGlocke"][5].ag = 8;
    m_Bonus_tmp[4]["MUWI243SymSieben"][5].coin = 0; m_Bonus_tmp[4]["MUWI243SymSieben"][5].ag = 40; // 50
    m_Bonus_tmp[4]["MUWI243SymMelone"][5].coin = 0; m_Bonus_tmp[4]["MUWI243SymMelone"][5].ag = 15;
    m_Bonus_tmp[4]["MUWI243SymGlocke"][5].coin = 0; m_Bonus_tmp[4]["MUWI243SymGlocke"][5].ag = 10;
    m_Bonus_tmp[5]["MUWI243SymSieben"][5].coin = 0; m_Bonus_tmp[5]["MUWI243SymSieben"][5].ag = 48; // 60
    m_Bonus_tmp[5]["MUWI243SymMelone"][5].coin = 0; m_Bonus_tmp[5]["MUWI243SymMelone"][5].ag = 18;
    m_Bonus_tmp[5]["MUWI243SymGlocke"][5].coin = 0; m_Bonus_tmp[5]["MUWI243SymGlocke"][5].ag = 12;
    m_Bonus_tmp[6]["MUWI243SymSieben"][5].coin = 0; m_Bonus_tmp[6]["MUWI243SymSieben"][5].ag = 64; // 80
    m_Bonus_tmp[6]["MUWI243SymMelone"][5].coin = 0; m_Bonus_tmp[6]["MUWI243SymMelone"][5].ag = 24;
    m_Bonus_tmp[6]["MUWI243SymGlocke"][5].coin = 0; m_Bonus_tmp[6]["MUWI243SymGlocke"][5].ag = 16;
    m_Bonus_tmp[7]["MUWI243SymSieben"][5].coin = 0; m_Bonus_tmp[7]["MUWI243SymSieben"][5].ag = 80; // 100
    m_Bonus_tmp[7]["MUWI243SymSieben"][4].coin = 0; m_Bonus_tmp[7]["MUWI243SymSieben"][4].ag = 8;
    m_Bonus_tmp[7]["MUWI243SymMelone"][5].coin = 0; m_Bonus_tmp[7]["MUWI243SymMelone"][5].ag = 30;
    m_Bonus_tmp[7]["MUWI243SymGlocke"][5].coin = 0; m_Bonus_tmp[7]["MUWI243SymGlocke"][5].ag = 20;
    m_Bonus_tmp[8]["MUWI243SymSieben"][5].coin = 0; m_Bonus_tmp[8]["MUWI243SymSieben"][5].ag = 100; // 150
    m_Bonus_tmp[8]["MUWI243SymSieben"][4].coin = 0; m_Bonus_tmp[8]["MUWI243SymSieben"][4].ag = 12;
    m_Bonus_tmp[8]["MUWI243SymMelone"][5].coin = 0; m_Bonus_tmp[8]["MUWI243SymMelone"][5].ag = 45;
    m_Bonus_tmp[8]["MUWI243SymGlocke"][5].coin = 0; m_Bonus_tmp[8]["MUWI243SymGlocke"][5].ag = 30;
    m_Bonus_tmp[9]["MUWI243SymSieben"][5].coin = 0; m_Bonus_tmp[9]["MUWI243SymSieben"][5].ag = 100; // 200
    m_Bonus_tmp[9]["MUWI243SymSieben"][4].coin = 0; m_Bonus_tmp[9]["MUWI243SymSieben"][4].ag = 16;
    m_Bonus_tmp[9]["MUWI243SymMelone"][5].coin = 0; m_Bonus_tmp[9]["MUWI243SymMelone"][5].ag = 60;
    m_Bonus_tmp[9]["MUWI243SymGlocke"][5].coin = 0; m_Bonus_tmp[9]["MUWI243SymGlocke"][5].ag = 40;
    m_Bonus_tmp[10]["MUWI243SymSieben"][5].coin = 0; m_Bonus_tmp[10]["MUWI243SymSieben"][5].ag = 100; // 300
    m_Bonus_tmp[10]["MUWI243SymSieben"][4].coin = 0; m_Bonus_tmp[10]["MUWI243SymSieben"][4].ag = 24;
    m_Bonus_tmp[10]["MUWI243SymMelone"][5].coin = 0; m_Bonus_tmp[10]["MUWI243SymMelone"][5].ag = 90;
    m_Bonus_tmp[10]["MUWI243SymGlocke"][5].coin = 0; m_Bonus_tmp[10]["MUWI243SymGlocke"][5].ag = 60;
    m_Bonus_tmp[11]["MUWI243SymSieben"][5].coin = 0; m_Bonus_tmp[11]["MUWI243SymSieben"][5].ag = 100; // 400
    m_Bonus_tmp[11]["MUWI243SymSieben"][4].coin = 0; m_Bonus_tmp[11]["MUWI243SymSieben"][4].ag = 32;
    m_Bonus_tmp[11]["MUWI243SymMelone"][5].coin = 0; m_Bonus_tmp[11]["MUWI243SymMelone"][5].ag = 100;
    m_Bonus_tmp[11]["MUWI243SymGlocke"][5].coin = 0; m_Bonus_tmp[11]["MUWI243SymGlocke"][5].ag = 80;

    int nSavedBetVal = 10;
    int _line = 0;
    string data;
    PlayDB::GetInstance().LoadCheckPoint(m_strGameName, nSavedBetVal, _line, m_strCheckPoint);
    if (nSavedBetVal == -1) {
        nSavedBetVal = 10;
    }

    BOOL start = FALSE;
    idx = 0;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_tmp, i) < AT(m_vecBetSteps, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps, idx) == nSavedBetVal) {
            m_nBetStep = idx;
        }

        m_Bonus[idx++] = m_Bonus_tmp[i];
        if (AT(m_vecBetSteps_tmp, i) == AT(m_vecBetSteps, m_vecBetSteps.size() - 1)) {
            break;
        }
    }

    m_vecBetSteps_05.clear();
    m_vecBetSteps_10.clear();
    PrintAllBonus();

    m_mapLineSounds["MUWI243SymSieben3"] = SMP_MUWI243_WinSound_HV3_X3;
    m_mapLineSounds["MUWI243SymSieben4"] = SMP_MUWI243_WinSound_HV3_X4;
    m_mapLineSounds["MUWI243SymSieben5"] = SMP_MUWI243_WinSound_HV3_X5;
    m_mapLineSounds["MUWI243SymMelone3"] = SMP_MUWI243_WinSound_HV2_X3;
    m_mapLineSounds["MUWI243SymMelone4"] = SMP_MUWI243_WinSound_HV2_X4;
    m_mapLineSounds["MUWI243SymMelone5"] = SMP_MUWI243_WinSound_HV2_X5;
    m_mapLineSounds["MUWI243SymGlocke3"] = SMP_MUWI243_WinSound_HV1_X3;
    m_mapLineSounds["MUWI243SymGlocke4"] = SMP_MUWI243_WinSound_HV1_X4;
    m_mapLineSounds["MUWI243SymGlocke5"] = SMP_MUWI243_WinSound_HV1_X5;
    m_mapLineSounds["MUWI243SymKirsche3"] = SMP_MUWI243_WinSound_LV1_X3;
    m_mapLineSounds["MUWI243SymKirsche4"] = SMP_MUWI243_WinSound_LV1_X4;
    m_mapLineSounds["MUWI243SymKirsche5"] = SMP_MUWI243_WinSound_LV1_X5;
    m_mapLineSounds["MUWI243SymZitrone3"] = SMP_MUWI243_WinSound_LV2_X3;
    m_mapLineSounds["MUWI243SymZitrone4"] = SMP_MUWI243_WinSound_LV2_X4;
    m_mapLineSounds["MUWI243SymZitrone5"] = SMP_MUWI243_WinSound_LV2_X5;
    m_mapLineSounds["MUWI243SymOrange3"] = SMP_MUWI243_WinSound_LV3_X3;
    m_mapLineSounds["MUWI243SymOrange4"] = SMP_MUWI243_WinSound_LV3_X4;
    m_mapLineSounds["MUWI243SymOrange5"] = SMP_MUWI243_WinSound_LV3_X5;
    m_mapLineSounds["MUWI243SymPflaume3"] = SMP_MUWI243_WinSound_LV4_X3;
    m_mapLineSounds["MUWI243SymPflaume4"] = SMP_MUWI243_WinSound_LV4_X4;
    m_mapLineSounds["MUWI243SymPflaume5"] = SMP_MUWI243_WinSound_LV4_X5;
    m_mapLineSounds["MUWI243SymTraube3"] = SMP_MUWI243_WinSound_LV5_X3;
    m_mapLineSounds["MUWI243SymTraube4"] = SMP_MUWI243_WinSound_LV5_X4;
    m_mapLineSounds["MUWI243SymTraube5"] = SMP_MUWI243_WinSound_LV5_X5;
}

void generateCombinations(
    const myVector<myVector<int>>& positionsPerReel,
    int reelIndex,
    myVector<int>& currentCombination,
    myVector<myVector<int>>& allCombinations)
{
    if (reelIndex == positionsPerReel.size()) {
        allCombinations.push_back(currentCombination);
        return;
    }

    for (int pos : AT(positionsPerReel, reelIndex)) {
        currentCombination.push_back(pos);
        generateCombinations(positionsPerReel, reelIndex + 1, currentCombination, allCombinations);
        currentCombination.pop_back();
    }
}

bool symbol_containsin_vec(const myVector<std::string>& vec, const std::string& symbol) {
    return std::find(vec.begin(), vec.end(), symbol) != vec.end();
}

myVector<UINT8> RgMultiWild243::Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) {
    m_nMagicCount = 0;
    myVector<UINT8> result;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);

    if (bTest) {
        std::string matchSymbol = AT(m_vecSymbols, myRandom() % m_vecSymbols.size());
        int line = (myRandom() % m_nWinLine);
        int weight = 1 + (myRandom() % 5);
        // rand
        for (int reel = 0; reel < m_nReel; reel++) {
            result.push_back((myRandom() % (AT(reelSet, reel).size() - 2)) + 1);
        }
    }
    else {
        result = _result;

        BOOL mmcode = mmcode_get_active_status();
        if (mmcode) {
            mmcode_set_deactive();
            for (int j = 0; j < 5; j++) {
                myVector<int> candidateIndices;
                for (int i = 2; i < AT(reelSet, j).size() - 3; ++i) {
                    if (AT(AT(reelSet, j), i) == RgMultiWild243_top) {
                        int offset = myRandom() % 3;
                        int selectedIndex = i - 2 + offset;
                        candidateIndices.push_back(selectedIndex);
                    }
                }
                if (!candidateIndices.empty()) {
                    int chosenIndex = AT(candidateIndices, myRandom() % candidateIndices.size());
                    AT(result, j) = chosenIndex + 1;
                }
            }
        }
    }

    myVector<std::string> expect_symbols;
    std::string symbol1 = AT(AT(reelSet, 0), AT(result, 0) - 1 + 2);
    std::string symbol2 = AT(AT(reelSet, 0), AT(result, 0) - 1 + 1);
    std::string symbol3 = AT(AT(reelSet, 0), AT(result, 0) - 1 + 0);

    if (!symbol_containsin_vec(expect_symbols, symbol1)) {
        expect_symbols.push_back(symbol1);
    }

    if (!symbol_containsin_vec(expect_symbols, symbol2)) {
        expect_symbols.push_back(symbol2);
    }

    if (!symbol_containsin_vec(expect_symbols, symbol3)) {
        expect_symbols.push_back(symbol3);
    }

    struct Multi243WinLine {
        std::string symbol;
        int matchLength;
        int wildCount;
        myVector<std::pair<int, int>> positions; // (reel, row)
    };

    myVector<Multi243WinLine> allWinLines;

    for (int i = 0; i < expect_symbols.size(); i++) {
        std::string targetSymbol = AT(expect_symbols, i);
        myVector<myVector<int>> matchingRowsPerReel;
        myVector<int> wildsPerReel;

        // Find matching rows and wild counts per reel
        for (int reel = 0; reel < 5; ++reel) {
            myVector<int> matchesThisReel;
            int wildCountThisReel = 0;

            for (int row = 0; row < 3; ++row) {
                std::string s = AT(AT(reelSet, reel), AT(result, reel) - 1 + (2 - row)); // reels[reel][row]
                if (s == targetSymbol) {
                    matchesThisReel.push_back(row);
                }
                else if (s == RgMultiWild243_wild) {
                    matchesThisReel.push_back(row);
                    wildCountThisReel++;
                }
            }

            matchingRowsPerReel.push_back(matchesThisReel);
            wildsPerReel.push_back(wildCountThisReel);
        }

        // Find max consecutive reels from left with matches
        int maxMatchLength = 0;
        for (int length = 5; length >= 3; --length) {
            bool consecutive = true;
            for (int r = 0; r < length; ++r) {
                if (AT(matchingRowsPerReel, r).empty()) {
                    consecutive = false;
                    break;
                }
            }
            if (consecutive) {
                maxMatchLength = length;
                break;
            }
        }

        if (maxMatchLength >= 3) {
            // Generate all position combinations for those reels
            myVector<myVector<int>> positionsToCombine(matchingRowsPerReel.begin(), matchingRowsPerReel.begin() + maxMatchLength);

            myVector<myVector<int>> allCombinations;
            myVector<int> currentCombination;
            generateCombinations(positionsToCombine, 0, currentCombination, allCombinations);

            // For each combination, calculate wild count and payout
            for (const auto& combo : allCombinations) {
                int totalWilds = 0;
                myVector<std::pair<int, int>> winPositions;

                for (int reel = 0; reel < maxMatchLength; ++reel) {
                    int row = AT(combo, reel);
                    winPositions.push_back({ reel, row });

                    // reelSet[reel][result[reel] - 1 + (2 - row)] -> reels[reel][row]
                    if (AT(AT(reelSet, reel), AT(result, reel) - 1 + (2 - row)) == RgMultiWild243_wild) totalWilds++;
                }

                Multi243WinLine winLine = { targetSymbol, maxMatchLength, totalWilds, winPositions };
                allWinLines.push_back(winLine);
            }
        }
    }

    normalMeter = 0;
    maxMeter = 0;
    BONUS totalBonus = {0, 0};
    for (int i = 0; i < allWinLines.size(); i++) {
        UINT16 meter = 0;
        for (int j = 0; j < AT(allWinLines, i).positions.size(); j++) {
            UINT8 reel = AT(AT(allWinLines, i).positions, j).first;
            UINT8 row = AT(AT(allWinLines, i).positions, j).second;

            meter |= (1 << (reel * 3 + row));
        }

        std::map<std::string, UINT16> mapMeter2;
        mapMeter2["MUWI243SymSieben5"] = 0x01;
        mapMeter2["MUWI243SymSieben4"] = 0x02;
        mapMeter2["MUWI243SymSieben3"] = 0x03;
        mapMeter2["MUWI243SymMelone5"] = 0x04;
        mapMeter2["MUWI243SymMelone4"] = 0x05;
        mapMeter2["MUWI243SymMelone3"] = 0x06;
        mapMeter2["MUWI243SymGlocke5"] = 0x07;
        mapMeter2["MUWI243SymGlocke4"] = 0x08;
        mapMeter2["MUWI243SymGlocke3"] = 0x09;
        mapMeter2["MUWI243SymTraube5"] = 0x0a;
        mapMeter2["MUWI243SymTraube4"] = 0x0b;
        mapMeter2["MUWI243SymTraube3"] = 0x0c;
        mapMeter2["MUWI243SymPflaume5"] = 0x0d;
        mapMeter2["MUWI243SymPflaume4"] = 0x0e;
        mapMeter2["MUWI243SymPflaume3"] = 0x0f;
        mapMeter2["MUWI243SymOrange5"] = 0x10;
        mapMeter2["MUWI243SymOrange4"] = 0x11;
        mapMeter2["MUWI243SymOrange3"] = 0x12;
        mapMeter2["MUWI243SymZitrone5"] = 0x13;
        mapMeter2["MUWI243SymZitrone4"] = 0x14;
        mapMeter2["MUWI243SymZitrone3"] = 0x15;
        mapMeter2["MUWI243SymKirsche5"] = 0x16;
        mapMeter2["MUWI243SymKirsche4"] = 0x17;
        mapMeter2["MUWI243SymKirsche3"] = 0x18;

        int multiplier = 1;

        if (AT(allWinLines, i).wildCount == 1) {
            multiplier = 1;
        }
        else if (AT(allWinLines, i).wildCount == 2) {
            multiplier = 3;
        }
        else if (AT(allWinLines, i).wildCount == 3) {
            multiplier = 7;
        }

        WinMeter e;
        e.line = 0;
        e.meter = meter;
        e.meter2 = mapMeter2[AT(allWinLines, i).symbol + std::to_string(AT(allWinLines, i).matchLength)];
        e.symbol = AT(allWinLines, i).symbol;
        e.weight = AT(allWinLines, i).matchLength;
        e.start = 0;
        e.bonus = m_Bonus[BetStep()][AT(allWinLines, i).symbol][AT(allWinLines, i).matchLength];
        e.sound = MAX_SOUND_IDS;
        SoundItem temp = getSoundByID(m_mapLineSounds[AT(allWinLines, i).symbol + std::to_string(AT(allWinLines, i).matchLength)]);
        e.swapDelay = temp.duration;

        totalBonus.coin += e.bonus.coin;
        totalBonus.ag += e.bonus.ag;
        meters.push_back(e);

        if (AT(allWinLines, i).wildCount > 0) {
            WinMeter ele;
            ele.line = 0xFF;            
            ele.bonus.coin = m_Bonus[BetStep()][AT(allWinLines, i).symbol][AT(allWinLines, i).matchLength].coin * multiplier;
            ele.bonus.ag = m_Bonus[BetStep()][AT(allWinLines, i).symbol][AT(allWinLines, i).matchLength].ag * multiplier;
            // show multi
            ele.IntWinbonus.push_back({
                0,
                0,
                {0x06, 0x92, 0x35, 0x01, 0x02, 0x31, 0x00, 0x08, 0x00, 0x92, 0x35, 0x9c, 0x11, 0x01, 0x12, static_cast<BYTE>(meter & 0xFF), static_cast<BYTE>((meter >> 8) & 0xFF), static_cast<BYTE>(e.meter2 & 0xFF), static_cast<BYTE>((e.meter2 >> 8) & 0xFF), 0x01, 0x04} });

            UINT16 MultiSoundID = SMP_MUWI243PS_Multiplikator_2;
            if (AT(allWinLines, i).wildCount == 1) {
                MultiSoundID = SMP_MUWI243PS_Multiplikator_2;
            }
            else if (AT(allWinLines, i).wildCount == 2) {
                MultiSoundID = SMP_MUWI243PS_Multiplikator_4;
            }
            else if (AT(allWinLines, i).wildCount == 3) {
                MultiSoundID = SMP_MUWI243PS_Multiplikator_8;
            }
            ele.swapDelay = getSoundByID(MultiSoundID).duration;
            // play multi sound
            ele.IntWinbonus.push_back({
                0,
                0,
                {0x01, 0x02, 0x34, 0x00, static_cast<BYTE>(MultiSoundID & 0xFF), static_cast<BYTE>((MultiSoundID >> 8) & 0xFF), 0x04} });

            // update bonus
            totalBonus.coin += ele.bonus.coin;
            totalBonus.ag += ele.bonus.ag;
            UINT16 _BONUS_BIT_GOC = BONUS_BIT_GOC;
            ele.IntWinbonus.push_back({
                0,
                0,
                {0x01, 0x02, 0x2C, 0x00,
                static_cast<BYTE>(BONUS_BIT_GOC & 0xFF),
                static_cast<BYTE>((BONUS_BIT_GOC >> 8) & 0xFF),
                static_cast<BYTE>(totalBonus.coin & 0xFF),
                static_cast<BYTE>((totalBonus.coin >> 8) & 0xFF),
                0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x01,
                0x04} });

            meters.push_back(ele);
        }

        if (AT(allWinLines, i).matchLength == m_nMaxMatch) {
            maxMeter |= meter;
        }
        else {
            normalMeter |= meter;
        }
    }
    m_vWinMeters = meters;
    m_nMagicCount = totalBonus.ag;
    if (bTest == FALSE) {
        m_vWinResult = result;
        updateCheckPoint();
    }
    if (meters.size() > 0) {
        BonusSound.duration = AT(m_vWinMeters, m_vWinMeters.size() - 1).swapDelay;
        BonusSound.soundID = MAX_SOUND_IDS;
    }    
    return result;
}

int RgMultiWild243::LineSwapDelay(int WinIdx) {
    if (m_vWinMeters.size() <= WinIdx) {
        return 0;
    }
    return AT(m_vWinMeters, WinIdx).swapDelay;
}

BOOL RgMultiWild243::stopAllSoundBeforeMove() {
    return TRUE;
}
UINT16 RgMultiWild243::LineSound(UINT Line, std::string symbol, UINT8 weight) {
    return MAX_SOUND_IDS;
}

UINT16 RgMultiWild243::MagicCount() {
    return m_nMagicCount;
}

myVector<UINT8> RgMultiWild243::ShowTotalWinLines(myVector<WinMeter> SpinMeters) {
    myVector<uint8_t> packet = {
        0x06, 0x30, 0x59, 0x01, 0x02, 0x31, 0x00,
        0x0F, 0x00,  // Placeholder for length 
        0x0F, 0x11, // GameID
        0x9C, 0x19, 0x01
    };
    myVector<UINT8> TotalMatch;
    for (int i = 0; i < SpinMeters.size(); i++) {
        if (AT(SpinMeters, i).line == 0xFF) { // clear after convert action
            continue;
        }
        TotalMatch.push_back(AT(SpinMeters, i).line);
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter >> 8) & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter2 & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter2 >> 8) & 0xFF));
    }
    if (TotalMatch.size() < 10) {
        myVector<UINT8> _;
        return _;
    }
    UINT16 pktLen = 1 + (TotalMatch.size() / 5) * 7;
    AT(packet, 7) = static_cast<BYTE>(pktLen & 0xFF);
    AT(packet, 8) = static_cast<BYTE>((pktLen >> 8) & 0xFF);
    AT(packet, 9) = static_cast<BYTE>(m_nGameID & 0xFF);
    AT(packet, 10) = static_cast<BYTE>((m_nGameID >> 8) & 0xFF);
    int entryCount = static_cast<int>(TotalMatch.size() / 5);
    for (int i = 0; i < entryCount; ++i) {
        packet.push_back(AT(TotalMatch, i * 5 + 0)); // Line
        packet.push_back(AT(TotalMatch, i * 5 + 1)); // Meter low byte
        packet.push_back(AT(TotalMatch, i * 5 + 2)); // Meter high byte
        packet.push_back(AT(TotalMatch, i * 5 + 3)); // Meter2 low byte
        packet.push_back(AT(TotalMatch, i * 5 + 4)); // Meter2 high byte
        packet.push_back(0x01);      // Status or flag 1
        packet.push_back(0x01);      // Status or flag 2
    }
    // Mark the end of the packet
    packet.back() = 0x04;
    return packet;
}
