#pragma once

#include "ReelGame.h"

class RgBookOfFire : public ReelGame
{
public:
	UINT8 m_nFreeModeTotalSpin;
	UINT8 m_nFreeModeGoneSpin;
	BONUS m_nFreeModeTotalBonus;
	BOOL m_bFreeMode;
	std::string m_strSelectedcard;

    myVector<WinMeter> m_vWinMeters;
	std::map<std::string, UINT16> m_vWinLineSounds;

	RgBookOfFire::RgBookOfFire();

    UINT8 CardCount(std::string card);
    BOOL BookInCol(int col);
    UINT8 CardNumInCol(int col, std::string card);

	UINT16 Run() override;
	UINT16 MagicCount() override;
    myVector<UINT8> Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& WinSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) override;
	int LineSwapDelay(int WinIdx) override;
	UINT16 SpinTime_MS() override;
	BOOL CanFreeMode() override;
	myVector<InterruptPacketData> EnterFreeGame(std::string) override;
	myVector<InterruptPacketData> InterruptBeforeSpin() override;
	myVector<InterruptPacketData> InterruptAfterMoveBonus(BOOL& EndFree) override;

	myVector<InterruptPacketData> MousePressed(MousePosition p) override;
	myVector<UINT8> ShowTotalWinLines(myVector<WinMeter> SpinMeters) override;

	BOOL stopAllSoundBeforeMove() override;

	bool RTP_force_bigWin() override;
	BOOL SelectedableReelsInFreeGame(myVector<UINT8> result) override;

	void RgBookOfFire::ChangeReelStrip(UINT16 NewReelPlan) override;
	void updateCheckPoint() override;
};
