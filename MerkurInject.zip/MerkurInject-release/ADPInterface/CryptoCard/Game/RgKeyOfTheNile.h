#pragma once

#include "ReelGame.h"

struct WilCounter {
	UINT8 count;
	BOOL fixed;
};

class RgKeyOfTheNile : public ReelGame
{
public:
	UINT8 m_nFreeModeTotalSpin;
	UINT8 m_nFreeModeGoneSpin;
	BONUS m_nFreeModeTotalBonus;
	BOOL m_bFreeMode;

	myVector<UINT16> m_vecBetSteps_tmp;

	myVector<WilCounter> m_vWildCounter;
	myVector<WilCounter> m_vCpOfWildCounter;
	myVector<myVector<WilCounter>> m_vWildCounterAll;

	UINT8 m_nWildReel;
	UINT8 m_nWildRow;

	int m_nForceWildInFreeModeGone;

	RgKeyOfTheNile::RgKeyOfTheNile();

	UINT8 CardCount(std::string card);
	BOOL ScatterInCol(int col);
	UINT8 CardNumInCol(int col, std::string card);
	void SetWildPosAndMask();
	UINT16 GetWildMask();
	BOOL IsWild(int reel, int row);

	UINT16 Run() override;
	myVector<UINT8> Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& WinSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) override;
	int LineSwapDelay(int WinIdx) override;
	UINT16 MagicCount() override;
	UINT16 SpinTime_MS() override;
	myVector<InterruptPacketData> InterruptAfterSpin() override;
	myVector<InterruptPacketData> InterruptBeforeSpin() override;
	myVector<InterruptPacketData> InterruptAfterMoveBonus(BOOL& EndFree) override;
	myVector<UINT8> AdditionalParam() override;
	BOOL CanFreeMode() override;
	myVector<InterruptPacketData> EnterFreeGame(std::string) override;
	myVector<InterruptPacketData> OnBetUp(int OrgBetStep, int NewBetStep) override;

	bool RTP_force_bigWin() override;
	BOOL SelectedableReelsInFreeGame(myVector<UINT8> result) override;

	void ChangeReelStrip(UINT16 NewReelPlan) override;
	void updateCheckPoint() override;

};
