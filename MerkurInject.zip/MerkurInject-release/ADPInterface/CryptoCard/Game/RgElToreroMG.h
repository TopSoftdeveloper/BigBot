#pragma once

#include "ReelGame.h"


class RgElToreroMG : public ReelGame
{
public:

	myVector<WinMeter> m_vWinMeters;
	std::map<std::string, UINT16> m_vWinLineSounds;

	myVector<Position> m_vWildCardsPositions;

	UINT8 m_nFreeModeTotalSpin;
	UINT8 m_nFreeModeGoneSpin;
	BONUS m_nFreeModeTotalBonus;

	BOOL m_bFreeMode;
public:
	RgElToreroMG::RgElToreroMG();

	UINT8 NumberOfScatter();
	BOOL NumberInCol(int col);
	void ChangeReelStrip(UINT16 NewReelPlan) override;
	UINT8 CardCount(std::string card);
	BOOL IsWild(UINT8 reel, UINT8 row, std::string card);

	UINT16 Run() override;
	UINT16 MagicCount() override;
	myVector<UINT8> Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& WinSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) override;
	int LineSwapDelay(int WinIdx) override;
	BOOL stopAllSoundBeforeMove() override;
	BOOL CanFreeMode() override;
	UINT16 SpinTime_MS() override;
	myVector<InterruptPacketData> EnterFreeGame(std::string) override;
	myVector<InterruptPacketData> InterruptBeforeSpin() override;
	myVector<InterruptPacketData> InterruptAfterMoveBonus(BOOL& EndFree) override;
	myVector<InterruptPacketData> InterruptAfterSpin() override;

	myVector<UINT8> ShowTotalWinLines(myVector<WinMeter> SpinMeters) override;
	BOOL SelectedableReelsInFreeGame(myVector<UINT8> result) override;
	void updateCheckPoint() override;
};
