#include "stdafx.h"
#include "RgEyeOfHorus.h"

#define RgEyeOfHorus_MP_ChangeLine_LB_x_reel   0x03
#define RgEyeOfHorus_MP_ChangeLine_LB_x_pos    0x28
#define RgEyeOfHorus_MP_ChangeLine_LB_y_row    0x02
#define RgEyeOfHorus_MP_ChangeLine_LB_y_pos    0x16
#define RgEyeOfHorus_MP_ChangeLine_RT_x_reel   0x03
#define RgEyeOfHorus_MP_ChangeLine_RT_x_pos    0x61
#define RgEyeOfHorus_MP_ChangeLine_RT_y_row    0x02
#define RgEyeOfHorus_MP_ChangeLine_RT_y_pos    0x50

#define RgEyeOfHorus_wild       "eohHORUS__"
#define RgEyeOfHorus_scatter    "eohPYRAMID"

myVector<std::string> EOH_convert_sorting = { "eohFLOWER_", "eohKEY____", "eohSCARAB_", "eohBIRD___", "eohDOG____"};

RgEyeOfHorus::RgEyeOfHorus() {
    m_nReel = 5;
    m_nWinLine = 5;
    m_nMaxMatch = 5;
    m_nBetStep = 0;

    m_strGameName = "RgEyeOfHorus";

    m_bFreeMode = FALSE;

    myVector<UINT16> m_vecBetSteps_05_tmp;
    myVector<UINT16> m_vecBetSteps_10_tmp;
    m_vecBetSteps_05_tmp.push_back(5);
    m_vecBetSteps_05_tmp.push_back(10);
    m_vecBetSteps_05_tmp.push_back(20);
    m_vecBetSteps_05_tmp.push_back(30);
    m_vecBetSteps_05_tmp.push_back(40);
    m_vecBetSteps_05_tmp.push_back(50);
    m_vecBetSteps_05_tmp.push_back(75);
    m_vecBetSteps_05_tmp.push_back(100);
    m_vecBetSteps_05_tmp.push_back(200);

    m_vecBetSteps_10_tmp.push_back(10);
    m_vecBetSteps_10_tmp.push_back(20);
    m_vecBetSteps_10_tmp.push_back(40);
    m_vecBetSteps_10_tmp.push_back(60);
    m_vecBetSteps_10_tmp.push_back(80);
    m_vecBetSteps_10_tmp.push_back(100);
    m_vecBetSteps_10_tmp.push_back(150);
    m_vecBetSteps_10_tmp.push_back(200);
    m_vecBetSteps_10_tmp.push_back(400);
#ifdef BIGBET_ACTIVE
    m_vecBetSteps_05_tmp.push_back(500);
    m_vecBetSteps_05_tmp.push_back(1000);
    m_vecBetSteps_10_tmp.push_back(1000);
    m_vecBetSteps_10_tmp.push_back(2000);
#endif
    LoadBets();

    m_vecBetSteps = m_vecBetSteps_05;

    m_vecSymbols.push_back("eohPYRAMID");
    m_vecSymbols.push_back("eohHORUS__");
    m_vecSymbols.push_back("eohEYE____");
    m_vecSymbols.push_back("eohDOG____");
    m_vecSymbols.push_back("eohBIRD___");
    m_vecSymbols.push_back("eohSCARAB_");
    m_vecSymbols.push_back("eohKEY____");
    m_vecSymbols.push_back("eohFLOWER_");
    m_vecSymbols.push_back("eohA______");
    m_vecSymbols.push_back("eohK______");
    m_vecSymbols.push_back("eohQ______");
    m_vecSymbols.push_back("eohJ______");

    m_mapSymbolMinMatch["eohPYRAMID"] = 3;
    m_mapSymbolMinMatch["eohEYE____"] = 3;
    m_mapSymbolMinMatch["eohDOG____"] = 3;
    m_mapSymbolMinMatch["eohBIRD___"] = 3;
    m_mapSymbolMinMatch["eohSCARAB_"] = 3;
    m_mapSymbolMinMatch["eohKEY____"] = 3;
    m_mapSymbolMinMatch["eohFLOWER_"] = 3;
    m_mapSymbolMinMatch["eohA______"] = 3;
    m_mapSymbolMinMatch["eohK______"] = 3;
    m_mapSymbolMinMatch["eohQ______"] = 3;
    m_mapSymbolMinMatch["eohJ______"] = 3;

    m_mapSymbolMeterGoc["eohPYRAMID"] = "eohPyramid$x";
    m_mapSymbolMeterGoc["eohEYE____"] = "eohEye$x";
    m_mapSymbolMeterGoc["eohDOG____"] = "eohDog$x";
    m_mapSymbolMeterGoc["eohBIRD___"] = "eohBird$x";
    m_mapSymbolMeterGoc["eohSCARAB_"] = "eohScarab$x";
    m_mapSymbolMeterGoc["eohKEY____"] = "eohKey$x";
    m_mapSymbolMeterGoc["eohFLOWER_"] = "eohFlower$x";
    m_mapSymbolMeterGoc["eohA______"] = "eohAKQJ$x";
    m_mapSymbolMeterGoc["eohK______"] = "eohAKQJ$x";
    m_mapSymbolMeterGoc["eohQ______"] = "eohAKQJ$x";
    m_mapSymbolMeterGoc["eohJ______"] = "eohAKQJ$x";

    m_vecWinLines.push_back("eohWinline1");
    m_vecWinLines.push_back("eohWinline2");
    m_vecWinLines.push_back("eohWinline3");
    m_vecWinLines.push_back("eohWinline4");
    m_vecWinLines.push_back("eohWinline5");
    m_vecWinLines.push_back("eohWinline6");
    m_vecWinLines.push_back("eohWinline7");
    m_vecWinLines.push_back("eohWinline8");
    m_vecWinLines.push_back("eohWinline9");
    m_vecWinLines.push_back("eohWinline10");

    m_vecLineSounds.push_back(SMP_GRa_WinStep1);
    m_vecLineSounds.push_back(SMP_GRa_WinStep2);
    m_vecLineSounds.push_back(SMP_GRa_WinStep3);
    m_vecLineSounds.push_back(SMP_GRa_WinStep4);
    m_vecLineSounds.push_back(SMP_GRa_WinStep5);
    m_vecLineSounds.push_back(SMP_GRa_WinStep6);
    m_vecLineSounds.push_back(SMP_GRa_WinStep7);
    m_vecLineSounds.push_back(SMP_GRa_WinStep8);
    m_vecLineSounds.push_back(SMP_GRa_WinStep9);
    m_vecLineSounds.push_back(SMP_GRa_WinStep10);

    m_vecWinSounds.push_back(SMP_GRa_WinTiny);
    m_vecWinSounds.push_back(SMP_GRa_WinMini);
    m_vecWinSounds.push_back(SMP_GRa_WinMinor);
    m_vecWinSounds.push_back(SMP_GRa_WinVSmall);
    m_vecWinSounds.push_back(SMP_GRa_WinSmall);
    m_vecWinSounds.push_back(SMP_GRa_WinMedium);
    m_vecWinSounds.push_back(SMP_GRa_WinBig);
    m_vecWinSounds.push_back(SMP_GRa_WinXLarge);
    m_vecWinSounds.push_back(SMP_GRa_WinHuge);
    m_vecWinSounds.push_back(SMP_GRa_WinTop);

    m_vecReelStripPlan.push_back("0");
    m_vecReelStripPlan.push_back("1");
    m_vecReelStripPlan.push_back("2");
    m_vecReelStripPlan.push_back("3");
    m_vecReelStripPlan.push_back("4");
    m_vecReelStripPlan.push_back("5");
    m_vecReelStripPlan.push_back("6");
    m_vecReelStripPlan.push_back("7");
    m_vecReelStripPlan.push_back("8");
    m_vecReelStripPlan.push_back("9");
    m_vecReelStripPlan.push_back("10");
    m_vecReelStripPlan.push_back("11");
    m_vecReelStripPlan.push_back("12");
    m_vecReelStripPlan.push_back("13");

    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));

    char* eohReelStrip[] = {
        "eohK______,eohK______,eohEYE____,eohK______,eohK______,eohK______,eohFLOWER_,eohFLOWER_,eohFLOWER_,eohA______,eohA______,eohPYRAMID,eohA______,eohA______,eohKEY____,eohKEY____,eohKEY____,eohJ______,eohJ______,eohJ______,eohEYE____,eohJ______,eohJ______,eohJ______,eohSCARAB_,eohSCARAB_,eohQ______,eohQ______,eohSCARAB_,eohSCARAB_,eohK______,eohK______,eohPYRAMID,eohK______,eohK______,eohK______,eohBIRD___,eohBIRD___,eohQ______,eohQ______,eohDOG____,eohDOG____,eohA______,eohA______,eohA______,eohKEY____,eohKEY____,eohQ______,eohQ______,eohFLOWER_,eohFLOWER_,eohJ______,eohJ______,eohJ______,eohBIRD___,eohBIRD___,eohQ______,eohQ______,eohDOG____,eohDOG____",
        "eohA______,eohA______,eohA______,eohFLOWER_,eohFLOWER_,eohK______,eohK______,eohK______,eohDOG____,eohDOG____,eohJ______,eohJ______,eohJ______,eohEYE____,eohJ______,eohJ______,eohKEY____,eohKEY____,eohQ______,eohQ______,eohQ______,eohPYRAMID,eohQ______,eohQ______,eohFLOWER_,eohFLOWER_,eohK______,eohK______,eohPYRAMID,eohK______,eohK______,eohK______,eohBIRD___,eohBIRD___,eohBIRD___,eohA______,eohA______,eohSCARAB_,eohSCARAB_,eohQ______,eohQ______,eohQ______,eohFLOWER_,eohFLOWER_,eohA______,eohA______,eohA______,eohKEY____,eohKEY____,eohKEY____,eohJ______,eohJ______,eohJ______,eohSCARAB_,eohSCARAB_",
        "eohA______,eohA______,eohA______,eohKEY____,eohKEY____,eohK______,eohK______,eohK______,eohDOG____,eohDOG____,eohJ______,eohJ______,eohJ______,eohEYE____,eohJ______,eohJ______,eohKEY____,eohKEY____,eohQ______,eohQ______,eohQ______,eohPYRAMID,eohQ______,eohQ______,eohKEY____,eohKEY____,eohK______,eohK______,eohPYRAMID,eohK______,eohK______,eohK______,eohBIRD___,eohBIRD___,eohBIRD___,eohA______,eohA______,eohSCARAB_,eohSCARAB_,eohQ______,eohQ______,eohQ______,eohKEY____,eohKEY____,eohA______,eohA______,eohA______,eohKEY____,eohKEY____,eohKEY____,eohJ______,eohJ______,eohJ______,eohSCARAB_,eohSCARAB_",
        "eohA______,eohA______,eohA______,eohSCARAB_,eohSCARAB_,eohK______,eohK______,eohK______,eohK______,eohDOG____,eohDOG____,eohJ______,eohJ______,eohJ______,eohEYE____,eohJ______,eohJ______,eohSCARAB_,eohSCARAB_,eohQ______,eohQ______,eohQ______,eohPYRAMID,eohQ______,eohQ______,eohSCARAB_,eohSCARAB_,eohK______,eohK______,eohK______,eohK______,eohBIRD___,eohBIRD___,eohBIRD___,eohA______,eohA______,eohSCARAB_,eohSCARAB_,eohQ______,eohQ______,eohQ______,eohSCARAB_,eohSCARAB_,eohA______,eohA______,eohA______,eohSCARAB_,eohSCARAB_,eohSCARAB_,eohJ______,eohJ______,eohJ______,eohSCARAB_,eohSCARAB_",
        "eohA______,eohA______,eohDOG____,eohA______,eohA______,eohBIRD___,eohK______,eohK______,eohBIRD___,eohK______,eohK______,eohBIRD___,eohJ______,eohJ______,eohBIRD___,eohJ______,eohJ______,eohBIRD___,eohBIRD___,eohQ______,eohQ______,eohPYRAMID,eohQ______,eohQ______,eohBIRD___,eohBIRD___,eohK______,eohK______,eohEYE____,eohK______,eohK______,eohBIRD___,eohQ______,eohQ______,eohDOG____,eohA______,eohA______,eohBIRD___,eohBIRD___,eohQ______,eohQ______,eohBIRD___,eohBIRD___,eohA______,eohA______,eohBIRD___,eohBIRD___,eohJ______,eohJ______,eohBIRD___,eohJ______,eohJ______,eohBIRD___,eohBIRD___",
        "eohA______,eohA______,eohDOG____,eohA______,eohA______,eohDOG____,eohK______,eohK______,eohDOG____,eohK______,eohK______,eohDOG____,eohJ______,eohJ______,eohDOG____,eohJ______,eohJ______,eohDOG____,eohDOG____,eohQ______,eohQ______,eohPYRAMID,eohQ______,eohQ______,eohDOG____,eohDOG____,eohK______,eohK______,eohEYE____,eohK______,eohK______,eohDOG____,eohQ______,eohQ______,eohDOG____,eohA______,eohA______,eohDOG____,eohDOG____,eohQ______,eohQ______,eohDOG____,eohDOG____,eohA______,eohA______,eohDOG____,eohDOG____,eohJ______,eohJ______,eohDOG____,eohJ______,eohJ______,eohDOG____,eohDOG____",
        "eohA______,eohA______,eohEYE____,eohA______,eohA______,eohEYE____,eohK______,eohK______,eohEYE____,eohK______,eohK______,eohEYE____,eohJ______,eohJ______,eohEYE____,eohJ______,eohJ______,eohEYE____,eohEYE____,eohQ______,eohQ______,eohPYRAMID,eohQ______,eohQ______,eohEYE____,eohEYE____,eohK______,eohK______,eohEYE____,eohK______,eohK______,eohEYE____,eohQ______,eohQ______,eohEYE____,eohA______,eohA______,eohEYE____,eohEYE____,eohQ______,eohQ______,eohEYE____,eohEYE____,eohA______,eohA______,eohEYE____,eohEYE____,eohJ______,eohJ______,eohEYE____,eohJ______,eohJ______,eohEYE____,eohEYE____",
        "eohK______,eohK______,eohEYE____,eohK______,eohK______,eohK______,eohFLOWER_,eohFLOWER_,eohA______,eohA______,eohA______,eohPYRAMID,eohA______,eohA______,eohKEY____,eohKEY____,eohJ______,eohJ______,eohSCARAB_,eohSCARAB_,eohSCARAB_,eohQ______,eohKEY____,eohKEY____,eohQ______,eohQ______,eohFLOWER_,eohFLOWER_,eohJ______,eohJ______,eohPYRAMID,eohJ______,eohBIRD___,eohBIRD___,eohQ______,eohQ______,eohDOG____,eohDOG____",
        "eohK______,eohK______,eohEYE____,eohK______,eohK______,eohK______,eohFLOWER_,eohFLOWER_,eohA______,eohA______,eohA______,eohPYRAMID,eohA______,eohA______,eohKEY____,eohKEY____,eohJ______,eohJ______,eohSCARAB_,eohSCARAB_,eohSCARAB_,eohQ______,eohKEY____,eohKEY____,eohQ______,eohQ______,eohFLOWER_,eohFLOWER_,eohJ______,eohJ______,eohJ______,eohBIRD___,eohBIRD___,eohQ______,eohQ______,eohDOG____,eohDOG____",
        "eohK______,eohK______,eohEYE____,eohK______,eohK______,eohK______,eohKEY____,eohKEY____,eohA______,eohA______,eohA______,eohPYRAMID,eohA______,eohA______,eohKEY____,eohKEY____,eohJ______,eohJ______,eohSCARAB_,eohSCARAB_,eohSCARAB_,eohQ______,eohKEY____,eohKEY____,eohQ______,eohQ______,eohKEY____,eohKEY____,eohJ______,eohJ______,eohJ______,eohBIRD___,eohBIRD___,eohQ______,eohQ______,eohDOG____,eohDOG____",
        "eohK______,eohK______,eohEYE____,eohK______,eohK______,eohK______,eohSCARAB_,eohSCARAB_,eohA______,eohA______,eohA______,eohPYRAMID,eohA______,eohA______,eohSCARAB_,eohSCARAB_,eohJ______,eohJ______,eohSCARAB_,eohSCARAB_,eohSCARAB_,eohQ______,eohSCARAB_,eohSCARAB_,eohQ______,eohQ______,eohSCARAB_,eohSCARAB_,eohJ______,eohJ______,eohJ______,eohBIRD___,eohBIRD___,eohQ______,eohQ______,eohDOG____,eohDOG____",
        "eohK______,eohK______,eohEYE____,eohK______,eohK______,eohK______,eohBIRD___,eohBIRD___,eohA______,eohA______,eohA______,eohPYRAMID,eohA______,eohA______,eohBIRD___,eohBIRD___,eohJ______,eohJ______,eohBIRD___,eohBIRD___,eohBIRD___,eohQ______,eohBIRD___,eohBIRD___,eohQ______,eohQ______,eohBIRD___,eohBIRD___,eohJ______,eohJ______,eohJ______,eohBIRD___,eohBIRD___,eohQ______,eohQ______,eohDOG____,eohDOG____",
        "eohK______,eohK______,eohEYE____,eohK______,eohK______,eohK______,eohDOG____,eohDOG____,eohA______,eohA______,eohA______,eohPYRAMID,eohA______,eohA______,eohDOG____,eohDOG____,eohJ______,eohJ______,eohDOG____,eohDOG____,eohDOG____,eohQ______,eohDOG____,eohDOG____,eohQ______,eohQ______,eohDOG____,eohDOG____,eohJ______,eohJ______,eohJ______,eohDOG____,eohDOG____,eohQ______,eohQ______,eohDOG____,eohDOG____",
        "eohK______,eohK______,eohEYE____,eohK______,eohK______,eohK______,eohEYE____,eohEYE____,eohA______,eohA______,eohA______,eohPYRAMID,eohA______,eohA______,eohEYE____,eohEYE____,eohJ______,eohJ______,eohEYE____,eohEYE____,eohEYE____,eohQ______,eohEYE____,eohEYE____,eohQ______,eohQ______,eohEYE____,eohEYE____,eohJ______,eohJ______,eohJ______,eohEYE____,eohEYE____,eohQ______,eohQ______,eohEYE____,eohEYE____",

        "eohA______,eohA______,eohA______,eohKEY____,eohKEY____,eohQ______,eohQ______,eohPYRAMID,eohQ______,eohQ______,eohBIRD___,eohBIRD___,eohK______,eohK______,eohPYRAMID,eohK______,eohK______,eohKEY____,eohKEY____,eohJ______,eohJ______,eohDOG____,eohDOG____,eohQ______,eohQ______,eohEYE____,eohQ______,eohQ______,eohKEY____,eohKEY____,eohK______,eohK______,eohSCARAB_,eohSCARAB_,eohA______,eohA______,eohEYE____,eohA______,eohA______,eohA______,eohFLOWER_,eohFLOWER_,eohFLOWER_,eohJ______,eohJ______,eohPYRAMID,eohJ______,eohJ______,eohHORUS__,eohK______,eohK______,eohFLOWER_,eohFLOWER_,eohA______,eohA______,eohSCARAB_,eohSCARAB_,eohJ______,eohJ______,eohBIRD___,eohBIRD___",
        "eohA______,eohA______,eohHORUS__,eohK______,eohK______,eohK______,eohPYRAMID,eohK______,eohK______,eohFLOWER_,eohFLOWER_,eohFLOWER_,eohQ______,eohQ______,eohHORUS__,eohJ______,eohJ______,eohJ______,eohPYRAMID,eohJ______,eohJ______,eohKEY____,eohKEY____,eohKEY____,eohA______,eohA______,eohSCARAB_,eohSCARAB_,eohA______,eohA______,eohDOG____,eohDOG____,eohK______,eohK______,eohK______,eohHORUS__,eohJ______,eohJ______,eohJ______,eohFLOWER_,eohFLOWER_,eohFLOWER_,eohA______,eohA______,eohKEY____,eohKEY____,eohQ______,eohQ______,eohEYE____,eohQ______,eohQ______,eohSCARAB_,eohSCARAB_,eohQ______,eohQ______,eohBIRD___,eohBIRD___,eohBIRD___",
        "eohA______,eohA______,eohHORUS__,eohK______,eohK______,eohK______,eohPYRAMID,eohK______,eohK______,eohKEY____,eohKEY____,eohQ______,eohQ______,eohQ______,eohHORUS__,eohJ______,eohJ______,eohJ______,eohKEY____,eohKEY____,eohA______,eohA______,eohSCARAB_,eohSCARAB_,eohA______,eohA______,eohDOG____,eohDOG____,eohK______,eohK______,eohK______,eohKEY____,eohKEY____,eohJ______,eohJ______,eohJ______,eohKEY____,eohKEY____,eohKEY____,eohA______,eohA______,eohKEY____,eohKEY____,eohQ______,eohQ______,eohQ______,eohEYE____,eohQ______,eohQ______,eohSCARAB_,eohSCARAB_,eohJ______,eohJ______,eohBIRD___,eohBIRD___,eohBIRD___",
        "eohA______,eohA______,eohA______,eohHORUS__,eohK______,eohK______,eohK______,eohPYRAMID,eohK______,eohK______,eohK______,eohSCARAB_,eohSCARAB_,eohQ______,eohQ______,eohQ______,eohSCARAB_,eohSCARAB_,eohJ______,eohJ______,eohJ______,eohSCARAB_,eohSCARAB_,eohA______,eohA______,eohA______,eohDOG____,eohDOG____,eohK______,eohK______,eohK______,eohSCARAB_,eohSCARAB_,eohJ______,eohJ______,eohJ______,eohSCARAB_,eohSCARAB_,eohSCARAB_,eohA______,eohA______,eohSCARAB_,eohSCARAB_,eohQ______,eohQ______,eohQ______,eohEYE____,eohQ______,eohQ______,eohSCARAB_,eohSCARAB_,eohJ______,eohJ______,eohBIRD___,eohBIRD___,eohK______,eohK______,eohK______,eohK______,eohSCARAB_,eohSCARAB_,eohQ______,eohQ______,eohQ______,eohSCARAB_,eohSCARAB_,eohA______,eohA______,eohA______,eohSCARAB_,eohSCARAB_,eohJ______,eohJ______,eohJ______,eohBIRD___,eohBIRD___,eohA______,eohA______,eohDOG____,eohDOG____,eohK______,eohK______,eohK______,eohSCARAB_,eohSCARAB_,eohJ______,eohJ______,eohJ______,eohSCARAB_,eohSCARAB_,eohSCARAB_,eohA______,eohA______,eohA______,eohSCARAB_,eohSCARAB_,eohQ______,eohQ______,eohQ______,eohEYE____,eohQ______,eohQ______,eohSCARAB_,eohSCARAB_,eohJ______,eohJ______,eohBIRD___,eohBIRD___",
        "eohA______,eohA______,eohHORUS__,eohK______,eohK______,eohPYRAMID,eohK______,eohK______,eohBIRD___,eohQ______,eohQ______,eohEYE____,eohQ______,eohQ______,eohBIRD___,eohK______,eohK______,eohDOG____,eohDOG____,eohJ______,eohJ______,eohBIRD___,eohA______,eohA______,eohBIRD___,eohA______,eohA______,eohBIRD___,eohBIRD___,eohK______,eohK______,eohBIRD___,eohBIRD___,eohJ______,eohJ______,eohEYE____,eohJ______,eohJ______,eohBIRD___,eohBIRD___,eohA______,eohA______,eohBIRD___,eohBIRD___,eohQ______,eohQ______,eohBIRD___,eohQ______,eohQ______,eohBIRD___,eohBIRD___,eohJ______,eohJ______,eohBIRD___,eohBIRD___,eohK______,eohK______,eohBIRD___,eohK______,eohK______,eohBIRD___,eohBIRD___,eohQ______,eohQ______,eohDOG____,eohA______,eohA______,eohBIRD___,eohBIRD___,eohJ______,eohJ______,eohBIRD___,eohA______,eohA______,eohBIRD___,eohBIRD___,eohK______,eohK______,eohDOG____,eohK______,eohK______,eohBIRD___,eohJ______,eohJ______,eohBIRD___,eohJ______,eohJ______,eohBIRD___,eohBIRD___,eohA______,eohA______,eohBIRD___,eohA______,eohA______,eohBIRD___,eohQ______,eohQ______,eohBIRD___,eohQ______,eohQ______,eohBIRD___,eohQ______,eohQ______,eohBIRD___,eohBIRD___,eohJ______,eohJ______,eohBIRD___",
        "eohA______,eohA______,eohHORUS__,eohK______,eohK______,eohPYRAMID,eohK______,eohK______,eohDOG____,eohQ______,eohQ______,eohEYE____,eohQ______,eohQ______,eohDOG____,eohK______,eohK______,eohDOG____,eohDOG____,eohJ______,eohJ______,eohDOG____,eohA______,eohA______,eohDOG____,eohA______,eohA______,eohDOG____,eohDOG____,eohK______,eohK______,eohDOG____,eohDOG____,eohJ______,eohJ______,eohEYE____,eohJ______,eohJ______,eohDOG____,eohDOG____,eohA______,eohA______,eohDOG____,eohDOG____,eohQ______,eohQ______,eohDOG____,eohQ______,eohQ______,eohDOG____,eohDOG____,eohJ______,eohJ______,eohDOG____,eohDOG____,eohK______,eohK______,eohDOG____,eohK______,eohK______,eohDOG____,eohDOG____,eohQ______,eohQ______,eohDOG____,eohA______,eohA______,eohDOG____,eohDOG____,eohJ______,eohJ______,eohDOG____,eohA______,eohA______,eohDOG____,eohDOG____,eohK______,eohK______,eohDOG____,eohK______,eohK______,eohDOG____,eohJ______,eohJ______,eohDOG____,eohJ______,eohJ______,eohDOG____,eohDOG____,eohA______,eohA______,eohDOG____,eohA______,eohA______,eohDOG____,eohQ______,eohQ______,eohDOG____,eohQ______,eohQ______,eohDOG____,eohQ______,eohQ______,eohDOG____,eohDOG____,eohJ______,eohJ______,eohDOG____",
        "eohA______,eohA______,eohHORUS__,eohK______,eohK______,eohPYRAMID,eohK______,eohK______,eohEYE____,eohQ______,eohQ______,eohEYE____,eohQ______,eohQ______,eohEYE____,eohK______,eohK______,eohEYE____,eohEYE____,eohJ______,eohJ______,eohEYE____,eohA______,eohA______,eohEYE____,eohA______,eohA______,eohEYE____,eohEYE____,eohK______,eohK______,eohEYE____,eohEYE____,eohJ______,eohJ______,eohEYE____,eohJ______,eohJ______,eohEYE____,eohEYE____,eohA______,eohA______,eohEYE____,eohEYE____,eohQ______,eohQ______,eohEYE____,eohQ______,eohQ______,eohEYE____,eohEYE____,eohJ______,eohJ______,eohEYE____,eohEYE____,eohK______,eohK______,eohEYE____,eohK______,eohK______,eohEYE____,eohEYE____,eohQ______,eohQ______,eohEYE____,eohA______,eohA______,eohEYE____,eohEYE____,eohJ______,eohJ______,eohEYE____,eohA______,eohA______,eohEYE____,eohEYE____,eohK______,eohK______,eohEYE____,eohK______,eohK______,eohEYE____,eohJ______,eohJ______,eohEYE____,eohJ______,eohJ______,eohEYE____,eohEYE____,eohA______,eohA______,eohEYE____,eohA______,eohA______,eohEYE____,eohQ______,eohQ______,eohEYE____,eohQ______,eohQ______,eohEYE____,eohQ______,eohQ______,eohEYE____,eohEYE____,eohJ______,eohJ______,eohEYE____",
        "eohA______,eohEYE____,eohA______,eohA______,eohKEY____,eohKEY____,eohQ______,eohQ______,eohPYRAMID,eohQ______,eohQ______,eohQ______,eohBIRD___,eohBIRD___,eohK______,eohK______,eohK______,eohDOG____,eohDOG____,eohJ______,eohSCARAB_,eohSCARAB_,eohJ______,eohJ______,eohHORUS__,eohK______,eohK______,eohFLOWER_,eohFLOWER_,eohA______,eohA______,eohSCARAB_,eohSCARAB_,eohJ______,eohJ______,eohKEY____,eohKEY____",
        "eohQ______,eohHORUS__,eohA______,eohA______,eohEYE____,eohA______,eohA______,eohKEY____,eohKEY____,eohQ______,eohQ______,eohPYRAMID,eohQ______,eohQ______,eohBIRD___,eohBIRD___,eohK______,eohK______,eohHORUS__,eohJ______,eohJ______,eohDOG____,eohDOG____,eohJ______,eohSCARAB_,eohSCARAB_,eohJ______,eohJ______,eohHORUS__,eohK______,eohK______,eohFLOWER_,eohFLOWER_,eohA______,eohA______,eohSCARAB_,eohSCARAB_,eohJ______,eohJ______,eohKEY____,eohKEY____,eohQ______",
        "eohQ______,eohHORUS__,eohA______,eohA______,eohEYE____,eohA______,eohA______,eohKEY____,eohKEY____,eohQ______,eohQ______,eohPYRAMID,eohQ______,eohQ______,eohBIRD___,eohBIRD___,eohK______,eohK______,eohHORUS__,eohJ______,eohJ______,eohDOG____,eohDOG____,eohJ______,eohSCARAB_,eohSCARAB_,eohJ______,eohJ______,eohHORUS__,eohK______,eohK______,eohKEY____,eohKEY____,eohA______,eohA______,eohSCARAB_,eohSCARAB_,eohJ______,eohJ______,eohKEY____,eohKEY____,eohQ______",
        "eohQ______,eohHORUS__,eohA______,eohA______,eohEYE____,eohA______,eohA______,eohSCARAB_,eohSCARAB_,eohQ______,eohQ______,eohPYRAMID,eohQ______,eohQ______,eohBIRD___,eohBIRD___,eohK______,eohK______,eohHORUS__,eohJ______,eohJ______,eohDOG____,eohDOG____,eohJ______,eohSCARAB_,eohSCARAB_,eohJ______,eohJ______,eohHORUS__,eohK______,eohK______,eohSCARAB_,eohSCARAB_,eohA______,eohA______,eohSCARAB_,eohSCARAB_,eohJ______,eohJ______,eohSCARAB_,eohSCARAB_,eohQ______",
        "eohQ______,eohHORUS__,eohA______,eohA______,eohEYE____,eohA______,eohA______,eohBIRD___,eohBIRD___,eohQ______,eohQ______,eohPYRAMID,eohQ______,eohQ______,eohBIRD___,eohBIRD___,eohK______,eohK______,eohHORUS__,eohJ______,eohJ______,eohDOG____,eohDOG____,eohJ______,eohBIRD___,eohBIRD___,eohJ______,eohJ______,eohHORUS__,eohK______,eohK______,eohBIRD___,eohBIRD___,eohA______,eohA______,eohBIRD___,eohBIRD___,eohJ______,eohJ______,eohBIRD___,eohBIRD___,eohQ______",
        "eohQ______,eohHORUS__,eohA______,eohA______,eohEYE____,eohA______,eohA______,eohDOG____,eohDOG____,eohQ______,eohQ______,eohPYRAMID,eohQ______,eohQ______,eohDOG____,eohDOG____,eohK______,eohK______,eohHORUS__,eohJ______,eohJ______,eohDOG____,eohDOG____,eohJ______,eohDOG____,eohDOG____,eohJ______,eohJ______,eohHORUS__,eohK______,eohK______,eohDOG____,eohDOG____,eohA______,eohA______,eohDOG____,eohDOG____,eohJ______,eohJ______,eohDOG____,eohDOG____,eohQ______",
        "eohQ______,eohHORUS__,eohA______,eohA______,eohEYE____,eohA______,eohA______,eohEYE____,eohEYE____,eohQ______,eohQ______,eohPYRAMID,eohQ______,eohQ______,eohEYE____,eohEYE____,eohK______,eohK______,eohHORUS__,eohJ______,eohJ______,eohEYE____,eohEYE____,eohJ______,eohEYE____,eohEYE____,eohJ______,eohJ______,eohHORUS__,eohK______,eohK______,eohEYE____,eohEYE____,eohA______,eohA______,eohEYE____,eohEYE____,eohJ______,eohJ______,eohEYE____,eohEYE____,eohQ______",

        "eohQ______,eohQ______,eohHORUS__,eohJ______,eohJ______,eohJ______,eohSCARAB_,eohSCARAB_,eohA______,eohA______,eohPYRAMID,eohA______,eohA______,eohKEY____,eohKEY____,eohJ______,eohJ______,eohJ______,eohEYE____,eohA______,eohA______,eohA______,eohFLOWER_,eohFLOWER_,eohFLOWER_,eohQ______,eohQ______,eohPYRAMID,eohQ______,eohQ______,eohQ______,eohBIRD___,eohBIRD___,eohJ______,eohJ______,eohJ______,eohKEY____,eohKEY____,eohKEY____,eohA______,eohA______,eohSCARAB_,eohSCARAB_,eohK______,eohK______,eohEYE____,eohK______,eohK______,eohK______,eohDOG____,eohDOG____,eohQ______,eohQ______,eohBIRD___,eohBIRD___,eohK______,eohK______,eohK______,eohFLOWER_,eohFLOWER_",
        "eohQ______,eohQ______,eohHORUS__,eohK______,eohK______,eohKEY____,eohKEY____,eohKEY____,eohQ______,eohQ______,eohPYRAMID,eohQ______,eohQ______,eohSCARAB_,eohSCARAB_,eohJ______,eohJ______,eohJ______,eohHORUS__,eohA______,eohA______,eohFLOWER_,eohFLOWER_,eohJ______,eohJ______,eohEYE____,eohJ______,eohJ______,eohJ______,eohHORUS__,eohQ______,eohQ______,eohKEY____,eohKEY____,eohK______,eohK______,eohFLOWER_,eohFLOWER_,eohA______,eohA______,eohPYRAMID,eohA______,eohA______,eohBIRD___,eohBIRD___,eohBIRD___,eohK______,eohK______,eohSCARAB_,eohSCARAB_,eohA______,eohA______,eohDOG____,eohDOG____,eohK______,eohK______,eohFLOWER_,eohFLOWER_",
        "eohQ______,eohQ______,eohHORUS__,eohK______,eohK______,eohK______,eohKEY____,eohKEY____,eohKEY____,eohQ______,eohQ______,eohPYRAMID,eohQ______,eohQ______,eohSCARAB_,eohSCARAB_,eohJ______,eohJ______,eohJ______,eohHORUS__,eohA______,eohA______,eohKEY____,eohKEY____,eohJ______,eohJ______,eohEYE____,eohJ______,eohJ______,eohJ______,eohKEY____,eohKEY____,eohK______,eohK______,eohK______,eohKEY____,eohKEY____,eohA______,eohA______,eohPYRAMID,eohA______,eohA______,eohBIRD___,eohBIRD___,eohBIRD___,eohQ______,eohQ______,eohSCARAB_,eohSCARAB_,eohA______,eohA______,eohDOG____,eohDOG____,eohK______,eohK______,eohKEY____,eohKEY____",
        "eohQ______,eohQ______,eohHORUS__,eohA______,eohA______,eohA______,eohSCARAB_,eohSCARAB_,eohSCARAB_,eohQ______,eohQ______,eohQ______,eohSCARAB_,eohSCARAB_,eohJ______,eohJ______,eohJ______,eohSCARAB_,eohSCARAB_,eohJ______,eohJ______,eohEYE____,eohJ______,eohJ______,eohJ______,eohSCARAB_,eohSCARAB_,eohK______,eohK______,eohK______,eohSCARAB_,eohSCARAB_,eohA______,eohA______,eohA______,eohPYRAMID,eohA______,eohA______,eohBIRD___,eohBIRD___,eohBIRD___,eohK______,eohK______,eohK______,eohSCARAB_,eohSCARAB_,eohQ______,eohQ______,eohQ______,eohDOG____,eohDOG____,eohK______,eohK______,eohSCARAB_,eohSCARAB_",
        "eohQ______,eohQ______,eohHORUS__,eohA______,eohA______,eohBIRD___,eohBIRD___,eohQ______,eohQ______,eohBIRD___,eohJ______,eohJ______,eohBIRD___,eohBIRD___,eohJ______,eohJ______,eohBIRD___,eohQ______,eohQ______,eohBIRD___,eohBIRD___,eohJ______,eohJ______,eohBIRD___,eohBIRD___,eohK______,eohK______,eohBIRD___,eohBIRD___,eohA______,eohA______,eohPYRAMID,eohA______,eohA______,eohEYE____,eohA______,eohA______,eohBIRD___,eohBIRD___,eohK______,eohK______,eohBIRD___,eohBIRD___,eohQ______,eohQ______,eohDOG____,eohK______,eohK______,eohBIRD___,eohBIRD___,eohK______,eohK______,eohDOG____,eohJ______,eohJ______",
        "eohQ______,eohQ______,eohHORUS__,eohA______,eohA______,eohDOG____,eohDOG____,eohQ______,eohQ______,eohDOG____,eohJ______,eohJ______,eohDOG____,eohJ______,eohDOG____,eohJ______,eohJ______,eohDOG____,eohQ______,eohQ______,eohDOG____,eohDOG____,eohJ______,eohJ______,eohDOG____,eohDOG____,eohK______,eohK______,eohDOG____,eohDOG____,eohA______,eohA______,eohPYRAMID,eohA______,eohA______,eohEYE____,eohA______,eohA______,eohDOG____,eohDOG____,eohK______,eohK______,eohDOG____,eohDOG____,eohQ______,eohQ______,eohDOG____,eohK______,eohK______,eohEYE____,eohK______,eohK______,eohDOG____,eohDOG____,eohA______,eohA______,eohDOG____,eohQ______,eohDOG____,eohQ______,eohQ______,eohDOG____,eohK______,eohK______,eohDOG____,eohQ______,eohQ______,eohDOG____,eohDOG____,eohJ______,eohJ______,eohDOG____,eohJ______,eohDOG____,eohJ______,eohJ______,eohDOG____,eohJ______,eohJ______,eohDOG____,eohDOG____,eohK______,eohK______,eohDOG____,eohK______,eohK______,eohDOG____,eohK______,eohK______,eohDOG____,eohA______,eohA______,eohDOG____,eohQ______,eohQ______,eohDOG____,eohQ______,eohDOG____,eohDOG____,eohA______,eohA______,eohDOG____,eohJ______,eohJ______,eohDOG____,eohDOG____,eohA______,eohA______",
        "eohQ______,eohQ______,eohHORUS__,eohA______,eohA______,eohEYE____,eohEYE____,eohQ______,eohQ______,eohEYE____,eohJ______,eohJ______,eohEYE____,eohJ______,eohEYE____,eohJ______,eohJ______,eohEYE____,eohQ______,eohQ______,eohEYE____,eohEYE____,eohJ______,eohJ______,eohEYE____,eohEYE____,eohK______,eohK______,eohEYE____,eohEYE____,eohA______,eohA______,eohPYRAMID,eohA______,eohA______,eohEYE____,eohA______,eohA______,eohEYE____,eohEYE____,eohK______,eohK______,eohEYE____,eohEYE____,eohQ______,eohQ______,eohEYE____,eohK______,eohK______,eohEYE____,eohK______,eohK______,eohEYE____,eohEYE____,eohA______,eohA______,eohEYE____,eohQ______,eohEYE____,eohQ______,eohQ______,eohEYE____,eohK______,eohK______,eohEYE____,eohQ______,eohQ______,eohEYE____,eohEYE____,eohJ______,eohJ______,eohEYE____,eohJ______,eohEYE____,eohJ______,eohJ______,eohEYE____,eohJ______,eohJ______,eohEYE____,eohEYE____,eohK______,eohK______,eohEYE____,eohK______,eohK______,eohEYE____,eohK______,eohK______,eohEYE____,eohA______,eohA______,eohEYE____,eohQ______,eohQ______,eohEYE____,eohQ______,eohEYE____,eohEYE____,eohA______,eohA______,eohEYE____,eohJ______,eohJ______,eohEYE____,eohEYE____,eohA______,eohA______",
        "eohQ______,eohQ______,eohHORUS__,eohJ______,eohJ______,eohJ______,eohSCARAB_,eohSCARAB_,eohA______,eohA______,eohPYRAMID,eohA______,eohKEY____,eohKEY____,eohJ______,eohJ______,eohFLOWER_,eohFLOWER_,eohA______,eohA______,eohSCARAB_,eohSCARAB_,eohK______,eohK______,eohEYE____,eohK______,eohK______,eohDOG____,eohDOG____,eohQ______,eohQ______,eohBIRD___,eohBIRD___,eohK______,eohK______,eohFLOWER_,eohFLOWER_",
        "eohQ______,eohQ______,eohHORUS__,eohJ______,eohJ______,eohJ______,eohSCARAB_,eohSCARAB_,eohA______,eohA______,eohPYRAMID,eohA______,eohKEY____,eohKEY____,eohJ______,eohJ______,eohHORUS__,eohQ______,eohQ______,eohFLOWER_,eohFLOWER_,eohA______,eohA______,eohSCARAB_,eohSCARAB_,eohK______,eohK______,eohEYE____,eohK______,eohK______,eohDOG____,eohDOG____,eohQ______,eohQ______,eohBIRD___,eohBIRD___,eohK______,eohK______,eohFLOWER_,eohFLOWER_",
        "eohQ______,eohQ______,eohHORUS__,eohJ______,eohJ______,eohJ______,eohSCARAB_,eohSCARAB_,eohA______,eohA______,eohPYRAMID,eohA______,eohKEY____,eohKEY____,eohJ______,eohJ______,eohHORUS__,eohQ______,eohQ______,eohKEY____,eohKEY____,eohA______,eohA______,eohSCARAB_,eohSCARAB_,eohK______,eohK______,eohEYE____,eohK______,eohK______,eohDOG____,eohDOG____,eohQ______,eohQ______,eohBIRD___,eohBIRD___,eohK______,eohK______,eohKEY____,eohKEY____",
        "eohQ______,eohQ______,eohHORUS__,eohJ______,eohJ______,eohJ______,eohSCARAB_,eohSCARAB_,eohA______,eohA______,eohPYRAMID,eohA______,eohSCARAB_,eohSCARAB_,eohJ______,eohJ______,eohHORUS__,eohQ______,eohQ______,eohSCARAB_,eohSCARAB_,eohA______,eohA______,eohSCARAB_,eohSCARAB_,eohK______,eohK______,eohEYE____,eohK______,eohK______,eohDOG____,eohDOG____,eohQ______,eohQ______,eohBIRD___,eohBIRD___,eohK______,eohK______,eohSCARAB_,eohSCARAB_",
        "eohQ______,eohQ______,eohHORUS__,eohJ______,eohJ______,eohJ______,eohBIRD___,eohBIRD___,eohA______,eohA______,eohPYRAMID,eohA______,eohBIRD___,eohBIRD___,eohJ______,eohJ______,eohHORUS__,eohQ______,eohQ______,eohBIRD___,eohBIRD___,eohA______,eohA______,eohBIRD___,eohBIRD___,eohK______,eohK______,eohEYE____,eohK______,eohK______,eohDOG____,eohDOG____,eohQ______,eohQ______,eohBIRD___,eohBIRD___,eohK______,eohK______,eohBIRD___,eohBIRD___",
        "eohQ______,eohQ______,eohHORUS__,eohJ______,eohJ______,eohJ______,eohDOG____,eohDOG____,eohA______,eohA______,eohPYRAMID,eohA______,eohDOG____,eohDOG____,eohJ______,eohJ______,eohHORUS__,eohQ______,eohQ______,eohDOG____,eohDOG____,eohA______,eohA______,eohDOG____,eohDOG____,eohK______,eohK______,eohEYE____,eohK______,eohK______,eohDOG____,eohDOG____,eohQ______,eohQ______,eohDOG____,eohDOG____,eohK______,eohK______,eohDOG____,eohDOG____",
        "eohQ______,eohQ______,eohHORUS__,eohJ______,eohJ______,eohJ______,eohEYE____,eohEYE____,eohA______,eohA______,eohPYRAMID,eohA______,eohEYE____,eohEYE____,eohJ______,eohJ______,eohHORUS__,eohQ______,eohQ______,eohEYE____,eohEYE____,eohA______,eohA______,eohEYE____,eohEYE____,eohK______,eohK______,eohEYE____,eohK______,eohK______,eohEYE____,eohEYE____,eohQ______,eohQ______,eohEYE____,eohEYE____,eohK______,eohK______,eohEYE____,eohEYE____",

        "eohA______,eohA______,eohHORUS__,eohK______,eohK______,eohDOG____,eohDOG____,eohQ______,eohQ______,eohKEY____,eohKEY____,eohKEY____,eohJ______,eohJ______,eohPYRAMID,eohJ______,eohJ______,eohJ______,eohSCARAB_,eohSCARAB_,eohK______,eohK______,eohKEY____,eohKEY____,eohA______,eohA______,eohEYE____,eohA______,eohA______,eohBIRD___,eohBIRD___,eohQ______,eohQ______,eohQ______,eohFLOWER_,eohFLOWER_,eohK______,eohK______,eohEYE____,eohK______,eohK______,eohBIRD___,eohBIRD___,eohA______,eohA______,eohA______,eohFLOWER_,eohFLOWER_,eohQ______,eohQ______,eohPYRAMID,eohQ______,eohQ______,eohFLOWER_,eohFLOWER_,eohJ______,eohJ______,eohJ______,eohSCARAB_,eohSCARAB_",
        "eohJ______,eohJ______,eohJ______,eohHORUS__,eohK______,eohK______,eohPYRAMID,eohK______,eohK______,eohKEY____,eohKEY____,eohKEY____,eohJ______,eohJ______,eohPYRAMID,eohJ______,eohJ______,eohJ______,eohSCARAB_,eohSCARAB_,eohQ______,eohQ______,eohQ______,eohDOG____,eohDOG____,eohA______,eohA______,eohA______,eohHORUS__,eohQ______,eohQ______,eohQ______,eohFLOWER_,eohFLOWER_,eohFLOWER_,eohA______,eohA______,eohSCARAB_,eohSCARAB_,eohQ______,eohQ______,eohBIRD___,eohBIRD___,eohBIRD___,eohK______,eohK______,eohEYE____,eohK______,eohK______,eohFLOWER_,eohFLOWER_,eohFLOWER_,eohA______,eohA______,eohA______,eohKEY____,eohKEY____",
        "eohJ______,eohJ______,eohJ______,eohHORUS__,eohK______,eohK______,eohK______,eohKEY____,eohKEY____,eohQ______,eohQ______,eohDOG____,eohDOG____,eohJ______,eohJ______,eohPYRAMID,eohJ______,eohJ______,eohJ______,eohSCARAB_,eohSCARAB_,eohQ______,eohQ______,eohQ______,eohKEY____,eohKEY____,eohA______,eohA______,eohA______,eohKEY____,eohKEY____,eohA______,eohA______,eohSCARAB_,eohSCARAB_,eohQ______,eohQ______,eohQ______,eohBIRD___,eohBIRD___,eohBIRD___,eohK______,eohK______,eohEYE____,eohK______,eohK______,eohK______,eohKEY____,eohKEY____,eohKEY____,eohA______,eohA______,eohA______,eohKEY____,eohKEY____",
        "eohJ______,eohJ______,eohJ______,eohHORUS__,eohK______,eohK______,eohK______,eohSCARAB_,eohSCARAB_,eohQ______,eohQ______,eohDOG____,eohDOG____,eohJ______,eohJ______,eohPYRAMID,eohJ______,eohJ______,eohJ______,eohSCARAB_,eohSCARAB_,eohQ______,eohQ______,eohQ______,eohSCARAB_,eohSCARAB_,eohA______,eohA______,eohA______,eohSCARAB_,eohSCARAB_,eohA______,eohA______,eohSCARAB_,eohSCARAB_,eohQ______,eohQ______,eohQ______,eohBIRD___,eohBIRD___,eohBIRD___,eohK______,eohK______,eohEYE____,eohK______,eohK______,eohK______,eohSCARAB_,eohSCARAB_,eohSCARAB_,eohA______,eohA______,eohA______,eohSCARAB_,eohSCARAB_",
        "eohA______,eohJ______,eohJ______,eohHORUS__,eohK______,eohK______,eohBIRD___,eohBIRD___,eohQ______,eohQ______,eohBIRD___,eohJ______,eohJ______,eohDOG____,eohJ______,eohJ______,eohPYRAMID,eohJ______,eohJ______,eohBIRD___,eohBIRD___,eohQ______,eohQ______,eohBIRD___,eohBIRD___,eohA______,eohA______,eohEYE____,eohA______,eohA______,eohBIRD___,eohBIRD___,eohQ______,eohQ______,eohBIRD___,eohQ______,eohQ______,eohBIRD___,eohK______,eohK______,eohBIRD___,eohK______,eohK______,eohDOG____,eohDOG____,eohK______,eohK______,eohBIRD___,eohA______,eohA______,eohBIRD___,eohA______,eohA______,eohBIRD___,eohBIRD___,eohJ______,eohJ______,eohEYE____,eohJ______,eohJ______,eohBIRD___,eohBIRD___,eohQ______,eohQ______,eohBIRD___,eohJ______,eohJ______,eohBIRD___,eohJ______,eohJ______,eohBIRD___,eohBIRD___,eohQ______,eohQ______,eohBIRD___,eohBIRD___,eohA______,eohA______,eohDOG____,eohA______,eohA______,eohBIRD___,eohQ______,eohQ______,eohBIRD___,eohQ______,eohQ______,eohBIRD___,eohBIRD___,eohK______,eohK______,eohBIRD___,eohK______,eohK______,eohBIRD___,eohBIRD___,eohK______,eohK______,eohBIRD___,eohK______,eohK______,eohBIRD___,eohBIRD___,eohA______,eohA______,eohBIRD___,eohBIRD___,eohA______",
        "eohA______,eohJ______,eohJ______,eohHORUS__,eohK______,eohK______,eohDOG____,eohDOG____,eohQ______,eohQ______,eohDOG____,eohJ______,eohJ______,eohDOG____,eohJ______,eohJ______,eohPYRAMID,eohJ______,eohJ______,eohDOG____,eohDOG____,eohQ______,eohQ______,eohDOG____,eohDOG____,eohA______,eohA______,eohEYE____,eohA______,eohA______,eohDOG____,eohDOG____,eohQ______,eohQ______,eohDOG____,eohQ______,eohQ______,eohDOG____,eohK______,eohK______,eohDOG____,eohK______,eohK______,eohDOG____,eohDOG____,eohK______,eohK______,eohDOG____,eohA______,eohA______,eohDOG____,eohA______,eohA______,eohDOG____,eohDOG____,eohJ______,eohJ______,eohEYE____,eohJ______,eohJ______,eohDOG____,eohDOG____,eohQ______,eohQ______,eohDOG____,eohJ______,eohJ______,eohDOG____,eohJ______,eohJ______,eohDOG____,eohDOG____,eohQ______,eohQ______,eohDOG____,eohDOG____,eohA______,eohA______,eohDOG____,eohA______,eohA______,eohDOG____,eohQ______,eohQ______,eohDOG____,eohQ______,eohQ______,eohDOG____,eohDOG____,eohK______,eohK______,eohDOG____,eohK______,eohK______,eohDOG____,eohDOG____,eohK______,eohK______,eohDOG____,eohK______,eohK______,eohDOG____,eohDOG____,eohA______,eohA______,eohDOG____,eohDOG____,eohA______",
        "eohA______,eohJ______,eohJ______,eohHORUS__,eohK______,eohK______,eohEYE____,eohEYE____,eohQ______,eohQ______,eohEYE____,eohJ______,eohJ______,eohEYE____,eohJ______,eohJ______,eohPYRAMID,eohJ______,eohJ______,eohEYE____,eohEYE____,eohQ______,eohQ______,eohEYE____,eohEYE____,eohA______,eohA______,eohEYE____,eohA______,eohA______,eohEYE____,eohEYE____,eohQ______,eohQ______,eohEYE____,eohQ______,eohQ______,eohEYE____,eohK______,eohK______,eohEYE____,eohK______,eohK______,eohEYE____,eohEYE____,eohK______,eohK______,eohEYE____,eohA______,eohA______,eohEYE____,eohA______,eohA______,eohEYE____,eohEYE____,eohJ______,eohJ______,eohEYE____,eohJ______,eohJ______,eohEYE____,eohEYE____,eohQ______,eohQ______,eohEYE____,eohJ______,eohJ______,eohEYE____,eohJ______,eohJ______,eohEYE____,eohEYE____,eohQ______,eohQ______,eohEYE____,eohEYE____,eohA______,eohA______,eohEYE____,eohA______,eohA______,eohEYE____,eohQ______,eohQ______,eohEYE____,eohQ______,eohQ______,eohEYE____,eohEYE____,eohK______,eohK______,eohEYE____,eohK______,eohK______,eohEYE____,eohEYE____,eohK______,eohK______,eohEYE____,eohK______,eohK______,eohEYE____,eohEYE____,eohA______,eohA______,eohEYE____,eohEYE____,eohA______",
        "eohA______,eohA______,eohHORUS__,eohK______,eohK______,eohDOG____,eohDOG____,eohQ______,eohQ______,eohKEY____,eohKEY____,eohJ______,eohJ______,eohKEY____,eohKEY____,eohJ______,eohJ______,eohEYE____,eohK______,eohK______,eohBIRD___,eohBIRD___,eohA______,eohA______,eohA______,eohFLOWER_,eohFLOWER_,eohQ______,eohPYRAMID,eohQ______,eohQ______,eohFLOWER_,eohFLOWER_,eohJ______,eohJ______,eohSCARAB_,eohSCARAB_",
        "eohA______,eohA______,eohHORUS__,eohK______,eohK______,eohDOG____,eohDOG____,eohQ______,eohQ______,eohKEY____,eohKEY____,eohJ______,eohJ______,eohEYE____,eohK______,eohK______,eohHORUS__,eohJ______,eohJ______,eohKEY____,eohKEY____,eohK______,eohK______,eohBIRD___,eohBIRD___,eohA______,eohA______,eohA______,eohFLOWER_,eohFLOWER_,eohQ______,eohPYRAMID,eohQ______,eohQ______,eohFLOWER_,eohFLOWER_,eohJ______,eohJ______,eohSCARAB_,eohSCARAB_",
        "eohA______,eohA______,eohHORUS__,eohK______,eohK______,eohDOG____,eohDOG____,eohQ______,eohQ______,eohKEY____,eohKEY____,eohJ______,eohJ______,eohEYE____,eohK______,eohK______,eohHORUS__,eohJ______,eohJ______,eohKEY____,eohKEY____,eohK______,eohK______,eohBIRD___,eohBIRD___,eohA______,eohA______,eohA______,eohKEY____,eohKEY____,eohQ______,eohPYRAMID,eohQ______,eohQ______,eohKEY____,eohKEY____,eohJ______,eohJ______,eohSCARAB_,eohSCARAB_",
        "eohA______,eohA______,eohHORUS__,eohK______,eohK______,eohDOG____,eohDOG____,eohQ______,eohQ______,eohSCARAB_,eohSCARAB_,eohJ______,eohJ______,eohEYE____,eohK______,eohK______,eohHORUS__,eohJ______,eohJ______,eohSCARAB_,eohSCARAB_,eohK______,eohK______,eohBIRD___,eohBIRD___,eohA______,eohA______,eohA______,eohSCARAB_,eohSCARAB_,eohQ______,eohPYRAMID,eohQ______,eohQ______,eohSCARAB_,eohSCARAB_,eohJ______,eohJ______,eohSCARAB_,eohSCARAB_",
        "eohA______,eohA______,eohHORUS__,eohK______,eohK______,eohDOG____,eohDOG____,eohQ______,eohQ______,eohBIRD___,eohBIRD___,eohJ______,eohJ______,eohEYE____,eohK______,eohK______,eohHORUS__,eohJ______,eohJ______,eohBIRD___,eohBIRD___,eohK______,eohK______,eohBIRD___,eohBIRD___,eohA______,eohA______,eohA______,eohBIRD___,eohBIRD___,eohQ______,eohPYRAMID,eohQ______,eohQ______,eohBIRD___,eohBIRD___,eohJ______,eohJ______,eohBIRD___,eohBIRD___",
        "eohA______,eohA______,eohHORUS__,eohK______,eohK______,eohDOG____,eohDOG____,eohQ______,eohQ______,eohDOG____,eohDOG____,eohJ______,eohJ______,eohEYE____,eohK______,eohK______,eohHORUS__,eohJ______,eohJ______,eohDOG____,eohDOG____,eohK______,eohK______,eohDOG____,eohDOG____,eohA______,eohA______,eohA______,eohDOG____,eohDOG____,eohQ______,eohPYRAMID,eohQ______,eohQ______,eohDOG____,eohDOG____,eohJ______,eohJ______,eohDOG____,eohDOG____",
        "eohA______,eohA______,eohHORUS__,eohK______,eohK______,eohEYE____,eohEYE____,eohQ______,eohQ______,eohEYE____,eohEYE____,eohJ______,eohJ______,eohEYE____,eohK______,eohK______,eohHORUS__,eohJ______,eohJ______,eohEYE____,eohEYE____,eohK______,eohK______,eohEYE____,eohEYE____,eohA______,eohA______,eohA______,eohEYE____,eohEYE____,eohQ______,eohPYRAMID,eohQ______,eohQ______,eohEYE____,eohEYE____,eohJ______,eohJ______,eohEYE____,eohEYE____",

        "eohQ______,eohQ______,eohEYE____,eohQ______,eohQ______,eohSCARAB_,eohSCARAB_,eohJ______,eohJ______,eohPYRAMID,eohJ______,eohJ______,eohKEY____,eohKEY____,eohKEY____,eohA______,eohA______,eohPYRAMID,eohA______,eohA______,eohA______,eohFLOWER_,eohFLOWER_,eohFLOWER_,eohJ______,eohJ______,eohJ______,eohBIRD___,eohBIRD___,eohK______,eohK______,eohEYE____,eohK______,eohK______,eohDOG____,eohDOG____,eohQ______,eohQ______,eohKEY____,eohKEY____,eohA______,eohA______,eohA______,eohDOG____,eohDOG____,eohK______,eohK______,eohK______,eohFLOWER_,eohFLOWER_,eohFLOWER_,eohJ______,eohJ______,eohSCARAB_,eohSCARAB_,eohQ______,eohQ______,eohQ______,eohBIRD___,eohBIRD___",
        "eohQ______,eohQ______,eohEYE____,eohQ______,eohQ______,eohQ______,eohSCARAB_,eohSCARAB_,eohK______,eohK______,eohK______,eohPYRAMID,eohK______,eohK______,eohKEY____,eohKEY____,eohKEY____,eohJ______,eohJ______,eohFLOWER_,eohFLOWER_,eohJ______,eohJ______,eohBIRD___,eohBIRD___,eohA______,eohA______,eohPYRAMID,eohA______,eohA______,eohA______,eohKEY____,eohKEY____,eohQ______,eohQ______,eohQ______,eohFLOWER_,eohFLOWER_,eohA______,eohA______,eohA______,eohDOG____,eohDOG____,eohJ______,eohJ______,eohBIRD___,eohK______,eohK______,eohK______,eohFLOWER_,eohFLOWER_,eohJ______,eohJ______,eohSCARAB_,eohSCARAB_",
        "eohQ______,eohQ______,eohEYE____,eohQ______,eohQ______,eohQ______,eohSCARAB_,eohSCARAB_,eohK______,eohK______,eohK______,eohPYRAMID,eohK______,eohK______,eohKEY____,eohKEY____,eohKEY____,eohJ______,eohJ______,eohKEY____,eohKEY____,eohJ______,eohJ______,eohBIRD___,eohBIRD___,eohA______,eohA______,eohPYRAMID,eohA______,eohA______,eohA______,eohKEY____,eohKEY____,eohQ______,eohQ______,eohQ______,eohKEY____,eohKEY____,eohA______,eohA______,eohA______,eohDOG____,eohDOG____,eohJ______,eohJ______,eohBIRD___,eohK______,eohK______,eohK______,eohKEY____,eohKEY____,eohJ______,eohJ______,eohSCARAB_,eohSCARAB_",
        "eohQ______,eohQ______,eohEYE____,eohQ______,eohQ______,eohQ______,eohSCARAB_,eohSCARAB_,eohK______,eohK______,eohK______,eohSCARAB_,eohSCARAB_,eohSCARAB_,eohK______,eohK______,eohSCARAB_,eohSCARAB_,eohJ______,eohJ______,eohJ______,eohBIRD___,eohBIRD___,eohA______,eohA______,eohPYRAMID,eohA______,eohA______,eohA______,eohSCARAB_,eohSCARAB_,eohQ______,eohQ______,eohQ______,eohSCARAB_,eohSCARAB_,eohA______,eohA______,eohA______,eohDOG____,eohDOG____,eohJ______,eohJ______,eohBIRD___,eohK______,eohK______,eohK______,eohSCARAB_,eohSCARAB_,eohJ______,eohJ______,eohJ______,eohSCARAB_,eohSCARAB_",
        "eohQ______,eohQ______,eohEYE____,eohQ______,eohQ______,eohBIRD___,eohBIRD___,eohK______,eohK______,eohDOG____,eohK______,eohK______,eohBIRD___,eohJ______,eohJ______,eohBIRD___,eohBIRD___,eohQ______,eohQ______,eohBIRD___,eohBIRD___,eohA______,eohA______,eohPYRAMID,eohA______,eohA______,eohBIRD___,eohQ______,eohQ______,eohBIRD___,eohBIRD___,eohA______,eohA______,eohDOG____,eohA______,eohA______,eohBIRD___,eohJ______,eohJ______,eohBIRD___,eohBIRD___,eohK______,eohK______,eohBIRD___,eohK______,eohK______,eohBIRD___,eohBIRD___,eohJ______,eohJ______,eohBIRD___,eohJ______,eohJ______,eohBIRD___",
        "eohQ______,eohQ______,eohEYE____,eohQ______,eohQ______,eohDOG____,eohDOG____,eohK______,eohK______,eohDOG____,eohK______,eohK______,eohDOG____,eohJ______,eohJ______,eohDOG____,eohDOG____,eohQ______,eohQ______,eohDOG____,eohDOG____,eohA______,eohA______,eohPYRAMID,eohA______,eohA______,eohDOG____,eohQ______,eohQ______,eohDOG____,eohDOG____,eohA______,eohA______,eohDOG____,eohA______,eohA______,eohDOG____,eohJ______,eohJ______,eohDOG____,eohDOG____,eohK______,eohK______,eohDOG____,eohK______,eohK______,eohDOG____,eohDOG____,eohJ______,eohJ______,eohDOG____,eohJ______,eohJ______,eohDOG____",
        "eohQ______,eohQ______,eohEYE____,eohQ______,eohQ______,eohEYE____,eohEYE____,eohK______,eohK______,eohEYE____,eohK______,eohK______,eohEYE____,eohJ______,eohJ______,eohEYE____,eohEYE____,eohQ______,eohQ______,eohEYE____,eohEYE____,eohA______,eohA______,eohPYRAMID,eohA______,eohA______,eohEYE____,eohQ______,eohQ______,eohEYE____,eohEYE____,eohA______,eohA______,eohEYE____,eohA______,eohA______,eohEYE____,eohJ______,eohJ______,eohEYE____,eohEYE____,eohK______,eohK______,eohEYE____,eohK______,eohK______,eohEYE____,eohEYE____,eohJ______,eohJ______,eohEYE____,eohJ______,eohJ______,eohEYE____",
        "eohQ______,eohQ______,eohEYE____,eohQ______,eohQ______,eohSCARAB_,eohSCARAB_,eohJ______,eohJ______,eohPYRAMID,eohJ______,eohJ______,eohKEY____,eohKEY____,eohA______,eohA______,eohPYRAMID,eohA______,eohA______,eohKEY____,eohKEY____,eohA______,eohA______,eohDOG____,eohDOG____,eohK______,eohK______,eohFLOWER_,eohFLOWER_,eohFLOWER_,eohQ______,eohQ______,eohSCARAB_,eohSCARAB_,eohK______,eohK______,eohBIRD___,eohBIRD___",
        "eohQ______,eohQ______,eohEYE____,eohQ______,eohQ______,eohSCARAB_,eohSCARAB_,eohJ______,eohJ______,eohPYRAMID,eohJ______,eohJ______,eohKEY____,eohKEY____,eohA______,eohA______,eohKEY____,eohKEY____,eohA______,eohA______,eohDOG____,eohDOG____,eohK______,eohK______,eohFLOWER_,eohFLOWER_,eohFLOWER_,eohA______,eohA______,eohSCARAB_,eohSCARAB_,eohK______,eohK______,eohBIRD___,eohBIRD___",
        "eohQ______,eohQ______,eohEYE____,eohQ______,eohQ______,eohSCARAB_,eohSCARAB_,eohJ______,eohJ______,eohPYRAMID,eohJ______,eohJ______,eohKEY____,eohKEY____,eohA______,eohA______,eohKEY____,eohKEY____,eohA______,eohA______,eohDOG____,eohDOG____,eohK______,eohK______,eohKEY____,eohKEY____,eohKEY____,eohA______,eohA______,eohSCARAB_,eohSCARAB_,eohK______,eohK______,eohBIRD___,eohBIRD___",
        "eohQ______,eohQ______,eohEYE____,eohQ______,eohQ______,eohSCARAB_,eohSCARAB_,eohJ______,eohJ______,eohPYRAMID,eohJ______,eohJ______,eohSCARAB_,eohSCARAB_,eohA______,eohA______,eohSCARAB_,eohSCARAB_,eohA______,eohA______,eohDOG____,eohDOG____,eohK______,eohK______,eohSCARAB_,eohSCARAB_,eohSCARAB_,eohA______,eohA______,eohSCARAB_,eohSCARAB_,eohK______,eohK______,eohBIRD___,eohBIRD___",
        "eohQ______,eohQ______,eohEYE____,eohQ______,eohQ______,eohBIRD___,eohBIRD___,eohJ______,eohJ______,eohPYRAMID,eohJ______,eohJ______,eohBIRD___,eohBIRD___,eohA______,eohA______,eohBIRD___,eohBIRD___,eohA______,eohA______,eohDOG____,eohDOG____,eohK______,eohK______,eohBIRD___,eohBIRD___,eohBIRD___,eohA______,eohA______,eohBIRD___,eohBIRD___,eohK______,eohK______,eohBIRD___,eohBIRD___",
        "eohQ______,eohQ______,eohEYE____,eohQ______,eohQ______,eohDOG____,eohDOG____,eohJ______,eohJ______,eohPYRAMID,eohJ______,eohJ______,eohDOG____,eohDOG____,eohA______,eohA______,eohDOG____,eohDOG____,eohA______,eohA______,eohDOG____,eohDOG____,eohK______,eohK______,eohDOG____,eohDOG____,eohDOG____,eohA______,eohA______,eohDOG____,eohDOG____,eohK______,eohK______,eohDOG____,eohDOG____",
        "eohQ______,eohQ______,eohEYE____,eohQ______,eohQ______,eohEYE____,eohEYE____,eohJ______,eohJ______,eohPYRAMID,eohJ______,eohJ______,eohEYE____,eohEYE____,eohA______,eohA______,eohEYE____,eohEYE____,eohA______,eohA______,eohEYE____,eohEYE____,eohK______,eohK______,eohEYE____,eohEYE____,eohEYE____,eohA______,eohA______,eohEYE____,eohEYE____,eohK______,eohK______,eohEYE____,eohEYE____",
    };

    for (int i = 0; i < m_vecReelStripPlan.size(); i++) {
        ReelSet set;
        for (int j = 0; j < m_nReel; j++) {
            ReelStrip strip;
            std::stringstream ss(eohReelStrip[j * m_vecReelStripPlan.size() + i]);
            std::string item;
            while (std::getline(ss, item, ',')) {
                strip.push_back(item);
            }
            set.push_back(strip);
        }
        m_vecReelStripSets.push_back(set);
    }

    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_05_tmp;
    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_10_tmp;
    for (int i = 0; i < m_vecBetSteps_05_tmp.size(); i++) {
        std::map<std::string, std::map<UINT8, BONUS>> perSym;
        std::map<UINT8, BONUS> e;
        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[5].ag = 0;
        perSym["eohJ______"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[5].ag = 0;
        perSym["eohQ______"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[5].ag = 0;
        perSym["eohK______"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[5].ag = 0;
        perSym["eohA______"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 50; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 200; e[5].ag = 0;
        perSym["eohFLOWER_"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 50; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 200; e[5].ag = 0;
        perSym["eohKEY____"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 250; e[5].ag = 0;
        perSym["eohSCARAB_"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 125; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 300; e[5].ag = 0;
        perSym["eohBIRD___"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 50; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 200; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 400; e[5].ag = 0;
        perSym["eohDOG____"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 250; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 500; e[5].ag = 0;
        perSym["eohEYE____"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 250; e[5].ag = 0;
        perSym["eohPYRAMID"] = e;
        e.clear();

        m_Bonus_05_tmp[i] = perSym;
    }
    m_Bonus_05_tmp[10]["eohEYE____"][5].coin = 80000;

    m_Bonus_10_tmp = m_Bonus_05_tmp;
    for (int i = 0; i < m_vecBetSteps_10_tmp.size(); i++) {
        m_Bonus_10_tmp[i]["eohPYRAMID"][3].coin *= 2;
        m_Bonus_10_tmp[i]["eohPYRAMID"][4].coin *= 2;
        m_Bonus_10_tmp[i]["eohPYRAMID"][5].coin *= 2;
    }

    int nSavedBetVal = 10;
    PlayDB::GetInstance().LoadCheckPoint(m_strGameName, nSavedBetVal, m_nWinLine, m_strCheckPoint);
    if (nSavedBetVal == -1) {
        nSavedBetVal = 10;
    }
    if (m_nWinLine == -1) {
        m_nWinLine = 5;
    }

    BOOL start = FALSE;
    int idx = 0;
    for (int i = 0; i < m_vecBetSteps_05_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_05_tmp, i) < AT(m_vecBetSteps_05, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps_05, idx) == nSavedBetVal && m_nWinLine == 5) {
            m_nBetStep = idx;
        }

        m_Bonus_05[idx++] = m_Bonus_05_tmp[i];
        if (AT(m_vecBetSteps_05_tmp, i) == AT(m_vecBetSteps_05, m_vecBetSteps_05.size() - 1)) {
            break;
        }
    }
    start = FALSE;
    idx = 0;
    for (int i = 0; i < m_vecBetSteps_10_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_10_tmp, i) < AT(m_vecBetSteps_10, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps_10, idx) == nSavedBetVal && m_nWinLine == 10) {
            m_nBetStep = idx;
        }

        m_Bonus_10[idx++] = m_Bonus_10_tmp[i];
        if (AT(m_vecBetSteps_10_tmp, i) == AT(m_vecBetSteps_10, m_vecBetSteps_10.size() - 1)) {
            break;
        }
    }
    m_Bonus = (m_nWinLine == 5 ? m_Bonus_05 : m_Bonus_10);
    m_vecBetSteps = (m_nWinLine == 5 ? m_vecBetSteps_05 : m_vecBetSteps_10);
    PrintAllBonus();
}

//eohFLOWER_ : 0, 1, 7, 8
//eohKEY____ : 0, 1, 2, 7, 8, 9
//eohSCARAB_ : 0, 1, 2, 3, 7, 8, 9, 10
//eohBIRD___ : 0, 1, 2, 3, 4, 7, 8, 9, 10, 11
//eohDOG____ : 0, 1, 2, 3, 4, 5, 7, 8, 9, 10, 11, 12
//eohEYE____ : 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13

UINT16 RgEyeOfHorus::Run() {
    m_nCurrentReelPlan = myRandom() % 2;
    m_shCurrentReelStrip = static_cast<uint16_t>(std::stoi(AT(m_vecReelStripPlan, m_nCurrentReelPlan)));
    return m_shCurrentReelStrip;
}

UINT16 RgEyeOfHorus::SpinTime_MS() {
    UINT8 n = ScatterCount();
    if (n == 2) {
        return 3300;
    }
    else if (n >= 3) {
        return 3800;
    }
    return 2500;
}

BOOL RgEyeOfHorus::CanFreeMode() {
    if (NumberOfScatter(m_vWinResult) >= 3) {
        return TRUE;
    }
    return FALSE;
}

BOOL RgEyeOfHorus::WildcountInCol(UINT8 col, myVector<UINT8> result) {
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    // check wild symbol
    int k = 0;
    for (; k < 3; k++) {
        std::string s = AT(AT(reelSet, col), AT(result, col) - 1 + k);
        if (s == RgEyeOfHorus_wild) {
            return TRUE;
        }
    }
    return FALSE;
}

UINT8 RgEyeOfHorus::Wildcount() {
    UINT8 n = 0;
    for (int i = 0; i < m_nReel; i++) {
        if (WildcountInCol(i, m_vWinResult)) {
            n++;
        }
    }
    return n;
}

UINT8 RgEyeOfHorus::ScatterCount() {
    return CardCount(RgEyeOfHorus_scatter);
}

UINT8 RgEyeOfHorus::CardCount(std::string card) {
    int n = 0;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int col = 0; col < m_nReel; col++) {
        if (WildcountInCol(col, m_vWinResult)) {
            continue;
        }
        int k = 0;
        for (; k < 3; k++) {
            std::string s = AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k);
            if (s == card) {
                n++;
            }
        }
    }
    return n;
}

UINT8 RgEyeOfHorus::NumberOfScatter(myVector<UINT8> result) {
    UINT8 n = 0;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int col = 0; col < m_nReel; col++) {
        int k = 0;
        for (; k < 3; k++) {
            std::string s = AT(AT(reelSet, col), AT(result, col) - 1 + k);
            if (s == RgEyeOfHorus_scatter) {
                n++;
            }
        }
    }
    return n;
}

myVector<UINT8> RgEyeOfHorus::Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) {
    m_bPrevSpinMatchedActive = FALSE;

    myVector<UINT8> result;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    if (bTest) {
        std::string matchSymbol = AT(m_vecSymbols, myRandom() % m_vecSymbols.size());
        int line = (myRandom() % m_nWinLine);
        int weight = 1 + (myRandom() % 5);

        BOOL bForceFree = (myRandom() % 10 == 0);
        for (int i = 0; i < m_nReel; i++) {
            ReelStrip reelStrip = AT(reelSet, i);
            int len = reelStrip.size() - 3;

            int valid_i[0x100];
            int valid_count = 0;
            myVector<int> freeSymbols;
            for (int j = 0; j <= len; j++) {
                if (weight > i) {
                    if (matchSymbol == AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                else {
                    if (matchSymbol != AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                if (AT(reelStrip, j) == RgEyeOfHorus_scatter && m_bFreeMode == FALSE) {
                    freeSymbols.push_back(j);
                }
            }
            if (valid_count > 0) {
                int rand_index = myRandom() % valid_count;
                int chosen_i = valid_i[rand_index];
                result.push_back(chosen_i + 1);
            }
            else {
                result.push_back((myRandom() % (len - 1)) + 1);
            }
            {
                int pool[5] = { 0, 1, 2, 3, 4 };
                auto v = pickRandom2or3(pool, 5, 3);
                if (bForceFree && m_bFreeMode == FALSE && freeSymbols.size() > 0 && std::find(v.begin(), v.end(), i) != v.end()) {
                    AT(result, result.size() - 1) =
                        AT(freeSymbols, myRandom() % freeSymbols.size()) - (myRandom() % 3) + 1;
                }
            }
        }
    }
    else {
        result = _result;

        BOOL mmcode = mmcode_get_active_status();
        if (mmcode) {
            mmcode_set_deactive();
            if (m_bFreeMode == FALSE) {
                for (int j = 0; j < 5; j ++) {
                    myVector<int> candidateIndices;
                    for (int i = 2; i < AT(reelSet, j).size() - 3; ++i) {
                        if (j%2 == 0 && AT(AT(reelSet, j), i) == RgEyeOfHorus_scatter) {
                            int offset = myRandom() % 3;
                            int selectedIndex = i - 2 + offset;
                            candidateIndices.push_back(selectedIndex);
                        }
                        if (j%2 == 1 && AT(AT(reelSet, j), i) != RgEyeOfHorus_scatter
                                    && AT(AT(reelSet, j), i-2) != RgEyeOfHorus_scatter
                                    && AT(AT(reelSet, j), i-1) != RgEyeOfHorus_scatter
                                    && AT(AT(reelSet, j), i+1) != RgEyeOfHorus_scatter
                                    && AT(AT(reelSet, j), i+2) != RgEyeOfHorus_scatter) {
                            int offset = myRandom() % 3;
                            int selectedIndex = i - 2 + offset;
                            candidateIndices.push_back(selectedIndex);
                        }
                    }
                    if (!candidateIndices.empty()) {
#ifdef BIGBET_ACTIVE
                        int chosenIndex = AT(candidateIndices, (candidateIndices.size()<3?myRandom() % candidateIndices.size():myRandom() % 3));
#else
                        int chosenIndex = AT(candidateIndices, myRandom() % candidateIndices.size());
#endif
                        AT(result, j) = chosenIndex + 1;
                    }
                }
            }
        }
    }

    m_vWinResult = result;

    normalMeter = 0;
    maxMeter = 0;
    BONUS totalBonus = {0, 0};
    for (int i = 0; i < m_nWinLine; i++) {
        int j = 1;
        UINT16 meter = ((UINT16)1 << (2 - g_match_lines_10_5[i][0]));
        std::string firstSymbol = AT(AT(reelSet, 0), AT(result, 0) - 1 + g_match_lines_10_5[i][0]);
        for (; j < m_nMaxMatch; j++) {
            std::string prev_symbol = AT(AT(reelSet, j - 1), AT(result, j - 1) - 1 + g_match_lines_10_5[i][j - 1]);
            std::string cur_symbol = AT(AT(reelSet, j), AT(result, j) - 1 + g_match_lines_10_5[i][j]);

            if (WildcountInCol(j, result)) {
                meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
                continue;
            }
            if (firstSymbol == cur_symbol) {
                meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
                continue;
            }
            break;
        }
        
        if (j < m_mapSymbolMinMatch[firstSymbol] || m_mapSymbolMinMatch[firstSymbol] == 0) {
            continue;
        }
        if (firstSymbol == RgEyeOfHorus_scatter) {
            continue;
        }
        // monitor 2 meter
        std::string meterStr = m_mapSymbolMeterGoc[firstSymbol];
        size_t pos = meterStr.find('$');
        if (pos != std::string::npos) {
            meterStr = meterStr.replace(pos, 1, std::to_string(j));
        }
        WinMeter e;
        e.line = i;
        e.meter = meter;
        e.meter2 = g_GrafficObjList.Str2GOCID(meterStr);
        e.symbol = firstSymbol;
        e.weight = j;
        e.start = 0;
        e.bonus = m_Bonus[BetStep()][firstSymbol][j];
        e.sound = MAX_SOUND_IDS;

        totalBonus.coin += e.bonus.coin;
        totalBonus.ag += e.bonus.ag;

        if (e.meter2 != -1) {
            meters.push_back(e);
        }
        if (j == m_nMaxMatch) {
            maxMeter |= meter;
        }
        else {
            normalMeter |= meter;
        }
        if (bTest == FALSE) {
            m_bPrevSpinMatchedActive = TRUE;
        }
    }


    int nScatter = CardCount(RgEyeOfHorus_scatter);
    if (nScatter >= 3) {
        bCanFreeMode = TRUE;

        // not match scatter 5, and scatter match contains other match
        UINT16 meter = 0;
        for (int i = 0; i < 3; i++) {
            for (int col = 0; col < m_nReel; col++) {
                std::string cur_symbol = AT(AT(reelSet, col), AT(result, col) - 1 + i);
                if (cur_symbol == RgEyeOfHorus_scatter) {
                    meter |= ((UINT16)1 << (3 * col + (2 - i)));
                }
            }
        }
        WinMeter e;
        e.line = 10;
        e.meter = meter;
        e.meter2 = g_GrafficObjList.Str2GOCID("eohPyramid" + std::to_string(nScatter) + "x");
        e.symbol = RgEyeOfHorus_scatter;
        e.weight = nScatter;
        e.start = 0;
        e.bonus = m_Bonus[BetStep()][RgEyeOfHorus_scatter][nScatter];
        e.sound = MAX_SOUND_IDS;

        normalMeter |= meter;
        totalBonus.coin += e.bonus.coin;
        totalBonus.ag += e.bonus.ag;

        meters.push_back(e);

        if (bTest == FALSE) {
            m_bPrevSpinMatchedActive = TRUE;
        }
    }

    if (bTest == FALSE) {
        updateCheckPoint();

        if (totalBonus.coin > 0 || totalBonus.ag > 0) {
            if (m_bFreeMode) {
                m_nFreeModeTotalBonus.coin += totalBonus.coin;
                m_nFreeModeTotalBonus.ag += totalBonus.ag;
            }
            BonusSound = getSoundByID(WinSound(totalBonus.coin + totalBonus.ag * 1000));
        }
    }
    return result;
}

myVector<InterruptPacketData> RgEyeOfHorus::EnterFreeGame(std::string check) {
    m_nConvertedInFreeMode = 0;

    m_nFreeModeTotalSpin = 12;
    m_nFreeModeGoneSpin = 0;

    m_nFreeModeTotalBonus = {0, 0};
    m_bFreeMode = TRUE;

    myVector<InterruptPacketData> packets;
    if (check != "") {
        myVector<int> values = ParseCheckPoint(check, "F", 4);
        if (values.size() == 4) {
            m_nConvertedInFreeMode = AT(values, 0);
            m_nFreeModeTotalSpin = AT(values, 1);
            m_nFreeModeGoneSpin = AT(values, 2);
            m_nFreeModeTotalBonus.coin = AT(values, 3);

            UINT8 gone = (m_nFreeModeGoneSpin ? m_nFreeModeGoneSpin : 1);
            packets.push_back({
                0,
                0,
                {0x01, 0x02, 0x30, 0x00, 0x08, 0x1a, gone, 0x00, m_nFreeModeTotalSpin, 0x00, m_nConvertedInFreeMode, 0x00, 0x00, 0x00, 0xa3, 0x04} });
            return packets;
        }
    }
    else {
        updateCheckPoint();
    }
    packets.push_back({
        0,
        0,
        {
            0x01, 0x02, 0x30, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x0c, 0x00, 0x01, 0x00, 0x0c, 0x00, 0x00, 0x00, 0xa6, 0x04
        }
        });
    packets.push_back({
        0,
        0,
        {
            0x01, 0x02, 0x31, 0x00, 0x0a, 0x00, 0x25, 0x53, 0x11, 0x00, 0x01, 0x00, 0x01, 0x00, 0x00, 0x00, 0x03, 0x03, 0x00, 0x04
        }
        });
    packets.push_back({
       7000,
       0,
       {
           0x01, 0x02, 0x30, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa8, 0x04
       }
        });
    packets.push_back({
       0,
       0,
       {
           0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0xd0, 0x58, 0x01, 0x01, 0x04
       }
        });

    packets.push_back({
       1000,
       0,
       {
           0x01, 0x02, 0x30, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa8, 0x04
       }
        });
    packets.push_back({
      0,
      0,
      {
          0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0xd0, 0x58, 0x01, 0x01, 0x04
      }
        });

    packets.push_back({
      0,
      0,
      {
          0x01, 0x02, 0x30, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x01, 0x00, 0x0c, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa3, 0x04
      }
      });
    return packets;
}

myVector<InterruptPacketData> RgEyeOfHorus::InterruptBeforeSpin() {
    myVector<InterruptPacketData> packets;
    if (!m_bFreeMode) {
        return packets;
    }
    m_nFreeModeGoneSpin++;
    updateCheckPoint();

    UINT8 gone = (m_nFreeModeGoneSpin ? m_nFreeModeGoneSpin : 1);
    // display total & remain free spin count
    packets.push_back({
        0,
        0,
        {
            0x01, 0x02, 0x30, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), gone, 0x00, m_nFreeModeTotalSpin, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa5, 0x04
        }
        });
    return packets;
}


myVector<InterruptPacketData> RgEyeOfHorus::InterruptAfterMoveBonus(BOOL &EndFree) {
    myVector<InterruptPacketData> packets;

    UINT8 nWildCnt = Wildcount();
    UINT8 nScatterCnt = ScatterCount();

    if ((m_nFreeModeGoneSpin >= m_nFreeModeTotalSpin && nWildCnt == 0 && nScatterCnt < 3)) {
        ChangeReelStrip(myRandom() % 2);

        // exit Freegame
        packets.push_back({
            0,
            0,
            {
                0x01, 0x02, 0x30, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x00, 0x00, 
                static_cast<BYTE>(m_nFreeModeTotalBonus.coin & 0xFF), 
                static_cast<BYTE>((m_nFreeModeTotalBonus.coin >> 8) & 0xFF), 
                static_cast<BYTE>((m_nFreeModeTotalBonus.coin >> 16) & 0xFF),
                static_cast<BYTE>((m_nFreeModeTotalBonus.coin >> 24) & 0xFF),
                0x1c, 0x00, 0xab, 0x04
            }
            });
        packets.push_back({
            0,
            0,
            {
                0x01, 0x02, 0x30, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa4, 0x04
            }
            });
        // <-- show total bonus
        packets.push_back({
            1500,
            0,
            {
                0x01, 0x02, 0x30, 0x00, 0x08, 0x1a, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xac, 0x04
            }
            });
        packets.push_back({
            0,
            0,
            {
                0x01, 0x02, 0x35, 0x00, static_cast<BYTE>(SMP_GRa_Ban2 & 0xFF), static_cast<BYTE>((SMP_GRa_Ban2 >> 8) & 0xFF), 0x04
            }
            });
        packets.push_back({
            0,
            0,
            {
                0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0xd0, 0x58, 0x01, 0x01, 0x04
            }
            });
        packets.push_back({
            0,
            0,
            {
                0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0x25, 0x53, 0x85, 0x01, 0x04
            }
            });
        packets.push_back({
           0,
           0,
           {
                0x01, 0x02, 0x2f, 0x00, 0x41, 0x5a, 0x01, 0x04
           }
           });       

        EndFree = TRUE;
        m_bFreeMode = FALSE;

        updateCheckPoint();
        return packets;
    }

    EndFree = FALSE;

    //m_nFreeModeGoneSpin++;
    updateCheckPoint();

    if (nWildCnt == 0 && nScatterCnt < 3) {
        return packets;
    }

    UINT8 plusCnt = nWildCnt;
    if (nScatterCnt >= 3) {
        plusCnt += 12;
    }
    
    // show additional
    packets.push_back({
      1000,
      0,
      {
          0x01, 0x02, 0x30, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), plusCnt, 0x00, 0x01, 0x00, 0x0c, 0x00, 0x00, 0x00, 0xa6, 0x04
      }
        });
    m_nFreeModeTotalSpin += plusCnt;

    UINT16 deltaTime = (plusCnt > 5 ? 3500 : 2000);
    packets.push_back({
        deltaTime,
        0,
        {
            0x01, 0x02, 0x30, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa8, 0x04
        }
        });
    packets.push_back({
        0,
        0,
        {
            0x01, 0x02, 0x31, 0x00, 0x01, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x02, 0x00, 0x04
        }
        });
    packets.push_back({
        0,
        0,
        {
            0x01, 0x02, 0x31, 0x00, 0x00, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0xce, 0x04
        }
        });

    UINT8 nConvertable = EOH_convert_sorting.size() - m_nConvertedInFreeMode;
    UINT8 c = min(nConvertable, nWildCnt);

    deltaTime = 0;
    if (c > 0) {
        packets.push_back({
            3000,
            0,
            {
                0x01, 0x02, 0x31, 0x00, 0x01, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x02, 0x06, 0x04
            }
            });
        m_nConvertedInFreeMode += c;

        deltaTime += (c * 7000); // converting symbol ani
        ChangeReelStrip(8 + m_nConvertedInFreeMode);
    }
    packets.push_back({
        deltaTime,
        0,
        {
            0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0x25, 0x53, 0x85, 0x01, 0x04
        }
        });    

    return packets;
}

void RgEyeOfHorus::ChangeReelStrip(UINT16 NewReelPlan) {
    m_nCurrentReelPlan = NewReelPlan;
    m_shCurrentReelStrip = static_cast<uint16_t>(std::stoi(AT(m_vecReelStripPlan, m_nCurrentReelPlan)));
}

myVector<InterruptPacketData> RgEyeOfHorus::MousePressed(MousePosition p) {
    myVector<InterruptPacketData> packets;

    MousePosition a{
       {RgEyeOfHorus_MP_ChangeLine_LB_x_reel, RgEyeOfHorus_MP_ChangeLine_LB_x_pos },
       {RgEyeOfHorus_MP_ChangeLine_LB_y_row, RgEyeOfHorus_MP_ChangeLine_LB_y_pos }
    };
    MousePosition b{
        {RgEyeOfHorus_MP_ChangeLine_RT_x_reel, RgEyeOfHorus_MP_ChangeLine_RT_x_pos },
        {RgEyeOfHorus_MP_ChangeLine_RT_y_row, RgEyeOfHorus_MP_ChangeLine_RT_y_pos }
    };
    if (IsMouseWithin(p, a, b)) {
        m_nWinLine = (m_nWinLine == 5) ? 10 : 5;
        if (m_bPrevSpinMatchedActive) {
            // hide win lines
            packets.push_back({ 0, 0, {0x01, 0x02, 0x31, 0x00, 0x01, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x02, 0x00, 0x04} });
            m_bPrevSpinMatchedActive = FALSE;
        }
        UINT16 newBetValue = 0;
        if (m_nWinLine == 5) {
            m_Bonus = m_Bonus_05;
            m_vecBetSteps = m_vecBetSteps_05;
            newBetValue = AT(m_vecBetSteps_10, m_nBetStep) / 2;
            // lines
            packets.push_back({ 0, 0, {0x01, 0x02, 0x31, 0x00, 0x04, 0x00,
                static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x9d, 0x1f, 0x00, 0x00, 0x00, 0x04} });
        }
        else {
            m_Bonus = m_Bonus_10;
            m_vecBetSteps = m_vecBetSteps_10;
            newBetValue = AT(m_vecBetSteps_05, m_nBetStep) * 2;
            // lines
            packets.push_back({ 0, 0, {0x01, 0x02, 0x31, 0x00, 0x04, 0x00, static_cast<BYTE>(m_nGameID & 0xFF),
                static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x9d, 0xff, 0x03, 0x00, 0x00, 0x04} });
        }
        BOOL flag = FALSE;
        for (int i = 0; i < m_vecBetSteps.size(); i++) {
            if (AT(m_vecBetSteps, i) == newBetValue) {
                m_nBetStep = i;
                flag = TRUE;
                break;
            }
        }
        if (flag == FALSE) {
            m_nBetStep = 0;
        }
        // play button sound
        packets.push_back({ 0, 0, {0x01, 0x02, 0x34, 0x00, 0xf7, 0x00, 0x04} });
        // change line button
        packets.push_back({ 0, 0, {0x01, 0x02, 0x28, 0x00,
            static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), static_cast<BYTE>(m_nWinLine), 0x00, 0x00, 0x00, 0x04} });
        // set bet
        UINT16 bet = AT(m_vecBetSteps, m_nBetStep) / 5;
        packets.push_back({ 0, 0, {0x01, 0x02, 0x30, 0x00, 0x25, 0x53, 
            static_cast<BYTE>(bet & 0xFF), static_cast<BYTE>((bet >> 8) & 0xFF),
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04, 0x04} });
    }
    return packets;
}

myVector<UINT8> RgEyeOfHorus::ShowTotalWinLines(myVector<WinMeter> SpinMeters) {
    myVector<uint8_t> packet = {
        0x06, 0x30, 0x59, 0x01, 0x02, 0x31, 0x00,
        0x0F, 0x00,  // Placeholder for length 
        0x0F, 0x11, // GameID
        0x9C, 0x19, 0x01
    };
    myVector<UINT8> TotalMatch;
    for (int i = 0; i < SpinMeters.size(); i++) {
        if (AT(SpinMeters, i).line == 0xFF) { // clear after convert action
            TotalMatch.clear();
            continue;
        }
        TotalMatch.push_back(AT(SpinMeters, i).line);
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter >> 8) & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter2 & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter2 >> 8) & 0xFF));
    }
    if (TotalMatch.size() < 10) {
        myVector<UINT8> _;
        return _;
    }
    UINT16 pktLen = 1 + (TotalMatch.size() / 5) * 7;
    AT(packet, 7) = static_cast<BYTE>(pktLen & 0xFF);
    AT(packet, 8) = static_cast<BYTE>((pktLen >> 8) & 0xFF);
    AT(packet, 9) = static_cast<BYTE>(m_nGameID & 0xFF);
    AT(packet, 10) = static_cast<BYTE>((m_nGameID >> 8) & 0xFF);
    int entryCount = static_cast<int>(TotalMatch.size() / 5);
    for (int i = 0; i < entryCount; ++i) {
        packet.push_back(AT(TotalMatch, i * 5 + 0)); // Line
        packet.push_back(AT(TotalMatch, i * 5 + 1)); // Meter low byte
        packet.push_back(AT(TotalMatch, i * 5 + 2)); // Meter high byte
        packet.push_back(AT(TotalMatch, i * 5 + 3)); // Meter2 low byte
        packet.push_back(AT(TotalMatch, i * 5 + 4)); // Meter2 high byte
        packet.push_back(0x01);      // Status or flag 1
        packet.push_back(0x01);      // Status or flag 2
    }
    // Mark the end of the packet
    packet.back() = 0x04;
    return packet;
}

BOOL RgEyeOfHorus::SelectedableReelsInFreeGame(myVector<UINT8> result) {
    if (m_bFreeMode == FALSE) {
        return TRUE;
    }

    //in 72%, discard eye of horus symbol
    if (myRandom() % 100 < 72)
    {
        UINT8 n = 0;
        for (int i = 0; i < m_nReel; i++) {
            if (WildcountInCol(i, result)) {
                n++;
            }
        }

        if (n != 0)
            return FALSE;
    }

    myVector<UINT8> cp = m_vWinResult;
    m_vWinResult = result;
    int n = CardCount(RgEyeOfHorus_scatter);
    m_vWinResult = cp;
    if (n >= 3) {
        return FALSE;
    }
    return TRUE;
}

BOOL RgEyeOfHorus::NoFunInFreeMode() {
    return TRUE;
}

void RgEyeOfHorus::updateCheckPoint() {
    std::ostringstream oss;
    oss << " P" << m_nCurrentReelPlan
        << " B"
        << static_cast<int>(AT(m_vWinResult, 0)) << ":"
        << static_cast<int>(AT(m_vWinResult, 1)) << ":"
        << static_cast<int>(AT(m_vWinResult, 2)) << ":"
        << static_cast<int>(AT(m_vWinResult, 3)) << ":"
        << static_cast<int>(AT(m_vWinResult, 4)) << " ";

    if (m_bFreeMode) {
        oss << " F"
            << static_cast<int>(m_nConvertedInFreeMode) << ":"
            << static_cast<int>(m_nFreeModeTotalSpin) << ":"
            << static_cast<int>(m_nFreeModeGoneSpin) << ":"
            << static_cast<int>(m_nFreeModeTotalBonus.coin) << " ";
    }
    m_strCheckPoint = oss.str();
}