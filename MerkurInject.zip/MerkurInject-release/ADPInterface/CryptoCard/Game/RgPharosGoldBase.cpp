#include "stdafx.h"
#include "RgPharosGoldBase.h"


RgPharosGoldBase::RgPharosGoldBase() {
    m_bMultiGo = FALSE;
    m_nMultiGoBetStep = 0;
    m_nMultiGoTotalCount = 0;
    m_nMultiGoGone = 0;
    m_nMultiLoop = 0;

    m_strGameName = "RgLuckyPharaoh"; //RgPharosGoldBase

    m_vPSPlans.push_back(0);
    m_vPSPlans.push_back(0);
    m_vPSPlans.push_back(0);
    m_vPSPlans.push_back(0);

    m_nReel = 5;
    m_nWinLine = 10;
    m_nMaxMatch = 5;
    m_nBetStep = 0;

    myVector<UINT16> m_vecBetSteps_tmp;
    m_vecBetSteps_tmp.push_back(10);
    m_vecBetSteps_tmp.push_back(20);
    m_vecBetSteps_tmp.push_back(30);
    m_vecBetSteps_tmp.push_back(40);
    m_vecBetSteps_tmp.push_back(50);
    m_vecBetSteps_tmp.push_back(60);
    m_vecBetSteps_tmp.push_back(80);
    m_vecBetSteps_tmp.push_back(100);
    m_vecBetSteps_tmp.push_back(150);
    m_vecBetSteps_tmp.push_back(200);
#ifdef BIGBET_ACTIVE
    m_vecBetSteps_tmp.push_back(500);
    m_vecBetSteps_tmp.push_back(1000);
#endif
    LoadBets();

    m_vecSymbols.push_back("PHGOHigh1_");
    m_vecSymbols.push_back("PHGOHigh2_");
    m_vecSymbols.push_back("PHGOHigh3_");
    m_vecSymbols.push_back("PHGOHigh4_");
    m_vecSymbols.push_back("PHGOLow1__");
    m_vecSymbols.push_back("PHGOLow2__");
    m_vecSymbols.push_back("PHGOLow3__");
    m_vecSymbols.push_back("PHGOLow4__");
    m_vecSymbols.push_back("PHGOLow5__");

    m_mapSymbolMinMatch["PHGOHigh1_"] = 3;
    m_mapSymbolMinMatch["PHGOHigh2_"] = 3;
    m_mapSymbolMinMatch["PHGOHigh3_"] = 3;
    m_mapSymbolMinMatch["PHGOHigh4_"] = 3;
    m_mapSymbolMinMatch["PHGOLow1__"] = 3;
    m_mapSymbolMinMatch["PHGOLow2__"] = 3;
    m_mapSymbolMinMatch["PHGOLow3__"] = 3;
    m_mapSymbolMinMatch["PHGOLow4__"] = 3;
    m_mapSymbolMinMatch["PHGOLow5__"] = 3;

    m_mapSymbolMeterGoc["PHGOHigh1_"] = "PHGOHigh1_$x";
    m_mapSymbolMeterGoc["PHGOHigh2_"] = "PHGOHigh2_$x";
    m_mapSymbolMeterGoc["PHGOHigh3_"] = "PHGOHigh3_$x";
    m_mapSymbolMeterGoc["PHGOHigh4_"] = "PHGOHigh4_$x";
    m_mapSymbolMeterGoc["PHGOLow1__"] = "PHGOLow1_2_$x";
    m_mapSymbolMeterGoc["PHGOLow2__"] = "PHGOLow1_2_$x";
    m_mapSymbolMeterGoc["PHGOLow3__"] = "PHGOLow3_4_5_$x";
    m_mapSymbolMeterGoc["PHGOLow4__"] = "PHGOLow3_4_5_$x";
    m_mapSymbolMeterGoc["PHGOLow5__"] = "PHGOLow3_4_5_$x";

    m_vecWinLines.push_back("PHGOWinline1");
    m_vecWinLines.push_back("PHGOWinline2");
    m_vecWinLines.push_back("PHGOWinline3");
    m_vecWinLines.push_back("PHGOWinline4");
    m_vecWinLines.push_back("PHGOWinline5");
    m_vecWinLines.push_back("PHGOWinline6");
    m_vecWinLines.push_back("PHGOWinline7");
    m_vecWinLines.push_back("PHGOWinline8");
    m_vecWinLines.push_back("PHGOWinline9");
    m_vecWinLines.push_back("PHGOWinline10");

    m_vecReelStripPlan.push_back("0");
    
    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));

    char* phgoReelStrip[] = {
        "PHGOLow1__,PHGOLow1__,PHGOLow1__,PHGOLow1__,PHGOLow2__,PHGOLow2__,PHGOLow2__,PHGOHigh2_,PHGOHigh2_,PHGOHigh2_,PHGOLow4__,PHGOLow4__,PHGOLow4__,PHGOLow4__,PHGOLow4__,PHGOHigh4_,PHGOHigh4_,PHGOHigh4_,PHGOLow3__,PHGOLow3__,PHGOLow3__,PHGOLow3__,PHGOLow3__,PHGOHigh1_,PHGOHigh1_,PHGOHigh1_,PHGOHigh1_,PHGOLow5__,PHGOLow5__,PHGOLow5__,PHGOLow1__,PHGOLow1__,PHGOLow1__,PHGOLow1__,PHGOHigh3_,PHGOHigh3_,PHGOHigh3_,PHGOLow2__,PHGOLow2__,PHGOLow2__,PHGOLow4__,PHGOLow4__,PHGOLow4__,PHGOLow4__,PHGOLow4__,PHGOLow3__,PHGOLow3__,PHGOLow3__,PHGOLow3__,PHGOLow3__,PHGOLow5__,PHGOLow5__,PHGOLow5__,PHGOLow1__,PHGOLow1__,PHGOLow1__,PHGOLow1__,PHGOHigh2_,PHGOHigh2_,PHGOHigh2_,PHGOLow2__,PHGOLow2__,PHGOLow2__,PHGOHigh2_,PHGOHigh2_,PHGOHigh2_,PHGOLow4__,PHGOLow4__,PHGOLow4__,PHGOLow4__,PHGOLow4__,PHGOHigh1_,PHGOHigh1_,PHGOHigh1_,PHGOHigh1_,PHGOLow3__,PHGOLow3__,PHGOLow3__,PHGOLow3__,PHGOLow5__,PHGOLow5__,PHGOLow5__,PHGOHigh3_,PHGOHigh3_,PHGOHigh3_",
        "PHGOHigh4_,PHGOHigh4_,PHGOHigh4_,PHGOHigh4_,PHGOLow4__,PHGOLow4__,PHGOLow4__,PHGOLow4__,PHGOHigh1_,PHGOHigh1_,PHGOHigh1_,PHGOHigh1_,PHGOLow2__,PHGOLow2__,PHGOLow2__,PHGOLow2__,PHGOLow2__,PHGOHigh3_,PHGOHigh3_,PHGOHigh3_,PHGOLow5__,PHGOLow5__,PHGOLow5__,PHGOLow5__,PHGOLow3__,PHGOLow3__,PHGOLow3__,PHGOHigh3_,PHGOHigh3_,PHGOHigh3_,PHGOLow4__,PHGOLow4__,PHGOLow4__,PHGOLow4__,PHGOLow2__,PHGOLow2__,PHGOLow2__,PHGOLow2__,PHGOLow2__,PHGOHigh4_,PHGOHigh4_,PHGOHigh4_,PHGOHigh4_,PHGOLow5__,PHGOLow5__,PHGOLow5__,PHGOLow5__,PHGOHigh1_,PHGOHigh1_,PHGOHigh1_,PHGOHigh1_,PHGOLow3__,PHGOLow3__,PHGOLow3__,PHGOHigh4_,PHGOHigh4_,PHGOHigh4_,PHGOHigh4_,PHGOLow4__,PHGOLow4__,PHGOLow4__,PHGOLow4__,PHGOHigh2_,PHGOHigh2_,PHGOHigh2_,PHGOLow2__,PHGOLow2__,PHGOLow2__,PHGOLow2__,PHGOLow2__,PHGOHigh3_,PHGOHigh3_,PHGOHigh3_,PHGOLow5__,PHGOLow5__,PHGOLow5__,PHGOLow5__,PHGOLow1__,PHGOLow1__,PHGOLow1__,PHGOHigh2_,PHGOHigh2_,PHGOHigh2_,PHGOLow3__,PHGOLow3__,PHGOLow3__,PHGOLow3__,PHGOLow3__",
        "PHGOLow2__,PHGOLow2__,PHGOLow2__,PHGOHigh1_,PHGOHigh1_,PHGOHigh1_,PHGOHigh1_,PHGOLow1__,PHGOLow1__,PHGOLow1__,PHGOLow1__,PHGOHigh2_,PHGOHigh2_,PHGOHigh2_,PHGOLow5__,PHGOLow5__,PHGOLow5__,PHGOLow5__,PHGOLow4__,PHGOLow4__,PHGOLow4__,PHGOHigh4_,PHGOHigh4_,PHGOHigh4_,PHGOHigh4_,PHGOLow3__,PHGOLow3__,PHGOLow3__,PHGOLow2__,PHGOLow2__,PHGOLow2__,PHGOLow1__,PHGOLow1__,PHGOLow1__,PHGOLow1__,PHGOHigh2_,PHGOHigh2_,PHGOHigh2_,PHGOLow5__,PHGOLow5__,PHGOLow5__,PHGOLow5__,PHGOLow4__,PHGOLow4__,PHGOLow4__,PHGOHigh4_,PHGOHigh4_,PHGOHigh4_,PHGOHigh4_,PHGOLow3__,PHGOLow3__,PHGOLow3__,PHGOLow2__,PHGOLow2__,PHGOLow2__,PHGOHigh2_,PHGOHigh2_,PHGOHigh2_,PHGOLow1__,PHGOLow1__,PHGOLow1__,PHGOLow1__,PHGOHigh3_,PHGOHigh3_,PHGOHigh3_,PHGOLow5__,PHGOLow5__,PHGOLow5__,PHGOLow5__,PHGOHigh2_,PHGOHigh2_,PHGOHigh2_,PHGOLow4__,PHGOLow4__,PHGOLow4__,PHGOHigh4_,PHGOHigh4_,PHGOHigh4_,PHGOHigh4_,PHGOLow3__,PHGOLow3__,PHGOLow3__,PHGOHigh3_,PHGOHigh3_,PHGOHigh3_",
        "PHGOLow2__,PHGOLow2__,PHGOLow2__,PHGOHigh3_,PHGOHigh3_,PHGOHigh3_,PHGOLow3__,PHGOLow3__,PHGOLow3__,PHGOLow3__,PHGOLow5__,PHGOLow5__,PHGOLow5__,PHGOHigh1_,PHGOHigh1_,PHGOHigh1_,PHGOHigh1_,PHGOLow4__,PHGOLow4__,PHGOLow4__,PHGOLow4__,PHGOLow4__,PHGOHigh2_,PHGOHigh2_,PHGOHigh2_,PHGOLow1__,PHGOLow1__,PHGOLow1__,PHGOLow3__,PHGOLow3__,PHGOLow3__,PHGOHigh3_,PHGOHigh3_,PHGOHigh3_,PHGOLow2__,PHGOLow2__,PHGOLow2__,PHGOLow1__,PHGOLow1__,PHGOLow1__,PHGOLow1__,PHGOLow5__,PHGOLow5__,PHGOLow5__,PHGOLow4__,PHGOLow4__,PHGOLow4__,PHGOLow4__,PHGOLow4__,PHGOHigh4_,PHGOHigh4_,PHGOHigh4_,PHGOLow3__,PHGOLow3__,PHGOLow3__,PHGOHigh2_,PHGOHigh2_,PHGOHigh2_,PHGOLow2__,PHGOLow2__,PHGOLow2__,PHGOLow5__,PHGOLow5__,PHGOLow5__,PHGOHigh1_,PHGOHigh1_,PHGOHigh1_,PHGOHigh1_,PHGOLow1__,PHGOLow1__,PHGOLow1__,PHGOLow1__,PHGOLow4__,PHGOLow4__,PHGOLow4__,PHGOLow4__,PHGOLow4__,PHGOLow3__,PHGOLow3__,PHGOLow3__",
        "PHGOLow2__,PHGOLow2__,PHGOLow2__,PHGOLow2__,PHGOHigh1_,PHGOHigh1_,PHGOHigh1_,PHGOHigh1_,PHGOLow3__,PHGOLow3__,PHGOLow3__,PHGOLow3__,PHGOLow3__,PHGOHigh2_,PHGOHigh2_,PHGOHigh2_,PHGOLow1__,PHGOLow1__,PHGOLow1__,PHGOLow4__,PHGOLow4__,PHGOLow4__,PHGOLow4__,PHGOHigh4_,PHGOHigh4_,PHGOHigh4_,PHGOHigh4_,PHGOLow2__,PHGOLow2__,PHGOLow2__,PHGOLow2__,PHGOHigh3_,PHGOHigh3_,PHGOHigh3_,PHGOHigh3_,PHGOLow3__,PHGOLow3__,PHGOLow3__,PHGOLow3__,PHGOLow3__,PHGOHigh2_,PHGOHigh2_,PHGOHigh2_,PHGOLow4__,PHGOLow4__,PHGOLow4__,PHGOLow4__,PHGOLow5__,PHGOLow5__,PHGOLow5__,PHGOHigh4_,PHGOHigh4_,PHGOHigh4_,PHGOHigh4_,PHGOLow2__,PHGOLow2__,PHGOLow2__,PHGOLow2__,PHGOHigh3_,PHGOHigh3_,PHGOHigh3_,PHGOHigh3_,PHGOLow3__,PHGOLow3__,PHGOLow3__,PHGOLow3__,PHGOLow3__,PHGOLow4__,PHGOLow4__,PHGOLow4__,PHGOLow4__,PHGOHigh3_,PHGOHigh3_,PHGOHigh3_,PHGOHigh3_,PHGOLow5__,PHGOLow5__,PHGOLow5__,PHGOHigh4_,PHGOHigh4_,PHGOHigh4_,PHGOHigh4_,PHGOLow5__,PHGOLow5__,PHGOLow5__,PHGOHigh2_,PHGOHigh2_,PHGOHigh2_",
    };

    int idx = 0;
    for (int i = 0; i < m_vecReelStripPlan.size(); i++) {
        ReelSet set;
        for (int j = 0; j < m_nReel; j++) {
            ReelStrip strip;
            std::stringstream ss(phgoReelStrip[idx]);
            std::string item;
            while (std::getline(ss, item, ',')) {
                strip.push_back(item);
            }
            set.push_back(strip);
            idx++;
        }
        m_vecReelStripSets.push_back(set);
    }
  
    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_tmp;

    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        std::map<std::string, std::map<UINT8, BONUS>> perSym;
        std::map<UINT8, BONUS> e;
        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 500; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5000; e[5].ag = 0; // 0%
        perSym["PHGOHigh1_"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 70; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 200; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 400; e[5].ag = 0;
        perSym["PHGOHigh2_"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 300; e[5].ag = 0;
        perSym["PHGOHigh3_"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 300; e[5].ag = 0;
        perSym["PHGOHigh4_"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 200; e[5].ag = 0;
        perSym["PHGOLow1__"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 200; e[5].ag = 0;
        perSym["PHGOLow2__"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 30; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[5].ag = 0;
        perSym["PHGOLow3__"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 30; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[5].ag = 0;
        perSym["PHGOLow4__"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 30; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[5].ag = 0;
        perSym["PHGOLow5__"] = e;
        e.clear();

        m_Bonus_tmp[i] = perSym;
    }
    m_Bonus_tmp[2]["PHGOHigh1_"][5].coin = 0; m_Bonus_tmp[2]["PHGOHigh1_"][5].ag = 15;// 30
    m_Bonus_tmp[3]["PHGOHigh1_"][5].coin = 0; m_Bonus_tmp[3]["PHGOHigh1_"][5].ag = 20;// 40
    m_Bonus_tmp[4]["PHGOHigh1_"][5].coin = 0; m_Bonus_tmp[4]["PHGOHigh1_"][5].ag = 25;// 50
    m_Bonus_tmp[5]["PHGOHigh1_"][5].coin = 0; m_Bonus_tmp[5]["PHGOHigh1_"][5].ag = 30;// 60
    m_Bonus_tmp[6]["PHGOHigh1_"][5].coin = 0; m_Bonus_tmp[6]["PHGOHigh1_"][5].ag = 40;// 80
    m_Bonus_tmp[7]["PHGOHigh1_"][5].coin = 0; m_Bonus_tmp[7]["PHGOHigh1_"][5].ag = 50;// 100
    m_Bonus_tmp[8]["PHGOHigh1_"][5].coin = 0; m_Bonus_tmp[8]["PHGOHigh1_"][5].ag = 75;// 150
    m_Bonus_tmp[9]["PHGOHigh1_"][5].coin = 0; m_Bonus_tmp[9]["PHGOHigh1_"][5].ag = 100;// 200
    m_Bonus_tmp[10]["PHGOHigh1_"][5].coin = 0; m_Bonus_tmp[10]["PHGOHigh1_"][5].ag = 250;// 500
    m_Bonus_tmp[10]["PHGOHigh1_"][4].coin = 0; m_Bonus_tmp[10]["PHGOHigh1_"][4].ag = 25;
    m_Bonus_tmp[10]["PHGOHigh2_"][5].coin = 0; m_Bonus_tmp[10]["PHGOHigh2_"][5].ag = 20;
    m_Bonus_tmp[10]["PHGOHigh3_"][5].coin = 0; m_Bonus_tmp[10]["PHGOHigh3_"][5].ag = 15;
    m_Bonus_tmp[10]["PHGOHigh4_"][5].coin = 0; m_Bonus_tmp[10]["PHGOHigh4_"][5].ag = 15;
    m_Bonus_tmp[11]["PHGOHigh1_"][5].coin = 0; m_Bonus_tmp[11]["PHGOHigh1_"][5].ag = 500;// 1000
    m_Bonus_tmp[11]["PHGOHigh1_"][4].coin = 0; m_Bonus_tmp[11]["PHGOHigh1_"][4].ag = 50;
    m_Bonus_tmp[11]["PHGOHigh2_"][5].coin = 0; m_Bonus_tmp[11]["PHGOHigh2_"][5].ag = 40;
    m_Bonus_tmp[11]["PHGOHigh2_"][4].coin = 0; m_Bonus_tmp[11]["PHGOHigh2_"][4].ag = 20;
    m_Bonus_tmp[11]["PHGOHigh3_"][5].coin = 0; m_Bonus_tmp[11]["PHGOHigh3_"][5].ag = 30;
    m_Bonus_tmp[11]["PHGOHigh4_"][5].coin = 0; m_Bonus_tmp[11]["PHGOHigh4_"][5].ag = 30;
    m_Bonus_tmp[11]["PHGOLow1__"][5].coin = 0; m_Bonus_tmp[11]["PHGOLow1__"][5].ag = 20;
    m_Bonus_tmp[11]["PHGOLow2__"][5].coin = 0; m_Bonus_tmp[11]["PHGOLow2__"][5].ag = 20;

    int nSavedBetVal = 10;
    int _line = 0;
    string data;
    PlayDB::GetInstance().LoadCheckPoint(m_strGameName, nSavedBetVal, _line, m_strCheckPoint);
    if (nSavedBetVal == -1) {
        nSavedBetVal = 10;
    }

    BOOL start = FALSE;
    idx = 0;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_tmp, i) < AT(m_vecBetSteps, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps, idx) == nSavedBetVal) {
            m_nBetStep = idx;
        }

        m_Bonus[idx++] = m_Bonus_tmp[i];
        if (AT(m_vecBetSteps_tmp, i) == AT(m_vecBetSteps, m_vecBetSteps.size() - 1)) {
            break;
        }
    }

    m_vecBetSteps_05.clear();
    m_vecBetSteps_10.clear();
    PrintAllBonus();
}

UINT16 RgPharosGoldBase::Run() {
    m_nCurrentReelPlan = (myRandom() % m_vecReelStripPlan.size());
    m_shCurrentReelStrip = static_cast<uint16_t>(std::stoi(AT(m_vecReelStripPlan, m_nCurrentReelPlan)));
    return m_shCurrentReelStrip;
}

myVector<UINT8> RgPharosGoldBase::Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) {
    if (m_bMultiGo) {
        if (bTest == FALSE) {
            if (mmcode_get_active_status()) {
                mmcode_set_deactive();
            }
        }

        int selectedSub = myRandom() % 4;
        if (myRandom() & 1) {
            selectedSub = -1;
        }

        myVector<WinMeter> metersPS1;
        UINT64 normalMeterPS1;
        UINT64 maxMeterPS1;
        SoundItem bonusSoundItemPS;
        myVector<UINT8> resultPS1;
        normalMeterPS1 = 0;
        maxMeterPS1 = 0;
        bonusSoundItemPS = { 0, "", 0 };
        metersPS1.clear();
        if (_result.size()) {
            resultPS1.insert(resultPS1.end(), _result.begin() + 0, _result.begin() + 0 + 5);
        }
        BOOL _ = FALSE;
        resultPS1 = m_PS1.Win(metersPS1, normalMeterPS1, maxMeterPS1, bonusSoundItemPS, bTest, resultPS1, _, selectedSub == 0);

        myVector<WinMeter> metersPS2;
        UINT64 normalMeterPS2;
        UINT64 maxMeterPS2;
        myVector<UINT8> resultPS2;
        normalMeterPS2 = 0;
        maxMeterPS2 = 0;
        metersPS2.clear();
        if (_result.size()) {
            resultPS2.insert(resultPS2.end(), _result.begin() + 0 + 5, _result.begin() + 0 + 10);
        }
        resultPS2 = m_PS2.Win(metersPS2, normalMeterPS2, maxMeterPS2, bonusSoundItemPS, bTest, resultPS2, _, selectedSub == 1);

        myVector<WinMeter> metersPS3;
        UINT64 normalMeterPS3;
        UINT64 maxMeterPS3;
        myVector<UINT8> resultPS3;
        normalMeterPS3 = 0;
        maxMeterPS3 = 0;
        metersPS3.clear();
        if (_result.size()) {
            resultPS3.insert(resultPS3.end(), _result.begin() + 0 + 10, _result.begin() + 0 + 15);
        }
        resultPS3 = m_PS3.Win(metersPS3, normalMeterPS3, maxMeterPS3, bonusSoundItemPS, bTest, resultPS3, _, selectedSub == 2);

        myVector<WinMeter> metersPS4;
        UINT64 normalMeterPS4;
        UINT64 maxMeterPS4;
        myVector<UINT8> resultPS4;
        normalMeterPS4 = 0;
        maxMeterPS4 = 0;
        metersPS4.clear();
        if (_result.size()) {
            resultPS4.insert(resultPS4.end(), _result.begin() + 0 + 15, _result.begin() + 0 + 20);
        }
        resultPS4 = m_PS4.Win(metersPS4, normalMeterPS4, maxMeterPS4, bonusSoundItemPS, bTest, resultPS4, _, selectedSub == 3);

        _result.clear();
        _result.insert(_result.end(), resultPS1.begin(), resultPS1.end());
        _result.insert(_result.end(), resultPS2.begin(), resultPS2.end());
        _result.insert(_result.end(), resultPS3.begin(), resultPS3.end());
        _result.insert(_result.end(), resultPS4.begin(), resultPS4.end());

        normalMeter = 0;
        normalMeter = (normalMeterPS1 << 0) | (normalMeterPS2 << 16) | (normalMeterPS3 << 32) | (normalMeterPS4 << 48);

        maxMeter = 0;
        maxMeter = (maxMeterPS1 << 0) | (maxMeterPS2 << 16) | (maxMeterPS3 << 32) | (maxMeterPS4 << 48);

        meters.clear();
        meters.insert(meters.end(), metersPS1.begin(), metersPS1.end());
        meters.insert(meters.end(), metersPS2.begin(), metersPS2.end());
        meters.insert(meters.end(), metersPS3.begin(), metersPS3.end());
        meters.insert(meters.end(), metersPS4.begin(), metersPS4.end());

        if (bTest == FALSE) {
            UINT16 totalErfolg = 0;
            for (int i = 0; i < meters.size(); i++) {
                totalErfolg += AT(meters, i).bonus.coin;
            }
            BonusSound.duration = 0;
            BonusSound.soundID = MAX_SOUND_IDS;

            UINT16 trans1 = m_PS1.GetTransSymbolGOC();
            _result.push_back(trans1 & 0xFF);
            _result.push_back((trans1 >> 8) & 0xFF);
            _result.push_back(!trans1);

            UINT16 trans2 = m_PS2.GetTransSymbolGOC();
            _result.push_back(trans2 & 0xFF);
            _result.push_back((trans2 >> 8) & 0xFF);
            _result.push_back(!trans2);

            UINT16 trans3 = m_PS3.GetTransSymbolGOC();
            _result.push_back(trans3 & 0xFF);
            _result.push_back((trans3 >> 8) & 0xFF);
            _result.push_back(!trans3);

            UINT16 trans4 = m_PS4.GetTransSymbolGOC();
            _result.push_back(trans4 & 0xFF);
            _result.push_back((trans4 >> 8) & 0xFF);
            _result.push_back(!trans4);
        }
        return _result;
    }
    else {
        m_bPrevSpinMatchedActive = FALSE;

        myVector<UINT8> result;
        ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);

        BOOL mmcode = FALSE;
        if (bTest == FALSE) {
            mmcode = mmcode_get_active_status();
        }
        if (bTest == TRUE || mmcode == TRUE) {
            std::string matchSymbol = AT(m_vecSymbols, myRandom() % (m_vecSymbols.size() - 1));
            int line = (myRandom() % m_nWinLine);
            int weight = 1 + (myRandom() % 5);

            if (mmcode) {
                mmcode_set_deactive();
                weight = m_nMaxMatch;
#ifdef BIGBET_ACTIVE
                matchSymbol = "PHGOLow5__";
#else
                matchSymbol = "PHGOHigh4_";
#endif
            }
            for (int i = 0; i < m_nReel; i++) {
                ReelStrip reelStrip = AT(reelSet, i);
                int len = reelStrip.size() - 3;

                int valid_i[0x100];
                int valid_count = 0;
                for (int j = 0; j <= len; j++) {
                    if (weight > i) {
                        if (matchSymbol == AT(reelStrip, j + g_match_lines_RgPharosGoldBase[line][i])) {
                            valid_i[valid_count++] = j;
                        }
                    }
                    else {
                        if (matchSymbol != AT(reelStrip, j + g_match_lines_RgPharosGoldBase[line][i])) {
                            valid_i[valid_count++] = j;
                        }
                    }
                }
                if (valid_count > 0) {
                    int rand_index = myRandom() % valid_count;
                    int chosen_i = valid_i[rand_index];
                    result.push_back(chosen_i + 1);
                }
                else {
                    result.push_back((myRandom() % (len - 1)) + 1);
                }
            }
        }
        else {
            result = _result;
        }
        normalMeter = 0;
        maxMeter = 0;
        UINT32 totalBonus = 0;
        for (int i = 0; i < m_nWinLine; i++) {
            int j = 1;
            UINT16 meter = ((UINT16)1 << (2 - g_match_lines_RgPharosGoldBase[i][0]));
            std::string firstSymbol = AT(AT(reelSet, 0), AT(result, 0) - 1 + g_match_lines_RgPharosGoldBase[i][0]);
        int nMatched = 1;
        for (; j < m_nMaxMatch; j++) {
                std::string prev_symbol = AT(AT(reelSet, j - 1), AT(result, j - 1) - 1 + g_match_lines_RgPharosGoldBase[i][j - 1]);
                std::string cur_symbol = AT(AT(reelSet, j), AT(result, j) - 1 + g_match_lines_RgPharosGoldBase[i][j]);

                if (firstSymbol == cur_symbol) {
                    meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_RgPharosGoldBase[i][j]));
                    nMatched++;
                    continue;
                }
                if (j >= 3) {
                    break;
                }

                nMatched = 1;
                firstSymbol = cur_symbol;
                meter = ((UINT16)1 << (3 * j + 2 - g_match_lines_RgPharosGoldBase[i][j]));
            }
            if (nMatched < m_mapSymbolMinMatch[firstSymbol]) {
                continue;
            }

            // monitor 2 meter
            std::string meterStr = m_mapSymbolMeterGoc[firstSymbol];
            size_t pos = meterStr.find('$');
            if (pos != std::string::npos) {
                meterStr = meterStr.replace(pos, 1, std::to_string(nMatched));
            }

            WinMeter e;
            e.line = i;
            e.meter = meter;
            e.meter2 = g_GrafficObjList.Str2GOCID(meterStr);
            e.symbol = firstSymbol;
            e.weight = nMatched;
            e.start = 0;
            e.bonus = m_Bonus[BetStep()][firstSymbol][nMatched];
            e.sound = MAX_SOUND_IDS;

            totalBonus += e.bonus.coin;

            if (e.meter2 != -1) {
                meters.push_back(e);
            }
            if (nMatched == m_nMaxMatch) {
                maxMeter |= meter;
            }
            else {
                normalMeter |= meter;
            }
        }
        m_vWinMeters = meters;
        BonusSound.duration = 0;
        BonusSound.soundID = MAX_SOUND_IDS;
        if (bTest == FALSE) {
            m_vWinResult = result;
            updateCheckPoint();
            m_bPrevSpinMatchedActive = TRUE;
        }
        return result;
    }
}

UINT16 RgPharosGoldBase::GetTotalBonus() {
    UINT16 totalErfolg = 0;
    for (int i = 0; i < m_vWinMeters.size(); i++) {
        totalErfolg += AT(m_vWinMeters, i).bonus.coin;
    }
    return totalErfolg;
}

BOOL RgPharosGoldBase::CanMultiGo() {
    if (m_bMultiGo) {
        return FALSE;
    }
    auto totalErfolg = GetTotalBonus();
    UINT16 betErfolg = AT(Bets(), BetStep());
    return (totalErfolg >= 4 * betErfolg);
}

myVector<InterruptPacketData> RgPharosGoldBase::EnterMultiGo(UINT32 &bonusErfolg, BOOL bIitMultiBet) {
    auto totalErfolg = bonusErfolg;
    auto bets = Bets();

    m_bMultiGo = TRUE;
    if (bIitMultiBet) {
        m_nMultiGoBetStep = BetStep();
    }
    m_nMultiGoGone = 0;
    UINT16 erfolgLevel = 4 * AT(bets, m_nMultiGoBetStep);
    m_nMultiGoTotalCount = totalErfolg / erfolgLevel;

    myVector<InterruptPacketData> packets;

    // clear right matched lines
    packets.push_back({ 0, 0, {0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0xac, 0x38, 0x02, 0x00, 0x04} });
    // show popup
    packets.push_back({
        0,
        0,
        {0x01, 0x02, 0x31, 0x00, 0x0b, 0x00, 0xb1, 0x38, 0xce,
        static_cast<BYTE>(totalErfolg & 0xFF), static_cast<BYTE>((totalErfolg >> 8) & 0xFF),
        0x00, 0x00, m_nMultiGoTotalCount, 0x01, 0x01, 0x01,
        static_cast<BYTE>(erfolgLevel & 0xFF), static_cast<BYTE>((erfolgLevel >> 8) & 0xFF), 0x01, 0x04} });

    UINT16 betval = AT(bets, m_nMultiGoBetStep) / 5;
    // update right panel
    packets.push_back({ 0, 0, {0x01, 0x02, 0x28, 0x00, 0xac, 0x38, 0x04, 0x00, 
        static_cast<BYTE>(betval & 0xFF), static_cast<BYTE>((betval >> 8) & 0xFF),  0x04} });
    // play multigo background sound
    packets.push_back({ 0, 0, {0x01, 0x02, 0x28, 0x00, 0x30, 0x59, 0x3e, 0x0f, 0x00, 0x00, 0x04, 0x06, 0xac, 0x38} });

    bonusErfolg -= erfolgLevel * m_nMultiGoTotalCount;

    AT(m_vPSPlans, 0) = m_PS1.Init(m_nMultiGoBetStep);
    AT(m_vPSPlans, 1) = m_PS2.Init(m_nMultiGoBetStep);
    AT(m_vPSPlans, 2) = m_PS3.Init(m_nMultiGoBetStep);
    AT(m_vPSPlans, 3) = m_PS4.Init(m_nMultiGoBetStep);
    return packets;
}
myVector<InterruptPacketData> RgPharosGoldBase::CloseMultiGo(UINT32& bonusErfolg, BOOL force) {
    auto bets = Bets();
    UINT16 erfolgLevel = 4 * AT(bets, m_nMultiGoBetStep);
    if (force) {
        bonusErfolg += erfolgLevel * m_nMultiGoTotalCount;
    }

    m_bMultiGo = FALSE;
    m_nMultiLoop = 0;
    myVector<InterruptPacketData> packets;
   /* packets.push_back({
       0,
       0,{0x01, 0x02, 0x31, 0x00, 0x0b, 0x00, 0xb1, 0x38, 0xce, static_cast<BYTE>(bonusErfolg & 0xFF), static_cast<BYTE>((bonusErfolg >> 8) & 0xFF),
       0x00, 0x00, 0x01, 0x02, 0x01, m_nMultiGoTotalCount, static_cast<BYTE>(erfolgLevel & 0xFF), static_cast<BYTE>((erfolgLevel >> 8) & 0xFF), 0x00, 0x04} });*/
    packets.push_back({
       0,
       0,{0x01, 0x02, 0x2c, 0x00, 0x8a, 0x5a, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04} });
    packets.push_back({
       0,
       0,{0x01, 0x02, 0x28, 0x00, 0xac, 0x38, 0x04, 0x00, 0x02, 0x00, 0x04} });
    packets.push_back({
       0,
       0,{0x01, 0x02, 0x35, 0x00, 0x3e, 0x0f, 0x04} });
    /*packets.push_back({
       0,
       0,{0x01, 0x02, 0x2c, 0x00, 0x8a, 0x5a, 0x28, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04} });*/
    /*packets.push_back({
       0,
       0,{0x01, 0x02, 0x28, 0x00, 0xac, 0x38, 0x04, 0x00, 0x02, 0x00, 0x04} });*/
    packets.push_back({
       0,
       0,{0x06, 0x30, 0x59, 0x01, 0x02, 0x2c, 0x00, 0x8a, 0x5a, 0x28, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04} });
    packets.push_back({
       0,
       0,{0x01, 0x02, 0x28, 0x00, 0xac, 0x38, 0x02, 0x00, 0x00, 0x00, 0x04} });    
    packets.push_back({
       0,
       0,{0x06, 0xac, 0x38, 0x01, 0x02, 0x2c, 0x00, 0x8a, 0x5a, 0x28, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04} });
    
    UINT16 betval = AT(bets, BetStep()) / 5;
    // update right
    packets.push_back({ 0, 0, {0x01, 0x02, 0x28, 0x00, 0xac, 0x38, 0x04, 0x00, 
        static_cast<BYTE>(betval & 0xFF), static_cast<BYTE>((betval >> 8) & 0xFF), 
        0x04} });

    // update betval
    packets.push_back({
       0,
       0,{0x01, 0x02, 0x30, 0x00, 0x25, 0x53, 
       static_cast<BYTE>(betval & 0xFF), static_cast<BYTE>((betval >> 8) & 0xFF), 
       0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04, 0x04} });
    return packets;
}

myVector<InterruptPacketData> RgPharosGoldBase::BetUpMultiGo(UINT32& bonusErfolg) {
    myVector<InterruptPacketData> packets;
    auto bets = Bets();
    if (m_nMultiGoBetStep >= (bets.size() - 1)) {
        return packets;
    }
    UINT16 erfolgLevel = 4 * AT(bets, m_nMultiGoBetStep);
    // total bonus erfolg
    auto totalErfolg = bonusErfolg + erfolgLevel * m_nMultiGoTotalCount;
    if (totalErfolg < 4 * AT(bets, m_nMultiGoBetStep + 1)) {
        return packets;
    }
    m_nMultiGoBetStep++;
    erfolgLevel = 4 * AT(bets, m_nMultiGoBetStep);
    m_nMultiGoTotalCount = totalErfolg / erfolgLevel;
    bonusErfolg = totalErfolg - m_nMultiGoTotalCount * erfolgLevel;
    // PharosGoldPopUp: 0x38b1
    packets.push_back({
        0,
        0,
        {0x01, 0x02, 0x31, 0x00, 0x0b, 0x00, 0xb1, 0x38, 0xce,
        static_cast<BYTE>(totalErfolg & 0xFF), static_cast<BYTE>((totalErfolg >> 8) & 0xFF), 0x00, 0x00,
        m_nMultiGoTotalCount, 0x01, 0x01, 0x01,
        static_cast<BYTE>(erfolgLevel & 0xFF), static_cast<BYTE>((erfolgLevel >> 8) & 0xFF), 0x01, 0x04} });
    
    // update bet on only 2nd display
    UINT16 betval = AT(bets, m_nMultiGoBetStep) / 5;
    packets.push_back({ 0, 0, {0x01, 0x02, 0x28, 0x00, 0xac, 0x38, 0x04, 0x00, 
        static_cast<BYTE>(betval & 0xFF), static_cast<BYTE>((betval >> 8) & 0xFF), 0x04} });
    /*packets.push_back({
        0,
        0,
        {0x01, 0x02, 0x28, 0x00, 
        static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF),
        0x03, 0x00, betval, 0x00, 0x04} });*/

    AT(m_vPSPlans, 0) = m_PS1.Init(m_nMultiGoBetStep);
    AT(m_vPSPlans, 1) = m_PS2.Init(m_nMultiGoBetStep);
    AT(m_vPSPlans, 2) = m_PS3.Init(m_nMultiGoBetStep);
    AT(m_vPSPlans, 3) = m_PS4.Init(m_nMultiGoBetStep);
    return packets;
}

myVector<InterruptPacketData> RgPharosGoldBase::BetDownMultiGo(UINT32& bonusErfolg) {
    myVector<InterruptPacketData> packets;
    auto bets = Bets();
    if (m_nMultiGoBetStep == 0) {
        return packets;
    }
    UINT16 erfolgLevel = 4 * AT(bets, m_nMultiGoBetStep);
    // total bonus erfolg
    auto totalErfolg = bonusErfolg + erfolgLevel * m_nMultiGoTotalCount;
    m_nMultiGoBetStep--;
    erfolgLevel = 4 * AT(bets, m_nMultiGoBetStep);
    m_nMultiGoTotalCount = totalErfolg / erfolgLevel;
    bonusErfolg = totalErfolg - m_nMultiGoTotalCount * erfolgLevel;
    // PharosGoldPopUp: 0x38b1
    packets.push_back({
        0,
        0,
        {0x01, 0x02, 0x31, 0x00, 0x0b, 0x00, 0xb1, 0x38, 0xce,
        static_cast<BYTE>(totalErfolg & 0xFF), static_cast<BYTE>((totalErfolg >> 8) & 0xFF), 0x00, 0x00,
        m_nMultiGoTotalCount, 0x01, 0x01, 0x01,
        static_cast<BYTE>(erfolgLevel & 0xFF), static_cast<BYTE>((erfolgLevel >> 8) & 0xFF), 0x01, 0x04} });

    // update bet on only 2nd display
    UINT16 betval = AT(bets, m_nMultiGoBetStep) / 5;
    packets.push_back({ 0, 0, {0x01, 0x02, 0x28, 0x00, 0xac, 0x38, 0x04, 0x00, 
        static_cast<BYTE>(betval & 0xFF), static_cast<BYTE>((betval >> 8) & 0xFF), 0x04} });
    /*packets.push_back({
        0,
        0,
        {0x01, 0x02, 0x28, 0x00,
        static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF),
        0x03, 0x00, betval, 0x00, 0x04} });*/

    AT(m_vPSPlans, 0) = m_PS1.Init(m_nMultiGoBetStep);
    AT(m_vPSPlans, 1) = m_PS2.Init(m_nMultiGoBetStep);
    AT(m_vPSPlans, 2) = m_PS3.Init(m_nMultiGoBetStep);
    AT(m_vPSPlans, 3) = m_PS4.Init(m_nMultiGoBetStep);
    return packets;
}

myVector<UINT16> RgPharosGoldBase::CurrentReelStrip() {
    myVector<UINT16> ret;
    if (m_bMultiGo) {
        ret.push_back(GOC_RgPharosGold1);
        ret.push_back(AT(m_vPSPlans, 0));
        ret.push_back(GOC_RgPharosGold2);
        ret.push_back(AT(m_vPSPlans, 1));
        ret.push_back(GOC_RgPharosGold3);
        ret.push_back(AT(m_vPSPlans, 2));
        ret.push_back(GOC_RgPharosGold4);
        ret.push_back(AT(m_vPSPlans, 3));
    }
    else {
        ret.push_back(m_shCurrentReelStrip);
    }
    return ret;
}

void RgPharosGoldBase::MultiGoGoneAndRemain(UINT8& gone, UINT8& total, UINT8& loop) {
    gone = m_nMultiGoGone;
    total = m_nMultiGoTotalCount;
    loop = m_nMultiLoop;
}

myVector<InterruptPacketData> RgPharosGoldBase::InterruptBeforeSpin() {
    myVector<InterruptPacketData> packets;    
    if (m_bMultiGo) {
        m_nMultiGoGone++;
        UINT8 remain = m_nMultiGoTotalCount - m_nMultiGoGone;
        // dec remain spin numbers
        packets.push_back({ 0, 0,{0x01, 0x02, 0x30, 0x00, 0xAC, 0x38, remain, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa5, 0x04} });
    }
    return packets;
}

UINT16 RgPharosGoldBase::MiltiGoBet() {
    auto bets = Bets();
    return AT(bets, m_nMultiGoBetStep);
}

UINT8 RgPharosGoldBase::MultiGoBetStep() {
    return m_nMultiGoBetStep;
}

void RgPharosGoldBase::SetMultiGoBetStep(UINT8 newStep) {
    m_nMultiGoBetStep = newStep;

    m_PS1.SetBetStep(newStep);
    m_PS2.SetBetStep(newStep);
    m_PS3.SetBetStep(newStep);
    m_PS4.SetBetStep(newStep);
}

BOOL RgPharosGoldBase::GetMultiGoEnable() {
    return m_bMultiGo;
}

void RgPharosGoldBase::SetMultiGoEnable(BOOL status) {
    m_bMultiGo = status;
}

int RgPharosGoldBase::LineSwapDelay(int WinIdx) {
    return 500;
}

void RgPharosGoldBase::GetMultiGoReelPlanIdx(int& p0, int& p1, int& p2, int& p3) {
    p0 = m_PS1.CurrentReelSetIdx();
    p1 = m_PS2.CurrentReelSetIdx();
    p2 = m_PS3.CurrentReelSetIdx();
    p3 = m_PS4.CurrentReelSetIdx();
}

void RgPharosGoldBase::SetMultiGoReelPlanIdx(int p0, int p1, int p2, int p3) {
    m_PS1.ChangeReelStrip(p0);
    m_PS2.ChangeReelStrip(p1);
    m_PS3.ChangeReelStrip(p2);
    m_PS4.ChangeReelStrip(p3);

    AT(m_vPSPlans, 0) = AT(m_PS1.CurrentReelStrip(), 0);
    AT(m_vPSPlans, 1) = AT(m_PS2.CurrentReelStrip(), 0);
    AT(m_vPSPlans, 2) = AT(m_PS3.CurrentReelStrip(), 0);
    AT(m_vPSPlans, 3) = AT(m_PS4.CurrentReelStrip(), 0);
}

UINT16 RgPharosGoldBase::LineSound(UINT Line, std::string symbol, UINT8 weight) {
    std::map<std::string, UINT16> lineSounds;
    lineSounds["PHGOHigh1_"] = SMP_phgo_win_diamond;
    lineSounds["PHGOHigh2_"] = SMP_phgo_win_red_gem;
    lineSounds["PHGOHigh3_"] = SMP_phgo_win_blue_gem;
    lineSounds["PHGOHigh4_"] = SMP_phgo_win_green_gem;
    lineSounds["PHGOLow1__"] = SMP_phgo_win_ace;
    lineSounds["PHGOLow2__"] = SMP_phgo_win_king;
    lineSounds["PHGOLow3__"] = SMP_phgo_win_queen;
    lineSounds["PHGOLow4__"] = SMP_phgo_win_jack;
    lineSounds["PHGOLow5__"] = SMP_phgo_win_ten;

    auto it = lineSounds.find(symbol);
    if (it != lineSounds.end()) {
        return it->second;
    }
    else {
        return SMP_phgo_win_ten;
    }
}

myVector<UINT8> RgPharosGoldBase::ShowTotalWinLines(myVector<WinMeter> SpinMeters) {
    if (m_bMultiGo) {
        myVector<UINT8> empty;
        return empty;
    }
    myVector<uint8_t> packet = {
        0x06, 0x30, 0x59, 0x01, 0x02, 0x31, 0x00,
        0x0F, 0x00,  // Placeholder for length 
        0x0F, 0x11, // GameID
        0x9C, 0x19, 0x01
    };
    myVector<UINT8> TotalMatch;
    for (int i = 0; i < SpinMeters.size(); i++) {
        if (AT(SpinMeters, i).line == 0xFF) { // clear after convert action
            TotalMatch.clear();
            continue;
        }
        TotalMatch.push_back(AT(SpinMeters, i).line);
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter >> 8) & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter2 & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter2 >> 8) & 0xFF));
    }
    if (TotalMatch.size() < 10) {
        myVector<UINT8> _;
        return _;
    }
    UINT16 pktLen = 1 + (TotalMatch.size() / 5) * 7;
    AT(packet, 7) = static_cast<BYTE>(pktLen & 0xFF);
    AT(packet, 8) = static_cast<BYTE>((pktLen >> 8) & 0xFF);
    AT(packet, 9) = static_cast<BYTE>(m_nGameID & 0xFF);
    AT(packet, 10) = static_cast<BYTE>((m_nGameID >> 8) & 0xFF);
    int entryCount = static_cast<int>(TotalMatch.size() / 5);
    for (int i = 0; i < entryCount; ++i) {
        packet.push_back(AT(TotalMatch, i * 5 + 0)); // Line
        packet.push_back(AT(TotalMatch, i * 5 + 1)); // Meter low byte
        packet.push_back(AT(TotalMatch, i * 5 + 2)); // Meter high byte
        packet.push_back(AT(TotalMatch, i * 5 + 3)); // Meter2 low byte
        packet.push_back(AT(TotalMatch, i * 5 + 4)); // Meter2 high byte
        packet.push_back(0x01);      // Status or flag 1
        packet.push_back(0x01);      // Status or flag 2
    }
    // Mark the end of the packet
    packet.back() = 0x04;
    return packet;
}

myVector<InterruptPacketData> RgPharosGoldBase::InterruptAfterSpin() {
    if (m_bMultiGo == FALSE) {
        myVector<InterruptPacketData> _;
        return _;
    }
    myVector<InterruptPacketData> intPacket1 = m_PS1.InterruptAfterSpin();
    myVector<InterruptPacketData> intPacket2 = m_PS2.InterruptAfterSpin();
    myVector<InterruptPacketData> intPacket3 = m_PS3.InterruptAfterSpin();
    myVector<InterruptPacketData> intPacket4 = m_PS4.InterruptAfterSpin();

    myVector<InterruptPacketData> merged;
    if (!intPacket1.empty()) {
        merged.insert(merged.end(), intPacket1.begin(), intPacket1.end());
    }
    if (!intPacket2.empty()) {
        merged.insert(merged.end(), intPacket2.begin(), intPacket2.end());
    }
    if (!intPacket3.empty()) {
        merged.insert(merged.end(), intPacket3.begin(), intPacket3.end());
    }
    if (!intPacket4.empty()) {
        merged.insert(merged.end(), intPacket4.begin(), intPacket4.end());
    }
    if (merged.size()) {
        AT(merged, merged.size() - 1).postDelay = 2500;
    }
    return merged;
}

void RgPharosGoldBase::ChangeReelStrip(UINT16 NewReelPlan) {
    m_nCurrentReelPlan = (myRandom() % m_vecReelStripPlan.size());
    m_shCurrentReelStrip = static_cast<uint16_t>(std::stoi(AT(m_vecReelStripPlan, m_nCurrentReelPlan)));
}
