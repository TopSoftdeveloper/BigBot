#include "stdafx.h"
#include "RgTotemChiefPlus.h"

#define RgTotemChiefPlus_MP_ChangeLine_LB_x_reel   0x03
#define RgTotemChiefPlus_MP_ChangeLine_LB_x_pos    0x26
#define RgTotemChiefPlus_MP_ChangeLine_LB_y_row    0x02
#define RgTotemChiefPlus_MP_ChangeLine_LB_y_pos    0x16
#define RgTotemChiefPlus_MP_ChangeLine_RT_x_reel   0x03
#define RgTotemChiefPlus_MP_ChangeLine_RT_x_pos    0x62
#define RgTotemChiefPlus_MP_ChangeLine_RT_y_row    0x02
#define RgTotemChiefPlus_MP_ChangeLine_RT_y_pos    0x50

#define RgTotemChiefPlus_top "TCPL_CHIEF_"
RgTotemChiefPlus::RgTotemChiefPlus() {
    m_nReel = 5;
    m_nWinLine = 5;
    m_nMaxMatch = 5;
    m_nBetStep = 0;

    m_strGameName = "RgTotemChiefPlus";

    myVector<UINT16> m_vecBetSteps_05_tmp;
    myVector<UINT16> m_vecBetSteps_10_tmp;

    m_vecBetSteps_05_tmp.push_back(5);
    m_vecBetSteps_05_tmp.push_back(10);
    m_vecBetSteps_05_tmp.push_back(20);
    m_vecBetSteps_05_tmp.push_back(30);
    m_vecBetSteps_05_tmp.push_back(40);
    m_vecBetSteps_05_tmp.push_back(50);
    m_vecBetSteps_05_tmp.push_back(75);
    m_vecBetSteps_05_tmp.push_back(100);
    m_vecBetSteps_05_tmp.push_back(200);

    m_vecBetSteps_10_tmp.push_back(10);
    m_vecBetSteps_10_tmp.push_back(20);
    m_vecBetSteps_10_tmp.push_back(40);
    m_vecBetSteps_10_tmp.push_back(60);
    m_vecBetSteps_10_tmp.push_back(80);
    m_vecBetSteps_10_tmp.push_back(100);
    m_vecBetSteps_10_tmp.push_back(150);
    m_vecBetSteps_10_tmp.push_back(200);
    m_vecBetSteps_10_tmp.push_back(400);
#ifdef BIGBET_ACTIVE
    m_vecBetSteps_05_tmp.push_back(500);
    m_vecBetSteps_05_tmp.push_back(1000);
    m_vecBetSteps_10_tmp.push_back(1000);
    m_vecBetSteps_10_tmp.push_back(2000);
#endif
    LoadBets();

    m_vecBetSteps = m_vecBetSteps_05;

    m_vecSymbols.push_back("TCPL_CHIEF_");
    m_vecSymbols.push_back("TCPL_WOLF__");
    m_vecSymbols.push_back("TCPL_EAGLE_");
    m_vecSymbols.push_back("TCPL_HATCH_");
    m_vecSymbols.push_back("TCPL_HEAD__");
    m_vecSymbols.push_back("TCPL_A_____");
    m_vecSymbols.push_back("TCPL_K_____");
    m_vecSymbols.push_back("TCPL_Q_____");
    m_vecSymbols.push_back("TCPL_J_____");
    m_vecSymbols.push_back("TCPL_TEN___");

    m_vecSymbols.push_back("TCPL_POLEA_");
    m_vecSymbols.push_back("TCPL_POLEB_");
    m_vecSymbols.push_back("TCPL_POLEC_");

    m_mapSymbolMinMatch["TCPL_CHIEF_"] = 3;
    m_mapSymbolMinMatch["TCPL_WOLF__"] = 3;
    m_mapSymbolMinMatch["TCPL_EAGLE_"] = 3;
    m_mapSymbolMinMatch["TCPL_HATCH_"] = 3;
    m_mapSymbolMinMatch["TCPL_HEAD__"] = 3;
    m_mapSymbolMinMatch["TCPL_A_____"] = 3;
    m_mapSymbolMinMatch["TCPL_K_____"] = 3;
    m_mapSymbolMinMatch["TCPL_Q_____"] = 3;
    m_mapSymbolMinMatch["TCPL_J_____"] = 3;
    m_mapSymbolMinMatch["TCPL_TEN___"] = 3;

    m_mapSymbolMeterGoc["TCPL_CHIEF_"] = "tcplChief$x";
    m_mapSymbolMeterGoc["TCPL_WOLF__"] = "tcplEagWolf$x";
    m_mapSymbolMeterGoc["TCPL_EAGLE_"] = "tcplEagWolf$x";
    m_mapSymbolMeterGoc["TCPL_HATCH_"] = "tcplHatchHead$x";
    m_mapSymbolMeterGoc["TCPL_HEAD__"] = "tcplHatchHead$x";
    m_mapSymbolMeterGoc["TCPL_A_____"] = "tcplA_$x";
    m_mapSymbolMeterGoc["TCPL_K_____"] = "tcplKQ_$x";
    m_mapSymbolMeterGoc["TCPL_Q_____"] = "tcplKQ_$x";
    m_mapSymbolMeterGoc["TCPL_J_____"] = "tcplJ10_$x";
    m_mapSymbolMeterGoc["TCPL_TEN___"] = "tcplJ10_$x";

    m_vecWinLines.push_back("tcplWinline1");
    m_vecWinLines.push_back("tcplWinline2");
    m_vecWinLines.push_back("tcplWinline3");
    m_vecWinLines.push_back("tcplWinline4");
    m_vecWinLines.push_back("tcplWinline5");
    m_vecWinLines.push_back("tcplWinline6");
    m_vecWinLines.push_back("tcplWinline7");
    m_vecWinLines.push_back("tcplWinline8");
    m_vecWinLines.push_back("tcplWinline9");
    m_vecWinLines.push_back("tcplWinline10");

    m_vecLineSounds.push_back(SMP_TCPLWinStep1);
    m_vecLineSounds.push_back(SMP_TCPLWinStep2);
    m_vecLineSounds.push_back(SMP_TCPLWinStep3);
    m_vecLineSounds.push_back(SMP_TCPLWinStep4);
    m_vecLineSounds.push_back(SMP_TCPLWinStep5);
    m_vecLineSounds.push_back(SMP_TCPLWinStep6);
    m_vecLineSounds.push_back(SMP_TCPLWinStep7);
    m_vecLineSounds.push_back(SMP_TCPLWinStep8);
    m_vecLineSounds.push_back(SMP_TCPLWinStep9);
    m_vecLineSounds.push_back(SMP_TCPLWinStep10);

    m_vecWinSounds.push_back(SMP_TCPLWinTiny);
    m_vecWinSounds.push_back(SMP_TCPLWinMini);
    m_vecWinSounds.push_back(SMP_TCPLWinMinor);
    m_vecWinSounds.push_back(SMP_TCPLWinVSmall);
    m_vecWinSounds.push_back(SMP_TCPLWinSmall);
    m_vecWinSounds.push_back(SMP_TCPLWinMedium);
    m_vecWinSounds.push_back(SMP_TCPLWinBig);
    m_vecWinSounds.push_back(SMP_TCPLWinXLarge);
    m_vecWinSounds.push_back(SMP_TCPLWinHuge);
    m_vecWinSounds.push_back(SMP_TCPLWinMega);

    m_vecReelStripPlan.push_back("tcplWalze1AS");
    m_vecReelStripPlan.push_back("tcplWalze1BS");
    m_vecReelStripPlan.push_back("tcplWalze1A_DUM");
    m_vecReelStripPlan.push_back("tcplWalze1B_DUM");
    
    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));

    char* tcplReelStrip[] = {
        "TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_A_____,TCPL_A_____,TCPL_K_____,TCPL_K_____,TCPL_WOLF__,TCPL_K_____,TCPL_HEAD__,TCPL_HEAD__,TCPL_TEN___,TCPL_HEAD__,TCPL_TEN___,TCPL_TEN___,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_A_____,TCPL_EAGLE_,TCPL_A_____,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_A_____,TCPL_A_____,TCPL_K_____,TCPL_WOLF__,TCPL_WOLF__,TCPL_K_____,TCPL_HEAD__,TCPL_HEAD__,TCPL_J_____,TCPL_HEAD__,TCPL_J_____,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_A_____,TCPL_EAGLE_,TCPL_A_____,TCPL_TEN___,TCPL_TEN___,TCPL_TEN___,TCPL_HATCH_,TCPL_HATCH_,TCPL_Q_____,TCPL_HATCH_,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_J_____,TCPL_J_____,TCPL_EAGLE_,TCPL_J_____,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_WOLF__,TCPL_TEN___,TCPL_TEN___,TCPL_HEAD__,TCPL_TEN___,TCPL_HEAD__,TCPL_HEAD__,TCPL_TEN___,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____",
        "TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_A_____,TCPL_A_____,TCPL_Q_____,TCPL_Q_____,TCPL_WOLF__,TCPL_Q_____,TCPL_HATCH_,TCPL_HATCH_,TCPL_HATCH_,TCPL_Q_____,TCPL_Q_____,TCPL_TEN___,TCPL_TEN___,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_A_____,TCPL_EAGLE_,TCPL_A_____,TCPL_POLEC_,TCPL_POLEB_,TCPL_POLEA_,TCPL_K_____,TCPL_K_____,TCPL_K_____,TCPL_WOLF__,TCPL_WOLF__,TCPL_K_____,TCPL_WOLF__,TCPL_A_____,TCPL_A_____,TCPL_WOLF__,TCPL_WOLF__,TCPL_HATCH_,TCPL_HATCH_,TCPL_HATCH_,TCPL_TEN___,TCPL_TEN___,TCPL_TEN___,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_A_____,TCPL_EAGLE_,TCPL_A_____,TCPL_POLEC_,TCPL_POLEB_,TCPL_POLEA_,TCPL_J_____,TCPL_J_____,TCPL_J_____,TCPL_HATCH_,TCPL_J_____,TCPL_HATCH_,TCPL_HATCH_,TCPL_K_____,TCPL_K_____,TCPL_K_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_J_____,TCPL_J_____,TCPL_EAGLE_,TCPL_J_____,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_WOLF__,TCPL_WOLF__,TCPL_K_____,TCPL_K_____,TCPL_HEAD__,TCPL_K_____,TCPL_HEAD__,TCPL_HEAD__,TCPL_J_____,TCPL_J_____,TCPL_J_____",
        "TCPL_POLEC_,TCPL_POLEB_,TCPL_POLEA_,TCPL_A_____,TCPL_A_____,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____,TCPL_HATCH_,TCPL_HATCH_,TCPL_J_____,TCPL_J_____,TCPL_J_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____,TCPL_POLEC_,TCPL_POLEB_,TCPL_POLEA_,TCPL_K_____,TCPL_K_____,TCPL_A_____,TCPL_A_____,TCPL_A_____,TCPL_HATCH_,TCPL_HATCH_,TCPL_TEN___,TCPL_TEN___,TCPL_TEN___,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_WOLF__,TCPL_A_____,TCPL_A_____,TCPL_A_____,TCPL_POLEC_,TCPL_POLEB_,TCPL_POLEA_,TCPL_J_____,TCPL_J_____,TCPL_J_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_K_____,TCPL_K_____,TCPL_K_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_TEN___,TCPL_TEN___,TCPL_WOLF__,TCPL_TEN___,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_K_____,TCPL_K_____,TCPL_HEAD__,TCPL_K_____,TCPL_HEAD__,TCPL_HEAD__,TCPL_TEN___,TCPL_HEAD__,TCPL_TEN___,TCPL_J_____,TCPL_J_____",
        "TCPL_POLEC_,TCPL_POLEB_,TCPL_POLEA_,TCPL_A_____,TCPL_A_____,TCPL_Q_____,TCPL_Q_____,TCPL_WOLF__,TCPL_Q_____,TCPL_HEAD__,TCPL_HEAD__,TCPL_HEAD__,TCPL_J_____,TCPL_J_____,TCPL_J_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____,TCPL_POLEC_,TCPL_POLEB_,TCPL_POLEA_,TCPL_K_____,TCPL_K_____,TCPL_K_____,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____,TCPL_HATCH_,TCPL_Q_____,TCPL_HATCH_,TCPL_HATCH_,TCPL_A_____,TCPL_A_____,TCPL_A_____,TCPL_J_____,TCPL_J_____,TCPL_J_____,TCPL_EAGLE_,TCPL_J_____,TCPL_EAGLE_,TCPL_HATCH_,TCPL_HATCH_,TCPL_HATCH_,TCPL_TEN___,TCPL_TEN___,TCPL_TEN___,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_A_____,TCPL_A_____,TCPL_A_____,TCPL_WOLF__,TCPL_WOLF__,TCPL_WOLF__,TCPL_J_____,TCPL_J_____,TCPL_J_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_K_____,TCPL_K_____,TCPL_K_____,TCPL_CHIEF_,TCPL_K_____,TCPL_CHIEF_,TCPL_TEN___,TCPL_TEN___,TCPL_TEN___,TCPL_WOLF__,TCPL_TEN___,TCPL_WOLF__,TCPL_WOLF__,TCPL_WOLF__,TCPL_A_____,TCPL_A_____,TCPL_K_____,TCPL_K_____,TCPL_K_____,TCPL_HEAD__,TCPL_HEAD__,TCPL_TEN___,TCPL_HEAD__,TCPL_TEN___,TCPL_TEN___",
        "TCPL_A_____,TCPL_A_____,TCPL_Q_____,TCPL_WOLF__,TCPL_WOLF__,TCPL_Q_____,TCPL_HEAD__,TCPL_HEAD__,TCPL_HEAD__,TCPL_J_____,TCPL_J_____,TCPL_J_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____,TCPL_K_____,TCPL_K_____,TCPL_K_____,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____,TCPL_HATCH_,TCPL_HATCH_,TCPL_HATCH_,TCPL_A_____,TCPL_A_____,TCPL_A_____,TCPL_J_____,TCPL_J_____,TCPL_J_____,TCPL_EAGLE_,TCPL_J_____,TCPL_EAGLE_,TCPL_HATCH_,TCPL_HATCH_,TCPL_HATCH_,TCPL_TEN___,TCPL_TEN___,TCPL_TEN___,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_A_____,TCPL_A_____,TCPL_A_____,TCPL_WOLF__,TCPL_WOLF__,TCPL_WOLF__,TCPL_J_____,TCPL_J_____,TCPL_J_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_K_____,TCPL_K_____,TCPL_K_____,TCPL_CHIEF_,TCPL_K_____,TCPL_CHIEF_,TCPL_TEN___,TCPL_TEN___,TCPL_TEN___,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_WOLF__,TCPL_A_____,TCPL_A_____,TCPL_K_____,TCPL_K_____,TCPL_K_____,TCPL_HEAD__,TCPL_HEAD__,TCPL_HEAD__,TCPL_TEN___,TCPL_TEN___",

        "TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_A_____,TCPL_A_____,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____,TCPL_EAGLE_,TCPL_HATCH_,TCPL_HATCH_,TCPL_J_____,TCPL_HATCH_,TCPL_J_____,TCPL_J_____,TCPL_WOLF__,TCPL_WOLF__,TCPL_A_____,TCPL_WOLF__,TCPL_A_____,TCPL_K_____,TCPL_K_____,TCPL_K_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_A_____,TCPL_A_____,TCPL_Q_____,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_Q_____,TCPL_HATCH_,TCPL_HATCH_,TCPL_TEN___,TCPL_HATCH_,TCPL_TEN___,TCPL_WOLF__,TCPL_WOLF__,TCPL_A_____,TCPL_WOLF__,TCPL_A_____,TCPL_J_____,TCPL_J_____,TCPL_J_____,TCPL_HEAD__,TCPL_HEAD__,TCPL_K_____,TCPL_HEAD__,TCPL_K_____,TCPL_K_____,TCPL_K_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_TEN___,TCPL_TEN___,TCPL_WOLF__,TCPL_TEN___,TCPL_WOLF__,TCPL_WOLF__,TCPL_EAGLE_,TCPL_J_____,TCPL_J_____,TCPL_HATCH_,TCPL_J_____,TCPL_HATCH_,TCPL_HATCH_,TCPL_J_____,TCPL_K_____,TCPL_K_____,TCPL_K_____",
        "TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_A_____,TCPL_A_____,TCPL_K_____,TCPL_K_____,TCPL_EAGLE_,TCPL_K_____,TCPL_HEAD__,TCPL_HEAD__,TCPL_HEAD__,TCPL_K_____,TCPL_K_____,TCPL_J_____,TCPL_J_____,TCPL_WOLF__,TCPL_WOLF__,TCPL_A_____,TCPL_WOLF__,TCPL_A_____,TCPL_POLEC_,TCPL_POLEB_,TCPL_POLEA_,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_Q_____,TCPL_EAGLE_,TCPL_A_____,TCPL_A_____,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_HEAD__,TCPL_HEAD__,TCPL_HEAD__,TCPL_J_____,TCPL_J_____,TCPL_J_____,TCPL_WOLF__,TCPL_WOLF__,TCPL_A_____,TCPL_WOLF__,TCPL_A_____,TCPL_POLEC_,TCPL_POLEB_,TCPL_POLEA_,TCPL_TEN___,TCPL_TEN___,TCPL_TEN___,TCPL_HEAD__,TCPL_TEN___,TCPL_HEAD__,TCPL_HEAD__,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_TEN___,TCPL_TEN___,TCPL_WOLF__,TCPL_TEN___,TCPL_WOLF__,TCPL_WOLF__,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_Q_____,TCPL_Q_____,TCPL_HATCH_,TCPL_Q_____,TCPL_HATCH_,TCPL_HATCH_,TCPL_TEN___,TCPL_TEN___,TCPL_TEN___",
        "TCPL_POLEC_,TCPL_POLEB_,TCPL_POLEA_,TCPL_A_____,TCPL_A_____,TCPL_K_____,TCPL_K_____,TCPL_K_____,TCPL_HATCH_,TCPL_HATCH_,TCPL_J_____,TCPL_J_____,TCPL_J_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_K_____,TCPL_K_____,TCPL_K_____,TCPL_POLEC_,TCPL_POLEB_,TCPL_POLEA_,TCPL_Q_____,TCPL_Q_____,TCPL_A_____,TCPL_A_____,TCPL_A_____,TCPL_HATCH_,TCPL_HATCH_,TCPL_TEN___,TCPL_TEN___,TCPL_TEN___,TCPL_WOLF__,TCPL_WOLF__,TCPL_EAGLE_,TCPL_A_____,TCPL_A_____,TCPL_A_____,TCPL_POLEC_,TCPL_POLEB_,TCPL_POLEA_,TCPL_J_____,TCPL_J_____,TCPL_J_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_TEN___,TCPL_TEN___,TCPL_EAGLE_,TCPL_TEN___,TCPL_WOLF__,TCPL_WOLF__,TCPL_Q_____,TCPL_Q_____,TCPL_HEAD__,TCPL_Q_____,TCPL_HEAD__,TCPL_HEAD__,TCPL_TEN___,TCPL_HEAD__,TCPL_TEN___,TCPL_J_____,TCPL_J_____",
        "TCPL_POLEC_,TCPL_POLEB_,TCPL_POLEA_,TCPL_A_____,TCPL_A_____,TCPL_Q_____,TCPL_Q_____,TCPL_EAGLE_,TCPL_Q_____,TCPL_HEAD__,TCPL_HEAD__,TCPL_HEAD__,TCPL_J_____,TCPL_J_____,TCPL_J_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____,TCPL_POLEC_,TCPL_POLEB_,TCPL_POLEA_,TCPL_K_____,TCPL_K_____,TCPL_K_____,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____,TCPL_HATCH_,TCPL_Q_____,TCPL_HATCH_,TCPL_HATCH_,TCPL_A_____,TCPL_A_____,TCPL_A_____,TCPL_J_____,TCPL_J_____,TCPL_J_____,TCPL_WOLF__,TCPL_J_____,TCPL_WOLF__,TCPL_HATCH_,TCPL_HATCH_,TCPL_HATCH_,TCPL_TEN___,TCPL_TEN___,TCPL_TEN___,TCPL_WOLF__,TCPL_WOLF__,TCPL_A_____,TCPL_A_____,TCPL_A_____,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_J_____,TCPL_J_____,TCPL_J_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_K_____,TCPL_K_____,TCPL_K_____,TCPL_CHIEF_,TCPL_K_____,TCPL_CHIEF_,TCPL_TEN___,TCPL_TEN___,TCPL_TEN___,TCPL_EAGLE_,TCPL_TEN___,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_A_____,TCPL_A_____,TCPL_K_____,TCPL_K_____,TCPL_K_____,TCPL_HEAD__,TCPL_HEAD__,TCPL_TEN___,TCPL_HEAD__,TCPL_TEN___,TCPL_TEN___",
        "TCPL_A_____,TCPL_A_____,TCPL_K_____,TCPL_WOLF__,TCPL_WOLF__,TCPL_K_____,TCPL_HEAD__,TCPL_HEAD__,TCPL_HEAD__,TCPL_TEN___,TCPL_TEN___,TCPL_TEN___,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_TEN___,TCPL_TEN___,TCPL_TEN___,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____,TCPL_K_____,TCPL_K_____,TCPL_K_____,TCPL_HATCH_,TCPL_HATCH_,TCPL_HATCH_,TCPL_A_____,TCPL_A_____,TCPL_A_____,TCPL_TEN___,TCPL_TEN___,TCPL_TEN___,TCPL_EAGLE_,TCPL_TEN___,TCPL_EAGLE_,TCPL_HATCH_,TCPL_HATCH_,TCPL_HATCH_,TCPL_J_____,TCPL_J_____,TCPL_J_____,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_A_____,TCPL_A_____,TCPL_A_____,TCPL_WOLF__,TCPL_WOLF__,TCPL_WOLF__,TCPL_K_____,TCPL_K_____,TCPL_K_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____,TCPL_CHIEF_,TCPL_Q_____,TCPL_CHIEF_,TCPL_J_____,TCPL_J_____,TCPL_J_____,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_WOLF__,TCPL_A_____,TCPL_A_____,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____,TCPL_HEAD__,TCPL_HEAD__,TCPL_HEAD__,TCPL_J_____,TCPL_J_____",

        "TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_A_____,TCPL_A_____,TCPL_K_____,TCPL_K_____,TCPL_WOLF__,TCPL_K_____,TCPL_HEAD__,TCPL_HEAD__,TCPL_TEN___,TCPL_HEAD__,TCPL_TEN___,TCPL_TEN___,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_A_____,TCPL_EAGLE_,TCPL_A_____,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_A_____,TCPL_A_____,TCPL_K_____,TCPL_WOLF__,TCPL_WOLF__,TCPL_K_____,TCPL_HEAD__,TCPL_HEAD__,TCPL_J_____,TCPL_HEAD__,TCPL_J_____,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_J_____,TCPL_TEN___,TCPL_TEN___,TCPL_TEN___,TCPL_HATCH_,TCPL_HATCH_,TCPL_Q_____,TCPL_HATCH_,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____",
        "TCPL_POLEC_,TCPL_POLEB_,TCPL_POLEA_,TCPL_TEN___,TCPL_TEN___,TCPL_TEN___,TCPL_HEAD__,TCPL_TEN___,TCPL_HEAD__,TCPL_HEAD__,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_TEN___,TCPL_TEN___,TCPL_WOLF__,TCPL_TEN___,TCPL_WOLF__,TCPL_WOLF__,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_Q_____,TCPL_Q_____,TCPL_HATCH_,TCPL_Q_____,TCPL_HATCH_,TCPL_HATCH_,TCPL_TEN___,TCPL_TEN___,TCPL_TEN___,TCPL_K_____,TCPL_K_____,TCPL_POLEC_,TCPL_POLEB_,TCPL_POLEA_,TCPL_J_____,TCPL_J_____,TCPL_WOLF__,TCPL_WOLF__,TCPL_A_____,TCPL_WOLF__,TCPL_A_____,TCPL_POLEC_,TCPL_POLEB_,TCPL_POLEA_,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_Q_____,TCPL_EAGLE_,TCPL_A_____,TCPL_A_____,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_HEAD__,TCPL_HEAD__,TCPL_HEAD__,TCPL_J_____,TCPL_J_____,TCPL_J_____",
        "TCPL_POLEC_,TCPL_POLEB_,TCPL_POLEA_,TCPL_A_____,TCPL_A_____,TCPL_Q_____,TCPL_Q_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_K_____,TCPL_K_____,TCPL_K_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____,TCPL_POLEC_,TCPL_POLEB_,TCPL_POLEA_,TCPL_K_____,TCPL_K_____,TCPL_A_____,TCPL_A_____,TCPL_A_____,TCPL_HATCH_,TCPL_HATCH_,TCPL_TEN___,TCPL_TEN___,TCPL_TEN___,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_WOLF__,TCPL_A_____,TCPL_A_____,TCPL_A_____,TCPL_POLEC_,TCPL_POLEB_,TCPL_POLEA_,TCPL_J_____,TCPL_J_____,TCPL_J_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_K_____,TCPL_K_____,TCPL_K_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_TEN___,TCPL_TEN___,TCPL_EAGLE_,TCPL_TEN___,TCPL_WOLF__,TCPL_WOLF__,TCPL_Q_____,TCPL_Q_____,TCPL_HEAD__,TCPL_Q_____,TCPL_HEAD__,TCPL_HEAD__,TCPL_TEN___,TCPL_HEAD__,TCPL_TEN___",
        "TCPL_POLEC_,TCPL_POLEB_,TCPL_POLEA_,TCPL_A_____,TCPL_A_____,TCPL_Q_____,TCPL_Q_____,TCPL_WOLF__,TCPL_Q_____,TCPL_HATCH_,TCPL_HATCH_,TCPL_HATCH_,TCPL_TEN___,TCPL_TEN___,TCPL_TEN___,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_A_____,TCPL_A_____,TCPL_A_____,TCPL_WOLF__,TCPL_WOLF__,TCPL_WOLF__,TCPL_J_____,TCPL_J_____,TCPL_J_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_K_____,TCPL_K_____,TCPL_K_____,TCPL_CHIEF_,TCPL_K_____,TCPL_CHIEF_,TCPL_TEN___,TCPL_TEN___,TCPL_TEN___,TCPL_WOLF__,TCPL_TEN___,TCPL_WOLF__,TCPL_WOLF__,TCPL_WOLF__,TCPL_A_____,TCPL_A_____,TCPL_K_____,TCPL_K_____,TCPL_K_____,TCPL_HEAD__,TCPL_HEAD__,TCPL_TEN___,TCPL_HEAD__,TCPL_TEN___,TCPL_TEN___,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_J_____,TCPL_J_____,TCPL_J_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_K_____,TCPL_K_____,TCPL_K_____,TCPL_A_____,TCPL_A_____,TCPL_HEAD__,TCPL_HEAD__,TCPL_TEN___,TCPL_HEAD__,TCPL_TEN___,TCPL_TEN___",
        "TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____,TCPL_HEAD__,TCPL_HEAD__,TCPL_HEAD__,TCPL_J_____,TCPL_J_____,TCPL_J_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____,TCPL_K_____,TCPL_K_____,TCPL_K_____,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_A_____,TCPL_A_____,TCPL_A_____,TCPL_WOLF__,TCPL_WOLF__,TCPL_WOLF__,TCPL_K_____,TCPL_K_____,TCPL_K_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____,TCPL_CHIEF_,TCPL_Q_____,TCPL_CHIEF_,TCPL_J_____,TCPL_J_____,TCPL_J_____,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_WOLF__,TCPL_A_____,TCPL_A_____,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____,TCPL_HATCH_,TCPL_HATCH_,TCPL_HATCH_,TCPL_J_____,TCPL_J_____,TCPL_TEN___,TCPL_TEN___,TCPL_TEN___,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_WOLF__,TCPL_A_____,TCPL_A_____",

        "TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_A_____,TCPL_A_____,TCPL_K_____,TCPL_K_____,TCPL_WOLF__,TCPL_K_____,TCPL_HEAD__,TCPL_HEAD__,TCPL_TEN___,TCPL_HEAD__,TCPL_TEN___,TCPL_TEN___,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_A_____,TCPL_EAGLE_,TCPL_A_____,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_A_____,TCPL_A_____,TCPL_K_____,TCPL_WOLF__,TCPL_WOLF__,TCPL_K_____,TCPL_HEAD__,TCPL_HEAD__,TCPL_J_____,TCPL_HEAD__,TCPL_J_____,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_J_____,TCPL_TEN___,TCPL_TEN___,TCPL_TEN___,TCPL_HATCH_,TCPL_HATCH_,TCPL_Q_____,TCPL_HATCH_,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____",
        "TCPL_POLEC_,TCPL_POLEB_,TCPL_POLEA_,TCPL_TEN___,TCPL_TEN___,TCPL_TEN___,TCPL_HEAD__,TCPL_TEN___,TCPL_HEAD__,TCPL_HEAD__,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_TEN___,TCPL_TEN___,TCPL_WOLF__,TCPL_TEN___,TCPL_WOLF__,TCPL_WOLF__,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_Q_____,TCPL_Q_____,TCPL_HATCH_,TCPL_Q_____,TCPL_HATCH_,TCPL_HATCH_,TCPL_TEN___,TCPL_TEN___,TCPL_TEN___,TCPL_K_____,TCPL_K_____,TCPL_POLEC_,TCPL_POLEB_,TCPL_POLEA_,TCPL_J_____,TCPL_J_____,TCPL_WOLF__,TCPL_WOLF__,TCPL_A_____,TCPL_WOLF__,TCPL_A_____,TCPL_POLEC_,TCPL_POLEB_,TCPL_POLEA_,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_Q_____,TCPL_EAGLE_,TCPL_A_____,TCPL_A_____,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_HEAD__,TCPL_HEAD__,TCPL_HEAD__,TCPL_J_____,TCPL_J_____,TCPL_J_____",
        "TCPL_POLEC_,TCPL_POLEB_,TCPL_POLEA_,TCPL_A_____,TCPL_A_____,TCPL_Q_____,TCPL_Q_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_K_____,TCPL_K_____,TCPL_K_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____,TCPL_POLEC_,TCPL_POLEB_,TCPL_POLEA_,TCPL_K_____,TCPL_K_____,TCPL_A_____,TCPL_A_____,TCPL_A_____,TCPL_HATCH_,TCPL_HATCH_,TCPL_TEN___,TCPL_TEN___,TCPL_TEN___,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_WOLF__,TCPL_A_____,TCPL_A_____,TCPL_A_____,TCPL_POLEC_,TCPL_POLEB_,TCPL_POLEA_,TCPL_J_____,TCPL_J_____,TCPL_J_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_K_____,TCPL_K_____,TCPL_K_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_TEN___,TCPL_TEN___,TCPL_EAGLE_,TCPL_TEN___,TCPL_WOLF__,TCPL_WOLF__,TCPL_Q_____,TCPL_Q_____,TCPL_HEAD__,TCPL_Q_____,TCPL_HEAD__,TCPL_HEAD__,TCPL_TEN___,TCPL_HEAD__,TCPL_TEN___",
        "TCPL_POLEC_,TCPL_POLEB_,TCPL_POLEA_,TCPL_A_____,TCPL_A_____,TCPL_Q_____,TCPL_Q_____,TCPL_WOLF__,TCPL_Q_____,TCPL_HATCH_,TCPL_HATCH_,TCPL_HATCH_,TCPL_TEN___,TCPL_TEN___,TCPL_TEN___,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_A_____,TCPL_A_____,TCPL_A_____,TCPL_WOLF__,TCPL_WOLF__,TCPL_WOLF__,TCPL_J_____,TCPL_J_____,TCPL_J_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_K_____,TCPL_K_____,TCPL_K_____,TCPL_CHIEF_,TCPL_K_____,TCPL_CHIEF_,TCPL_TEN___,TCPL_TEN___,TCPL_TEN___,TCPL_WOLF__,TCPL_TEN___,TCPL_WOLF__,TCPL_WOLF__,TCPL_WOLF__,TCPL_A_____,TCPL_A_____,TCPL_K_____,TCPL_K_____,TCPL_K_____,TCPL_HEAD__,TCPL_HEAD__,TCPL_TEN___,TCPL_HEAD__,TCPL_TEN___,TCPL_TEN___,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_J_____,TCPL_J_____,TCPL_J_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_K_____,TCPL_K_____,TCPL_K_____,TCPL_A_____,TCPL_A_____,TCPL_HEAD__,TCPL_HEAD__,TCPL_TEN___,TCPL_HEAD__,TCPL_TEN___,TCPL_TEN___",
        "TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____,TCPL_HEAD__,TCPL_HEAD__,TCPL_HEAD__,TCPL_J_____,TCPL_J_____,TCPL_J_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____,TCPL_K_____,TCPL_K_____,TCPL_K_____,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_A_____,TCPL_A_____,TCPL_A_____,TCPL_WOLF__,TCPL_WOLF__,TCPL_WOLF__,TCPL_K_____,TCPL_K_____,TCPL_K_____,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_CHIEF_,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____,TCPL_CHIEF_,TCPL_Q_____,TCPL_CHIEF_,TCPL_J_____,TCPL_J_____,TCPL_J_____,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_WOLF__,TCPL_A_____,TCPL_A_____,TCPL_Q_____,TCPL_Q_____,TCPL_Q_____,TCPL_HATCH_,TCPL_HATCH_,TCPL_HATCH_,TCPL_J_____,TCPL_J_____,TCPL_TEN___,TCPL_TEN___,TCPL_TEN___,TCPL_EAGLE_,TCPL_EAGLE_,TCPL_WOLF__,TCPL_A_____,TCPL_A_____",
    };

    int idx = 0;
    for (int i = 0; i < m_vecReelStripPlan.size(); i++) {
        ReelSet set;
        for (int j = 0; j < m_nReel; j++) {
            ReelStrip strip;
            std::stringstream ss(tcplReelStrip[idx]);
            std::string item;
            while (std::getline(ss, item, ',')) {
                strip.push_back(item);
            }
            set.push_back(strip);
            idx++;
        }
        m_vecReelStripSets.push_back(set);
    }

    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_05_tmp;
    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_10_tmp;
    for (int i = 0; i < m_vecBetSteps_05_tmp.size(); i++) {
        std::map<std::string, std::map<UINT8, BONUS>> perSym;
        std::map<UINT8, BONUS> e;
        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[5].ag = 0;
        perSym["TCPL_TEN___"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[5].ag = 0;
        perSym["TCPL_J_____"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[5].ag = 0;
        perSym["TCPL_Q_____"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[5].ag = 0;
        perSym["TCPL_K_____"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[5].ag = 0;
        perSym["TCPL_A_____"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 15; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 50; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 250; e[5].ag = 0;
        perSym["TCPL_HEAD__"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 15; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 50; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 250; e[5].ag = 0;
        perSym["TCPL_HATCH_"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 500; e[5].ag = 0;
        perSym["TCPL_EAGLE_"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 500; e[5].ag = 0;
        perSym["TCPL_WOLF__"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 50; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 250; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 1000; e[5].ag = 0;
        perSym["TCPL_CHIEF_"] = e;
        e.clear();

        m_Bonus_05_tmp[i] = perSym;
    }
    m_Bonus_10_tmp = m_Bonus_05_tmp;

    m_Bonus_05_tmp[7]["TCPL_CHIEF_"][5].coin = 0; m_Bonus_05_tmp[7]["TCPL_CHIEF_"][5].ag = 20; // 100
    m_Bonus_05_tmp[8]["TCPL_CHIEF_"][5].coin = 0; m_Bonus_05_tmp[8]["TCPL_CHIEF_"][5].ag = 40; // 200
    m_Bonus_05_tmp[8]["TCPL_EAGLE_"][5].coin = 0; m_Bonus_05_tmp[8]["TCPL_EAGLE_"][5].ag = 20;
    m_Bonus_05_tmp[8]["TCPL_WOLF__"][5].coin = 0; m_Bonus_05_tmp[8]["TCPL_WOLF__"][5].ag = 20;

    m_Bonus_10_tmp[5]["TCPL_CHIEF_"][5].coin = 0; m_Bonus_10_tmp[5]["TCPL_CHIEF_"][5].ag = 10; // 100
    m_Bonus_10_tmp[6]["TCPL_CHIEF_"][5].coin = 0; m_Bonus_10_tmp[6]["TCPL_CHIEF_"][5].ag = 15; // 150
    m_Bonus_10_tmp[7]["TCPL_CHIEF_"][5].coin = 0; m_Bonus_10_tmp[7]["TCPL_CHIEF_"][5].ag = 20; // 200
    m_Bonus_10_tmp[7]["TCPL_EAGLE_"][5].coin = 0; m_Bonus_10_tmp[7]["TCPL_EAGLE_"][5].ag = 10;
    m_Bonus_10_tmp[7]["TCPL_WOLF__"][5].coin = 0; m_Bonus_10_tmp[7]["TCPL_WOLF__"][5].ag = 10;
    m_Bonus_10_tmp[8]["TCPL_CHIEF_"][5].coin = 0; m_Bonus_10_tmp[8]["TCPL_CHIEF_"][5].ag = 40; // 400
    m_Bonus_10_tmp[8]["TCPL_CHIEF_"][4].coin = 0; m_Bonus_10_tmp[8]["TCPL_CHIEF_"][4].ag = 10;
    m_Bonus_10_tmp[8]["TCPL_EAGLE_"][5].coin = 0; m_Bonus_10_tmp[8]["TCPL_EAGLE_"][5].ag = 20;
    m_Bonus_10_tmp[8]["TCPL_WOLF__"][5].coin = 0; m_Bonus_10_tmp[8]["TCPL_WOLF__"][5].ag = 20;
    m_Bonus_10_tmp[8]["TCPL_HEAD__"][5].coin = 0; m_Bonus_10_tmp[8]["TCPL_HEAD__"][5].ag = 10;
    m_Bonus_10_tmp[8]["TCPL_HATCH_"][5].coin = 0; m_Bonus_10_tmp[8]["TCPL_HATCH_"][5].ag = 10;

    int nSavedBetVal = 10;
    string data;
    PlayDB::GetInstance().LoadCheckPoint(m_strGameName, nSavedBetVal, m_nWinLine, m_strCheckPoint);
    if (nSavedBetVal == -1) {
        nSavedBetVal = 10;
    }
    if (m_nWinLine == -1) {
        m_nWinLine = 5;
    }

    BOOL start = FALSE;
    idx = 0;
    for (int i = 0; i < m_vecBetSteps_05_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_05_tmp, i) < AT(m_vecBetSteps_05, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps_05, idx) == nSavedBetVal && m_nWinLine == 5) {
            m_nBetStep = idx;
        }

        m_Bonus_05[idx++] = m_Bonus_05_tmp[i];
        if (AT(m_vecBetSteps_05_tmp, i) == AT(m_vecBetSteps_05, m_vecBetSteps_05.size() - 1)) {
            break;
        }
    }
    start = FALSE;
    idx = 0;
    for (int i = 0; i < m_vecBetSteps_10_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_10_tmp, i) < AT(m_vecBetSteps_10, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps_10, idx) == nSavedBetVal && m_nWinLine == 10) {
            m_nBetStep = idx;
        }

        m_Bonus_10[idx++] = m_Bonus_10_tmp[i];
        if (AT(m_vecBetSteps_10_tmp, i) == AT(m_vecBetSteps_10, m_vecBetSteps_10.size() - 1)) {
            break;
        }
    }
    m_Bonus = (m_nWinLine == 5 ? m_Bonus_05 : m_Bonus_10);
    m_vecBetSteps = (m_nWinLine == 5 ? m_vecBetSteps_05 : m_vecBetSteps_10);
    PrintAllBonus();
}

myVector<UINT8> RgTotemChiefPlus::Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) {
    m_nMagicCount = 0;
    m_bPrevSpinMatchedActive = FALSE;
    myVector<UINT8> result;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);

    BOOL mmcode = FALSE;
    if (bTest == FALSE) {
        mmcode = mmcode_get_active_status();
    }
    if (bTest == TRUE || mmcode == TRUE) {
        // avoid 3 wild cards;
        std::string matchSymbol = AT(m_vecSymbols, myRandom() % (m_vecSymbols.size() - 3));
        int line = (myRandom() % m_nWinLine);
        int weight = 1 + (myRandom() % 5);

        if (mmcode) {
            mmcode_set_deactive();
            weight = m_nMaxMatch;
            matchSymbol = RgTotemChiefPlus_top;
        }
        for (int i = 0; i < m_nReel; i++) {
            ReelStrip reelStrip = AT(reelSet, i);
            int len = reelStrip.size() - 3;

            int valid_i[0x100];
            int valid_count = 0;
            for (int j = 0; j <= len; j++) {
                if (weight > i) {
                    if (matchSymbol == AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                else {
                    if (matchSymbol != AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
            }
            if (valid_count > 0) {
                int rand_index = myRandom() % valid_count;
                int chosen_i = valid_i[rand_index];
                result.push_back(chosen_i + 1);
            }
            else {
                result.push_back((myRandom() % (len - 1)) + 1);
            }
        }
#ifdef TEST_WILD
        int testReel = 1 + (myRandom() % 3);
        ReelStrip reelStrip = AT(reelSet, testReel);
        for (int i = 0; i < reelStrip.size() - 2; i++) {
            if (AT(reelStrip, i) == "TCPL_POLEC_") {
                AT(result, testReel) = i + 1 + (myRandom() % 3);
                break;
            }
        }
#endif
    }
    else {
        result = _result;
    }

    normalMeter = 0;
    maxMeter = 0;
    BONUS totalBonus = {0, 0};
    for (int i = 0; i < m_nWinLine; i++) {
        int j = 1;
        UINT16 meter = ((UINT16)1 << (2 - g_match_lines_10_5[i][0]));
        std::string firstSymbol = AT(AT(reelSet, 0), AT(result, 0) - 1 + g_match_lines_10_5[i][0]);
        for (; j < m_nMaxMatch; j++) {
            std::string prev_symbol = AT(AT(reelSet, j - 1), AT(result, j - 1) - 1 + g_match_lines_10_5[i][j - 1]);
            std::string cur_symbol = AT(AT(reelSet, j), AT(result, j) - 1 + g_match_lines_10_5[i][j]);

            if (IsWild(firstSymbol)) {
                firstSymbol = cur_symbol;
            }

            if (firstSymbol == cur_symbol || IsWild(cur_symbol)) {
                meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
                continue;
            }
            break;
        }

        if (j < m_mapSymbolMinMatch[firstSymbol]) {
            continue;
        }
      
        // monitor 2 meter
        std::string meterStr = m_mapSymbolMeterGoc[firstSymbol];
        size_t pos = meterStr.find('$');
        if (pos != std::string::npos) {
            meterStr = meterStr.replace(pos, 1, std::to_string(j));
        }

        WinMeter e;
        e.line = i;
        e.meter = meter;
        e.meter2 = g_GrafficObjList.Str2GOCID(meterStr);
        e.symbol = firstSymbol;
        e.weight = j;
        e.start = 0;
        e.bonus = m_Bonus[BetStep()][firstSymbol][j];
        e.sound = MAX_SOUND_IDS;

        totalBonus.coin += e.bonus.coin;
        totalBonus.ag += e.bonus.ag;

        meters.push_back(e);
        if (j == m_nMaxMatch) {
            maxMeter |= meter;
        }
        else {
            normalMeter |= meter;
        }

        if (bTest == FALSE) {
            m_bPrevSpinMatchedActive = TRUE;
        }
    }
    m_nMagicCount = totalBonus.ag;
    if (bTest == FALSE) {
        m_vWinResult = result;
        updateCheckPoint();
    }
    if (totalBonus.coin > 0 || totalBonus.ag > 0) {
        BonusSound = getSoundByID(WinSound(totalBonus.coin + totalBonus.ag * 1000));
    }
    else {
        BonusSound.duration = 0;
        BonusSound.soundID = MAX_SOUND_IDS;
    }
    return result;
}

BOOL RgTotemChiefPlus::IsWild(std::string card) {
    if (card == "TCPL_POLEA_" ||
        card == "TCPL_POLEB_" ||
        card == "TCPL_POLEC_") {
        return TRUE;
    }
    return FALSE;
}

UINT16 RgTotemChiefPlus::SpinTime_MS() {
    return 2200;
}

int RgTotemChiefPlus::LineSwapDelay(int WinIdx) {
    return 700;
}

UINT16 RgTotemChiefPlus::MagicCount() {
    return m_nMagicCount;
}

myVector<InterruptPacketData> RgTotemChiefPlus::MousePressed(MousePosition p) {
    myVector<InterruptPacketData> packets;

    MousePosition a{
       {RgTotemChiefPlus_MP_ChangeLine_LB_x_reel, RgTotemChiefPlus_MP_ChangeLine_LB_x_pos },
       {RgTotemChiefPlus_MP_ChangeLine_LB_y_row, RgTotemChiefPlus_MP_ChangeLine_LB_y_pos }
    };
    MousePosition b{
        {RgTotemChiefPlus_MP_ChangeLine_RT_x_reel, RgTotemChiefPlus_MP_ChangeLine_RT_x_pos },
        {RgTotemChiefPlus_MP_ChangeLine_RT_y_row, RgTotemChiefPlus_MP_ChangeLine_RT_y_pos }
    };
    if (IsMouseWithin(p, a, b)) {
        m_nWinLine = (m_nWinLine == 5) ? 10 : 5;
        if (m_bPrevSpinMatchedActive) {
            // hide win lines
            packets.push_back({ 0, 0, {0x01, 0x02, 0x31, 0x00, 0x01, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x02, 0x00, 0x04} });
            m_bPrevSpinMatchedActive = FALSE;
        }
        UINT16 newBetValue = 0;
        if (m_nWinLine == 5) {
            m_Bonus = m_Bonus_05;
            m_vecBetSteps = m_vecBetSteps_05;
            newBetValue = AT(m_vecBetSteps_10, m_nBetStep) / 2;
            // lines
            packets.push_back({ 0, 0, {0x01, 0x02, 0x31, 0x00, 0x04, 0x00,
                static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x9d, 0x1f, 0x00, 0x00, 0x00, 0x04} });
        }
        else {
            m_Bonus = m_Bonus_10;
            m_vecBetSteps = m_vecBetSteps_10;
            newBetValue = AT(m_vecBetSteps_05, m_nBetStep) * 2;
            // lines
            packets.push_back({ 0, 0, {0x01, 0x02, 0x31, 0x00, 0x04, 0x00, static_cast<BYTE>(m_nGameID & 0xFF),
                static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x9d, 0xff, 0x03, 0x00, 0x00, 0x04} });
        }
        BOOL flag = FALSE;
        for (int i = 0; i < m_vecBetSteps.size(); i++) {
            if (AT(m_vecBetSteps, i) == newBetValue) {
                m_nBetStep = i;
                flag = TRUE;
                break;
            }
        }
        if (flag == FALSE) {
            m_nBetStep = 0;
        }
        // play button sound
        packets.push_back({ 0, 0, {0x01, 0x02, 0x34, 0x00, 0xf7, 0x00, 0x04} });
        // change line button
        packets.push_back({ 0, 0, {0x01, 0x02, 0x28, 0x00,
            static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), static_cast<BYTE>(m_nWinLine), 0x00, 0x00, 0x00, 0x04} });
        // set bet
        UINT16 bet = AT(m_vecBetSteps, m_nBetStep) / 5;
        packets.push_back({ 0, 0, {0x01, 0x02, 0x30, 0x00, 0x25, 0x53, 
            static_cast<BYTE>(bet & 0xFF), static_cast<BYTE>((bet >> 8) & 0xFF), 
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04, 0x04} });
    }
    return packets;
}

myVector<UINT8> RgTotemChiefPlus::ShowTotalWinLines(myVector<WinMeter> SpinMeters) {
    myVector<uint8_t> packet = {
        0x06, 0x30, 0x59, 0x01, 0x02, 0x31, 0x00,
        0x0F, 0x00,  // Placeholder for length 
        0x0F, 0x11, // GameID
        0x9C, 0x19, 0x01
    };
    myVector<UINT8> TotalMatch;
    for (int i = 0; i < SpinMeters.size(); i++) {
        if (AT(SpinMeters, i).line == 0xFF) { // clear after convert action
            TotalMatch.clear();
            continue;
        }
        TotalMatch.push_back(AT(SpinMeters, i).line);
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter >> 8) & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter2 & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter2 >> 8) & 0xFF));
    }
    if (TotalMatch.size() < 10) {
        myVector<UINT8> _;
        return _;
    }
    UINT16 pktLen = 1 + (TotalMatch.size() / 5) * 7;
    AT(packet, 7) = static_cast<BYTE>(pktLen & 0xFF);
    AT(packet, 8) = static_cast<BYTE>((pktLen >> 8) & 0xFF);
    AT(packet, 9) = static_cast<BYTE>(m_nGameID & 0xFF);
    AT(packet, 10) = static_cast<BYTE>((m_nGameID >> 8) & 0xFF);
    int entryCount = static_cast<int>(TotalMatch.size() / 5);
    for (int i = 0; i < entryCount; ++i) {
        packet.push_back(AT(TotalMatch, i * 5 + 0)); // Line
        packet.push_back(AT(TotalMatch, i * 5 + 1)); // Meter low byte
        packet.push_back(AT(TotalMatch, i * 5 + 2)); // Meter high byte
        packet.push_back(AT(TotalMatch, i * 5 + 3)); // Meter2 low byte
        packet.push_back(AT(TotalMatch, i * 5 + 4)); // Meter2 high byte
        packet.push_back(0x01);      // Status or flag 1
        packet.push_back(0x01);      // Status or flag 2
    }
    // Mark the end of the packet
    packet.back() = 0x04;
    return packet;
}
