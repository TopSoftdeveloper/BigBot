#pragma once

#include "ReelGame.h"

class RgTotemChiefPlus : public ReelGame
{
public:
	RgTotemChiefPlus::RgTotemChiefPlus();
	BOOL IsWild(std::string card);

	myVector<UINT8> Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& WinSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) override;
	UINT16 SpinTime_MS() override;
	int LineSwapDelay(int WinIdx) override;
	UINT16 MagicCount() override;

	myVector<InterruptPacketData> MousePressed(MousePosition p) override;
	myVector<UINT8> ShowTotalWinLines(myVector<WinMeter> SpinMeters) override;
};
