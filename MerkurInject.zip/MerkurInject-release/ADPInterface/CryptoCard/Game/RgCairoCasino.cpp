#include "stdafx.h"
#include "RgCairoCasino.h"
#include <set>

// in freemode, win must not be matched
int g_match_cairo[10][4] = {
    {1,     2,  3,  4},
    {13,    14, 15, 16},
    {5,     6,  7,  8},
    {9,     10, 11, 12},
    {1,     5,  9,  13},
    {4,     8,  12, 16},
    {2,     6,  10, 14},
    {3,     7,  11, 15},
    {1,     6,  11, 16},
    {13,    10, 7,  4},
};

#define RgCairoCasino_scatter "cacascattr"

RgCairoCasino::RgCairoCasino() {
    m_nReel = 4;
    m_nWinLine = 10;
    m_nMaxMatch = 4;
    m_nBetStep = 0;

    m_strGameName = "RgCairoCasino";

    m_bFreeMode = FALSE;
    m_bFreeModePenddingFinish = FALSE;
    
    myVector<UINT16> m_vecBetSteps_tmp;
    m_vecBetSteps_tmp.push_back(10);
    m_vecBetSteps_tmp.push_back(20);
    m_vecBetSteps_tmp.push_back(30);
    m_vecBetSteps_tmp.push_back(40);
    m_vecBetSteps_tmp.push_back(50);
    m_vecBetSteps_tmp.push_back(60);
    m_vecBetSteps_tmp.push_back(80);
    m_vecBetSteps_tmp.push_back(100);
    m_vecBetSteps_tmp.push_back(150);
    m_vecBetSteps_tmp.push_back(200);
#ifdef BIGBET_ACTIVE
    m_vecBetSteps_tmp.push_back(500);
#endif
    LoadBets();

    m_nBetOffset = 0;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        if (AT(m_vecBetSteps_tmp, i) < AT(m_vecBetSteps, 0)) {
            m_nBetOffset++;
            continue;
        }
        break;
    }

    m_vecSymbols.push_back("cacaHigh_1");
    m_vecSymbols.push_back("cacaHigh_2");
    m_vecSymbols.push_back("cacaHigh_3");
    m_vecSymbols.push_back("caca_low_1");
    m_vecSymbols.push_back("caca_low_2");
    m_vecSymbols.push_back("caca_low_3");
    m_vecSymbols.push_back("caca_low_4");
    m_vecSymbols.push_back("cacascattr");

    m_mapSymbolMeterGoc["cacaHigh_1"] = "cacaSpades4x";
    m_mapSymbolMeterGoc["cacaHigh_2"] = "cacaHeart4x";
    m_mapSymbolMeterGoc["cacaHigh_3"] = "caca3Dices4x";
    m_mapSymbolMeterGoc["caca_SpHeMix"] = "cacaSpHeMix4x";
    m_mapSymbolMeterGoc["caca_low_1"] = "caca2Dices4x";
    m_mapSymbolMeterGoc["caca_low_2"] = "cacaJeton4x";
    m_mapSymbolMeterGoc["caca_low_3"] = "caca1Dice4x";
    m_mapSymbolMeterGoc["caca_low_4"] = "cacaHorseShoe4x";
    m_mapSymbolMeterGoc["caca_DiceMix"] = "cacaDiceMix4x";

    m_vecWinLines.push_back("cacaWinline1");
    m_vecWinLines.push_back("cacaWinline2");
    m_vecWinLines.push_back("cacaWinline3");
    m_vecWinLines.push_back("cacaWinline4");
    m_vecWinLines.push_back("cacaWinline5");
    m_vecWinLines.push_back("cacaWinline6");
    m_vecWinLines.push_back("cacaWinline7");
    m_vecWinLines.push_back("cacaWinline8");
    m_vecWinLines.push_back("cacaWinline9");
    m_vecWinLines.push_back("cacaWinline10");
    m_vecWinLines.push_back("cacaWinlineScat");

    m_vecLineSounds.push_back(SMP_CACA_reelstop);
    m_vecWinSounds.push_back(SMP_CACA_mix);
    
    m_vecReelStripPlan.push_back("0");
    m_vecReelStripPlan.push_back("1");
    
    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));

    char* cacaReelStrip[] = {
        /* cacaW1_01   */ "cacaHigh_1,cacaHigh_2,cacaHigh_2,cacaHigh_3,cacaHigh_3,caca_low_1,caca_low_1,caca_low_1,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,cacascattr,cacascattr,cacascattr",
        /* cacaW2_01   */ "cacaHigh_1,cacaHigh_2,cacaHigh_2,cacaHigh_3,cacaHigh_3,cacaHigh_3,caca_low_1,caca_low_1,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_4,caca_low_4,caca_low_4,cacascattr,cacascattr,cacascattr,cacascattr",
        /* cacaW3_01   */ "cacaHigh_1,cacaHigh_2,cacaHigh_3,cacaHigh_3,caca_low_1,caca_low_1,caca_low_1,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_4,caca_low_4,caca_low_4,caca_low_4,cacascattr,cacascattr,cacascattr",
        /* cacaW4_01   */ "cacaHigh_1,cacaHigh_2,cacaHigh_3,cacaHigh_3,caca_low_1,caca_low_1,caca_low_1,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_3,caca_low_3,caca_low_3,caca_low_4,caca_low_4,caca_low_4,caca_low_4,cacascattr,cacascattr,cacascattr",
        /* cacaW5_01   */ "cacaHigh_1,cacaHigh_2,cacaHigh_2,cacaHigh_3,cacaHigh_3,caca_low_1,caca_low_1,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,cacascattr,cacascattr,cacascattr",
        /* cacaW6_01   */ "cacaHigh_1,cacaHigh_1,cacaHigh_2,cacaHigh_3,cacaHigh_3,caca_low_1,caca_low_1,caca_low_1,caca_low_1,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,cacascattr,cacascattr,cacascattr",
        /* cacaW7_01   */ "cacaHigh_1,cacaHigh_2,cacaHigh_2,cacaHigh_3,caca_low_1,caca_low_1,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,cacascattr,cacascattr",
        /* cacaW8_01   */ "cacaHigh_1,cacaHigh_2,cacaHigh_3,cacaHigh_3,caca_low_1,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_4,caca_low_4,caca_low_4,caca_low_4,cacascattr,cacascattr,cacascattr,cacascattr",
        /* cacaW9_01   */ "cacaHigh_1,cacaHigh_2,cacaHigh_2,cacaHigh_3,caca_low_1,caca_low_1,caca_low_1,caca_low_1,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,cacascattr,cacascattr,cacascattr",
        /* cacaW10_01  */ "cacaHigh_1,cacaHigh_2,cacaHigh_2,cacaHigh_3,caca_low_1,caca_low_1,caca_low_1,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_4,caca_low_4,caca_low_4,caca_low_4,cacascattr,cacascattr,cacascattr",
        /* cacaW11_01  */ "cacaHigh_1,cacaHigh_1,cacaHigh_2,cacaHigh_3,cacaHigh_3,caca_low_1,caca_low_1,caca_low_1,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,cacascattr,cacascattr",
        /* cacaW12_01  */ "cacaHigh_1,cacaHigh_2,cacaHigh_2,cacaHigh_3,cacaHigh_3,caca_low_1,caca_low_1,caca_low_1,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_3,caca_low_3,caca_low_3,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,cacascattr,cacascattr",
        /* cacaW13_01  */ "cacaHigh_1,cacaHigh_2,cacaHigh_2,cacaHigh_3,cacaHigh_3,caca_low_1,caca_low_1,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,cacascattr,cacascattr",
        /* cacaW14_01  */ "cacaHigh_1,cacaHigh_2,cacaHigh_2,cacaHigh_3,cacaHigh_3,caca_low_1,caca_low_1,caca_low_1,caca_low_1,caca_low_2,caca_low_2,caca_low_2,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,cacascattr,cacascattr,cacascattr,cacascattr",
        /* cacaW15_01  */ "cacaHigh_1,cacaHigh_2,cacaHigh_2,cacaHigh_3,cacaHigh_3,cacaHigh_3,caca_low_1,caca_low_1,caca_low_2,caca_low_2,caca_low_3,caca_low_3,caca_low_3,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,cacascattr,cacascattr",
        /* cacaW16_01  */ "cacaHigh_1,cacaHigh_2,cacaHigh_2,cacaHigh_2,cacaHigh_3,cacaHigh_3,caca_low_1,caca_low_1,caca_low_1,caca_low_2,caca_low_2,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,cacascattr,cacascattr",
        
        /* cacaW1_02   */ "cacaHigh_1,cacaHigh_2,cacaHigh_2,cacaHigh_3,cacaHigh_3,caca_low_1,caca_low_1,caca_low_1,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,cacascattr,cacascattr,cacascattr",
        /* cacaW2_02   */ "cacaHigh_1,cacaHigh_2,cacaHigh_2,cacaHigh_3,cacaHigh_3,cacaHigh_3,caca_low_1,caca_low_1,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_4,caca_low_4,caca_low_4,cacascattr,cacascattr,cacascattr,cacascattr",
        /* cacaW3_02   */ "cacaHigh_1,cacaHigh_2,cacaHigh_3,cacaHigh_3,caca_low_1,caca_low_1,caca_low_1,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_4,caca_low_4,caca_low_4,caca_low_4,cacascattr,cacascattr,cacascattr",
        /* cacaW4_02   */ "cacaHigh_1,cacaHigh_2,cacaHigh_3,cacaHigh_3,caca_low_1,caca_low_1,caca_low_1,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_3,caca_low_3,caca_low_3,caca_low_4,caca_low_4,caca_low_4,caca_low_4,cacascattr,cacascattr,cacascattr",
        /* cacaW5_02   */ "cacaHigh_1,cacaHigh_2,cacaHigh_2,cacaHigh_3,cacaHigh_3,caca_low_1,caca_low_1,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,cacascattr,cacascattr,cacascattr",
        /* cacaW6_02   */ "cacaHigh_1,cacaHigh_1,cacaHigh_2,cacaHigh_3,cacaHigh_3,caca_low_1,caca_low_1,caca_low_1,caca_low_1,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,cacascattr,cacascattr,cacascattr",
        /* cacaW7_02   */ "cacaHigh_1,cacaHigh_2,cacaHigh_2,cacaHigh_3,caca_low_1,caca_low_1,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,cacascattr,cacascattr",
        /* cacaW8_02   */ "cacaHigh_1,cacaHigh_2,cacaHigh_3,cacaHigh_3,caca_low_1,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_4,caca_low_4,caca_low_4,caca_low_4,cacascattr,cacascattr,cacascattr,cacascattr",
        /* cacaW9_02   */ "cacaHigh_1,cacaHigh_2,cacaHigh_2,cacaHigh_3,caca_low_1,caca_low_1,caca_low_1,caca_low_1,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,cacascattr,cacascattr,cacascattr",
        /* cacaW10_02  */ "cacaHigh_1,cacaHigh_2,cacaHigh_2,cacaHigh_3,caca_low_1,caca_low_1,caca_low_1,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_4,caca_low_4,caca_low_4,caca_low_4,cacascattr,cacascattr,cacascattr",
        /* cacaW11_02  */ "cacaHigh_1,cacaHigh_1,cacaHigh_2,cacaHigh_3,cacaHigh_3,caca_low_1,caca_low_1,caca_low_1,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,cacascattr,cacascattr",
        /* cacaW12_02  */ "cacaHigh_1,cacaHigh_2,cacaHigh_2,cacaHigh_3,caca_low_1,caca_low_1,caca_low_1,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_3,caca_low_3,caca_low_3,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,cacascattr,cacascattr,cacascattr",
        /* cacaW13_02  */ "cacaHigh_1,cacaHigh_2,cacaHigh_2,cacaHigh_3,cacaHigh_3,caca_low_1,caca_low_1,caca_low_2,caca_low_2,caca_low_2,caca_low_2,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,cacascattr,cacascattr",
        /* cacaW14_02  */ "cacaHigh_1,cacaHigh_2,cacaHigh_2,cacaHigh_3,cacaHigh_3,caca_low_1,caca_low_1,caca_low_1,caca_low_1,caca_low_2,caca_low_2,caca_low_2,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,cacascattr,cacascattr,cacascattr,cacascattr",
        /* cacaW15_02  */ "cacaHigh_1,cacaHigh_2,cacaHigh_2,cacaHigh_3,cacaHigh_3,cacaHigh_3,caca_low_1,caca_low_1,caca_low_2,caca_low_2,caca_low_3,caca_low_3,caca_low_3,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,cacascattr,cacascattr",
        /* cacaW16_02  */ "cacaHigh_1,cacaHigh_2,cacaHigh_2,cacaHigh_3,cacaHigh_3,caca_low_1,caca_low_1,caca_low_1,caca_low_2,caca_low_2,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_3,caca_low_4,caca_low_4,caca_low_4,caca_low_4,caca_low_4,cacascattr,cacascattr,cacascattr",
    };
    int idx = 0;
    for (int i = 0; i < m_vecReelStripPlan.size(); i++) {
        ReelSet set;
        for (int j = 0; j < 16; j++) {
            ReelStrip strip;
            std::stringstream ss(cacaReelStrip[idx]);
            std::string item;
            while (std::getline(ss, item, ',')) {
                strip.push_back(item);
            }
            set.push_back(strip);
            idx++;
        }
        m_vecReelStripSets.push_back(set);
    }

    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_tmp;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        std::map<std::string, std::map<UINT8, BONUS>> perSym;
        std::map<UINT8, BONUS> e;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 10; e[3].ag = 0;
        perSym["caca_DiceMix"] = e;
        e.clear();

        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[3].ag = 0;
        perSym["caca_low_4"] = e;
        e.clear();

        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 30; e[3].ag = 0;
        perSym["caca_low_3"] = e;
        e.clear();

        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 40; e[3].ag = 0;
        perSym["caca_low_2"] = e;
        e.clear();

        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[3].ag = 0;
        perSym["caca_low_1"] = e;
        e.clear();

        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[3].ag = 0;
        perSym["caca_SpHeMix"] = e;
        e.clear();

        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 150; e[3].ag = 0;
        perSym["cacaHigh_3"] = e;
        e.clear();

        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 150; e[3].ag = 0;
        perSym["cacaHigh_2"] = e;
        e.clear();

        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 1000; e[3].ag = 0;
        perSym["cacaHigh_1"] = e;
        e.clear();

        m_Bonus_tmp[i] = perSym;
    }
    m_Bonus_tmp[5]["cacaHigh_1"][4].coin = 0; m_Bonus_tmp[5]["cacaHigh_1"][4].ag = 6; // 60
    m_Bonus_tmp[6]["cacaHigh_1"][4].coin = 0; m_Bonus_tmp[6]["cacaHigh_1"][4].ag = 8; // 80
    m_Bonus_tmp[7]["cacaHigh_1"][4].coin = 0; m_Bonus_tmp[7]["cacaHigh_1"][4].ag = 10; // 100
    m_Bonus_tmp[8]["cacaHigh_1"][4].coin = 0; m_Bonus_tmp[8]["cacaHigh_1"][4].ag = 15; // 150
    m_Bonus_tmp[9]["cacaHigh_1"][4].coin = 0; m_Bonus_tmp[9]["cacaHigh_1"][4].ag = 20; // 200
    m_Bonus_tmp[10]["cacaHigh_1"][4].coin = 0; m_Bonus_tmp[10]["cacaHigh_1"][4].ag = 50; // 500

    int nSavedBetVal = 10;
    int _line = 0;
    string data;
    PlayDB::GetInstance().LoadCheckPoint(m_strGameName, nSavedBetVal, _line, m_strCheckPoint);
    if (nSavedBetVal == -1) {
        nSavedBetVal = 10;
    }

    BOOL start = FALSE;
    idx = 0;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_tmp, i) < AT(m_vecBetSteps, 0)) {
                continue;
            }
            start = TRUE;
        }
        // set betstep by saved value
        if (AT(m_vecBetSteps, idx) == nSavedBetVal) {
            m_nBetStep = idx;
        }

        m_Bonus[idx++] = m_Bonus_tmp[i];
        if (AT(m_vecBetSteps_tmp, i) == AT(m_vecBetSteps, m_vecBetSteps.size() - 1)) {
            break;
        }
    }

    m_vecBetSteps_05.clear();
    m_vecBetSteps_10.clear();
    PrintAllBonus();
}


UINT16 RgCairoCasino::Run() {    
    m_nCurrentReelPlan = (myRandom() % m_vecReelStripPlan.size());
    m_shCurrentReelStrip = static_cast<uint16_t>(std::stoi(AT(m_vecReelStripPlan, m_nCurrentReelPlan)));
    return m_shCurrentReelStrip;
}

void RgCairoCasino::ChangeReelStrip(UINT16 NewReelPlan) {
    m_nCurrentReelPlan = NewReelPlan;
    m_shCurrentReelStrip = static_cast<uint16_t>(std::stoi(AT(m_vecReelStripPlan, m_nCurrentReelPlan)));
}

myVector<UINT8> RgCairoCasino::Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) {
    m_bPrevSpinMatchedActive = FALSE;
    m_nMagicCount = 0;

    myVector<UINT8> result;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    if (bTest) {
        std::string matchSymbol = AT(m_vecSymbols, myRandom() % (m_vecSymbols.size() - 1));
        int line = (myRandom() % m_nWinLine);
        
        int weight = 0;// (myRandom() % 1) ? 0 : 4;
        if (m_bFreeMode) {
            weight = 0;
        }

        for (int i = 0; i < 16; i++) {
            ReelStrip reelStrip = AT(reelSet, i);
            int len = reelStrip.size();

            bool transable = ((myRandom() % 100) < 50);

            UINT8 idx = (myRandom() % len);
            if (transable == false) {
                while (AT(reelStrip, idx) == RgCairoCasino_scatter) {
                    idx = (myRandom() % len);
                }
            }
            result.push_back(idx);
        }

        if ((myRandom() % 35) == 0) {
            // select 5~7 numbers
            myVector<UINT8> pool;
            for (UINT8 i = 0; i <= 15; ++i) {
                pool.push_back(i);
            }
            std::random_device rd;
            std::mt19937 rng(rd());
            std::shuffle(pool.begin(), pool.end(), rng);
            std::uniform_int_distribution<int> countDist(5, 7);
            int count = countDist(rng);
            myVector<UINT8> selected(pool.begin(), pool.begin() + count);

            for (int j = 0; j < selected.size(); j++) {
                myVector<int> candidateIndices;
                for (int i = 0; i < AT(reelSet, AT(selected, j)).size(); ++i) {
                    if (AT(AT(reelSet, AT(selected, j)), i) == RgCairoCasino_scatter) {
                        candidateIndices.push_back(i);
                    }
                }
                if (!candidateIndices.empty()) {
                    int chosenIndex = AT(candidateIndices, myRandom() % candidateIndices.size());
                    AT(result, AT(selected, j)) = chosenIndex;
                }
            }
        }
    }
    else {
        result = _result;
        BOOL mmcode = mmcode_get_active_status();
        if (mmcode) {
            mmcode_set_deactive();
            if (m_bFreeMode == FALSE) {
                // select 5~7 numbers
                myVector<UINT8> pool;
                for (UINT8 i = 0; i <= 15; ++i) {
                    pool.push_back(i);
                }
                std::random_device rd;
                std::mt19937 rng(rd());
                std::shuffle(pool.begin(), pool.end(), rng);
                std::uniform_int_distribution<int> countDist(5, 7);
                int count = countDist(rng);
                myVector<UINT8> selected(pool.begin(), pool.begin() + count);

                for (int j = 0; j < selected.size(); j++) {
                    myVector<int> candidateIndices;
                    for (int i = 0; i < AT(reelSet, AT(selected, j)).size(); ++i) {
                        if (AT(AT(reelSet, AT(selected, j)), i) == RgCairoCasino_scatter) {
                            candidateIndices.push_back(i);
                        }
                    }
                    if (!candidateIndices.empty()) {
                        int chosenIndex = AT(candidateIndices, myRandom() % candidateIndices.size());
                        AT(result, AT(selected, j)) = chosenIndex;
                    }
                }
            }
        }
    }
    m_vWinResult = result;

    if (CardCount(RgCairoCasino_scatter) >= 5) {
        //bCanFreeMode = TRUE;
    }

    normalMeter = 0;
    maxMeter = 0;
    BONUS totalBonus = { 0, 0 };
    // Iterate through all win lines
    for (int i = 0; i < m_nWinLine; ++i) {
        // Extract symbols from the result based on the line match definition
        const int idx0 = g_match_cairo[i][0] - 1;
        const int idx1 = g_match_cairo[i][1] - 1;
        const int idx2 = g_match_cairo[i][2] - 1;
        const int idx3 = g_match_cairo[i][3] - 1;

        std::string symbol0 = AT(AT(reelSet, idx0), AT(result, idx0));
        std::string symbol1 = AT(AT(reelSet, idx1), AT(result, idx1));
        std::string symbol2 = AT(AT(reelSet, idx2), AT(result, idx2));
        std::string symbol3 = AT(AT(reelSet, idx3), AT(result, idx3));

        // when freemode
        if (std::find(m_vFreeModeScatters.begin(), m_vFreeModeScatters.end(), g_match_cairo[i][0]) != m_vFreeModeScatters.end()) {
            symbol0 = RgCairoCasino_scatter;
        }
        if (std::find(m_vFreeModeScatters.begin(), m_vFreeModeScatters.end(), g_match_cairo[i][1]) != m_vFreeModeScatters.end()) {
            symbol1 = RgCairoCasino_scatter;
        }
        if (std::find(m_vFreeModeScatters.begin(), m_vFreeModeScatters.end(), g_match_cairo[i][2]) != m_vFreeModeScatters.end()) {
            symbol2 = RgCairoCasino_scatter;
        }
        if (std::find(m_vFreeModeScatters.begin(), m_vFreeModeScatters.end(), g_match_cairo[i][3]) != m_vFreeModeScatters.end()) {
            symbol3 = RgCairoCasino_scatter;
        }
        
        // Flags for symbol matching
        BOOL match = FALSE;
        BOOL mixed = FALSE;
        std::string matchedSymbol = "";

        // Check for exact symbol match
        if (symbol0 == symbol1 && symbol0 == symbol2 && symbol0 == symbol3) {
            match = TRUE;
            matchedSymbol = symbol0;
        }

        // Check for special mixed-symbol match cases if exact match failed
        if (!match) {
            const std::set<std::string> spHeMixSet = {
                "cacaHigh_1", "cacaHigh_2"
            };

            const std::set<std::string> diceMixSet = {
                "cacaHigh_3", "caca_low_1", "caca_low_3"
            };

            // Helper lambda to check if all 4 symbols belong to a given set
            auto allInSet = [](const std::set<std::string>& validSet,
                const std::string& s1,
                const std::string& s2,
                const std::string& s3,
                const std::string& s4) -> bool {
                    return validSet.count(s1) && validSet.count(s2) &&
                        validSet.count(s3) && validSet.count(s4);
                };

            if (allInSet(spHeMixSet, symbol0, symbol1, symbol2, symbol3)) {
                match = TRUE;
                mixed = TRUE;
                matchedSymbol = "caca_SpHeMix";
            }
            else if (allInSet(diceMixSet, symbol0, symbol1, symbol2, symbol3)) {
                match = TRUE;
                mixed = TRUE;
                matchedSymbol = "caca_DiceMix";
            }

            if (!match) {
                continue; // Skip line if no valid match found
            }
        }

        // Skip scatter symbols
        if (symbol0 == RgCairoCasino_scatter) {
            continue;
        }
        // Build meter bitmap from positions (each position encoded in 16-bit)
        UINT16 meter = 0;
        meter |= 1 << ((((g_match_cairo[i][0] - 1) % 4) * 4) + ((g_match_cairo[i][0] - 1) / 4));
        meter |= 1 << ((((g_match_cairo[i][1] - 1) % 4) * 4) + ((g_match_cairo[i][1] - 1) / 4));
        meter |= 1 << ((((g_match_cairo[i][2] - 1) % 4) * 4) + ((g_match_cairo[i][2] - 1) / 4));
        meter |= 1 << ((((g_match_cairo[i][3] - 1) % 4) * 4) + ((g_match_cairo[i][3] - 1) / 4));

        // Create a WinMeter object to store the win info
       
        WinMeter win;
        win.line = i;
        win.meter = meter;
        win.meter2 = g_GrafficObjList.Str2GOCID(m_mapSymbolMeterGoc[matchedSymbol]);
        win.symbol = matchedSymbol;
        win.weight = 4;
        win.start = 0;
        win.bonus = m_Bonus[BetStep()][matchedSymbol][4];
        win.sound = MAX_SOUND_IDS;

        // Accumulate bonus values
        totalBonus.coin += win.bonus.coin;
        totalBonus.ag += win.bonus.ag;

        // Track meter and wins
        meters.push_back(win);
        normalMeter |= meter;

        if (!bTest) {
            m_bPrevSpinMatchedActive = TRUE;
        }
    }
    m_nMagicCount = totalBonus.ag;
    if (bTest == FALSE) {
        if (totalBonus.coin > 0 || totalBonus.ag > 0) {
            BonusSound = getSoundByID(WinSound(totalBonus.coin + totalBonus.ag * 1000));
        }
        else {
            BonusSound.duration = 0;
            BonusSound.soundID = MAX_SOUND_IDS;
        }
    }

    // replace scatter place with 0xFF
    if (m_bFreeMode && bTest == FALSE) {
        for (int i = 0; i < 16; i++) {
            // fixed scatter
            if (std::find(m_vFreeModeScatters.begin(), m_vFreeModeScatters.end(), i + 1) != m_vFreeModeScatters.end()) {
                AT(result, i) = 0xFF;
            }
        }
    }
    return result;
}

UINT16 RgCairoCasino::LineSound(UINT Line, std::string symbol, UINT8 weight) {
    return AT(m_vecLineSounds, 0);
}

UINT16 RgCairoCasino::MagicCount() {
    if (m_bFreeMode) {
        return 0;
    }
    else {
        return m_nMagicCount;
    }
}

BOOL RgCairoCasino::CanFreeMode() {
    if (CardCount(RgCairoCasino_scatter) >= 5) {
        return TRUE;
    }
    return FALSE;
}

UINT8 RgCairoCasino::CardCount(std::string card) {
    UINT8 n = 0;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int i = 0; i < 16; i++) {
        if (AT(AT(reelSet, i), AT(m_vWinResult, i)) == card) {
            n++;
        }
    }
    return n;
}

#include "../StateMachine.h"
myVector<InterruptPacketData> RgCairoCasino::EnterFreeGame(std::string check) {
    m_bFreeMode = TRUE;
    m_bFreeModePenddingFinish = FALSE;    
    
    m_vFreeModeScatters.clear();
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int i = 0; i < 16; i++) {
        if (AT(AT(reelSet, i), AT(m_vWinResult, i)) == RgCairoCasino_scatter) {
            m_vFreeModeScatters.push_back(i + 1);
        }
    }
    myVector<InterruptPacketData> packets;
    packets.push_back({ 0, 0, {0x06, 0xbe, 0x04, 0x01, 0x02, 0x31, 0x00, 0x02, 0x00, 0xd0, 0x58, 0x06, 0x00, 0x01, 0x04} });
    packets.push_back({ 0, 0, {0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0xbe, 0x04, 0x02, 0x00, 0x04} });
    packets.push_back({ 0, 0, {0x01, 0x02, 0x30, 0x00, 0xbe, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa6, 0x04} });
    packets.push_back({ 0, 7000, {0x01, 0x02, 0x31, 0x00, 0x0a, 0x00, 0x25, 0x53, 0x11, 0x00, 0x01, 0x00, 0x01, 0x00, 0x00, 0x00, 0x04, 0x03, 0x00, 0x04} });

    auto freeBonus = GetFreeModeBonus();
    g_StateMachine.SetBonusBit(0, freeBonus[m_vFreeModeScatters.size()]);
    return packets;
}

myVector<InterruptPacketData> RgCairoCasino::InterruptAfterSpin() {
    myVector<InterruptPacketData> packets;
    if (!m_bFreeMode) {
        return packets;
    }
    UINT32 nNewScatter = 0;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int i = 0; i < 16; i++) {
        if (AT(AT(reelSet, i), AT(m_vWinResult, i)) == RgCairoCasino_scatter) {
            if (std::find(m_vFreeModeScatters.begin(), m_vFreeModeScatters.end(), i + 1) == m_vFreeModeScatters.end()) { // new scatter
                m_vFreeModeScatters.push_back(i + 1);
                nNewScatter++;
            }
        }
    }
    if (nNewScatter) {
        packets.push_back({ 0, 0, {0x06, 0xbe, 0x04, 0x01, 0x02, 0x31, 0x00, 0x02, 0x00, 0xd0, 0x58, 0x06, 0x00, 0x01, 0x04} });
        packets.push_back({ 0, 0, {0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0xbe, 0x04, 0x02, 0x00, 0x04} });
        packets.push_back({ 0, nNewScatter * 3300, {0x01, 0x02, 0x30, 0x00, 0xbe, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa7, 0x04} });

        auto freeBonus = GetFreeModeBonus();
        g_StateMachine.SetBonusBit(0, freeBonus[m_vFreeModeScatters.size()]);
    }
    if (nNewScatter == 0 || m_vFreeModeScatters.size() >= 16) { // no new scatter or reach max -> end freemode
        auto freeBonus = GetFreeModeBonus();
        m_FreeModeBonus.coin = freeBonus[m_vFreeModeScatters.size()];
        m_FreeModeBonus.ag = 0;

        m_bFreeModePenddingFinish = TRUE;
    }
    return packets;
}

myVector<InterruptPacketData> RgCairoCasino::InterruptAfterMoveBonus(BOOL& EndFree) {
    myVector<InterruptPacketData> packets;
    if (m_bFreeMode == TRUE) {
        if (m_bFreeModePenddingFinish == TRUE) {
           
            // show result dialog
            packets.push_back({ 500, 0, {0x01, 0x02, 0x30, 0x00, 0xbe, 0x04, 0x00, 0x00, 
                static_cast<BYTE>(m_FreeModeBonus.coin & 0xFF), 
                static_cast<BYTE>((m_FreeModeBonus.coin >> 8) & 0xFF), 
                static_cast<BYTE>((m_FreeModeBonus.coin >> 16) & 0xFF),
                static_cast<BYTE>((m_FreeModeBonus.coin >> 24) & 0xFF),
                0x00, 0x00, 0xab, 0x04} });
            // return to main game
            packets.push_back({ 0, 0, {0x01, 0x02, 0x30, 0x00, 0xbe, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa4, 0x04} });

            // hide dialog
            packets.push_back({ 6000, 0, {0x01, 0x02, 0x30, 0x00, 0xbe, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xac, 0x04} });

            m_vFreeModeScatters.clear();
            m_bFreeMode = FALSE;
            EndFree = TRUE;
        }
    }
    return packets;
}

myVector<UINT8> RgCairoCasino::ShowTotalWinLines(myVector<WinMeter> SpinMeters) {
    myVector<uint8_t> packet = {
        0x01, 0x02, 0x31, 0x00, 
        0x0f, 0x00,  // Placeholder for length  
        0xbe, 0x04, // GameID 
        0x9c, 0x1d, 0x01
    };
    myVector<UINT8> TotalMatch;
    for (int i = 0; i < SpinMeters.size(); i++) {
        if (AT(SpinMeters, i).line == 0xFF) { // clear after convert action
            TotalMatch.clear();
            continue;
        }
        TotalMatch.push_back(AT(SpinMeters, i).line);
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter >> 8) & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter2 & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter2 >> 8) & 0xFF));
    }
    if (TotalMatch.size() < 10) {
        myVector<UINT8> _;
        return _;
    }
    UINT16 pktLen = 1 + (TotalMatch.size() / 5) * 7;
    AT(packet, 4) = static_cast<BYTE>(pktLen & 0xFF);
    AT(packet, 5) = static_cast<BYTE>((pktLen >> 8) & 0xFF);
    AT(packet, 6) = static_cast<BYTE>(m_nGameID & 0xFF);
    AT(packet, 7) = static_cast<BYTE>((m_nGameID >> 8) & 0xFF);
    int entryCount = static_cast<int>(TotalMatch.size() / 5);
    for (int i = 0; i < entryCount; ++i) {
        packet.push_back(AT(TotalMatch, i * 5 + 0)); // Line
        packet.push_back(AT(TotalMatch, i * 5 + 1)); // Meter low byte
        packet.push_back(AT(TotalMatch, i * 5 + 2)); // Meter high byte
        packet.push_back(AT(TotalMatch, i * 5 + 3)); // Meter2 low byte
        packet.push_back(AT(TotalMatch, i * 5 + 4)); // Meter2 high byte
        packet.push_back(0x01);      // Status or flag 1
        packet.push_back(0x01);      // Status or flag 2
    }
    // Mark the end of the packet
    packet.back() = 0x04;
    return packet;
}

std::map<UINT8, UINT32> RgCairoCasino::GetFreeModeBonus() {
    
    int bet = AT(Bets(), BetStep());
    std::map<UINT8, UINT32> freeBonus;
    freeBonus[5] = 20 * (bet / 10);
    freeBonus[6] = 30 * (bet / 10);
    freeBonus[7] = 40 * (bet / 10);
    freeBonus[8] = 50 * (bet / 10);
    freeBonus[9] = 70 * (bet / 10);
    freeBonus[10] = 100 * (bet / 10);
    freeBonus[11] = 200 * (bet / 10);
    freeBonus[12] = 500 * (bet / 10);
    freeBonus[13] = 1000 * (bet / 10);
    freeBonus[14] = 2000 * (bet / 10);
    freeBonus[15] = 3000 * (bet / 10);
    freeBonus[16] = 6000 * (bet / 10);
    return freeBonus;
}

void RgCairoCasino::updateCheckPoint() {
}