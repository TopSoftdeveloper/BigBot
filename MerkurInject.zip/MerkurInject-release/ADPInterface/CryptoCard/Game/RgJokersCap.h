#pragma once

#include "ReelGame.h"

class RgJokersCap : public ReelGame
{
public:
	myVector<WinMeter> m_vWinMeters;

	std::string m_strSymbol_0;
	std::string m_strSymbol_1;

	RgJokersCap::RgJokersCap();
	UINT8 CardCount(std::string card);
	BOOL IsWild(std::string card);
	std::pair<std::string, std::string> getTwoRandomSymbols(const myVector<std::string>& symbols);
	void Choose2SymbolsToConvert();

	UINT16 Run() override;
	myVector<UINT8> Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& WinSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) override;
	myVector<InterruptPacketData> InterruptAfterSpin() override;

	int LineSwapDelay(int WinIdx) override;

	bool RTP_force_bigWin() override;
};
