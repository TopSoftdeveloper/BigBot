#include "stdafx.h"
#include "RgConvertusAurum.h"

#define RgConvertusAurum_MP_ChangeLine_LB_x_reel   0x03
#define RgConvertusAurum_MP_ChangeLine_LB_x_pos    0x28
#define RgConvertusAurum_MP_ChangeLine_LB_y_row    0x02
#define RgConvertusAurum_MP_ChangeLine_LB_y_pos    0x17
#define RgConvertusAurum_MP_ChangeLine_RT_x_reel   0x03
#define RgConvertusAurum_MP_ChangeLine_RT_x_pos    0x61
#define RgConvertusAurum_MP_ChangeLine_RT_y_row    0x02
#define RgConvertusAurum_MP_ChangeLine_RT_y_pos    0x50

#define RgConvertusAurum_wild       "coauMAN_____"
#define RgConvertusAurum_scatter    "coauCAULDRON"

RgConvertusAurum::RgConvertusAurum() {
    m_nReel = 5;
    m_nWinLine = 5;
    m_nMaxMatch = 5;
    m_nBetStep = 0;

    m_strGameName = "RgConvertusAurum";

    m_vecAdditionalParam.push_back(0xFF);
    m_vecAdditionalParam.push_back(0xFF);

    m_bFreeMode = FALSE;

    myVector<UINT16> m_vecBetSteps_05_tmp;
    myVector<UINT16> m_vecBetSteps_10_tmp;

    m_vecBetSteps_05_tmp.push_back(5);
    m_vecBetSteps_05_tmp.push_back(10);
    m_vecBetSteps_05_tmp.push_back(20);
    m_vecBetSteps_05_tmp.push_back(30);
    m_vecBetSteps_05_tmp.push_back(40);
    m_vecBetSteps_05_tmp.push_back(50);
    m_vecBetSteps_05_tmp.push_back(75);
    m_vecBetSteps_05_tmp.push_back(100);

    m_vecBetSteps_10_tmp.push_back(10);
    m_vecBetSteps_10_tmp.push_back(20);
    m_vecBetSteps_10_tmp.push_back(40);
    m_vecBetSteps_10_tmp.push_back(60);
    m_vecBetSteps_10_tmp.push_back(80);
    m_vecBetSteps_10_tmp.push_back(100);
    m_vecBetSteps_10_tmp.push_back(150);
    m_vecBetSteps_10_tmp.push_back(200);

#ifdef BIGBET_ACTIVE
    m_vecBetSteps_05_tmp.push_back(200);
    m_vecBetSteps_05_tmp.push_back(500);
    m_vecBetSteps_10_tmp.push_back(400);
    m_vecBetSteps_10_tmp.push_back(1000);
#endif
    LoadBets();

    m_vecBetSteps = m_vecBetSteps_05;

    m_vecSymbols.push_back("coauTEN_____");
    m_vecSymbols.push_back("coauJ_______");
    m_vecSymbols.push_back("coauQ_______");
    m_vecSymbols.push_back("coauK_______");
    m_vecSymbols.push_back("coauA_______");
    m_vecSymbols.push_back("coauPARCH___");
    m_vecSymbols.push_back("coauVIAL____");
    m_vecSymbols.push_back("coauGOLD____");
    m_vecSymbols.push_back("coauSCALES__");
    m_vecSymbols.push_back("coauBIRD____");
    m_vecSymbols.push_back("coauMAN_____");
    m_vecSymbols.push_back("coauCAULDRON");

    m_mapSymbolMinMatch["coauTEN_____"] = 3;
    m_mapSymbolMinMatch["coauJ_______"] = 3;
    m_mapSymbolMinMatch["coauQ_______"] = 3;
    m_mapSymbolMinMatch["coauK_______"] = 3;
    m_mapSymbolMinMatch["coauA_______"] = 3;
    m_mapSymbolMinMatch["coauPARCH___"] = 3;
    m_mapSymbolMinMatch["coauVIAL____"] = 3;
    m_mapSymbolMinMatch["coauGOLD____"] = 3;
    m_mapSymbolMinMatch["coauSCALES__"] = 3;
    m_mapSymbolMinMatch["coauBIRD____"] = 3;

    m_mapSymbolMeterGoc["coauTEN_____"] = "coauAKQJT_$x";
    m_mapSymbolMeterGoc["coauJ_______"] = "coauAKQJT_$x";
    m_mapSymbolMeterGoc["coauQ_______"] = "coauAKQJT_$x";
    m_mapSymbolMeterGoc["coauK_______"] = "coauAKQJT_$x";
    m_mapSymbolMeterGoc["coauA_______"] = "coauAKQJT_$x";
    m_mapSymbolMeterGoc["coauPARCH___"] = "coauVialParch_$x";
    m_mapSymbolMeterGoc["coauVIAL____"] = "coauVialParch_$x";
    m_mapSymbolMeterGoc["coauGOLD____"] = "coauGold_$x";
    m_mapSymbolMeterGoc["coauSCALES__"] = "coauScales_$x";
    m_mapSymbolMeterGoc["coauBIRD____"] = "coauBird_$x";

    m_vecWinLines.push_back("coauWinline1");
    m_vecWinLines.push_back("coauWinline2");
    m_vecWinLines.push_back("coauWinline3");
    m_vecWinLines.push_back("coauWinline4");
    m_vecWinLines.push_back("coauWinline5");
    m_vecWinLines.push_back("coauWinline6");
    m_vecWinLines.push_back("coauWinline7");
    m_vecWinLines.push_back("coauWinline8");
    m_vecWinLines.push_back("coauWinline9");
    m_vecWinLines.push_back("coauWinline10");
    m_vecWinLines.push_back("coauWinlineScat");    
    
    m_vecLineSounds.push_back(SMP_Alc_WinStep1);
    m_vecLineSounds.push_back(SMP_Alc_WinStep2);
    m_vecLineSounds.push_back(SMP_Alc_WinStep3);
    m_vecLineSounds.push_back(SMP_Alc_WinStep4);
    m_vecLineSounds.push_back(SMP_Alc_WinStep5);
    m_vecLineSounds.push_back(SMP_Alc_WinStep6);
    m_vecLineSounds.push_back(SMP_Alc_WinStep7);
    m_vecLineSounds.push_back(SMP_Alc_WinStep8);
    m_vecLineSounds.push_back(SMP_Alc_WinStep9);
    m_vecLineSounds.push_back(SMP_Alc_WinStep10);

    m_vecWinSounds.push_back(SMP_Alc_Win1);
    m_vecWinSounds.push_back(SMP_Alc_Win2);
    m_vecWinSounds.push_back(SMP_Alc_Win3);
    m_vecWinSounds.push_back(SMP_Alc_Win4);
    m_vecWinSounds.push_back(SMP_Alc_Win5);
    m_vecWinSounds.push_back(SMP_Alc_Win6);
    m_vecWinSounds.push_back(SMP_Alc_Win7);
    m_vecWinSounds.push_back(SMP_Alc_Win8);
    m_vecWinSounds.push_back(SMP_Alc_Win9);
    m_vecWinSounds.push_back(SMP_Alc_Win10);

    m_vecReelStripPlan.push_back("0");
    m_vecReelStripPlan.push_back("1");
    m_vecReelStripPlan.push_back("2");
    m_vecReelStripPlan.push_back("3");
    
    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));

    char* coauReelStrip[] = {
        "coauA_______,coauBIRD____,coauK_______,coauQ_______,coauPARCH___,coauA_______,coauGOLD____,coauGOLD____,coauGOLD____,coauTEN_____,coauQ_______,coauJ_______,coauCAULDRON,coauQ_______,coauVIAL____,coauSCALES__,coauA_______,coauTEN_____,coauGOLD____,coauGOLD____,coauGOLD____,coauK_______,coauJ_______,coauCAULDRON,coauK_______,coauPARCH___,coauJ_______,coauTEN_____,coauA_______,coauK_______,coauVIAL____,coauTEN_____,coauGOLD____,coauGOLD____,coauGOLD____,coauPARCH___,coauJ_______,coauBIRD____,coauQ_______,coauSCALES__,coauK_______",
        "coauCAULDRON,coauA_______,coauQ_______,coauK_______,coauA_______,coauQ_______,coauJ_______,coauTEN_____,coauA_______,coauQ_______,coauPARCH___,coauTEN_____,coauCAULDRON,coauK_______,coauSCALES__,coauJ_______,coauGOLD____,coauGOLD____,coauGOLD____,coauVIAL____,coauPARCH___,coauJ_______,coauTEN_____,coauA_______,coauK_______,coauGOLD____,coauGOLD____,coauGOLD____,coauJ_______,coauVIAL____,coauPARCH___,coauTEN_____,coauBIRD____,coauQ_______,coauSCALES__,coauK_______",
        "coauA_______,coauBIRD____,coauK_______,coauQ_______,coauPARCH___,coauA_______,coauGOLD____,coauGOLD____,coauGOLD____,coauTEN_____,coauQ_______,coauJ_______,coauCAULDRON,coauA_______,coauVIAL____,coauSCALES__,coauTEN_____,coauQ_______,coauGOLD____,coauGOLD____,coauGOLD____,coauK_______,coauJ_______,coauPARCH___,coauK_______,coauJ_______,coauTEN_____",
        "coauCAULDRON,coauK_______,coauBIRD____,coauJ_______,coauGOLD____,coauGOLD____,coauGOLD____,coauQ_______,coauVIAL____,coauPARCH___,coauJ_______,coauTEN_____,coauA_______,coauK_______,coauGOLD____,coauGOLD____,coauGOLD____,coauTEN_____,coauVIAL____,coauPARCH___,coauJ_______,coauBIRD____,coauQ_______,coauSCALES__,coauK_______,coauTEN_____,coauPARCH___,coauA_______,coauK_______,coauTEN_____",

        "coauMAN_____,coauTEN_____,coauA_______,coauVIAL____,coauK_______,coauGOLD____,coauGOLD____,coauGOLD____,coauJ_______,coauQ_______,coauSCALES__,coauTEN_____,coauPARCH___,coauVIAL____,coauQ_______,coauTEN_____,coauGOLD____,coauGOLD____,coauGOLD____,coauJ_______,coauPARCH___,coauK_______,coauJ_______,coauCAULDRON,coauTEN_____,coauQ_______,coauA_______,coauBIRD____,coauJ_______,coauQ_______,coauGOLD____,coauGOLD____,coauGOLD____,coauA_______,coauTEN_____,coauSCALES__,coauK_______,coauBIRD____,coauA_______",
        "coauVIAL____,coauA_______,coauK_______,coauTEN_____,coauSCALES__,coauJ_______,coauTEN_____,coauSCALES__,coauQ_______,coauPARCH___,coauVIAL____,coauQ_______,coauK_______,coauJ_______,coauBIRD____,coauA_______,coauTEN_____,coauJ_______,coauQ_______,coauVIAL____,coauK_______,coauGOLD____,coauGOLD____,coauGOLD____,coauJ_______,coauA_______,coauPARCH___,coauBIRD____,coauQ_______,coauCAULDRON,coauA_______,coauGOLD____,coauGOLD____,coauGOLD____,coauK_______,coauPARCH___,coauTEN_____",
        "coauMAN_____,coauTEN_____,coauA_______,coauVIAL____,coauK_______,coauGOLD____,coauGOLD____,coauGOLD____,coauQ_______,coauJ_______,coauCAULDRON,coauQ_______,coauSCALES__,coauTEN_____,coauPARCH___,coauVIAL____,coauQ_______,coauTEN_____,coauGOLD____,coauGOLD____,coauGOLD____,coauJ_______,coauPARCH___,coauTEN_____,coauMAN_____,coauJ_______,coauBIRD____,coauA_______,coauCAULDRON,coauK_______",
        "coauGOLD____,coauGOLD____,coauGOLD____,coauK_______,coauTEN_____,coauBIRD____,coauA_______,coauTEN_____,coauJ_______,coauQ_______,coauVIAL____,coauA_______,coauGOLD____,coauGOLD____,coauGOLD____,coauA_______,coauJ_______,coauPARCH___,coauSCALES__,coauQ_______,coauCAULDRON,coauA_______,coauTEN_____,coauBIRD____,coauQ_______,coauSCALES__,coauK_______,coauVIAL____,coauTEN_____",

        "coauMAN_____,coauQ_______,coauJ_______,coauTEN_____,coauVIAL____,coauA_______,coauQ_______,coauCAULDRON,coauTEN_____,coauK_______,coauPARCH___,coauJ_______,coauQ_______,coauTEN_____,coauVIAL____,coauSCALES__,coauA_______,coauK_______,coauPARCH___,coauJ_______,coauGOLD____,coauGOLD____,coauGOLD____,coauVIAL____,coauK_______,coauA_______,coauPARCH___,coauTEN_____,coauSCALES__,coauJ_______,coauBIRD____,coauQ_______,coauK_______,coauGOLD____,coauGOLD____,coauGOLD____,coauVIAL____,coauA_______",
        "coauJ_______,coauVIAL____,coauQ_______,coauSCALES__,coauTEN_____,coauVIAL____,coauPARCH___,coauA_______,coauSCALES__,coauQ_______,coauCAULDRON,coauTEN_____,coauPARCH___,coauK_______,coauJ_______,coauQ_______,coauVIAL____,coauTEN_____,coauJ_______,coauA_______,coauTEN_____,coauK_______,coauA_______,coauQ_______,coauGOLD____,coauGOLD____,coauGOLD____,coauK_______,coauJ_______,coauPARCH___,coauBIRD____,coauK_______,coauCAULDRON,coauVIAL____,coauA_______",
        "coauMAN_____,coauQ_______,coauTEN_____,coauVIAL____,coauA_______,coauQ_______,coauCAULDRON,coauTEN_____,coauK_______,coauPARCH___,coauJ_______,coauTEN_____,coauPARCH___,coauSCALES__,coauJ_______,coauA_______,coauBIRD____,coauJ_______,coauVIAL____,coauK_______,coauGOLD____,coauGOLD____,coauGOLD____,coauVIAL____,coauTEN_____,coauK_______,coauSCALES__,coauMAN_____,coauQ_______,coauA_______",
        "coauVIAL____,coauK_______,coauJ_______,coauQ_______,coauPARCH___,coauTEN_____,coauGOLD____,coauGOLD____,coauGOLD____,coauA_______,coauTEN_____,coauJ_______,coauVIAL____,coauA_______,coauK_______,coauQ_______,coauGOLD____,coauGOLD____,coauGOLD____,coauJ_______,coauK_______,coauPARCH___,coauBIRD____,coauK_______,coauVIAL____,coauA_______,coauSCALES__,coauQ_______,coauCAULDRON,coauTEN_____",

        "coauMAN_____,coauA_______,coauVIAL____,coauGOLD____,coauGOLD____,coauGOLD____,coauJ_______,coauQ_______,coauSCALES__,coauVIAL____,coauTEN_____,coauQ_______,coauVIAL____,coauJ_______,coauPARCH___,coauK_______,coauBIRD____,coauJ_______,coauCAULDRON,coauTEN_____,coauPARCH___,coauQ_______,coauA_______,coauBIRD____,coauQ_______,coauVIAL____,coauTEN_____,coauJ_______,coauGOLD____,coauGOLD____,coauGOLD____,coauA_______,coauK_______,coauSCALES__,coauA_______,coauBIRD____,coauK_______",
        "coauA_______,coauVIAL____,coauK_______,coauJ_______,coauBIRD____,coauTEN_____,coauJ_______,coauSCALES__,coauPARCH___,coauQ_______,coauSCALES__,coauTEN_____,coauPARCH___,coauVIAL____,coauJ_______,coauCAULDRON,coauTEN_____,coauPARCH___,coauSCALES__,coauQ_______,coauA_______,coauGOLD____,coauGOLD____,coauGOLD____,coauQ_______,coauPARCH___,coauVIAL____,coauK_______,coauJ_______,coauA_______,coauVIAL____,coauSCALES__,coauA_______,coauBIRD____,coauK_______,coauCAULDRON",
        "coauMAN_____,coauA_______,coauVIAL____,coauGOLD____,coauGOLD____,coauGOLD____,coauJ_______,coauQ_______,coauSCALES__,coauVIAL____,coauTEN_____,coauQ_______,coauVIAL____,coauJ_______,coauPARCH___,coauK_______,coauBIRD____,coauJ_______,coauCAULDRON,coauTEN_____,coauPARCH___,coauQ_______,coauA_______,coauBIRD____,coauQ_______,coauVIAL____,coauTEN_____,coauJ_______",
        "coauPARCH___,coauVIAL____,coauJ_______,coauCAULDRON,coauTEN_____,coauA_______,coauSCALES__,coauQ_______,coauA_______,coauGOLD____,coauGOLD____,coauGOLD____,coauQ_______,coauBIRD____,coauVIAL____,coauK_______,coauJ_______,coauA_______,coauVIAL____,coauSCALES__,coauA_______,coauBIRD____,coauK_______,coauVIAL____,coauTEN_____,coauQ_______,coauJ_______",

        "coauQ_______,coauK_______,coauPARCH___,coauA_______,coauGOLD____,coauGOLD____,coauGOLD____,coauQ_______,coauTEN_____,coauA_______,coauVIAL____,coauSCALES__,coauTEN_____,coauCAULDRON,coauK_______,coauPARCH___,coauJ_______,coauA_______,coauK_______,coauJ_______,coauTEN_____,coauK_______,coauVIAL____,coauTEN_____,coauJ_______,coauBIRD____,coauQ_______,coauTEN_____,coauSCALES__,coauA_______",
        "coauQ_______,coauK_______,coauVIAL____,coauQ_______,coauSCALES__,coauPARCH___,coauA_______,coauTEN_____,coauQ_______,coauA_______,coauTEN_____,coauSCALES__,coauCAULDRON,coauK_______,coauJ_______,coauPARCH___,coauCAULDRON,coauJ_______,coauA_______,coauK_______,coauGOLD____,coauGOLD____,coauGOLD____,coauK_______,coauTEN_____,coauJ_______,coauVIAL____,coauBIRD____,coauQ_______,coauSCALES__,coauVIAL____,coauA_______,coauBIRD____,coauJ_______,coauTEN_____",
        "coauQ_______,coauK_______,coauPARCH___,coauA_______,coauGOLD____,coauGOLD____,coauGOLD____,coauQ_______,coauTEN_____,coauA_______,coauVIAL____,coauSCALES__,coauTEN_____,coauCAULDRON,coauK_______,coauPARCH___,coauJ_______,coauA_______,coauK_______,coauJ_______,coauTEN_____,coauK_______,coauVIAL____,coauTEN_____,coauQ_______,coauBIRD____,coauJ_______,coauTEN_____",
        "coauCAULDRON,coauTEN_____,coauJ_______,coauPARCH___,coauQ_______,coauTEN_____,coauA_______,coauK_______,coauGOLD____,coauGOLD____,coauGOLD____,coauK_______,coauTEN_____,coauQ_______,coauVIAL____,coauBIRD____,coauQ_______,coauSCALES__,coauVIAL____,coauA_______,coauSCALES__,coauJ_______,coauTEN_____,coauK_______,coauA_______",
    };

    for (int i = 0; i < m_vecReelStripPlan.size(); i++) {
        ReelSet set;
        for (int j = 0; j < m_nReel; j++) {
            ReelStrip strip;
            std::stringstream ss(coauReelStrip[j * m_vecReelStripPlan.size() + i]);
            std::string item;
            while (std::getline(ss, item, ',')) {
                strip.push_back(item);
            }
            set.push_back(strip);
        }
        m_vecReelStripSets.push_back(set);
    }
    
    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_05_tmp;
    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_10_tmp;
    for (int i = 0; i < m_vecBetSteps_05_tmp.size(); i++) {
        std::map<std::string, std::map<UINT8, BONUS>> perSym;
        std::map<UINT8, BONUS> e;
        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[5].ag = 0;
        perSym["coauTEN_____"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[5].ag = 0;
        perSym["coauJ_______"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[5].ag = 0;
        perSym["coauQ_______"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[5].ag = 0;
        perSym["coauK_______"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[5].ag = 0;
        perSym["coauA_______"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 15; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 50; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 350; e[5].ag = 0;
        perSym["coauPARCH___"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 15; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 50; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 350; e[5].ag = 0;
        perSym["coauVIAL____"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 40; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 150; e[5].ag = 0;
        perSym["coauGOLD____"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 75; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 1000; e[5].ag = 0;
        perSym["coauSCALES__"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 50; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 200; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5000; e[5].ag = 0;
        perSym["coauBIRD____"] = e;
        e.clear();

        m_Bonus_05_tmp[i] = perSym;
    }

    m_Bonus_05_tmp[7]["coauBIRD____"][5].coin = 80000; //100
    m_Bonus_05_tmp[8]["coauBIRD____"][5].coin = 80000; //200
    m_Bonus_05_tmp[9]["coauBIRD____"][5].coin = 80000; //500
    m_Bonus_05_tmp[9]["coauSCALES__"][5].coin = 80000; 

    m_Bonus_10_tmp = m_Bonus_05_tmp;


    int nSavedBetVal = 10;
    string data;
    PlayDB::GetInstance().LoadCheckPoint(m_strGameName, nSavedBetVal, m_nWinLine, m_strCheckPoint);
    if (nSavedBetVal == -1) {
        nSavedBetVal = 10;
    }
    if (m_nWinLine == -1) {
        m_nWinLine = 5;
    }

    BOOL start = FALSE;
    int idx = 0;
    for (int i = 0; i < m_vecBetSteps_05_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_05_tmp, i) < AT(m_vecBetSteps_05, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps_05, idx) == nSavedBetVal && m_nWinLine == 5) {
            m_nBetStep = idx;
        }

        m_Bonus_05[idx++] = m_Bonus_05_tmp[i];
        if (AT(m_vecBetSteps_05_tmp, i) == AT(m_vecBetSteps_05, m_vecBetSteps_05.size() - 1)) {
            break;
        }
    }
    start = FALSE;
    idx = 0;
    for (int i = 0; i < m_vecBetSteps_10_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_10_tmp, i) < AT(m_vecBetSteps_10, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps_10, idx) == nSavedBetVal && m_nWinLine == 10) {
            m_nBetStep = idx;
        }

        m_Bonus_10[idx++] = m_Bonus_10_tmp[i];
        if (AT(m_vecBetSteps_10_tmp, i) == AT(m_vecBetSteps_10, m_vecBetSteps_10.size() - 1)) {
            break;
        }
    }
    m_Bonus = (m_nWinLine == 5 ? m_Bonus_05 : m_Bonus_10);
    m_vecBetSteps = (m_nWinLine == 5 ? m_vecBetSteps_05 : m_vecBetSteps_10);
    PrintAllBonus();


}

UINT16 RgConvertusAurum::Run() {
    m_nCurrentReelPlan = (myRandom() & 1) ? 0 : 2;// (myRandom() % m_vecReelStripPlan.size());
    m_shCurrentReelStrip = static_cast<uint16_t>(std::stoi(AT(m_vecReelStripPlan, m_nCurrentReelPlan)));
    return m_shCurrentReelStrip;
}

void RgConvertusAurum::ChangeReelStrip(UINT16 NewReelPlan) {
    m_nCurrentReelPlan = NewReelPlan;
    m_shCurrentReelStrip = static_cast<uint16_t>(std::stoi(AT(m_vecReelStripPlan, m_nCurrentReelPlan)));
}

UINT16 RgConvertusAurum::SpinTime_MS() {
    UINT8 n = NumberOfScatter();
    if (n >= 3) {
        return 4000;
    }
    else if (n == 2 && NumberInCol(4) == FALSE) {
        return 4000;
    }
    return 2500;
}

BOOL RgConvertusAurum::NumberInCol(int col) {
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int k = 0; k < 3; k++) {
        std::string s = AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k);
        if (s == RgConvertusAurum_scatter) {
            return TRUE;
        }
    }
    return FALSE;
}

UINT8 RgConvertusAurum::NumberOfScatter() {
    UINT8 n = 0;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int col = 0; col < m_nReel; col++) {
        int k = 0;
        for (; k < 3; k++) {
            std::string s = AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k);
            if (s == RgConvertusAurum_scatter) {
                n++;
            }
        }
    }
    return n;
}

int RgConvertusAurum::LineSwapDelay(int WinIdx) {
    return 500;
}

UINT8 RgConvertusAurum::CardCount(std::string card) {
    int n = 0;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int col = 0; col < m_nReel; col++) {
        int k = 0;
        for (; k < 3; k++) {
            std::string s = AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k);
            if (s == card) {
                n++;
            }
        }
    }
    return n;
}

BOOL RgConvertusAurum::CauldRonInCol(int col) {
    return CardNumInCol(col, RgConvertusAurum_scatter);
}

UINT8 RgConvertusAurum::CardNumInCol(int col, std::string card) {
    int n = 0;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int k = 0; k < 3; k++) {
        std::string s = AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k);
        if (s == card) {
            n++;
        }
    }
    return n;
}

myVector<UINT8> RgConvertusAurum::Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) {
    m_bPrevSpinMatchedActive = FALSE;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    myVector<UINT8> result;
    if (bTest) {
        std::string matchSymbol = AT(m_vecSymbols, myRandom() % (m_vecSymbols.size() - 2));
        int line = (myRandom() % m_nWinLine);
        int weight = 1 + (myRandom() % 5);
        bool forceMatch = false;

        BOOL bForceFree = (myRandom() % 10 == 0);
        if (m_bFreeMode) {
            // in freemode
            for (UINT8 v : m_vForceMatchInFree) {
                if (v == m_nFreeModeGoneSpin) {
                    forceMatch = true;
                    break;
                }
            }
            if (forceMatch) {
                myVector<std::string> matchableSymbols;
                matchableSymbols.push_back("coauTEN_____");
                matchableSymbols.push_back("coauJ_______");
                matchableSymbols.push_back("coauQ_______");
                matchableSymbols.push_back("coauK_______");
                matchableSymbols.push_back("coauA_______");
                matchableSymbols.push_back("coauPARCH___");
                matchableSymbols.push_back("coauVIAL____");
                matchableSymbols.push_back("coauGOLD____");

                matchSymbol = AT(matchableSymbols, matchableSymbols.size() - 1);
                weight = 3;
            }
        }

        for (int i = 0; i < m_nReel; i++) {
            ReelStrip reelStrip = AT(reelSet, i);
            int len = reelStrip.size() - 3;

            int valid_i[0x100];
            int valid_count = 0;
            myVector<int> freeSymbols;
            for (int j = 0; j <= len; j++) {
                if (weight > i) {
                    if (matchSymbol == AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                else {
                    if (matchSymbol != AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                if (AT(reelStrip, j) == RgConvertusAurum_scatter && m_bFreeMode == FALSE && j > 0) {
                    freeSymbols.push_back(j);
                }
            }
            if (valid_count > 0) {
                int rand_index = myRandom() % valid_count;
                int chosen_i = valid_i[rand_index];
                result.push_back(chosen_i + 1);
            }
            else {
                result.push_back((myRandom() % (len - 1)) + 1);
            }

            if (bForceFree && m_bFreeMode == FALSE && (i == 1 || i == 2 || i == 3) && freeSymbols.size() > 0) {
                AT(result, result.size() - 1) =
                    AT(freeSymbols, myRandom() % freeSymbols.size()) - (1 + (myRandom() % 2)) + 1;
            }
        }
        if (m_bFreeMode) {
            if (forceMatch) {
                AT(result, 1 + (myRandom() % 3)) = 1;
            }
        }
    }
    else {
        result = _result;
        m_vWinResult = result;

        BOOL mmcode = mmcode_get_active_status();
        if (mmcode) {
            mmcode_set_deactive();
            if (m_bFreeMode == FALSE) {
                for (int j = 0; j < 5; j++) {
                    myVector<int> candidateIndices;
                    for (int i = 2; i < AT(reelSet, j).size() - 3; ++i) {
                        if (j%2 == 0 && AT(AT(reelSet, j), i) == RgConvertusAurum_scatter) {
                            int offset = myRandom() % 3;
                            int selectedIndex = i - 2 + offset;
                            candidateIndices.push_back(selectedIndex);
                        }
                        if (j%2 == 1 && AT(AT(reelSet, j), i) != RgConvertusAurum_scatter 
                                    && AT(AT(reelSet, j), i-2) != RgConvertusAurum_scatter
                                    && AT(AT(reelSet, j), i-1) != RgConvertusAurum_scatter
                                    && AT(AT(reelSet, j), i+1) != RgConvertusAurum_scatter
                                    && AT(AT(reelSet, j), i+2) != RgConvertusAurum_scatter) {
                            int offset = myRandom() % 3;
                            int selectedIndex = i - 2 + offset;
                            candidateIndices.push_back(selectedIndex);
                        }
                    }
                    if (!candidateIndices.empty()) {
#ifdef BIGBET_ACTIVE
                        int chosenIndex = AT(candidateIndices, (candidateIndices.size()<3?myRandom() % candidateIndices.size():myRandom() % 3));
#else
                        int chosenIndex = AT(candidateIndices, myRandom() % candidateIndices.size());
#endif
                        AT(result, j) = chosenIndex + 1;
                    }
                }
            }
        }
        
        /*if (m_bFreeMode) {
            if ((CardNumInCol(3, "coauJ_______") + CardNumInCol(3, "coauQ_______") + CardNumInCol(3, "coauK_______") + CardNumInCol(3, "coauA_______") + CardNumInCol(3, "coauTEN_____") + CardNumInCol(3, "coauGOLD____")) <= 1 &&
                (CardNumInCol(0, "coauJ_______") + CardNumInCol(0, "coauQ_______") + CardNumInCol(0, "coauK_______") + CardNumInCol(0, "coauA_______") + CardNumInCol(0, "coauTEN_____") + CardNumInCol(0, "coauGOLD____")) <= 1) {
                AT(result, 1 + (myRandom() % 2)) = 1;
            }
        }*/
    }

    m_vWinResult = result;
    AT(m_vecAdditionalParam, 0) = 0xFF;
    AT(m_vecAdditionalParam, 1) = 0xFF;
    if (Convertable()) {
        for (int i = 0; i < m_nReel; i++) {
            if (CardNumInCol(i, RgConvertusAurum_wild)) {
                AT(m_vecAdditionalParam, 0) = i;
                
                for (int row = 0; row < 3; row++) {
                    if (AT(AT(reelSet, i), AT(result, i) - 1 + row) == RgConvertusAurum_wild) {
                        AT(m_vecAdditionalParam, 1) = (1 << (2 - row));
                        break;
                    }
                }
                break;
            }
        }
    }
    
    normalMeter = 0;
    maxMeter = 0;
    BONUS totalBonus = {0, 0};
    for (int i = 0; i < m_nWinLine; i++) {
        int j = 1;
        UINT16 meter = ((UINT16)1 << (2 - g_match_lines_10_5[i][0]));
        std::string firstSymbol = AT(AT(reelSet, 0), AT(result, 0) - 1 + g_match_lines_10_5[i][0]);
        firstSymbol = ConvertedSymbol(firstSymbol);

        for (; j < m_nMaxMatch; j++) {
            std::string prev_symbol = AT(AT(reelSet, j - 1), AT(result, j - 1) - 1 + g_match_lines_10_5[i][j - 1]);
            std::string cur_symbol = AT(AT(reelSet, j), AT(result, j) - 1 + g_match_lines_10_5[i][j]);

            prev_symbol = ConvertedSymbol(prev_symbol);
            cur_symbol = ConvertedSymbol(cur_symbol);
            
            if (firstSymbol == RgConvertusAurum_wild) { // scatter
                firstSymbol = cur_symbol;
            }

            if (firstSymbol == cur_symbol || cur_symbol == RgConvertusAurum_wild) {
                meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
                continue;
            }
            break;
        }

        if (j < m_mapSymbolMinMatch[firstSymbol] || m_mapSymbolMinMatch[firstSymbol] == 0) {
            continue;
        }

        // monitor 2 meter
        std::string meterStr = m_mapSymbolMeterGoc[firstSymbol];
        size_t pos = meterStr.find('$');
        if (pos != std::string::npos) {
            meterStr = meterStr.replace(pos, 1, std::to_string(j));
        }

        WinMeter e;
        e.line = i;
        e.meter = meter;
        e.meter2 = g_GrafficObjList.Str2GOCID(meterStr);
        e.symbol = firstSymbol;
        e.weight = j;
        e.start = 0;
        e.bonus = m_Bonus[BetStep()][firstSymbol][j];
        e.sound = MAX_SOUND_IDS;

        totalBonus.coin += e.bonus.coin;
        totalBonus.ag += e.bonus.ag;

        if (e.meter2 != -1) {
            meters.push_back(e);
        }
        if (j == m_nMaxMatch) {
            maxMeter |= meter;
        }
        else {
            normalMeter |= meter;
        }
        if (bTest == FALSE) {
            m_bPrevSpinMatchedActive = TRUE;
        }
    }

    int nCauldRon = CardCount(RgConvertusAurum_scatter);
    if (nCauldRon >= 3) {
        bCanFreeMode = TRUE;

        UINT16 meter = 0;
        for (int i = 0; i < 3; i++) {
            for (int col = 0; col < m_nReel; col++) {
                std::string cur_symbol = AT(AT(reelSet, col), AT(result, col) - 1 + i);
                if (cur_symbol == RgConvertusAurum_scatter) {
                    meter |= ((UINT16)1 << (3 * col + (2 - i)));
                }
            }
        }

        WinMeter e;
        e.line = 10;
        e.meter = meter;
        e.meter2 = 0;
        e.symbol = RgConvertusAurum_scatter;
        e.weight = nCauldRon;
        e.start = 0;
        e.bonus = {0, 0};
        e.sound = MAX_SOUND_IDS;

        normalMeter |= meter;
        meters.push_back(e);
    }
    m_vWinMeters = meters;
    if (bTest == FALSE) {
        updateCheckPoint();

        if (totalBonus.coin > 0 || totalBonus.ag > 0) {
            if (m_bFreeMode) {
                m_nFreeModeTotalBonus.coin += totalBonus.coin;
                m_nFreeModeTotalBonus.ag += totalBonus.ag;
            }
            BonusSound = getSoundByID(WinSound(totalBonus.coin + totalBonus.ag * 1000));
        }
        else {
            BonusSound.duration = 0;
            BonusSound.soundID = MAX_SOUND_IDS;
        }
    }
    return result;
}

BOOL RgConvertusAurum::CanFreeMode() {
    if (CardCount(RgConvertusAurum_scatter) >= 3) {
        return TRUE;
    }
    return FALSE;
}

myVector<InterruptPacketData> RgConvertusAurum::EnterFreeGame(std::string check) {
    int n = 3;
    if (check == "") {
        n = CardCount(RgConvertusAurum_scatter);
    }

    m_bFreeMode = TRUE;
    m_nFreeModeTotalSpin = 10;
    if (n == 4) {
        m_nFreeModeTotalSpin = 15;
    }
    else if (n == 5) {
        m_nFreeModeTotalSpin = 30;
    }
    m_nFreeModeGoneSpin = 0;
    m_nFreeModeTotalBonus = {0, 0};

    myVector<InterruptPacketData> packets;
    if (check != "") {
        myVector<int> values = ParseCheckPoint(check, "F", 4);
        if (values.size() == 4) {
            m_nFreeModeTotalSpin = AT(values, 0);
            m_nFreeModeGoneSpin = AT(values, 1);
            m_nFreeModeTotalBonus.coin = AT(values, 2);
            m_nFreeModeTotalBonus.ag = AT(values, 3);
            UINT8 gone = (m_nFreeModeGoneSpin ? m_nFreeModeGoneSpin : 1);

            packets.push_back({ 0, 0, {0x01, 0x02, 0x31, 0x00, 0x04, 0x00, 0xbb, 0x13, 0xba, gone, 0x00, m_nFreeModeTotalSpin, 0x00, 0x04} });
            return packets;
        }
    }
    else {
        updateCheckPoint();
    }

    // select force convert match -->
    m_vForceMatchInFree.clear();
    int k = m_nFreeModeTotalSpin / 4;
    int arr[30] = { 0 };

    // initialize array [1..n]
    for (int i = 0; i < m_nFreeModeTotalSpin; i++) {
        arr[i] = i + 1;
    }
    // Fisher�Yates shuffle
    for (int i = m_nFreeModeTotalSpin - 1; i > 0; i--) {
        int j = myRandom() % (i + 1);
        int tmp = arr[i];
        arr[i] = arr[j];
        arr[j] = tmp;
    }
    // take first n/3 members
    for (int i = 0; i < k; i++) {
        m_vForceMatchInFree.push_back(arr[i]);
    }
    // <--
    UINT8 gone = m_nFreeModeGoneSpin > 1 ? (m_nFreeModeGoneSpin - 1) : m_nFreeModeGoneSpin;
    // stop all sound
    packets.push_back({
        0,
        0,
        {0x01, 0x02, 0x35, 0x00, 0x00, 0x00, 0x04} });

    // show freemode dialog
    packets.push_back({ 
        0, 4000, 
        {0x01, 0x02, 0x30, 0x00, 0xbb, 0x13, 0x02, 0x00, m_nFreeModeTotalSpin, 0x00, 1, 0x00, 0x00, 0x00, 0xab, 0x04} });

    // hide freemode intro dialog
    packets.push_back({
        0,
        0,
        {0x01, 0x02, 0x30, 0x00, 0xbb, 0x13, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xac, 0x04} });
    return packets;
}

myVector<InterruptPacketData> RgConvertusAurum::InterruptBeforeSpin() {
    myVector<InterruptPacketData> packets;
    if (!m_bFreeMode) {
        return packets;
    }
    m_nFreeModeGoneSpin++;
    updateCheckPoint();

    UINT8 gone = (m_nFreeModeGoneSpin ? m_nFreeModeGoneSpin : 1);

    // display total & remain free spin count
    packets.push_back({
        0,
        0,
        {
            0x01, 0x02, 0x30, 0x00, 0xbb, 0x13, gone, 0x00, m_nFreeModeTotalSpin, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa5, 0x04
        }
        });
    return packets;
}

myVector<InterruptPacketData> RgConvertusAurum::InterruptAfterMoveBonus(BOOL& EndFree) {
    myVector<InterruptPacketData> packets;
    if (m_nFreeModeGoneSpin >= m_nFreeModeTotalSpin) {
        EndFree = TRUE;
        m_bFreeMode = FALSE;
        
        // return to main game
        packets.push_back({
             0,
             0,
             {0x01, 0x02, 0x30, 0x00, 0xbb, 0x13, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa4, 0x04} });
        // show freemode result dialog
        packets.push_back({
             0,
             3000,
             {0x01, 0x02, 0x30, 0x00, 0xbb, 0x13, 0x00, 0x00, 
             static_cast<BYTE>(m_nFreeModeTotalBonus.coin & 0xFF), 
             static_cast<BYTE>((m_nFreeModeTotalBonus.coin >> 8) & 0xFF), 
             static_cast<BYTE>((m_nFreeModeTotalBonus.coin >> 16) & 0xFF),
             static_cast<BYTE>((m_nFreeModeTotalBonus.coin >> 24) & 0xFF),
             0x0a, 0x00, 0xab, 0x04} });

        // hide result dialog
        packets.push_back({
             0,
             0,
             {0x01, 0x02, 0x30, 0x00, 0xbb, 0x13, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xac, 0x04} });

        updateCheckPoint();
        return packets;
    }
    EndFree = FALSE;
    //m_nFreeModeGoneSpin++;
    updateCheckPoint();
    return packets;
}

myVector<InterruptPacketData> RgConvertusAurum::InterruptAfterSpin() {
    myVector<InterruptPacketData> packets;
    if (Convertable()) {
        // convert symbols
        packets.push_back({
            0,
            5000,
            {0x06, 0xBB, 0x13, 0x01, 0x02, 0x31, 0x00, 0x00, 0x00, 0xBB, 0x13, 0xCE, 0x04} });

    }
    return packets;
}

BOOL RgConvertusAurum::Convertable() {
    if (m_bFreeMode == FALSE) {
        return FALSE;
    }
    
    if (CardCount(RgConvertusAurum_wild) == 0) {
        return FALSE;
    }
    if (CardCount("coauTEN_____") == 0 &&
        CardCount("coauJ_______") == 0 &&
        CardCount("coauQ_______") == 0 &&
        CardCount("coauK_______") == 0 &&
        CardCount("coauA_______") == 0) {
        return FALSE;
    }
    return TRUE;
}

std::string RgConvertusAurum::ConvertedSymbol(std::string card) {
    if (!Convertable()) {
        return card;
    }
    if (card == "coauTEN_____" ||
        card == "coauJ_______" ||
        card == "coauQ_______" ||
        card == "coauK_______" ||
        card == "coauA_______") {
        return "coauGOLD____";
    }
    return card;
}

myVector<InterruptPacketData> RgConvertusAurum::MousePressed(MousePosition p) {
    myVector<InterruptPacketData> packets;

    MousePosition a{
       {RgConvertusAurum_MP_ChangeLine_LB_x_reel, RgConvertusAurum_MP_ChangeLine_LB_x_pos },
       {RgConvertusAurum_MP_ChangeLine_LB_y_row, RgConvertusAurum_MP_ChangeLine_LB_y_pos }
    };
    MousePosition b{
        {RgConvertusAurum_MP_ChangeLine_RT_x_reel, RgConvertusAurum_MP_ChangeLine_RT_x_pos },
        {RgConvertusAurum_MP_ChangeLine_RT_y_row, RgConvertusAurum_MP_ChangeLine_RT_y_pos }
    };
    if (IsMouseWithin(p, a, b)) {
        m_nWinLine = (m_nWinLine == 5) ? 10 : 5;
        if (m_bPrevSpinMatchedActive) {
            // hide win lines
            packets.push_back({ 0, 0, {0x01, 0x02, 0x31, 0x00, 0x01, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x02, 0x00, 0x04} });
            m_bPrevSpinMatchedActive = FALSE;
        }
        UINT16 newBetValue = 0;
        if (m_nWinLine == 5) {
            m_Bonus = m_Bonus_05;
            m_vecBetSteps = m_vecBetSteps_05;
            newBetValue = AT(m_vecBetSteps_10, m_nBetStep) / 2;
            // lines
            packets.push_back({ 0, 0, {0x01, 0x02, 0x31, 0x00, 0x04, 0x00,
                static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x9d, 0x1f, 0x00, 0x00, 0x00, 0x04} });
        }
        else {
            m_Bonus = m_Bonus_10;
            m_vecBetSteps = m_vecBetSteps_10;
            newBetValue = AT(m_vecBetSteps_05, m_nBetStep) * 2;
            // lines
            packets.push_back({ 0, 0, {0x01, 0x02, 0x31, 0x00, 0x04, 0x00, static_cast<BYTE>(m_nGameID & 0xFF),
                static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x9d, 0xff, 0x03, 0x00, 0x00, 0x04} });
        }
        BOOL flag = FALSE;
        for (int i = 0; i < m_vecBetSteps.size(); i++) {
            if (AT(m_vecBetSteps, i) == newBetValue) {
                m_nBetStep = i;
                flag = TRUE;
                break;
            }
        }
        if (flag == FALSE) {
            m_nBetStep = 0;
        }

        // play button sound
        packets.push_back({ 0, 0, {0x01, 0x02, 0x34, 0x00, 0xf7, 0x00, 0x04} });
        // change line button
        packets.push_back({ 0, 0, {0x01, 0x02, 0x28, 0x00,
            static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), static_cast<BYTE>(m_nWinLine), 0x00, 0x00, 0x00, 0x04} });
        // set bet
        UINT16 bet = AT(m_vecBetSteps, m_nBetStep) / 5;
        packets.push_back({ 0, 0, {0x01, 0x02, 0x30, 0x00, 0x25, 0x53, 
            static_cast<BYTE>(bet & 0xFF), static_cast<BYTE>((bet >> 8) & 0xFF), 
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04, 0x04} });
    }
    return packets;
}

myVector<UINT8> RgConvertusAurum::ShowTotalWinLines(myVector<WinMeter> SpinMeters) {
    myVector<uint8_t> packet = {
        0x06, 0x30, 0x59, 0x01, 0x02, 0x31, 0x00,
        0x0F, 0x00,  // Placeholder for length 
        0x0F, 0x11, // GameID
        0x9C, 0x19, 0x01
    };
    myVector<UINT8> TotalMatch;
    for (int i = 0; i < SpinMeters.size(); i++) {
        if (AT(SpinMeters, i).line == 0xFF) { // clear after convert action
            TotalMatch.clear();
            continue;
        }
        TotalMatch.push_back(AT(SpinMeters, i).line);
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter >> 8) & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter2 & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter2 >> 8) & 0xFF));
    }
    if (TotalMatch.size() < 10) {
        myVector<UINT8> _;
        return _;
    }
    UINT16 pktLen = 1 + (TotalMatch.size() / 5) * 7;
    AT(packet, 7) = static_cast<BYTE>(pktLen & 0xFF);
    AT(packet, 8) = static_cast<BYTE>((pktLen >> 8) & 0xFF);
    AT(packet, 9) = static_cast<BYTE>(m_nGameID & 0xFF);
    AT(packet, 10) = static_cast<BYTE>((m_nGameID >> 8) & 0xFF);
    int entryCount = static_cast<int>(TotalMatch.size() / 5);
    for (int i = 0; i < entryCount; ++i) {
        packet.push_back(AT(TotalMatch, i * 5 + 0)); // Line
        packet.push_back(AT(TotalMatch, i * 5 + 1)); // Meter low byte
        packet.push_back(AT(TotalMatch, i * 5 + 2)); // Meter high byte
        packet.push_back(AT(TotalMatch, i * 5 + 3)); // Meter2 low byte
        packet.push_back(AT(TotalMatch, i * 5 + 4)); // Meter2 high byte
        packet.push_back(0x01);      // Status or flag 1
        packet.push_back(0x01);      // Status or flag 2
    }
    // Mark the end of the packet
    packet.back() = 0x04;
    return packet;
}

BOOL RgConvertusAurum::SelectedableReelsInFreeGame(myVector<UINT8> result) {
    if (m_bFreeMode == FALSE) {
        return TRUE;
    }
    myVector<UINT8> cp = m_vWinResult;
    m_vWinResult = result;
    int n = CardCount(RgConvertusAurum_scatter);
    m_vWinResult = cp;
    if (n >= 3) {
        return FALSE;
    }
    return TRUE;
}

void RgConvertusAurum::updateCheckPoint() {
    std::ostringstream oss;
    oss << " P" << m_nCurrentReelPlan
        << " B"
        << static_cast<int>(AT(m_vWinResult, 0)) << ":"
        << static_cast<int>(AT(m_vWinResult, 1)) << ":"
        << static_cast<int>(AT(m_vWinResult, 2)) << ":"
        << static_cast<int>(AT(m_vWinResult, 3)) << ":"
        << static_cast<int>(AT(m_vWinResult, 4)) << " ";

    if (m_bFreeMode) {
        oss << " F"
            << static_cast<int>(m_nFreeModeTotalSpin) << ":"
            << static_cast<int>(m_nFreeModeGoneSpin) << ":"
            << static_cast<int>(m_nFreeModeTotalBonus.coin) << ":"
            << static_cast<int>(m_nFreeModeTotalBonus.ag) << " ";
    }
    m_strCheckPoint = oss.str();
}