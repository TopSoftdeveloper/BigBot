#include "stdafx.h"
#include "RgMerkurMagnus.h"

#define RgMerkurMagnus_top "SUNBS"
RgMerkurMagnus::RgMerkurMagnus() {
    m_nReel = 5;
    m_nWinLine = 5;
    m_nMaxMatch = 5;
    m_nBetStep = 0;

    m_strGameName = "RgMerkurMagnus";

    myVector<UINT16> m_vecBetSteps_tmp;
    m_vecBetSteps_tmp.push_back(5);
    m_vecBetSteps_tmp.push_back(10);
    m_vecBetSteps_tmp.push_back(20);
    m_vecBetSteps_tmp.push_back(30);
    m_vecBetSteps_tmp.push_back(40);
    m_vecBetSteps_tmp.push_back(50);
    m_vecBetSteps_tmp.push_back(60);
    m_vecBetSteps_tmp.push_back(80);
    m_vecBetSteps_tmp.push_back(100);
    m_vecBetSteps_tmp.push_back(150);
    m_vecBetSteps_tmp.push_back(200);
#ifdef BIGBET_ACTIVE
    m_vecBetSteps_tmp.push_back(500);
    m_vecBetSteps_tmp.push_back(1000);
#endif
    LoadBets();

    m_vecSymbols.push_back("SUNBS");
    m_vecSymbols.push_back("GRABS");
    m_vecSymbols.push_back("MELBS");
    m_vecSymbols.push_back("PLUBS");
    m_vecSymbols.push_back("ORABS");
    m_vecSymbols.push_back("LEMBS");
    m_vecSymbols.push_back("CHEBS");

    m_mapSymbolMinMatch["SUNBS"] = 3;
    m_mapSymbolMinMatch["GRABS"] = 3;
    m_mapSymbolMinMatch["MELBS"] = 3;
    m_mapSymbolMinMatch["PLUBS"] = 3;
    m_mapSymbolMinMatch["ORABS"] = 3;
    m_mapSymbolMinMatch["LEMBS"] = 3;
    m_mapSymbolMinMatch["CHEBS"] = 2;

    m_mapSymbolMeterGoc["SUNBS"] = "sun$xBs";
    m_mapSymbolMeterGoc["GRABS"] = "gra$xBS";
    m_mapSymbolMeterGoc["MELBS"] = "me$xlBS";
    m_mapSymbolMeterGoc["PLUBS"] = "plu$xBS";
    m_mapSymbolMeterGoc["ORABS"] = "ora$xBS";
    m_mapSymbolMeterGoc["LEMBS"] = "lem$xBS";
    m_mapSymbolMeterGoc["CHEBS"] = "che$xBS";

    m_vecWinLines.push_back("WinL1MEMA");
    m_vecWinLines.push_back("WinL2MEMA");
    m_vecWinLines.push_back("WinL3MEMA");
    m_vecWinLines.push_back("WinL4MEMA");
    m_vecWinLines.push_back("WinL5MEMA");

    m_vecLineSounds.push_back(SMP_MEMA_WinPart_1);
    m_vecLineSounds.push_back(SMP_MEMA_WinPart_2);
    m_vecLineSounds.push_back(SMP_MEMA_WinPart_3);
    m_vecLineSounds.push_back(SMP_MEMA_WinPart_4);
    m_vecLineSounds.push_back(SMP_MEMA_WinPart_5);

    m_vecWinSounds.push_back(SMP_MEMA_WinTiny);
    m_vecWinSounds.push_back(SMP_MEMA_WinVerySmall);
    m_vecWinSounds.push_back(SMP_MEMA_WinSmall);
    m_vecWinSounds.push_back(SMP_MEMA_WinMedium);
    m_vecWinSounds.push_back(SMP_MEMA_WinBig);
    m_vecWinSounds.push_back(SMP_MEMA_WinHuge);
    m_vecWinSounds.push_back(SMP_MEMA_WinTop);

    m_vecReelStripPlan.push_back("Walz1Aq94BS");
    m_vecReelStripPlan.push_back("Walz1Bq94BS");
    m_vecReelStripPlan.push_back("Walz1Aq96BS");

    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));

    char* cfrtReelStrip[] = {
        //"ORABS,ORABS,PLUBS,PLUBS,PLUBS,MELBS,MELBS,CHEBS,MELBS,CHEBS,CHEBS,CHEBS,LEMBS,CHEBS,LEMBS,LEMBS,LEMBS,PLUBS,PLUBS,GRABS,GRABS,PLUBS,GRABS,PLUBS,PLUBS,PLUBS,MELBS,MELBS,ORABS,MELBS,ORABS,ORABS,SUNBS,ORABS,ORABS,SUNBS,ORABS,ORABS,ORABS,SUNBS",
        //"MELBS,MELBS,PLUBS,PLUBS,PLUBS,CHEBS,CHEBS,CHEBS,ORABS,ORABS,CHEBS,ORABS,ORABS,ORABS,ORABS,GRABS,ORABS,GRABS,GRABS,PLUBS,PLUBS,CHEBS,PLUBS,PLUBS,SUNBS,PLUBS,PLUBS,ORABS,ORABS,ORABS,MELBS,MELBS,LEMBS,LEMBS,SUNBS,LEMBS,LEMBS,MELBS,MELBS,SUNBS",
        //"CHEBS,CHEBS,LEMBS,LEMBS,LEMBS,CHEBS,CHEBS,CHEBS,GRABS,CHEBS,GRABS,GRABS,LEMBS,LEMBS,LEMBS,LEMBS,MELBS,LEMBS,LEMBS,MELBS,MELBS,ORABS,ORABS,ORABS,PLUBS,PLUBS,PLUBS,LEMBS,LEMBS,GRABS,GRABS,SUNBS,GRABS,GRABS,CHEBS,CHEBS,SUNBS,CHEBS,CHEBS,SUNBS",
        //"PLUBS,PLUBS,PLUBS,LEMBS,LEMBS,LEMBS,PLUBS,PLUBS,GRABS,GRABS,PLUBS,GRABS,GRABS,LEMBS,LEMBS,SUNBS,LEMBS,LEMBS,PLUBS,PLUBS,LEMBS,PLUBS,LEMBS,LEMBS,CHEBS,CHEBS,CHEBS,MELBS,CHEBS,MELBS,MELBS,ORABS,ORABS,SUNBS,ORABS,ORABS,ORABS,PLUBS,PLUBS,SUNBS",
        //"ORABS,ORABS,ORABS,LEMBS,LEMBS,LEMBS,CHEBS,LEMBS,LEMBS,CHEBS,CHEBS,ORABS,ORABS,ORABS,ORABS,GRABS,ORABS,GRABS,GRABS,LEMBS,LEMBS,SUNBS,LEMBS,LEMBS,PLUBS,PLUBS,SUNBS,PLUBS,PLUBS,PLUBS,MELBS,PLUBS,MELBS,MELBS,CHEBS,CHEBS,CHEBS,ORABS,ORABS,SUNBS",

        //"GRABS,GRABS,LEMBS,LEMBS,LEMBS,PLUBS,LEMBS,PLUBS,PLUBS,CHEBS,CHEBS,LEMBS,LEMBS,PLUBS,LEMBS,PLUBS,PLUBS,LEMBS,LEMBS,LEMBS,PLUBS,PLUBS,MELBS,PLUBS,MELBS,MELBS,ORABS,ORABS,SUNBS,ORABS,ORABS,CHEBS,CHEBS,CHEBS,GRABS,GRABS,SUNBS,GRABS,GRABS,SUNBS",
        //"LEMBS,LEMBS,PLUBS,PLUBS,PLUBS,CHEBS,CHEBS,LEMBS,LEMBS,CHEBS,CHEBS,ORABS,ORABS,GRABS,ORABS,GRABS,ORABS,GRABS,GRABS,PLUBS,PLUBS,CHEBS,PLUBS,PLUBS,SUNBS,PLUBS,PLUBS,GRABS,GRABS,MELBS,MELBS,LEMBS,MELBS,LEMBS,LEMBS,LEMBS,SUNBS,LEMBS,LEMBS,SUNBS",
        //"CHEBS,CHEBS,ORABS,ORABS,CHEBS,CHEBS,SUNBS,CHEBS,CHEBS,MELBS,MELBS,ORABS,ORABS,MELBS,MELBS,ORABS,MELBS,ORABS,ORABS,MELBS,MELBS,LEMBS,LEMBS,LEMBS,PLUBS,PLUBS,PLUBS,ORABS,ORABS,ORABS,GRABS,ORABS,GRABS,GRABS,CHEBS,CHEBS,SUNBS,CHEBS,CHEBS,SUNBS",
        //"PLUBS,PLUBS,ORABS,PLUBS,ORABS,ORABS,PLUBS,PLUBS,MELBS,MELBS,PLUBS,MELBS,MELBS,ORABS,ORABS,SUNBS,ORABS,ORABS,PLUBS,PLUBS,ORABS,PLUBS,ORABS,ORABS,CHEBS,CHEBS,CHEBS,GRABS,CHEBS,GRABS,GRABS,LEMBS,LEMBS,SUNBS,LEMBS,LEMBS,LEMBS,PLUBS,PLUBS,SUNBS",
        //"ORABS,ORABS,LEMBS,ORABS,LEMBS,LEMBS,LEMBS,CHEBS,LEMBS,LEMBS,CHEBS,CHEBS,ORABS,ORABS,ORABS,GRABS,ORABS,GRABS,GRABS,LEMBS,LEMBS,SUNBS,LEMBS,LEMBS,PLUBS,PLUBS,SUNBS,PLUBS,PLUBS,PLUBS,MELBS,PLUBS,MELBS,MELBS,CHEBS,CHEBS,CHEBS,ORABS,ORABS,SUNBS",

        "MELBS,MELBS,CHEBS,CHEBS,LEMBS,LEMBS,LEMBS,PLUBS,LEMBS,PLUBS,PLUBS,ORABS,PLUBS,ORABS,PLUBS,PLUBS,ORABS,ORABS,ORABS,MELBS,MELBS,PLUBS,PLUBS,PLUBS,GRABS,GRABS,SUNBS,GRABS,GRABS,CHEBS,CHEBS,CHEBS,ORABS,ORABS,SUNBS,ORABS,ORABS,MELBS,MELBS,SUNBS",
        "MELBS,MELBS,PLUBS,PLUBS,PLUBS,CHEBS,CHEBS,CHEBS,ORABS,ORABS,CHEBS,ORABS,ORABS,GRABS,ORABS,GRABS,ORABS,GRABS,GRABS,PLUBS,PLUBS,CHEBS,PLUBS,PLUBS,SUNBS,PLUBS,PLUBS,ORABS,ORABS,ORABS,MELBS,MELBS,LEMBS,LEMBS,SUNBS,LEMBS,LEMBS,MELBS,MELBS,SUNBS",
        "CHEBS,CHEBS,LEMBS,LEMBS,LEMBS,CHEBS,CHEBS,CHEBS,GRABS,CHEBS,GRABS,GRABS,LEMBS,LEMBS,LEMBS,LEMBS,MELBS,LEMBS,LEMBS,MELBS,MELBS,ORABS,ORABS,ORABS,PLUBS,PLUBS,PLUBS,LEMBS,LEMBS,GRABS,GRABS,SUNBS,GRABS,GRABS,CHEBS,CHEBS,SUNBS,CHEBS,CHEBS,SUNBS",
        "PLUBS,PLUBS,PLUBS,LEMBS,LEMBS,LEMBS,PLUBS,PLUBS,GRABS,GRABS,PLUBS,GRABS,GRABS,LEMBS,LEMBS,SUNBS,LEMBS,LEMBS,PLUBS,PLUBS,LEMBS,PLUBS,LEMBS,LEMBS,CHEBS,CHEBS,CHEBS,MELBS,CHEBS,MELBS,MELBS,ORABS,ORABS,SUNBS,ORABS,ORABS,ORABS,PLUBS,PLUBS,SUNBS",
        "ORABS,ORABS,ORABS,LEMBS,LEMBS,LEMBS,CHEBS,LEMBS,LEMBS,CHEBS,CHEBS,ORABS,ORABS,ORABS,ORABS,GRABS,ORABS,GRABS,GRABS,LEMBS,LEMBS,SUNBS,LEMBS,LEMBS,PLUBS,PLUBS,SUNBS,PLUBS,PLUBS,PLUBS,MELBS,PLUBS,MELBS,MELBS,CHEBS,CHEBS,CHEBS,ORABS,ORABS,SUNBS",

        "MELBS,MELBS,LEMBS,LEMBS,LEMBS,PLUBS,LEMBS,PLUBS,PLUBS,CHEBS,CHEBS,LEMBS,LEMBS,PLUBS,LEMBS,PLUBS,PLUBS,LEMBS,LEMBS,GRABS,GRABS,PLUBS,PLUBS,PLUBS,GRABS,GRABS,SUNBS,GRABS,GRABS,CHEBS,CHEBS,CHEBS,ORABS,ORABS,SUNBS,ORABS,ORABS,MELBS,MELBS,SUNBS",
        "MELBS,MELBS,PLUBS,PLUBS,PLUBS,CHEBS,CHEBS,LEMBS,LEMBS,CHEBS,CHEBS,ORABS,ORABS,GRABS,ORABS,GRABS,ORABS,GRABS,GRABS,PLUBS,PLUBS,CHEBS,PLUBS,PLUBS,SUNBS,PLUBS,PLUBS,LEMBS,LEMBS,LEMBS,GRABS,GRABS,LEMBS,LEMBS,SUNBS,LEMBS,LEMBS,MELBS,MELBS,SUNBS",
        "CHEBS,CHEBS,ORABS,ORABS,CHEBS,CHEBS,SUNBS,CHEBS,CHEBS,MELBS,MELBS,ORABS,ORABS,MELBS,MELBS,ORABS,MELBS,ORABS,ORABS,MELBS,MELBS,LEMBS,LEMBS,LEMBS,PLUBS,PLUBS,PLUBS,ORABS,ORABS,ORABS,GRABS,ORABS,GRABS,GRABS,CHEBS,CHEBS,SUNBS,CHEBS,CHEBS,SUNBS",
        "PLUBS,PLUBS,ORABS,PLUBS,ORABS,ORABS,PLUBS,PLUBS,MELBS,MELBS,PLUBS,MELBS,MELBS,ORABS,ORABS,SUNBS,ORABS,ORABS,PLUBS,PLUBS,ORABS,PLUBS,ORABS,ORABS,CHEBS,CHEBS,CHEBS,GRABS,CHEBS,GRABS,GRABS,LEMBS,LEMBS,SUNBS,LEMBS,LEMBS,LEMBS,PLUBS,PLUBS,SUNBS",
        "ORABS,ORABS,LEMBS,ORABS,LEMBS,LEMBS,LEMBS,CHEBS,LEMBS,LEMBS,CHEBS,CHEBS,ORABS,ORABS,ORABS,GRABS,ORABS,GRABS,GRABS,LEMBS,LEMBS,SUNBS,LEMBS,LEMBS,PLUBS,PLUBS,SUNBS,PLUBS,PLUBS,PLUBS,MELBS,PLUBS,MELBS,MELBS,CHEBS,CHEBS,CHEBS,ORABS,ORABS,SUNBS",

        "MELBS,MELBS,CHEBS,CHEBS,LEMBS,LEMBS,LEMBS,PLUBS,LEMBS,PLUBS,PLUBS,ORABS,PLUBS,ORABS,PLUBS,PLUBS,ORABS,ORABS,ORABS,MELBS,MELBS,PLUBS,PLUBS,PLUBS,GRABS,GRABS,SUNBS,GRABS,GRABS,CHEBS,CHEBS,CHEBS,ORABS,ORABS,SUNBS,ORABS,ORABS,MELBS,MELBS,SUNBS",
        "MELBS,MELBS,PLUBS,PLUBS,PLUBS,CHEBS,CHEBS,CHEBS,ORABS,ORABS,CHEBS,ORABS,ORABS,GRABS,ORABS,GRABS,ORABS,GRABS,GRABS,PLUBS,PLUBS,CHEBS,PLUBS,PLUBS,SUNBS,PLUBS,PLUBS,ORABS,ORABS,ORABS,MELBS,MELBS,LEMBS,LEMBS,SUNBS,LEMBS,LEMBS,MELBS,MELBS,SUNBS",
        "CHEBS,CHEBS,LEMBS,LEMBS,LEMBS,CHEBS,CHEBS,CHEBS,GRABS,CHEBS,GRABS,GRABS,LEMBS,LEMBS,MELBS,LEMBS,MELBS,LEMBS,LEMBS,MELBS,MELBS,ORABS,ORABS,ORABS,PLUBS,PLUBS,PLUBS,LEMBS,LEMBS,GRABS,GRABS,SUNBS,GRABS,GRABS,CHEBS,CHEBS,SUNBS,CHEBS,CHEBS,SUNBS",
        "PLUBS,PLUBS,PLUBS,LEMBS,LEMBS,LEMBS,PLUBS,PLUBS,GRABS,GRABS,PLUBS,GRABS,GRABS,LEMBS,LEMBS,SUNBS,LEMBS,LEMBS,PLUBS,PLUBS,LEMBS,PLUBS,LEMBS,LEMBS,CHEBS,CHEBS,CHEBS,MELBS,CHEBS,MELBS,MELBS,ORABS,ORABS,SUNBS,ORABS,ORABS,ORABS,PLUBS,PLUBS,SUNBS",
        "ORABS,ORABS,ORABS,LEMBS,LEMBS,LEMBS,CHEBS,LEMBS,LEMBS,CHEBS,CHEBS,ORABS,ORABS,ORABS,ORABS,GRABS,ORABS,GRABS,GRABS,LEMBS,LEMBS,SUNBS,LEMBS,LEMBS,PLUBS,PLUBS,SUNBS,PLUBS,PLUBS,PLUBS,MELBS,PLUBS,MELBS,MELBS,CHEBS,CHEBS,CHEBS,ORABS,ORABS,SUNBS",

        //"MELBS,MELBS,LEMBS,LEMBS,LEMBS,PLUBS,LEMBS,PLUBS,PLUBS,CHEBS,CHEBS,LEMBS,LEMBS,PLUBS,LEMBS,PLUBS,PLUBS,LEMBS,LEMBS,GRABS,GRABS,PLUBS,PLUBS,PLUBS,GRABS,GRABS,SUNBS,GRABS,GRABS,CHEBS,CHEBS,CHEBS,ORABS,ORABS,SUNBS,ORABS,ORABS,MELBS,MELBS,SUNBS",
        //"MELBS,MELBS,PLUBS,PLUBS,PLUBS,CHEBS,CHEBS,LEMBS,LEMBS,CHEBS,CHEBS,ORABS,ORABS,GRABS,ORABS,GRABS,ORABS,GRABS,GRABS,PLUBS,PLUBS,CHEBS,PLUBS,PLUBS,SUNBS,PLUBS,PLUBS,LEMBS,LEMBS,LEMBS,GRABS,GRABS,LEMBS,LEMBS,SUNBS,LEMBS,LEMBS,MELBS,MELBS,SUNBS",
        //"CHEBS,CHEBS,ORABS,ORABS,ORABS,CHEBS,CHEBS,CHEBS,MELBS,CHEBS,MELBS,MELBS,ORABS,ORABS,MELBS,ORABS,MELBS,ORABS,ORABS,MELBS,MELBS,LEMBS,LEMBS,LEMBS,PLUBS,PLUBS,PLUBS,ORABS,ORABS,GRABS,GRABS,SUNBS,GRABS,GRABS,CHEBS,CHEBS,SUNBS,CHEBS,CHEBS,SUNBS",
        //"PLUBS,PLUBS,ORABS,PLUBS,ORABS,ORABS,PLUBS,PLUBS,MELBS,MELBS,PLUBS,MELBS,MELBS,ORABS,ORABS,SUNBS,ORABS,ORABS,PLUBS,PLUBS,ORABS,PLUBS,ORABS,ORABS,CHEBS,CHEBS,CHEBS,GRABS,CHEBS,GRABS,GRABS,LEMBS,LEMBS,SUNBS,LEMBS,LEMBS,LEMBS,PLUBS,PLUBS,SUNBS",
        //"ORABS,ORABS,LEMBS,ORABS,LEMBS,LEMBS,LEMBS,CHEBS,LEMBS,LEMBS,CHEBS,CHEBS,ORABS,ORABS,ORABS,GRABS,ORABS,GRABS,GRABS,LEMBS,LEMBS,SUNBS,LEMBS,LEMBS,PLUBS,PLUBS,SUNBS,PLUBS,PLUBS,PLUBS,MELBS,PLUBS,MELBS,MELBS,CHEBS,CHEBS,CHEBS,ORABS,ORABS,SUNBS",

        //"MELBS,MELBS,CHEBS,CHEBS,LEMBS,LEMBS,LEMBS,PLUBS,LEMBS,PLUBS,PLUBS,PLUBS,ORABS,PLUBS,ORABS,ORABS,ORABS,GRABS,GRABS,SUNBS,GRABS,GRABS,CHEBS,CHEBS,CHEBS,ORABS,ORABS,SUNBS,ORABS,ORABS,MELBS,MELBS,SUNBS",
        //"MELBS,MELBS,CHEBS,CHEBS,CHEBS,ORABS,ORABS,CHEBS,ORABS,ORABS,ORABS,GRABS,ORABS,GRABS,GRABS,PLUBS,PLUBS,PLUBS,CHEBS,PLUBS,PLUBS,SUNBS,PLUBS,PLUBS,MELBS,MELBS,LEMBS,LEMBS,LEMBS,SUNBS,LEMBS,LEMBS,MELBS,MELBS,SUNBS",
        //"CHEBS,CHEBS,CHEBS,GRABS,CHEBS,GRABS,GRABS,LEMBS,LEMBS,LEMBS,MELBS,LEMBS,MELBS,MELBS,ORABS,ORABS,ORABS,PLUBS,PLUBS,PLUBS,LEMBS,LEMBS,GRABS,GRABS,SUNBS,GRABS,GRABS,CHEBS,CHEBS,SUNBS",
        //"PLUBS,PLUBS,PLUBS,LEMBS,PLUBS,LEMBS,LEMBS,LEMBS,GRABS,GRABS,PLUBS,GRABS,GRABS,LEMBS,LEMBS,SUNBS,LEMBS,LEMBS,CHEBS,CHEBS,CHEBS,MELBS,CHEBS,MELBS,MELBS,ORABS,ORABS,SUNBS,ORABS,ORABS,ORABS,PLUBS,PLUBS,SUNBS",
        //"ORABS,ORABS,LEMBS,LEMBS,LEMBS,CHEBS,LEMBS,LEMBS,CHEBS,CHEBS,CHEBS,ORABS,ORABS,ORABS,GRABS,ORABS,GRABS,GRABS,LEMBS,LEMBS,SUNBS,LEMBS,LEMBS,PLUBS,PLUBS,SUNBS,PLUBS,PLUBS,PLUBS,MELBS,PLUBS,MELBS,MELBS,ORABS,ORABS,SUNBS",
    };

    int idx = 0;
    for (int i = 0; i < m_vecReelStripPlan.size(); i++) {
        ReelSet set;
        for (int j = 0; j < m_nReel; j++) {
            ReelStrip strip;
            std::stringstream ss(cfrtReelStrip[idx]);
            std::string item;
            while (std::getline(ss, item, ',')) {
                strip.push_back(item);
            }
            set.push_back(strip);
            idx++;
        }
        m_vecReelStripSets.push_back(set);
    }

    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_tmp;

    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        std::map<std::string, std::map<UINT8, BONUS>> perSym;
        std::map<UINT8, BONUS> e;
        e[2].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5; e[2].ag = 0;
        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 200; e[5].ag = 0;
        perSym["CHEBS"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 250; e[5].ag = 0;
        perSym["LEMBS"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 250; e[5].ag = 0;
        perSym["ORABS"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 250; e[5].ag = 0;
        perSym["PLUBS"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 250; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 1000; e[5].ag = 0;
        perSym["MELBS"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 250; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 1000; e[5].ag = 0;
        perSym["GRABS"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 1000; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5000; e[5].ag = 0;
        perSym["SUNBS"] = e;
        e.clear();

        m_Bonus_tmp[i] = perSym;
    }

    m_Bonus_tmp[m_vecBetSteps_tmp.size() - 1 - BIGBET_BETSTEP_EXTRA_COUNT]["SUNBS"][5].coin = 80000;
    m_Bonus_tmp[m_vecBetSteps_tmp.size() - 1 - BIGBET_BETSTEP_EXTRA_COUNT]["SUNBS"][4].coin = 50000;
    m_Bonus_tmp[m_vecBetSteps_tmp.size() - 1 - BIGBET_BETSTEP_EXTRA_COUNT]["GRABS"][5].coin = 50000;
    m_Bonus_tmp[m_vecBetSteps_tmp.size() - 1 - BIGBET_BETSTEP_EXTRA_COUNT]["MELBS"][5].coin = 50000;

    m_Bonus_tmp[m_vecBetSteps_tmp.size() - 2 - BIGBET_BETSTEP_EXTRA_COUNT]["SUNBS"][5].coin = 80000;
    m_Bonus_tmp[m_vecBetSteps_tmp.size() - 2 - BIGBET_BETSTEP_EXTRA_COUNT]["GRABS"][5].coin = 40000;
    m_Bonus_tmp[m_vecBetSteps_tmp.size() - 2 - BIGBET_BETSTEP_EXTRA_COUNT]["MELBS"][5].coin = 40000;

    m_Bonus_tmp[m_vecBetSteps_tmp.size() - 3 - BIGBET_BETSTEP_EXTRA_COUNT]["SUNBS"][5].coin = 80000;
    m_Bonus_tmp[m_vecBetSteps_tmp.size() - 3 - BIGBET_BETSTEP_EXTRA_COUNT]["GRABS"][5].coin = 25000;
    m_Bonus_tmp[m_vecBetSteps_tmp.size() - 3 - BIGBET_BETSTEP_EXTRA_COUNT]["MELBS"][5].coin = 25000;

    int nSavedBetVal = 10;
    int _line = 0;
    string data;
    PlayDB::GetInstance().LoadCheckPoint(m_strGameName, nSavedBetVal, _line, m_strCheckPoint);
    if (nSavedBetVal == -1) {
        nSavedBetVal = 10;
    }

    BOOL start = FALSE;
    idx = 0;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_tmp, i) < AT(m_vecBetSteps, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps, idx) == nSavedBetVal) {
            m_nBetStep = idx;
        }

        m_Bonus[idx++] = m_Bonus_tmp[i];
        if (AT(m_vecBetSteps_tmp, i) == AT(m_vecBetSteps, m_vecBetSteps.size() - 1)) {
            break;
        }
    }

    m_vecBetSteps_05.clear();
    m_vecBetSteps_10.clear();
    PrintAllBonus();
}

myVector<UINT8> RgMerkurMagnus::Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) {
    m_bPrevSpinMatchedActive = FALSE;

    myVector<UINT8> result;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);

    BOOL mmcode = FALSE;
    if (bTest == FALSE) {
        mmcode = mmcode_get_active_status();
    }
    if (bTest == TRUE || mmcode == TRUE) {
        std::string matchSymbol = AT(m_vecSymbols, myRandom() % m_vecSymbols.size());
        int line = (myRandom() % m_nWinLine);
        int weight = 1 + (myRandom() % 5);
       
        if (mmcode) {
            mmcode_set_deactive();
            weight = m_nMaxMatch;
            matchSymbol = RgMerkurMagnus_top;
        }
        for (int i = 0; i < m_nReel; i++) {
            ReelStrip reelStrip = AT(reelSet, i);
            int len = reelStrip.size() - 3;

            int valid_i[0x100];
            int valid_count = 0;
            for (int j = 0; j <= len; j++) {
                if (weight > i) {
                    if (matchSymbol == AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                else {
                    if (matchSymbol != AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
            }
            if (valid_count > 0) {
                int rand_index = myRandom() % valid_count;
                int chosen_i = valid_i[rand_index];
                result.push_back(chosen_i + 1);
            }
            else {
                result.push_back((myRandom() % (len - 1)) + 1);
            }
        }
    }
    else {
        result = _result;
    }
    normalMeter = 0;
    maxMeter = 0;
    BONUS totalBonus = { 0, 0 };
    for (int i = 0; i < m_nWinLine; i++) {
        int j = 1;
        UINT16 meter = ((UINT16)1 << (2 - g_match_lines_10_5[i][0]));

        for (; j < m_nMaxMatch; j++) {
            if (AT(AT(reelSet, j - 1), AT(result, j - 1) - 1 + g_match_lines_10_5[i][j - 1]) == AT(AT(reelSet, j), AT(result, j) - 1 + g_match_lines_10_5[i][j])) {

                meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
                continue;
            }
            break;
        }
        std::string firstSymbol = AT(AT(reelSet, 0), AT(result, 0) - 1 + g_match_lines_10_5[i][0]);
        if (j < m_mapSymbolMinMatch[firstSymbol]) {
            continue;
        }

        // monitor 2 meter
        std::string meterStr = m_mapSymbolMeterGoc[firstSymbol];
        size_t pos = meterStr.find('$');
        if (pos != std::string::npos) {
            meterStr = meterStr.replace(pos, 1, std::to_string(j));
        }

        WinMeter e;
        e.line = i;
        e.meter = meter;
        e.meter2 = g_GrafficObjList.Str2GOCID(meterStr);
        e.symbol = firstSymbol;
        e.weight = j;
        e.start = 0;
        e.bonus = m_Bonus[BetStep()][firstSymbol][j];
        e.sound = MAX_SOUND_IDS;

        totalBonus.coin += e.bonus.coin;
        totalBonus.ag += e.bonus.ag;

        if (e.meter2 != -1) {
            meters.push_back(e);
        }
        if (j == m_nMaxMatch) {
            maxMeter |= meter;
        }
        else {
            normalMeter |= meter;
        }
        if (bTest == FALSE) {
            m_bPrevSpinMatchedActive = TRUE;
        }
    }
    if (bTest == FALSE) {
        m_vWinResult = result;
        updateCheckPoint();
        if (totalBonus.coin > 0 || totalBonus.ag > 0) {
            BonusSound = getSoundByID(WinSound(totalBonus.coin + totalBonus.ag * 1000));
        }
        else {
            BonusSound.duration = 0;
            BonusSound.soundID = MAX_SOUND_IDS;
        }
    }
    return result;
}
