#include "stdafx.h"
#include "RgLegacyOfFire.h"

#define RgLegacyOfFire_scatter      "FIRE__LF"
#define RgLegacyOfFire_wild         "MASTERLF"

RgLegacyOfFire::RgLegacyOfFire() {
    m_nReel = 5;
    m_nWinLine = 3;
    m_nMaxMatch = 5;
    m_nBetStep = 0;

    m_strGameName = "RgLegacyOfFire";

    m_bFreeMode = FALSE;

    myVector<UINT16> m_vecBetSteps_tmp;
    m_vecBetSteps_tmp.push_back(5);
    m_vecBetSteps_tmp.push_back(10);
    m_vecBetSteps_tmp.push_back(20);
    m_vecBetSteps_tmp.push_back(30);
    m_vecBetSteps_tmp.push_back(40);
    m_vecBetSteps_tmp.push_back(50);
    m_vecBetSteps_tmp.push_back(60);
    m_vecBetSteps_tmp.push_back(80);
    m_vecBetSteps_tmp.push_back(100);
#ifdef BIGBET_ACTIVE
    m_vecBetSteps_tmp.push_back(200);
    m_vecBetSteps_tmp.push_back(500);
#endif
    LoadBets();

    m_vecSymbols.push_back("MAN___LF");
    m_vecSymbols.push_back("BOY___LF");
    m_vecSymbols.push_back("GIRL__LF");
    m_vecSymbols.push_back("AMULETLF");
    m_vecSymbols.push_back("DAGGERLF");
    m_vecSymbols.push_back("BRACELLF");
    m_vecSymbols.push_back("FIRE__LF");
    m_vecSymbols.push_back("MASTERLF");

    m_mapSymbolMinMatch["MAN___LF"] = 2;
    m_mapSymbolMinMatch["BOY___LF"] = 3;
    m_mapSymbolMinMatch["GIRL__LF"] = 3;
    m_mapSymbolMinMatch["AMULETLF"] = 3;
    m_mapSymbolMinMatch["DAGGERLF"] = 3;
    m_mapSymbolMinMatch["BRACELLF"] = 3;

    m_mapSymbolMeterGoc["MAN___LF"] = "LEFIMan$x";
    m_mapSymbolMeterGoc["BOY___LF"] = "LEFIBoy$x";
    m_mapSymbolMeterGoc["GIRL__LF"] = "LEFIGirl$x";
    m_mapSymbolMeterGoc["AMULETLF"] = "LEFIAmulet$x";
    m_mapSymbolMeterGoc["DAGGERLF"] = "LEFIDagger$x";
    m_mapSymbolMeterGoc["BRACELLF"] = "LEFIBracelet$x";

    m_vecWinLines.push_back("WinL1LEFI");
    m_vecWinLines.push_back("WinL2LEFI");
    m_vecWinLines.push_back("WinL3LEFI");
    m_vecWinLines.push_back("WinScatLEFI");

    m_vecLineSounds.push_back(SMP_LEFI_WinPart_1);
    m_vecLineSounds.push_back(SMP_LEFI_WinPart_2);
    m_vecLineSounds.push_back(SMP_LEFI_WinPart_3);

    m_vecWinSounds.push_back(SMP_LEFI_WinVeryTiny);
    m_vecWinSounds.push_back(SMP_LEFI_WinTiny);
    m_vecWinSounds.push_back(SMP_LEFI_WinSmall);
    m_vecWinSounds.push_back(SMP_LEFI_WinMedium);
    m_vecWinSounds.push_back(SMP_LEFI_WinBig);
    m_vecWinSounds.push_back(SMP_LEFI_WinTop);
    m_vecWinSounds.push_back(SMP_LEFI_WinHuge);

    m_vecReelStripPlan.push_back("lefiW1A");
    m_vecReelStripPlan.push_back("lefiW1B");
    m_vecReelStripPlan.push_back("lefiW1C");
    m_vecReelStripPlan.push_back("lefiW1DUMMY");
    
    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));

    char* lefiReelStrip[] = {
        "AMULETLF,DAGGERLF,BOY___LF,BRACELLF,MAN___LF,AMULETLF,DAGGERLF,BRACELLF,AMULETLF,BOY___LF,BRACELLF,MAN___LF,AMULETLF,DAGGERLF,BRACELLF,BOY___LF,DAGGERLF,MASTERLF,BRACELLF,GIRL__LF,AMULETLF,BOY___LF,BRACELLF,MAN___LF,AMULETLF,BOY___LF,DAGGERLF,AMULETLF,BRACELLF,GIRL__LF,AMULETLF,MAN___LF,DAGGERLF,GIRL__LF,AMULETLF,BOY___LF,DAGGERLF,MASTERLF,BRACELLF,GIRL__LF,AMULETLF,MAN___LF,DAGGERLF,GIRL__LF,AMULETLF,BOY___LF,DAGGERLF,FIRE__LF,BRACELLF,GIRL__LF,AMULETLF,MAN___LF,DAGGERLF,GIRL__LF,AMULETLF,BOY___LF,DAGGERLF,MASTERLF,BRACELLF,GIRL__LF",
        "AMULETLF,BOY___LF,BRACELLF,DAGGERLF,BOY___LF,AMULETLF,DAGGERLF,BOY___LF,BRACELLF,GIRL__LF,DAGGERLF,BOY___LF,AMULETLF,MAN___LF,BRACELLF,GIRL__LF,DAGGERLF,BRACELLF,GIRL__LF,AMULETLF,BOY___LF,BRACELLF,MAN___LF,DAGGERLF,GIRL__LF,AMULETLF,DAGGERLF,BOY___LF,BRACELLF,GIRL__LF,DAGGERLF,BOY___LF,AMULETLF,MAN___LF,BRACELLF,GIRL__LF,DAGGERLF,BRACELLF,GIRL__LF,AMULETLF,BOY___LF,BRACELLF,MAN___LF,DAGGERLF,GIRL__LF",
        "BRACELLF,DAGGERLF,BRACELLF,GIRL__LF,DAGGERLF,AMULETLF,BOY___LF,MAN___LF,AMULETLF,BRACELLF,DAGGERLF,AMULETLF,BOY___LF,MAN___LF,AMULETLF,BRACELLF,DAGGERLF,MASTERLF,AMULETLF,BOY___LF,DAGGERLF,AMULETLF,BOY___LF,MAN___LF,AMULETLF,BRACELLF,DAGGERLF,GIRL__LF,AMULETLF,BOY___LF,BRACELLF,GIRL__LF,DAGGERLF,MAN___LF,GIRL__LF,BRACELLF,DAGGERLF,MASTERLF,AMULETLF,BOY___LF,BRACELLF,GIRL__LF,DAGGERLF,MAN___LF,GIRL__LF,BRACELLF,DAGGERLF,FIRE__LF,AMULETLF,BOY___LF,BRACELLF,GIRL__LF,DAGGERLF,MAN___LF,GIRL__LF,BRACELLF,DAGGERLF,MASTERLF,AMULETLF,BOY___LF",
        "GIRL__LF,DAGGERLF,BRACELLF,GIRL__LF,AMULETLF,DAGGERLF,BRACELLF,GIRL__LF,AMULETLF,BRACELLF,BOY___LF,AMULETLF,GIRL__LF,MAN___LF,DAGGERLF,BRACELLF,BOY___LF,DAGGERLF,BRACELLF,GIRL__LF,DAGGERLF,AMULETLF,MAN___LF,BOY___LF,BRACELLF,DAGGERLF,BOY___LF,AMULETLF,GIRL__LF,BRACELLF,BOY___LF,AMULETLF,GIRL__LF,MAN___LF,DAGGERLF,BRACELLF,BOY___LF,DAGGERLF,BRACELLF,GIRL__LF,DAGGERLF,AMULETLF,MAN___LF,BOY___LF,BRACELLF",
        "BOY___LF,AMULETLF,GIRL__LF,BRACELLF,BOY___LF,AMULETLF,MAN___LF,DAGGERLF,GIRL__LF,BRACELLF,BOY___LF,AMULETLF,GIRL__LF,DAGGERLF,BRACELLF,AMULETLF,BOY___LF,DAGGERLF,BRACELLF,BOY___LF,AMULETLF,MAN___LF,DAGGERLF,GIRL__LF,BRACELLF,BOY___LF,AMULETLF,FIRE__LF,DAGGERLF,BRACELLF,AMULETLF,BOY___LF,DAGGERLF,GIRL__LF,BRACELLF,BOY___LF,AMULETLF,DAGGERLF,GIRL__LF,BRACELLF,BOY___LF,AMULETLF,MASTERLF,DAGGERLF,BRACELLF",

        "AMULETLF,DAGGERLF,BOY___LF,BRACELLF,MAN___LF,AMULETLF,DAGGERLF,BRACELLF,AMULETLF,BOY___LF,BRACELLF,MAN___LF,AMULETLF,DAGGERLF,BRACELLF,BOY___LF,DAGGERLF,FIRE__LF,BRACELLF,GIRL__LF,AMULETLF,BOY___LF,BRACELLF,MAN___LF,AMULETLF,BOY___LF,DAGGERLF,AMULETLF,BRACELLF,GIRL__LF,AMULETLF,MAN___LF,DAGGERLF,GIRL__LF,AMULETLF,BOY___LF,DAGGERLF,FIRE__LF,BRACELLF,GIRL__LF,AMULETLF,MAN___LF,DAGGERLF,GIRL__LF,AMULETLF,BOY___LF,DAGGERLF,FIRE__LF,BRACELLF,GIRL__LF,AMULETLF,MAN___LF,DAGGERLF,GIRL__LF,AMULETLF,BOY___LF,DAGGERLF,MASTERLF,BRACELLF,GIRL__LF",
        "AMULETLF,BOY___LF,BRACELLF,DAGGERLF,BOY___LF,AMULETLF,DAGGERLF,BOY___LF,BRACELLF,GIRL__LF,DAGGERLF,BOY___LF,AMULETLF,MAN___LF,BRACELLF,GIRL__LF,DAGGERLF,BRACELLF,GIRL__LF,AMULETLF,BOY___LF,BRACELLF,MAN___LF,DAGGERLF,GIRL__LF,AMULETLF,DAGGERLF,BOY___LF,BRACELLF,GIRL__LF,DAGGERLF,BOY___LF,AMULETLF,MAN___LF,BRACELLF,GIRL__LF,DAGGERLF,BRACELLF,GIRL__LF,AMULETLF,BOY___LF,BRACELLF,MAN___LF,DAGGERLF,GIRL__LF",
        "BRACELLF,DAGGERLF,BRACELLF,GIRL__LF,DAGGERLF,AMULETLF,BOY___LF,MAN___LF,AMULETLF,BRACELLF,DAGGERLF,AMULETLF,BOY___LF,MAN___LF,AMULETLF,BRACELLF,DAGGERLF,MASTERLF,AMULETLF,BOY___LF,DAGGERLF,AMULETLF,BOY___LF,MAN___LF,AMULETLF,BRACELLF,DAGGERLF,GIRL__LF,AMULETLF,BOY___LF,BRACELLF,GIRL__LF,DAGGERLF,MAN___LF,GIRL__LF,BRACELLF,DAGGERLF,MASTERLF,AMULETLF,BOY___LF,BRACELLF,GIRL__LF,DAGGERLF,MAN___LF,GIRL__LF,BRACELLF,DAGGERLF,FIRE__LF,AMULETLF,BOY___LF,BRACELLF,GIRL__LF,DAGGERLF,MAN___LF,GIRL__LF,BRACELLF,DAGGERLF,MASTERLF,AMULETLF,BOY___LF",
        "GIRL__LF,DAGGERLF,BRACELLF,GIRL__LF,AMULETLF,DAGGERLF,BRACELLF,GIRL__LF,AMULETLF,BRACELLF,BOY___LF,AMULETLF,GIRL__LF,MAN___LF,DAGGERLF,BRACELLF,BOY___LF,DAGGERLF,BRACELLF,GIRL__LF,DAGGERLF,AMULETLF,MAN___LF,BOY___LF,BRACELLF,DAGGERLF,BOY___LF,AMULETLF,GIRL__LF,BRACELLF,BOY___LF,AMULETLF,GIRL__LF,MAN___LF,DAGGERLF,BRACELLF,BOY___LF,DAGGERLF,BRACELLF,GIRL__LF,DAGGERLF,AMULETLF,MAN___LF,BOY___LF,BRACELLF",
        "BOY___LF,AMULETLF,GIRL__LF,BRACELLF,BOY___LF,AMULETLF,MAN___LF,DAGGERLF,GIRL__LF,BRACELLF,BOY___LF,AMULETLF,GIRL__LF,DAGGERLF,BRACELLF,AMULETLF,BOY___LF,DAGGERLF,BRACELLF,BOY___LF,AMULETLF,MAN___LF,DAGGERLF,GIRL__LF,BRACELLF,BOY___LF,AMULETLF,FIRE__LF,DAGGERLF,BRACELLF,AMULETLF,BOY___LF,DAGGERLF,GIRL__LF,BRACELLF,BOY___LF,AMULETLF,DAGGERLF,GIRL__LF,BRACELLF,BOY___LF,AMULETLF,MASTERLF,DAGGERLF,BRACELLF",

        "AMULETLF,DAGGERLF,BOY___LF,BRACELLF,MAN___LF,AMULETLF,DAGGERLF,BRACELLF,AMULETLF,BOY___LF,BRACELLF,MAN___LF,AMULETLF,DAGGERLF,BRACELLF,BOY___LF,DAGGERLF,FIRE__LF,BRACELLF,GIRL__LF,AMULETLF,BOY___LF,BRACELLF,MAN___LF,AMULETLF,BOY___LF,DAGGERLF,MASTERLF,BRACELLF,GIRL__LF,AMULETLF,MAN___LF,DAGGERLF,GIRL__LF,AMULETLF,BOY___LF,DAGGERLF,FIRE__LF,BRACELLF,GIRL__LF,AMULETLF,MAN___LF,DAGGERLF,GIRL__LF,AMULETLF,BOY___LF,DAGGERLF,FIRE__LF,BRACELLF,GIRL__LF,AMULETLF,MAN___LF,DAGGERLF,GIRL__LF,AMULETLF,BOY___LF,DAGGERLF,MASTERLF,BRACELLF,GIRL__LF",
        "AMULETLF,BOY___LF,BRACELLF,DAGGERLF,BOY___LF,AMULETLF,DAGGERLF,BOY___LF,BRACELLF,GIRL__LF,DAGGERLF,BOY___LF,AMULETLF,MAN___LF,BRACELLF,GIRL__LF,DAGGERLF,BRACELLF,GIRL__LF,AMULETLF,BOY___LF,BRACELLF,MAN___LF,DAGGERLF,GIRL__LF,AMULETLF,DAGGERLF,BOY___LF,BRACELLF,GIRL__LF,DAGGERLF,BOY___LF,AMULETLF,MAN___LF,BRACELLF,GIRL__LF,DAGGERLF,BRACELLF,GIRL__LF,AMULETLF,BOY___LF,BRACELLF,MAN___LF,DAGGERLF,GIRL__LF",
        "BRACELLF,DAGGERLF,BRACELLF,GIRL__LF,DAGGERLF,AMULETLF,BOY___LF,MAN___LF,AMULETLF,BRACELLF,DAGGERLF,AMULETLF,BOY___LF,MAN___LF,AMULETLF,BRACELLF,DAGGERLF,MASTERLF,AMULETLF,BOY___LF,DAGGERLF,AMULETLF,BOY___LF,MAN___LF,AMULETLF,BRACELLF,DAGGERLF,FIRE__LF,AMULETLF,BOY___LF,BRACELLF,GIRL__LF,DAGGERLF,MAN___LF,GIRL__LF,BRACELLF,DAGGERLF,MASTERLF,AMULETLF,BOY___LF,BRACELLF,GIRL__LF,DAGGERLF,MAN___LF,GIRL__LF,BRACELLF,DAGGERLF,FIRE__LF,AMULETLF,BOY___LF,BRACELLF,GIRL__LF,DAGGERLF,MAN___LF,GIRL__LF,BRACELLF,DAGGERLF,MASTERLF,AMULETLF,BOY___LF",
        "GIRL__LF,DAGGERLF,BRACELLF,GIRL__LF,AMULETLF,DAGGERLF,BRACELLF,GIRL__LF,AMULETLF,BRACELLF,BOY___LF,AMULETLF,GIRL__LF,MAN___LF,DAGGERLF,BRACELLF,BOY___LF,DAGGERLF,BRACELLF,GIRL__LF,DAGGERLF,AMULETLF,MAN___LF,BOY___LF,BRACELLF,DAGGERLF,BOY___LF,AMULETLF,GIRL__LF,BRACELLF,BOY___LF,AMULETLF,GIRL__LF,MAN___LF,DAGGERLF,BRACELLF,BOY___LF,DAGGERLF,BRACELLF,GIRL__LF,DAGGERLF,AMULETLF,MAN___LF,BOY___LF,BRACELLF",
        "BOY___LF,AMULETLF,GIRL__LF,BRACELLF,BOY___LF,AMULETLF,MAN___LF,DAGGERLF,GIRL__LF,BRACELLF,BOY___LF,AMULETLF,GIRL__LF,DAGGERLF,BRACELLF,AMULETLF,BOY___LF,DAGGERLF,BRACELLF,BOY___LF,AMULETLF,MAN___LF,DAGGERLF,GIRL__LF,BRACELLF,BOY___LF,AMULETLF,FIRE__LF,DAGGERLF,BRACELLF,AMULETLF,BOY___LF,DAGGERLF,GIRL__LF,BRACELLF,BOY___LF,AMULETLF,DAGGERLF,GIRL__LF,BRACELLF,BOY___LF,AMULETLF,MASTERLF,DAGGERLF,BRACELLF",

        "DAGGERLF,BRACELLF,GIRL__LF,AMULETLF,BOY___LF,BRACELLF,MAN___LF,AMULETLF,DAGGERLF,BRACELLF,AMULETLF,BOY___LF,BRACELLF,MAN___LF,AMULETLF,BOY___LF,DAGGERLF,AMULETLF,BRACELLF,GIRL__LF,AMULETLF,MAN___LF,DAGGERLF,GIRL__LF,AMULETLF,BOY___LF,DAGGERLF,FIRE__LF,BRACELLF,GIRL__LF,AMULETLF,MAN___LF,DAGGERLF,GIRL__LF,AMULETLF,BOY___LF,DAGGERLF,MASTERLF,BRACELLF,GIRL__LF",
        "AMULETLF,DAGGERLF,BRACELLF,GIRL__LF,AMULETLF,BOY___LF,BRACELLF,AMULETLF,DAGGERLF,GIRL__LF,AMULETLF,DAGGERLF,BOY___LF,BRACELLF,GIRL__LF,DAGGERLF,BOY___LF,AMULETLF,MAN___LF,BRACELLF,GIRL__LF,DAGGERLF,BRACELLF,GIRL__LF,AMULETLF,BOY___LF,BRACELLF,MAN___LF,DAGGERLF,GIRL__LF",
        "DAGGERLF,AMULETLF,BOY___LF,MAN___LF,AMULETLF,BRACELLF,DAGGERLF,GIRL__LF,AMULETLF,BOY___LF,BRACELLF,GIRL__LF,DAGGERLF,MAN___LF,GIRL__LF,BRACELLF,DAGGERLF,FIRE__LF,AMULETLF,BOY___LF,BRACELLF,GIRL__LF,DAGGERLF,MAN___LF,GIRL__LF,BRACELLF,DAGGERLF,MASTERLF,AMULETLF,BOY___LF",
        "DAGGERLF,BOY___LF,AMULETLF,GIRL__LF,BRACELLF,BOY___LF,AMULETLF,GIRL__LF,MAN___LF,DAGGERLF,BRACELLF,BOY___LF,DAGGERLF,BRACELLF,GIRL__LF,DAGGERLF,AMULETLF,MAN___LF,BOY___LF,BRACELLF",
        "BOY___LF,AMULETLF,GIRL__LF,BRACELLF,BOY___LF,AMULETLF,MAN___LF,DAGGERLF,GIRL__LF,BRACELLF,BOY___LF,AMULETLF,FIRE__LF,DAGGERLF,BRACELLF,AMULETLF,BOY___LF,DAGGERLF,GIRL__LF,BRACELLF,BOY___LF,AMULETLF,DAGGERLF,GIRL__LF,BRACELLF,BOY___LF,AMULETLF,MASTERLF,DAGGERLF,BRACELLF",
    };

    int idx = 0;
    for (int i = 0; i < m_vecReelStripPlan.size(); i++) {
        ReelSet set;
        for (int j = 0; j < m_nReel; j++) {
            ReelStrip strip;
            std::stringstream ss(lefiReelStrip[idx]);
            std::string item;
            while (std::getline(ss, item, ',')) {
                strip.push_back(item);
            }
            set.push_back(strip);
            idx++;
        }
        m_vecReelStripSets.push_back(set);
    }

    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_tmp;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        std::map<std::string, std::map<UINT8, BONUS>> perSym;
        std::map<UINT8, BONUS> e;
        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 15; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[5].ag = 0;
        perSym["BRACELLF"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 15; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[5].ag = 0;
        perSym["DAGGERLF"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 30; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[5].ag = 0;
        perSym["AMULETLF"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 250; e[5].ag = 0;
        perSym["GIRL__LF"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 250; e[5].ag = 0;
        perSym["BOY___LF"] = e;
        e.clear();

        e[2].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 10; e[3].ag = 0;
        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 250; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 2500; e[5].ag = 0;
        perSym["MAN___LF"] = e;
        e.clear();

        m_Bonus_tmp[i] = perSym;
    }

    int nSavedBetVal = 10;
    int _line = 0;
    string data;
    PlayDB::GetInstance().LoadCheckPoint(m_strGameName, nSavedBetVal, _line, m_strCheckPoint);
    if (nSavedBetVal == -1) {
        nSavedBetVal = 10;
    }

    BOOL start = FALSE;
    idx = 0;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_tmp, i) < AT(m_vecBetSteps, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps, idx) == nSavedBetVal) {
            m_nBetStep = idx;
        }

        m_Bonus[idx++] = m_Bonus_tmp[i];
        if (AT(m_vecBetSteps_tmp, i) == AT(m_vecBetSteps, m_vecBetSteps.size() - 1)) {
            break;
        }
    }

    m_vecBetSteps_05.clear();
    m_vecBetSteps_10.clear();
    PrintAllBonus();
}

UINT16 RgLegacyOfFire::Run() {
    m_nCurrentReelPlan = 0;// (myRandom() % m_vecReelStripPlan.size());
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));
    return m_shCurrentReelStrip;
}

UINT8 RgLegacyOfFire::CardCount(std::string card) {
    int n = 0;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int col = 0; col < m_nReel; col++) {
        int k = 0;
        for (; k < 3; k++) {
            std::string s = AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k);
            if (s == card) {
                n++;
            }
        }
    }
    return n;
}

BOOL RgLegacyOfFire::ScatterInCol(int col) {
    return CardNumInCol(col, RgLegacyOfFire_scatter);
}

UINT8 RgLegacyOfFire::CardNumInCol(int col, std::string card) {
    int n = 0;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int k = 0; k < 3; k++) {
        std::string s = AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k);
        if (s == card) {
            n++;
        }
    }
    return n;
}

myVector<UINT8> RgLegacyOfFire::Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) {
    myVector<UINT8> result;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);

    if (bTest) {
        std::string matchSymbol = AT(m_vecSymbols, myRandom() % (m_vecSymbols.size() - 2));
        int line = (myRandom() % m_nWinLine);
        int weight = 1 +(myRandom() % 5);

        BOOL bForceFree = (myRandom() % 10 == 0);
        if (m_bFreeMode) {
            auto it = std::find(m_nForceMatchInFreeMode.begin(), m_nForceMatchInFreeMode.end(), m_nFreeModeGoneSpin);
            if (it != m_nForceMatchInFreeMode.end()) {
                weight = 4;
            }
        }
        for (int i = 0; i < m_nReel; i++) {
            ReelStrip reelStrip = AT(reelSet, i);
            int len = reelStrip.size() - 3;

            int valid_i[0x100];
            int valid_count = 0;

            myVector<int> freeSymbols;
            for (int j = 0; j <= len; j++) {
                if (weight > i) {
                    if (matchSymbol == AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                else {
                    if (matchSymbol != AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                if (AT(reelStrip, j) == RgLegacyOfFire_scatter && m_bFreeMode == FALSE) {
                    freeSymbols.push_back(j);
                }
            }
            if (valid_count > 0) {
                int rand_index = myRandom() % valid_count;
                int chosen_i = valid_i[rand_index];
                result.push_back(chosen_i + 1);
            }
            else {
                result.push_back((myRandom() % (len - 1)) + 1);
            }
            {
                int pool[5] = { 0, 2, 4 };
                auto v = pickRandom2or3(pool, 3, 3);
                if (bForceFree && m_bFreeMode == FALSE && freeSymbols.size() > 0 && std::find(v.begin(), v.end(), i) != v.end()) {
                    AT(result, result.size() - 1) =
                        AT(freeSymbols, myRandom() % freeSymbols.size()) - (myRandom() % 3) + 1;
                }
            }
        }
    }
    else {
        result = _result;

        BOOL mmcode = mmcode_get_active_status();
        if (mmcode) {
            mmcode_set_deactive();
            if (m_bFreeMode == FALSE) {
                for (int j = 0; j < 5; j ++) {
                    myVector<int> candidateIndices;
                    for (int i = 2; i < AT(reelSet, j).size() - 3; ++i) {
                        if (j%2 == 0 && AT(AT(reelSet, j), i) == RgLegacyOfFire_scatter) {
                            int offset = myRandom() % 3;
                            int selectedIndex = i - 2 + offset;
                            candidateIndices.push_back(selectedIndex);
                        }
                        if (j%2 == 1 && AT(AT(reelSet, j), i) != RgLegacyOfFire_scatter
                                    && AT(AT(reelSet, j), i-2) != RgLegacyOfFire_scatter
                                    && AT(AT(reelSet, j), i-1) != RgLegacyOfFire_scatter
                                    && AT(AT(reelSet, j), i+1) != RgLegacyOfFire_scatter
                                    && AT(AT(reelSet, j), i+2) != RgLegacyOfFire_scatter) {
                            int offset = myRandom() % 3;
                            int selectedIndex = i - 2 + offset;
                            candidateIndices.push_back(selectedIndex);
                        }
                    }
                    if (!candidateIndices.empty()) {
#ifdef BIGBET_ACTIVE
                        int chosenIndex = AT(candidateIndices, (candidateIndices.size()<3?myRandom() % candidateIndices.size():myRandom() % 3));
#else
                        int chosenIndex = AT(candidateIndices, myRandom() % candidateIndices.size());
#endif
                        AT(result, j) = chosenIndex + 1;
                    }
                }
            }
        }
    }

    m_vWinResult = result;

    normalMeter = 0;
    maxMeter = 0;
    UINT32 totalBonus = 0;

    m_nCountToConvert = 0;
    for (int i = 0; i < m_nWinLine; i++) {
        int j = 1;
        UINT16 meter = ((UINT16)1 << (2 - g_match_lines_10_5[i][0]));
        std::string firstSymbol = AT(AT(reelSet, 0), AT(result, 0) - 1 + g_match_lines_10_5[i][0]);

        for (; j < m_nMaxMatch; j++) {
            std::string prev_symbol = AT(AT(reelSet, j - 1), AT(result, j - 1) - 1 + g_match_lines_10_5[i][j - 1]);
            std::string cur_symbol = AT(AT(reelSet, j), AT(result, j) - 1 + g_match_lines_10_5[i][j]);

            if (firstSymbol == RgLegacyOfFire_wild) {
                firstSymbol = cur_symbol;
            }           
            if (firstSymbol == cur_symbol || cur_symbol == RgLegacyOfFire_wild) {
                meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
                continue;
            }
            break;
        }
        if (m_bFreeMode) {
            int col = 1;
            std::string symbol_1 = AT(AT(reelSet, col), AT(result, col) - 1 + g_match_lines_10_5[i][col]);
            col = 3;
            std::string symbol_3 = AT(AT(reelSet, col), AT(result, col) - 1 + g_match_lines_10_5[i][col]);
            UINT16 newMeter = 0;
            if (CardNumInCol(0, symbol_1) || CardNumInCol(0, RgLegacyOfFire_wild)) {
                newMeter |= ((UINT16)1 << (3 * 0 + 2 - g_match_lines_10_5[i][0]));
                newMeter |= ((UINT16)1 << (3 * 1 + 2 - g_match_lines_10_5[i][1]));
            }
            else {
                if (j < m_mapSymbolMinMatch[firstSymbol] || m_mapSymbolMinMatch[firstSymbol] == 0) {
                    continue;
                }
                goto CONT;
            }
            firstSymbol = symbol_1;
            if (CardNumInCol(2, symbol_1) || CardNumInCol(2, RgLegacyOfFire_wild)) {
                newMeter |= ((UINT16)1 << (3 * 2 + 2 - g_match_lines_10_5[i][2]));
            }
            else {
                if (m_mapSymbolMinMatch[firstSymbol] == 0) {
                    continue;
                }
                if (m_mapSymbolMinMatch[firstSymbol] > 2) {
                    if (j < m_mapSymbolMinMatch[firstSymbol]) {
                        continue;
                    }
                    goto CONT;
                }
            }
            
            int nMatchCnt = 3;
            if (symbol_1 == symbol_3) {
                newMeter |= ((UINT16)1 << (3 * 3 + 2 - g_match_lines_10_5[i][3]));
                nMatchCnt = 4;
                if (CardNumInCol(4, symbol_1) || CardNumInCol(4, RgLegacyOfFire_wild)) {
                    newMeter |= ((UINT16)1 << (3 * 4 + 2 - g_match_lines_10_5[i][4]));
                    nMatchCnt = 5;
                }
            }
            if (nMatchCnt > j) {
                j = nMatchCnt;
                firstSymbol = symbol_1;
                meter = newMeter;

                m_nCountToConvert++;
            }
            else if (nMatchCnt == j) {
                for (int k = 0; k < m_nMaxMatch; k += 2) {
                    std::string cur_symbol = AT(AT(reelSet, k), AT(result, k) - 1 + g_match_lines_10_5[i][k]);
                    if (cur_symbol != RgLegacyOfFire_wild && CardNumInCol(k, RgLegacyOfFire_wild) > 0) {
                        m_nCountToConvert++;
                    }
                }
            }
        }
        else {
            if (j < m_mapSymbolMinMatch[firstSymbol] || m_mapSymbolMinMatch[firstSymbol] == 0) {
                continue;
            }
        }
    CONT:
        uint16_t temp = meter;  // copy
        UINT16 weight = 0;
        while (temp) {
            weight += temp & 1;
            temp >>= 1;
        }
        // monitor 2 meter
        std::string meterStr = m_mapSymbolMeterGoc[firstSymbol];
        size_t pos = meterStr.find('$');
        if (pos != std::string::npos) {
            meterStr = meterStr.replace(pos, 1, std::to_string(weight));
        }

        WinMeter e;
        e.line = i;
        e.meter = meter;
        e.meter2 = g_GrafficObjList.Str2GOCID(meterStr);
        e.symbol = firstSymbol;
        e.weight = weight;
        e.start = 0;
        e.bonus = m_Bonus[BetStep()][firstSymbol][weight];
        e.sound = MAX_SOUND_IDS;

        totalBonus += e.bonus.coin;

        if (e.meter2 != -1) {
            meters.push_back(e);
        }
        if (j == m_nMaxMatch) {
            maxMeter |= meter;
        }
        else {
            normalMeter |= meter;
        }
    }

    if ((CardCount(RgLegacyOfFire_scatter) + CardCount(RgLegacyOfFire_wild)) >= 3) {
        bCanFreeMode = TRUE;
    }

    int nScatter = CardCount(RgLegacyOfFire_scatter);
    if (nScatter >= 3) {
        // not match nScatter 5, and nScatter match contains other match
        UINT16 meter = 0;
        for (int i = 0; i < 3; i++) {
            for (int col = 0; col < m_nReel; col++) {
                std::string cur_symbol = AT(AT(reelSet, col), AT(result, col) - 1 + i);
                if (cur_symbol == RgLegacyOfFire_scatter) {
                    meter |= ((UINT16)1 << (3 * col + (2 - i)));
                }
            }
        }

        WinMeter e;
        e.line = 3;
        e.meter = meter;
        e.meter2 = 0;
        e.symbol = RgLegacyOfFire_scatter;
        e.weight = nScatter;
        e.start = 0;
        e.bonus = {0, 0};
        e.sound = MAX_SOUND_IDS;

        normalMeter |= meter;
        totalBonus += e.bonus.coin;

        meters.push_back(e);
    }
   
    m_vWinMeters = meters;
    if (bTest == FALSE) {
        updateCheckPoint();

        if (totalBonus > 0) {
            if (m_bFreeMode) {
                m_nFreeModeTotalBonus.coin += totalBonus;
            }
            BonusSound = getSoundByID(WinSound(totalBonus));
        }
        else {
            BonusSound.soundID = MAX_SOUND_IDS;
            BonusSound.duration = 0;
        }
    }
    return result;
}

int RgLegacyOfFire::LineSwapDelay(int WinIdx) {
    return 500;    
}

UINT16 RgLegacyOfFire::SpinTime_MS() {

    if ((CardCount(RgLegacyOfFire_scatter) + CardCount(RgLegacyOfFire_wild)) >= 3) {
        return 4200;
    }
    if ((CardNumInCol(0, RgLegacyOfFire_scatter) || CardNumInCol(0, RgLegacyOfFire_wild)) && (CardNumInCol(2, RgLegacyOfFire_scatter) || CardNumInCol(2, RgLegacyOfFire_wild))) {
        return 4200;
    }
    return 2200;
}

BOOL RgLegacyOfFire::CanFreeMode() {
    //if (CardCount(RgLegacyOfFire_scatter) >= 1 && (CardCount(RgLegacyOfFire_scatter) + CardCount(RgLegacyOfFire_wild)) >= 3) {
    if ((CardCount(RgLegacyOfFire_scatter) + CardCount(RgLegacyOfFire_wild)) >= 3) {
        return TRUE;
    }
    return FALSE;
}


myVector<InterruptPacketData> RgLegacyOfFire::EnterFreeGame(std::string check) {
    m_bFreeMode = TRUE;
    m_nFreeModeTotalSpin = 12;
    m_nFreeModeGoneSpin = 0;
    m_nFreeModeTotalBonus = {0, 0};

    m_nForceMatchInFreeMode.clear();
    int pool[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 };
    m_nForceMatchInFreeMode = pickRandom2or3(pool, sizeof(pool) / sizeof(int), 3);
    myVector<InterruptPacketData> packets;
    if (check != "") {
        myVector<int> values = ParseCheckPoint(check, "F", 4);
        if (values.size() == 4) {
            m_nFreeModeTotalSpin = AT(values, 0);
            m_nFreeModeGoneSpin = AT(values, 1);
            m_nFreeModeTotalBonus.coin = AT(values, 2);
            m_nFreeModeTotalBonus.ag = AT(values, 3);

            UINT8 gone = m_nFreeModeGoneSpin ? m_nFreeModeGoneSpin : 1;
            packets.push_back({
                   0,
                   0,{0x01, 0x02, 0x30, 0x00, 0xac, 0x2d, gone, 0x00, m_nFreeModeTotalSpin, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa3, 0x04} });
            return packets;
        }
    }
    else {
        updateCheckPoint();
    }
    packets.push_back({
       0,
       0,{0x01, 0x02, 0x30, 0x00, 0xac, 0x2d, 0xff, 0xff, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x9b, 0x04} });
    packets.push_back({
       1000,
       0,{0x06, 0xac, 0x2d, 0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0xd0, 0x58, 0x01, 0x01, 0x04} });
    packets.push_back({
       0,
       6000,{0x01, 0x02, 0x30, 0x00, 0xac, 0x2d, 0x0c, 0x00, 0x01, 0x00, m_nFreeModeTotalSpin, 0x00, 0x00, 0x00, 0xa6, 0x04} });
    return packets;
}

myVector<InterruptPacketData> RgLegacyOfFire::InterruptBeforeSpin() {
    myVector<InterruptPacketData> packets;
    if (!m_bFreeMode) {
        return packets;
    }
    m_nFreeModeGoneSpin++;
    updateCheckPoint();

    UINT8 gone = (m_nFreeModeGoneSpin ? m_nFreeModeGoneSpin : 1);

    // display total & remain free spin count
    packets.push_back({
        0,
        0,
        {
            0x01, 0x02, 0x30, 0x00, 0xac, 0x2d, gone, 0x00, m_nFreeModeTotalSpin, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa5, 0x04
        }
        });
    return packets;
}

myVector<InterruptPacketData> RgLegacyOfFire::InterruptAfterMoveBonus(BOOL& EndFree) {
    myVector<InterruptPacketData> packets;
    if (m_nFreeModeGoneSpin >= m_nFreeModeTotalSpin) {
        EndFree = TRUE;
        m_bFreeMode = FALSE;

        // show freemode result dialog and return to main game
        packets.push_back({
             100,
             2000,
             {0x06, 0xac, 0x2d, 0x01, 0x02, 0x30, 0x00, 0xac, 0x2d, 0x00, 0x00, 
             static_cast<BYTE>(m_nFreeModeTotalBonus.coin & 0xFF), 
             static_cast<BYTE>((m_nFreeModeTotalBonus.coin >> 8) & 0xFF),
             static_cast<BYTE>((m_nFreeModeTotalBonus.coin >> 16) & 0xFF),
             static_cast<BYTE>((m_nFreeModeTotalBonus.coin >> 24) & 0xFF),
             0x0c, 0x00, 0xab, 0x04} });
        updateCheckPoint();

        return packets;
    }
    EndFree = FALSE;

    //m_nFreeModeGoneSpin++;
    updateCheckPoint();
    return packets;
}

UINT16 RgLegacyOfFire::LineSound(UINT Line, std::string symbol, UINT8 weight) {
    if (m_vecLineSounds.size() <= Line) {
        return MAX_SOUND_IDS;
    }
    myVector<WinMeter> normalMeters;
    for (int i = 0; i < m_vWinMeters.size(); i++) {
        if (AT(m_vWinMeters, i).line == 0xFF) {
            continue;
        }
        normalMeters.push_back(AT(m_vWinMeters, i));
    }
    if (normalMeters.size() <= 1) {
        return MAX_SOUND_IDS;
    }
    return AT(m_vecLineSounds, Line);
}

myVector<InterruptPacketData> RgLegacyOfFire::InterruptAfterSpin() {
    myVector<InterruptPacketData> packets;
    if (m_nCountToConvert) {
        
        UINT32 convertDelay = max(2, m_nCountToConvert) * 1300;
        packets.push_back({
                 100,
                 convertDelay,
                 {0x06, 0xac, 0x2d, 0x01, 0x02, 0x31, 0x00, 0x00, 0x00, 0xac, 0x2d, 0xd0, 0x04} });
    }
    
    return packets;
}

myVector<UINT8> RgLegacyOfFire::ShowTotalWinLines(myVector<WinMeter> SpinMeters) {
    myVector<uint8_t> packet = {
        0x06, 0x30, 0x59, 0x01, 0x02, 0x31, 0x00,
        0x0F, 0x00,  // Placeholder for length 
        0x0F, 0x11, // GameID
        0x9C, 0x19, 0x01
    };
    myVector<UINT8> TotalMatch;
    for (int i = 0; i < SpinMeters.size(); i++) {
        if (AT(SpinMeters, i).line == 0xFF) { // clear after convert action
            TotalMatch.clear();
            continue;
        }
        TotalMatch.push_back(AT(SpinMeters, i).line);
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter >> 8) & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter2 & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter2 >> 8) & 0xFF));
    }
    if (TotalMatch.size() < 10) {
        myVector<UINT8> _;
        return _;
    }
    UINT16 pktLen = 1 + (TotalMatch.size() / 5) * 7;
    AT(packet, 7) = static_cast<BYTE>(pktLen & 0xFF);
    AT(packet, 8) = static_cast<BYTE>((pktLen >> 8) & 0xFF);
    AT(packet, 9) = static_cast<BYTE>(m_nGameID & 0xFF);
    AT(packet, 10) = static_cast<BYTE>((m_nGameID >> 8) & 0xFF);
    int entryCount = static_cast<int>(TotalMatch.size() / 5);
    for (int i = 0; i < entryCount; ++i) {
        packet.push_back(AT(TotalMatch, i * 5 + 0)); // Line
        packet.push_back(AT(TotalMatch, i * 5 + 1)); // Meter low byte
        packet.push_back(AT(TotalMatch, i * 5 + 2)); // Meter high byte
        packet.push_back(AT(TotalMatch, i * 5 + 3)); // Meter2 low byte
        packet.push_back(AT(TotalMatch, i * 5 + 4)); // Meter2 high byte
        packet.push_back(0x01);      // Status or flag 1
        packet.push_back(0x01);      // Status or flag 2
    }
    // Mark the end of the packet
    packet.back() = 0x04;
    return packet;
}

bool RgLegacyOfFire::RTP_force_bigWin() {
    return (myRandom() % 100 == 0); // 1%
}

BOOL RgLegacyOfFire::SelectedableReelsInFreeGame(myVector<UINT8> result) {
    if (m_bFreeMode == FALSE) {
        return TRUE;
    }
    myVector<UINT8> cp = m_vWinResult;
    m_vWinResult = result;
    int n = CardCount(RgLegacyOfFire_scatter);
    m_vWinResult = cp;
    if (n >= 3) {
        return FALSE;
    }
    return TRUE;
}

void RgLegacyOfFire::updateCheckPoint() {
    std::ostringstream oss;
    oss << " P" << m_nCurrentReelPlan
        << " B"
        << static_cast<int>(AT(m_vWinResult, 0)) << ":"
        << static_cast<int>(AT(m_vWinResult, 1)) << ":"
        << static_cast<int>(AT(m_vWinResult, 2)) << ":"
        << static_cast<int>(AT(m_vWinResult, 3)) << ":"
        << static_cast<int>(AT(m_vWinResult, 4)) << " ";

    if (m_bFreeMode && m_nFreeModeGoneSpin < m_nFreeModeTotalSpin) {
        oss << " F"
            << static_cast<int>(m_nFreeModeTotalSpin) << ":"
            << static_cast<int>(m_nFreeModeGoneSpin) << ":"
            << static_cast<int>(m_nFreeModeTotalBonus.coin) << ":"
            << static_cast<int>(m_nFreeModeTotalBonus.ag) << " ";
    }
    m_strCheckPoint = oss.str();
}