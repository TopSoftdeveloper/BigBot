#include "stdafx.h"
#include <vector>
#include <string>
#include <sstream>
#include <iostream>
#include "Utils.h"
#include <cstdlib>
#include <ctime>
#include <array>
#include <chrono>
#include <random>
#include <ntsecapi.h>
#include "ReelGame.h"

#pragma comment(lib, "advapi32.lib")

namespace {
// mt19937 is fast but not cryptographic; seed it from OS entropy (RtlGenRandom) plus mixed sources
// so mini/embedded Windows builds do not collapse to a weak single random_device() word.
void robust_seed_mt19937(std::mt19937& rng) {
	std::array<uint32_t, 32> parts{};
	const BOOL ok = RtlGenRandom(parts.data(), static_cast<ULONG>(parts.size() * sizeof(uint32_t)));
	if (!ok) {
		std::random_device rd;
		for (auto& p : parts)
			p = static_cast<uint32_t>(rd()) ^ (static_cast<uint32_t>(rd()) << 16);
	}
	const uint64_t ticks = GetTickCount64();
	parts[0] ^= static_cast<uint32_t>(ticks);
	parts[1] ^= static_cast<uint32_t>(ticks >> 32);
	LARGE_INTEGER qpc{};
	if (QueryPerformanceCounter(&qpc)) {
		parts[2] ^= static_cast<uint32_t>(static_cast<ULONG_PTR>(qpc.QuadPart));
		parts[3] ^= static_cast<uint32_t>(static_cast<ULONG_PTR>(qpc.QuadPart) >> 32);
	}
	const uint64_t ns = static_cast<uint64_t>(
		std::chrono::high_resolution_clock::now().time_since_epoch().count());
	parts[4] ^= static_cast<uint32_t>(ns);
	parts[5] ^= static_cast<uint32_t>(ns >> 32);
	parts[6] ^= GetCurrentProcessId();
	parts[7] ^= GetCurrentThreadId();
	std::seed_seq sseq(parts.begin(), parts.end());
	rng.seed(sseq);
}
} // namespace

int g_match_lines_10_5[10][5] = {
    {1, 1, 1, 1, 1},
    {2, 2, 2, 2, 2},
    {0, 0, 0, 0, 0},
    {2, 1, 0, 1, 2},
    {0, 1, 2, 1, 0},

    {2, 2, 1, 0, 0},
    {0, 0, 1, 2, 2},
    {1, 2, 2, 2, 1},
    {1, 0, 0, 0, 1},
    {2, 1, 1, 1, 2},
};

int g_match_lines_pyramid[16][5] = {
    {4, 3, 2, 1, 0},
    {3, 3, 2, 1, 0},
    {3, 2, 2, 1, 0},
    {3, 2, 1, 1, 0},
    {3, 2, 1, 0, 0},
    {2, 2, 2, 1, 0},
    {2, 2, 1, 1, 0},
    {2, 2, 1, 0, 0},
    {2, 1, 1, 1, 0},
    {2, 1, 1, 0, 0},
    {2, 1, 0, 0, 0},
    {1, 1, 1, 1, 0},
    {1, 1, 1, 0, 0},
    {1, 1, 0, 0, 0},
    {1, 0, 0, 0, 0},
    {0, 0, 0, 0, 0},
};

int g_match_lines_5_3[5][3] = {
    {1, 1, 1},
    {2, 2, 2},
    {0, 0, 0},
    {2, 1, 0},
    {0, 1, 2},
};

int g_match_lines_RgPharosGoldBase[10][5] = {
    {1, 1, 1, 1, 1},
    {2, 2, 2, 2, 2},
    {0, 0, 0, 0, 0},
    {2, 1, 0, 1, 2},
    {0, 1, 2, 1, 0},
    {1, 2, 1, 2, 1},
    {1, 0, 1, 0, 1},
    {2, 2, 1, 0, 0},
    {0, 0, 1, 2, 2},
    {2, 1, 1, 1, 2},
};

ReelGame::ReelGame() {
    m_nMagicCount = 0;
    m_bPrevSpinMatchedActive = FALSE;
}

void ReelGame::SetGameID(UINT16 id) {
    m_nGameID = id;
}

UINT16 ReelGame::GetGameId() {
    return m_nGameID;
}

std::string ReelGame::GetGameName() {
    return m_strGameName;
}

UINT16 ReelGame::Run() {
    if (m_vecReelStripPlan.size() <= 1) {
        m_nCurrentReelPlan = 0;
    }
    else {
        m_nCurrentReelPlan = (myRandom() % m_vecReelStripPlan.size());
    }
    //m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));
    return m_shCurrentReelStrip;
}

void ReelGame::ChangeReelStrip(UINT16 NewReelPlan) {
    m_nCurrentReelPlan = NewReelPlan;
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));
}

myVector<UINT8> ReelGame::Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) {
    m_bPrevSpinMatchedActive = FALSE;

    myVector<UINT8> result;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);

    if (bTest) {
        std::string matchSymbol = AT(m_vecSymbols, myRandom() % m_vecSymbols.size());
        int line = (myRandom() % m_nWinLine);
        int weight = 1 + (myRandom() % 5);
        for (int i = 0; i < m_nReel; i++) {
            ReelStrip reelStrip = AT(reelSet, i);
            int len = reelStrip.size() - 3;

            int valid_i[0x100];
            int valid_count = 0;
            for (int j = 0; j <= len; j++) {
                if (weight > i) {
                    if (matchSymbol == AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                else {
                    if (matchSymbol != AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
            }
            if (valid_count > 0) {
                int rand_index = myRandom() % valid_count;
                int chosen_i = valid_i[rand_index];
                result.push_back(chosen_i + 1);
            }
            else {
                result.push_back((myRandom() % (len - 1)) + 1);
            }
        }
    }
    else {
        result = _result;
    }
    normalMeter = 0;
    maxMeter = 0;
    BONUS totalBonus = {0, 0};
    for (int i = 0; i < m_nWinLine; i++) {
        int j = 1;
        UINT16 meter = ((UINT16)1 << (2 - g_match_lines_10_5[i][0]));
        
        for (; j < m_nMaxMatch; j++) {
            if (AT(AT(reelSet, j - 1), AT(result, j - 1) - 1 + g_match_lines_10_5[i][j - 1]) == AT(AT(reelSet, j), AT(result, j) - 1 + g_match_lines_10_5[i][j])) {

                meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
                continue;
            }
            break;
        }
        std::string firstSymbol = AT(AT(reelSet, 0), AT(result, 0) - 1 + g_match_lines_10_5[i][0]);
        if (j < m_mapSymbolMinMatch[firstSymbol]) {
            continue;
        }

        // monitor 2 meter
        std::string meterStr = m_mapSymbolMeterGoc[firstSymbol];
        size_t pos = meterStr.find('$');
        if (pos != std::string::npos) {
            meterStr = meterStr.replace(pos, 1, std::to_string(j));
        }

        WinMeter e;
        e.line = i;
        e.meter = meter;
        e.meter2 = g_GrafficObjList.Str2GOCID(meterStr);
        e.symbol = firstSymbol;
        e.weight = j;
        e.start = 0;
        e.bonus = m_Bonus[BetStep()][firstSymbol][j];
        e.sound = MAX_SOUND_IDS;

        totalBonus.coin += e.bonus.coin;
        totalBonus.ag += e.bonus.ag;
        
        if (e.meter2 != -1) {
            meters.push_back(e);
        }
        if (j == m_nMaxMatch) {
            maxMeter |= meter;
        }
        else {
            normalMeter |= meter;
        }
        if (bTest == FALSE) {
            m_bPrevSpinMatchedActive = TRUE;
        }
    }
    if (bTest == FALSE) {
        m_vWinResult = result;
        updateCheckPoint();
        if (totalBonus.coin > 0 || totalBonus.ag > 0) {
            BonusSound = getSoundByID(WinSound(totalBonus.coin + totalBonus.ag * 1000));
        }
        else {
            BonusSound.duration = 0;
            BonusSound.soundID = MAX_SOUND_IDS;
        }
    }
    return result;
}

UINT16 ReelGame::LineSound(UINT Line, std::string symbol, UINT8 weight) {
    if (m_vecLineSounds.size() <= Line) {
        return MAX_SOUND_IDS;
    }
    return AT(m_vecLineSounds, Line);
}

UINT16 ReelGame::WinSound(UINT32 totalBonus) {
    const UINT16 bet = BetBit();
    int n = totalBonus / bet / 4;

    if (n >= m_vecWinSounds.size()) {
        n = m_vecWinSounds.size() - 1;
    }
    return AT(m_vecWinSounds, n);
}

myVector<UINT16> ReelGame::Bets() {
    return m_vecBetSteps;
}

int ReelGame::LineSwapDelay(int WinIdx) {
    return 1000;
}

UINT16 ReelGame::BetBit() {
    const auto bets = Bets();
    return AT(bets, BetStep());
}

void ReelGame::SetBetStep(int newStep) {
    m_nBetStep = newStep;
}

UINT8 ReelGame::BetUp() {
    const auto& bets = Bets();
    m_nBetStep = (m_nBetStep + 1) % bets.size();
    return static_cast<UINT8>(m_nBetStep);
}

UINT8 ReelGame::MaxBet() {
    m_nBetStep = Bets().size() - 1;
    return static_cast<UINT8>(m_nBetStep);
}

UINT8 ReelGame::BetStep() {
    return m_nBetStep;
}

UINT16 ReelGame::SpinTime_MS() {
    return 2000;
}

BOOL ReelGame::CanFreeMode() {
    return FALSE;
}

UINT8 ReelGame::Wildcount() {
    return 0;
}

myVector<InterruptPacketData> ReelGame::EnterFreeGame(std::string check) {
    myVector<InterruptPacketData> empty;
    return empty;
}

myVector<InterruptPacketData> ReelGame::InterruptAfterMoveBonus(BOOL &EndFree) {
    myVector<InterruptPacketData> empty;
    EndFree = FALSE;
    return empty;
}

myVector<InterruptPacketData> ReelGame::InterruptAfterSpin() {
    myVector<InterruptPacketData> empty;
    return empty;
}

myVector<InterruptPacketData> ReelGame::InterruptBeforeSpin() {
    myVector<InterruptPacketData> empty;
    return empty;
}

myVector<InterruptPacketData> ReelGame::InterruptBeforeRisiko() {
    myVector<InterruptPacketData> empty;
    return empty;
}

BOOL ReelGame::PlayBonusSoundAfterWinLine() {
    return FALSE;
}

BOOL ReelGame::stopAllSoundBeforeMove() {
    return FALSE;
}

//change to casino slot game rtp
//int myRandom() {
//    static std::mt19937 gprng;
//    static bool seeded = false;
//    if (!seeded) {
//        gprng.seed(static_cast<unsigned int>(
//            std::chrono::steady_clock::now().time_since_epoch().count()));
//        seeded = true;
//    }
//    static std::uniform_int_distribution<int> dist(0, 9999);
//    return dist(gprng);
//}

// Fast PRNG: seeded once per thread from OS RNG + mixed entropy; output range 0..9999.
int myRandom() {
	thread_local std::mt19937 rng;
	thread_local std::uniform_int_distribution<int> dist(0, 9999);
	thread_local bool seeded = false;
	if (!seeded) {
		robust_seed_mt19937(rng);
		seeded = true;
	}
	return dist(rng);
}

myVector<UINT16> ReelGame::CurrentReelStrip() {
    myVector<UINT16> ret;
    ret.push_back(m_shCurrentReelStrip);
    return ret;
}

int ReelGame::CurrentReelSetIdx() {
    return m_nCurrentReelPlan;
}

myVector<UINT8> ReelGame::AdditionalParam() {
    return m_vecAdditionalParam;
}
UINT8 ReelGame::WinLine() {
    return m_nWinLine;
}

UINT ReelGame::GameMode() {
    return 0;
}

myVector<InterruptPacketData> ReelGame::MousePressed(MousePosition p) {
    myVector<InterruptPacketData> _;
    return _;
}

void ReelGame::PrintBonusSet(const std::string& label,
    myVector<UINT16> betSteps,
    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> bonusMap)
{
    return;
    if (betSteps.empty() || bonusMap.empty())
        return;

    DebugPrintf("==== %s ====\n", label.c_str());
    DebugPrintf("Bet Steps:\n");
    for (size_t i = 0; i < betSteps.size(); ++i) {
        DebugPrintf("  %zu: %d\n", i, AT(betSteps, i));
    }
    DebugPrintf("\n");

    for (const auto& outerPair : bonusMap) {
        UINT16 i = outerPair.first;
        const auto& perSym = outerPair.second;

        if (i >= betSteps.size()) {
            // Out-of-bounds check
            continue;
        }

        UINT16 betValue = AT(betSteps, i);
        DebugPrintf("Bet Value: %d\n", betValue);

        for (const auto& symPair : perSym) {
            const std::string& symbol = symPair.first;
            const auto& bonusMap = symPair.second;

            DebugPrintf("  Symbol: %s\n", symbol.c_str());

            for (const auto& bonusPair : bonusMap) {
                UINT8 key = bonusPair.first;
                const BONUS& bonus = bonusPair.second;

                DebugPrintf("    Key: %d | Coin: %d | AG: %d\n",
                    key, bonus.coin, bonus.ag);
            }
        }

        DebugPrintf("-------------------------\n");
    }
}

void ReelGame::PrintAllBonus() {
    return;
    if (!m_vecBetSteps_05.empty()) {
        PrintBonusSet("Bonus 05", m_vecBetSteps_05, m_Bonus_05);
    }

    if (!m_vecBetSteps_10.empty()) {
        PrintBonusSet("Bonus 10", m_vecBetSteps_10, m_Bonus_10);
    }

    if (m_vecBetSteps_05.empty() && m_vecBetSteps_10.empty()) {
        PrintBonusSet("Default Bonus", m_vecBetSteps, m_Bonus);
    }
}

UINT16 ReelGame::MagicCount() {
    return 0;
}

BOOL ReelGame::CanMultiGo() {
    return FALSE;
}

myVector<InterruptPacketData> ReelGame::EnterMultiGo(UINT32& bonusErfolg, BOOL bIitMultiBet) {
    myVector<InterruptPacketData> empty;   
    return empty;
}

myVector<InterruptPacketData> ReelGame::CloseMultiGo(UINT32& bonusErfolg, BOOL force) {
    myVector<InterruptPacketData> empty;
    return empty;
}

myVector<InterruptPacketData> ReelGame::BetUpMultiGo(UINT32& bonusErfolg) {
    myVector<InterruptPacketData> empty;
    return empty;
}

myVector<InterruptPacketData> ReelGame::BetDownMultiGo(UINT32& bonusErfolg) {
    myVector<InterruptPacketData> empty;
    return empty;
}

void ReelGame::MultiGoGoneAndRemain(UINT8& gone, UINT8& total, UINT8& loop) {
    gone = 0;
    total = 0;
    loop = 0;
}

UINT16 ReelGame::MiltiGoBet() {
    return 0;
}

UINT8 ReelGame::MultiGoBetStep() {
    return 0;    
}

void ReelGame::SetMultiGoBetStep(UINT8 newStep) {
}

BOOL ReelGame::GetMultiGoEnable() {
    return FALSE;
}

void ReelGame::SetMultiGoEnable(BOOL status) {
}

void ReelGame::GetMultiGoReelPlanIdx(int& p0, int& p1, int& p2, int& p3) {
}

void ReelGame::SetMultiGoReelPlanIdx(int p0, int p1, int p2, int p3) {
}

myVector<UINT8> ReelGame::ShowTotalWinLines(myVector<WinMeter> SpinMeters) {
    myVector<uint8_t> packet = {
        0x06, 0x30, 0x59, 0x01, 0x02, 0x31, 0x00,
        0x0F, 0x00,  // Placeholder for length 
        0x0F, 0x11, // GameID
        0x9C, 0x13, 0x01
    };
    myVector<UINT8> TotalMatch;
    for (int i = 0; i < SpinMeters.size(); i++) {
        TotalMatch.push_back(AT(SpinMeters, i).line);
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter >> 8) & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter2 & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter2 >> 8) & 0xFF));
    }
    if (TotalMatch.size() < 10) {
        myVector<UINT8> _;
        return _;
    }
    UINT16 pktLen = 1 + (TotalMatch.size() / 5) * 7;
    AT(packet, 7) = static_cast<BYTE>(pktLen & 0xFF);
    AT(packet, 8) = static_cast<BYTE>((pktLen >> 8) & 0xFF);
    AT(packet, 9) = static_cast<BYTE>(m_nGameID & 0xFF);
    AT(packet, 10) = static_cast<BYTE>((m_nGameID >> 8) & 0xFF);
    int entryCount = static_cast<int>(TotalMatch.size() / 5);
    for (int i = 0; i < entryCount; ++i) {
        packet.push_back(AT(TotalMatch, i * 5 + 0)); // Line
        packet.push_back(AT(TotalMatch, i * 5 + 1)); // Meter low byte
        packet.push_back(AT(TotalMatch, i * 5 + 2)); // Meter high byte
        packet.push_back(AT(TotalMatch, i * 5 + 3)); // Meter2 low byte
        packet.push_back(AT(TotalMatch, i * 5 + 4)); // Meter2 high byte
        packet.push_back(0x01);      // Status or flag 1
        packet.push_back(0x01);      // Status or flag 2
    }
    // Mark the end of the packet
    packet.back() = 0x04;
    return packet;
}

myVector<InterruptPacketData> ReelGame::SelectSymbol(std::string symbol) {
    myVector<InterruptPacketData> empty;
    return empty;
}


myVector<InterruptPacketData> ReelGame::OnBetUp(int OrgBetStep, int NewBetStep) {
    myVector<InterruptPacketData> empty;
    return empty;
}

void ReelGame::LoadBets() {
    int betSteps5[20];
    int betSteps10[20];
    int betMin5;
    int betMax5;
    int betMin10;
    int betMax10;
    PlayDB& playDB = PlayDB::GetInstance();
    playDB.GetBetInfo(playDB.GetGameID(m_strGameName), betSteps5, betSteps10, betMin5, betMax5, betMin10, betMax10);

    m_vecBetSteps.clear();
    m_vecBetSteps_05.clear();
    m_vecBetSteps_10.clear();
    for (int i = 0; i < 20; i++) {
        if (betSteps5[i] >= betMin5 && betSteps5[i] <= betMax5) {
            m_vecBetSteps_05.push_back(betSteps5[i]);
        }
        if (betSteps10[i] >= betMin10 && betSteps10[i] <= betMax10) {
            m_vecBetSteps_10.push_back(betSteps10[i]);
        }
    }
    // Active bet step list for this game: match win-line mode. (PlayDB may only define 5-line or only 10-line.)
    m_vecBetSteps = !m_vecBetSteps_05.empty() ? m_vecBetSteps_05 : m_vecBetSteps_10;
}

bool ReelGame::RTP_force_bigWin() {
    return (myRandom() % 65 == 0); // 1.53%
}

myVector<int> ReelGame::GetStartInfo() {
    myVector<int> ret;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);

    for (int i = 0; i < m_nReel; i++) {
        ReelStrip reelStrip = AT(reelSet, i);
        int len = reelStrip.size();
        ret.push_back(len / 3 + (myRandom() % (len / 3)));
    }
    return ret;
}

int ReelGame::GetWinLine() {
    return m_nWinLine;
}
void ReelGame::SetWinLine(int newWinLine) {
    m_nWinLine = newWinLine;
}


BOOL ReelGame::SelectedableReelsInFreeGame(myVector<UINT8> result) {
    return TRUE;
}

BOOL ReelGame::NoFunInFreeMode() {
    return FALSE;
}

BOOL LessThanOrEqual(_Point a, _Point b) {
    if (a.region < b.region) return TRUE;
    if (a.region > b.region) return FALSE;
    return a.pos <= b.pos;
}

_Point MinPoint(_Point a, _Point b) {
    return LessThanOrEqual(a, b) ? a : b;
}

_Point MaxPoint(_Point a, _Point b) {
    return LessThanOrEqual(a, b) ? b : a;
}

BOOL IsMouseWithin(MousePosition target, MousePosition a, MousePosition b) {
    _Point minX = MinPoint(a.x, b.x);
    _Point maxX = MaxPoint(a.x, b.x);
    _Point minY = MinPoint(a.y, b.y);
    _Point maxY = MaxPoint(a.y, b.y);

    return LessThanOrEqual(minX, target.x) && LessThanOrEqual(target.x, maxX) &&
        LessThanOrEqual(minY, target.y) && LessThanOrEqual(target.y, maxY);
}

std::string ReelGame::CheckPoint() {
    return m_strCheckPoint;
}

void ReelGame::updateCheckPoint() {
    std::ostringstream oss;
    oss << " P" << m_nCurrentReelPlan
        << " B"
        << static_cast<int>(AT(m_vWinResult, 0)) << ":"
        << static_cast<int>(AT(m_vWinResult, 1)) << ":"
        << static_cast<int>(AT(m_vWinResult, 2)) << ":"
        << static_cast<int>(AT(m_vWinResult, 3)) << ":"
        << static_cast<int>(AT(m_vWinResult, 4)) << " ";
    m_strCheckPoint = oss.str();
}

myVector<int> ReelGame::ParseCheckPoint(std::string check, std::string prefix, int num) {
    size_t pos = check.find(prefix);
    std::string f_data = check.substr(pos + 1);
    size_t end_pos = f_data.find(' ');
    if (end_pos != std::string::npos) {
        f_data = f_data.substr(0, end_pos);
    }
    std::stringstream ss(f_data);
    std::string token;
    myVector<int> values;
    int i = 0;
    while (std::getline(ss, token, ':') && i < num) {
        values.push_back(std::stoi(token));
        ++i;
    }
    return values;
}

std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> ReelGame::GetBonus() {
    return m_Bonus;
}

void ReelGame::SetBonus(std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> b) {
    m_Bonus = b;
}

void ReelGame::SetBets(myVector<UINT16> b) {
    m_vecBetSteps = b;   
}