#pragma once

#include "ReelGame.h"

class RgEyeOfHorus : public ReelGame
{
public:
	
	UINT8 m_nConvertedInFreeMode;

	UINT8 m_nFreeModeTotalSpin;
	UINT8 m_nFreeModeGoneSpin;
	BONUS m_nFreeModeTotalBonus;
	BOOL m_bFreeMode;

	RgEyeOfHorus::RgEyeOfHorus();

	UINT16 Run() override;
	myVector<UINT8> Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& WinSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) override;
	UINT16 SpinTime_MS() override;
	BOOL CanFreeMode() override;
	UINT8 Wildcount() override;

	UINT8 ScatterCount();
	UINT8 CardCount(std::string card);	

	myVector<InterruptPacketData> EnterFreeGame(std::string) override;
	myVector<InterruptPacketData> InterruptAfterMoveBonus(BOOL& EndFree) override;
	myVector<InterruptPacketData> InterruptBeforeSpin() override;

	BOOL WildcountInCol(UINT8 col, myVector<UINT8> result);
	UINT8 NumberOfScatter(myVector<UINT8> result);
	void ChangeReelStrip(UINT16 NewReelPlan) override;

	myVector<InterruptPacketData> MousePressed(MousePosition p) override;
	myVector<UINT8> ShowTotalWinLines(myVector<WinMeter> SpinMeters) override;

	BOOL SelectedableReelsInFreeGame(myVector<UINT8> result) override;
	BOOL NoFunInFreeMode() override;

	void updateCheckPoint();
};
