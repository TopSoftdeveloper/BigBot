#include "stdafx.h"

#include "RgFruitinator.h"
#define RgFruitinator_top "CFRT_SEVEN_"

RgFruitinator::RgFruitinator() {
	m_nReel = 5;
	m_nWinLine = 5;
    m_nMaxMatch = 5;
    m_nBetStep = 0; 

    m_strGameName = "RgFruitinator";

    myVector<UINT16> m_vecBetSteps_tmp;
    m_vecBetSteps_tmp.push_back(5);
    m_vecBetSteps_tmp.push_back(10);
    m_vecBetSteps_tmp.push_back(20);
    m_vecBetSteps_tmp.push_back(30);
    m_vecBetSteps_tmp.push_back(40);
    m_vecBetSteps_tmp.push_back(50);
    m_vecBetSteps_tmp.push_back(60);
    m_vecBetSteps_tmp.push_back(80);
    m_vecBetSteps_tmp.push_back(100);
#ifdef BIGBET_ACTIVE
    m_vecBetSteps_tmp.push_back(200);
    m_vecBetSteps_tmp.push_back(500);
#endif
    LoadBets();

	m_vecSymbols.push_back("CFRT_SEVEN_");
	m_vecSymbols.push_back("CFRT_BELL__");
	m_vecSymbols.push_back("CFRT_MELON_");
	m_vecSymbols.push_back("CFRT_PLUM__");
	m_vecSymbols.push_back("CFRT_ORANGE");
	m_vecSymbols.push_back("CFRT_LEMON_");
	m_vecSymbols.push_back("CFRT_CHERRY");

    m_mapSymbolMinMatch["CFRT_SEVEN_"] = 3;
    m_mapSymbolMinMatch["CFRT_BELL__"] = 3;
    m_mapSymbolMinMatch["CFRT_MELON_"] = 3;
    m_mapSymbolMinMatch["CFRT_PLUM__"] = 3;
    m_mapSymbolMinMatch["CFRT_ORANGE"] = 3;
    m_mapSymbolMinMatch["CFRT_LEMON_"] = 3;
    m_mapSymbolMinMatch["CFRT_CHERRY"] = 2;

    m_mapSymbolMeterGoc["CFRT_SEVEN_"] = "cfrtSeven$x";
    m_mapSymbolMeterGoc["CFRT_BELL__"] = "cfrtBell$x";
    m_mapSymbolMeterGoc["CFRT_MELON_"] = "cfrtMelon$x";
    m_mapSymbolMeterGoc["CFRT_PLUM__"] = "cfrtPlum$x";
    m_mapSymbolMeterGoc["CFRT_ORANGE"] = "cfrtOrange$x";
    m_mapSymbolMeterGoc["CFRT_LEMON_"] = "cfrtLemon$x";
    m_mapSymbolMeterGoc["CFRT_CHERRY"] = "cfrtCherry$x";


	m_vecWinLines.push_back("WinL1CFRT");
	m_vecWinLines.push_back("WinL2CFRT");
	m_vecWinLines.push_back("WinL3CFRT");
	m_vecWinLines.push_back("WinL4CFRT");
	m_vecWinLines.push_back("WinL5CFRT");

    m_vecLineSounds.push_back(SMP_CFRT_WinStep5_1);
    m_vecLineSounds.push_back(SMP_CFRT_WinStep5_2);
    m_vecLineSounds.push_back(SMP_CFRT_WinStep5_3);
    m_vecLineSounds.push_back(SMP_CFRT_WinStep5_4);
    m_vecLineSounds.push_back(SMP_CFRT_WinStep5_5);

    m_vecWinSounds.push_back(SMP_CFRT_WinMini);
    m_vecWinSounds.push_back(SMP_CFRT_WinMinor);
    m_vecWinSounds.push_back(SMP_CFRT_WinSmall);
    m_vecWinSounds.push_back(SMP_CFRT_WinMedium);
    m_vecWinSounds.push_back(SMP_CFRT_WinLarge);
    m_vecWinSounds.push_back(SMP_CFRT_WinXlarge);
    m_vecWinSounds.push_back(SMP_CFRT_WinHuge);
    m_vecWinSounds.push_back(SMP_CFRT_WinMega);

    m_vecReelStripPlan.push_back("cfrtW1A");
    m_vecReelStripPlan.push_back("cfrtW1B");
    m_vecReelStripPlan.push_back("cfrtW1DUMMY");

    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));

    char* cfrtReelStrip[] = {
        "CFRT_SEVEN_,CFRT_LEMON_,CFRT_LEMON_,CFRT_LEMON_,CFRT_CHERRY,CFRT_LEMON_,CFRT_CHERRY,CFRT_CHERRY,CFRT_MELON_,CFRT_CHERRY,CFRT_MELON_,CFRT_MELON_,CFRT_SEVEN_,CFRT_MELON_,CFRT_MELON_,CFRT_PLUM__,CFRT_MELON_,CFRT_PLUM__,CFRT_PLUM__,CFRT_ORANGE,CFRT_PLUM__,CFRT_ORANGE,CFRT_ORANGE,CFRT_SEVEN_,CFRT_ORANGE,CFRT_ORANGE,CFRT_ORANGE,CFRT_BELL__,CFRT_BELL__,CFRT_LEMON_,CFRT_LEMON_,CFRT_LEMON_,CFRT_CHERRY,CFRT_LEMON_,CFRT_CHERRY,CFRT_LEMON_,CFRT_CHERRY,CFRT_CHERRY,CFRT_SEVEN_,CFRT_CHERRY,CFRT_CHERRY,CFRT_MELON_,CFRT_MELON_,CFRT_MELON_,CFRT_BELL__,CFRT_BELL__,CFRT_LEMON_,CFRT_LEMON_,CFRT_LEMON_,CFRT_BELL__,CFRT_BELL__,CFRT_MELON_,CFRT_MELON_,CFRT_MELON_,CFRT_LEMON_,CFRT_MELON_,CFRT_MELON_,CFRT_LEMON_,CFRT_LEMON_,CFRT_LEMON_",
        "CFRT_SEVEN_,CFRT_ORANGE,CFRT_ORANGE,CFRT_BELL__,CFRT_BELL__,CFRT_MELON_,CFRT_MELON_,CFRT_MELON_,CFRT_SEVEN_,CFRT_MELON_,CFRT_MELON_,CFRT_ORANGE,CFRT_ORANGE,CFRT_BELL__,CFRT_BELL__,CFRT_LEMON_,CFRT_LEMON_,CFRT_CHERRY,CFRT_CHERRY,CFRT_MELON_,CFRT_MELON_,CFRT_MELON_,CFRT_PLUM__,CFRT_PLUM__,CFRT_PLUM__,CFRT_LEMON_,CFRT_LEMON_,CFRT_PLUM__,CFRT_PLUM__,CFRT_CHERRY,CFRT_CHERRY,CFRT_ORANGE,CFRT_ORANGE,CFRT_SEVEN_,CFRT_ORANGE,CFRT_ORANGE,CFRT_ORANGE,CFRT_SEVEN_,CFRT_ORANGE,CFRT_ORANGE,CFRT_MELON_,CFRT_MELON_,CFRT_BELL__,CFRT_BELL__,CFRT_MELON_,CFRT_MELON_,CFRT_MELON_,CFRT_ORANGE,CFRT_ORANGE,CFRT_ORANGE,CFRT_MELON_,CFRT_MELON_,CFRT_ORANGE,CFRT_ORANGE",
        "CFRT_SEVEN_,CFRT_LEMON_,CFRT_LEMON_,CFRT_PLUM__,CFRT_LEMON_,CFRT_PLUM__,CFRT_PLUM__,CFRT_SEVEN_,CFRT_PLUM__,CFRT_PLUM__,CFRT_CHERRY,CFRT_PLUM__,CFRT_CHERRY,CFRT_PLUM__,CFRT_CHERRY,CFRT_CHERRY,CFRT_SEVEN_,CFRT_CHERRY,CFRT_CHERRY,CFRT_CHERRY,CFRT_BELL__,CFRT_CHERRY,CFRT_BELL__,CFRT_BELL__,CFRT_ORANGE,CFRT_ORANGE,CFRT_PLUM__,CFRT_PLUM__,CFRT_PLUM__,CFRT_MELON_,CFRT_PLUM__,CFRT_MELON_,CFRT_MELON_,CFRT_MELON_,CFRT_ORANGE,CFRT_ORANGE,CFRT_LEMON_,CFRT_LEMON_,CFRT_LEMON_,CFRT_BELL__,CFRT_BELL__,CFRT_PLUM__,CFRT_BELL__,CFRT_PLUM__,CFRT_PLUM__,CFRT_LEMON_,CFRT_LEMON_,CFRT_SEVEN_,CFRT_LEMON_,CFRT_LEMON_,CFRT_CHERRY,CFRT_LEMON_,CFRT_LEMON_,CFRT_CHERRY,CFRT_CHERRY,CFRT_LEMON_,CFRT_CHERRY,CFRT_LEMON_,CFRT_LEMON_,CFRT_LEMON_",
        "CFRT_SEVEN_,CFRT_ORANGE,CFRT_ORANGE,CFRT_ORANGE,CFRT_ORANGE,CFRT_SEVEN_,CFRT_ORANGE,CFRT_ORANGE,CFRT_PLUM__,CFRT_ORANGE,CFRT_PLUM__,CFRT_PLUM__,CFRT_BELL__,CFRT_PLUM__,CFRT_BELL__,CFRT_PLUM__,CFRT_BELL__,CFRT_PLUM__,CFRT_PLUM__,CFRT_CHERRY,CFRT_CHERRY,CFRT_CHERRY,CFRT_BELL__,CFRT_CHERRY,CFRT_BELL__,CFRT_BELL__,CFRT_LEMON_,CFRT_LEMON_,CFRT_SEVEN_,CFRT_LEMON_,CFRT_LEMON_,CFRT_LEMON_,CFRT_PLUM__,CFRT_LEMON_,CFRT_PLUM__,CFRT_PLUM__,CFRT_SEVEN_,CFRT_PLUM__,CFRT_PLUM__,CFRT_ORANGE,CFRT_ORANGE,CFRT_ORANGE,CFRT_CHERRY,CFRT_CHERRY,CFRT_MELON_,CFRT_MELON_,CFRT_CHERRY,CFRT_CHERRY,CFRT_ORANGE,CFRT_ORANGE,CFRT_MELON_,CFRT_MELON_,CFRT_CHERRY,CFRT_CHERRY,CFRT_CHERRY,CFRT_ORANGE,CFRT_CHERRY,CFRT_ORANGE,CFRT_ORANGE,CFRT_ORANGE",
        "CFRT_SEVEN_,CFRT_PLUM__,CFRT_PLUM__,CFRT_ORANGE,CFRT_PLUM__,CFRT_ORANGE,CFRT_ORANGE,CFRT_CHERRY,CFRT_CHERRY,CFRT_BELL__,CFRT_BELL__,CFRT_CHERRY,CFRT_CHERRY,CFRT_CHERRY,CFRT_ORANGE,CFRT_ORANGE,CFRT_SEVEN_,CFRT_ORANGE,CFRT_ORANGE,CFRT_ORANGE,CFRT_BELL__,CFRT_BELL__,CFRT_LEMON_,CFRT_LEMON_,CFRT_LEMON_,CFRT_SEVEN_,CFRT_LEMON_,CFRT_LEMON_,CFRT_PLUM__,CFRT_LEMON_,CFRT_PLUM__,CFRT_PLUM__,CFRT_PLUM__,CFRT_BELL__,CFRT_BELL__,CFRT_PLUM__,CFRT_PLUM__,CFRT_SEVEN_,CFRT_PLUM__,CFRT_PLUM__,CFRT_CHERRY,CFRT_PLUM__,CFRT_CHERRY,CFRT_CHERRY,CFRT_ORANGE,CFRT_ORANGE,CFRT_ORANGE,CFRT_MELON_,CFRT_MELON_,CFRT_MELON_,CFRT_ORANGE,CFRT_ORANGE,CFRT_MELON_,CFRT_MELON_,CFRT_ORANGE,CFRT_MELON_,CFRT_ORANGE,CFRT_ORANGE,CFRT_PLUM__,CFRT_PLUM__",

        "CFRT_SEVEN_,CFRT_ORANGE,CFRT_ORANGE,CFRT_ORANGE,CFRT_ORANGE,CFRT_BELL__,CFRT_BELL__,CFRT_ORANGE,CFRT_BELL__,CFRT_BELL__,CFRT_ORANGE,CFRT_ORANGE,CFRT_PLUM__,CFRT_PLUM__,CFRT_BELL__,CFRT_PLUM__,CFRT_BELL__,CFRT_PLUM__,CFRT_PLUM__,CFRT_CHERRY,CFRT_PLUM__,CFRT_CHERRY,CFRT_PLUM__,CFRT_PLUM__,CFRT_SEVEN_,CFRT_PLUM__,CFRT_PLUM__,CFRT_ORANGE,CFRT_ORANGE,CFRT_SEVEN_,CFRT_ORANGE,CFRT_ORANGE,CFRT_LEMON_,CFRT_ORANGE,CFRT_LEMON_,CFRT_LEMON_,CFRT_SEVEN_,CFRT_LEMON_,CFRT_LEMON_,CFRT_LEMON_,CFRT_MELON_,CFRT_MELON_,CFRT_MELON_,CFRT_PLUM__,CFRT_MELON_,CFRT_PLUM__,CFRT_PLUM__,CFRT_PLUM__,CFRT_ORANGE,CFRT_ORANGE,CFRT_CHERRY,CFRT_CHERRY,CFRT_ORANGE,CFRT_ORANGE",
        "CFRT_SEVEN_,CFRT_CHERRY,CFRT_CHERRY,CFRT_SEVEN_,CFRT_CHERRY,CFRT_CHERRY,CFRT_LEMON_,CFRT_LEMON_,CFRT_LEMON_,CFRT_BELL__,CFRT_LEMON_,CFRT_BELL__,CFRT_BELL__,CFRT_PLUM__,CFRT_PLUM__,CFRT_PLUM__,CFRT_SEVEN_,CFRT_PLUM__,CFRT_PLUM__,CFRT_MELON_,CFRT_MELON_,CFRT_BELL__,CFRT_BELL__,CFRT_ORANGE,CFRT_BELL__,CFRT_ORANGE,CFRT_ORANGE,CFRT_ORANGE,CFRT_PLUM__,CFRT_PLUM__,CFRT_LEMON_,CFRT_LEMON_,CFRT_SEVEN_,CFRT_LEMON_,CFRT_LEMON_,CFRT_CHERRY,CFRT_CHERRY,CFRT_LEMON_,CFRT_LEMON_,CFRT_LEMON_,CFRT_PLUM__,CFRT_PLUM__,CFRT_PLUM__,CFRT_LEMON_,CFRT_PLUM__,CFRT_LEMON_,CFRT_LEMON_,CFRT_PLUM__,CFRT_PLUM__,CFRT_PLUM__,CFRT_MELON_,CFRT_PLUM__,CFRT_MELON_,CFRT_MELON_,CFRT_CHERRY,CFRT_CHERRY,CFRT_LEMON_,CFRT_LEMON_,CFRT_CHERRY,CFRT_CHERRY",
        "CFRT_SEVEN_,CFRT_ORANGE,CFRT_ORANGE,CFRT_ORANGE,CFRT_ORANGE,CFRT_SEVEN_,CFRT_ORANGE,CFRT_ORANGE,CFRT_PLUM__,CFRT_ORANGE,CFRT_PLUM__,CFRT_PLUM__,CFRT_PLUM__,CFRT_MELON_,CFRT_MELON_,CFRT_MELON_,CFRT_BELL__,CFRT_BELL__,CFRT_CHERRY,CFRT_CHERRY,CFRT_CHERRY,CFRT_MELON_,CFRT_MELON_,CFRT_MELON_,CFRT_SEVEN_,CFRT_MELON_,CFRT_MELON_,CFRT_CHERRY,CFRT_MELON_,CFRT_CHERRY,CFRT_CHERRY,CFRT_BELL__,CFRT_BELL__,CFRT_LEMON_,CFRT_LEMON_,CFRT_BELL__,CFRT_BELL__,CFRT_LEMON_,CFRT_LEMON_,CFRT_MELON_,CFRT_MELON_,CFRT_SEVEN_,CFRT_MELON_,CFRT_MELON_,CFRT_ORANGE,CFRT_MELON_,CFRT_ORANGE,CFRT_ORANGE,CFRT_CHERRY,CFRT_CHERRY,CFRT_ORANGE,CFRT_CHERRY,CFRT_ORANGE,CFRT_CHERRY,CFRT_CHERRY,CFRT_ORANGE,CFRT_CHERRY,CFRT_ORANGE,CFRT_ORANGE,CFRT_ORANGE",
        "CFRT_SEVEN_,CFRT_LEMON_,CFRT_LEMON_,CFRT_LEMON_,CFRT_BELL__,CFRT_BELL__,CFRT_LEMON_,CFRT_BELL__,CFRT_LEMON_,CFRT_LEMON_,CFRT_MELON_,CFRT_MELON_,CFRT_SEVEN_,CFRT_MELON_,CFRT_MELON_,CFRT_CHERRY,CFRT_CHERRY,CFRT_CHERRY,CFRT_SEVEN_,CFRT_CHERRY,CFRT_CHERRY,CFRT_LEMON_,CFRT_LEMON_,CFRT_LEMON_,CFRT_MELON_,CFRT_MELON_,CFRT_BELL__,CFRT_MELON_,CFRT_BELL__,CFRT_BELL__,CFRT_ORANGE,CFRT_ORANGE,CFRT_ORANGE,CFRT_SEVEN_,CFRT_ORANGE,CFRT_ORANGE,CFRT_ORANGE,CFRT_CHERRY,CFRT_CHERRY,CFRT_PLUM__,CFRT_PLUM__,CFRT_CHERRY,CFRT_CHERRY,CFRT_MELON_,CFRT_MELON_,CFRT_PLUM__,CFRT_PLUM__,CFRT_MELON_,CFRT_MELON_,CFRT_MELON_,CFRT_LEMON_,CFRT_LEMON_,CFRT_LEMON_,CFRT_CHERRY,CFRT_LEMON_,CFRT_CHERRY,CFRT_CHERRY,CFRT_LEMON_,CFRT_LEMON_,CFRT_LEMON_",
        "CFRT_SEVEN_,CFRT_MELON_,CFRT_MELON_,CFRT_MELON_,CFRT_BELL__,CFRT_BELL__,CFRT_PLUM__,CFRT_BELL__,CFRT_PLUM__,CFRT_PLUM__,CFRT_ORANGE,CFRT_ORANGE,CFRT_ORANGE,CFRT_SEVEN_,CFRT_ORANGE,CFRT_ORANGE,CFRT_LEMON_,CFRT_ORANGE,CFRT_LEMON_,CFRT_LEMON_,CFRT_CHERRY,CFRT_LEMON_,CFRT_CHERRY,CFRT_CHERRY,CFRT_CHERRY,CFRT_LEMON_,CFRT_LEMON_,CFRT_SEVEN_,CFRT_LEMON_,CFRT_LEMON_,CFRT_MELON_,CFRT_LEMON_,CFRT_MELON_,CFRT_MELON_,CFRT_SEVEN_,CFRT_MELON_,CFRT_MELON_,CFRT_LEMON_,CFRT_LEMON_,CFRT_BELL__,CFRT_BELL__,CFRT_LEMON_,CFRT_BELL__,CFRT_LEMON_,CFRT_LEMON_,CFRT_LEMON_,CFRT_CHERRY,CFRT_LEMON_,CFRT_CHERRY,CFRT_CHERRY,CFRT_MELON_,CFRT_CHERRY,CFRT_MELON_,CFRT_MELON_,CFRT_PLUM__,CFRT_MELON_,CFRT_PLUM__,CFRT_PLUM__,CFRT_MELON_,CFRT_MELON_",

        "CFRT_SEVEN_,CFRT_LEMON_,CFRT_LEMON_,CFRT_LEMON_,CFRT_BELL__,CFRT_LEMON_,CFRT_BELL__,CFRT_BELL__,CFRT_ORANGE,CFRT_ORANGE,CFRT_ORANGE,CFRT_ORANGE,CFRT_SEVEN_,CFRT_ORANGE,CFRT_ORANGE,CFRT_PLUM__,CFRT_PLUM__,CFRT_PLUM__,CFRT_CHERRY,CFRT_CHERRY,CFRT_CHERRY,CFRT_MELON_,CFRT_CHERRY,CFRT_MELON_,CFRT_CHERRY,CFRT_CHERRY,CFRT_PLUM__,CFRT_PLUM__,CFRT_PLUM__,CFRT_MELON_,CFRT_MELON_,CFRT_MELON_,CFRT_MELON_,CFRT_LEMON_,CFRT_LEMON_",
        "CFRT_SEVEN_,CFRT_ORANGE,CFRT_ORANGE,CFRT_ORANGE,CFRT_MELON_,CFRT_MELON_,CFRT_CHERRY,CFRT_CHERRY,CFRT_LEMON_,CFRT_LEMON_,CFRT_LEMON_,CFRT_PLUM__,CFRT_PLUM__,CFRT_BELL__,CFRT_PLUM__,CFRT_BELL__,CFRT_BELL__,CFRT_PLUM__,CFRT_PLUM__,CFRT_MELON_,CFRT_MELON_,CFRT_PLUM__,CFRT_MELON_,CFRT_MELON_,CFRT_CHERRY,CFRT_CHERRY,CFRT_SEVEN_,CFRT_CHERRY,CFRT_CHERRY,CFRT_LEMON_,CFRT_LEMON_,CFRT_ORANGE,CFRT_LEMON_,CFRT_ORANGE,CFRT_ORANGE",
        "CFRT_SEVEN_,CFRT_LEMON_,CFRT_LEMON_,CFRT_LEMON_,CFRT_BELL__,CFRT_LEMON_,CFRT_BELL__,CFRT_BELL__,CFRT_MELON_,CFRT_MELON_,CFRT_MELON_,CFRT_MELON_,CFRT_SEVEN_,CFRT_MELON_,CFRT_MELON_,CFRT_PLUM__,CFRT_PLUM__,CFRT_PLUM__,CFRT_CHERRY,CFRT_CHERRY,CFRT_CHERRY,CFRT_ORANGE,CFRT_CHERRY,CFRT_ORANGE,CFRT_CHERRY,CFRT_CHERRY,CFRT_PLUM__,CFRT_PLUM__,CFRT_PLUM__,CFRT_ORANGE,CFRT_ORANGE,CFRT_ORANGE,CFRT_ORANGE,CFRT_LEMON_,CFRT_LEMON_",
        "CFRT_SEVEN_,CFRT_ORANGE,CFRT_ORANGE,CFRT_ORANGE,CFRT_MELON_,CFRT_MELON_,CFRT_CHERRY,CFRT_CHERRY,CFRT_LEMON_,CFRT_LEMON_,CFRT_LEMON_,CFRT_PLUM__,CFRT_PLUM__,CFRT_BELL__,CFRT_PLUM__,CFRT_BELL__,CFRT_BELL__,CFRT_PLUM__,CFRT_PLUM__,CFRT_MELON_,CFRT_MELON_,CFRT_PLUM__,CFRT_MELON_,CFRT_MELON_,CFRT_CHERRY,CFRT_CHERRY,CFRT_SEVEN_,CFRT_CHERRY,CFRT_CHERRY,CFRT_LEMON_,CFRT_LEMON_,CFRT_ORANGE,CFRT_LEMON_,CFRT_ORANGE,CFRT_ORANGE",
        "CFRT_SEVEN_,CFRT_LEMON_,CFRT_LEMON_,CFRT_LEMON_,CFRT_BELL__,CFRT_LEMON_,CFRT_BELL__,CFRT_BELL__,CFRT_ORANGE,CFRT_ORANGE,CFRT_ORANGE,CFRT_ORANGE,CFRT_SEVEN_,CFRT_ORANGE,CFRT_ORANGE,CFRT_PLUM__,CFRT_PLUM__,CFRT_PLUM__,CFRT_CHERRY,CFRT_CHERRY,CFRT_CHERRY,CFRT_MELON_,CFRT_CHERRY,CFRT_MELON_,CFRT_CHERRY,CFRT_CHERRY,CFRT_PLUM__,CFRT_PLUM__,CFRT_PLUM__,CFRT_MELON_,CFRT_MELON_,CFRT_MELON_,CFRT_MELON_,CFRT_LEMON_,CFRT_LEMON_",
    };

    int idx = 0;
    for (int i = 0; i < m_vecReelStripPlan.size(); i++) {
        ReelSet set;
        for (int j = 0; j < m_nReel; j++) {
            ReelStrip strip;
            std::stringstream ss(cfrtReelStrip[idx]);
            std::string item;
            while (std::getline(ss, item, ',')) {
                strip.push_back(item);
            }
            set.push_back(strip);
            idx++;
        }
        m_vecReelStripSets.push_back(set);
    }

    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_tmp;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        std::map<std::string, std::map<UINT8, BONUS>> perSym;
        std::map<UINT8, BONUS> e;
        e[2].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5; e[2].ag = 0;
        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 200; e[5].ag = 0;
        perSym["CFRT_CHERRY"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 250; e[5].ag = 0;
        perSym["CFRT_LEMON_"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 250; e[5].ag = 0;
        perSym["CFRT_ORANGE"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 40; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 200; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 750; e[5].ag = 0;
        perSym["CFRT_PLUM__"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 40; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 200; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 750; e[5].ag = 0;
        perSym["CFRT_MELON_"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 500; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 2500; e[5].ag = 0;
        perSym["CFRT_BELL__"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 1000; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5000; e[5].ag = 0;
        perSym["CFRT_SEVEN_"] = e;

        m_Bonus_tmp[i] = perSym;
    }
    m_Bonus_tmp[m_vecBetSteps_tmp.size() - 1 - BIGBET_BETSTEP_EXTRA_COUNT]["CFRT_SEVEN_"][5].coin = 80000;

    int nSavedBetVal = 10;
    int _line = 0;
    string data;
    PlayDB::GetInstance().LoadCheckPoint(m_strGameName, nSavedBetVal, _line, m_strCheckPoint);
    if (nSavedBetVal == -1) {
        nSavedBetVal = 10;
    }

    BOOL start = FALSE;
    idx = 0;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_tmp, i) < AT(m_vecBetSteps, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps, idx) == nSavedBetVal) {
            m_nBetStep = idx;
        }

        m_Bonus[idx++] = m_Bonus_tmp[i];
        if (AT(m_vecBetSteps_tmp, i) == AT(m_vecBetSteps, m_vecBetSteps.size() - 1)) {
            break;
        }
    }

    m_vecBetSteps_05.clear();
    m_vecBetSteps_10.clear();
    PrintAllBonus();
}


myVector<UINT8> RgFruitinator::Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) {
    m_bPrevSpinMatchedActive = FALSE;

    myVector<UINT8> result;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);

    BOOL mmcode = FALSE;
    if (bTest == FALSE) {
        mmcode = mmcode_get_active_status();
    }
    if (bTest == TRUE || mmcode == TRUE) {
        std::string matchSymbol = AT(m_vecSymbols, myRandom() % m_vecSymbols.size());
        int line = (myRandom() % m_nWinLine);
        int weight = 1 + (myRandom() % 5);
        if (mmcode) {
            mmcode_set_deactive();
            weight = m_nMaxMatch;
            matchSymbol = RgFruitinator_top;
        }
        for (int i = 0; i < m_nReel; i++) {
            ReelStrip reelStrip = AT(reelSet, i);
            int len = reelStrip.size() - 3;

            int valid_i[0x100];
            int valid_count = 0;
            for (int j = 0; j <= len; j++) {
                if (weight > i) {
                    if (matchSymbol == AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                else {
                    if (matchSymbol != AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
            }
            if (valid_count > 0) {
                int rand_index = myRandom() % valid_count;
                int chosen_i = valid_i[rand_index];
                result.push_back(chosen_i + 1);
            }
            else {
                result.push_back((myRandom() % (len - 1)) + 1);
            }
        }
    }
    else {
        result = _result;
    }
    normalMeter = 0;
    maxMeter = 0;
    BONUS totalBonus = { 0, 0 };
    for (int i = 0; i < m_nWinLine; i++) {
        int j = 1;
        UINT16 meter = ((UINT16)1 << (2 - g_match_lines_10_5[i][0]));

        for (; j < m_nMaxMatch; j++) {
            if (AT(AT(reelSet, j - 1), AT(result, j - 1) - 1 + g_match_lines_10_5[i][j - 1]) == AT(AT(reelSet, j), AT(result, j) - 1 + g_match_lines_10_5[i][j])) {

                meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
                continue;
            }
            break;
        }
        std::string firstSymbol = AT(AT(reelSet, 0), AT(result, 0) - 1 + g_match_lines_10_5[i][0]);
        if (j < m_mapSymbolMinMatch[firstSymbol]) {
            continue;
        }

        // monitor 2 meter
        std::string meterStr = m_mapSymbolMeterGoc[firstSymbol];
        size_t pos = meterStr.find('$');
        if (pos != std::string::npos) {
            meterStr = meterStr.replace(pos, 1, std::to_string(j));
        }

        WinMeter e;
        e.line = i;
        e.meter = meter;
        e.meter2 = g_GrafficObjList.Str2GOCID(meterStr);
        e.symbol = firstSymbol;
        e.weight = j;
        e.start = 0;
        e.bonus = m_Bonus[BetStep()][firstSymbol][j];
        e.sound = MAX_SOUND_IDS;

        totalBonus.coin += e.bonus.coin;
        totalBonus.ag += e.bonus.ag;

        if (e.meter2 != -1) {
            meters.push_back(e);
        }
        if (j == m_nMaxMatch) {
            maxMeter |= meter;
        }
        else {
            normalMeter |= meter;
        }
        if (bTest == FALSE) {
            m_bPrevSpinMatchedActive = TRUE;
        }
    }
    if (bTest == FALSE) {
        m_vWinResult = result;
        updateCheckPoint();
        if (totalBonus.coin > 0 || totalBonus.ag > 0) {
            BonusSound = getSoundByID(WinSound(totalBonus.coin + totalBonus.ag * 1000));
        }
        else {
            BonusSound.duration = 0;
            BonusSound.soundID = MAX_SOUND_IDS;
        }
    }
    return result;
}

myVector<UINT8> RgFruitinator::ShowTotalWinLines(myVector<WinMeter> SpinMeters) {
    myVector<uint8_t> packet = {
        0x06, 0x30, 0x59, 0x01, 0x02, 0x31, 0x00,
        0x0F, 0x00,  // Placeholder for length 
        0x0F, 0x11, // GameID
        0x9C, 0x19, 0x01
    };
    myVector<UINT8> TotalMatch;
    for (int i = 0; i < SpinMeters.size(); i++) {
        TotalMatch.push_back(AT(SpinMeters, i).line);
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter >> 8) & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter2 & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter2 >> 8) & 0xFF));
    }
    if (TotalMatch.size() < 10) {
        myVector<UINT8> _;
        return _;
    }
    UINT16 pktLen = 1 + (TotalMatch.size() / 5) * 7;
    AT(packet, 7) = static_cast<BYTE>(pktLen & 0xFF);
    AT(packet, 8) = static_cast<BYTE>((pktLen >> 8) & 0xFF);
    AT(packet, 9) = static_cast<BYTE>(m_nGameID & 0xFF);
    AT(packet, 10) = static_cast<BYTE>((m_nGameID >> 8) & 0xFF);
    int entryCount = static_cast<int>(TotalMatch.size() / 5);
    for (int i = 0; i < entryCount; ++i) {
        packet.push_back(AT(TotalMatch, i * 5 + 0)); // Line
        packet.push_back(AT(TotalMatch, i * 5 + 1)); // Meter low byte
        packet.push_back(AT(TotalMatch, i * 5 + 2)); // Meter high byte
        packet.push_back(AT(TotalMatch, i * 5 + 3)); // Meter2 low byte
        packet.push_back(AT(TotalMatch, i * 5 + 4)); // Meter2 high byte
        packet.push_back(0x01);      // Status or flag 1
        packet.push_back(0x01);      // Status or flag 2
    }
    // Mark the end of the packet
    packet.back() = 0x04;
    return packet;
}
