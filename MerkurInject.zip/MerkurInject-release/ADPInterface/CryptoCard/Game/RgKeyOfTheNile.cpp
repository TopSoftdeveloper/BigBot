#include "stdafx.h"
#include "RgKeyOfTheNile.h"

#define RgKeyOfTheNile_wild     "KOTN_WI1"
#define RgKeyOfTheNile_scatter  "KOTN_SC1"


// please avoid freemode when there is expanded wild card;
RgKeyOfTheNile::RgKeyOfTheNile() {
    m_nReel = 5;
    m_nWinLine = 10;
    m_nMaxMatch = 5;
    m_nBetStep = 0;

    m_nForceWildInFreeModeGone = FALSE;

    m_strGameName = "RgKeyOfTheNile";

    m_nWildReel = -1;
    m_nWildRow = -1;

    m_bFreeMode = FALSE;

    m_vecAdditionalParam.push_back(0);
    m_vecAdditionalParam.push_back(0);
    
    m_vecBetSteps_tmp.push_back(10);
    m_vecBetSteps_tmp.push_back(20);
    m_vecBetSteps_tmp.push_back(30);
    m_vecBetSteps_tmp.push_back(40);
    m_vecBetSteps_tmp.push_back(50);
    m_vecBetSteps_tmp.push_back(60);
    m_vecBetSteps_tmp.push_back(80);
    m_vecBetSteps_tmp.push_back(100);
    m_vecBetSteps_tmp.push_back(150);
    m_vecBetSteps_tmp.push_back(200);
#ifdef BIGBET_ACTIVE
    m_vecBetSteps_tmp.push_back(500);
    m_vecBetSteps_tmp.push_back(1000);
#endif
    LoadBets();

    for (int i = 0; i < m_vecBetSteps.size(); i++) {
        m_vWildCounterAll.push_back(myVector<WilCounter>(5, { 0, FALSE }));
    }
    m_vWildCounter = AT(m_vWildCounterAll, 0);

    m_vecSymbols.push_back("KOTN_LV5");
    m_vecSymbols.push_back("KOTN_LV4");
    m_vecSymbols.push_back("KOTN_LV3");
    m_vecSymbols.push_back("KOTN_LV2");
    m_vecSymbols.push_back("KOTN_LV1");
    m_vecSymbols.push_back("KOTN_HV5");
    m_vecSymbols.push_back("KOTN_HV4");
    m_vecSymbols.push_back("KOTN_HV3");
    m_vecSymbols.push_back("KOTN_HV2");
    m_vecSymbols.push_back("KOTN_HV1");
    m_vecSymbols.push_back("KOTN_WI1");
    m_vecSymbols.push_back("KOTN_SC1");
    
    m_mapSymbolMinMatch["KOTN_LV5"] = 3;
    m_mapSymbolMinMatch["KOTN_LV4"] = 3;
    m_mapSymbolMinMatch["KOTN_LV3"] = 3;
    m_mapSymbolMinMatch["KOTN_LV2"] = 3;
    m_mapSymbolMinMatch["KOTN_LV1"] = 3;
    m_mapSymbolMinMatch["KOTN_HV5"] = 3;
    m_mapSymbolMinMatch["KOTN_HV4"] = 3;
    m_mapSymbolMinMatch["KOTN_HV3"] = 3;
    m_mapSymbolMinMatch["KOTN_HV2"] = 3;
    m_mapSymbolMinMatch["KOTN_HV1"] = 2;

    m_mapSymbolMeterGoc["KOTN_LV5"] = "LV15KOTN$x";
    m_mapSymbolMeterGoc["KOTN_LV4"] = "LV15KOTN$x";
    m_mapSymbolMeterGoc["KOTN_LV3"] = "LV15KOTN$x";
    m_mapSymbolMeterGoc["KOTN_LV2"] = "LV15KOTN$x";
    m_mapSymbolMeterGoc["KOTN_LV1"] = "LV15KOTN$x";
    m_mapSymbolMeterGoc["KOTN_HV5"] = "HV45KOTN$x";
    m_mapSymbolMeterGoc["KOTN_HV4"] = "HV45KOTN$x";
    m_mapSymbolMeterGoc["KOTN_HV3"] = "HV3_KOTN$x";
    m_mapSymbolMeterGoc["KOTN_HV2"] = "HV2_KOTN$x";
    m_mapSymbolMeterGoc["KOTN_HV1"] = "HV1_KOTN$x";

    m_vecWinLines.push_back("WinL01KOTN");
    m_vecWinLines.push_back("WinL02KOTN");
    m_vecWinLines.push_back("WinL03KOTN");
    m_vecWinLines.push_back("WinL04KOTN");
    m_vecWinLines.push_back("WinL05KOTN");
    m_vecWinLines.push_back("WinL06KOTN");
    m_vecWinLines.push_back("WinL07KOTN");
    m_vecWinLines.push_back("WinL08KOTN");
    m_vecWinLines.push_back("WinL09KOTN");
    m_vecWinLines.push_back("WinL10KOTN");
    m_vecWinLines.push_back("WinLScKOTN");

    m_vecLineSounds.push_back(SMP_KOTN_MW_SOUND_01);
    m_vecLineSounds.push_back(SMP_KOTN_MW_SOUND_02);
    m_vecLineSounds.push_back(SMP_KOTN_MW_SOUND_03);
    m_vecLineSounds.push_back(SMP_KOTN_MW_SOUND_04);
    m_vecLineSounds.push_back(SMP_KOTN_MW_SOUND_05);
    m_vecLineSounds.push_back(SMP_KOTN_MW_SOUND_06);
    m_vecLineSounds.push_back(SMP_KOTN_MW_SOUND_07);
    m_vecLineSounds.push_back(SMP_KOTN_MW_SOUND_08);
    m_vecLineSounds.push_back(SMP_KOTN_MW_SOUND_09);
    m_vecLineSounds.push_back(SMP_KOTN_MW_SOUND_10);

    //m_vecWinSounds.push_back(SMP_KOTN_W_SOUND_1);
    m_vecWinSounds.push_back(SMP_KOTN_W_SOUND_2);
    m_vecWinSounds.push_back(SMP_KOTN_W_SOUND_3);
    m_vecWinSounds.push_back(SMP_KOTN_W_SOUND_4);
    m_vecWinSounds.push_back(SMP_KOTN_W_SOUND_5);
    m_vecWinSounds.push_back(SMP_KOTN_W_SOUND_5_6);
    m_vecWinSounds.push_back(SMP_KOTN_W_SOUND_6);
    m_vecWinSounds.push_back(SMP_KOTN_W_SOUND_6_7);
    m_vecWinSounds.push_back(SMP_KOTN_W_SOUND_7);
           
    m_vecReelStripPlan.push_back("kotnWalze1");
    
    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));
    char* kotnReelStrip[] = {
        "KOTN_LV5,KOTN_LV1,KOTN_LV1,KOTN_LV1,KOTN_LV1,KOTN_LV1,KOTN_LV1,KOTN_LV1,KOTN_LV4,KOTN_HV1,KOTN_LV2,KOTN_LV3,KOTN_HV5,KOTN_LV4,KOTN_LV5,KOTN_HV3,KOTN_LV1,KOTN_LV3,KOTN_HV4,KOTN_LV4,KOTN_LV1,KOTN_HV2,KOTN_LV2,KOTN_LV3,KOTN_LV4,KOTN_HV5,KOTN_LV3,KOTN_LV5,KOTN_LV4,KOTN_SC1,KOTN_LV2,KOTN_LV3,KOTN_LV1,KOTN_LV2,KOTN_HV3,KOTN_LV5,KOTN_LV3,KOTN_LV4,KOTN_LV2,KOTN_HV5,KOTN_LV1,KOTN_LV2,KOTN_LV3,KOTN_HV1,KOTN_LV5,KOTN_LV4,KOTN_HV5,KOTN_LV3,KOTN_LV2,KOTN_LV5,KOTN_HV4,KOTN_LV4,KOTN_LV2,KOTN_SC1,KOTN_LV4,KOTN_LV3,KOTN_LV5,KOTN_HV5,KOTN_LV4,KOTN_LV2,KOTN_LV3,KOTN_HV2,KOTN_LV5,KOTN_LV3,KOTN_LV4,KOTN_HV4,KOTN_LV1,KOTN_LV2,KOTN_LV3,KOTN_LV5,KOTN_LV2,KOTN_SC1,KOTN_LV3,KOTN_LV2,KOTN_LV4,KOTN_HV4,KOTN_LV5,KOTN_LV2",
        "KOTN_LV4,KOTN_LV1,KOTN_LV1,KOTN_LV1,KOTN_LV1,KOTN_LV1,KOTN_LV1,KOTN_LV1,KOTN_LV5,KOTN_LV4,KOTN_LV1,KOTN_HV5,KOTN_LV1,KOTN_LV5,KOTN_LV2,KOTN_LV4,KOTN_LV1,KOTN_LV5,KOTN_HV1,KOTN_LV4,KOTN_LV5,KOTN_LV3,KOTN_SC1,KOTN_LV1,KOTN_LV3,KOTN_LV4,KOTN_HV4,KOTN_LV5,KOTN_LV4,KOTN_HV2,KOTN_LV5,KOTN_LV1,KOTN_LV3,KOTN_HV4,KOTN_LV4,KOTN_LV1,KOTN_HV5,KOTN_LV3,KOTN_LV5,KOTN_LV1,KOTN_LV4,KOTN_HV3,KOTN_LV1,KOTN_LV3,KOTN_HV5,KOTN_LV1,KOTN_LV4,KOTN_LV5,KOTN_SC1,KOTN_LV1,KOTN_LV3,KOTN_HV3,KOTN_LV4,KOTN_LV5,KOTN_HV5,KOTN_LV1,KOTN_LV3,KOTN_LV2,KOTN_HV2,KOTN_LV1,KOTN_LV3,KOTN_HV4,KOTN_LV4,KOTN_LV5,KOTN_LV2,KOTN_HV3,KOTN_LV1,KOTN_LV4,KOTN_LV5,KOTN_HV5,KOTN_LV1,KOTN_LV5,KOTN_LV4,KOTN_HV1,KOTN_LV4,KOTN_LV3,KOTN_LV5,KOTN_LV1,KOTN_LV4",
        "KOTN_LV3,KOTN_LV1,KOTN_LV1,KOTN_LV1,KOTN_LV1,KOTN_LV1,KOTN_LV1,KOTN_LV1,KOTN_LV4,KOTN_HV5,KOTN_LV3,KOTN_HV4,KOTN_LV4,KOTN_HV3,KOTN_LV2,KOTN_HV5,KOTN_LV1,KOTN_SC1,KOTN_LV5,KOTN_HV5,KOTN_LV5,KOTN_LV3,KOTN_HV4,KOTN_LV2,KOTN_HV2,KOTN_LV1,KOTN_HV5,KOTN_LV2,KOTN_HV1,KOTN_LV4,KOTN_HV4,KOTN_LV2,KOTN_HV2,KOTN_LV1,KOTN_HV5,KOTN_LV5,KOTN_SC1,KOTN_LV1,KOTN_HV4,KOTN_LV5,KOTN_HV3,KOTN_LV3,KOTN_HV5,KOTN_LV1,KOTN_HV4,KOTN_LV4,KOTN_HV5,KOTN_LV3,KOTN_HV1,KOTN_LV2,KOTN_HV5,KOTN_LV2,KOTN_HV2,KOTN_LV2,KOTN_HV4,KOTN_LV5,KOTN_HV5,KOTN_LV3,KOTN_HV3,KOTN_LV3,KOTN_HV5,KOTN_LV2,KOTN_HV2,KOTN_LV2,KOTN_HV5,KOTN_LV4,KOTN_HV4,KOTN_LV2,KOTN_HV2,KOTN_LV1,KOTN_HV5,KOTN_LV5,KOTN_SC1,KOTN_LV2,KOTN_HV4,KOTN_LV1,KOTN_HV3,KOTN_LV3,KOTN_HV5",
        "KOTN_LV3,KOTN_LV1,KOTN_LV1,KOTN_LV1,KOTN_LV1,KOTN_LV1,KOTN_LV1,KOTN_LV1,KOTN_LV1,KOTN_LV5,KOTN_LV4,KOTN_HV2,KOTN_LV3,KOTN_LV1,KOTN_HV1,KOTN_LV4,KOTN_LV5,KOTN_LV3,KOTN_HV4,KOTN_LV1,KOTN_HV3,KOTN_LV4,KOTN_LV2,KOTN_HV2,KOTN_LV1,KOTN_LV5,KOTN_LV4,KOTN_SC1,KOTN_LV5,KOTN_LV4,KOTN_HV5,KOTN_LV1,KOTN_LV4,KOTN_HV4,KOTN_LV3,KOTN_LV4,KOTN_HV5,KOTN_LV2,KOTN_LV1,KOTN_LV5,KOTN_HV3,KOTN_LV2,KOTN_LV5,KOTN_HV4,KOTN_LV3,KOTN_LV5,KOTN_HV3,KOTN_LV2,KOTN_LV1,KOTN_HV1,KOTN_LV3,KOTN_LV5,KOTN_HV5,KOTN_LV4,KOTN_LV2,KOTN_HV2,KOTN_LV5,KOTN_LV3,KOTN_SC1,KOTN_LV5,KOTN_LV3,KOTN_LV4,KOTN_HV4,KOTN_LV2,KOTN_LV4,KOTN_HV3,KOTN_LV5,KOTN_LV1,KOTN_LV2,KOTN_HV2,KOTN_LV5,KOTN_LV1,KOTN_LV3,KOTN_SC1,KOTN_LV5,KOTN_LV3,KOTN_LV4,KOTN_HV5,KOTN_LV5",
        "KOTN_LV3,KOTN_LV1,KOTN_LV1,KOTN_LV1,KOTN_LV1,KOTN_LV1,KOTN_LV1,KOTN_LV1,KOTN_LV1,KOTN_LV1,KOTN_LV2,KOTN_LV3,KOTN_HV2,KOTN_LV5,KOTN_HV4,KOTN_LV4,KOTN_HV2,KOTN_LV3,KOTN_LV5,KOTN_LV2,KOTN_HV5,KOTN_LV3,KOTN_HV4,KOTN_LV2,KOTN_HV2,KOTN_LV4,KOTN_SC1,KOTN_LV2,KOTN_LV3,KOTN_HV4,KOTN_LV3,KOTN_HV5,KOTN_LV3,KOTN_HV2,KOTN_LV1,KOTN_HV3,KOTN_LV1,KOTN_HV4,KOTN_LV2,KOTN_HV1,KOTN_LV4,KOTN_HV4,KOTN_LV4,KOTN_LV5,KOTN_LV1,KOTN_HV5,KOTN_LV3,KOTN_HV4,KOTN_LV2,KOTN_HV2,KOTN_LV1,KOTN_LV2,KOTN_HV5,KOTN_LV5,KOTN_SC1,KOTN_LV2,KOTN_HV4,KOTN_LV1,KOTN_HV2,KOTN_LV2,KOTN_HV3,KOTN_LV1,KOTN_HV4,KOTN_LV1,KOTN_LV2,KOTN_HV1,KOTN_LV3,KOTN_LV2",
    };

    int idx = 0;
    for (int i = 0; i < m_vecReelStripPlan.size(); i++) {
        ReelSet set;
        for (int j = 0; j < m_nReel; j++) {
            ReelStrip strip;
            std::stringstream ss(kotnReelStrip[idx]);
            std::string item;
            while (std::getline(ss, item, ',')) {
                strip.push_back(item);
            }
            set.push_back(strip);
            idx++;
        }
        m_vecReelStripSets.push_back(set);
    }

    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_tmp;

    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        std::map<std::string, std::map<UINT8, BONUS>> perSym;
        std::map<UINT8, BONUS> e;
        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[5].ag = 0;
        perSym["KOTN_LV5"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[5].ag = 0;
        perSym["KOTN_LV4"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[5].ag = 0;
        perSym["KOTN_LV3"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[5].ag = 0;
        perSym["KOTN_LV2"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[5].ag = 0;
        perSym["KOTN_LV1"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 200; e[5].ag = 0;
        perSym["KOTN_HV5"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 200; e[5].ag = 0;
        perSym["KOTN_HV4"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 75; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 300; e[5].ag = 0;
        perSym["KOTN_HV3"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 15; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 600; e[5].ag = 0;
        perSym["KOTN_HV2"] = e;
        e.clear();

        e[2].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5; e[2].ag = 0;
        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 25; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 200; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 1000; e[5].ag = 0;
        perSym["KOTN_HV1"] = e;
        e.clear();

        m_Bonus_tmp[i] = perSym;
    }
    m_Bonus_tmp[4]["KOTN_HV1"][5].coin = 0; m_Bonus_tmp[4]["KOTN_HV1"][5].ag = 5; // 50
    m_Bonus_tmp[5]["KOTN_HV1"][5].coin = 0; m_Bonus_tmp[5]["KOTN_HV1"][5].ag = 6; // 60
    m_Bonus_tmp[6]["KOTN_HV1"][5].coin = 0; m_Bonus_tmp[6]["KOTN_HV1"][5].ag = 8; // 80
    m_Bonus_tmp[7]["KOTN_HV1"][5].coin = 0; m_Bonus_tmp[7]["KOTN_HV1"][5].ag = 10; // 100
    m_Bonus_tmp[7]["KOTN_HV2"][5].coin = 0; m_Bonus_tmp[7]["KOTN_HV2"][5].ag = 6;
    m_Bonus_tmp[8]["KOTN_HV1"][5].coin = 0; m_Bonus_tmp[8]["KOTN_HV1"][5].ag = 15; // 150
    m_Bonus_tmp[8]["KOTN_HV2"][5].coin = 0; m_Bonus_tmp[8]["KOTN_HV2"][5].ag = 9;
    m_Bonus_tmp[9]["KOTN_HV1"][5].coin = 0; m_Bonus_tmp[9]["KOTN_HV1"][5].ag = 20; // 200
    m_Bonus_tmp[9]["KOTN_HV2"][5].coin = 0; m_Bonus_tmp[9]["KOTN_HV2"][5].ag = 12;
    m_Bonus_tmp[9]["KOTN_HV3"][5].coin = 0; m_Bonus_tmp[9]["KOTN_HV3"][5].ag = 6;
    m_Bonus_tmp[10]["KOTN_HV1"][5].coin = 0; m_Bonus_tmp[10]["KOTN_HV1"][5].ag = 50; // 500
    m_Bonus_tmp[10]["KOTN_HV1"][4].coin = 0; m_Bonus_tmp[10]["KOTN_HV1"][4].ag = 10; 
    m_Bonus_tmp[10]["KOTN_HV2"][5].coin = 0; m_Bonus_tmp[10]["KOTN_HV2"][5].ag = 30;
    m_Bonus_tmp[10]["KOTN_HV2"][4].coin = 0; m_Bonus_tmp[10]["KOTN_HV2"][4].ag = 5;
    m_Bonus_tmp[10]["KOTN_HV3"][5].coin = 0; m_Bonus_tmp[10]["KOTN_HV3"][5].ag = 15;
    m_Bonus_tmp[10]["KOTN_HV4"][5].coin = 0; m_Bonus_tmp[10]["KOTN_HV4"][5].ag = 10;
    m_Bonus_tmp[10]["KOTN_HV5"][5].coin = 0; m_Bonus_tmp[10]["KOTN_HV5"][5].ag = 10;
    m_Bonus_tmp[10]["KOTN_LV5"][5].coin = 0; m_Bonus_tmp[10]["KOTN_LV5"][5].ag = 5;
    m_Bonus_tmp[10]["KOTN_LV4"][5].coin = 0; m_Bonus_tmp[10]["KOTN_LV4"][5].ag = 5;
    m_Bonus_tmp[10]["KOTN_LV3"][5].coin = 0; m_Bonus_tmp[10]["KOTN_LV3"][5].ag = 5;
    m_Bonus_tmp[10]["KOTN_LV2"][5].coin = 0; m_Bonus_tmp[10]["KOTN_LV2"][5].ag = 5;
    m_Bonus_tmp[10]["KOTN_LV1"][5].coin = 0; m_Bonus_tmp[10]["KOTN_LV1"][5].ag = 5;
    m_Bonus_tmp[11]["KOTN_HV1"][5].coin = 0; m_Bonus_tmp[11]["KOTN_HV1"][5].ag = 100; // 1000
    m_Bonus_tmp[11]["KOTN_HV1"][4].coin = 0; m_Bonus_tmp[11]["KOTN_HV1"][4].ag = 20; 
    m_Bonus_tmp[11]["KOTN_HV2"][5].coin = 0; m_Bonus_tmp[11]["KOTN_HV2"][5].ag = 60;
    m_Bonus_tmp[11]["KOTN_HV2"][4].coin = 0; m_Bonus_tmp[11]["KOTN_HV2"][4].ag = 10;
    m_Bonus_tmp[11]["KOTN_HV3"][5].coin = 0; m_Bonus_tmp[11]["KOTN_HV3"][5].ag = 30;
    m_Bonus_tmp[11]["KOTN_HV3"][4].coin = 0; m_Bonus_tmp[11]["KOTN_HV3"][4].ag = 8;
    m_Bonus_tmp[11]["KOTN_HV4"][5].coin = 0; m_Bonus_tmp[11]["KOTN_HV4"][5].ag = 20;
    m_Bonus_tmp[11]["KOTN_HV5"][5].coin = 0; m_Bonus_tmp[11]["KOTN_HV5"][5].ag = 20;
    m_Bonus_tmp[11]["KOTN_HV4"][4].coin = 0; m_Bonus_tmp[11]["KOTN_HV4"][4].ag = 5;
    m_Bonus_tmp[11]["KOTN_HV5"][4].coin = 0; m_Bonus_tmp[11]["KOTN_HV5"][4].ag = 5;
    m_Bonus_tmp[11]["KOTN_LV5"][5].coin = 0; m_Bonus_tmp[11]["KOTN_LV5"][5].ag = 10;
    m_Bonus_tmp[11]["KOTN_LV4"][5].coin = 0; m_Bonus_tmp[11]["KOTN_LV4"][5].ag = 10;
    m_Bonus_tmp[11]["KOTN_LV3"][5].coin = 0; m_Bonus_tmp[11]["KOTN_LV3"][5].ag = 10;
    m_Bonus_tmp[11]["KOTN_LV2"][5].coin = 0; m_Bonus_tmp[11]["KOTN_LV2"][5].ag = 10;
    m_Bonus_tmp[11]["KOTN_LV1"][5].coin = 0; m_Bonus_tmp[11]["KOTN_LV1"][5].ag = 10;


    int nSavedBetVal = 10;
    int _line = 0;
    string data;
    PlayDB::GetInstance().LoadCheckPoint(m_strGameName, nSavedBetVal, _line, m_strCheckPoint);
    if (nSavedBetVal == -1) {
        nSavedBetVal = 10;
    }
    {
        myVector<int> vals = ParseCheckPoint(m_strCheckPoint, "L", m_vecBetSteps_tmp.size() * 11);
        if (vals.size() == m_vecBetSteps_tmp.size() * 11) {
            typedef struct _Save {
                int bet;
                WilCounter counts[5];
            };
            myVector<_Save> leds;
            for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
                _Save e;
                e.bet = AT(vals, 11 * i);
                e.counts[0].count = static_cast<UINT8>(AT(vals, 11 * i + 1));
                e.counts[0].fixed = static_cast<BOOL>(AT(vals, 11 * i + 2));
                e.counts[1].count = static_cast<UINT8>(AT(vals, 11 * i + 3));
                e.counts[1].fixed = static_cast<BOOL>(AT(vals, 11 * i + 4));
                e.counts[2].count = static_cast<UINT8>(AT(vals, 11 * i + 5));
                e.counts[2].fixed = static_cast<BOOL>(AT(vals, 11 * i + 6));
                e.counts[3].count = static_cast<UINT8>(AT(vals, 11 * i + 7));
                e.counts[3].fixed = static_cast<BOOL>(AT(vals, 11 * i + 8));
                e.counts[4].count = static_cast<UINT8>(AT(vals, 11 * i + 9));
                e.counts[4].fixed = static_cast<BOOL>(AT(vals, 11 * i + 10));
                leds.push_back(e);
            }

            for (int i = 0; i < m_vWildCounterAll.size(); i++) {
                int j = 0;
                for (; j < leds.size(); j++) {
                    if (AT(m_vecBetSteps, i) == AT(leds, j).bet) {
                        break;
                    }
                }
                if (j == leds.size()) {
                    continue;
                }
                for (int reel = 0; reel < 5; reel++) {
                    AT(AT(m_vWildCounterAll, i), reel).count = AT(leds, j).counts[reel].count;
                    AT(AT(m_vWildCounterAll, i), reel).fixed = AT(leds, j).counts[reel].fixed;
                }
            }
        }
    }

    BOOL start = FALSE;
    idx = 0;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_tmp, i) < AT(m_vecBetSteps, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps, idx) == nSavedBetVal) {
            m_nBetStep = idx;
        }

        m_Bonus[idx++] = m_Bonus_tmp[i];
        if (AT(m_vecBetSteps_tmp, i) == AT(m_vecBetSteps, m_vecBetSteps.size() - 1)) {
            break;
        }
    }
    m_vWildCounter = AT(m_vWildCounterAll, m_nBetStep);

    m_vecBetSteps_05.clear();
    m_vecBetSteps_10.clear();
    PrintAllBonus();
}

UINT16 RgKeyOfTheNile::Run() {
    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = 0;
    return m_shCurrentReelStrip;
}

void RgKeyOfTheNile::ChangeReelStrip(UINT16 NewReelPlan) {
    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = 0;
}

myVector<UINT8> RgKeyOfTheNile::Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) {
    m_nMagicCount = 0;

    myVector<UINT8> result;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    if (bTest) {
        std::string matchSymbol = AT(m_vecSymbols, myRandom() % (m_vecSymbols.size() - 2));
        int line = (myRandom() % m_nWinLine);
        int weight = 1 + (myRandom() % 5);

        BOOL bForceFree = (myRandom() % 10 == 0);
        for (int i = 0; i < m_nReel; i++) {
            ReelStrip reelStrip = AT(reelSet, i);
            int len = (reelStrip.size() - 3);

            int valid_i[0x100];
            int valid_count = 0;
            myVector<int> freeSymbols;
            for (int j = 11; j <= len; j++) { // avoid KOTN_IN1 in reelstrip
                if (weight > i) {
                    if (matchSymbol == AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                else {
                    if (matchSymbol != AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                if (AT(reelStrip, j) == RgKeyOfTheNile_scatter && m_bFreeMode == FALSE) {
                    freeSymbols.push_back(j);
                }
            }
            if (valid_count > 0) {
                int rand_index = myRandom() % valid_count;
                int chosen_i = valid_i[rand_index];
                result.push_back(chosen_i + 1);
            }
            else {
                result.push_back((11 + myRandom() % (len - 13)) + 1);
            }
            {
                int pool[5] = { 0, 1, 2, 3, 4 };
                auto v = pickRandom2or3(pool, 5, 3);
                if (bForceFree && m_bFreeMode == FALSE && freeSymbols.size() > 0 && std::find(v.begin(), v.end(), i) != v.end()) {
                    AT(result, result.size() - 1) =
                        AT(freeSymbols, myRandom() % freeSymbols.size()) - (myRandom() % 3) + 1;
                }
            }
        }
    }
    else {
        result = _result;

        BOOL mmcode = mmcode_get_active_status();
        if (mmcode) {
            mmcode_set_deactive();
            if (m_bFreeMode == FALSE) {
                for (int j = 0; j < 5; j ++) {
                    myVector<int> candidateIndices;
                    for (int i = 2; i < AT(reelSet, j).size() - 3; ++i) {
                        if (j%2 == 0 && AT(AT(reelSet, j), i) == RgKeyOfTheNile_scatter) {
                            int offset = myRandom() % 3;
                            int selectedIndex = i - 2 + offset;
                            candidateIndices.push_back(selectedIndex);
                        }
                        if (j%2 == 1 && AT(AT(reelSet, j), i) != RgKeyOfTheNile_scatter
                                    && AT(AT(reelSet, j), i-2) != RgKeyOfTheNile_scatter
                                    && AT(AT(reelSet, j), i-1) != RgKeyOfTheNile_scatter
                                    && AT(AT(reelSet, j), i+1) != RgKeyOfTheNile_scatter
                                    && AT(AT(reelSet, j), i+2) != RgKeyOfTheNile_scatter) {
                            int offset = myRandom() % 3;
                            int selectedIndex = i - 2 + offset;
                            candidateIndices.push_back(selectedIndex);
                        }
                    }
                    if (!candidateIndices.empty()) {
#ifdef BIGBET_ACTIVE
                        int chosenIndex = AT(candidateIndices, (candidateIndices.size()<3?myRandom() % candidateIndices.size():myRandom() % 3));
#else
                        int chosenIndex = AT(candidateIndices, myRandom() % candidateIndices.size());
#endif
                        AT(result, j) = chosenIndex + 1;
                    }
                }
            }
        }        
    }
    for (int reel = 0; reel < 5; reel++) {
        if (AT(m_vWildCounter, reel).fixed) {
            AT(result, reel) = 0xFF;
        }
    }
    
    m_vWinResult = result;
    if (bTest == FALSE) {
        SetWildPosAndMask();
    }
    
    normalMeter = 0;
    maxMeter = 0;
    BONUS totalBonus = {0, 0};
    for (int i = 0; i < m_nWinLine; i++) {
        int j = 1;
        std::string firstSymbol;
        if (IsWild(0, g_match_lines_10_5[i][0])) { // Wild
            firstSymbol = RgKeyOfTheNile_wild;
        }
        else {
            firstSymbol  = AT(AT(reelSet, 0), AT(result, 0) - 1 + g_match_lines_10_5[i][0]);
        }
        UINT16 meter = ((UINT16)1 << (2 - g_match_lines_10_5[i][0]));
        for (; j < m_nMaxMatch; j++) {
            std::string prev_symbol;
            std::string cur_symbol;
            if (IsWild(j - 1, g_match_lines_10_5[i][j - 1])) {
                prev_symbol = RgKeyOfTheNile_wild;
            }
            else {
                prev_symbol = AT(AT(reelSet, j - 1), AT(result, j - 1) - 1 + g_match_lines_10_5[i][j - 1]);
            }
            if (IsWild(j, g_match_lines_10_5[i][j])) {
                cur_symbol = RgKeyOfTheNile_wild;
            }
            else {
                cur_symbol = AT(AT(reelSet, j), AT(result, j) - 1 + g_match_lines_10_5[i][j]);
            }

            if (firstSymbol == RgKeyOfTheNile_wild) {
                firstSymbol = cur_symbol;
            }
            if (firstSymbol == cur_symbol || cur_symbol == RgKeyOfTheNile_wild) {
                meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
                continue;
            }
            break;
        }
        
        if (j < m_mapSymbolMinMatch[firstSymbol] || m_mapSymbolMinMatch[firstSymbol] == 0 || firstSymbol == RgKeyOfTheNile_scatter) {
            continue;
        }

        // monitor 2 meter
        std::string meterStr = m_mapSymbolMeterGoc[firstSymbol];
        size_t pos = meterStr.find('$');
        if (pos != std::string::npos) {
            meterStr = meterStr.replace(pos, 1, std::to_string(j));
        }

        WinMeter e;
        e.line = i;
        e.meter = meter;
        e.meter2 = g_GrafficObjList.Str2GOCID(meterStr);
        e.symbol = firstSymbol;
        e.weight = j;
        e.start = 0;
        e.bonus.coin = m_Bonus[BetStep()][firstSymbol][j].coin * (m_bFreeMode ? 2 : 1);
        e.bonus.ag = m_Bonus[BetStep()][firstSymbol][j].ag * (m_bFreeMode ? 2 : 1);
        e.sound = MAX_SOUND_IDS;

        totalBonus.coin += e.bonus.coin;
        totalBonus.ag += e.bonus.ag;

        meters.push_back(e);
        if (j == m_nMaxMatch) {
            maxMeter |= meter;
        }
        else {
            normalMeter |= meter;
        }
    }

    int nScatter = CardCount(RgKeyOfTheNile_scatter);
    if (nScatter >= 3) {
        bCanFreeMode = TRUE;

        UINT16 meter = 0;
        for (int i = 0; i < 3; i++) {
            for (int col = 0; col < m_nReel; col++) {
                if (AT(m_vWildCounter, col).fixed) {
                    continue;
                }
                std::string cur_symbol = AT(AT(reelSet, col), AT(result, col) - 1 + i);
                if (cur_symbol == RgKeyOfTheNile_scatter) {
                    meter |= ((UINT16)1 << (3 * col + (2 - i)));
                }
            }
        }
        WinMeter e;
        e.line = 10;
        e.meter = meter;
        e.meter2 = 0;
        e.symbol = RgKeyOfTheNile_scatter;
        e.weight = nScatter;
        e.start = 0;
        e.bonus = {0, 0};
        e.sound = MAX_SOUND_IDS;

        normalMeter |= meter;
        meters.push_back(e);
    }

    m_nMagicCount = totalBonus.ag;
    if (bTest == FALSE) {
        updateCheckPoint();

        if (totalBonus.coin > 0 || totalBonus.ag > 0) {
            if (m_bFreeMode) {
                m_nFreeModeTotalBonus.coin += totalBonus.coin;
                m_nFreeModeTotalBonus.ag += totalBonus.ag;
            }
            BonusSound = getSoundByID(WinSound(totalBonus.coin + totalBonus.ag * 1000));
        }
        else {
            BonusSound.duration = 0;
            BonusSound.soundID = MAX_SOUND_IDS;
        }
    }
    return result;
}

int RgKeyOfTheNile::LineSwapDelay(int WinIdx) {
    return 500;
}
UINT16 RgKeyOfTheNile::SpinTime_MS() {
    const int scatterCount = CardCount(RgKeyOfTheNile_scatter);
    if (scatterCount >= 3) {
        return 5200;
    }
    if (scatterCount == 2) {
        const bool inCol0 = ScatterInCol(0);
        const bool inCol1 = ScatterInCol(1);
        const bool inCol2 = ScatterInCol(2);
        const bool inCol3 = ScatterInCol(3);
        if (inCol0 && inCol1) {
            return 5100;
        }
        if ((inCol0 && inCol2) || (inCol1 && inCol2)) {
            return 4300;
        }
        if ((inCol0 && inCol3) || (inCol1 && inCol3) || (inCol2 && inCol3)) {
            return 3000;
        }
    }
    return 2000;
}

UINT8 RgKeyOfTheNile::CardCount(std::string card) {
    int n = 0;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int col = 0; col < m_nReel; col++) {
        if (AT(m_vWinResult, col) == 0xFF) { // expanded wild
            continue;
        }
        int k = 0;
        for (; k < 3; k++) {
            std::string s = AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k);
            if (s == card) {
                n++;
            }
        }
    }
    return n;
}

BOOL RgKeyOfTheNile::ScatterInCol(int col) {
    return CardNumInCol(col, RgKeyOfTheNile_scatter);
}

UINT8 RgKeyOfTheNile::CardNumInCol(int col, std::string card) {
    int n = 0;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int k = 0; k < 3; k++) {
        if (AT(m_vWinResult, col) == 0xFF) { // expanded wild
            continue;
        }
        std::string s = AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k);
        if (s == card) {
            n++;
        }
    }
    return n;
}

myVector<InterruptPacketData> RgKeyOfTheNile::InterruptAfterSpin() {
    BOOL more_delay = FALSE;
    BOOL counterChanged = FALSE;

    UINT16 wildMask = GetWildMask();
    for (int reel = 0; reel < 5; reel++) {
        if (AT(m_vWildCounter, reel).fixed) {
            if (AT(m_vWildCounter, reel).count > 0) {
                AT(m_vWildCounter, reel).count--;
            }
            if (AT(m_vWildCounter, reel).count == 0) {
                AT(m_vWildCounter, reel).fixed = FALSE;
            }
            continue;
        }
        if (reel == m_nWildReel && AT(m_vWildCounter, reel).fixed == FALSE) {
            AT(m_vWildCounter, reel).count++;
            counterChanged = TRUE;
            if (AT(m_vWildCounter, reel).count >= 4) {
                AT(m_vWildCounter, reel).fixed = TRUE;
                more_delay = TRUE;
            }
        }
    }
    
    UINT delay = (more_delay ? 4800 : (counterChanged ? 2200 : 0));
    myVector<InterruptPacketData> packets;
    packets.push_back({
        0,
        delay,
        {0x06, 0xbb, 0x05, 0x01, 0x02, 0x31, 0x00, 0x08, 0x00, 0xbb, 0x05, 0xce, 
        AT(m_vWildCounter, 0).count, AT(m_vWildCounter, 1).count, AT(m_vWildCounter, 2).count, AT(m_vWildCounter, 3).count, AT(m_vWildCounter, 4).count,
        static_cast<BYTE>((wildMask & 0xFF)), static_cast<BYTE>((wildMask >> 8)), 0x00, 0x04} });
    updateCheckPoint();
    return packets;
}

myVector<InterruptPacketData> RgKeyOfTheNile::InterruptBeforeSpin() {
    UINT16 wildMask = GetWildMask();

    myVector<WilCounter> cp;
    for (int i = 0; i < 5; i++) {
        if (AT(m_vWildCounter, i).fixed && 0) {
            cp.push_back(AT(m_vWildCounter, i));
            if (AT(cp, i).count > 1) {
                AT(cp, i).count--;
            }
        }
        else {
            cp.push_back(AT(m_vWildCounter, i));
        }
    }
    
    myVector<InterruptPacketData> packets;    
    packets.push_back({
       0,
       0,
       {0x06, 0xbb, 0x05, 0x01, 0x02, 0x31, 0x00, 0x08, 0x00, 0xbb, 0x05, 0xce,
       AT(cp, 0).count, AT(cp, 1).count, AT(cp, 2).count, AT(cp, 3).count, AT(cp, 4).count,
       static_cast<BYTE>((wildMask & 0xFF)), static_cast<BYTE>((wildMask >> 8)), 0x00, 0x04} });

    if (m_bFreeMode) {
        m_nFreeModeGoneSpin++;
        updateCheckPoint();

        UINT8 gone = (m_nFreeModeGoneSpin ? m_nFreeModeGoneSpin : 1);
        // display total & remain free spin count
        packets.push_back({
            0,
            0,
            {
                0x01, 0x02, 0x30, 0x00, 0xbb, 0x05, gone, 0x00, m_nFreeModeTotalSpin, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa5, 0x04
            }
            });
    }
    return packets;
}

myVector<UINT8> RgKeyOfTheNile::AdditionalParam() {
    return m_vecAdditionalParam;
}

BOOL RgKeyOfTheNile::IsWild(int reel, int row) {
    if (AT(m_vWildCounter, reel).fixed == TRUE) {
        return TRUE;
    }
    if (AT(m_vWildCounter, reel).count == 3 && m_nWildReel == reel) {
        return TRUE;
    }
    if (AT(m_vWinResult, reel) == 0xFF) { // expanded wild
        return TRUE;
    }
    if (reel == m_nWildReel && row == m_nWildRow) {
        return TRUE;
    }
    return FALSE;
}

void RgKeyOfTheNile::SetWildPosAndMask() {
    BOOL enable = ((myRandom() % 100) < 5);  

    if (m_bFreeMode == TRUE && m_nForceWildInFreeModeGone == m_nFreeModeGoneSpin) {
        enable = TRUE;
    }

    m_nWildReel = -1;
    m_nWildRow = -1;

    m_vecAdditionalParam.clear();
    m_vecAdditionalParam.push_back(0);
    m_vecAdditionalParam.push_back(0);

    myVector<int> unfixedReel;
    UINT16 wildMask = 0;
    for (int reel = 0; reel < 5; reel++) {
        if (AT(m_vWildCounter, reel).fixed) {
            for (int row = 0; row < 3; row++) {
                wildMask |= (1 << (reel * 3 + (2 - row)));
            }
        }
        else {
            if (ScatterInCol(reel) == FALSE) {
                unfixedReel.push_back(reel);
            }
        }
    }
    
    if (unfixedReel.size() == 0 || enable == 0 || wildMask != 0) {
        goto RET;
    }
    m_nWildReel = AT(unfixedReel, myRandom() % unfixedReel.size());

    m_nWildRow = (myRandom() % 3);
    wildMask |= (1 << (3 * m_nWildReel + (2 - m_nWildRow)));
RET:
    m_vecAdditionalParam.clear();
    m_vecAdditionalParam.push_back(static_cast<BYTE>(wildMask & 0xFF));
    m_vecAdditionalParam.push_back(static_cast<BYTE>(wildMask >> 8));
}

UINT16 RgKeyOfTheNile::GetWildMask() {
    UINT16 wildMask = 0;
    for (int reel = 0; reel < 5; reel++) {
        if (AT(m_vWildCounter, reel).fixed) {
            for (int row = 0; row < 3; row++) {
                wildMask |= (1 << (reel * 3 + (2 - row)));
            }
        }
    }
    if (m_nWildReel != -1 && m_nWildRow != -1) {
        wildMask |= (1 << (3 * m_nWildReel + (2 - m_nWildRow)));
    }
    return wildMask;
}

BOOL RgKeyOfTheNile::CanFreeMode() {
    if (CardCount(RgKeyOfTheNile_scatter) >= 3) {
        return TRUE;
    }
    return FALSE;
}

myVector<InterruptPacketData> RgKeyOfTheNile::EnterFreeGame(std::string check) {
    int n = 3;
    if (check == "") {
        n = CardCount(RgKeyOfTheNile_scatter);
    }
    m_bFreeMode = TRUE;
    m_nFreeModeTotalSpin = 10;
    switch (n)
    {
    case 4:
        m_nFreeModeTotalSpin = 15;
        break;
    case 5:
        m_nFreeModeTotalSpin = 20;
        break;
    default:
        break;
    }
    m_nForceWildInFreeModeGone = 2 + (myRandom() % 5);

    m_nFreeModeGoneSpin = 0;
    m_nFreeModeTotalBonus = {0, 0};

    // set all wild counter as 3
    //for (int i = 0; i < m_vWildCounter.size(); i++) { // disable all 
    //    AT(m_vWildCounter, i).fixed = FALSE;
    //}
    m_vCpOfWildCounter = m_vWildCounter;
    m_vWildCounter.clear();
    m_vWildCounter = myVector<WilCounter>(5, { 3, FALSE });

    myVector<InterruptPacketData> packets;
    if (check != "") {
        myVector<int> values = ParseCheckPoint(check, "F", 24);
        if (values.size() == 24) {
            m_nFreeModeTotalSpin = AT(values, 0);
            m_nFreeModeGoneSpin = AT(values, 1);
            m_nFreeModeTotalBonus.coin = AT(values, 2);
            m_nFreeModeTotalBonus.ag = AT(values, 3);
            AT(m_vWildCounter, 0).fixed = AT(values, 4);
            AT(m_vWildCounter, 0).count = AT(values, 5);
            AT(m_vWildCounter, 1).fixed = AT(values, 6);
            AT(m_vWildCounter, 1).count = AT(values, 7);
            AT(m_vWildCounter, 2).fixed = AT(values, 8);
            AT(m_vWildCounter, 2).count = AT(values, 9);
            AT(m_vWildCounter, 3).fixed = AT(values, 10);
            AT(m_vWildCounter, 3).count = AT(values, 11);
            AT(m_vWildCounter, 4).fixed = AT(values, 12);
            AT(m_vWildCounter, 4).count = AT(values, 13);

            AT(m_vCpOfWildCounter, 0).fixed = AT(values, 14);
            AT(m_vCpOfWildCounter, 0).count = AT(values, 15);
            AT(m_vCpOfWildCounter, 1).fixed = AT(values, 16);
            AT(m_vCpOfWildCounter, 1).count = AT(values, 17);
            AT(m_vCpOfWildCounter, 2).fixed = AT(values, 18);
            AT(m_vCpOfWildCounter, 2).count = AT(values, 19);
            AT(m_vCpOfWildCounter, 3).fixed = AT(values, 20);
            AT(m_vCpOfWildCounter, 3).count = AT(values, 21);
            AT(m_vCpOfWildCounter, 4).fixed = AT(values, 22);
            AT(m_vCpOfWildCounter, 4).count = AT(values, 23);
            UINT16 mask = 0;
            for (int reel = 0; reel < 5; reel++) {
                if (AT(m_vWildCounter, reel).fixed) {
                    mask |= (1 << (0 + reel * 3));
                    mask |= (1 << (1 + reel * 3));
                    mask |= (1 << (2 + reel * 3));
                }
            }
            UINT8 gone = (m_nFreeModeGoneSpin ? m_nFreeModeGoneSpin : 1);
            packets.push_back({ 0, 0, { 0x01, 0x02, 0x30, 0x00, 0xbb, 0x05, gone, 0x00, m_nFreeModeTotalSpin, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa3, 0x04 } });
            packets.push_back({ 0, 0, { 0x01, 0x02, 0x31, 0x00, 0x08, 0x00, 0xbb, 0x05, 0xce, AT(m_vWildCounter, 0).count, AT(m_vWildCounter, 1).count, AT(m_vWildCounter, 2).count, AT(m_vWildCounter, 3).count, AT(m_vWildCounter, 4).count, static_cast<BYTE>(mask & 0xFF), static_cast<BYTE>((mask >> 8) & 0xFF), 0x01, 0x04 } });
            return packets;
        }
    }
    else {
        updateCheckPoint();
    }
    // show freemode dialog
    packets.push_back({
        0, 4000,
        {0x01, 0x02, 0x30, 0x00, 0xbb, 0x05, 0x02, 0x00, m_nFreeModeTotalSpin, 0x00, 0x00, 0x00, 0x00, 0x00, 0xab, 0x04} });
    // hide dialog
    packets.push_back({
        0, 0,
        {0x01, 0x02, 0x30, 0x00, 0xbb, 0x05, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xac, 0x04} });
    // top freespin number
    packets.push_back({
        0, 0,
        {0x01, 0x02, 0x30, 0x00, 0xbb, 0x05, 0x01, 0x00, m_nFreeModeTotalSpin, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa3, 0x04} });
    packets.push_back({
        0, 300,
        {0x06, 0xbb, 0x05, 0x01, 0x02, 0x31, 0x00, 0x08, 0x00, 0xbb, 0x05, 0xce, 
        AT(m_vWildCounter, 0).count, AT(m_vWildCounter, 1).count, AT(m_vWildCounter, 2).count, AT(m_vWildCounter, 3).count, AT(m_vWildCounter, 4).count, 
        0x00, 0x00, 0x02, 0x04}});
    return packets;
}

UINT16 RgKeyOfTheNile::MagicCount() {
    if (m_bFreeMode) {
        return 0;
    }
    else {
        return m_nMagicCount;
    }
}

myVector<InterruptPacketData> RgKeyOfTheNile::InterruptAfterMoveBonus(BOOL& EndFree) {
    myVector<InterruptPacketData> packets;
    if (m_nFreeModeGoneSpin >= m_nFreeModeTotalSpin) {
        EndFree = TRUE;
        m_bFreeMode = FALSE;

        // show result
        packets.push_back({
             0,
             3000,
             {0x01, 0x02, 0x30, 0x00, 0xbb, 0x05, 0x00, 0x00,
             static_cast<BYTE>(m_nFreeModeTotalBonus.coin & 0xFF), 
             static_cast<BYTE>((m_nFreeModeTotalBonus.coin >> 8) & 0xFF),
             static_cast<BYTE>((m_nFreeModeTotalBonus.coin >> 16) & 0xFF),
             static_cast<BYTE>((m_nFreeModeTotalBonus.coin >> 24) & 0xFF),
             m_nFreeModeTotalSpin, 0x00, 0xab, 0x04} });

        // hide dialog
        packets.push_back({
             0,
             0,
             {0x06, 0x30, 0x59, 0x01, 0x02, 0x30, 0x00, 0xbb, 0x05, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xac, 0x04} });
        // return to main game
        packets.push_back({
             0,
             0,
             {0x01, 0x02, 0x30, 0x00, 0xbb, 0x05, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa4, 0x04} });
        
        // rollback wild counter
        m_vWildCounter = m_vCpOfWildCounter;
        UINT16 wildMask = GetWildMask();
        packets.push_back({
             0,
             0,
             {0x06, 0xbb, 0x05, 0x01, 0x02, 0x31, 0x00, 0x08, 0x00, 0xbb, 0x05, 0xce, 
             AT(m_vWildCounter, 0).count, AT(m_vWildCounter, 1).count, AT(m_vWildCounter, 2).count, AT(m_vWildCounter, 3).count, AT(m_vWildCounter, 4).count,
             static_cast<BYTE>((wildMask & 0xFF)), static_cast<BYTE>((wildMask >> 8)), 
             0x03, 0x04} });
        updateCheckPoint();

        return packets;
    }
    EndFree = FALSE;
    //m_nFreeModeGoneSpin++;
    updateCheckPoint();

    return packets;
}

myVector<InterruptPacketData> RgKeyOfTheNile::OnBetUp(int OrgBetStep, int NewBetStep) {
    myVector<InterruptPacketData> packets;

    AT(m_vWildCounterAll, OrgBetStep) = m_vWildCounter;
    m_vWildCounter = AT(m_vWildCounterAll, NewBetStep);

    UINT16 mask = 0;
    for (int reel = 0; reel < 5; reel++) {
        if (AT(m_vWildCounter, reel).fixed) {
            mask |= (1 << (0 + reel * 3));
            mask |= (1 << (1 + reel * 3));
            mask |= (1 << (2 + reel * 3));
        }
    }

    packets.push_back({0, 0, { 0x01, 0x02, 0x31, 0x00, 0x08, 0x00, 0xbb, 0x05, 0xce, AT(m_vWildCounter, 0).count, AT(m_vWildCounter, 1).count, AT(m_vWildCounter, 2).count, AT(m_vWildCounter, 3).count, AT(m_vWildCounter, 4).count, static_cast<BYTE>(mask & 0xFF), static_cast<BYTE>((mask >> 8) & 0xFF), 0x01, 0x04 }});

    /*packets.push_back({
        
        {0x06, 0xbb, 0x05, 0x01, 0x02, 0x31, 0x00, 0x08, 0x00, 0xbb, 0x05, 0xce,
        AT(m_vWildCounter, 0).count, AT(m_vWildCounter, 1).count, AT(m_vWildCounter, 2).count, AT(m_vWildCounter, 3).count, AT(m_vWildCounter, 4).count,
        0x00, 0x00, 0x02, 0x04} });*/

    return packets;
}

bool RgKeyOfTheNile::RTP_force_bigWin() {
    return (myRandom() % 80 == 0);
}


BOOL RgKeyOfTheNile::SelectedableReelsInFreeGame(myVector<UINT8> result) {
    if (m_bFreeMode == FALSE) {
        return TRUE;
    }
    myVector<UINT8> cp = m_vWinResult;
    m_vWinResult = result;
    int n = CardCount(RgKeyOfTheNile_scatter);
    m_vWinResult = cp;
    if (n >= 3) {
        return FALSE;
    }
    return TRUE;
}

void RgKeyOfTheNile::updateCheckPoint() {
    typedef struct _Save {
        int bet;
        WilCounter counts[5];
    };

    myVector<_Save> vals;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        _Save e;
        e.bet = AT(m_vecBetSteps_tmp, i);
        for (int reel = 0; reel < 5; reel++) {
            e.counts[reel].count = 0;
            e.counts[reel].fixed = FALSE;
        }

        int j = 0;
        for (; j < m_vWildCounterAll.size(); j++) {
            if (AT(m_vecBetSteps, j) == e.bet) {
                break;
            }
        }
        if (j == m_vWildCounterAll.size()) {
            vals.push_back(e);
            continue;
        }

        if (AT(m_vecBetSteps, m_nBetStep) == e.bet) {
            for (int reel = 0; reel < 5; reel++) {
                e.counts[reel].count = AT(m_vWildCounter, reel).count;
                e.counts[reel].fixed = AT(m_vWildCounter, reel).fixed;
            }
            vals.push_back(e);
            continue;
        }
        for (int reel = 0; reel < 5; reel++) {
            e.counts[reel].count = AT(AT(m_vWildCounterAll, j), reel).count;
            e.counts[reel].fixed = AT(AT(m_vWildCounterAll, j), reel).fixed;
        }
        vals.push_back(e);
    }

    std::ostringstream oss;
    oss << " P" << m_nCurrentReelPlan
        << " B"
        << static_cast<int>(AT(m_vWinResult, 0)) << ":"
        << static_cast<int>(AT(m_vWinResult, 1)) << ":"
        << static_cast<int>(AT(m_vWinResult, 2)) << ":"
        << static_cast<int>(AT(m_vWinResult, 3)) << ":"
        << static_cast<int>(AT(m_vWinResult, 4)) << " ";

    if (m_bFreeMode) {
        oss << " F"
            << static_cast<int>(m_nFreeModeTotalSpin) << ":"
            << static_cast<int>(m_nFreeModeGoneSpin) << ":"
            << static_cast<int>(m_nFreeModeTotalBonus.coin) << ":"
            << static_cast<int>(m_nFreeModeTotalBonus.ag) << ":"
            << static_cast<int>(AT(m_vWildCounter, 0).fixed) << ":"
            << static_cast<int>(AT(m_vWildCounter, 0).count) << ":"
            << static_cast<int>(AT(m_vWildCounter, 1).fixed) << ":"
            << static_cast<int>(AT(m_vWildCounter, 1).count) << ":"
            << static_cast<int>(AT(m_vWildCounter, 2).fixed) << ":"
            << static_cast<int>(AT(m_vWildCounter, 2).count) << ":"
            << static_cast<int>(AT(m_vWildCounter, 3).fixed) << ":"
            << static_cast<int>(AT(m_vWildCounter, 3).count) << ":"
            << static_cast<int>(AT(m_vWildCounter, 4).fixed) << ":"
            << static_cast<int>(AT(m_vWildCounter, 4).count) << ":"
            << static_cast<int>(AT(m_vCpOfWildCounter, 0).fixed) << ":"
            << static_cast<int>(AT(m_vCpOfWildCounter, 0).count) << ":"
            << static_cast<int>(AT(m_vCpOfWildCounter, 1).fixed) << ":"
            << static_cast<int>(AT(m_vCpOfWildCounter, 1).count) << ":"
            << static_cast<int>(AT(m_vCpOfWildCounter, 2).fixed) << ":"
            << static_cast<int>(AT(m_vCpOfWildCounter, 2).count) << ":"
            << static_cast<int>(AT(m_vCpOfWildCounter, 3).fixed) << ":"
            << static_cast<int>(AT(m_vCpOfWildCounter, 3).count) << ":"
            << static_cast<int>(AT(m_vCpOfWildCounter, 4).fixed) << ":"
            << static_cast<int>(AT(m_vCpOfWildCounter, 4).count) << " ";
    }

    oss << " L";
    for (int i = 0; i < vals.size(); i++) {
        oss << static_cast<int>(AT(vals, i).bet) << ":";
        for (int reel = 0; reel < 5; reel++) {
            oss << static_cast<int>(AT(vals, i).counts[reel].count) << ":";
            oss << static_cast<int>(AT(vals, i).counts[reel].fixed) << ":";
        }
    }
    m_strCheckPoint = oss.str();
    m_strCheckPoint[m_strCheckPoint.size() - 1] = ' ';

}