#pragma once

#include "ReelGame.h"


class RgPharosGold2 : public ReelGame
{
public:
	myVector<WinMeter> m_vWinMeters;
	std::string m_TransSymbol;

	RgPharosGold2::RgPharosGold2();

	UINT8 CardCount(std::string card);
	UINT16 Init(UINT8 betStep);
	myVector<UINT8> Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode, BOOL match);
	myVector<InterruptPacketData> InterruptAfterSpin() override;
	void ChangeReelStrip(UINT16 NewReelPlan) override;

	UINT16 GetTransSymbolGOC();
	BOOL ReelIsTransable(int reel, std::string card);
	BOOL CardInCol(int reel, std::string card);
};
