#pragma once

#include "ReelGame.h"

class RgRisingLiner : public ReelGame
{
public:
	UINT8 m_nWildPos;

	RgRisingLiner::RgRisingLiner();
	BOOL IsWild(int reel, int row);

	UINT16 Run() override;
	myVector<UINT8> Win(myVector<WinMeter>&meters, UINT64 & normalMeter, UINT64 & maxMeter, SoundItem & BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) override;
	UINT16 SpinTime_MS() override;
	int LineSwapDelay(int WinIdx) override;
	myVector<UINT8> AdditionalParam() override;
	myVector<InterruptPacketData> InterruptAfterSpin() override;

	bool RTP_force_bigWin() override;

	void ChangeReelStrip(UINT16 NewReelPlan) override;
};
