#include "stdafx.h"
#include "RgDoubleBook.h"

#define RgDoubleBook_MP_ChangeLine_LB_x_reel   0x03
#define RgDoubleBook_MP_ChangeLine_LB_x_pos    0x05
#define RgDoubleBook_MP_ChangeLine_LB_y_row    0x02
#define RgDoubleBook_MP_ChangeLine_LB_y_pos    0x1E
#define RgDoubleBook_MP_ChangeLine_RT_x_reel   0x03
#define RgDoubleBook_MP_ChangeLine_RT_x_pos    0x63
#define RgDoubleBook_MP_ChangeLine_RT_y_row    0x02
#define RgDoubleBook_MP_ChangeLine_RT_y_pos    0x4E

#define RgDoubleBook_book    "bookBOOK___"
RgDoubleBook::RgDoubleBook() {
    m_nMode = RgDoubleBook_MODE_single;

    m_nReel = 5;
    m_nWinLine = 5;
    m_nMaxMatch = 5;
    m_nBetStep = 0;

    m_strGameName = "RgDoppelBuch";

    m_bFreeMode = FALSE;

    myVector<UINT16> m_vecBetSteps_s_tmp;
    myVector<UINT16> m_vecBetSteps_d_tmp;

    m_vecBetSteps_s_tmp.push_back(5);
    m_vecBetSteps_s_tmp.push_back(10);
    m_vecBetSteps_s_tmp.push_back(20);
    m_vecBetSteps_s_tmp.push_back(30);
    m_vecBetSteps_s_tmp.push_back(40);
    m_vecBetSteps_s_tmp.push_back(50);
    m_vecBetSteps_s_tmp.push_back(60);
    m_vecBetSteps_s_tmp.push_back(80);
    m_vecBetSteps_s_tmp.push_back(100);

    m_vecBetSteps_d_tmp.push_back(10);
    m_vecBetSteps_d_tmp.push_back(20);
    m_vecBetSteps_d_tmp.push_back(40);
    m_vecBetSteps_d_tmp.push_back(60);
    m_vecBetSteps_d_tmp.push_back(80);
    m_vecBetSteps_d_tmp.push_back(100);
    m_vecBetSteps_d_tmp.push_back(120);
    m_vecBetSteps_d_tmp.push_back(160);
    m_vecBetSteps_d_tmp.push_back(200);

#ifdef BIGBET_ACTIVE
    m_vecBetSteps_s_tmp.push_back(200);
    m_vecBetSteps_s_tmp.push_back(500);
    m_vecBetSteps_d_tmp.push_back(400);
    m_vecBetSteps_d_tmp.push_back(1000);
#endif
    LoadBets();
    m_vecBetSteps_s = m_vecBetSteps_05;
    m_vecBetSteps_d = m_vecBetSteps_10;

    m_vecBetSteps = m_vecBetSteps_s;

    m_vecSymbols.push_back("bookMAN____");
    m_vecSymbols.push_back("bookTUT____");
    m_vecSymbols.push_back("bookSTATUE_");
    m_vecSymbols.push_back("bookSCARAB_");
    m_vecSymbols.push_back("bookA______");
    m_vecSymbols.push_back("bookK______");
    m_vecSymbols.push_back("bookQ______");
    m_vecSymbols.push_back("bookJ______");
    m_vecSymbols.push_back("bookTEN____");
    m_vecSymbols.push_back("bookBOOK___");

    m_mapSymbolMinMatch["bookMAN____"] = 2;
    m_mapSymbolMinMatch["bookTUT____"] = 2;
    m_mapSymbolMinMatch["bookSTATUE_"] = 2;
    m_mapSymbolMinMatch["bookSCARAB_"] = 2;
    m_mapSymbolMinMatch["bookA______"] = 3;
    m_mapSymbolMinMatch["bookK______"] = 3;
    m_mapSymbolMinMatch["bookQ______"] = 3;
    m_mapSymbolMinMatch["bookJ______"] = 3;
    m_mapSymbolMinMatch["bookTEN____"] = 3;
    m_mapSymbolMinMatch["bookBOOK___"] = 3;

    m_mapSymbolMeterGoc["bookMAN____"] = "bookMan$x";
    m_mapSymbolMeterGoc["bookTUT____"] = "bookTut$x";
    m_mapSymbolMeterGoc["bookSTATUE_"] = "bookStatue$x";
    m_mapSymbolMeterGoc["bookSCARAB_"] = "bookScarab$x";
    m_mapSymbolMeterGoc["bookA______"] = "bookA$x";
    m_mapSymbolMeterGoc["bookK______"] = "bookK$x";
    m_mapSymbolMeterGoc["bookQ______"] = "bookQ$x";
    m_mapSymbolMeterGoc["bookJ______"] = "bookJ$x";
    m_mapSymbolMeterGoc["bookTEN____"] = "bookT$x";
    m_mapSymbolMeterGoc["bookBOOK___"] = "bookBook$x";

    m_vecWinLines.push_back("bookWinline1");
    m_vecWinLines.push_back("bookWinline2");
    m_vecWinLines.push_back("bookWinline3");
    m_vecWinLines.push_back("bookWinline4");
    m_vecWinLines.push_back("bookWinline5");
    m_vecWinLines.push_back("bookWinlineScat");

    m_vecLineSounds.push_back(SMP_Book_WinStep1);
    m_vecLineSounds.push_back(SMP_Book_WinStep2);
    m_vecLineSounds.push_back(SMP_Book_WinStep3);
    m_vecLineSounds.push_back(SMP_Book_WinStep4);
    m_vecLineSounds.push_back(SMP_Book_WinStep5);
    m_vecLineSounds.push_back(SMP_Book_WinStep1);    

    m_vecWinSounds.push_back(SMP_Book_Win1);
    m_vecWinSounds.push_back(SMP_Book_Win2);
    m_vecWinSounds.push_back(SMP_Book_Win3);
    m_vecWinSounds.push_back(SMP_Book_Win4);
    m_vecWinSounds.push_back(SMP_Book_Win5);
    m_vecWinSounds.push_back(SMP_Book_Win6);
    m_vecWinSounds.push_back(SMP_Book_Win7);
    m_vecWinSounds.push_back(SMP_Book_Win8);
    m_vecWinSounds.push_back(SMP_Book_Win9);
    m_vecWinSounds.push_back(SMP_Book_Win10);

    m_vecReelStripPlan.push_back("0");
    m_vecReelStripPlan.push_back("1");
    m_vecReelStripPlan.push_back("2");
    m_vecReelStripPlan.push_back("3");
    m_vecReelStripPlan.push_back("4");

    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));

    char* bookReelStrip[] = {
        "bookQ______,bookA______,bookBOOK___,bookQ______,bookJ______,bookSCARAB_,bookQ______,bookA______,bookMAN____,bookQ______,bookK______,bookSCARAB_,bookA______,bookK______,bookSTATUE_,bookJ______,bookQ______,bookK______,bookA______,bookTUT____,bookK______,bookA______,bookSCARAB_,bookK______,bookTEN____,bookSCARAB_,bookJ______,bookQ______,bookA______,bookK______,bookSTATUE_,bookJ______,bookK______,bookSCARAB_,bookQ______,bookTEN____,bookA______,bookJ______,bookTUT____,bookK______,bookA______,bookSCARAB_,bookQ______,bookTEN____,bookMAN____,bookQ______,bookA______,bookK______,bookTEN____,bookJ______",
        "bookJ______,bookK______,bookBOOK___,bookJ______,bookTEN____,bookSTATUE_,bookJ______,bookK______,bookMAN____,bookJ______,bookA______,bookSTATUE_,bookK______,bookA______,bookSCARAB_,bookTEN____,bookJ______,bookA______,bookK______,bookTUT____,bookA______,bookK______,bookSTATUE_,bookA______,bookQ______,bookSTATUE_,bookTEN____,bookJ______,bookK______,bookA______,bookSCARAB_,bookTEN____,bookA______,bookSTATUE_,bookJ______,bookQ______,bookK______,bookTEN____,bookTUT____,bookA______,bookK______,bookSTATUE_,bookJ______,bookQ______,bookMAN____,bookJ______,bookK______,bookA______,bookQ______,bookTEN____",
        "bookJ______,bookMAN____,bookK______,bookJ______,bookTUT____,bookK______,bookA______,bookSCARAB_,bookTEN____,bookJ______,bookK______,bookA______,bookTUT____,bookQ______,bookTEN____,bookBOOK___,bookA______,bookJ______,bookTUT____,bookQ______,bookTEN____,bookSTATUE_,bookK______,bookJ______,bookTUT____,bookQ______,bookK______,bookJ______,bookSTATUE_,bookQ______,bookA______,bookSCARAB_,bookK______,bookA______,bookBOOK___,bookQ______,bookA______",
        "bookTEN____,bookK______,bookSCARAB_,bookA______,bookQ______,bookTUT____,bookA______,bookJ______,bookSTATUE_,bookA______,bookK______,bookTEN____,bookBOOK___,bookJ______,bookK______,bookQ______,bookSTATUE_,bookK______,bookA______,bookQ______,bookSCARAB_,bookA______,bookQ______,bookBOOK___,bookA______,bookQ______,bookTEN____,bookSCARAB_,bookK______,bookQ______,bookA______,bookMAN____,bookJ______,bookK______,bookQ______,bookA______,bookSCARAB_,bookK______,bookQ______,bookA______,bookSCARAB_,bookK______,bookJ______,bookMAN____,bookQ______,bookJ______,bookTUT____,bookTEN____,bookJ______,bookK______",
        "bookQ______,bookTEN____,bookBOOK___,bookJ______,bookA______,bookSCARAB_,bookTEN____,bookQ______,bookSCARAB_,bookJ______,bookA______,bookMAN____,bookQ______,bookK______,bookSTATUE_,bookA______,bookJ______,bookTEN____,bookQ______,bookTUT____,bookTEN____,bookK______,bookSTATUE_,bookQ______,bookK______,bookTUT____,bookJ______,bookA______,bookQ______,bookMAN____,bookTEN____,bookJ______,bookSTATUE_",

        "bookJ______,bookQ______,bookBOOK___,bookA______,bookJ______,bookK______,bookTUT____,bookTEN____,bookA______,bookJ______,bookSTATUE_,bookTEN____,bookK______,bookSTATUE_,bookTEN____,bookJ______,bookTUT____,bookQ______,bookK______,bookTEN____,bookA______,bookJ______,bookK______,bookTEN____,bookJ______,bookK______,bookTEN____,bookSTATUE_,bookJ______,bookK______,bookTEN____,bookMAN____,bookJ______,bookK______,bookQ______,bookSTATUE_,bookTEN____,bookJ______,bookA______,bookSCARAB_,bookJ______,bookK______,bookTEN____,bookQ______,bookK______",
        "bookTEN____,bookJ______,bookBOOK___,bookK______,bookTEN____,bookA______,bookTUT____,bookQ______,bookK______,bookTEN____,bookSCARAB_,bookQ______,bookA______,bookSCARAB_,bookQ______,bookTEN____,bookTUT____,bookJ______,bookA______,bookQ______,bookK______,bookTEN____,bookA______,bookQ______,bookTEN____,bookA______,bookQ______,bookSCARAB_,bookTEN____,bookA______,bookQ______,bookMAN____,bookTEN____,bookA______,bookJ______,bookSCARAB_,bookQ______,bookTEN____,bookK______,bookSTATUE_,bookTEN____,bookA______,bookQ______,bookJ______,bookA______",
        "bookQ______,bookSCARAB_,bookK______,bookTEN____,bookSTATUE_,bookJ______,bookBOOK___,bookK______,bookQ______,bookA______,bookTEN____,bookJ______,bookMAN____,bookQ______,bookA______,bookSTATUE_,bookJ______,bookQ______,bookBOOK___,bookA______,bookTEN____,bookK______,bookSCARAB_,bookQ______,bookJ______,bookA______,bookTEN____,bookTUT____,bookJ______,bookA______,bookTEN____,bookJ______,bookSTATUE_,bookQ______,bookA______,bookK______,bookTEN____",
        "bookK______,bookJ______,bookTEN____,bookK______,bookJ______,bookSCARAB_,bookTEN____,bookQ______,bookSTATUE_,bookJ______,bookQ______,bookSTATUE_,bookJ______,bookK______,bookBOOK___,bookTEN____,bookK______,bookJ______,bookA______,bookTEN____,bookQ______,bookSTATUE_,bookJ______,bookK______,bookQ______,bookTUT____,bookTEN____,bookK______,bookBOOK___,bookTEN____,bookA______,bookQ______,bookK______,bookJ______,bookA______,bookMAN____,bookK______,bookJ______,bookTEN____,bookK______,bookTUT____,bookJ______,bookA______,bookTEN____",
        "bookJ______,bookQ______,bookBOOK___,bookA______,bookTEN____,bookSCARAB_,bookA______,bookTEN____,bookTUT____,bookJ______,bookSTATUE_,bookK______,bookTEN____,bookBOOK___,bookQ______,bookK______,bookTUT____,bookQ______,bookTEN____,bookSCARAB_,bookA______,bookJ______,bookSTATUE_,bookK______,bookA______,bookSCARAB_,bookTEN____,bookSTATUE_,bookJ______,bookQ______,bookK______,bookMAN____,bookQ______,bookA______,bookSCARAB_",

        "bookQ______,bookJ______,bookBOOK___,bookTEN____,bookQ______,bookTUT____,bookK______,bookJ______,bookMAN____,bookA______,bookTEN____,bookQ______,bookA______,bookTEN____,bookSCARAB_,bookQ______,bookJ______,bookSCARAB_,bookK______,bookJ______,bookMAN____,bookA______,bookTEN____,bookTUT____,bookA______,bookQ______,bookJ______,bookTEN____,bookSTATUE_,bookQ______,bookA______,bookTEN____,bookTUT____,bookK______,bookJ______,bookTEN____,bookSTATUE_,bookA______,bookTEN____,bookSCARAB_,bookQ______,bookJ______,bookSTATUE_,bookA______,bookTEN____",
        "bookJ______,bookTEN____,bookBOOK___,bookQ______,bookJ______,bookTUT____,bookA______,bookTEN____,bookMAN____,bookK______,bookQ______,bookJ______,bookK______,bookQ______,bookSTATUE_,bookJ______,bookTEN____,bookSTATUE_,bookA______,bookTEN____,bookMAN____,bookK______,bookQ______,bookTUT____,bookK______,bookJ______,bookTEN____,bookQ______,bookSCARAB_,bookJ______,bookK______,bookQ______,bookTUT____,bookA______,bookTEN____,bookQ______,bookSCARAB_,bookK______,bookQ______,bookSTATUE_,bookJ______,bookTEN____,bookSCARAB_,bookK______,bookQ______",
        "bookA______,bookMAN____,bookQ______,bookTEN____,bookMAN____,bookK______,bookJ______,bookQ______,bookSCARAB_,bookJ______,bookK______,bookTUT____,bookA______,bookQ______,bookMAN____,bookTEN____,bookA______,bookK______,bookSTATUE_,bookA______,bookQ______,bookJ______,bookK______,bookTEN____,bookA______,bookJ______,bookBOOK___,bookTEN____,bookK______,bookJ______,bookSCARAB_,bookTEN____,bookQ______,bookTUT____,bookK______,bookJ______",
        "bookSTATUE_,bookA______,bookTEN____,bookSCARAB_,bookA______,bookJ______,bookQ______,bookMAN____,bookA______,bookSCARAB_,bookQ______,bookA______,bookSTATUE_,bookQ______,bookTEN____,bookA______,bookK______,bookMAN____,bookQ______,bookTEN____,bookTUT____,bookQ______,bookK______,bookBOOK___,bookQ______,bookJ______,bookTUT____,bookA______,bookTEN____,bookQ______,bookA______,bookBOOK___,bookQ______,bookJ______,bookTEN____,bookTUT____,bookA______,bookTEN____,bookQ______,bookSCARAB_,bookTEN____,bookJ______,bookSTATUE_,bookK______,bookTEN____,bookJ______",
        "bookJ______,bookA______,bookBOOK___,bookK______,bookTEN____,bookTUT____,bookA______,bookQ______,bookTUT____,bookTEN____,bookK______,bookMAN____,bookJ______,bookTEN____,bookSCARAB_,bookQ______,bookJ______,bookSCARAB_,bookK______,bookJ______,bookBOOK___,bookTEN____,bookQ______,bookSTATUE_,bookJ______,bookK______,bookA______,bookTEN____,bookSTATUE_,bookQ______",

        "bookSTATUE_,bookJ______,bookBOOK___,bookTEN____,bookK______,bookMAN____,bookA______,bookQ______,bookTUT____,bookA______,bookSCARAB_,bookK______,bookJ______,bookMAN____,bookTEN____,bookQ______,bookSCARAB_,bookK______,bookA______,bookSCARAB_,bookQ______,bookK______,bookBOOK___,bookQ______,bookA______,bookSTATUE_,bookQ______,bookTEN____,bookTUT____,bookK______,bookSTATUE_,bookA______,bookJ______,bookQ______,bookK______,bookSCARAB_,bookTEN____,bookA______,bookSTATUE_,bookJ______,bookTEN____,bookQ______,bookK______,bookTUT____,bookTEN____,bookJ______,bookQ______,bookSCARAB_,bookTEN____,bookA______",
        "bookSCARAB_,bookTEN____,bookBOOK___,bookQ______,bookA______,bookMAN____,bookK______,bookJ______,bookTUT____,bookK______,bookSTATUE_,bookA______,bookTEN____,bookMAN____,bookQ______,bookJ______,bookSTATUE_,bookA______,bookK______,bookSTATUE_,bookJ______,bookA______,bookBOOK___,bookJ______,bookK______,bookSCARAB_,bookJ______,bookQ______,bookTUT____,bookA______,bookSCARAB_,bookK______,bookTEN____,bookJ______,bookA______,bookSTATUE_,bookQ______,bookK______,bookSCARAB_,bookTEN____,bookQ______,bookJ______,bookA______,bookTUT____,bookQ______,bookTEN____,bookJ______,bookSTATUE_,bookQ______,bookK______",
        "bookBOOK___,bookTEN____,bookK______,bookQ______,bookSTATUE_,bookK______,bookTUT____,bookQ______,bookJ______,bookMAN____,bookA______,bookQ______,bookSCARAB_,bookK______,bookQ______,bookSTATUE_,bookTEN____,bookK______,bookSCARAB_,bookQ______,bookTEN____,bookSTATUE_,bookA______,bookJ______,bookTEN____,bookMAN____,bookJ______,bookA______,bookBOOK___,bookK______,bookTEN____,bookSCARAB_,bookK______,bookTEN____,bookSTATUE_,bookQ______,bookJ______",
        "bookTEN____,bookA______,bookSTATUE_,bookQ______,bookTEN____,bookTUT____,bookK______,bookA______,bookQ______,bookSCARAB_,bookTEN____,bookQ______,bookSTATUE_,bookJ______,bookK______,bookTEN____,bookTUT____,bookK______,bookA______,bookMAN____,bookJ______,bookQ______,bookBOOK___,bookA______,bookK______,bookSTATUE_,bookQ______,bookSCARAB_,bookA______,bookQ______,bookK______,bookTEN____,bookBOOK___,bookJ______,bookSCARAB_,bookA______,bookK______,bookMAN____,bookTEN____,bookSCARAB_,bookJ______",
        "bookSTATUE_,bookJ______,bookA______,bookBOOK___,bookTEN____,bookK______,bookMAN____,bookA______,bookQ______,bookSTATUE_,bookA______,bookTEN____,bookSCARAB_,bookK______,bookJ______,bookMAN____,bookTEN____,bookQ______,bookSCARAB_,bookJ______,bookA______,bookQ______,bookSCARAB_,bookTEN____,bookK______,bookBOOK___,bookJ______,bookA______,bookSTATUE_,bookQ______,bookTEN____,bookTUT____,bookJ______,bookK______",

        "bookTEN____,bookJ______,bookBOOK___,bookK______,bookJ______,bookSTATUE_,bookQ______,bookA______,bookTUT____,bookK______,bookQ______,bookTEN____,bookSCARAB_,bookQ______,bookA______,bookTUT____,bookJ______,bookSCARAB_,bookQ______,bookSTATUE_,bookA______,bookTEN____,bookBOOK___,bookQ______,bookJ______,bookSTATUE_,bookA______,bookK______,bookTUT____,bookQ______,bookSCARAB_,bookA______,bookTEN____,bookSCARAB_,bookK______,bookSTATUE_,bookQ______,bookMAN____,bookJ______,bookTEN____,bookSCARAB_,bookK______,bookJ______,bookMAN____,bookA______,bookK______,bookQ______,bookA______,bookK______",
        "bookQ______,bookTEN____,bookBOOK___,bookA______,bookTEN____,bookSCARAB_,bookJ______,bookK______,bookTUT____,bookA______,bookJ______,bookQ______,bookSTATUE_,bookJ______,bookK______,bookTUT____,bookTEN____,bookSTATUE_,bookJ______,bookSCARAB_,bookK______,bookQ______,bookBOOK___,bookJ______,bookTEN____,bookSCARAB_,bookK______,bookA______,bookTUT____,bookJ______,bookSTATUE_,bookK______,bookQ______,bookSTATUE_,bookA______,bookSCARAB_,bookJ______,bookMAN____,bookTEN____,bookQ______,bookSTATUE_,bookA______,bookTEN____,bookMAN____,bookK______,bookA______,bookJ______,bookK______,bookA______",
        "bookQ______,bookSTATUE_,bookTEN____,bookBOOK___,bookK______,bookTUT____,bookQ______,bookA______,bookSCARAB_,bookTEN____,bookJ______,bookBOOK___,bookK______,bookJ______,bookTUT____,bookA______,bookSCARAB_,bookJ______,bookA______,bookMAN____,bookJ______,bookTEN____,bookSCARAB_,bookA______,bookMAN____,bookK______,bookSTATUE_,bookTEN____,bookTUT____,bookQ______,bookSCARAB_,bookK______,bookSTATUE_,bookQ______,bookTUT____,bookTEN____,bookMAN____",
        "bookJ______,bookBOOK___,bookQ______,bookSCARAB_,bookK______,bookJ______,bookMAN____,bookQ______,bookA______,bookSTATUE_,bookQ______,bookSCARAB_,bookA______,bookTEN____,bookQ______,bookSCARAB_,bookA______,bookJ______,bookSTATUE_,bookQ______,bookK______,bookA______,bookSCARAB_,bookTEN____,bookA______,bookBOOK___,bookJ______,bookSTATUE_,bookK______,bookA______,bookMAN____,bookK______,bookSCARAB_,bookQ______,bookA______,bookTUT____,bookK______,bookJ______,bookQ______,bookSTATUE_,bookJ______,bookTUT____,bookTEN____,bookK______,bookMAN____,bookTEN____",
        "bookTEN____,bookJ______,bookBOOK___,bookK______,bookJ______,bookTUT____,bookQ______,bookTEN____,bookSCARAB_,bookK______,bookTEN____,bookSTATUE_,bookQ______,bookA______,bookTUT____,bookTEN____,bookQ______,bookSCARAB_,bookA______,bookTEN____,bookBOOK___,bookQ______,bookJ______,bookMAN____,bookA______,bookK______,bookSCARAB_,bookQ______,bookSTATUE_,bookK______,bookTEN____,bookSTATUE_,bookK______",
    };

    for (int i = 0; i < m_vecReelStripPlan.size(); i++) {
        ReelSet set;
        for (int j = 0; j < m_nReel; j++) {
            ReelStrip strip;
            std::stringstream ss(bookReelStrip[j * m_vecReelStripPlan.size() + i]);
            std::string item;
            while (std::getline(ss, item, ',')) {
                strip.push_back(item);
            }
            set.push_back(strip);
        }
        m_vecReelStripSets.push_back(set);
    }

    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_s_tmp;
    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_d_tmp;
    
    for (int i = 0; i < m_vecBetSteps_s_tmp.size(); i++) {
        std::map<std::string, std::map<UINT8, BONUS>> perSym;
        std::map<UINT8, BONUS> e;
        e[3].coin = AT(m_vecBetSteps_s_tmp, i) / AT(m_vecBetSteps_s_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_s_tmp, i) / AT(m_vecBetSteps_s_tmp, 0) * 25; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_s_tmp, i) / AT(m_vecBetSteps_s_tmp, 0) * 100; e[5].ag = 0;
        perSym["bookTEN____"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_s_tmp, i) / AT(m_vecBetSteps_s_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_s_tmp, i) / AT(m_vecBetSteps_s_tmp, 0) * 25; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_s_tmp, i) / AT(m_vecBetSteps_s_tmp, 0) * 100; e[5].ag = 0;
        perSym["bookJ______"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_s_tmp, i) / AT(m_vecBetSteps_s_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_s_tmp, i) / AT(m_vecBetSteps_s_tmp, 0) * 25; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_s_tmp, i) / AT(m_vecBetSteps_s_tmp, 0) * 100; e[5].ag = 0;
        perSym["bookQ______"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_s_tmp, i) / AT(m_vecBetSteps_s_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_s_tmp, i) / AT(m_vecBetSteps_s_tmp, 0) * 40; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_s_tmp, i) / AT(m_vecBetSteps_s_tmp, 0) * 150; e[5].ag = 0;
        perSym["bookK______"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_s_tmp, i) / AT(m_vecBetSteps_s_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_s_tmp, i) / AT(m_vecBetSteps_s_tmp, 0) * 40; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_s_tmp, i) / AT(m_vecBetSteps_s_tmp, 0) * 150; e[5].ag = 0;
        perSym["bookA______"] = e;
        e.clear();

        e[2].coin = AT(m_vecBetSteps_s_tmp, i) / AT(m_vecBetSteps_s_tmp, 0) * 5; e[2].ag = 0;
        e[3].coin = AT(m_vecBetSteps_s_tmp, i) / AT(m_vecBetSteps_s_tmp, 0) * 30; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_s_tmp, i) / AT(m_vecBetSteps_s_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_s_tmp, i) / AT(m_vecBetSteps_s_tmp, 0) * 750; e[5].ag = 0;
        perSym["bookSCARAB_"] = e;
        e.clear();

        e[2].coin = AT(m_vecBetSteps_s_tmp, i) / AT(m_vecBetSteps_s_tmp, 0) * 5; e[2].ag = 0;
        e[3].coin = AT(m_vecBetSteps_s_tmp, i) / AT(m_vecBetSteps_s_tmp, 0) * 30; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_s_tmp, i) / AT(m_vecBetSteps_s_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_s_tmp, i) / AT(m_vecBetSteps_s_tmp, 0) * 750; e[5].ag = 0;
        perSym["bookSTATUE_"] = e;
        e.clear();

        e[2].coin = AT(m_vecBetSteps_s_tmp, i) / AT(m_vecBetSteps_s_tmp, 0) * 5; e[2].ag = 0;
        e[3].coin = AT(m_vecBetSteps_s_tmp, i) / AT(m_vecBetSteps_s_tmp, 0) * 50; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_s_tmp, i) / AT(m_vecBetSteps_s_tmp, 0) * 500; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_s_tmp, i) / AT(m_vecBetSteps_s_tmp, 0) * 2000; e[5].ag = 0;
        perSym["bookTUT____"] = e;
        e.clear();

        e[2].coin = AT(m_vecBetSteps_s_tmp, i) / AT(m_vecBetSteps_s_tmp, 0) * 10; e[2].ag = 0;
        e[3].coin = AT(m_vecBetSteps_s_tmp, i) / AT(m_vecBetSteps_s_tmp, 0) * 100; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_s_tmp, i) / AT(m_vecBetSteps_s_tmp, 0) * 1000; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_s_tmp, i) / AT(m_vecBetSteps_s_tmp, 0) * 5000; e[5].ag = 0;
        perSym["bookMAN____"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_s_tmp, i) / AT(m_vecBetSteps_s_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_s_tmp, i) / AT(m_vecBetSteps_s_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_s_tmp, i) / AT(m_vecBetSteps_s_tmp, 0) * 1000; e[5].ag = 0;
        perSym["bookBOOK___"] = e;
        e.clear();

        m_Bonus_s_tmp[i] = perSym;
    }

    m_Bonus_s_tmp[1]["bookMAN____"][5].coin = 0; m_Bonus_s_tmp[1]["bookMAN____"][5].ag = 10; // 10
    m_Bonus_s_tmp[2]["bookMAN____"][5].coin = 0; m_Bonus_s_tmp[2]["bookMAN____"][5].ag = 20; // 20
    m_Bonus_s_tmp[3]["bookMAN____"][5].coin = 0; m_Bonus_s_tmp[3]["bookMAN____"][5].ag = 30; // 30
    m_Bonus_s_tmp[3]["bookTUT____"][5].coin = 0; m_Bonus_s_tmp[3]["bookTUT____"][5].ag = 12;
    m_Bonus_s_tmp[4]["bookMAN____"][5].coin = 0; m_Bonus_s_tmp[4]["bookMAN____"][5].ag = 40; // 40
    m_Bonus_s_tmp[4]["bookTUT____"][5].coin = 0; m_Bonus_s_tmp[4]["bookTUT____"][5].ag = 16;
    m_Bonus_s_tmp[5]["bookMAN____"][5].coin = 0; m_Bonus_s_tmp[5]["bookMAN____"][5].ag = 50; // 50
    m_Bonus_s_tmp[5]["bookMAN____"][4].coin = 0; m_Bonus_s_tmp[5]["bookMAN____"][4].ag = 10;
    m_Bonus_s_tmp[5]["bookTUT____"][5].coin = 0; m_Bonus_s_tmp[5]["bookTUT____"][5].ag = 20;
    m_Bonus_s_tmp[5]["bookBOOK___"][5].coin = 0; m_Bonus_s_tmp[5]["bookBOOK___"][5].ag = 10;
    m_Bonus_s_tmp[6]["bookMAN____"][5].coin = 0; m_Bonus_s_tmp[6]["bookMAN____"][5].ag = 60; // 60
    m_Bonus_s_tmp[6]["bookMAN____"][4].coin = 0; m_Bonus_s_tmp[6]["bookMAN____"][4].ag = 12;
    m_Bonus_s_tmp[6]["bookTUT____"][5].coin = 0; m_Bonus_s_tmp[6]["bookTUT____"][5].ag = 24;
    m_Bonus_s_tmp[6]["bookBOOK___"][5].coin = 0; m_Bonus_s_tmp[6]["bookBOOK___"][5].ag = 12;
    m_Bonus_s_tmp[7]["bookMAN____"][5].coin = 0; m_Bonus_s_tmp[7]["bookMAN____"][5].ag = 80; // 80
    m_Bonus_s_tmp[7]["bookMAN____"][4].coin = 0; m_Bonus_s_tmp[7]["bookMAN____"][4].ag = 16;
    m_Bonus_s_tmp[7]["bookTUT____"][5].coin = 0; m_Bonus_s_tmp[7]["bookTUT____"][5].ag = 32;
    m_Bonus_s_tmp[7]["bookBOOK___"][5].coin = 0; m_Bonus_s_tmp[7]["bookBOOK___"][5].ag = 16;
    m_Bonus_s_tmp[7]["bookSCARAB_"][5].coin = 0; m_Bonus_s_tmp[7]["bookSCARAB_"][5].ag = 12;
    m_Bonus_s_tmp[7]["bookSTATUE_"][5].coin = 0; m_Bonus_s_tmp[7]["bookSTATUE_"][5].ag = 12;
    m_Bonus_s_tmp[8]["bookMAN____"][5].coin = 0; m_Bonus_s_tmp[8]["bookMAN____"][5].ag = 100; // 100
    m_Bonus_s_tmp[8]["bookMAN____"][4].coin = 0; m_Bonus_s_tmp[8]["bookMAN____"][4].ag = 20;
    m_Bonus_s_tmp[8]["bookTUT____"][5].coin = 0; m_Bonus_s_tmp[8]["bookTUT____"][5].ag = 40;
    m_Bonus_s_tmp[8]["bookTUT____"][4].coin = 0; m_Bonus_s_tmp[8]["bookTUT____"][4].ag = 10;
    m_Bonus_s_tmp[8]["bookBOOK___"][5].coin = 0; m_Bonus_s_tmp[8]["bookBOOK___"][5].ag = 20;
    m_Bonus_s_tmp[8]["bookSCARAB_"][5].coin = 0; m_Bonus_s_tmp[8]["bookSCARAB_"][5].ag = 15;
    m_Bonus_s_tmp[8]["bookSTATUE_"][5].coin = 0; m_Bonus_s_tmp[8]["bookSTATUE_"][5].ag = 15;
    m_Bonus_s_tmp[9]["bookMAN____"][5].coin = 0; m_Bonus_s_tmp[9]["bookMAN____"][5].ag = 100; // 200
    m_Bonus_s_tmp[9]["bookMAN____"][4].coin = 0; m_Bonus_s_tmp[9]["bookMAN____"][4].ag = 40;
    m_Bonus_s_tmp[9]["bookTUT____"][5].coin = 0; m_Bonus_s_tmp[9]["bookTUT____"][5].ag = 80;
    m_Bonus_s_tmp[9]["bookTUT____"][4].coin = 0; m_Bonus_s_tmp[9]["bookTUT____"][4].ag = 20;
    m_Bonus_s_tmp[9]["bookBOOK___"][5].coin = 0; m_Bonus_s_tmp[9]["bookBOOK___"][5].ag = 40;
    m_Bonus_s_tmp[9]["bookSCARAB_"][5].coin = 0; m_Bonus_s_tmp[9]["bookSCARAB_"][5].ag = 30;
    m_Bonus_s_tmp[9]["bookSTATUE_"][5].coin = 0; m_Bonus_s_tmp[9]["bookSTATUE_"][5].ag = 30;
    m_Bonus_s_tmp[10]["bookMAN____"][5].coin = 0; m_Bonus_s_tmp[10]["bookMAN____"][5].ag = 100; // 500
    m_Bonus_s_tmp[10]["bookMAN____"][4].coin = 0; m_Bonus_s_tmp[10]["bookMAN____"][4].ag = 100;
    m_Bonus_s_tmp[10]["bookMAN____"][3].coin = 0; m_Bonus_s_tmp[10]["bookMAN____"][3].ag = 10;
    m_Bonus_s_tmp[10]["bookTUT____"][5].coin = 0; m_Bonus_s_tmp[10]["bookTUT____"][5].ag = 100;
    m_Bonus_s_tmp[10]["bookTUT____"][4].coin = 0; m_Bonus_s_tmp[10]["bookTUT____"][4].ag = 50;
    m_Bonus_s_tmp[10]["bookBOOK___"][5].coin = 0; m_Bonus_s_tmp[10]["bookBOOK___"][5].ag = 100;
    m_Bonus_s_tmp[10]["bookBOOK___"][4].coin = 0; m_Bonus_s_tmp[10]["bookBOOK___"][4].ag = 10;
    m_Bonus_s_tmp[10]["bookSCARAB_"][5].coin = 0; m_Bonus_s_tmp[10]["bookSCARAB_"][5].ag = 75;
    m_Bonus_s_tmp[10]["bookSCARAB_"][4].coin = 0; m_Bonus_s_tmp[10]["bookSCARAB_"][4].ag = 10;
    m_Bonus_s_tmp[10]["bookSTATUE_"][5].coin = 0; m_Bonus_s_tmp[10]["bookSTATUE_"][5].ag = 75;
    m_Bonus_s_tmp[10]["bookSTATUE_"][4].coin = 0; m_Bonus_s_tmp[10]["bookSTATUE_"][4].ag = 10;
    m_Bonus_s_tmp[10]["bookA______"][5].coin = 0; m_Bonus_s_tmp[10]["bookA______"][5].ag = 15;
    m_Bonus_s_tmp[10]["bookK______"][5].coin = 0; m_Bonus_s_tmp[10]["bookK______"][5].ag = 15;
    m_Bonus_s_tmp[10]["bookQ______"][5].coin = 0; m_Bonus_s_tmp[10]["bookQ______"][5].ag = 10;
    m_Bonus_s_tmp[10]["bookJ______"][5].coin = 0; m_Bonus_s_tmp[10]["bookJ______"][5].ag = 10;
    m_Bonus_s_tmp[10]["bookTEN____"][5].coin = 0; m_Bonus_s_tmp[10]["bookTEN____"][5].ag = 10;

    
    m_Bonus_d_tmp = m_Bonus_s_tmp;

    int nSavedBetVal = 10;
    int nMode = RgDoubleBook_MODE_single;
    string data;
    PlayDB::GetInstance().LoadCheckPoint(m_strGameName, nSavedBetVal, nMode, m_strCheckPoint);
    if (nSavedBetVal == -1) {
        nSavedBetVal = 10;
    }
    if (nMode == -1) {
        nMode = RgDoubleBook_MODE_single;
    }
    m_nMode = nMode;

    BOOL start = FALSE;
    int idx = 0;
    for (int i = 0; i < m_vecBetSteps_s_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_s_tmp, i) < AT(m_vecBetSteps_s, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps_s, idx) == nSavedBetVal && m_nMode == RgDoubleBook_MODE_single) {
            m_nBetStep = idx;
        }

        m_Bonus_s[idx++] = m_Bonus_s_tmp[i];
        if (AT(m_vecBetSteps_s_tmp, i) == AT(m_vecBetSteps_s, m_vecBetSteps_s.size() - 1)) {
            break;
        }
    }
    start = FALSE;
    idx = 0;
    for (int i = 0; i < m_vecBetSteps_d_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_d_tmp, i) < AT(m_vecBetSteps_d, 0)) {
                continue;
            }
            start = TRUE;
        }
        
        // set betstep by saved value
        if (AT(m_vecBetSteps_d, idx) == nSavedBetVal && m_nMode == RgDoubleBook_MODE_double) {
            m_nBetStep = idx;
        }

        m_Bonus_d[idx++] = m_Bonus_d_tmp[i];
        if (AT(m_vecBetSteps_d_tmp, i) == AT(m_vecBetSteps_d, m_vecBetSteps_d.size() - 1)) {
            break;
        }
    }
    m_Bonus_05 = m_Bonus_s;
    m_Bonus_10 = m_Bonus_d;

    m_Bonus = (m_nMode == RgDoubleBook_MODE_single ? m_Bonus_s : m_Bonus_d);
    m_vecBetSteps = (m_nMode == RgDoubleBook_MODE_single ? m_vecBetSteps_s : m_vecBetSteps_d);
    PrintAllBonus();
}

UINT16 RgDoubleBook::Run() {
    m_nCurrentReelPlan = 1 + (myRandom() % (m_vecReelStripPlan.size() - 1));
#ifdef TEST_FREE_MODE
    m_nCurrentReelPlan = 0;
#endif
    m_shCurrentReelStrip = static_cast<uint16_t>(std::stoi(AT(m_vecReelStripPlan, m_nCurrentReelPlan)));
    return m_shCurrentReelStrip;
}

void RgDoubleBook::ChangeReelStrip(UINT16 NewReelPlan) {
    m_nCurrentReelPlan = NewReelPlan;
    m_shCurrentReelStrip = static_cast<uint16_t>(std::stoi(AT(m_vecReelStripPlan, m_nCurrentReelPlan)));
}

myVector<UINT8> RgDoubleBook::Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) {
    m_bPrevSpinMatchedActive = FALSE;
    m_nMagicCount = 0;

    myVector<UINT8> result;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);

    if (bTest) {
        std::string matchSymbol = AT(m_vecSymbols, myRandom() % (m_vecSymbols.size() - 1));
        int line = (myRandom() % m_nWinLine);
        int weight = 1 + (myRandom() % 5);

        BOOL bForceFree = (myRandom() % 10 == 0);
        for (int i = 0; i < m_nReel; i++) {
            ReelStrip reelStrip = AT(reelSet, i);
            int len = reelStrip.size() - 3;

            int valid_i[0x100];
            int valid_count = 0;
            myVector<int> freeSymbols;
            for (int j = 0; j <= len; j++) {
                if (weight > i) {
                    if (matchSymbol == AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                else {
                    if (matchSymbol != AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                if (AT(reelStrip, j) == RgDoubleBook_book && m_bFreeMode == FALSE) {
                    freeSymbols.push_back(j);
                }
            }
            if (valid_count > 0) {
                int rand_index = myRandom() % valid_count;
                int chosen_i = valid_i[rand_index];
                result.push_back(chosen_i + 1);
            }
            else {
                result.push_back((myRandom() % (len - 1)) + 1);
            }
            if (bForceFree && m_bFreeMode == FALSE && (i == 1 || i == 2 || i == 4) && freeSymbols.size() > 0) {
                AT(result, result.size() - 1) =
                    AT(freeSymbols, myRandom() % freeSymbols.size()) - (myRandom() % 2) + 1;
            }
        }
    }
    else {
        result = _result;
        m_vWinResult = result;

        BOOL mmcode = mmcode_get_active_status();
        if (mmcode) {
            mmcode_set_deactive();
            if (m_bFreeMode == FALSE) {
                for (int j = 0; j < 5; j ++) {
                    myVector<int> candidateIndices;
                    for (int i = 2; i < AT(reelSet, j).size() - 3; ++i) {
                        if (j%2 == 0 && AT(AT(reelSet, j), i) == RgDoubleBook_book) {
                            int offset = myRandom() % 3;
                            int selectedIndex = i - 2 + offset;
                            candidateIndices.push_back(selectedIndex);
                        }
                        if (j%2 == 1 && AT(AT(reelSet, j), i) != RgDoubleBook_book
                                    && AT(AT(reelSet, j), i-2) != RgDoubleBook_book
                                    && AT(AT(reelSet, j), i-1) != RgDoubleBook_book
                                    && AT(AT(reelSet, j), i+1) != RgDoubleBook_book
                                    && AT(AT(reelSet, j), i+2) != RgDoubleBook_book) {
                            int offset = myRandom() % 3;
                            int selectedIndex = i - 2 + offset;
                            candidateIndices.push_back(selectedIndex);
                        }
                    }
                    if (!candidateIndices.empty()) {
#ifdef BIGBET_ACTIVE
                        int chosenIndex = AT(candidateIndices, 0);
#else
                        int chosenIndex = AT(candidateIndices, myRandom() % candidateIndices.size());
#endif
                        AT(result, j) = chosenIndex + 1;
                    }
                }
            }
        }
        if (m_bFreeMode && ((myRandom() % 3) == 0)) {
            int pool[5] = { 0, 1, 2, 3, 4 };
            int existCnt = 0;

            std::string strConvertableSymbol = m_strSelected_0;
            if (m_nMode == RgDoubleBook_MODE_single) {
                strConvertableSymbol = m_strSelected_0;
            }
            else {
                strConvertableSymbol = (myRandom() & 1) ? m_strSelected_0 : m_strSelected_1;
            }
            // get exists
            // check wild symbol
            for (int col = 0; col < 5; col++) {
                if (CardNumInCol(col, strConvertableSymbol) > 0) {
                    existCnt++;
                }
            }
            if (existCnt < m_mapSymbolMinMatch[strConvertableSymbol]) {
                int poolSize = 0;
                for (int col = 0; col < 5; col++) {
                    if (CardNumInCol(col, strConvertableSymbol) == 0) {
                        pool[poolSize] = col;
                        poolSize++;
                    }
                }
                myVector<int> selectedReels = pickRandom2or3(pool, poolSize, m_mapSymbolMinMatch[strConvertableSymbol] - existCnt);
                for (int j = 0; j < selectedReels.size(); j++) {
                    int reel = AT(selectedReels, j);
                    ReelStrip reelStrip = AT(reelSet, reel);
                    for (int i = 3; i < reelStrip.size() - 2; i++) {
                        if (AT(reelStrip, i) == strConvertableSymbol) {
                            AT(result, reel) = i - (myRandom() % 3) + 1;
                            break;
                        }
                    }
                }
            }
        }
    }

    m_vWinResult = result;

    normalMeter = 0;
    maxMeter = 0;
    BONUS totalBonus = {0, 0};
    int maxBookMatchCount = 0;
    int Book5Matched = 0;
    for (int i = 0; i < m_nWinLine; i++) {
        int j = 1;
        UINT16 meter = ((UINT16)1 << (2 - g_match_lines_10_5[i][0]));
        std::string firstSymbol = AT(AT(reelSet, 0), AT(result, 0) - 1 + g_match_lines_10_5[i][0]);
        maxBookMatchCount = 0;

        for (; j < m_nMaxMatch; j++) {
            std::string prev_symbol = AT(AT(reelSet, j - 1), AT(result, j - 1) - 1 + g_match_lines_10_5[i][j - 1]);
            std::string cur_symbol = AT(AT(reelSet, j), AT(result, j) - 1 + g_match_lines_10_5[i][j]);

            if (cur_symbol == RgDoubleBook_book) {
                maxBookMatchCount++;
            }
            if (firstSymbol == RgDoubleBook_book) { // scatter
                firstSymbol = cur_symbol;
            }

            if (firstSymbol == cur_symbol || cur_symbol == RgDoubleBook_book) {
                meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
                continue;
            }
            break;
        }

        if (j < m_mapSymbolMinMatch[firstSymbol] || m_mapSymbolMinMatch[firstSymbol] == 0) {
            continue;
        }
        if (firstSymbol == RgDoubleBook_book) {
            Book5Matched = 1;
        }

        // monitor 2 meter
        std::string meterStr = m_mapSymbolMeterGoc[firstSymbol];
        size_t pos = meterStr.find('$');
        if (pos != std::string::npos) {
            meterStr = meterStr.replace(pos, 1, std::to_string(j));
        }

        WinMeter e;
        e.line = i;
        e.meter = meter;
        e.meter2 = g_GrafficObjList.Str2GOCID(meterStr);
        e.symbol = firstSymbol;
        e.weight = j;
        e.start = 0;
        e.bonus = m_Bonus[BetStep()][firstSymbol][j];
        e.sound = MAX_SOUND_IDS;

        totalBonus.coin += e.bonus.coin;
        totalBonus.ag += e.bonus.ag;

        if (e.meter2 != -1) {
            meters.push_back(e);
        }
        if (j == m_nMaxMatch) {
            maxMeter |= meter;
        }
        else {
            normalMeter |= meter;
        }

        if (bTest == FALSE) {
            m_bPrevSpinMatchedActive = TRUE;
        }
    }

    int nBook = CardCount(RgDoubleBook_book);
    if (nBook >= 3) {
        bCanFreeMode = TRUE;

        // not match Book 5, and Book match contains other match
        if (Book5Matched == 0 && maxBookMatchCount < nBook) {
            UINT16 meter = 0;
            for (int i = 0; i < 3; i++) {
                for (int col = 0; col < m_nReel; col++) {
                    std::string cur_symbol = AT(AT(reelSet, col), AT(result, col) - 1 + i);
                    if (cur_symbol == RgDoubleBook_book) {
                        meter |= ((UINT16)1 << (3 * col + (2 - i)));
                    }
                }
            }

            WinMeter e;
            e.line = 5;
            e.meter = meter;
            e.meter2 = g_GrafficObjList.Str2GOCID("bookBook" + std::to_string(nBook) + "x");
            e.symbol = RgDoubleBook_book;
            e.weight = nBook;
            e.start = 0;
            e.bonus = m_Bonus[BetStep()][RgDoubleBook_book][nBook];
            e.sound = MAX_SOUND_IDS;

            normalMeter |= meter;
            totalBonus.coin += e.bonus.coin;
            totalBonus.ag += e.bonus.ag;

            meters.push_back(e);
            if (bTest == FALSE) {
                m_bPrevSpinMatchedActive = TRUE;
            }
        }
    }
    if (m_bFreeMode) {
        int colCount_0 = 0;
        int symbolToConvert_0 = 0;
        for (int col = 0; col < m_nReel; col++) {
            int n = CardNumInCol(col, m_strSelected_0);
            if (n > 0) {
                colCount_0++;
                symbolToConvert_0 += (3 - n);
            }
        }
        BOOL firstSymbolConvertable = (colCount_0 >= m_mapSymbolMinMatch[m_strSelected_0] && m_mapSymbolMinMatch[m_strSelected_0] > 0);

        int colCount_1 = 0;
        int symbolToConvert_1 = 0;
        if (m_nMode == RgDoubleBook_MODE_double) {
            for (int col = 0; col < m_nReel; col++) {
                int n = CardNumInCol(col, m_strSelected_1);
                if (n > 0) {
                    colCount_1++;
                    symbolToConvert_1 += (3 - n);
                }
            }
        }
        BOOL secondSymbolConvertable = (colCount_1 >= m_mapSymbolMinMatch[m_strSelected_1] && m_mapSymbolMinMatch[m_strSelected_1] > 0);        
        if (firstSymbolConvertable) {
            Convert1stSymbol(colCount_0, symbolToConvert_0, totalBonus, meters);
        }
        if (secondSymbolConvertable && m_nMode == RgDoubleBook_MODE_double) {
            Convert2ndSymbol(colCount_1, symbolToConvert_1, totalBonus, meters, firstSymbolConvertable);
        }
    }
    m_vWinMeters = meters;
    m_nMagicCount = totalBonus.ag;
    if (bTest == FALSE) {
        updateCheckPoint();

        if (totalBonus.coin > 0 || totalBonus.ag > 0) {
            m_nFreeModeTotalBonus.coin += totalBonus.coin;
            m_nFreeModeTotalBonus.ag += totalBonus.ag;
            BonusSound = getSoundByID(WinSound(totalBonus.coin + totalBonus.ag * 1000));
        }
    }
    return result;
}

void RgDoubleBook::Convert1stSymbol(int weight, int symbolToconvert, BONUS& totalBonus, myVector<WinMeter>& meters) {
    UINT16 GOC_0 = g_GrafficObjList.Str2GOCID(m_strSelected_0);

    UINT32 convertDelay = symbolToconvert * 500;
    WinMeter e;
    e.line = 0xFF;
    e.bonus = {0, 0};
    e.IntWinbonus.push_back({
        0,
        convertDelay,
        {0x01, 0x02, 0x31, 0x00, 0x02, 0x00, 0x03, 0x16, 0xce, 
        static_cast<BYTE>(GOC_0 & 0xFF), static_cast<BYTE>((GOC_0 >> 8) & 0xFF), 0x04} });

    //
    myVector<uint8_t> pkt = {
        0x01, 0x02, 0x31, 0x00, 0x08, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x9c, 0x15, 0x00
    };
    int pktLen = 0;
    // get win match after convert
    myVector<WinMeter> FreeMeters;
    for (int i = 0; i < m_nWinLine; i++) {
        UINT16 meter = 0;// ((UINT16)1 << (2 - g_match_lines_10_5[i][0]));
        for (int j = 0; j < m_nMaxMatch; j++) {
            if (!CardNumInCol(j, m_strSelected_0)) {
                continue;
            }
            meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
        }
        std::string meterStr = m_mapSymbolMeterGoc[m_strSelected_0];
        size_t pos = meterStr.find('$');
        if (pos != std::string::npos) {
            meterStr = meterStr.replace(pos, 1, std::to_string(weight));
        }

        WinMeter ele;
        ele.line = i;
        ele.meter = meter;
        ele.meter2 = g_GrafficObjList.Str2GOCID(meterStr);
        ele.symbol = m_strSelected_0;
        ele.weight = weight;
        ele.start = 0;
        ele.bonus = m_Bonus[BetStep()][m_strSelected_0][weight];
        ele.sound = MAX_SOUND_IDS;

        totalBonus.coin += ele.bonus.coin;
        totalBonus.ag += ele.bonus.ag;

        /*if (ele.meter2 != -1) {
            meters.push_back(ele);
        }*/
        FreeMeters.push_back(ele);
        pkt.push_back(ele.line);
        pkt.push_back(static_cast<BYTE>(ele.meter & 0xFF));
        pkt.push_back(static_cast<BYTE>((ele.meter >> 8) & 0xFF));
        pkt.push_back(static_cast<BYTE>(ele.meter2 & 0xFF));
        pkt.push_back(static_cast<BYTE>((ele.meter2 >> 8) & 0xFF));
        pkt.push_back(0x01);
        pkt.push_back(0x00);
        pktLen += 7;
    }
    AT(pkt, 4) = 1 + pktLen; //len
    AT(pkt, pkt.size() - 1) = 0x04;
    // refresh meters
    e.IntWinbonus.push_back({ 0, 0, pkt });
    meters.push_back(e);
    meters.insert(meters.end(), FreeMeters.begin(), FreeMeters.end());

}

void RgDoubleBook::Convert2ndSymbol(int weight, int symbolToconvert, BONUS& totalBonus, myVector<WinMeter>& meters, BOOL firstEnable) {
    UINT16 GOC_1 = g_GrafficObjList.Str2GOCID(m_strSelected_1);

    UINT preDelay = 0;
    if (firstEnable) {
        preDelay = 1000;
    }

    UINT32 convertDelay = symbolToconvert * 500;
    WinMeter e;
    e.line = 0xFF;
    e.bonus = {0, 0};
    e.IntWinbonus.push_back({
        preDelay,
        convertDelay,
        {0x06, 0x30, 0x59, 0x01, 0x02, 0x31, 0x00, 0x02, 0x00, 0x03, 0x16, 0xce, 
        static_cast<BYTE>(GOC_1 & 0xFF), static_cast<BYTE>((GOC_1 >> 8) & 0xFF), 0x04} });

    //
    myVector<uint8_t> pkt = {
        0x01, 0x02, 0x31, 0x00, 0x08, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x9c, 0x15, 0x00
    };
    int pktLen = 0;
    // get win match after convert
    myVector<WinMeter> FreeMeters;
    for (int i = 0; i < m_nWinLine; i++) {
        UINT16 meter = 0;// ((UINT16)1 << (2 - g_match_lines_10_5[i][0]));
        for (int j = 0; j < m_nMaxMatch; j++) {
            if (!CardNumInCol(j, m_strSelected_1)) {
                continue;
            }
            meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
        }
        std::string meterStr = m_mapSymbolMeterGoc[m_strSelected_1];
        size_t pos = meterStr.find('$');
        if (pos != std::string::npos) {
            meterStr = meterStr.replace(pos, 1, std::to_string(weight));
        }

        WinMeter ele;
        ele.line = i;
        ele.meter = meter;
        ele.meter2 = g_GrafficObjList.Str2GOCID(meterStr);
        ele.symbol = m_strSelected_1;
        ele.weight = weight;
        ele.start = 0;
        ele.bonus = m_Bonus[BetStep()][m_strSelected_1][weight];
        ele.sound = MAX_SOUND_IDS;

        totalBonus.coin += ele.bonus.coin;
        totalBonus.ag += ele.bonus.ag;

        /*if (ele.meter2 != -1) {
            meters.push_back(ele);
        }*/
        FreeMeters.push_back(ele);
        pkt.push_back(ele.line);
        pkt.push_back(static_cast<BYTE>(ele.meter & 0xFF));
        pkt.push_back(static_cast<BYTE>((ele.meter >> 8) & 0xFF));
        pkt.push_back(static_cast<BYTE>(ele.meter2 & 0xFF));
        pkt.push_back(static_cast<BYTE>((ele.meter2 >> 8) & 0xFF));
        pkt.push_back(0x01);
        pkt.push_back(0x00);
        pktLen += 7;
    }
    AT(pkt, 4) = 1 + pktLen; //len
    AT(pkt, pkt.size() - 1) = 0x04;
    // refresh meters
    e.IntWinbonus.push_back({ 0, 0, pkt });
    meters.push_back(e);
    meters.insert(meters.end(), FreeMeters.begin(), FreeMeters.end());
}

UINT8 RgDoubleBook::CardCount(std::string card) {
    int n = 0;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int col = 0; col < m_nReel; col++) {
        int k = 0;
        for (; k < 3; k++) {
            std::string s = AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k);
            if (s == card) {
                n++;
            }
        }
    }
    return n;
}

BOOL RgDoubleBook::BookInCol(int col) {
    return CardNumInCol(col, RgDoubleBook_book);
}

UINT8 RgDoubleBook::CardNumInCol(int col, std::string card) {
    int n = 0;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int k = 0; k < 3; k++) {
        std::string s = AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k);
        if (s == card) {
            n++;
        }
    }
    return n;
}

UINT16 RgDoubleBook::SpinTime_MS() {
    if (CardCount(RgDoubleBook_book) >= 3) {
        return 4000;
    }
    if (CardCount(RgDoubleBook_book) == 2 && BookInCol(4) == FALSE) {
        return 4000;
    }
    return 2000;
}

int RgDoubleBook::LineSwapDelay(int _WinIdx) {
    return 300;
}

BOOL RgDoubleBook::CanFreeMode() {
    if (CardCount(RgDoubleBook_book) >= 3) {
        return TRUE;
    }
    return FALSE;
}

myVector<InterruptPacketData> RgDoubleBook::EnterFreeGame(std::string check) {
    m_bFreeMode = TRUE;
    m_nFreeModeTotalSpin = (m_nMode == RgDoubleBook_MODE_double ? 15 : 10);
    m_nFreeModeGoneSpin = 0;
    m_nFreeModeTotalBonus = {0, 0};
    myVector<InterruptPacketData> packets;

    // stop all sound
    packets.push_back({
        0,
        0,
        {0x01, 0x02, 0x35, 0x00, 0x00, 0x00, 0x04} });

    std::mt19937 rng(static_cast<unsigned>(std::time(nullptr)));
    std::uniform_int_distribution<size_t> dist1(0, m_vecSymbols.size() - 2);
    size_t index1 = dist1(rng);
    size_t index2;
    do {
        index2 = dist1(rng);
    } while (index2 == index1);

    m_strSelected_0 = AT(m_vecSymbols, index1);
    m_strSelected_1 = AT(m_vecSymbols, index2);

    if (check != "") {
        myVector<int> values = ParseCheckPoint(check, "F", 6);
        if (values.size() == 6) {
            index1 = AT(values, 0);
            index2 = AT(values, 1);

            m_strSelected_0 = AT(m_vecSymbols, index1);
            m_strSelected_1 = AT(m_vecSymbols, index2);

            m_nFreeModeTotalSpin = AT(values, 2);
            m_nFreeModeGoneSpin = AT(values, 3);
            m_nFreeModeTotalBonus.coin = AT(values, 4);
            m_nFreeModeTotalBonus.ag = AT(values, 5);

            UINT8 gone = (m_nFreeModeGoneSpin ? m_nFreeModeGoneSpin : 1);
            packets.push_back({
                0,
                0,
                {0x01, 0x02, 0x30, 0x00, 0x03, 0x16, gone, 0x00, m_nFreeModeTotalSpin, 0x00, 0x00, 0x00,
                static_cast<BYTE>(index1 + 1), static_cast<BYTE>(index2 + 1), 0xa3, 0x04} });
            return packets;
        }
    }
    else {
        updateCheckPoint();
    }

    // show video
    packets.push_back({
        0,
        26 * 1000,
        {0x01, 0x02, 0x30, 0x00, 0x03, 0x16, 0x00, 0x00, m_nFreeModeGoneSpin, 0x00, m_nFreeModeTotalSpin, 0x00, static_cast<BYTE>(index1 + 1), static_cast<BYTE>(index2 + 1), 0xa6, 0x04} });

    UINT32 delay = (m_nMode == RgDoubleBook_MODE_double ? 21 * 1000 : 12 * 1000);
    // select cards
    packets.push_back({
        0,
        delay,
        {0x06, 0x03, 0x16, 0x01, 0x02, 0x31, 0x00, 0x00, 0x00, 0x03, 0x16, 0xcf, 0x04} });
    return packets;
}

myVector<InterruptPacketData> RgDoubleBook::InterruptBeforeSpin() {
    myVector<InterruptPacketData> packets;
    if (!m_bFreeMode) {
        return packets;
    }
    m_nFreeModeGoneSpin++;
    updateCheckPoint();

    UINT8 gone = (m_nFreeModeGoneSpin ? m_nFreeModeGoneSpin : 1);

    // display total & remain free spin count
    packets.push_back({
        0,
        0,
        {
            0x01, 0x02, 0x30, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), gone, 0x00, m_nFreeModeTotalSpin, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa5, 0x04
        }
        });
    return packets;
}

myVector<InterruptPacketData> RgDoubleBook::InterruptAfterMoveBonus(BOOL& EndFree) {
    myVector<InterruptPacketData> packets;
    if (m_nFreeModeGoneSpin >= m_nFreeModeTotalSpin) { // ref EyeOfHorus
        EndFree = TRUE;
        m_bFreeMode = FALSE;
        
        // show freemode result dialog and return to main game
        packets.push_back({
             100,
             0,
             {0x06, 0x03, 0x16, 0x01, 0x02, 0x30, 0x00, 0x03, 0x16, 0x00, 0x00, 
             static_cast<BYTE>(m_nFreeModeTotalBonus.coin & 0xFF), 
             static_cast<BYTE>((m_nFreeModeTotalBonus.coin >> 8) & 0xFF),
             static_cast<BYTE>((m_nFreeModeTotalBonus.coin >> 16) & 0xFF),
             static_cast<BYTE>((m_nFreeModeTotalBonus.coin >> 24) & 0xFF),
             0x1e, 0x00, 0xab, 0x04} });
        
        // return to main game
        packets.push_back({
             0,
             2000,
             {0x01, 0x02, 0x30, 0x00, 0x03, 0x16, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa4, 0x04} });

        updateCheckPoint();
        return packets;
    }
    EndFree = FALSE;

    //m_nFreeModeGoneSpin++;
    updateCheckPoint();
    return packets;
}

UINT16 RgDoubleBook::MagicCount() {
    if (m_bFreeMode) {
        return 0;
    }
    else {
        return m_nMagicCount;
    }
}

myVector<InterruptPacketData> RgDoubleBook::MousePressed(MousePosition p) {
    myVector<InterruptPacketData> packets;

    MousePosition a{
       {RgDoubleBook_MP_ChangeLine_LB_x_reel, RgDoubleBook_MP_ChangeLine_LB_x_pos },
       {RgDoubleBook_MP_ChangeLine_LB_y_row, RgDoubleBook_MP_ChangeLine_LB_y_pos }
    };
    MousePosition b{
        {RgDoubleBook_MP_ChangeLine_RT_x_reel, RgDoubleBook_MP_ChangeLine_RT_x_pos },
        {RgDoubleBook_MP_ChangeLine_RT_y_row, RgDoubleBook_MP_ChangeLine_RT_y_pos }
    };
    UINT16 newBetValue = 0;
    if (IsMouseWithin(p, a, b)) {
        m_nMode = (m_nMode == RgDoubleBook_MODE_double) ? RgDoubleBook_MODE_single : RgDoubleBook_MODE_double;
        if (m_bPrevSpinMatchedActive) {
            // hide win lines
            packets.push_back({ 0, 0, {0x01, 0x02, 0x31, 0x00, 0x01, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x02, 0x00, 0x04} });
            m_bPrevSpinMatchedActive = FALSE;
        }
        if (m_nMode == RgDoubleBook_MODE_double) {
            m_Bonus = m_Bonus_d;
            m_vecBetSteps = m_vecBetSteps_d;
            newBetValue = AT(m_vecBetSteps_s, m_nBetStep) * 2;
        }
        else {
            m_Bonus = m_Bonus_s;
            m_vecBetSteps = m_vecBetSteps_s;
            newBetValue = AT(m_vecBetSteps_d, m_nBetStep) / 2;
        }
        BOOL flag = FALSE;
        for (int i = 0; i < m_vecBetSteps.size(); i++) {
            if (AT(m_vecBetSteps, i) == newBetValue) {
                m_nBetStep = i;
                flag = TRUE;
                break;
            }
        }
        if (flag == FALSE) {
            m_nBetStep = 0;
        }
        // change game mode
        packets.push_back({ 0, 0, {0x01, 0x02, 0x28, 0x00, 0x03, 0x16, static_cast<BYTE>(m_nMode), 0x00, 0x00, 0x00, 0x04}});
        // play button sound
        packets.push_back({ 0, 0, {0x01, 0x02, 0x34, 0x00, 0xf7, 0x00, 0x04} });
        // set bet
        UINT16 bet = AT(m_vecBetSteps, m_nBetStep) / 5;
        packets.push_back({ 0, 0, {0x01, 0x02, 0x30, 0x00, 0x25, 0x53, 
            static_cast<BYTE>(bet & 0xFF), static_cast<BYTE>((bet >> 8) & 0xFF), 
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04, 0x04} });
    }
    return packets;
}


myVector<UINT8> RgDoubleBook::ShowTotalWinLines(myVector<WinMeter> SpinMeters) {
    myVector<uint8_t> packet = {
        0x06, 0x30, 0x59, 0x01, 0x02, 0x31, 0x00,
        0x0F, 0x00,  // Placeholder for length 
        0x0F, 0x11, // GameID
        0x9C, 0x19, 0x01
    };
    myVector<UINT8> TotalMatch;
    for (int i = 0; i < SpinMeters.size(); i++) {
        if (AT(SpinMeters, i).line == 0xFF) { // clear after convert action
            TotalMatch.clear();
            continue;
        }
        TotalMatch.push_back(AT(SpinMeters, i).line);
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter >> 8) & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter2 & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter2 >> 8) & 0xFF));
    }
    if (TotalMatch.size() < 10) {
        myVector<UINT8> _;
        return _;
    }
    UINT16 pktLen = 1 + (TotalMatch.size() / 5) * 7;
    AT(packet, 7) = static_cast<BYTE>(pktLen & 0xFF);
    AT(packet, 8) = static_cast<BYTE>((pktLen >> 8) & 0xFF);
    AT(packet, 9) = static_cast<BYTE>(m_nGameID & 0xFF);
    AT(packet, 10) = static_cast<BYTE>((m_nGameID >> 8) & 0xFF);
    int entryCount = static_cast<int>(TotalMatch.size() / 5);
    for (int i = 0; i < entryCount; ++i) {
        packet.push_back(AT(TotalMatch, i * 5 + 0)); // Line
        packet.push_back(AT(TotalMatch, i * 5 + 1)); // Meter low byte
        packet.push_back(AT(TotalMatch, i * 5 + 2)); // Meter high byte
        packet.push_back(AT(TotalMatch, i * 5 + 3)); // Meter2 low byte
        packet.push_back(AT(TotalMatch, i * 5 + 4)); // Meter2 high byte
        packet.push_back(0x01);      // Status or flag 1
        packet.push_back(0x01);      // Status or flag 2
    }
    // Mark the end of the packet
    packet.back() = 0x04;
    return packet;
}

bool RgDoubleBook::RTP_force_bigWin() {
    return (myRandom() % 80 == 0); // 1.2%
}

BOOL RgDoubleBook::SelectedableReelsInFreeGame(myVector<UINT8> result) {
    if (m_bFreeMode == FALSE) {
        return TRUE;
    }
    myVector<UINT8> cp = m_vWinResult;
    m_vWinResult = result;
    int n = CardCount(RgDoubleBook_book);
    m_vWinResult = cp;
    if (n >= 3) {
        return FALSE;
    }
    return TRUE;
}

UINT RgDoubleBook::GameMode() {
    return m_nMode;
}

void RgDoubleBook::updateCheckPoint() {
    std::ostringstream oss;
    oss << " P" << m_nCurrentReelPlan
        << " B"
        << static_cast<int>(AT(m_vWinResult, 0)) << ":"
        << static_cast<int>(AT(m_vWinResult, 1)) << ":"
        << static_cast<int>(AT(m_vWinResult, 2)) << ":"
        << static_cast<int>(AT(m_vWinResult, 3)) << ":"
        << static_cast<int>(AT(m_vWinResult, 4)) << " ";

    if (m_bFreeMode) {
        int idx_0 = 0;
        auto it_0 = std::find(m_vecSymbols.begin(), m_vecSymbols.end(), m_strSelected_0);
        if (it_0 != m_vecSymbols.end()) {
            idx_0 = std::distance(m_vecSymbols.begin(), it_0);
        }

        int idx_1 = 0;
        auto it_1 = std::find(m_vecSymbols.begin(), m_vecSymbols.end(), m_strSelected_1);
        if (it_1 != m_vecSymbols.end()) {
            idx_1 = std::distance(m_vecSymbols.begin(), it_1);
        }
        
        oss << " F"
            << static_cast<int>(idx_0) << ":"
            << static_cast<int>(idx_1) << ":"
            << static_cast<int>(m_nFreeModeTotalSpin) << ":"
            << static_cast<int>(m_nFreeModeGoneSpin) << ":"
            << static_cast<int>(m_nFreeModeTotalBonus.coin) << ":"
            << static_cast<int>(m_nFreeModeTotalBonus.ag)
            << " ";
    }
    m_strCheckPoint = oss.str();
}