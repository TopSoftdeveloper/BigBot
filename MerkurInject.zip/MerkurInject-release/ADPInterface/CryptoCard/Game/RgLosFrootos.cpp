#include "stdafx.h"
#include "RgLosFrootos.h"
#define RgLosFrootos_top "lofrHV1"
RgLosFrootos::RgLosFrootos() {
    m_bMultiGo = FALSE;
    m_nMultiGoBetStep = 0;
    m_nMultiGoTotalCount = 0;
    m_nMultiGoGone = 0;
    m_nMultiLoop = 0;

    m_strGameName = "RgLosFrootos";

    m_vPSPlans.push_back(0);
    m_vPSPlans.push_back(0);
    m_vPSPlans.push_back(0);
    m_vPSPlans.push_back(0);

    m_nReel = 5;
    m_nWinLine = 10;
    m_nMaxMatch = 5;
    m_nBetStep = 0;

    myVector<UINT16> m_vecBetSteps_tmp;
    m_vecBetSteps_tmp.push_back(10);
    m_vecBetSteps_tmp.push_back(20);
    m_vecBetSteps_tmp.push_back(30);
    m_vecBetSteps_tmp.push_back(40);
    m_vecBetSteps_tmp.push_back(50);
    m_vecBetSteps_tmp.push_back(60);
    m_vecBetSteps_tmp.push_back(80);
    m_vecBetSteps_tmp.push_back(100);
    m_vecBetSteps_tmp.push_back(150);
    m_vecBetSteps_tmp.push_back(200);
#ifdef BIGBET_ACTIVE
    m_vecBetSteps_tmp.push_back(500);
    m_vecBetSteps_tmp.push_back(1000);
#endif
    LoadBets();

    m_vecSymbols.push_back("lofrHV1");
    m_vecSymbols.push_back("lofrHV2");
    m_vecSymbols.push_back("lofrHV3");
    m_vecSymbols.push_back("lofrHV4");
    m_vecSymbols.push_back("lofrHV5");
    m_vecSymbols.push_back("lofrHV6");
    m_vecSymbols.push_back("lofrHV7");

    m_mapSymbolMinMatch["lofrHV1"] = 3;
    m_mapSymbolMinMatch["lofrHV2"] = 3;
    m_mapSymbolMinMatch["lofrHV3"] = 3;
    m_mapSymbolMinMatch["lofrHV4"] = 3;
    m_mapSymbolMinMatch["lofrHV5"] = 3;
    m_mapSymbolMinMatch["lofrHV6"] = 3;
    m_mapSymbolMinMatch["lofrHV7"] = 3;

    m_mapSymbolMeterGoc["lofrHV1"] = "lofrHV1_$x";
    m_mapSymbolMeterGoc["lofrHV2"] = "lofrHV2_$x";
    m_mapSymbolMeterGoc["lofrHV3"] = "lofrHV3_$x";
    m_mapSymbolMeterGoc["lofrHV4"] = "lofrHV4_$x";
    m_mapSymbolMeterGoc["lofrHV5"] = "lofrH56_$x";
    m_mapSymbolMeterGoc["lofrHV6"] = "lofrH56_$x";
    m_mapSymbolMeterGoc["lofrHV7"] = "lofrHV7_$x";

    m_vecWinLines.push_back("lofrWinline01");
    m_vecWinLines.push_back("lofrWinline02");
    m_vecWinLines.push_back("lofrWinline03");
    m_vecWinLines.push_back("lofrWinline04");
    m_vecWinLines.push_back("lofrWinline05");
    m_vecWinLines.push_back("lofrWinline06");
    m_vecWinLines.push_back("lofrWinline07");
    m_vecWinLines.push_back("lofrWinline08");
    m_vecWinLines.push_back("lofrWinline09");
    m_vecWinLines.push_back("lofrWinline10");

    m_vecLineSounds.push_back(SMP_LOFR_MW_1);
    m_vecLineSounds.push_back(SMP_LOFR_MW_2);
    m_vecLineSounds.push_back(SMP_LOFR_MW_3);
    m_vecLineSounds.push_back(SMP_LOFR_MW_4);
    m_vecLineSounds.push_back(SMP_LOFR_MW_5);
    m_vecLineSounds.push_back(SMP_LOFR_MW_6);
    m_vecLineSounds.push_back(SMP_LOFR_MW_7);
    m_vecLineSounds.push_back(SMP_LOFR_MW_8);
    m_vecLineSounds.push_back(SMP_LOFR_MW_9);
    m_vecLineSounds.push_back(SMP_LOFR_MW_10);

    m_vecWinSounds.push_back(SMP_LOFR_Win_1);
    m_vecWinSounds.push_back(SMP_LOFR_Win_2);
    m_vecWinSounds.push_back(SMP_LOFR_Win_3);
    m_vecWinSounds.push_back(SMP_LOFR_Win_4);
    m_vecWinSounds.push_back(SMP_LOFR_Win_5);
    m_vecWinSounds.push_back(SMP_LOFR_Win_6);
    m_vecWinSounds.push_back(SMP_LOFR_Win_7);
    m_vecWinSounds.push_back(SMP_LOFR_Win_8);
    m_vecWinSounds.push_back(SMP_LOFR_Win_9);

    m_vecReelStripPlan.push_back("0");
    m_vecReelStripPlan.push_back("1");
    m_vecReelStripPlan.push_back("2");
    m_vecReelStripPlan.push_back("3");
    
    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));

    char* lofrReelStrip[] = {
        "lofrHV1,lofrHV4,lofrHV4,lofrHV4,lofrHV3,lofrHV1,lofrHV3,lofrHV3,lofrHV6,lofrHV6,lofrHV7,lofrHV7,lofrHV7,lofrHV4,lofrHV1,lofrHV6,lofrHV6,lofrHV6,lofrHV2,lofrHV5,lofrHV2,lofrHV5,lofrHV5,lofrHV5,lofrHV5,lofrHV4",
        "lofrHV1,lofrHV4,lofrHV7,lofrHV7,lofrHV7,lofrHV3,lofrHV1,lofrHV3,lofrHV3,lofrHV6,lofrHV6,lofrHV7,lofrHV7,lofrHV7,lofrHV5,lofrHV5,lofrHV5,lofrHV7,lofrHV7,lofrHV2,lofrHV5,lofrHV2,lofrHV5,lofrHV5,lofrHV5,lofrHV5,lofrHV4",
        "lofrHV1,lofrHV4,lofrHV4,lofrHV4,lofrHV3,lofrHV1,lofrHV3,lofrHV3,lofrHV6,lofrHV6,lofrHV4,lofrHV4,lofrHV4,lofrHV4,lofrHV6,lofrHV6,lofrHV6,lofrHV7,lofrHV7,lofrHV2,lofrHV5,lofrHV2,lofrHV5,lofrHV6,lofrHV6,lofrHV6,lofrHV4",
        "lofrHV4,lofrHV4,lofrHV4,lofrHV3,lofrHV2,lofrHV6,lofrHV6,lofrHV6,lofrHV1,lofrHV5,lofrHV5,lofrHV5,lofrHV2,lofrHV7,lofrHV7,lofrHV7,lofrHV1",

        "lofrHV1,lofrHV5,lofrHV5,lofrHV5,lofrHV2,lofrHV2,lofrHV1,lofrHV2,lofrHV7,lofrHV7,lofrHV7,lofrHV1,lofrHV4,lofrHV4,lofrHV4,lofrHV6,lofrHV6,lofrHV4,lofrHV4,lofrHV3,lofrHV6,lofrHV6,lofrHV6,lofrHV5,lofrHV3,lofrHV3,lofrHV5",
        "lofrHV1,lofrHV4,lofrHV4,lofrHV4,lofrHV2,lofrHV2,lofrHV1,lofrHV2,lofrHV6,lofrHV6,lofrHV4,lofrHV4,lofrHV4,lofrHV5,lofrHV6,lofrHV6,lofrHV6,lofrHV4,lofrHV4,lofrHV6,lofrHV6,lofrHV6,lofrHV3,lofrHV6,lofrHV7,lofrHV3,lofrHV3,lofrHV5",
        "lofrHV1,lofrHV5,lofrHV5,lofrHV5,lofrHV2,lofrHV2,lofrHV1,lofrHV2,lofrHV7,lofrHV7,lofrHV7,lofrHV7,lofrHV5,lofrHV5,lofrHV5,lofrHV5,lofrHV7,lofrHV4,lofrHV4,lofrHV7,lofrHV7,lofrHV7,lofrHV3,lofrHV7,lofrHV6,lofrHV3,lofrHV3,lofrHV5",
        "lofrHV4,lofrHV4,lofrHV4,lofrHV3,lofrHV2,lofrHV6,lofrHV6,lofrHV6,lofrHV1,lofrHV5,lofrHV5,lofrHV5,lofrHV2,lofrHV7,lofrHV7,lofrHV7,lofrHV1",

        "lofrHV1,lofrHV6,lofrHV7,lofrHV7,lofrHV7,lofrHV1,lofrHV5,lofrHV5,lofrHV5,lofrHV1,lofrHV5,lofrHV2,lofrHV2,lofrHV6,lofrHV2,lofrHV6,lofrHV6,lofrHV6,lofrHV3,lofrHV3,lofrHV4,lofrHV3,lofrHV4,lofrHV4,lofrHV4",
        "lofrHV1,lofrHV6,lofrHV6,lofrHV7,lofrHV7,lofrHV7,lofrHV5,lofrHV5,lofrHV5,lofrHV1,lofrHV5,lofrHV2,lofrHV2,lofrHV7,lofrHV2,lofrHV7,lofrHV7,lofrHV7,lofrHV3,lofrHV3,lofrHV4,lofrHV3,lofrHV5,lofrHV5,lofrHV5",
        "lofrHV1,lofrHV6,lofrHV6,lofrHV6,lofrHV7,lofrHV7,lofrHV4,lofrHV4,lofrHV4,lofrHV1,lofrHV5,lofrHV2,lofrHV2,lofrHV6,lofrHV2,lofrHV6,lofrHV6,lofrHV6,lofrHV3,lofrHV3,lofrHV4,lofrHV3,lofrHV4,lofrHV4,lofrHV4",
        "lofrHV4,lofrHV4,lofrHV4,lofrHV3,lofrHV2,lofrHV6,lofrHV6,lofrHV6,lofrHV1,lofrHV5,lofrHV5,lofrHV5,lofrHV2,lofrHV7,lofrHV7,lofrHV7,lofrHV1",

        "lofrHV1,lofrHV4,lofrHV4,lofrHV4,lofrHV7,lofrHV1,lofrHV4,lofrHV5,lofrHV5,lofrHV5,lofrHV3,lofrHV3,lofrHV7,lofrHV7,lofrHV7,lofrHV6,lofrHV4,lofrHV1,lofrHV6,lofrHV6,lofrHV6,lofrHV5,lofrHV5,lofrHV2,lofrHV2,lofrHV6",
        "lofrHV1,lofrHV4,lofrHV4,lofrHV4,lofrHV4,lofrHV1,lofrHV4,lofrHV5,lofrHV5,lofrHV5,lofrHV3,lofrHV3,lofrHV7,lofrHV7,lofrHV7,lofrHV6,lofrHV7,lofrHV6,lofrHV6,lofrHV6,lofrHV5,lofrHV5,lofrHV2,lofrHV2,lofrHV6",
        "lofrHV1,lofrHV4,lofrHV4,lofrHV4,lofrHV4,lofrHV1,lofrHV4,lofrHV5,lofrHV5,lofrHV5,lofrHV3,lofrHV3,lofrHV7,lofrHV7,lofrHV7,lofrHV6,lofrHV7,lofrHV6,lofrHV6,lofrHV6,lofrHV5,lofrHV5,lofrHV2,lofrHV2,lofrHV6",
        "lofrHV4,lofrHV4,lofrHV4,lofrHV3,lofrHV2,lofrHV6,lofrHV6,lofrHV6,lofrHV1,lofrHV5,lofrHV5,lofrHV5,lofrHV2,lofrHV7,lofrHV7,lofrHV7,lofrHV1",

        "lofrHV1,lofrHV4,lofrHV4,lofrHV6,lofrHV6,lofrHV6,lofrHV1,lofrHV7,lofrHV7,lofrHV2,lofrHV2,lofrHV5,lofrHV5,lofrHV5,lofrHV3,lofrHV3,lofrHV4,lofrHV4,lofrHV4,lofrHV6,lofrHV6,lofrHV1,lofrHV7,lofrHV7,lofrHV7,lofrHV5,lofrHV5",
        "lofrHV1,lofrHV4,lofrHV4,lofrHV6,lofrHV6,lofrHV6,lofrHV7,lofrHV7,lofrHV2,lofrHV2,lofrHV5,lofrHV5,lofrHV5,lofrHV3,lofrHV3,lofrHV4,lofrHV4,lofrHV4,lofrHV6,lofrHV6,lofrHV1,lofrHV7,lofrHV7,lofrHV7,lofrHV5,lofrHV5",
        "lofrHV1,lofrHV4,lofrHV4,lofrHV6,lofrHV6,lofrHV6,lofrHV7,lofrHV7,lofrHV2,lofrHV2,lofrHV5,lofrHV5,lofrHV5,lofrHV3,lofrHV3,lofrHV4,lofrHV4,lofrHV4,lofrHV6,lofrHV6,lofrHV1,lofrHV7,lofrHV7,lofrHV7,lofrHV5,lofrHV5",
        "lofrHV4,lofrHV4,lofrHV4,lofrHV3,lofrHV2,lofrHV6,lofrHV6,lofrHV6,lofrHV1,lofrHV5,lofrHV5,lofrHV5,lofrHV2,lofrHV7,lofrHV7,lofrHV7,lofrHV1",

    };

    for (int i = 0; i < m_vecReelStripPlan.size(); i++) {
        ReelSet set;
        for (int j = 0; j < m_nReel; j++) {
            ReelStrip strip;
            std::stringstream ss(lofrReelStrip[j * m_vecReelStripPlan.size() + i]);
            std::string item;
            while (std::getline(ss, item, ',')) {
                strip.push_back(item);
            }
            set.push_back(strip);
        }
        m_vecReelStripSets.push_back(set);
    }

    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_tmp;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        std::map<std::string, std::map<UINT8, BONUS>> perSym;
        std::map<UINT8, BONUS> e;
        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 30; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 150; e[5].ag = 0;
        perSym["lofrHV7"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 200; e[5].ag = 0;
        perSym["lofrHV6"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 200; e[5].ag = 0;
        perSym["lofrHV5"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 200; e[5].ag = 0;
        perSym["lofrHV4"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 200; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 500; e[5].ag = 0;
        perSym["lofrHV3"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 75; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 500; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 1500; e[5].ag = 0;
        perSym["lofrHV2"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 1000; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5000; e[5].ag = 0;
        perSym["lofrHV1"] = e;
        e.clear();

        m_Bonus_tmp[i] = perSym;
    }

    int nSavedBetVal = 10;
    int _line = 0;
    string data;
    PlayDB::GetInstance().LoadCheckPoint(m_strGameName, nSavedBetVal, _line, m_strCheckPoint);
    if (nSavedBetVal == -1) {
        nSavedBetVal = 10;
    }

    BOOL start = FALSE;
    int idx = 0;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_tmp, i) < AT(m_vecBetSteps, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps, idx) == nSavedBetVal) {
            m_nBetStep = idx;
        }

        m_Bonus[idx++] = m_Bonus_tmp[i];
        if (AT(m_vecBetSteps_tmp, i) == AT(m_vecBetSteps, m_vecBetSteps.size() - 1)) {
            break;
        }
    }

    m_vecBetSteps_05.clear();
    m_vecBetSteps_10.clear();

    PrintAllBonus();
}

UINT16 RgLosFrootos::Run() {
    m_nCurrentReelPlan = (myRandom() % m_vecReelStripPlan.size());
    m_shCurrentReelStrip = static_cast<uint16_t>(std::stoi(AT(m_vecReelStripPlan, m_nCurrentReelPlan)));
    return m_shCurrentReelStrip;
}

myVector<UINT8> RgLosFrootos::Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) {
    if (m_bMultiGo) {
        if (bTest == FALSE) {
            if (mmcode_get_active_status()) {
                mmcode_set_deactive();
            }
        }

        myVector<WinMeter> metersPS1;
        UINT64 normalMeterPS1;
        UINT64 maxMeterPS1;
        SoundItem bonusSoundItemPS;
        myVector<UINT8> resultPS1;
        normalMeterPS1 = 0;
        maxMeterPS1 = 0;
        bonusSoundItemPS = { 0, "", 0 };
        metersPS1.clear();
        if (_result.size()) {
            resultPS1.insert(resultPS1.end(), _result.begin() + 0, _result.begin() + 0 + 5);
        }
        BOOL _ = FALSE;
        resultPS1 = m_PS1.Win(metersPS1, normalMeterPS1, maxMeterPS1, bonusSoundItemPS, bTest, resultPS1, _);

        myVector<WinMeter> metersPS2;
        UINT64 normalMeterPS2;
        UINT64 maxMeterPS2;
        myVector<UINT8> resultPS2;
        normalMeterPS2 = 0;
        maxMeterPS2 = 0;
        metersPS2.clear();
        if (_result.size()) {
            resultPS2.insert(resultPS2.end(), _result.begin() + 0 + 5, _result.begin() + 0 + 10);
        }
        resultPS2 = m_PS2.Win(metersPS2, normalMeterPS2, maxMeterPS2, bonusSoundItemPS, bTest, resultPS2, _);

        myVector<WinMeter> metersPS3;
        UINT64 normalMeterPS3;
        UINT64 maxMeterPS3;
        myVector<UINT8> resultPS3;
        normalMeterPS3 = 0;
        maxMeterPS3 = 0;
        metersPS3.clear();
        if (_result.size()) {
            resultPS3.insert(resultPS3.end(), _result.begin() + 0 + 10, _result.begin() + 0 + 15);
        }
        resultPS3 = m_PS3.Win(metersPS3, normalMeterPS3, maxMeterPS3, bonusSoundItemPS, bTest, resultPS3, _);

        myVector<WinMeter> metersPS4;
        UINT64 normalMeterPS4;
        UINT64 maxMeterPS4;
        myVector<UINT8> resultPS4;
        normalMeterPS4 = 0;
        maxMeterPS4 = 0;
        metersPS4.clear();
        if (_result.size()) {
            resultPS4.insert(resultPS4.end(), _result.begin() + 0 + 15, _result.begin() + 0 + 20);
        }
        resultPS4 = m_PS4.Win(metersPS4, normalMeterPS4, maxMeterPS4, bonusSoundItemPS, bTest, resultPS4, _);

        _result.clear();
        _result.insert(_result.end(), resultPS1.begin(), resultPS1.end());
        _result.insert(_result.end(), resultPS2.begin(), resultPS2.end());
        _result.insert(_result.end(), resultPS3.begin(), resultPS3.end());
        _result.insert(_result.end(), resultPS4.begin(), resultPS4.end());

        normalMeter = 0;
        normalMeter = (normalMeterPS1 << 0) | (normalMeterPS2 << 16) | (normalMeterPS3 << 32) | (normalMeterPS4 << 48);

        maxMeter = 0;
        maxMeter = (maxMeterPS1 << 0) | (maxMeterPS2 << 16) | (maxMeterPS3 << 32) | (maxMeterPS4 << 48);

        meters.clear();
        meters.insert(meters.end(), metersPS1.begin(), metersPS1.end());
        meters.insert(meters.end(), metersPS2.begin(), metersPS2.end());
        meters.insert(meters.end(), metersPS3.begin(), metersPS3.end());
        meters.insert(meters.end(), metersPS4.begin(), metersPS4.end());

        if (bTest == FALSE) {
            UINT16 totalErfolg = 0;
            for (int i = 0; i < meters.size(); i++) {
                totalErfolg += AT(meters, i).bonus.coin;
            }
            if (totalErfolg > 0) {
                BonusSound = getSoundByID(WinSound(totalErfolg));
            }
            else {
                BonusSound.duration = 0;
                BonusSound.soundID = MAX_SOUND_IDS;
            }
            
            UINT16 trans1 = m_PS1.GetTransSymbolGOC();
            _result.push_back(trans1 & 0xFF);
            _result.push_back((trans1 >> 8) & 0xFF);
            _result.push_back(!trans1);

            UINT16 trans2 = m_PS2.GetTransSymbolGOC();
            _result.push_back(trans2 & 0xFF);
            _result.push_back((trans2 >> 8) & 0xFF);
            _result.push_back(!trans2);

            UINT16 trans3 = m_PS3.GetTransSymbolGOC();
            _result.push_back(trans3 & 0xFF);
            _result.push_back((trans3 >> 8) & 0xFF);
            _result.push_back(!trans3);

            UINT16 trans4 = m_PS4.GetTransSymbolGOC();
            _result.push_back(trans4 & 0xFF);
            _result.push_back((trans4 >> 8) & 0xFF);
            _result.push_back(!trans4);
        }
        return _result;
    }
    else {
        m_bPrevSpinMatchedActive = FALSE;

        myVector<UINT8> result;
        ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);

        BOOL mmcode = FALSE;
        if (bTest == FALSE) {
            mmcode = mmcode_get_active_status();
        }
        if (bTest == TRUE || mmcode == TRUE) {
            std::string matchSymbol = AT(m_vecSymbols, myRandom() % m_vecSymbols.size());
            int line = (myRandom() % m_nWinLine);
            int weight = 1 + (myRandom() % 5);

            if (mmcode) {
                mmcode_set_deactive();
                weight = m_nMaxMatch;
                matchSymbol = RgLosFrootos_top;
            }
            for (int i = 0; i < m_nReel; i++) {
                ReelStrip reelStrip = AT(reelSet, i);
                int len = reelStrip.size() - 3;

                int valid_i[0x100];
                int valid_count = 0;
                for (int j = 0; j <= len; j++) {
                    if (weight > i) {
                        if (matchSymbol == AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                            valid_i[valid_count++] = j;
                        }
                    }
                    else {
                        if (matchSymbol != AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                            valid_i[valid_count++] = j;
                        }
                    }
                }
                if (valid_count > 0) {
                    int rand_index = myRandom() % valid_count;
                    int chosen_i = valid_i[rand_index];
                    result.push_back(chosen_i + 1);
                }
                else {
                    result.push_back((myRandom() % (len - 1)) + 1);
                }
            }
        }
        else {
            result = _result;
        }
        m_vWinResult = result;

        normalMeter = 0;
        maxMeter = 0;
        UINT16 totalBonus = 0;
        for (int i = 0; i < m_nWinLine; i++) {
            int j = 1;
            UINT16 meter = ((UINT16)1 << (2 - g_match_lines_10_5[i][0]));

            for (; j < m_nMaxMatch; j++) {
                if (AT(AT(reelSet, j - 1), AT(result, j - 1) - 1 + g_match_lines_10_5[i][j - 1]) == AT(AT(reelSet, j), AT(result, j) - 1 + g_match_lines_10_5[i][j])) {

                    meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
                    continue;
                }
                break;
            }
            std::string firstSymbol = AT(AT(reelSet, 0), AT(result, 0) - 1 + g_match_lines_10_5[i][0]);
            if (j < m_mapSymbolMinMatch[firstSymbol]) {
                continue;
            }

            // monitor 2 meter
            std::string meterStr = m_mapSymbolMeterGoc[firstSymbol];
            size_t pos = meterStr.find('$');
            if (pos != std::string::npos) {
                meterStr = meterStr.replace(pos, 1, std::to_string(j));
            }

            WinMeter e;
            e.line = i;
            e.meter = meter;
            e.meter2 = g_GrafficObjList.Str2GOCID(meterStr);
            e.symbol = firstSymbol;
            e.weight = j;
            e.start = 0;
            e.bonus = m_Bonus[BetStep()][firstSymbol][j];
            e.sound = MAX_SOUND_IDS;

            totalBonus += e.bonus.coin;

            if (e.meter2 != -1) {
                meters.push_back(e);
            }
            if (j == m_nMaxMatch) {
                maxMeter |= meter;
            }
            else {
                normalMeter |= meter;
            }
            if (bTest == FALSE) {
                m_bPrevSpinMatchedActive = TRUE;
            }
        }
        m_vWinMeters = meters;
        if (bTest == FALSE) {
            updateCheckPoint();
            if (totalBonus > 0) {
                BonusSound = getSoundByID(WinSound(totalBonus));
            }
            else {
                BonusSound.duration = 0;
                BonusSound.soundID = MAX_SOUND_IDS;
            }
        }
        return result;
    }
}

UINT16 RgLosFrootos::GetTotalBonus() {
    UINT16 totalErfolg = 0;
    for (int i = 0; i < m_vWinMeters.size(); i++) {
        totalErfolg += AT(m_vWinMeters, i).bonus.coin;
    }
    return totalErfolg;
}

BOOL RgLosFrootos::CanMultiGo() {
    if (m_bMultiGo) {
        return FALSE;
    }
    auto totalErfolg = GetTotalBonus();
    UINT16 betErfolg = AT(Bets(), BetStep());
    return (totalErfolg >= 4 * betErfolg);
}

myVector<InterruptPacketData> RgLosFrootos::EnterMultiGo(UINT32 &bonusErfolg, BOOL bIitMultiBet) {
    auto totalErfolg = bonusErfolg;
    auto bets = Bets();

    m_bMultiGo = TRUE;
    if (bIitMultiBet) {
        m_nMultiGoBetStep = BetStep();
    }
    m_nMultiGoGone = 0;
    UINT16 erfolgLevel = 4 * AT(bets, m_nMultiGoBetStep);
    m_nMultiGoTotalCount = totalErfolg / erfolgLevel;

    myVector<InterruptPacketData> packets;
    packets.push_back({
        0,
        0,
        { 0x01, 0x02, 0x31, 0x00, 0x0D, 0x00, 0x6D, 0x0B, 0xAE,
        static_cast<BYTE>(totalErfolg & 0xFF), static_cast<BYTE>((totalErfolg >> 8) & 0xFF),
        0x00, 0x00,
        m_nMultiGoTotalCount,
        static_cast<BYTE>(erfolgLevel & 0xFF), static_cast<BYTE>((erfolgLevel >> 8) & 0xFF),
        0x00, 0x00, 0x00, 0x00, 0x01, 0x01, 0x04} });
    bonusErfolg -= erfolgLevel * m_nMultiGoTotalCount;

    AT(m_vPSPlans, 0) = m_PS1.Init(m_nMultiGoBetStep);
    AT(m_vPSPlans, 1) = m_PS2.Init(m_nMultiGoBetStep);
    AT(m_vPSPlans, 2) = m_PS3.Init(m_nMultiGoBetStep);
    AT(m_vPSPlans, 3) = m_PS4.Init(m_nMultiGoBetStep);
    return packets;
}

myVector<InterruptPacketData> RgLosFrootos::CloseMultiGo(UINT32& bonusErfolg, BOOL force) {
    auto bets = Bets();
    UINT16 erfolgLevel = 4 * AT(bets, m_nMultiGoBetStep);
    if (force) {
        bonusErfolg += erfolgLevel * m_nMultiGoTotalCount;
    }

    m_bMultiGo = FALSE;
    m_nMultiLoop = 0;
    myVector<InterruptPacketData> packets;
    packets.push_back({
        0,
        0,
        {0x01, 0x02, 0x31, 0x00, 0x0d, 0x00, 0x6d, 0x0b, 0xae,
        static_cast<BYTE>(bonusErfolg & 0xFF), static_cast<BYTE>((bonusErfolg >> 8) & 0xFF),
        0x00, 0x00,
        m_nMultiGoTotalCount,
        static_cast<BYTE>(erfolgLevel & 0xFF), static_cast<BYTE>((erfolgLevel >> 8) & 0xFF),
        0x00, 0x00, 0x01, 0x00, 0x01, 0x01, 0x04} });
    // return to orign bet
    UINT16 betval = AT(bets, BetStep()) / 5;
    packets.push_back({
        0,
        0,
        {0x01, 0x02, 0x28, 0x00,
        static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF),
        0x03, 0x00, static_cast<BYTE>(betval & 0xFF), static_cast<BYTE>((betval >> 8) & 0xFF),  0x04} });
    return packets;
}

myVector<InterruptPacketData> RgLosFrootos::BetUpMultiGo(UINT32& bonusErfolg) {
    myVector<InterruptPacketData> packets;
    auto bets = Bets();
    if (m_nMultiGoBetStep >= (bets.size() - 1)) {
        return packets;
    }
    UINT16 erfolgLevel = 4 * AT(bets, m_nMultiGoBetStep);
    // total bonus erfolg
    auto totalErfolg = bonusErfolg + erfolgLevel * m_nMultiGoTotalCount;
    if (totalErfolg < 4 * AT(bets, m_nMultiGoBetStep + 1)) {
        return packets;
    }
    m_nMultiGoBetStep++;
    erfolgLevel = 4 * AT(bets, m_nMultiGoBetStep);
    m_nMultiGoTotalCount = totalErfolg / erfolgLevel;
    bonusErfolg = totalErfolg - m_nMultiGoTotalCount * erfolgLevel;
    packets.push_back({
        0,
        0,
        {0x01, 0x02, 0x31, 0x00, 0x0d, 0x00, 0x6d, 0x0b, 0xae,
        static_cast<BYTE>(totalErfolg & 0xFF), static_cast<BYTE>((totalErfolg >> 8) & 0xFF),
        0x00, 0x00,
        m_nMultiGoTotalCount,
        static_cast<BYTE>(erfolgLevel & 0xFF), static_cast<BYTE>((erfolgLevel >> 8) & 0xFF),
        0x00, 0x00, 0x00, 0x00, 0x01, 0x01, 0x04} });
    // update bet on only 2nd display
    UINT16 betval = AT(bets, m_nMultiGoBetStep) / 5;
    packets.push_back({
        0,
        0,
        {0x01, 0x02, 0x28, 0x00, 
        static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF),
        0x03, 0x00, static_cast<BYTE>(betval & 0xFF), static_cast<BYTE>((betval >> 8) & 0xFF), 
         0x04} });

    AT(m_vPSPlans, 0) = m_PS1.Init(m_nMultiGoBetStep);
    AT(m_vPSPlans, 1) = m_PS2.Init(m_nMultiGoBetStep);
    AT(m_vPSPlans, 2) = m_PS3.Init(m_nMultiGoBetStep);
    AT(m_vPSPlans, 3) = m_PS4.Init(m_nMultiGoBetStep);
    return packets;
}

myVector<InterruptPacketData> RgLosFrootos::BetDownMultiGo(UINT32& bonusErfolg) {
    myVector<InterruptPacketData> packets;
    auto bets = Bets();
    if (m_nMultiGoBetStep == 0) {
        return packets;
    }
    UINT16 erfolgLevel = 4 * AT(bets, m_nMultiGoBetStep);
    // total bonus erfolg
    auto totalErfolg = bonusErfolg + erfolgLevel * m_nMultiGoTotalCount;
    m_nMultiGoBetStep--;
    erfolgLevel = 4 * AT(bets, m_nMultiGoBetStep);
    m_nMultiGoTotalCount = totalErfolg / erfolgLevel;
    bonusErfolg = totalErfolg - m_nMultiGoTotalCount * erfolgLevel;
    packets.push_back({
        0,
        0,
        {0x01, 0x02, 0x31, 0x00, 0x0d, 0x00, 0x6d, 0x0b, 0xae,
        static_cast<BYTE>(totalErfolg & 0xFF), static_cast<BYTE>((totalErfolg >> 8) & 0xFF),
        0x00, 0x00,
        m_nMultiGoTotalCount,
        static_cast<BYTE>(erfolgLevel & 0xFF), static_cast<BYTE>((erfolgLevel >> 8) & 0xFF),
        0x00, 0x00, 0x00, 0x00, 0x01, 0x01, 0x04} });
    // update bet on only 2nd display
    UINT16 betval = AT(bets, m_nMultiGoBetStep) / 5;
    packets.push_back({
        0,
        0,
        {0x01, 0x02, 0x28, 0x00,
        static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF),
        0x03, 0x00, static_cast<BYTE>(betval & 0xFF), static_cast<BYTE>((betval >> 8) & 0xFF),  0x04} });

    AT(m_vPSPlans, 0) = m_PS1.Init(m_nMultiGoBetStep);
    AT(m_vPSPlans, 1) = m_PS2.Init(m_nMultiGoBetStep);
    AT(m_vPSPlans, 2) = m_PS3.Init(m_nMultiGoBetStep);
    AT(m_vPSPlans, 3) = m_PS4.Init(m_nMultiGoBetStep);
    return packets;
}

myVector<UINT16> RgLosFrootos::CurrentReelStrip() {
    myVector<UINT16> ret;
    if (m_bMultiGo) {
        ret.push_back(GOC_RgLosFrootosPS1);
        ret.push_back(AT(m_vPSPlans, 0));
        ret.push_back(GOC_RgLosFrootosPS2);
        ret.push_back(AT(m_vPSPlans, 1));
        ret.push_back(GOC_RgLosFrootosPS3);
        ret.push_back(AT(m_vPSPlans, 2));
        ret.push_back(GOC_RgLosFrootosPS4);
        ret.push_back(AT(m_vPSPlans, 3));
    }
    else {
        ret.push_back(m_shCurrentReelStrip);
    }
    return ret;
}

void RgLosFrootos::MultiGoGoneAndRemain(UINT8& gone, UINT8& total, UINT8& loop) {
    gone = m_nMultiGoGone;
    total = m_nMultiGoTotalCount;
    loop = m_nMultiLoop;
}

myVector<InterruptPacketData> RgLosFrootos::InterruptBeforeSpin() {
    myVector<InterruptPacketData> packets;    
    if (m_bMultiGo) {
        m_nMultiGoGone++;
        UINT8 remain = m_nMultiGoTotalCount - m_nMultiGoGone;
        // dec remain spin numbers
        packets.push_back({ 0, 0,{0x01, 0x02, 0x30, 0x00, 0x68, 0x0b, remain, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa5, 0x04} });
    }
    return packets;
}


UINT16 RgLosFrootos::MiltiGoBet() {
    auto bets = Bets();
    return AT(bets, m_nMultiGoBetStep);
}

int RgLosFrootos::LineSwapDelay(int WinIdx) {
    return 500;
}

myVector<UINT8> RgLosFrootos::ShowTotalWinLines(myVector<WinMeter> SpinMeters) {
    if (m_bMultiGo) {
        myVector<UINT8> empty;
        return empty;
    }
    myVector<uint8_t> packet = {
        0x06, 0x30, 0x59, 0x01, 0x02, 0x31, 0x00,
        0x0F, 0x00,  // Placeholder for length 
        0x0F, 0x11, // GameID
        0x9C, 0x19, 0x01
    };
    myVector<UINT8> TotalMatch;
    for (int i = 0; i < SpinMeters.size(); i++) {
        if (AT(SpinMeters, i).line == 0xFF) { // clear after convert action
            TotalMatch.clear();
            continue;
        }
        TotalMatch.push_back(AT(SpinMeters, i).line);
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter >> 8) & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter2 & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter2 >> 8) & 0xFF));
    }
    if (TotalMatch.size() < 10) {
        myVector<UINT8> _;
        return _;
    }
    UINT16 pktLen = 1 + (TotalMatch.size() / 5) * 7;
    AT(packet, 7) = static_cast<BYTE>(pktLen & 0xFF);
    AT(packet, 8) = static_cast<BYTE>((pktLen >> 8) & 0xFF);
    AT(packet, 9) = static_cast<BYTE>(m_nGameID & 0xFF);
    AT(packet, 10) = static_cast<BYTE>((m_nGameID >> 8) & 0xFF);
    int entryCount = static_cast<int>(TotalMatch.size() / 5);
    for (int i = 0; i < entryCount; ++i) {
        packet.push_back(AT(TotalMatch, i * 5 + 0)); // Line
        packet.push_back(AT(TotalMatch, i * 5 + 1)); // Meter low byte
        packet.push_back(AT(TotalMatch, i * 5 + 2)); // Meter high byte
        packet.push_back(AT(TotalMatch, i * 5 + 3)); // Meter2 low byte
        packet.push_back(AT(TotalMatch, i * 5 + 4)); // Meter2 high byte
        packet.push_back(0x01);      // Status or flag 1
        packet.push_back(0x01);      // Status or flag 2
    }
    // Mark the end of the packet
    packet.back() = 0x04;
    return packet;
}

myVector<InterruptPacketData> RgLosFrootos::InterruptAfterSpin() {
    if (m_bMultiGo == FALSE) {
        myVector<InterruptPacketData> _;
        return _;
    }
    myVector<InterruptPacketData> intPacket1 = m_PS1.InterruptAfterSpin();
    myVector<InterruptPacketData> intPacket2 = m_PS2.InterruptAfterSpin();
    myVector<InterruptPacketData> intPacket3 = m_PS3.InterruptAfterSpin();
    myVector<InterruptPacketData> intPacket4 = m_PS4.InterruptAfterSpin();

    myVector<InterruptPacketData> merged;
    if (!intPacket1.empty()) {
        merged.insert(merged.end(), intPacket1.begin(), intPacket1.end());
    }
    if (!intPacket2.empty()) {
        merged.insert(merged.end(), intPacket2.begin(), intPacket2.end());
    }
    if (!intPacket3.empty()) {
        merged.insert(merged.end(), intPacket3.begin(), intPacket3.end());
    }
    if (!intPacket4.empty()) {
        merged.insert(merged.end(), intPacket4.begin(), intPacket4.end());
    }
    if (merged.size()) {
        AT(merged, merged.size() - 1).postDelay = 2000;
    }
    return merged;
}

UINT8 RgLosFrootos::MultiGoBetStep() {
    return m_nMultiGoBetStep;
}

void RgLosFrootos::SetMultiGoBetStep(UINT8 newStep) {
    m_nMultiGoBetStep = newStep;

    m_PS1.SetBetStep(newStep);
    m_PS2.SetBetStep(newStep);
    m_PS3.SetBetStep(newStep);
    m_PS4.SetBetStep(newStep);
}

BOOL RgLosFrootos::GetMultiGoEnable() {
    return m_bMultiGo;
}

void RgLosFrootos::SetMultiGoEnable(BOOL status) {
    m_bMultiGo = status;
}

void RgLosFrootos::ChangeReelStrip(UINT16 NewReelPlan) {
    m_nCurrentReelPlan = NewReelPlan;
    m_shCurrentReelStrip = static_cast<uint16_t>(std::stoi(AT(m_vecReelStripPlan, m_nCurrentReelPlan)));
}


void RgLosFrootos::GetMultiGoReelPlanIdx(int& p0, int& p1, int& p2, int& p3) {
    p0 = m_PS1.CurrentReelSetIdx();
    p1 = m_PS2.CurrentReelSetIdx();
    p2 = m_PS3.CurrentReelSetIdx();
    p3 = m_PS4.CurrentReelSetIdx();
}

void RgLosFrootos::SetMultiGoReelPlanIdx(int p0, int p1, int p2, int p3) {
    m_PS1.ChangeReelStrip(p0);
    m_PS2.ChangeReelStrip(p1);
    m_PS3.ChangeReelStrip(p2);
    m_PS4.ChangeReelStrip(p3);

    AT(m_vPSPlans, 0) = AT(m_PS1.CurrentReelStrip(), 0);
    AT(m_vPSPlans, 1) = AT(m_PS2.CurrentReelStrip(), 0);
    AT(m_vPSPlans, 2) = AT(m_PS3.CurrentReelStrip(), 0);
    AT(m_vPSPlans, 3) = AT(m_PS4.CurrentReelStrip(), 0);
}