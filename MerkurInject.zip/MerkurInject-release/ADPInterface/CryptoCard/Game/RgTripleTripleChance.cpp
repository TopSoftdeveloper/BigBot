#include "stdafx.h"
#include "RgTripleTripleChance.h"

RgTripleTripleChance::RgTripleTripleChance() {
    m_nReel = 3;
    m_nWinLine = 5;
    m_nMaxMatch = 3;
    m_nBetStep = 0;

    m_bFreeMode = FALSE;

    m_strGameName = "RgTripleTripleChance";

    myVector<UINT16> m_vecBetSteps_tmp;
    m_vecBetSteps_tmp.push_back(5);
    m_vecBetSteps_tmp.push_back(10);
    m_vecBetSteps_tmp.push_back(20);
    m_vecBetSteps_tmp.push_back(30);
    m_vecBetSteps_tmp.push_back(40);
    m_vecBetSteps_tmp.push_back(50);
    m_vecBetSteps_tmp.push_back(60);
    m_vecBetSteps_tmp.push_back(80);
    m_vecBetSteps_tmp.push_back(100);
    m_vecBetSteps_tmp.push_back(150);
    m_vecBetSteps_tmp.push_back(200);
#ifdef BIGBET_ACTIVE
    m_vecBetSteps_tmp.push_back(500);
    m_vecBetSteps_tmp.push_back(1000);
#endif
    LoadBets();

    m_vecSymbols.push_back("ttchSie");
    m_vecSymbols.push_back("ttchMel");
    m_vecSymbols.push_back("ttchGlo");
    m_vecSymbols.push_back("ttchPfl");
    m_vecSymbols.push_back("ttchOra");
    m_vecSymbols.push_back("ttchZit");
    m_vecSymbols.push_back("ttchKir");
    m_vecSymbols.push_back("ttchRau");

    m_mapSymbolMeterGoc["ttchSie"] = "ttchSieben3x";
    m_mapSymbolMeterGoc["ttchMel"] = "ttchMelone3x";
    m_mapSymbolMeterGoc["ttchGlo"] = "ttchGlocke3x";
    m_mapSymbolMeterGoc["ttchPfl"] = "ttchPflaume3x";
    m_mapSymbolMeterGoc["ttchOra"] = "ttchOrange3x";
    m_mapSymbolMeterGoc["ttchZit"] = "ttchZitrone3x";
    m_mapSymbolMeterGoc["ttchKir"] = "ttchKirsche3x";
    m_mapSymbolMeterGoc["ttchRau"] = "ttchRaute3x";

    m_vecWinLines.push_back("ttchWinline1");
    m_vecWinLines.push_back("ttchWinline2");
    m_vecWinLines.push_back("ttchWinline3");
    m_vecWinLines.push_back("ttchWinline4");
    m_vecWinLines.push_back("ttchWinline5");
    
    m_mapLineSounds["ttchSie"] = SMP_TTCH_MG_sound_max_win_tune_20;
    m_mapLineSounds["ttchMel"] = SMP_TTCH_MG_sound_gewinn_200;
    m_mapLineSounds["ttchGlo"] = SMP_TTCH_MG_sound_gewinn_80;
    m_mapLineSounds["ttchPfl"] = SMP_TTCH_MG_sound_gewinn_40;
    m_mapLineSounds["ttchOra"] = SMP_TTCH_MG_sound_gewinn_40;
    m_mapLineSounds["ttchZit"] = SMP_TTCH_MG_sound_gewinn_40;
    m_mapLineSounds["ttchKir"] = SMP_TTCH_MG_sound_gewinn_40;
    m_mapLineSounds["ttchRau"] = SMP_TTCH_sound_gewinn_5;

       
    m_vecReelStripPlan.push_back("ttchWalze1BG");
    
    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));

    char* ttchReelStrip[] = {
        "ttchSie,ttchKir,ttchKir,ttchKir,ttchKir,ttchMel,ttchRau,ttchZit,ttchZit,ttchZit,ttchZit,ttchRau,ttchPfl,ttchPfl,ttchPfl,ttchPfl,ttchRau,ttchMel,ttchOra,ttchOra,ttchOra,ttchOra,ttchRau,ttchGlo,ttchGlo,ttchKir,ttchKir,ttchKir,ttchKir,ttchMel,ttchRau,ttchZit,ttchZit,ttchZit,ttchZit,ttchRau,ttchPfl,ttchPfl,ttchPfl,ttchPfl,ttchRau,ttchGlo,ttchOra,ttchOra,ttchOra,ttchOra,ttchRau,ttchGlo,ttchGlo",
        "ttchMel,ttchKir,ttchKir,ttchKir,ttchZit,ttchSie,ttchRau,ttchZit,ttchZit,ttchZit,ttchRau,ttchPfl,ttchPfl,ttchPfl,ttchPfl,ttchRau,ttchMel,ttchOra,ttchOra,ttchOra,ttchOra,ttchRau,ttchGlo,ttchKir,ttchGlo,ttchKir,ttchKir,ttchKir,ttchZit,ttchSie,ttchRau,ttchZit,ttchZit,ttchZit,ttchPfl,ttchRau,ttchPfl,ttchPfl,ttchPfl,ttchRau,ttchMel,ttchOra,ttchRau,ttchOra,ttchOra,ttchOra,ttchGlo,ttchGlo,ttchKir",
        "ttchKir,ttchKir,ttchKir,ttchKir,ttchMel,ttchKir,ttchZit,ttchZit,ttchZit,ttchZit,ttchRau,ttchZit,ttchPfl,ttchRau,ttchSie,ttchPfl,ttchPfl,ttchPfl,ttchPfl,ttchRau,ttchOra,ttchOra,ttchOra,ttchOra,ttchMel,ttchGlo,ttchKir,ttchKir,ttchKir,ttchKir,ttchMel,ttchRau,ttchZit,ttchZit,ttchZit,ttchZit,ttchSie,ttchRau,ttchPfl,ttchPfl,ttchPfl,ttchRau,ttchMel,ttchOra,ttchOra,ttchOra,ttchOra,ttchRau,ttchGlo,ttchOra,ttchRau,ttchGlo,ttchZit,ttchRau,ttchPfl,ttchSie,ttchPfl,ttchGlo",
    };

    int idx = 0;
    for (int i = 0; i < m_vecReelStripPlan.size(); i++) {
        ReelSet set;
        for (int j = 0; j < m_nReel; j++) {
            ReelStrip strip;
            std::stringstream ss(ttchReelStrip[idx]);
            std::string item;
            while (std::getline(ss, item, ',')) {
                strip.push_back(item);
            }
            set.push_back(strip);
            idx++;
        }
        m_vecReelStripSets.push_back(set);
    }

    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_tmp;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        std::map<std::string, std::map<UINT8, BONUS>> perSym;
        std::map<UINT8, BONUS> e;
        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 40; e[3].ag = 0;
        perSym["ttchKir"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 40; e[3].ag = 0;
        perSym["ttchZit"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 40; e[3].ag = 0;
        perSym["ttchOra"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 40; e[3].ag = 0;
        perSym["ttchPfl"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 60; e[3].ag = 0;
        perSym["ttchGlo"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 200; e[3].ag = 0;
        perSym["ttchMel"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 750; e[3].ag = 0;
        perSym["ttchSie"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 0; e[3].ag = 0;
        perSym["ttchRau"] = e;
        e.clear();

        m_Bonus_tmp[i] = perSym;
    }

    int nSavedBetVal = 10;
    int _line = 0;
    string data;
    PlayDB::GetInstance().LoadCheckPoint(m_strGameName, nSavedBetVal, _line, m_strCheckPoint);
    if (nSavedBetVal == -1) {
        nSavedBetVal = 10;
    }

    BOOL start = FALSE;
    idx = 0;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_tmp, i) < AT(m_vecBetSteps, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps, idx) == nSavedBetVal) {
            m_nBetStep = idx;
        }

        m_Bonus[idx++] = m_Bonus_tmp[i];
        if (AT(m_vecBetSteps_tmp, i) == AT(m_vecBetSteps, m_vecBetSteps.size() - 1)) {
            break;
        }
    }

    m_vecBetSteps_05.clear();
    m_vecBetSteps_10.clear();
    PrintAllBonus();
}

UINT16 RgTripleTripleChance::WinSound(UINT32 totalBonus) {
    return MAX_SOUND_IDS;
}

myVector<UINT8> RgTripleTripleChance::Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) {
    myVector<UINT8> result;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);

    if (bTest) {
        std::string matchSymbol = AT(m_vecSymbols, myRandom() % m_vecSymbols.size());
        int line = (myRandom() % m_nWinLine);
        int weight = 1 + (myRandom() % 3);
        for (int i = 0; i < m_nReel; i++) {
            ReelStrip reelStrip = AT(reelSet, i);
            int len = reelStrip.size() - 3;

            int valid_i[0x100];
            int valid_count = 0;
            for (int j = 0; j <= len; j++) {
                if (weight > i) {
                    if (matchSymbol == AT(reelStrip, j + g_match_lines_5_3[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                else {
                    if (matchSymbol != AT(reelStrip, j + g_match_lines_5_3[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
            }
            if (valid_count > 0) {
                int rand_index = myRandom() % valid_count;
                int chosen_i = valid_i[rand_index];
                result.push_back(chosen_i + 1);
            }
            else {
                result.push_back((myRandom() % (len - 1)) + 1);
            }
        }
    }
    else {
        result = _result;

        BOOL mmcode = mmcode_get_active_status();
        if (mmcode) {
            mmcode_set_deactive();
            if (m_bFreeMode == FALSE) {
                AT(result, 0) = 13;
                AT(result, 1) = 12;
                AT(result, 2) = 16;
            }
        }
    }

    //TEST_REEL3_SYMBOLS(result, 8, 8, 8);
    m_vWinResult = result;

    normalMeter = 0;
    maxMeter = 0;
    UINT32 totalBonus = 0;
    for (int i = 0; i < m_nWinLine; i++) {
        int j = 1;
        UINT16 meter = ((UINT16)1 << (2 - g_match_lines_5_3[i][0]));

        for (; j < m_nMaxMatch; j++) {
            if (AT(AT(reelSet, j - 1), AT(result, j - 1) - 1 + g_match_lines_5_3[i][j - 1]) == AT(AT(reelSet, j), AT(result, j) - 1 + g_match_lines_5_3[i][j])) {

                meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_5_3[i][j]));
                continue;
            }
            break;
        }
        std::string firstSymbol = AT(AT(reelSet, 0), AT(result, 0) - 1 + g_match_lines_5_3[i][0]);
        if (j < m_nMaxMatch) {
            continue;
        }

        WinMeter e;
        e.line = i;
        e.meter = meter;
        e.meter2 = g_GrafficObjList.Str2GOCID(m_mapSymbolMeterGoc[firstSymbol]);
        e.symbol = firstSymbol;
        e.weight = j;
        e.start = 0;
        e.bonus = m_Bonus[BetStep()][firstSymbol][j];
        e.sound = MAX_SOUND_IDS;        

        totalBonus += e.bonus.coin;

        if (e.bonus.coin) {
            WinMeter ele;
            ele.line = 0xFF;
            ele.bonus = {0, 0};
            // show top
            ele.IntWinbonus.push_back({
                0,
                0,
                {0x01, 0x02, 0x2c, 0x00, 0xeb, 0x58, static_cast<BYTE>(totalBonus & 0xFF), static_cast<BYTE>((totalBonus >> 8) & 0xFF), 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04} });
            meters.push_back(ele);
        }

        if (e.meter2 != -1) {
            meters.push_back(e);
        }
        if (j == m_nMaxMatch) {
            maxMeter |= meter;
        }
        else {
            normalMeter |= meter;
        }
    }
    m_vWinMeters = meters;

    if (CanRewin()) {
        WinMeter ele;
        ele.line = 0xFF;
        ele.bonus = {0, 0};
        // blink rewin feature banner on meter2 and play rewin-feature voice
        ele.IntWinbonus.push_back({ 2000, 0, {0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0x2c, 0x4d, 0xce, 0x01, 0x04} });
        ele.IntWinbonus.push_back({ 300, 300, {0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0x2c, 0x4d, 0xce, 0x00, 0x04} });
        // <--
        // show rewin panel and start
        ele.IntWinbonus.push_back({ 0, 1000, {0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0x2c, 0x4d, 0x08, 0x00, 0x04} });
        
        int maxRewin = 3;
        int gone = 0;
        UINT8 _cont = (myRandom() % 2);
        while (1) {
            UINT32 spinDelay = (_cont ? 7000 : 5500);
            // select stop or continue
            ele.IntWinbonus.push_back({ 1000, spinDelay, { 0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0x2c, 0x4d, 0xd0, _cont, 0x04 } });
            if (_cont) {
                UINT8 line = 0;
                for (int i = 0; i < m_vWinMeters.size(); i++) {
                    if (AT(m_vWinMeters, i).line == 0xFF) {
                        continue;
                    }
                    // match line
                    ele.IntWinbonus.push_back({
                        0, 0, 
                        { 0x01, 0x02, 0x31, 0x00, 0x08, 0x00, 0x2c, 0x4d, 0x9c, 0x11, 0x01, line, static_cast<BYTE>(AT(meters, i).meter & 0xFF), static_cast<BYTE>((AT(meters, i).meter >> 8) & 0xFF), static_cast<BYTE>(AT(meters, i).meter2 & 0xFF), static_cast<BYTE>((AT(meters, i).meter2 >> 8) & 0xFF), 0x01, 0x04 } });

                    // update money
                    totalBonus += AT(m_vWinMeters, i).bonus.coin;
                    ele.bonus.coin += AT(m_vWinMeters, i).bonus.coin;
                    ele.IntWinbonus.push_back({
                        0, 0,
                        {0x01, 0x02, 0x2C, 0x00,
                        static_cast<BYTE>(23178 & 0xFF),
                        static_cast<BYTE>((23178 >> 8) & 0xFF),
                        static_cast<BYTE>(totalBonus & 0xFF),
                        static_cast<BYTE>((totalBonus >> 8) & 0xFF),
                        0x00, 0x00, 0, 0x00,
                        0x00, 0x00, 0x01,
                        0x04} });
                    ele.IntWinbonus.push_back({
                       0,
                       2000,
                       {0x01, 0x02, 0x2c, 0x00, 0xeb, 0x58, static_cast<BYTE>(totalBonus & 0xFF), static_cast<BYTE>((totalBonus >> 8) & 0xFF), 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04} });
                    line++;
                }
                // set selected part as stop
                ele.IntWinbonus.push_back({
                       0,
                       0,{0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0x2c, 0x4d, 0xcf, 0x01, 0x04} });
            }
            if (_cont == 0) {
                // hide rewin panel
                ele.IntWinbonus.push_back({
                       0,
                       500,{0x01, 0x02, 0x31, 0x00, 0x00, 0x00, 0x2c, 0x4d, 0x09, 0x04} });
                break;
            }
            _cont = (myRandom() % 2);
            if (gone >= maxRewin) {
                _cont = 0;
            }
            gone++;
        }        
        meters.push_back(ele);

        BonusSound.duration = 0;
        BonusSound.soundID = MAX_SOUND_IDS;
    }
    else {
        if (meters.size()) {
            BonusSound = getSoundByID(m_mapLineSounds[AT(meters, meters.size() - 1).symbol]);
            BonusSound.soundID = MAX_SOUND_IDS;
        }        
    }
    if (bTest == FALSE) {
        updateCheckPoint();
    }
    return result;
}

UINT16 RgTripleTripleChance::LineSound(UINT Line, std::string symbol, UINT8 weight) {    
    return MAX_SOUND_IDS;
}

int RgTripleTripleChance::LineSwapDelay(int WinIdx) {
    if (WinIdx >= m_vWinMeters.size()) {
        return 2000;
    }
    SoundItem e = getSoundByID(m_mapLineSounds[AT(m_vWinMeters, WinIdx).symbol]);
    return e.duration;
}

UINT16 RgTripleTripleChance::Run() {
    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = 0;
    return m_shCurrentReelStrip;
}

void RgTripleTripleChance::ChangeReelStrip(UINT16 NewReelPlan) {
    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = 0;
}

UINT16 RgTripleTripleChance::SpinTime_MS() {
    return 1800;
}

BOOL RgTripleTripleChance::stopAllSoundBeforeMove() {
    return TRUE;
}

BOOL RgTripleTripleChance::CanFreeMode() {
    for (int i = 0; i < m_vWinMeters.size(); i++) {
        if (AT(m_vWinMeters, i).symbol == "ttchRau") {
            return TRUE;
        }
    }
    return FALSE;
}

myVector<InterruptPacketData> RgTripleTripleChance::EnterFreeGame(std::string check) {
    m_bFreeMode = TRUE;

    m_nFreeModeTotalSpin = 1;
    m_nFreeModeGoneSpin = 1;

    myVector<InterruptPacketData> packets;

    // stop all sound
    packets.push_back({
        0,
        0,
        {0x01, 0x02, 0x35, 0x00, 0x00, 0x00, 0x04} });
    packets.push_back({
        0,
        0,
        {
    0x06, 0x2c, 0x4d, 0x01, 0x02, 0x28, 0x00, 0x2c, 0x4d, 0xce, 0x00, 0x00, 0x00, 0x04} });
    // play sound respin voice
    packets.push_back({
        0,
        1500,
        {0x01, 0x02, 0x34, 0x00,
        static_cast<BYTE>(SMP_TTCH_Respin_Voice & 0xFF), static_cast<BYTE>((SMP_TTCH_Respin_Voice >> 8) & 0xFF),
        0x04} });

    return packets;
}

BOOL RgTripleTripleChance::CanRewin() {
    myVector<WinMeter> realMeters;
    for (int i = 0; i < m_vWinMeters.size(); i++) {
        if (AT(m_vWinMeters, i).line != 0xFF) {
            realMeters.push_back(AT(m_vWinMeters, i));
        }
    }

    if (realMeters.size() != m_nWinLine) {
        return FALSE;
    }

    auto firstSymbol = AT(realMeters, 0).symbol;

    if (firstSymbol != "ttchPfl" &&
        firstSymbol != "ttchOra" &&
        firstSymbol != "ttchZit" &&
        firstSymbol != "ttchKir") {
        return FALSE;
    }
    for (size_t i = 1; i < realMeters.size(); ++i) {
        if (AT(realMeters, i).symbol != firstSymbol) {
            return FALSE;
        }
    }
    return TRUE;
}

myVector<InterruptPacketData> RgTripleTripleChance::InterruptAfterMoveBonus(BOOL& EndFree) {
    myVector<InterruptPacketData> packets;
    if (CanFreeMode()) {
        EndFree = FALSE;
        return EnterFreeGame("");
    }
    else {
        EndFree = TRUE;
        m_bFreeMode = FALSE;
        return packets;
    }    
    return packets;
}

myVector<InterruptPacketData> RgTripleTripleChance::InterruptAfterSpin() {
    myVector<InterruptPacketData> empty;
    return empty;
}

myVector<UINT8> RgTripleTripleChance::ShowTotalWinLines(myVector<WinMeter> SpinMeters) {
    myVector<uint8_t> packet = {
       0x01, 0x02, 0x31, 0x00, 
       0x24, 0x00, // Placeholder for length 
       0x2c, 0x4d, // GameID
       0x9c, 0x13, 0x01,
    };
    myVector<UINT8> TotalMatch;
    for (int i = 0; i < SpinMeters.size(); i++) {
        if (AT(SpinMeters, i).line == 0xFF) {
            continue;
        }
        TotalMatch.push_back(AT(SpinMeters, i).line);
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter >> 8) & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter2 & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter2 >> 8) & 0xFF));
    }
    if (TotalMatch.size() < 10) {
        myVector<UINT8> _;
        return _;
    }
    UINT16 pktLen = 1 + (TotalMatch.size() / 5) * 7;
    AT(packet, 4) = static_cast<BYTE>(pktLen & 0xFF);
    AT(packet, 5) = static_cast<BYTE>((pktLen >> 8) & 0xFF);
    AT(packet, 6) = static_cast<BYTE>(m_nGameID & 0xFF);
    AT(packet, 7) = static_cast<BYTE>((m_nGameID >> 8) & 0xFF);
    int entryCount = static_cast<int>(TotalMatch.size() / 5);
    for (int i = 0; i < entryCount; ++i) {
        packet.push_back(AT(TotalMatch, i * 5 + 0)); // Line
        packet.push_back(AT(TotalMatch, i * 5 + 1)); // Meter low byte
        packet.push_back(AT(TotalMatch, i * 5 + 2)); // Meter high byte
        packet.push_back(AT(TotalMatch, i * 5 + 3)); // Meter2 low byte
        packet.push_back(AT(TotalMatch, i * 5 + 4)); // Meter2 high byte
        packet.push_back(0x01);      // Status or flag 1
        packet.push_back(0x01);      // Status or flag 2
    }
    // Mark the end of the packet
    packet.back() = 0x04;
    return packet;
}

myVector<InterruptPacketData> RgTripleTripleChance::InterruptBeforeRisiko() {
    myVector<InterruptPacketData> packets;
    // hide top erfolg
    packets.push_back({
           0,
           0,
           {0x01, 0x02, 0x2f, 0x00, 0xeb, 0x58, 0x00, 0x04} });
    return packets;
}

myVector<InterruptPacketData> RgTripleTripleChance::InterruptBeforeSpin() {
    myVector<InterruptPacketData> packets;
    // hide top erfolg
    packets.push_back({
           0,
           0,
           {0x01, 0x02, 0x2f, 0x00, 0xeb, 0x58, 0x00, 0x04} });
    return packets;
}

void RgTripleTripleChance::updateCheckPoint() {
    std::ostringstream oss;
    oss << " P" << m_nCurrentReelPlan
        << " B"
        << static_cast<int>(AT(m_vWinResult, 0)) << ":"
        << static_cast<int>(AT(m_vWinResult, 1)) << ":"
        << static_cast<int>(AT(m_vWinResult, 2)) << " ";
    m_strCheckPoint = oss.str();
}