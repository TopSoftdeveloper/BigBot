#ifndef __REEL_GAME_H_
#define __REEL_GAME_H_

#include "../myVector.h"
#include <Windows.h>
#include <string>
#include <vector>
#include <iostream>
#include <sstream>
#include "Utils.h"
#include <cstdlib>
#include <ctime>
#include "../headerSoundIds.h"
#include "../GrafficObjList.h"
#include "../mmcode.h"
#include "../PlayDB.h"
#include <format>
#include <iostream>

#define __DEBUG__

//#define TEST_FREE_MODE


#define GOC_RgFruitinator 7155
#define GOC_RgBlazingSun 4367
#define GOC_RgHotFrootastic 10263
#define GOC_RgMerkurMagnus 12501
#define GOC_RgEyeOfHorus 6664
#define GOC_RgMultiSevenWild 13402
#define GOC_RgElToreroMG 6580
#define GOC_RgGoldCup 8902
#define GOC_RgIndianRuby 10526
#define GOC_RgDragonsTreas 6071
#define GOC_RgMagicMirrorDeluxe2 12741
#define GOC_RgDoubleBook 5635
#define GOC_RgMultiWild243 13714
#define GOC_RgJokersCap 10655
#define GOC_RgGongHei 9431
#define GOC_RgGl 8759
#define GOC_RgTripleTripleChance 19756
#define GOC_RgConvertusAurum 5051
#define GOC_RgPyramidsDeluxe 2320
#define GOC_RgBookOfFire 4463
#define GOC_RgLegacyOfFire 11692
#define GOC_RgExtraWild 6988
#define GOC_RgRisingLiner 15871
#define GOC_RgTotemChiefPlus 18039
#define GOC_RgPyramidOfPower 15316
#define GOC_RgKeyOfTheNile 1467
#define GOC_RgKongsTemple 11486
#define GOC_RgLosFrootos 2920
#define GOC_RgLosFrootosPS1 2921
#define GOC_RgLosFrootosPS2 2922
#define GOC_RgLosFrootosPS3 2923
#define GOC_RgLosFrootosPS4 2924
#define GOC_RgPharosGoldBase 14508
#define GOC_RgPharosGold1 14509
#define GOC_RgPharosGold2 14510
#define GOC_RgPharosGold3 14511
#define GOC_RgPharosGold4 14512

#define GOC_RgCairoCasino 1214

#define BANK_BIT_GOC	g_GrafficObjList.Str2GOCID("Winmeter")
#define BONUS_BIT_GOC	g_GrafficObjList.Str2GOCID("WinAnzeige")
#define SUNNIER_GOC		g_GrafficObjList.Str2GOCID("UmbuchSonne")

#define LATEST_LABEL_GOC	g_GrafficObjList.Str2GOCID("LetzterGewinn")

#define TEST_REEL5_SYMBOLS(v, _0, _1, _2, _3, _4) do {	\
	v.clear();			\
	v.push_back(_0);	\
	v.push_back(_1);	\
	v.push_back(_2);	\
	v.push_back(_3);	\
	v.push_back(_4);	\
} while(0)

#define TEST_REEL5_ESTIMATE(v, e) do {	\
	v.clear();			\
	v.push_back(e);	\
	v.push_back(e);	\
	v.push_back(e);	\
	v.push_back(e);	\
	v.push_back(e);	\
} while(0)

#define TEST_REEL3_SYMBOLS(v, _0, _1, _2) do {	\
	v.clear();			\
	v.push_back(_0);	\
	v.push_back(_1);	\
	v.push_back(_2);	\
} while(0)


struct Position {
	UINT8 reel;
	UINT8 row;
};

typedef myVector<std::string> ReelStrip;
typedef myVector<ReelStrip> ReelSet;

typedef struct {
	UINT32 coin;
	UINT32 ag;
} BONUS;

typedef struct {
	UINT8 region;
	UINT8 pos;
} _Point;

typedef struct {
	_Point x;
	_Point y;
} MousePosition;


struct InterruptPacketData {
	UINT32 preDelay;
	UINT32 postDelay;
	myVector<UINT8> data;
};


typedef struct {
	UINT8 line;

	UINT16 meter;
	UINT16 meter2;

	std::string symbol;
	UINT8 weight;
	UINT8 start;
	BONUS bonus;
	UINT8 multi;

	myVector<InterruptPacketData> IntWinbonus;

	UINT16 sound;
	UINT16 swapDelay;

	UINT16 gameId;
	UINT16 gamePlan;
	UINT16 psIdx;
} WinMeter;

class ReelGame {
public:
	ReelGame::ReelGame();

	UINT16 m_nGameID;
	std::string m_strGameName;

	int m_nReel;
	int m_nWinLine;
	int m_nMaxMatch;
	int m_nBetStep;
	int m_nMaxBetStep;
	int m_nMinBetStep;
	UINT16 m_nMagicCount;

	BOOL m_bPrevSpinMatchedActive;

	myVector<UINT8> m_vecAdditionalParam;

	myVector<std::string> m_vecSymbols;
	myVector<std::string> m_vecWinLines;
	myVector<UINT16> m_vecLineSounds;
	myVector<UINT16> m_vecWinSounds;

	myVector<UINT16> m_vecBetSteps;
	myVector<UINT16> m_vecBetSteps_05;
	myVector<UINT16> m_vecBetSteps_10;

	myVector<UINT8> m_vWinResult;

	std::map<std::string, UINT8> m_mapSymbolMinMatch;
	std::map<std::string, std::string> m_mapSymbolMeterGoc;

	myVector<std::string> m_vecReelStripPlan;
	myVector<ReelSet> m_vecReelStripSets;

	// Bet, STRING, Weight, Bonus
	std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus; 
	std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_05;
	std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_10;	
public:
	int m_nCurrentReelPlan;
	UINT16 m_shCurrentReelStrip;

	BOOL m_bMultiGo;
	UINT8 m_nMultiGoBetStep;
public:
	void SetGameID(UINT16 id);
	UINT16 GetGameId();
	std::string GetGameName();


	virtual int GetWinLine();
	virtual void SetWinLine(int newWinLine);

	virtual void ChangeReelStrip(UINT16 NewReelPlan);

	virtual myVector<InterruptPacketData> MousePressed(MousePosition p);
	
	virtual UINT8 WinLine();
	virtual UINT GameMode();
	virtual UINT16 Run();
	virtual void LoadBets();
	virtual UINT16 MagicCount();
	virtual myVector<InterruptPacketData> SelectSymbol(std::string symbol);

	virtual myVector<UINT8> Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& WinSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode);
	virtual UINT16 LineSound(UINT Line, std::string symbol, UINT8 weight);
	virtual UINT16 WinSound(UINT32 totalBonus);
	virtual int LineSwapDelay(int WinIdx);
	virtual myVector<UINT16> Bets();
	virtual void SetBets(myVector<UINT16> b);
	virtual UINT8 BetUp();
	virtual UINT8 MaxBet();
	virtual UINT8 BetStep();
	virtual UINT16 BetBit();
	virtual void SetBetStep(int newStep);
	virtual UINT16 SpinTime_MS();
	virtual myVector<UINT16> CurrentReelStrip();
	virtual int CurrentReelSetIdx();
	virtual BOOL CanFreeMode();
	virtual UINT8 Wildcount();
	virtual BOOL PlayBonusSoundAfterWinLine();
	virtual BOOL stopAllSoundBeforeMove();
	virtual myVector<UINT8> AdditionalParam();
	virtual myVector<InterruptPacketData> OnBetUp(int OrgBetStep, int NewBetStep);

	virtual std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> GetBonus();
	virtual void SetBonus(std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> b);

	virtual myVector<InterruptPacketData> EnterFreeGame(std::string);
	virtual myVector<InterruptPacketData> InterruptAfterMoveBonus(BOOL& EndFree);
	virtual myVector<InterruptPacketData> InterruptAfterSpin();
	virtual myVector<InterruptPacketData> InterruptBeforeSpin();

	virtual BOOL CanMultiGo();
	virtual myVector<InterruptPacketData> EnterMultiGo(UINT32& bonusErfolg, BOOL bIitMultiBet);
	virtual myVector<InterruptPacketData> CloseMultiGo(UINT32& bonusErfolg, BOOL force);
	virtual myVector<InterruptPacketData> BetUpMultiGo(UINT32& bonusErfolg);
	virtual myVector<InterruptPacketData> BetDownMultiGo(UINT32& bonusErfolg);
	virtual void MultiGoGoneAndRemain(UINT8& gone, UINT8& total, UINT8& loop);
	virtual UINT16 MiltiGoBet();	
	virtual UINT8 MultiGoBetStep();
	virtual void SetMultiGoBetStep(UINT8 newStep);
	virtual BOOL GetMultiGoEnable();
	virtual void SetMultiGoEnable(BOOL status);
	virtual void GetMultiGoReelPlanIdx(int& p0, int& p1, int& p2, int& p3);
	virtual void SetMultiGoReelPlanIdx(int p0, int p1, int p2, int p3);


	virtual myVector<UINT8> ShowTotalWinLines(myVector<WinMeter> SpinMeters);
	// for Debug
	virtual void PrintAllBonus();
	void PrintBonusSet(const std::string& label,
		myVector<UINT16> betSteps,
		std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> bonusMap);

	virtual bool RTP_force_bigWin();
	virtual myVector<int> GetStartInfo();

	virtual BOOL SelectedableReelsInFreeGame(myVector<UINT8> result);
	virtual BOOL NoFunInFreeMode();

	virtual myVector<InterruptPacketData> InterruptBeforeRisiko();

	std::string m_strCheckPoint;
	virtual std::string CheckPoint();
	virtual void updateCheckPoint();

	myVector<int> ParseCheckPoint(std::string check, std::string prefix, int num);
	
};

extern int g_match_lines_10_5[10][5];
extern int g_match_lines_5_3[5][3];
extern int g_match_lines_pyramid[16][5];
extern int g_match_lines_RgPharosGoldBase[10][5];

extern ReelGame* g_ReelGame;
extern ReelGame* g_ReelGameTmp;

// Variant A is always defined. Variants B and C are only active when
// VARIANTBC_ACTIVE is defined (see stdafx.h). Their numeric values are still
// declared unconditionally so that any reference compiles, but the variant
// selection logic only allows A unless the macro is enabled.
#define VARIANT_A (0.7)
#define VARIANT_B (0.6)
#define VARIANT_C (0.5)

extern double gTargetRTP;

int myRandom();
BOOL IsMouseWithin(MousePosition target, MousePosition a, MousePosition b);
myVector<int> pickRandom2or3(int pool[], int poolSize, int count);

#endif