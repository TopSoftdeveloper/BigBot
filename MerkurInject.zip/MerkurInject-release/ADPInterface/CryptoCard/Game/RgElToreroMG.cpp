#include "stdafx.h"
#include "RgElToreroMG.h"

#define RgElToreroMG_wild "eltMAN___"
#define RgElToreroMG_scatter "eltBULL__"

RgElToreroMG::RgElToreroMG() {
    m_nReel = 5;
    m_nWinLine = 10;
    m_nMaxMatch = 5;
    m_nBetStep = 0;

    m_bFreeMode = FALSE;

    m_strGameName = "RgElToreroMG";

    myVector<UINT16> m_vecBetSteps_tmp;
    m_vecBetSteps_tmp.push_back(10);
    m_vecBetSteps_tmp.push_back(20);
    m_vecBetSteps_tmp.push_back(30);
    m_vecBetSteps_tmp.push_back(40);
    m_vecBetSteps_tmp.push_back(50);
    m_vecBetSteps_tmp.push_back(60);
    m_vecBetSteps_tmp.push_back(80);
    m_vecBetSteps_tmp.push_back(100);
    m_vecBetSteps_tmp.push_back(150);
    m_vecBetSteps_tmp.push_back(200);
#ifdef BIGBET_ACTIVE
    m_vecBetSteps_tmp.push_back(500);
    m_vecBetSteps_tmp.push_back(1000);
#endif
    LoadBets();

    m_vecSymbols.push_back("eltMAN___");
    m_vecSymbols.push_back("eltFAN___");
    m_vecSymbols.push_back("eltGUIT__");
    m_vecSymbols.push_back("eltROSE__");
    m_vecSymbols.push_back("eltHAT___");
    m_vecSymbols.push_back("eltA_____");
    m_vecSymbols.push_back("eltK_____");
    m_vecSymbols.push_back("eltQ_____");
    m_vecSymbols.push_back("eltJ_____");
    m_vecSymbols.push_back("eltTEN___");

    m_vecSymbols.push_back("eltBULL__");
    
    m_mapSymbolMinMatch["eltMAN___"] = 2;
    m_mapSymbolMinMatch["eltFAN___"] = 2;
    m_mapSymbolMinMatch["eltGUIT__"] = 3;
    m_mapSymbolMinMatch["eltROSE__"] = 3;
    m_mapSymbolMinMatch["eltHAT___"] = 3;
    m_mapSymbolMinMatch["eltA_____"] = 3;
    m_mapSymbolMinMatch["eltK_____"] = 3;
    m_mapSymbolMinMatch["eltQ_____"] = 3;
    m_mapSymbolMinMatch["eltJ_____"] = 3;
    m_mapSymbolMinMatch["eltTEN___"] = 3;

    m_mapSymbolMeterGoc["eltMAN___"] = "eltMan$xMG";
    m_mapSymbolMeterGoc["eltFAN___"] = "eltFan$xMG";
    m_mapSymbolMeterGoc["eltGUIT__"] = "eltHatGuitRos$xMG";
    m_mapSymbolMeterGoc["eltROSE__"] = "eltHatGuitRos$xMG";
    m_mapSymbolMeterGoc["eltHAT___"] = "eltHatGuitRos$xMG";
    m_mapSymbolMeterGoc["eltA_____"] = "eltAK$xMG";
    m_mapSymbolMeterGoc["eltK_____"] = "eltAK$xMG";
    m_mapSymbolMeterGoc["eltQ_____"] = "eltQJ10$xMG";
    m_mapSymbolMeterGoc["eltJ_____"] = "eltQJ10$xMG";
    m_mapSymbolMeterGoc["eltTEN___"] = "eltQJ10$xMG";

    m_vWinLineSounds["eltMAN___2"] = SMP_ELTSmall;
    m_vWinLineSounds["eltMAN___3"] = SMP_ELTLarge;
    m_vWinLineSounds["eltMAN___4"] = SMP_ELTMan;
    m_vWinLineSounds["eltMAN___5"] = SMP_ELTMan5;
    m_vWinLineSounds["eltFAN___2"] = SMP_ELTEval;
    m_vWinLineSounds["eltFAN___3"] = SMP_ELTEval;
    m_vWinLineSounds["eltFAN___4"] = SMP_ELTEval;
    m_vWinLineSounds["eltFAN___5"] = SMP_ELTEval;
    m_vWinLineSounds["eltGUIT__3"] = SMP_ELTMedium;
    m_vWinLineSounds["eltGUIT__4"] = SMP_ELTpic4;
    m_vWinLineSounds["eltGUIT__5"] = SMP_ELTpic5;
    m_vWinLineSounds["eltROSE__3"] = SMP_ELTMedium;
    m_vWinLineSounds["eltROSE__4"] = SMP_ELTpic4;
    m_vWinLineSounds["eltROSE__5"] = SMP_ELTpic5;
    m_vWinLineSounds["eltHAT___3"] = SMP_ELTMedium;
    m_vWinLineSounds["eltHAT___4"] = SMP_ELTpic4;
    m_vWinLineSounds["eltHAT___5"] = SMP_ELTpic5;
    m_vWinLineSounds["eltA_____3"] = SMP_ELTSmall;
    m_vWinLineSounds["eltA_____4"] = SMP_ELTMedium;
    m_vWinLineSounds["eltA_____5"] = SMP_ELTLarge;
    m_vWinLineSounds["eltK_____3"] = SMP_ELTSmall;
    m_vWinLineSounds["eltK_____4"] = SMP_ELTMedium;
    m_vWinLineSounds["eltK_____5"] = SMP_ELTLarge;
    m_vWinLineSounds["eltQ_____3"] = SMP_ELTSmall;
    m_vWinLineSounds["eltQ_____4"] = SMP_ELTMedium;
    m_vWinLineSounds["eltQ_____5"] = SMP_ELTLarge;
    m_vWinLineSounds["eltJ_____3"] = SMP_ELTSmall;
    m_vWinLineSounds["eltJ_____4"] = SMP_ELTMedium;
    m_vWinLineSounds["eltJ_____5"] = SMP_ELTLarge;
    m_vWinLineSounds["eltTEN___3"] = SMP_ELTSmall;
    m_vWinLineSounds["eltTEN___4"] = SMP_ELTMedium;
    m_vWinLineSounds["eltTEN___5"] = SMP_ELTLarge;

    m_vecWinLines.push_back("eltWinline1");
    m_vecWinLines.push_back("eltWinline2");
    m_vecWinLines.push_back("eltWinline3");
    m_vecWinLines.push_back("eltWinline4");
    m_vecWinLines.push_back("eltWinline5");
    m_vecWinLines.push_back("eltWinline6");
    m_vecWinLines.push_back("eltWinline7");
    m_vecWinLines.push_back("eltWinline8");
    m_vecWinLines.push_back("eltWinline9");
    m_vecWinLines.push_back("eltWinline10");
    m_vecWinLines.push_back("eltWinlineScat");       
    
    m_vecReelStripPlan.push_back("eltW1A");
    m_vecReelStripPlan.push_back("eltW1B");
    m_vecReelStripPlan.push_back("eltW1C");
    m_vecReelStripPlan.push_back("eltW1D");
    m_vecReelStripPlan.push_back("eltW1E");
    m_vecReelStripPlan.push_back("eltW1F");
    m_vecReelStripPlan.push_back("eltW1G");
    m_vecReelStripPlan.push_back("eltW1H");
        
    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));

    char* eltReelStrip[] = {
        "eltMAN___,eltQ_____,eltTEN___,eltGUIT__,eltJ_____,eltTEN___,eltBULL__,eltQ_____,eltK_____,eltHAT___,eltQ_____,eltK_____,eltBULL__,eltJ_____,eltROSE__,eltK_____,eltGUIT__,eltQ_____,eltK_____,eltHAT___,eltQ_____,eltTEN___,eltGUIT__,eltK_____,eltTEN___,eltHAT___,eltGUIT__,eltQ_____,eltA_____,eltJ_____,eltBULL__,eltK_____,eltQ_____,eltMAN___,eltK_____,eltQ_____,eltA_____,eltK_____,eltGUIT__,eltQ_____,eltK_____,eltTEN___,eltROSE__,eltQ_____,eltK_____",
        "eltMAN___,eltK_____,eltJ_____,eltTEN___,eltK_____,eltGUIT__,eltA_____,eltJ_____,eltTEN___,eltFAN___,eltFAN___,eltFAN___,eltFAN___,eltA_____,eltJ_____,eltTEN___,eltA_____,eltHAT___,eltROSE__,eltJ_____,eltQ_____,eltA_____,eltJ_____,eltMAN___,eltK_____,eltJ_____,eltHAT___,eltA_____,eltJ_____,eltTEN___,eltA_____,eltQ_____,eltHAT___,eltJ_____,eltTEN___,eltA_____,eltJ_____,eltHAT___,eltA_____,eltJ_____,eltTEN___,eltA_____,eltROSE__,eltTEN___,eltQ_____",
        "eltMAN___,eltTEN___,eltJ_____,eltROSE__,eltA_____,eltQ_____,eltBULL__,eltTEN___,eltJ_____,eltA_____,eltMAN___,eltTEN___,eltJ_____,eltK_____,eltBULL__,eltTEN___,eltQ_____,eltROSE__,eltA_____,eltGUIT__,eltQ_____,eltJ_____,eltROSE__,eltQ_____,eltBULL__,eltA_____,eltK_____,eltHAT___,eltTEN___,eltFAN___,eltFAN___,eltFAN___,eltFAN___,eltA_____,eltK_____,eltROSE__,eltJ_____,eltHAT___,eltA_____,eltQ_____,eltGUIT__,eltBULL__,eltTEN___,eltA_____,eltROSE__",
        "eltMAN___,eltK_____,eltA_____,eltGUIT__,eltROSE__,eltQ_____,eltJ_____,eltK_____,eltFAN___,eltFAN___,eltFAN___,eltFAN___,eltTEN___,eltK_____,eltHAT___,eltQ_____,eltA_____,eltGUIT__,eltTEN___,eltJ_____,eltA_____,eltTEN___,eltHAT___,eltQ_____,eltA_____,eltJ_____,eltQ_____,eltROSE__,eltA_____,eltGUIT__,eltJ_____,eltK_____,eltMAN___,eltQ_____,eltJ_____,eltHAT___,eltA_____,eltJ_____,eltGUIT__,eltTEN___,eltROSE__,eltA_____,eltK_____,eltHAT___,eltJ_____",
        "eltMAN___,eltA_____,eltTEN___,eltGUIT__,eltJ_____,eltK_____,eltROSE__,eltA_____,eltK_____,eltFAN___,eltFAN___,eltFAN___,eltFAN___,eltTEN___,eltJ_____,eltK_____,eltROSE__,eltHAT___,eltK_____,eltTEN___,eltGUIT__,eltJ_____,eltROSE__,eltQ_____,eltTEN___,eltJ_____,eltQ_____,eltBULL__,eltA_____,eltQ_____,eltTEN___,eltA_____,eltHAT___,eltK_____,eltQ_____,eltMAN___,eltTEN___,eltA_____,eltBULL__,eltJ_____,eltA_____,eltHAT___,eltQ_____",

        "eltFAN___,eltFAN___,eltFAN___,eltFAN___,eltA_____,eltJ_____,eltMAN___,eltQ_____,eltK_____,eltFAN___,eltFAN___,eltFAN___,eltJ_____,eltQ_____,eltMAN___,eltTEN___,eltK_____,eltFAN___,eltFAN___,eltFAN___,eltA_____,eltK_____,eltMAN___,eltA_____,eltTEN___",
        "eltFAN___,eltFAN___,eltFAN___,eltFAN___,eltK_____,eltTEN___,eltJ_____,eltFAN___,eltFAN___,eltFAN___,eltQ_____,eltTEN___,eltA_____,eltFAN___,eltFAN___,eltFAN___,eltQ_____,eltJ_____,eltA_____,eltFAN___,eltFAN___,eltFAN___,eltK_____,eltJ_____,eltTEN___",
        "eltFAN___,eltFAN___,eltFAN___,eltA_____,eltTEN___,eltROSE__,eltQ_____,eltK_____,eltFAN___,eltFAN___,eltFAN___,eltTEN___,eltA_____,eltGUIT__,eltHAT___,eltQ_____,eltK_____,eltJ_____,eltQ_____,eltGUIT__,eltA_____,eltJ_____,eltROSE__,eltK_____,eltJ_____",
        "eltFAN___,eltFAN___,eltFAN___,eltTEN___,eltA_____,eltK_____,eltTEN___,eltROSE__,eltHAT___,eltA_____,eltGUIT__,eltK_____,eltTEN___,eltA_____,eltK_____,eltHAT___,eltQ_____,eltTEN___,eltROSE__,eltQ_____,eltA_____,eltJ_____,eltQ_____,eltHAT___,eltGUIT__,eltJ_____,eltROSE__,eltK_____,eltTEN___,eltA_____",
        "eltGUIT__,eltK_____,eltQ_____,eltTEN___,eltK_____,eltHAT___,eltROSE__,eltA_____,eltQ_____,eltJ_____,eltGUIT__,eltK_____,eltQ_____,eltTEN___,eltK_____,eltHAT___,eltROSE__,eltA_____,eltQ_____,eltJ_____",

        "eltFAN___,eltFAN___,eltFAN___,eltFAN___,eltA_____,eltJ_____,eltTEN___,eltFAN___,eltFAN___,eltFAN___,eltA_____,eltJ_____,eltTEN___,eltFAN___,eltFAN___,eltFAN___,eltFAN___,eltA_____,eltJ_____,eltTEN___",
        "eltGUIT__,eltHAT___,eltQ_____,eltK_____,eltTEN___,eltQ_____,eltROSE__,eltK_____,eltQ_____,eltTEN___,eltGUIT__,eltHAT___,eltQ_____,eltK_____,eltTEN___,eltQ_____,eltROSE__,eltK_____,eltQ_____,eltTEN___",
        "eltFAN___,eltFAN___,eltFAN___,eltA_____,eltJ_____,eltMAN___,eltA_____,eltJ_____,eltFAN___,eltFAN___,eltFAN___,eltTEN___,eltA_____,eltJ_____,eltFAN___,eltFAN___,eltFAN___,eltTEN___,eltA_____,eltJ_____",
        "eltFAN___,eltFAN___,eltFAN___,eltA_____,eltK_____,eltJ_____,eltA_____,eltFAN___,eltFAN___,eltFAN___,eltQ_____,eltTEN___,eltK_____,eltQ_____,eltMAN___,eltJ_____,eltK_____,eltROSE__,eltJ_____,eltA_____",
        "eltFAN___,eltFAN___,eltFAN___,eltQ_____,eltA_____,eltTEN___,eltQ_____,eltFAN___,eltFAN___,eltFAN___,eltTEN___,eltQ_____,eltK_____,eltTEN___,eltROSE__,eltK_____,eltQ_____,eltGUIT__,eltTEN___,eltK_____",

        "eltFAN___,eltFAN___,eltFAN___,eltFAN___,eltA_____,eltJ_____,eltTEN___,eltFAN___,eltFAN___,eltFAN___,eltA_____,eltJ_____,eltTEN___,eltFAN___,eltFAN___,eltFAN___,eltFAN___,eltA_____,eltJ_____,eltTEN___",
        "eltFAN___,eltFAN___,eltFAN___,eltQ_____,eltK_____,eltTEN___,eltQ_____,eltROSE__,eltK_____,eltQ_____,eltTEN___,eltGUIT__,eltHAT___,eltQ_____,eltK_____,eltTEN___,eltQ_____,eltROSE__,eltK_____,eltQ_____",
        "eltFAN___,eltFAN___,eltFAN___,eltJ_____,eltK_____,eltA_____,eltJ_____,eltGUIT__,eltK_____,eltA_____,eltJ_____,eltHAT___,eltROSE__,eltJ_____,eltK_____,eltA_____,eltJ_____,eltGUIT__,eltK_____,eltA_____",
        "eltFAN___,eltFAN___,eltFAN___,eltA_____,eltK_____,eltTEN___,eltA_____,eltMAN___,eltJ_____,eltQ_____,eltA_____,eltGUIT__,eltHAT___,eltQ_____,eltK_____,eltA_____,eltQ_____,eltROSE__,eltTEN___,eltQ_____",
        "eltFAN___,eltFAN___,eltFAN___,eltK_____,eltTEN___,eltA_____,eltK_____,eltMAN___,eltQ_____,eltJ_____,eltTEN___,eltROSE__,eltHAT___,eltK_____,eltTEN___,eltA_____,eltK_____,eltGUIT__,eltQ_____,eltJ_____",

        "eltFAN___,eltFAN___,eltFAN___,eltFAN___,eltA_____,eltJ_____,eltTEN___,eltFAN___,eltFAN___,eltFAN___,eltA_____,eltJ_____,eltTEN___,eltFAN___,eltFAN___,eltFAN___,eltFAN___,eltA_____,eltJ_____,eltTEN___",
        "eltFAN___,eltFAN___,eltFAN___,eltJ_____,eltA_____,eltMAN___,eltJ_____,eltA_____,eltFAN___,eltFAN___,eltFAN___,eltTEN___,eltJ_____,eltA_____,eltFAN___,eltFAN___,eltFAN___,eltTEN___,eltJ_____,eltA_____",
        "eltHAT___,eltROSE__,eltJ_____,eltK_____,eltA_____,eltJ_____,eltGUIT__,eltK_____,eltA_____,eltJ_____,eltHAT___,eltROSE__,eltJ_____,eltK_____,eltA_____,eltJ_____,eltGUIT__,eltK_____,eltA_____,eltJ_____",
        "eltFAN___,eltFAN___,eltFAN___,eltA_____,eltK_____,eltJ_____,eltA_____,eltFAN___,eltFAN___,eltFAN___,eltQ_____,eltTEN___,eltK_____,eltQ_____,eltGUIT__,eltJ_____,eltK_____,eltROSE__,eltJ_____,eltA_____",
        "eltFAN___,eltFAN___,eltFAN___,eltQ_____,eltA_____,eltTEN___,eltQ_____,eltFAN___,eltFAN___,eltFAN___,eltTEN___,eltQ_____,eltK_____,eltTEN___,eltMAN___,eltK_____,eltQ_____,eltGUIT__,eltTEN___,eltK_____",

        "eltMAN___,eltQ_____,eltA_____,eltJ_____,eltROSE__,eltQ_____,eltJ_____,eltTEN___,eltFAN___,eltFAN___,eltFAN___,eltA_____,eltTEN___,eltK_____,eltGUIT__,eltTEN___,eltK_____,eltQ_____,eltMAN___,eltJ_____,eltK_____,eltTEN___,eltROSE__,eltK_____,eltJ_____,eltGUIT__,eltQ_____,eltTEN___,eltA_____,eltJ_____,eltHAT___,eltQ_____,eltA_____,eltROSE__,eltQ_____,eltTEN___,eltHAT___,eltA_____,eltJ_____,eltK_____",
        "eltMAN___,eltQ_____,eltK_____,eltROSE__,eltA_____,eltK_____,eltGUIT__,eltJ_____,eltA_____,eltHAT___,eltJ_____,eltA_____,eltQ_____,eltROSE__,eltTEN___,eltJ_____,eltMAN___,eltA_____,eltQ_____,eltGUIT__,eltTEN___,eltK_____,eltFAN___,eltFAN___,eltFAN___,eltJ_____,eltQ_____,eltHAT___,eltTEN___,eltK_____,eltGUIT__,eltA_____,eltK_____,eltROSE__,eltTEN___,eltA_____",
        "eltMAN___,eltK_____,eltQ_____,eltHAT___,eltA_____,eltJ_____,eltTEN___,eltROSE__,eltA_____,eltQ_____,eltJ_____,eltFAN___,eltFAN___,eltFAN___,eltTEN___,eltJ_____,eltA_____,eltGUIT__,eltK_____,eltTEN___,eltQ_____,eltMAN___,eltK_____,eltJ_____,eltHAT___,eltTEN___,eltJ_____,eltQ_____,eltGUIT__,eltK_____,eltA_____,eltQ_____,eltTEN___,eltHAT___,eltJ_____,eltK_____,eltTEN___,eltROSE__,eltK_____,eltQ_____,eltA_____",
        "eltMAN___,eltK_____,eltTEN___,eltQ_____,eltROSE__,eltJ_____,eltTEN___,eltHAT___,eltK_____,eltTEN___,eltGUIT__,eltQ_____,eltK_____,eltTEN___,eltROSE__,eltJ_____,eltK_____,eltA_____,eltHAT___,eltQ_____,eltA_____,eltFAN___,eltFAN___,eltFAN___,eltJ_____,eltQ_____,eltHAT___,eltA_____,eltTEN___,eltGUIT__,eltJ_____,eltA_____,eltK_____,eltHAT___,eltQ_____,eltJ_____",
        "eltMAN___,eltK_____,eltJ_____,eltA_____,eltROSE__,eltTEN___,eltK_____,eltJ_____,eltHAT___,eltTEN___,eltQ_____,eltJ_____,eltROSE__,eltK_____,eltTEN___,eltROSE__,eltJ_____,eltK_____,eltA_____,eltHAT___,eltQ_____,eltTEN___,eltJ_____,eltFAN___,eltFAN___,eltFAN___,eltTEN___,eltK_____,eltQ_____,eltGUIT__,eltJ_____,eltQ_____,eltK_____,eltHAT___,eltA_____,eltQ_____,eltGUIT__,eltTEN___,eltA_____,eltQ_____",

        "eltMAN___,eltA_____,eltK_____,eltROSE__,eltQ_____,eltTEN___,eltFAN___,eltFAN___,eltFAN___,eltK_____,eltJ_____,eltBULL__,eltA_____,eltTEN___,eltHAT___,eltA_____,eltJ_____,eltGUIT__,eltK_____,eltQ_____",
        "eltMAN___,eltQ_____,eltA_____,eltFAN___,eltFAN___,eltFAN___,eltFAN___,eltQ_____,eltJ_____,eltROSE__,eltK_____,eltTEN___,eltMAN___,eltJ_____,eltTEN___,eltGUIT__,eltA_____,eltTEN___,eltHAT___,eltK_____,eltJ_____",
        "eltMAN___,eltTEN___,eltK_____,eltROSE__,eltJ_____,eltQ_____,eltBULL__,eltA_____,eltJ_____,eltFAN___,eltFAN___,eltFAN___,eltA_____,eltK_____,eltGUIT__,eltQ_____,eltK_____,eltBULL__,eltTEN___,eltA_____,eltHAT___,eltJ_____,eltQ_____",
        "eltMAN___,eltJ_____,eltTEN___,eltROSE__,eltA_____,eltQ_____,eltMAN___,eltK_____,eltJ_____,eltHAT___,eltTEN___,eltA_____,eltFAN___,eltFAN___,eltFAN___,eltFAN___,eltK_____,eltQ_____,eltGUIT__,eltJ_____,eltTEN___",
        "eltMAN___,eltA_____,eltJ_____,eltBULL__,eltTEN___,eltK_____,eltROSE__,eltQ_____,eltTEN___,eltFAN___,eltFAN___,eltFAN___,eltK_____,eltA_____,eltBULL__,eltQ_____,eltJ_____,eltGUIT__,eltK_____,eltJ_____,eltHAT___,eltA_____,eltQ_____",

        "eltMAN___,eltA_____,eltK_____,eltROSE__,eltQ_____,eltTEN___,eltFAN___,eltFAN___,eltFAN___,eltK_____,eltJ_____,eltROSE__,eltA_____,eltTEN___,eltHAT___,eltA_____,eltJ_____,eltGUIT__,eltK_____,eltQ_____",
        "eltMAN___,eltQ_____,eltA_____,eltFAN___,eltFAN___,eltFAN___,eltFAN___,eltQ_____,eltJ_____,eltROSE__,eltK_____,eltTEN___,eltMAN___,eltJ_____,eltTEN___,eltGUIT__,eltA_____,eltTEN___,eltHAT___,eltK_____,eltJ_____",
        "eltMAN___,eltTEN___,eltK_____,eltROSE__,eltJ_____,eltQ_____,eltGUIT__,eltA_____,eltJ_____,eltFAN___,eltFAN___,eltFAN___,eltA_____,eltK_____,eltGUIT__,eltQ_____,eltK_____,eltROSE__,eltTEN___,eltA_____,eltHAT___,eltJ_____,eltQ_____",
        "eltMAN___,eltJ_____,eltTEN___,eltROSE__,eltA_____,eltQ_____,eltMAN___,eltK_____,eltJ_____,eltHAT___,eltTEN___,eltA_____,eltFAN___,eltFAN___,eltFAN___,eltFAN___,eltK_____,eltQ_____,eltGUIT__,eltJ_____,eltTEN___",
        "eltMAN___,eltA_____,eltJ_____,eltGUIT__,eltTEN___,eltK_____,eltROSE__,eltQ_____,eltTEN___,eltFAN___,eltFAN___,eltFAN___,eltK_____,eltA_____,eltHAT___,eltQ_____,eltJ_____,eltGUIT__,eltK_____,eltJ_____,eltHAT___,eltA_____,eltQ_____",
    };

    int idx = 0;
    for (int i = 0; i < m_vecReelStripPlan.size(); i++) {
        ReelSet set;
        for (int j = 0; j < m_nReel; j++) {
            ReelStrip strip;
            std::stringstream ss(eltReelStrip[idx]);
            std::string item;
            while (std::getline(ss, item, ',')) {
                strip.push_back(item);
            }
            set.push_back(strip);
            idx++;
        }
        m_vecReelStripSets.push_back(set);
    }

    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_tmp;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        std::map<std::string, std::map<UINT8, BONUS>> perSym;
        std::map<UINT8, BONUS> e;
        e[2].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 10; e[2].ag = 0;
        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 200; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 1000; e[5].ag = 0;
        perSym["eltMAN___"] = e;
        e.clear();

        e[2].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 2; e[2].ag = 0;
        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 500; e[5].ag = 0;
        perSym["eltFAN___"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 15; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 250; e[5].ag = 0;
        perSym["eltGUIT__"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 15; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 250; e[5].ag = 0;
        perSym["eltROSE__"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 15; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 250; e[5].ag = 0;
        perSym["eltHAT___"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[5].ag = 0;
        perSym["eltA_____"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[5].ag = 0;
        perSym["eltK_____"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[5].ag = 0;
        perSym["eltQ_____"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[5].ag = 0;
        perSym["eltJ_____"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[5].ag = 0;
        perSym["eltTEN___"] = e;
        e.clear();

        m_Bonus_tmp[i] = perSym;
    }

    m_Bonus_tmp[1]["eltMAN___"][5].coin = 0; m_Bonus_tmp[1]["eltMAN___"][5].ag = 2;

    m_Bonus_tmp[2]["eltMAN___"][5].coin = 0; m_Bonus_tmp[2]["eltMAN___"][5].ag = 3;
    m_Bonus_tmp[2]["eltFAN___"][5].coin = 500; m_Bonus_tmp[2]["eltFAN___"][5].ag = 1;

    m_Bonus_tmp[3]["eltMAN___"][5].coin = 0; m_Bonus_tmp[3]["eltMAN___"][5].ag = 4;
    m_Bonus_tmp[3]["eltFAN___"][5].coin = 0; m_Bonus_tmp[3]["eltFAN___"][5].ag = 2;

    m_Bonus_tmp[4]["eltMAN___"][5].coin = 0; m_Bonus_tmp[4]["eltMAN___"][5].ag = 5;
    m_Bonus_tmp[4]["eltFAN___"][5].coin = 500; m_Bonus_tmp[4]["eltFAN___"][5].ag = 2;
    m_Bonus_tmp[4]["eltGUIT__"][5].coin = 250; m_Bonus_tmp[4]["eltGUIT__"][5].ag = 1;
    m_Bonus_tmp[4]["eltROSE__"][5].coin = 250; m_Bonus_tmp[4]["eltROSE__"][5].ag = 1;
    m_Bonus_tmp[4]["eltHAT___"][5].coin = 250; m_Bonus_tmp[4]["eltHAT___"][5].ag = 1;

    m_Bonus_tmp[5]["eltMAN___"][5].coin = 0; m_Bonus_tmp[5]["eltMAN___"][5].ag = 6;
    m_Bonus_tmp[5]["eltMAN___"][4].coin = 200; m_Bonus_tmp[5]["eltMAN___"][4].ag = 1;
    m_Bonus_tmp[5]["eltFAN___"][5].coin = 0; m_Bonus_tmp[5]["eltFAN___"][5].ag = 3;
    m_Bonus_tmp[5]["eltGUIT__"][5].coin = 500; m_Bonus_tmp[5]["eltGUIT__"][5].ag = 1;
    m_Bonus_tmp[5]["eltROSE__"][5].coin = 500; m_Bonus_tmp[5]["eltROSE__"][5].ag = 1;
    m_Bonus_tmp[5]["eltHAT___"][5].coin = 500; m_Bonus_tmp[5]["eltHAT___"][5].ag = 1;

    m_Bonus_tmp[6]["eltMAN___"][5].coin = 0; m_Bonus_tmp[6]["eltMAN___"][5].ag = 8;
    m_Bonus_tmp[6]["eltMAN___"][4].coin = 600; m_Bonus_tmp[6]["eltMAN___"][4].ag = 1;
    m_Bonus_tmp[6]["eltFAN___"][5].coin = 0; m_Bonus_tmp[6]["eltFAN___"][5].ag = 4;
    m_Bonus_tmp[6]["eltGUIT__"][5].coin = 0; m_Bonus_tmp[6]["eltGUIT__"][5].ag = 2;
    m_Bonus_tmp[6]["eltROSE__"][5].coin = 0; m_Bonus_tmp[6]["eltROSE__"][5].ag = 2;
    m_Bonus_tmp[6]["eltHAT___"][5].coin = 0; m_Bonus_tmp[6]["eltHAT___"][5].ag = 2;

    m_Bonus_tmp[7]["eltMAN___"][5].coin = 0; m_Bonus_tmp[7]["eltMAN___"][5].ag = 10;
    m_Bonus_tmp[7]["eltMAN___"][4].coin = 0; m_Bonus_tmp[7]["eltMAN___"][4].ag = 2;
    m_Bonus_tmp[7]["eltFAN___"][5].coin = 0; m_Bonus_tmp[7]["eltFAN___"][5].ag = 5;
    m_Bonus_tmp[7]["eltGUIT__"][5].coin = 500; m_Bonus_tmp[7]["eltGUIT__"][5].ag = 2;
    m_Bonus_tmp[7]["eltROSE__"][5].coin = 500; m_Bonus_tmp[7]["eltROSE__"][5].ag = 2;
    m_Bonus_tmp[7]["eltHAT___"][5].coin = 500; m_Bonus_tmp[7]["eltHAT___"][5].ag = 2;

    m_Bonus_tmp[8]["eltMAN___"][5].coin = 0; m_Bonus_tmp[8]["eltMAN___"][5].ag = 15;
    m_Bonus_tmp[8]["eltMAN___"][4].coin = 0; m_Bonus_tmp[8]["eltMAN___"][4].ag = 3;
    m_Bonus_tmp[8]["eltFAN___"][5].coin = 500; m_Bonus_tmp[8]["eltFAN___"][5].ag = 7;
    m_Bonus_tmp[8]["eltFAN___"][4].coin = 500; m_Bonus_tmp[8]["eltFAN___"][4].ag = 1;
    m_Bonus_tmp[8]["eltGUIT__"][5].coin = 750; m_Bonus_tmp[8]["eltGUIT__"][5].ag = 3;
    m_Bonus_tmp[8]["eltROSE__"][5].coin = 750; m_Bonus_tmp[8]["eltROSE__"][5].ag = 3;
    m_Bonus_tmp[8]["eltHAT___"][5].coin = 750; m_Bonus_tmp[8]["eltHAT___"][5].ag = 3;
    m_Bonus_tmp[8]["eltA_____"][5].coin = 500; m_Bonus_tmp[8]["eltA_____"][5].ag = 1;
    m_Bonus_tmp[8]["eltK_____"][5].coin = 500; m_Bonus_tmp[8]["eltK_____"][5].ag = 1;
    m_Bonus_tmp[8]["eltQ_____"][5].coin = 500; m_Bonus_tmp[8]["eltQ_____"][5].ag = 1;
    m_Bonus_tmp[8]["eltJ_____"][5].coin = 500; m_Bonus_tmp[8]["eltJ_____"][5].ag = 1;
    m_Bonus_tmp[8]["eltTEN___"][5].coin = 500; m_Bonus_tmp[8]["eltTEN___"][5].ag = 1;

    m_Bonus_tmp[9]["eltMAN___"][5].coin = 0; m_Bonus_tmp[9]["eltMAN___"][5].ag = 20;
    m_Bonus_tmp[9]["eltMAN___"][4].coin = 0; m_Bonus_tmp[9]["eltMAN___"][4].ag = 4;
    m_Bonus_tmp[9]["eltFAN___"][5].coin = 0; m_Bonus_tmp[9]["eltFAN___"][5].ag = 10;
    m_Bonus_tmp[9]["eltFAN___"][4].coin = 0; m_Bonus_tmp[9]["eltFAN___"][4].ag = 2;
    m_Bonus_tmp[9]["eltGUIT__"][5].coin = 0; m_Bonus_tmp[9]["eltGUIT__"][5].ag = 5;
    m_Bonus_tmp[9]["eltROSE__"][5].coin = 0; m_Bonus_tmp[9]["eltROSE__"][5].ag = 5;
    m_Bonus_tmp[9]["eltHAT___"][5].coin = 0; m_Bonus_tmp[9]["eltHAT___"][5].ag = 5;
    m_Bonus_tmp[9]["eltA_____"][5].coin = 0; m_Bonus_tmp[9]["eltA_____"][5].ag = 2;
    m_Bonus_tmp[9]["eltK_____"][5].coin = 0; m_Bonus_tmp[9]["eltK_____"][5].ag = 2;
    m_Bonus_tmp[9]["eltQ_____"][5].coin = 0; m_Bonus_tmp[9]["eltQ_____"][5].ag = 2;
    m_Bonus_tmp[9]["eltJ_____"][5].coin = 0; m_Bonus_tmp[9]["eltJ_____"][5].ag = 2;
    m_Bonus_tmp[9]["eltTEN___"][5].coin = 0; m_Bonus_tmp[9]["eltTEN___"][5].ag = 2;

    m_Bonus_tmp[10]["eltMAN___"][5].coin = 0; m_Bonus_tmp[10]["eltMAN___"][5].ag = 50;
    m_Bonus_tmp[10]["eltMAN___"][4].coin = 0; m_Bonus_tmp[10]["eltMAN___"][4].ag = 10;
    m_Bonus_tmp[10]["eltMAN___"][3].coin = 500; m_Bonus_tmp[10]["eltMAN___"][3].ag = 2;
    m_Bonus_tmp[10]["eltFAN___"][5].coin = 0; m_Bonus_tmp[10]["eltFAN___"][5].ag = 25;
    m_Bonus_tmp[10]["eltFAN___"][4].coin = 0; m_Bonus_tmp[10]["eltFAN___"][4].ag = 5;
    m_Bonus_tmp[10]["eltGUIT__"][5].coin = 0; m_Bonus_tmp[10]["eltGUIT__"][5].ag = 13;
    m_Bonus_tmp[10]["eltROSE__"][5].coin = 0; m_Bonus_tmp[10]["eltROSE__"][5].ag = 13;
    m_Bonus_tmp[10]["eltHAT___"][5].coin = 0; m_Bonus_tmp[10]["eltHAT___"][5].ag = 13;
    m_Bonus_tmp[10]["eltGUIT__"][4].coin = 500; m_Bonus_tmp[10]["eltGUIT__"][4].ag = 2;
    m_Bonus_tmp[10]["eltROSE__"][4].coin = 500; m_Bonus_tmp[10]["eltROSE__"][4].ag = 2;
    m_Bonus_tmp[10]["eltHAT___"][4].coin = 500; m_Bonus_tmp[10]["eltHAT___"][4].ag = 2;
    m_Bonus_tmp[10]["eltA_____"][5].coin = 0; m_Bonus_tmp[10]["eltA_____"][5].ag = 5;
    m_Bonus_tmp[10]["eltK_____"][5].coin = 0; m_Bonus_tmp[10]["eltK_____"][5].ag = 5;
    m_Bonus_tmp[10]["eltQ_____"][5].coin = 0; m_Bonus_tmp[10]["eltQ_____"][5].ag = 5;
    m_Bonus_tmp[10]["eltJ_____"][5].coin = 0; m_Bonus_tmp[10]["eltJ_____"][5].ag = 5;
    m_Bonus_tmp[10]["eltTEN___"][5].coin = 0; m_Bonus_tmp[10]["eltTEN___"][5].ag = 5;

    m_Bonus_tmp[11]["eltMAN___"][5].coin = 0; m_Bonus_tmp[11]["eltMAN___"][5].ag = 50;
    m_Bonus_tmp[11]["eltMAN___"][4].coin = 0; m_Bonus_tmp[11]["eltMAN___"][4].ag = 10;
    m_Bonus_tmp[11]["eltMAN___"][3].coin = 0; m_Bonus_tmp[11]["eltMAN___"][3].ag = 5;
    m_Bonus_tmp[11]["eltFAN___"][5].coin = 0; m_Bonus_tmp[11]["eltFAN___"][5].ag = 50;
    m_Bonus_tmp[11]["eltFAN___"][4].coin = 0; m_Bonus_tmp[11]["eltFAN___"][4].ag = 10;
    m_Bonus_tmp[11]["eltFAN___"][3].coin = 0; m_Bonus_tmp[11]["eltFAN___"][3].ag = 2;
    m_Bonus_tmp[11]["eltGUIT__"][5].coin = 0; m_Bonus_tmp[11]["eltGUIT__"][5].ag = 25;
    m_Bonus_tmp[11]["eltROSE__"][5].coin = 0; m_Bonus_tmp[11]["eltROSE__"][5].ag = 25;
    m_Bonus_tmp[11]["eltHAT___"][5].coin = 0; m_Bonus_tmp[11]["eltHAT___"][5].ag = 25;
    m_Bonus_tmp[11]["eltGUIT__"][4].coin = 0; m_Bonus_tmp[11]["eltGUIT__"][4].ag = 5;
    m_Bonus_tmp[11]["eltROSE__"][4].coin = 0; m_Bonus_tmp[11]["eltROSE__"][4].ag = 5;
    m_Bonus_tmp[11]["eltHAT___"][4].coin = 0; m_Bonus_tmp[11]["eltHAT___"][4].ag = 5;
    m_Bonus_tmp[11]["eltGUIT__"][3].coin = 500; m_Bonus_tmp[11]["eltGUIT__"][3].ag = 1;
    m_Bonus_tmp[11]["eltROSE__"][3].coin = 500; m_Bonus_tmp[11]["eltROSE__"][3].ag = 1;
    m_Bonus_tmp[11]["eltHAT___"][3].coin = 500; m_Bonus_tmp[11]["eltHAT___"][3].ag = 1;
    m_Bonus_tmp[11]["eltA_____"][5].coin = 0; m_Bonus_tmp[11]["eltA_____"][5].ag = 10;
    m_Bonus_tmp[11]["eltK_____"][5].coin = 0; m_Bonus_tmp[11]["eltK_____"][5].ag = 10;
    m_Bonus_tmp[11]["eltA_____"][4].coin = 0; m_Bonus_tmp[11]["eltA_____"][4].ag = 2;
    m_Bonus_tmp[11]["eltK_____"][4].coin = 0; m_Bonus_tmp[11]["eltK_____"][4].ag = 2;
    m_Bonus_tmp[11]["eltQ_____"][5].coin = 0; m_Bonus_tmp[11]["eltQ_____"][5].ag = 10;
    m_Bonus_tmp[11]["eltJ_____"][5].coin = 0; m_Bonus_tmp[11]["eltJ_____"][5].ag = 10;
    m_Bonus_tmp[11]["eltTEN___"][5].coin = 0; m_Bonus_tmp[11]["eltTEN___"][5].ag = 10;
    m_Bonus_tmp[11]["eltQ_____"][4].coin = 0; m_Bonus_tmp[11]["eltQ_____"][4].ag = 2;
    m_Bonus_tmp[11]["eltJ_____"][4].coin = 0; m_Bonus_tmp[11]["eltJ_____"][4].ag = 2;
    m_Bonus_tmp[11]["eltTEN___"][4].coin = 0; m_Bonus_tmp[11]["eltTEN___"][4].ag = 2;

    int nSavedBetVal = 10;
    int _line = 0;
    string data;
    PlayDB::GetInstance().LoadCheckPoint(m_strGameName, nSavedBetVal, _line, m_strCheckPoint);
    if (nSavedBetVal == -1) {
        nSavedBetVal = 10;
    }

    BOOL start = FALSE;
    idx = 0;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_tmp, i) < AT(m_vecBetSteps, 0)) {
                continue;
            }
            start = TRUE;
        }
        
        // set betstep by saved value
        if (AT(m_vecBetSteps, idx) == nSavedBetVal) {
            m_nBetStep = idx;
        }

        m_Bonus[idx++] = m_Bonus_tmp[i];
        if (AT(m_vecBetSteps_tmp, i) == AT(m_vecBetSteps, m_vecBetSteps.size() - 1)) {
            break;
        }
    }

    m_vecBetSteps_05.clear();
    m_vecBetSteps_10.clear();
    PrintAllBonus();
}

UINT16 RgElToreroMG::Run() {
    m_nCurrentReelPlan = 0;// (myRandom() % m_vecReelStripPlan.size());
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));
    return m_shCurrentReelStrip;
}

void RgElToreroMG::ChangeReelStrip(UINT16 NewReelPlan) {
    m_nCurrentReelPlan = NewReelPlan;
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));
}

int RgElToreroMG::LineSwapDelay(int WinIdx) {
    if (m_vWinMeters.size() <= WinIdx) {
        return 1000;
    }
    auto soundItem = getSoundByID(m_vWinLineSounds[AT(m_vWinMeters, WinIdx).symbol + std::to_string(AT(m_vWinMeters, WinIdx).weight)]);
    return soundItem.duration;
}

BOOL RgElToreroMG::CanFreeMode() {
    if (NumberOfScatter() >= 3) {
        return TRUE;
    }
    return FALSE;
}

UINT8 RgElToreroMG::NumberOfScatter() {
    UINT8 n = 0;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int col = 0; col < m_nReel; col++) {
        int k = 0;
        for (; k < 3; k++) {
            std::string s = AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k);
            if (s == RgElToreroMG_scatter) {
                n++;
            }
        }
    }
    return n;
}

UINT16 RgElToreroMG::SpinTime_MS() {
    UINT8 n = NumberOfScatter();
    if (n >= 2 && NumberInCol(0) == TRUE && NumberInCol(2) == TRUE) {
        return 3000;
    }
    return 2000;
}

BOOL RgElToreroMG::NumberInCol(int col) {
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int k = 0; k < 3; k++) {
        std::string s = AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k);
        if (s == RgElToreroMG_scatter) {
            return TRUE;
        }
    }
    return FALSE;
}

myVector<UINT8> RgElToreroMG::Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) {
    m_nMagicCount = 0;

    BOOL mmcode = mmcode_get_active_status();
    if (mmcode == TRUE && bTest == FALSE) {
        ChangeReelStrip(0);
    }
    // avoid scatter (bull)
    myVector<UINT8> result;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);

    if (bTest) {
        std::string matchSymbol = AT(m_vecSymbols, myRandom() % (m_vecSymbols.size() - 1));
        int line = (myRandom() % m_nWinLine);
        int weight = 1 + (myRandom() % 5);

        BOOL bForceFree = (myRandom() % 10 == 0);
        for (int i = 0; i < m_nReel; i++) {
            ReelStrip reelStrip = AT(reelSet, i);
            int len = reelStrip.size() - 3;

            int valid_i[0x100];
            int valid_count = 0;
            myVector<int> freeSymbols;
            for (int j = 0; j <= len; j++) {
                if (weight > i) {
                    if (matchSymbol == AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                else {
                    if (matchSymbol != AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                if (AT(reelStrip, j) == RgElToreroMG_scatter && m_bFreeMode == FALSE) {
                    freeSymbols.push_back(j);
                }
            }
            if (valid_count > 0) {
                int rand_index = myRandom() % valid_count;
                int chosen_i = valid_i[rand_index];
                result.push_back(chosen_i + 1);
            }
            else {
                result.push_back((myRandom() % (len - 1)) + 1);
            }
            if (bForceFree && m_bFreeMode == FALSE && freeSymbols.size() > 0) {
                AT(result, result.size() - 1) =
                    AT(freeSymbols, myRandom() % freeSymbols.size()) - (myRandom() % 3) + 1;
            }
        }
    }
    else {
        result = _result;
        BOOL mmcode = mmcode_get_active_status();
        if (mmcode) {
            mmcode_set_deactive();
            if (m_bFreeMode == FALSE) {
                for (int j = 0; j < 5; j ++) {
                    myVector<int> candidateIndices;
                    for (int i = 2; i < AT(reelSet, j).size() - 3; ++i) {
                        if (j%2 == 0 && AT(AT(reelSet, j), i) == RgElToreroMG_scatter) {
                            int offset = myRandom() % 3;
                            int selectedIndex = i - 2 + offset;
                            candidateIndices.push_back(selectedIndex);
                        }
                        if (j%2 == 1 && AT(AT(reelSet, j), i) != RgElToreroMG_scatter
                                    && AT(AT(reelSet, j), i-2) != RgElToreroMG_scatter
                                    && AT(AT(reelSet, j), i-1) != RgElToreroMG_scatter
                                    && AT(AT(reelSet, j), i+1) != RgElToreroMG_scatter
                                    && AT(AT(reelSet, j), i+2) != RgElToreroMG_scatter) {
                            int offset = myRandom() % 3;
                            int selectedIndex = i - 2 + offset;
                            candidateIndices.push_back(selectedIndex);
                        }
                    }
                    if (!candidateIndices.empty()) {
#ifdef BIGBET_ACTIVE
                        int chosenIndex = AT(candidateIndices, (candidateIndices.size()<3?myRandom() % candidateIndices.size():myRandom() % 3));
#else
                        int chosenIndex = AT(candidateIndices, myRandom() % candidateIndices.size());
#endif
                        AT(result, j) = chosenIndex + 1;
                    }
                }
            }
        }
    }
    m_vWinResult = result;

    normalMeter = 0;
    maxMeter = 0;
    BONUS totalBonus = {0, 0};
    for (int i = 0; i < m_nWinLine; i++) {
        UINT16 meter = ((UINT16)1 << (2 - g_match_lines_10_5[i][0]));
        std::string firstSymbol = AT(AT(reelSet, 0), AT(result, 0) - 1 + g_match_lines_10_5[i][0]);
        if (IsWild(0, g_match_lines_10_5[i][0], firstSymbol)) {
            firstSymbol = RgElToreroMG_wild;
        }

        int maxWinBonus = 0;
        UINT16 maxWinMeter = 0;
        int maxWinWeight = 0;
        std::string maxWinSymbol = "";
        int j = 1;
        for (; j < m_nMaxMatch; j++) {
            std::string prev_symbol = AT(AT(reelSet, j - 1), AT(result, j - 1) - 1 + g_match_lines_10_5[i][j - 1]);
            std::string cur_symbol = AT(AT(reelSet, j), AT(result, j) - 1 + g_match_lines_10_5[i][j]);

            if (IsWild(j, g_match_lines_10_5[i][j], cur_symbol)) {
                meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));

                UINT32 bo = m_Bonus[BetStep()][firstSymbol][j + 1].coin + m_Bonus[BetStep()][firstSymbol][j + 1].ag * 1000;
                if (maxWinBonus < bo) {
                    maxWinBonus = bo;
                    maxWinMeter = meter;
                    maxWinSymbol = firstSymbol;
                    maxWinWeight = j + 1;
                }
                continue;
            }
            // wild card is not match A, K, Q, J, TEN
            /*if (
                (cur_symbol == "eltA_____" || cur_symbol == "eltK_____" || cur_symbol == "eltQ_____" || cur_symbol == "eltJ_____" || cur_symbol == "eltTEN___" || cur_symbol == RgElToreroMG_scatter) &&
                firstSymbol == RgElToreroMG_wild && j >= 2
                ) {                
                break;
            }*/
            if (firstSymbol == RgElToreroMG_wild) {
                firstSymbol = cur_symbol;
            }
            if (firstSymbol == cur_symbol) {
                meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
                UINT32 bo = m_Bonus[BetStep()][firstSymbol][j + 1].coin + m_Bonus[BetStep()][firstSymbol][j + 1].ag * 1000;
                if (maxWinBonus < bo) {
                    maxWinBonus = bo;
                    maxWinMeter = meter;
                    maxWinSymbol = firstSymbol;
                    maxWinWeight = j + 1;
                }
                continue;
            }
            break;
        }

        if (j < m_mapSymbolMinMatch[maxWinSymbol] || m_mapSymbolMinMatch[maxWinSymbol] == 0) {
            continue;
        }

        
        // monitor 2 meter
        std::string meterStr = m_mapSymbolMeterGoc[maxWinSymbol];
        size_t pos = meterStr.find('$');
        if (pos != std::string::npos) {
            meterStr = meterStr.replace(pos, 1, std::to_string(maxWinWeight));
        }

        WinMeter e;
        e.line = i;
        e.meter = maxWinMeter;
        e.meter2 = g_GrafficObjList.Str2GOCID(meterStr);
        e.symbol = maxWinSymbol;
        e.weight = maxWinWeight;
        e.start = 0;
        e.bonus = m_Bonus[BetStep()][maxWinSymbol][maxWinWeight];
        e.sound = MAX_SOUND_IDS;

        totalBonus.coin += e.bonus.coin;
        totalBonus.ag += e.bonus.ag;

        if (e.meter2 != -1) {
            meters.push_back(e);
        }
        if (j == m_nMaxMatch) {
            maxMeter |= meter;
        }
        else {
            normalMeter |= meter;
        }
    }
    int nScatter = CardCount(RgElToreroMG_scatter);
    if (nScatter >= 3) {
        bCanFreeMode = TRUE;

        UINT16 meter = 0;
        for (int i = 0; i < 3; i++) {
            for (int col = 0; col < m_nReel; col++) {
                std::string cur_symbol = AT(AT(reelSet, col), AT(result, col) - 1 + i);
                if (cur_symbol == RgElToreroMG_scatter) {
                    meter |= ((UINT16)1 << (3 * col + (2 - i)));
                }
            }
        }

        WinMeter e;
        e.line = 10;
        e.meter = meter;
        e.meter2 = 0;
        e.symbol = RgElToreroMG_scatter;
        e.weight = nScatter;
        e.start = 0;
        e.bonus = { 0, 0 };
        e.sound = MAX_SOUND_IDS;

        normalMeter |= meter;
        meters.push_back(e);
    }
    m_vWinMeters = meters;
    m_nMagicCount = totalBonus.ag;
    if (!bTest) {
        updateCheckPoint();

        if (m_vWinMeters.size() > 0) {
            if (m_bFreeMode) {
                m_nFreeModeTotalBonus.coin += totalBonus.coin;
                m_nFreeModeTotalBonus.ag += totalBonus.ag;
            }
            BonusSound = getSoundByID(m_vWinLineSounds[AT(m_vWinMeters, m_vWinMeters.size() - 1).symbol + std::to_string(AT(m_vWinMeters, m_vWinMeters.size() - 1).weight)]);
            BonusSound.soundID = MAX_SOUND_IDS;
        }
        else {
            BonusSound.duration = 0;
            BonusSound.soundID = MAX_SOUND_IDS;
        }
    }
    return result;
}

myVector<InterruptPacketData> RgElToreroMG::EnterFreeGame(std::string check) {
    m_bFreeMode = TRUE;
    m_nFreeModeTotalSpin = 10;
    m_nFreeModeGoneSpin = 0;
    m_nFreeModeTotalBonus = {0, 0};

    m_vWildCardsPositions.clear();
    ChangeReelStrip(5);

    myVector<InterruptPacketData> packets;
    if (check != "") {
        myVector<int> values = ParseCheckPoint(check, "F", 5);
        if (values.size() == 5) {
            m_nFreeModeTotalSpin = AT(values, 0);
            m_nFreeModeGoneSpin = AT(values, 1);
            m_nFreeModeTotalBonus.coin = AT(values, 2);
            m_nFreeModeTotalBonus.ag = AT(values, 3);
            UINT mask = AT(values, 4);
            for (int reel = 0; reel < 5; ++reel) {
                for (int row = 0; row < 3; ++row) {
                    int index = reel * 3 + row;
                    if (mask & (1u << index)) {
                        Position p;
                        p.reel = reel;
                        p.row = 2 - row;
                        m_vWildCardsPositions.push_back(p);
                    }
                }
            }
            UINT8 gone = (m_nFreeModeGoneSpin ? m_nFreeModeGoneSpin : 1);
            packets.push_back({ 0, 0, {0x01, 0x02, 0x30, 0x00, 0xb4, 0x19, gone, 0x00, m_nFreeModeTotalSpin, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa3, 0x04} });
            
            return packets;
        }
    }
    else {
        updateCheckPoint();
    }
    
    packets.push_back({ 0, 3000, {0x06, 0x23, 0x59, 0x01, 0x02, 0x30, 0x00, 0xb4, 0x19, 0x02, 0x00, m_nFreeModeTotalSpin, 0x00, 0x00, 0x00, 0x00, 0x00, 0xab, 0x04} });
    packets.push_back({ 0, 0, {0x01, 0x02, 0x30, 0x00, 0xb4, 0x19, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xac, 0x04} });
    packets.push_back({ 0, 500, {0x01, 0x02, 0x30, 0x00, 0xb4, 0x19, 0x01, 0x00, 0x0a, 0x00, 0x01, 0x00, 0x00, 0x00, 0xa3, 0x04} });
    
    return packets;
}

myVector<InterruptPacketData> RgElToreroMG::InterruptBeforeSpin() {
    myVector<InterruptPacketData> packets;
    if (!m_bFreeMode) {
        return packets;
    }
    m_nFreeModeGoneSpin++;
    updateCheckPoint();

    UINT8 gone = (m_nFreeModeGoneSpin ? m_nFreeModeGoneSpin : 1);
    packets.push_back({
        0,
        0,
        {
            0x01, 0x02, 0x30, 0x00, 0xb4, 0x19, gone, 0x00, m_nFreeModeTotalSpin, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa5, 0x04
        }
        });
    return packets;
}

myVector<InterruptPacketData> RgElToreroMG::InterruptAfterMoveBonus(BOOL& EndFree) {
    myVector<InterruptPacketData> packets;
    if (m_nFreeModeGoneSpin >= m_nFreeModeTotalSpin) {
        EndFree = TRUE;
        m_bFreeMode = FALSE;
        ChangeReelStrip(0);
        
        // return to main game
        packets.push_back({
             0,
             0,
             {0x01, 0x02, 0x30, 0x00, 0xb4, 0x19, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa4, 0x04} });
        // show result dialog
        packets.push_back({
             0,
             2000,
             {0x06, 0x23, 0x59, 0x01, 0x02, 0x30, 0x00, 0xb4, 0x19, 0x00, 0x00, 
             static_cast<BYTE>(m_nFreeModeTotalBonus.coin & 0xFF), 
             static_cast<BYTE>((m_nFreeModeTotalBonus.coin >> 8) & 0xFF), 
             static_cast<BYTE>((m_nFreeModeTotalBonus.coin >> 16) & 0xFF),
             static_cast<BYTE>((m_nFreeModeTotalBonus.coin >> 24) & 0xFF),             
             0x0a, 0x00, 0xab, 0x04} });
        // hide result dialog
        packets.push_back({
            0,
            500,
            {0x01, 0x02, 0x30, 0x00, 0xb4, 0x19, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xac, 0x04} });
        
        updateCheckPoint();

        return packets;
    }    
    EndFree = FALSE;
    //m_nFreeModeGoneSpin++;
    updateCheckPoint();

    return packets;
}

BOOL RgElToreroMG::stopAllSoundBeforeMove() {
    return TRUE;
}

UINT8 RgElToreroMG::CardCount(std::string card) {
    int n = 0;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int col = 0; col < m_nReel; col++) {
        int k = 0;
        for (; k < 3; k++) {
            std::string s = AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k);
            if (s == card) {
                n++;
            }
        }
    }
    return n;
}

myVector<InterruptPacketData> RgElToreroMG::InterruptAfterSpin() {
    myVector<InterruptPacketData> packets;
    if (m_bFreeMode) {
        
        BOOL newScatter = FALSE;
        ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
        for (int col = 0; col < m_nReel; col++) {
            int k = 0;
            for (; k < 3; k++) {
                std::string s = AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k);
                if (s == RgElToreroMG_wild) {
                    Position p = {col, k};
                    auto it = std::find_if(m_vWildCardsPositions.begin(), m_vWildCardsPositions.end(),
                        [&](const Position& pos) {
                            return pos.reel == p.reel && pos.row == p.row; // adjust member names
                        });

                    if (it == m_vWildCardsPositions.end()) {
                        m_vWildCardsPositions.push_back(p);
                        newScatter = TRUE;
                    }
                }
            }
        }
        if (newScatter) {
            // fix wild cards
            packets.push_back({ 0, 1500, {0x06, 0xb4, 0x19, 0x01, 0x02, 0x31, 0x00, 0x02, 0x00, 0xb4, 0x19, 0xce, 0x00, 0x00, 0x04} });
        }
    }
    updateCheckPoint();
    return packets;
}

BOOL RgElToreroMG::IsWild(UINT8 reel, UINT8 row, std::string card) {
    if (card == RgElToreroMG_wild) {
        return TRUE;
    }
    if (m_bFreeMode) {
        for (int i = 0; i < m_vWildCardsPositions.size(); i++) {
            if (AT(m_vWildCardsPositions, i).reel == reel && AT(m_vWildCardsPositions, i).row == row) {
                return TRUE;
            }
        }
    }
    return FALSE;
}

UINT16 RgElToreroMG::MagicCount() {
    if (m_bFreeMode) {
        return 0;
    }
    else {
        return m_nMagicCount;
    }
}

myVector<UINT8> RgElToreroMG::ShowTotalWinLines(myVector<WinMeter> SpinMeters) {
    myVector<uint8_t> packet = {
        0x06, 0x30, 0x59, 0x01, 0x02, 0x31, 0x00,
        0x0F, 0x00,  // Placeholder for length 
        0x0F, 0x11, // GameID
        0x9C, 0x19, 0x01
    };
    myVector<UINT8> TotalMatch;
    for (int i = 0; i < SpinMeters.size(); i++) {
        if (AT(SpinMeters, i).line == 0xFF) { // clear after convert action
            TotalMatch.clear();
            continue;
        }
        TotalMatch.push_back(AT(SpinMeters, i).line);
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter >> 8) & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter2 & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter2 >> 8) & 0xFF));
    }
    if (TotalMatch.size() < 10) {
        myVector<UINT8> _;
        return _;
    }
    UINT16 pktLen = 1 + (TotalMatch.size() / 5) * 7;
    AT(packet, 7) = static_cast<BYTE>(pktLen & 0xFF);
    AT(packet, 8) = static_cast<BYTE>((pktLen >> 8) & 0xFF);
    AT(packet, 9) = static_cast<BYTE>(m_nGameID & 0xFF);
    AT(packet, 10) = static_cast<BYTE>((m_nGameID >> 8) & 0xFF);
    int entryCount = static_cast<int>(TotalMatch.size() / 5);
    for (int i = 0; i < entryCount; ++i) {
        packet.push_back(AT(TotalMatch, i * 5 + 0)); // Line
        packet.push_back(AT(TotalMatch, i * 5 + 1)); // Meter low byte
        packet.push_back(AT(TotalMatch, i * 5 + 2)); // Meter high byte
        packet.push_back(AT(TotalMatch, i * 5 + 3)); // Meter2 low byte
        packet.push_back(AT(TotalMatch, i * 5 + 4)); // Meter2 high byte
        packet.push_back(0x01);      // Status or flag 1
        packet.push_back(0x01);      // Status or flag 2
    }
    // Mark the end of the packet
    packet.back() = 0x04;
    return packet;
}

BOOL RgElToreroMG::SelectedableReelsInFreeGame(myVector<UINT8> result) {
    if (m_bFreeMode == FALSE) {
        return TRUE;
    }
    myVector<UINT8> cp = m_vWinResult;
    m_vWinResult = result;
    int n = CardCount(RgElToreroMG_scatter);
    m_vWinResult = cp;
    if (n >= 3) {
        return FALSE;
    }
    return TRUE;
}

void RgElToreroMG::updateCheckPoint() {
    std::ostringstream oss;
    oss << " P" << m_nCurrentReelPlan
        << " B"
        << static_cast<int>(AT(m_vWinResult, 0)) << ":"
        << static_cast<int>(AT(m_vWinResult, 1)) << ":"
        << static_cast<int>(AT(m_vWinResult, 2)) << ":"
        << static_cast<int>(AT(m_vWinResult, 3)) << ":"
        << static_cast<int>(AT(m_vWinResult, 4)) << " ";

    if (m_bFreeMode) {
        UINT16 mask = 0;
        for (int i = 0; i < m_vWildCardsPositions.size(); i++) {
            mask |= (1u << (AT(m_vWildCardsPositions, i).reel * 3 + (2 - AT(m_vWildCardsPositions, i).row)));
        }
        oss << " F"
            << static_cast<int>(m_nFreeModeTotalSpin) << ":"
            << static_cast<int>(m_nFreeModeGoneSpin) << ":"
            << static_cast<int>(m_nFreeModeTotalBonus.coin) << ":"
            << static_cast<int>(m_nFreeModeTotalBonus.ag) << ":"
            << static_cast<int>(mask) << " ";
    }
    m_strCheckPoint = oss.str();
}