#include "stdafx.h"
#include "RgExtraWild.h"

#define RgExtraWild_wild "Wild1EXWI"
#define RgExtraWild_top "High1EXWI"
RgExtraWild::RgExtraWild() {
    m_nReel = 5;
    m_nWinLine = 10;
    m_nMaxMatch = 5;
    m_nBetStep = 0;

    m_strGameName = "RgExtraWild";

    myVector<UINT16> m_vecBetSteps_tmp;
    m_vecBetSteps_tmp.push_back(5);
    m_vecBetSteps_tmp.push_back(10);
    m_vecBetSteps_tmp.push_back(20);
    m_vecBetSteps_tmp.push_back(30);
    m_vecBetSteps_tmp.push_back(40);
    m_vecBetSteps_tmp.push_back(50);
    m_vecBetSteps_tmp.push_back(60);
    m_vecBetSteps_tmp.push_back(80);
    m_vecBetSteps_tmp.push_back(100);
    m_vecBetSteps_tmp.push_back(150);
    m_vecBetSteps_tmp.push_back(200);
#ifdef BIGBET_ACTIVE
    m_vecBetSteps_tmp.push_back(500);
    m_vecBetSteps_tmp.push_back(1000);
#endif
    LoadBets();

    m_vecSymbols.push_back("Low5EXWI");
    m_vecSymbols.push_back("Low4EXWI");
    m_vecSymbols.push_back("Low3EXWI");
    m_vecSymbols.push_back("Low2EXWI");
    m_vecSymbols.push_back("Low1EXWI");
    m_vecSymbols.push_back("High3EXWI");
    m_vecSymbols.push_back("High2EXWI");
    m_vecSymbols.push_back("High1EXWI");
    m_vecSymbols.push_back("Wild1EXWI");

    m_mapSymbolMinMatch["Low5EXWI"] = 3;
    m_mapSymbolMinMatch["Low4EXWI"] = 3;
    m_mapSymbolMinMatch["Low3EXWI"] = 3;
    m_mapSymbolMinMatch["Low2EXWI"] = 3;
    m_mapSymbolMinMatch["Low1EXWI"] = 3;
    m_mapSymbolMinMatch["High3EXWI"] = 3;
    m_mapSymbolMinMatch["High2EXWI"] = 3;
    m_mapSymbolMinMatch["High1EXWI"] = 3;
    m_mapSymbolMinMatch["Wild1EXWI"] = 1;

    m_mapSymbolMeterGoc["Low5EXWI"] = "Low2EXWI$x";
    m_mapSymbolMeterGoc["Low4EXWI"] = "Low2EXWI$x";
    m_mapSymbolMeterGoc["Low3EXWI"] = "Low2EXWI$x";
    m_mapSymbolMeterGoc["Low2EXWI"] = "Low1EXWI$x";
    m_mapSymbolMeterGoc["Low1EXWI"] = "Low1EXWI$x";
    m_mapSymbolMeterGoc["High3EXWI"] = "High3EXWI$x";
    m_mapSymbolMeterGoc["High2EXWI"] = "High2EXWI$x";
    m_mapSymbolMeterGoc["High1EXWI"] = "High1EXWI$x";
    m_mapSymbolMeterGoc["Wild1EXWI"] = "Wild_EXWI1x";

    m_vecWinLines.push_back("WinL1EXWI");
    m_vecWinLines.push_back("WinL2EXWI");
    m_vecWinLines.push_back("WinL3EXWI");
    m_vecWinLines.push_back("WinL4EXWI");
    m_vecWinLines.push_back("WinL5EXWI");
    m_vecWinLines.push_back("WinL6EXWI");
    m_vecWinLines.push_back("WinL7EXWI");
    m_vecWinLines.push_back("WinL8EXWI");
    m_vecWinLines.push_back("WinL9EXWI");
    m_vecWinLines.push_back("WinL10EXWI");
    m_vecWinLines.push_back("WinScatEXWI");

    m_vecLineSounds.push_back(SMP_EXWI_bet01);
    m_vecLineSounds.push_back(SMP_EXWI_bet02);
    m_vecLineSounds.push_back(SMP_EXWI_bet03);
    m_vecLineSounds.push_back(SMP_EXWI_bet04);
    m_vecLineSounds.push_back(SMP_EXWI_bet05);
    m_vecLineSounds.push_back(SMP_EXWI_bet06);
    m_vecLineSounds.push_back(SMP_EXWI_bet07);
    m_vecLineSounds.push_back(SMP_EXWI_bet08);
    m_vecLineSounds.push_back(SMP_EXWI_bet09);
    m_vecLineSounds.push_back(SMP_EXWI_bet10);

    m_vecWinSounds.push_back(SMP_EXWI_winsound_01);
    m_vecWinSounds.push_back(SMP_EXWI_winsound_02);
    m_vecWinSounds.push_back(SMP_EXWI_winsound_03);
    m_vecWinSounds.push_back(SMP_EXWI_winsound_04);
    m_vecWinSounds.push_back(SMP_EXWI_winsound_05);
    m_vecWinSounds.push_back(SMP_EXWI_winsound_06);
    m_vecWinSounds.push_back(SMP_EXWI_winsound_07);
    m_vecWinSounds.push_back(SMP_EXWI_winsound_08);

    m_vecReelStripPlan.push_back("Walze1EXWI");
    m_vecReelStripPlan.push_back("Walze1WTEXWI");
    
    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));

    char* exwiReelStrip[] = {
        "High3EXWI,High3EXWI,High3EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low1EXWI,Low1EXWI,Low1EXWI,Low2EXWI,Low2EXWI,Low2EXWI,Low2EXWI,High3EXWI,High3EXWI,High3EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low1EXWI,Low1EXWI,Low1EXWI,Low2EXWI,Low2EXWI,Low2EXWI,Low2EXWI,Low4EXWI,Low4EXWI,Low4EXWI,High3EXWI,High3EXWI,High3EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low3EXWI,High1EXWI,High1EXWI,High1EXWI,Low2EXWI,Low2EXWI,Low2EXWI,Low2EXWI,High3EXWI,High3EXWI,High3EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low3EXWI,High2EXWI,High2EXWI,High2EXWI,Low2EXWI,Low2EXWI,Low2EXWI",
        "High2EXWI,High2EXWI,High2EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low1EXWI,Low1EXWI,Low1EXWI,Low1EXWI,High2EXWI,High2EXWI,High2EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low1EXWI,Low1EXWI,Low1EXWI,Low1EXWI,High2EXWI,High2EXWI,High2EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low5EXWI,High3EXWI,High3EXWI,High3EXWI,Low2EXWI,Low2EXWI,Low2EXWI,Low1EXWI,Low1EXWI,Low1EXWI,Low1EXWI,High2EXWI,High2EXWI,High2EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low5EXWI,Low5EXWI,Low5EXWI,High1EXWI,High1EXWI,High1EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low2EXWI,Low2EXWI,Low2EXWI,Low1EXWI,Low1EXWI,Low1EXWI",
        "High1EXWI,High1EXWI,High1EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Wild1EXWI,Wild1EXWI,Wild1EXWI,Low4EXWI,Low4EXWI,Low4EXWI,High2EXWI,High2EXWI,High2EXWI,Low2EXWI,Low2EXWI,Low2EXWI,High3EXWI,High3EXWI,High3EXWI,Low1EXWI,Low1EXWI,Low1EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low4EXWI,Low4EXWI,Low4EXWI,High2EXWI,High2EXWI,High2EXWI,Low2EXWI,Low2EXWI,Low2EXWI,High3EXWI,High3EXWI,High3EXWI,Low1EXWI,Low1EXWI,Low1EXWI,Low3EXWI,Low3EXWI,Low3EXWI,High1EXWI,High1EXWI,High1EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low2EXWI,Low2EXWI,Low2EXWI,High3EXWI,High3EXWI,High3EXWI,Low1EXWI,Low1EXWI,Low1EXWI,Low3EXWI,Low3EXWI,Low3EXWI,High1EXWI,High1EXWI,High1EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low4EXWI,Low4EXWI,Low4EXWI,High2EXWI,High2EXWI,High2EXWI,Low2EXWI,Low2EXWI,Low2EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low1EXWI,Low1EXWI,Low1EXWI,Low3EXWI,Low3EXWI,Low3EXWI",
        "High3EXWI,High3EXWI,High3EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low1EXWI,Low1EXWI,Low1EXWI,Low2EXWI,Low2EXWI,Low2EXWI,Low2EXWI,High3EXWI,High3EXWI,High3EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low1EXWI,Low1EXWI,Low1EXWI,Low2EXWI,Low2EXWI,Low2EXWI,Low2EXWI,Low4EXWI,Low4EXWI,Low4EXWI,High3EXWI,High3EXWI,High3EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low3EXWI,High1EXWI,High1EXWI,High1EXWI,Low2EXWI,Low2EXWI,Low2EXWI,Low2EXWI,High3EXWI,High3EXWI,High3EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low3EXWI,High2EXWI,High2EXWI,High2EXWI,Low2EXWI,Low2EXWI,Low2EXWI",
        "High2EXWI,High2EXWI,High2EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low1EXWI,Low1EXWI,Low1EXWI,Low1EXWI,High2EXWI,High2EXWI,High2EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low1EXWI,Low1EXWI,Low1EXWI,Low1EXWI,High2EXWI,High2EXWI,High2EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low5EXWI,High3EXWI,High3EXWI,High3EXWI,Low2EXWI,Low2EXWI,Low2EXWI,Low1EXWI,Low1EXWI,Low1EXWI,Low1EXWI,High2EXWI,High2EXWI,High2EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low5EXWI,Low5EXWI,Low5EXWI,High1EXWI,High1EXWI,High1EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low2EXWI,Low2EXWI,Low2EXWI,Low1EXWI,Low1EXWI,Low1EXWI",

        "High3EXWI,High3EXWI,High3EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low5EXWI,High3EXWI,High3EXWI,High3EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low1EXWI,Low1EXWI,Low1EXWI,Low1EXWI,Low2EXWI,Low2EXWI,Low2EXWI,Low2EXWI,High3EXWI,High3EXWI,High3EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low4EXWI,High1EXWI,High1EXWI,High1EXWI,Low2EXWI,Low2EXWI,Low2EXWI,Low2EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low3EXWI,High2EXWI,High2EXWI,High2EXWI,Low1EXWI,Low1EXWI,Low1EXWI,Low1EXWI,Low2EXWI,Low2EXWI,Low2EXWI,Low2EXWI",
        "High2EXWI,High2EXWI,High2EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low1EXWI,Low1EXWI,Low1EXWI,Low1EXWI,High3EXWI,High3EXWI,High3EXWI,Low2EXWI,Low2EXWI,Low2EXWI,Low2EXWI,Low1EXWI,Low1EXWI,Low1EXWI,Low1EXWI,High1EXWI,High1EXWI,High1EXWI,Low2EXWI,Low2EXWI,Low2EXWI,Low2EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low4EXWI,High2EXWI,High2EXWI,High2EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low1EXWI,Low1EXWI,Low1EXWI,Low1EXWI,High2EXWI,High2EXWI,High2EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low4EXWI",
        "High3EXWI,High3EXWI,High3EXWI,Low1EXWI,Low1EXWI,Low1EXWI,Low1EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low4EXWI,High2EXWI,High2EXWI,High2EXWI,Low2EXWI,Low2EXWI,Low2EXWI,Low2EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low3EXWI,High1EXWI,High1EXWI,High1EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Wild1EXWI,Wild1EXWI,Wild1EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low4EXWI,High2EXWI,High2EXWI,High2EXWI,Low2EXWI,Low2EXWI,Low2EXWI,Low2EXWI,High3EXWI,High3EXWI,High3EXWI,Low1EXWI,Low1EXWI,Low1EXWI,Low1EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low3EXWI,High1EXWI,High1EXWI,High1EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low2EXWI,Low2EXWI,Low2EXWI,Low2EXWI,High3EXWI,High3EXWI,High3EXWI,Low1EXWI,Low1EXWI,Low1EXWI,Low1EXWI,High1EXWI,High1EXWI,High1EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low5EXWI,High2EXWI,High2EXWI,High2EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low5EXWI",
        "High3EXWI,High3EXWI,High3EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low2EXWI,Low2EXWI,Low2EXWI,Low2EXWI,High3EXWI,High3EXWI,High3EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low2EXWI,Low2EXWI,Low2EXWI,Low2EXWI,High3EXWI,High3EXWI,High3EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low1EXWI,Low1EXWI,Low1EXWI,Low1EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low4EXWI,High1EXWI,High1EXWI,High1EXWI,Low2EXWI,Low2EXWI,Low2EXWI,Low2EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low3EXWI,High2EXWI,High2EXWI,High2EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low1EXWI,Low1EXWI,Low1EXWI,Low1EXWI",
        "High2EXWI,High2EXWI,High2EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low4EXWI,High2EXWI,High2EXWI,High2EXWI,Low1EXWI,Low1EXWI,Low1EXWI,Low1EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low5EXWI,High3EXWI,High3EXWI,High3EXWI,Low2EXWI,Low2EXWI,Low2EXWI,Low2EXWI,Low1EXWI,Low1EXWI,Low1EXWI,Low1EXWI,High2EXWI,High2EXWI,High2EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low5EXWI,Low4EXWI,Low4EXWI,Low4EXWI,Low4EXWI,High1EXWI,High1EXWI,High1EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low3EXWI,Low2EXWI,Low2EXWI,Low2EXWI,Low2EXWI,Low1EXWI,Low1EXWI,Low1EXWI,Low1EXWI",
    };

    int idx = 0;
    for (int i = 0; i < m_vecReelStripPlan.size(); i++) {
        ReelSet set;
        for (int j = 0; j < m_nReel; j++) {
            ReelStrip strip;
            std::stringstream ss(exwiReelStrip[idx]);
            std::string item;
            while (std::getline(ss, item, ',')) {
                strip.push_back(item);
            }
            set.push_back(strip);
            idx++;
        }
        m_vecReelStripSets.push_back(set);
    }

    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_tmp;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        int n = (i <= 1) ? 1 : (AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 1));
        std::map<std::string, std::map<UINT8, BONUS>> perSym;
        std::map<UINT8, BONUS> e;        
        e[3].coin = n * 10; e[3].ag = 0;
        e[4].coin = n * 25; e[4].ag = 0;
        e[5].coin = n * 150; e[5].ag = 0;
        perSym["Low5EXWI"] = e;
        e.clear();

        e[3].coin = n * 10; e[3].ag = 0;
        e[4].coin = n * 25; e[4].ag = 0;
        e[5].coin = n * 150; e[5].ag = 0;
        perSym["Low4EXWI"] = e;
        e.clear();

        e[3].coin = n * 10; e[3].ag = 0;
        e[4].coin = n * 25; e[4].ag = 0;
        e[5].coin = n * 150; e[5].ag = 0;
        perSym["Low3EXWI"] = e;
        e.clear();

        e[3].coin = n * 15; e[3].ag = 0;
        e[4].coin = n * 50; e[4].ag = 0;
        e[5].coin = n * 200; e[5].ag = 0;
        perSym["Low2EXWI"] = e;
        e.clear();

        e[3].coin = n * 15; e[3].ag = 0;
        e[4].coin = n * 50; e[4].ag = 0;
        e[5].coin = n * 200; e[5].ag = 0;
        perSym["Low1EXWI"] = e;
        e.clear();

        e[3].coin = n * 30; e[3].ag = 0;
        e[4].coin = n * 150; e[4].ag = 0;
        e[5].coin = n * 500; e[5].ag = 0;
        perSym["High3EXWI"] = e;
        e.clear();

        e[3].coin = n * 30; e[3].ag = 0;
        e[4].coin = n * 150; e[4].ag = 0;
        e[5].coin = n * 500; e[5].ag = 0;
        perSym["High2EXWI"] = e;
        e.clear();

        e[3].coin = n * 50; e[3].ag = 0;
        e[4].coin = n * 500; e[4].ag = 0;
        e[5].coin = n * 5000; e[5].ag = 0;
        perSym["High1EXWI"] = e;
        e.clear();

        e[1].coin = (AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0)) * 5; e[3].ag = 0;
        perSym["Wild1EXWI"] = e;
        e.clear();

        m_Bonus_tmp[i] = perSym;
    }
    m_Bonus_tmp[m_vecBetSteps_tmp.size() - 1 - BIGBET_BETSTEP_EXTRA_COUNT]["High1EXWI"][5].coin = 50000;
    m_Bonus_tmp[m_vecBetSteps_tmp.size() - 1 - BIGBET_BETSTEP_EXTRA_COUNT]["High1EXWI"][4].coin = 12500;

    m_Bonus_tmp[m_vecBetSteps_tmp.size() - 2 - BIGBET_BETSTEP_EXTRA_COUNT]["High1EXWI"][5].coin = 50000;
    m_Bonus_tmp[m_vecBetSteps_tmp.size() - 2 - BIGBET_BETSTEP_EXTRA_COUNT]["High1EXWI"][4].coin = 10000;

    int nSavedBetVal = 10;
    int _line = 0;
    string data;
    PlayDB::GetInstance().LoadCheckPoint(m_strGameName, nSavedBetVal, _line, m_strCheckPoint);
    if (nSavedBetVal == -1) {
        nSavedBetVal = 10;
    }

    BOOL start = FALSE;
    idx = 0;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_tmp, i) < AT(m_vecBetSteps, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps, idx) == nSavedBetVal) {
            m_nBetStep = idx;
        }

        m_Bonus[idx++] = m_Bonus_tmp[i];
        if (AT(m_vecBetSteps_tmp, i) == AT(m_vecBetSteps, m_vecBetSteps.size() - 1)) {
            break;
        }
    }

    m_vecBetSteps_05.clear();
    m_vecBetSteps_10.clear();
    PrintAllBonus();
}

UINT16 RgExtraWild::Run() {
#ifdef TEST_WILD
    m_nCurrentReelPlan = 0;
#else
    m_nCurrentReelPlan = (myRandom() % m_vecReelStripPlan.size());
#endif
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));
    return m_shCurrentReelStrip;
}

myVector<UINT8> RgExtraWild::Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) {
    myVector<UINT8> result;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);

    BOOL mmcode = FALSE;
    if (bTest == FALSE) {
        mmcode = mmcode_get_active_status();
    }
    if (bTest == TRUE || mmcode == TRUE) {
        std::string matchSymbol = AT(m_vecSymbols, myRandom() % m_vecSymbols.size());

        int line = (myRandom() % (BetBit() == 5 ? 5 : 10));
        int weight = 1 + (myRandom() % 5);

        if (mmcode) {
            mmcode_set_deactive();
            weight = m_nMaxMatch;
            matchSymbol = "High3EXWI";
        }
        for (int i = 0; i < m_nReel; i++) {
            ReelStrip reelStrip = AT(reelSet, i);
            int len = reelStrip.size() - 3;

            int valid_i[0x100];
            int valid_count = 0;
            for (int j = 0; j <= len; j++) {
                if (weight > i) {
                    if (matchSymbol == AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                else {
                    if (matchSymbol != AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
            }
            if (valid_count > 0) {
                int rand_index = myRandom() % valid_count;
                int chosen_i = valid_i[rand_index];
                result.push_back(chosen_i + 1);
            }
            else {
                result.push_back((myRandom() % (len - 1)) + 1);
            }
        }
#ifdef TEST_WILD
        AT(result, 2) = 7 + (myRandom() % 3);
#endif
    }
    else {
        result = _result;
    }
    //TEST_REEL5_ESTIMATE(result, 67);
    m_mapWildMatch[0] = 0;
    m_mapWildMatch[1] = 0;
    m_mapWildMatch[2] = 0;

    std::map<UINT8, UINT8> mapLine2WildRow;
    normalMeter = 0;
    maxMeter = 0;
    UINT32 totalBonus = 0;
    for (int i = 0; i < (BetBit() == 5 ? 5 : 10); i++) {
        int j = 1;
        UINT16 meter = ((UINT16)1 << (2 - g_match_lines_10_5[i][0]));
        std::string firstSymbol = AT(AT(reelSet, 0), AT(result, 0) - 1 + g_match_lines_10_5[i][0]);

        int nMatched = 1;
        int wildRow = -1;
        for (; j < m_nMaxMatch; j++) {
            std::string prev_symbol = AT(AT(reelSet, j - 1), AT(result, j - 1) - 1 + g_match_lines_10_5[i][j - 1]);
            std::string cur_symbol = AT(AT(reelSet, j), AT(result, j) - 1 + g_match_lines_10_5[i][j]);
            
            if (firstSymbol == RgExtraWild_wild) {
                firstSymbol = cur_symbol;                
            }
            if (cur_symbol == RgExtraWild_wild) {
                wildRow = 2 - g_match_lines_10_5[i][j];// from top
            }

            if (firstSymbol == cur_symbol || cur_symbol == RgExtraWild_wild) {
                meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
                nMatched++;
                continue;
            }
            if (j >= 3) {
                if (j == 3 && nMatched < 3 && prev_symbol == RgExtraWild_wild) {
                    nMatched = 2;
                    firstSymbol = cur_symbol;
                    meter = ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
                    meter |= ((UINT16)1 << (3 * (j - 1) + 2 - g_match_lines_10_5[i][j - 1]));
                    wildRow = 2 - g_match_lines_10_5[i][j - 1];// from top
                    continue;
                }
                if (nMatched == 3) { // choose from right or left to get higher value when wild in col 2
                    if (AT(AT(reelSet, 2), AT(result, 2) - 1 + g_match_lines_10_5[i][2]) == RgExtraWild_wild
                        ) {
                        std::string symbol0 = AT(AT(reelSet, 0), AT(result, 0) - 1 + g_match_lines_10_5[i][0]);
                        std::string symbol3 = AT(AT(reelSet, 3), AT(result, 3) - 1 + g_match_lines_10_5[i][3]);
                        std::string symbol4 = AT(AT(reelSet, 4), AT(result, 4) - 1 + g_match_lines_10_5[i][4]);
                        if (symbol3 == symbol4) {
                            if (m_Bonus[BetStep()][symbol0][4].coin >= m_Bonus[BetStep()][symbol4][4].coin) {
                                firstSymbol = symbol0;
                                meter = ((UINT16)1 << (3 * 0 + 2 - g_match_lines_10_5[i][0]));
                                meter |= ((UINT16)1 << (3 * 1 + 2 - g_match_lines_10_5[i][1]));
                                meter |= ((UINT16)1 << (3 * 2 + 2 - g_match_lines_10_5[i][2]));
                            }
                            else {
                                firstSymbol = symbol4;
                                meter = ((UINT16)1 << (3 * 2 + 2 - g_match_lines_10_5[i][2]));
                                meter |= ((UINT16)1 << (3 * 3 + 2 - g_match_lines_10_5[i][3]));
                                meter |= ((UINT16)1 << (3 * 4 + 2 - g_match_lines_10_5[i][4]));
                            }
                        }
                    }
                }
                break;
            }
            nMatched = 1;
            firstSymbol = cur_symbol;
            meter = ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
            wildRow = -1;
        }
        if (nMatched < m_mapSymbolMinMatch[firstSymbol]) {
            continue;
        }
        if (wildRow != -1) {
            m_mapWildMatch[wildRow] = 1;
            mapLine2WildRow[i] = wildRow + 1;
        }
        // monitor 2 meter
        std::string meterStr = m_mapSymbolMeterGoc[firstSymbol];
        size_t pos = meterStr.find('$');
        if (pos != std::string::npos) {
            meterStr = meterStr.replace(pos, 1, std::to_string(nMatched));
        }
        WinMeter e;
        e.line = i;
        e.meter = meter;
        e.meter2 = g_GrafficObjList.Str2GOCID(meterStr);
        e.symbol = firstSymbol;
        e.weight = nMatched;
        e.start = 0;
        e.bonus = m_Bonus[BetStep()][firstSymbol][nMatched];
        e.sound = MAX_SOUND_IDS;
        
        meters.push_back(e);
        if (nMatched == m_nMaxMatch) {
            maxMeter |= meter;
        }
        else {
            normalMeter |= meter;
        }
    }

    // Handle Extra Wild matches in reel 2
    for (int i = 0; i < 3; ++i) {
        if (m_mapWildMatch[2 - i] != 0)
            continue;
        // (2, i)
        const int reelIndex = 2;
        const int resultOffset = AT(result, reelIndex) - 1 + i;
        const std::string sym = AT(AT(reelSet, reelIndex), resultOffset);
        if (sym == RgExtraWild_wild) {
            WinMeter meter;
            meter.line = 10;
            meter.meter = static_cast<UINT16>(1 << (3 * reelIndex + 2 - i));
            meter.meter2 = g_GrafficObjList.Str2GOCID("Wild_EXWI1x");
            meter.symbol = RgExtraWild_wild;
            meter.weight = 1;
            meter.start = 0;
            meter.bonus = m_Bonus[BetStep()][RgExtraWild_wild][1];
            meter.sound = MAX_SOUND_IDS;
            meters.push_back(meter);
        }
    }

    if (m_mapWildMatch[0] == 0 && m_mapWildMatch[1] == 0 && m_mapWildMatch[2] == 1) {
        m_mapWildMatch[0] = 1;
        m_mapWildMatch[1] = 1;
        m_mapWildMatch[2] = 2;
    }
    else if (m_mapWildMatch[0] == 0 && m_mapWildMatch[1] == 1 && m_mapWildMatch[2] == 1) {
        m_mapWildMatch[0] = 1;
        m_mapWildMatch[1] = 2;
        m_mapWildMatch[2] = 3;
    }
    else if (m_mapWildMatch[0] == 1 && m_mapWildMatch[1] == 0 && m_mapWildMatch[2] == 1) {
        m_mapWildMatch[0] = 2;
        m_mapWildMatch[1] = 1;
        m_mapWildMatch[2] = 3;
    }
    else if (m_mapWildMatch[0] == 1 && m_mapWildMatch[1] == 1 && m_mapWildMatch[2] == 1) {
        m_mapWildMatch[0] = 2;
        m_mapWildMatch[1] = 3;
        m_mapWildMatch[2] = 7;
    }
    else if (m_mapWildMatch[0] == 0 && m_mapWildMatch[1] == 1 && m_mapWildMatch[2] == 0) {
        m_mapWildMatch[0] = 1;
        m_mapWildMatch[1] = 2;
        m_mapWildMatch[2] = 1;
    }
    else if (m_mapWildMatch[0] == 1 && m_mapWildMatch[1] == 0 && m_mapWildMatch[2] == 0) {
        m_mapWildMatch[0] = 2;
        m_mapWildMatch[1] = 1;
        m_mapWildMatch[2] = 1;
    }
    else if (m_mapWildMatch[0] == 1 && m_mapWildMatch[1] == 1 && m_mapWildMatch[2] == 0) {
        m_mapWildMatch[0] = 2;
        m_mapWildMatch[1] = 3;
        m_mapWildMatch[2] = 1;
    }
    else {
        m_mapWildMatch[0] = 1;
        m_mapWildMatch[1] = 1;
        m_mapWildMatch[2] = 1;
    }

    // update multi
    myVector<WinMeter> updatedMeters;
    for (int i = 0; i < meters.size(); i++) {
        int currBonus = AT(meters, i).bonus.coin;
        int wildRow = mapLine2WildRow[AT(meters, i).line];
        UINT8 multi = 0x01;
        if (wildRow != 0) {
            currBonus *= m_mapWildMatch[wildRow - 1];
            if (m_mapWildMatch[wildRow - 1] > 1) {
                multi = m_mapWildMatch[wildRow - 1];
            }
        }
        totalBonus += currBonus;
        
        // Insert the "ele" before current
        WinMeter ele;
        ele.line = 0xFF;
        ele.bonus = {0, 0};
        ele.IntWinbonus.push_back({
            0,
            0,
            {
                0x01, 0x02, 0x2c, 0x00, 0xeb, 0x58,
                static_cast<BYTE>(totalBonus & 0xFF),
                static_cast<BYTE>((totalBonus >> 8) & 0xFF),
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04
            }
            });
        updatedMeters.push_back(ele);
        WinMeter updated = AT(meters, i);
        updated.bonus.coin = currBonus;
        updated.multi = multi;
        updatedMeters.push_back(updated);
    }
    meters = updatedMeters;
    m_vWinMeters = meters;
    
    if (totalBonus > 0) {
        BonusSound = getSoundByID(WinSound(totalBonus));
    }
    else {
        BonusSound.soundID = MAX_SOUND_IDS;
        BonusSound.duration = 0;
    }

    if (bTest == FALSE) {
        m_vWinResult = result;
        updateCheckPoint();
    }
    return result;
}

int RgExtraWild::LineSwapDelay(int WinIdx) {
    if (AT(m_vWinMeters, WinIdx).line == 0xFF) {
        return 0;
    }
    return 500;
}

myVector<InterruptPacketData> RgExtraWild::InterruptAfterSpin() {
    myVector<InterruptPacketData> packets;

    // 1, 2, 3
    if (m_mapWildMatch[0] > 1 && m_mapWildMatch[1] > 1 && m_mapWildMatch[2] > 1) {
        packets.push_back({
            0,
            3500,
            {0x06, 0x4c, 0x1b, 0x01, 0x02, 0x31, 0x00, 0x08, 0x00, 0x4c, 0x1b, 0xce, 0xc0, 0x01, 0x02, 0x00, 0x03, 0x00, 0x07, 0x00, 0x04} });
    }
    // 1, 2
    else if (m_mapWildMatch[0] > 1 && m_mapWildMatch[1] > 1 && m_mapWildMatch[2] == 1) {
        packets.push_back({
            0,
            3500,
            {0x06, 0x4c, 0x1b, 0x01, 0x02, 0x31, 0x00, 0x06, 0x00, 0x4c, 0x1b, 0xce, 0xc0, 0x00, 0x02, 0x00, 0x03, 0x00, 0x04} });
    }
    // 2, 3
    else if (m_mapWildMatch[0] == 1 && m_mapWildMatch[1] > 1 && m_mapWildMatch[2] > 1) {
        packets.push_back({
            0,
            3500,
            {0x06, 0x4c, 0x1b, 0x01, 0x02, 0x31, 0x00, 0x06, 0x00, 0x4c, 0x1b, 0xce, 0x80, 0x01, 0x02, 0x00, 0x03, 0x00, 0x04} });
    }
    // 1, 3
    else if (m_mapWildMatch[0] > 1 && m_mapWildMatch[1] == 1 && m_mapWildMatch[2] > 1) {
        packets.push_back({
            0,
            3500,
            {0x06, 0x4c, 0x1b, 0x01, 0x02, 0x31, 0x00, 0x06, 0x00, 0x4c, 0x1b, 0xce, 0x40, 0x01, 0x02, 0x00, 0x03, 0x00, 0x04} });
    }
    // 1
    else if (m_mapWildMatch[0] > 1 && m_mapWildMatch[1] == 1 && m_mapWildMatch[2] == 1) {
        packets.push_back({
            0,
            3500,
            {0x06, 0x4c, 0x1b, 0x01, 0x02, 0x31, 0x00, 0x04, 0x00, 0x4c, 0x1b, 0xce, 0x40, 0x00, 0x02, 0x00, 0x04} });
    }
    // 2
    else if (m_mapWildMatch[0] == 1 && m_mapWildMatch[1] > 1 && m_mapWildMatch[2] == 1) {
        packets.push_back({
            0,
            3500,
            {0x06, 0x4c, 0x1b, 0x01, 0x02, 0x31, 0x00, 0x04, 0x00, 0x4c, 0x1b, 0xce, 0x80, 0x00, 0x02, 0x00, 0x04} });
    }
    // 3
    else if (m_mapWildMatch[0] == 1 && m_mapWildMatch[1] == 1 && m_mapWildMatch[2] > 1) {
        packets.push_back({
            0,
            3500,
            {0x06, 0x4c, 0x1b, 0x01, 0x02, 0x31, 0x00, 0x04, 0x00, 0x4c, 0x1b, 0xce, 0x00, 0x01, 0x02, 0x00, 0x04} });
    }
    
    return packets;
}

myVector<UINT8> RgExtraWild::ShowTotalWinLines(myVector<WinMeter> SpinMeters) {
    myVector<uint8_t> packet = {
        0x06, 0x30, 0x59, 0x01, 0x02, 0x31, 0x00,
        0x0F, 0x00,  // Placeholder for length 
        0x0F, 0x11, // GameID
        0x9C, 0x00, 0x00
    };
    UINT16 totalMeter = 0;
    myVector<UINT8> TotalMatch;

    UINT16 rndMeter2 = 0;
    for (int i = 0; i < SpinMeters.size(); i++) {
        if (AT(SpinMeters, i).line == 0xFF) { // clear after convert action
            continue;
        }
        TotalMatch.push_back(AT(SpinMeters, i).line);
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter >> 8) & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter2 & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter2 >> 8) & 0xFF));

        totalMeter |= AT(SpinMeters, i).meter;
        if (rndMeter2 == 0) {
            rndMeter2 = AT(SpinMeters, i).meter2;
        }
    }
    if (TotalMatch.size() < 10) {
        myVector<UINT8> _;
        return _;
    }
    UINT16 pktLen = 1 + (TotalMatch.size() / 5) * 7;
    AT(packet, 7) = static_cast<BYTE>(pktLen & 0xFF);
    AT(packet, 8) = static_cast<BYTE>((pktLen >> 8) & 0xFF);
    AT(packet, 9) = static_cast<BYTE>(m_nGameID & 0xFF);
    AT(packet, 10) = static_cast<BYTE>((m_nGameID >> 8) & 0xFF);
    int entryCount = static_cast<int>(TotalMatch.size() / 5);
    for (int i = 0; i < entryCount; ++i) {
        packet.push_back(AT(TotalMatch, i * 5 + 0)); // Line
        packet.push_back(AT(TotalMatch, i * 5 + 1)); // Meter low byte
        packet.push_back(AT(TotalMatch, i * 5 + 2)); // Meter high byte
        packet.push_back(AT(TotalMatch, i * 5 + 3)); // Meter2 low byte
        packet.push_back(AT(TotalMatch, i * 5 + 4)); // Meter2 high byte
        packet.push_back(0x01);      // Status or flag 1
        packet.push_back(0x00);      // Status or flag 2
    }
    // Mark the end of the packet
    packet.back() = 0x04;

    packet.push_back(static_cast<BYTE>(totalMeter & 0xFF));
    packet.push_back(static_cast<BYTE>((totalMeter >> 8) & 0xFF));

    packet.push_back(static_cast<BYTE>(rndMeter2 & 0xFF));
    packet.push_back(static_cast<BYTE>((rndMeter2 >> 8) & 0xFF));    
    return packet;
}

myVector<InterruptPacketData> RgExtraWild::InterruptBeforeRisiko() {
    myVector<InterruptPacketData> packets;
    // hide top erfolg
    packets.push_back({
           0,
           0,
           {0x01, 0x02, 0x2f, 0x00, 0xeb, 0x58, 0x00, 0x04} });
    return packets;
}

myVector<InterruptPacketData> RgExtraWild::InterruptBeforeSpin() {
    myVector<InterruptPacketData> packets;
    // hide top erfolg
    packets.push_back({
           0,
           0,
           {0x01, 0x02, 0x2f, 0x00, 0xeb, 0x58, 0x00, 0x04} });
    return packets;
}
