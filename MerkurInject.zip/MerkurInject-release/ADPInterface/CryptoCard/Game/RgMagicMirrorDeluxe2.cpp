#include "stdafx.h"
#include "RgMagicMirrorDeluxe2.h"

#define RgMagicMirrorDeluxe2_MP_ChangeLine_LB_x_reel   0x03
#define RgMagicMirrorDeluxe2_MP_ChangeLine_LB_x_pos    0x28
#define RgMagicMirrorDeluxe2_MP_ChangeLine_LB_y_row    0x02
#define RgMagicMirrorDeluxe2_MP_ChangeLine_LB_y_pos    0x18
#define RgMagicMirrorDeluxe2_MP_ChangeLine_RT_x_reel   0x03
#define RgMagicMirrorDeluxe2_MP_ChangeLine_RT_x_pos    0x62
#define RgMagicMirrorDeluxe2_MP_ChangeLine_RT_y_row    0x02
#define RgMagicMirrorDeluxe2_MP_ChangeLine_RT_y_pos    0x52

#define RgMagicMirrorDeluxe2_mirror    "MMDL2Sca"
RgMagicMirrorDeluxe2::RgMagicMirrorDeluxe2() {
    m_nReel = 5;
    m_nWinLine = 5;
    m_nMaxMatch = 5;
    m_nBetStep = 0;

    m_strGameName = "RgMagicMirrorDeluxe2";

    m_bFreeMode = FALSE;

    myVector<UINT16> m_vecBetSteps_05_tmp;
    myVector<UINT16> m_vecBetSteps_10_tmp;
    m_vecBetSteps_05_tmp.push_back(5);
    m_vecBetSteps_05_tmp.push_back(10);
    m_vecBetSteps_05_tmp.push_back(20);
    m_vecBetSteps_05_tmp.push_back(30);
    m_vecBetSteps_05_tmp.push_back(40);
    m_vecBetSteps_05_tmp.push_back(50);
    m_vecBetSteps_05_tmp.push_back(60);
    m_vecBetSteps_05_tmp.push_back(80);
    m_vecBetSteps_05_tmp.push_back(100);
    m_vecBetSteps_05_tmp.push_back(150);
    m_vecBetSteps_05_tmp.push_back(200);

    m_vecBetSteps_10_tmp.push_back(10);
    m_vecBetSteps_10_tmp.push_back(20);
    m_vecBetSteps_10_tmp.push_back(30);
    m_vecBetSteps_10_tmp.push_back(40);
    m_vecBetSteps_10_tmp.push_back(50);
    m_vecBetSteps_10_tmp.push_back(60);
    m_vecBetSteps_10_tmp.push_back(80);
    m_vecBetSteps_10_tmp.push_back(100);
    m_vecBetSteps_10_tmp.push_back(150);
    m_vecBetSteps_10_tmp.push_back(200);
    m_vecBetSteps_10_tmp.push_back(400);
#ifdef BIGBET_ACTIVE
    m_vecBetSteps_05_tmp.push_back(500);
    m_vecBetSteps_05_tmp.push_back(1000);
    m_vecBetSteps_10_tmp.push_back(1000);
    m_vecBetSteps_10_tmp.push_back(2000);
#endif
    LoadBets();

    m_vecBetSteps = m_vecBetSteps_05;

    m_vecSymbols.push_back("MMDL2HV1");
    m_vecSymbols.push_back("MMDL2HV2");
    m_vecSymbols.push_back("MMDL2HV3");
    m_vecSymbols.push_back("MMDL2HV4");
    m_vecSymbols.push_back("MMDL2_A_");
    m_vecSymbols.push_back("MMDL2_K_");
    m_vecSymbols.push_back("MMDL2_Q_");
    m_vecSymbols.push_back("MMDL2_J_");
    m_vecSymbols.push_back("MMDL2_10");
    m_vecSymbols.push_back("MMDL2Sca");

    m_vSelectableSymbols.push_back("MMDL2HV3");
    m_vSelectableSymbols.push_back("MMDL2HV4");
    m_vSelectableSymbols.push_back("MMDL2_A_");
    m_vSelectableSymbols.push_back("MMDL2_K_");
    m_vSelectableSymbols.push_back("MMDL2_Q_");
    m_vSelectableSymbols.push_back("MMDL2_J_");
    m_vSelectableSymbols.push_back("MMDL2_10");
    m_vSelectableSymbols.push_back("MMDL2_A_");
    m_vSelectableSymbols.push_back("MMDL2_K_");
    m_vSelectableSymbols.push_back("MMDL2_Q_");
    m_vSelectableSymbols.push_back("MMDL2_J_");
    m_vSelectableSymbols.push_back("MMDL2_10");

    m_mapSymbolMinMatch["MMDL2HV1"] = 2;
    m_mapSymbolMinMatch["MMDL2HV2"] = 2;
    m_mapSymbolMinMatch["MMDL2HV3"] = 2;
    m_mapSymbolMinMatch["MMDL2HV4"] = 2;
    m_mapSymbolMinMatch["MMDL2_A_"] = 3;
    m_mapSymbolMinMatch["MMDL2_K_"] = 3;
    m_mapSymbolMinMatch["MMDL2_Q_"] = 3;
    m_mapSymbolMinMatch["MMDL2_J_"] = 3;
    m_mapSymbolMinMatch["MMDL2_10"] = 3;
    m_mapSymbolMinMatch["MMDL2Sca"] = 3;

    m_mapSymbolMeterGoc["MMDL2HV1"] = "MMDL2HV1Magier$x";
    m_mapSymbolMeterGoc["MMDL2HV2"] = "MMDL2HV2Einh$x";
    m_mapSymbolMeterGoc["MMDL2HV3"] = "MMDL2HV3Buch$x";
    m_mapSymbolMeterGoc["MMDL2HV4"] = "MMDL2HV4Ring$x";
    m_mapSymbolMeterGoc["MMDL2_A_"] = "MMDL2A$x";
    m_mapSymbolMeterGoc["MMDL2_K_"] = "MMDL2K$x";
    m_mapSymbolMeterGoc["MMDL2_Q_"] = "MMDL2Q$x";
    m_mapSymbolMeterGoc["MMDL2_J_"] = "MMDL2J$x";
    m_mapSymbolMeterGoc["MMDL2_10"] = "MMDL2T$x";
    m_mapSymbolMeterGoc["MMDL2Sca"] = "MMDL2ScaMirror$x";

    m_vecWinLines.push_back("MMDL2winline1");
    m_vecWinLines.push_back("MMDL2winline2");
    m_vecWinLines.push_back("MMDL2winline3");
    m_vecWinLines.push_back("MMDL2winline4");
    m_vecWinLines.push_back("MMDL2winline5");
    m_vecWinLines.push_back("MMDL2winline6");
    m_vecWinLines.push_back("MMDL2winline7");
    m_vecWinLines.push_back("MMDL2winline8");
    m_vecWinLines.push_back("MMDL2winline9");
    m_vecWinLines.push_back("MMDL2winline10");
    m_vecWinLines.push_back("MMDL2winlineScat");

    //m_vecLineSounds.push_back(SMP_BS_Win5Part_1);

    // autoplay in clientside
    //m_vecWinSounds.push_back(SMP_MMDL2_win_tiny);
    //m_vecWinSounds.push_back(SMP_MMDL2_win_small);
    //m_vecWinSounds.push_back(SMP_MMDL2_win_lv_5_of_a_kind);
    //m_vecWinSounds.push_back(SMP_MMDL2_win_hv_middle);
    //m_vecWinSounds.push_back(SMP_MMDL2_win_middle);    
    //m_vecWinSounds.push_back(SMP_MMDL2_win_hv_huge);
    //m_vecWinSounds.push_back(SMP_MMDL2_win_maxwin);

    m_vecReelStripPlan.push_back("0");
    m_vecReelStripPlan.push_back("1");
    m_vecReelStripPlan.push_back("2");

    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));

    char* mmdl2ReelStrip[] = {
        "MMDL2_J_,MMDL2_A_,MMDL2HV4,MMDL2_K_,MMDL2_Q_,MMDL2HV3,MMDL2_A_,MMDL2_K_,MMDL2HV1,MMDL2_Q_,MMDL2_A_,MMDL2HV3,MMDL2_J_,MMDL2_A_,MMDL2Sca,MMDL2_10,MMDL2_Q_,MMDL2_A_,MMDL2_J_,MMDL2_K_,MMDL2_Q_,MMDL2_A_,MMDL2HV1,MMDL2_10,MMDL2_A_,MMDL2HV3,MMDL2_Q_,MMDL2_K_,MMDL2HV2,MMDL2_J_,MMDL2_A_,MMDL2_10,MMDL2_Q_,MMDL2HV3,MMDL2_J_,MMDL2_K_,MMDL2HV4,MMDL2_Q_,MMDL2_K_,MMDL2_A_,MMDL2_J_,MMDL2HV3,MMDL2_K_,MMDL2_Q_,MMDL2HV3,MMDL2_K_,MMDL2_10,MMDL2HV2,MMDL2_Q_,MMDL2_K_",
        "MMDL2_Q_,MMDL2HV4,MMDL2_A_,MMDL2_K_,MMDL2HV3,MMDL2_J_,MMDL2_Q_,MMDL2HV4,MMDL2_A_,MMDL2_K_,MMDL2_Q_,MMDL2HV2,MMDL2_J_,MMDL2_K_,MMDL2Sca,MMDL2_10,MMDL2_Q_,MMDL2HV2,MMDL2_J_,MMDL2_A_,MMDL2Sca,MMDL2_10,MMDL2_Q_,MMDL2HV2,MMDL2_A_,MMDL2_J_,MMDL2_K_,MMDL2_10,MMDL2HV3,MMDL2_A_,MMDL2_K_,MMDL2HV1,MMDL2_J_,MMDL2_K_,MMDL2HV2,MMDL2_J_,MMDL2_A_",
        "MMDL2_J_,MMDL2_A_,MMDL2HV4,MMDL2_K_,MMDL2_Q_,MMDL2HV3,MMDL2_A_,MMDL2_K_,MMDL2HV1,MMDL2_Q_,MMDL2_A_,MMDL2HV3,MMDL2_J_,MMDL2_A_,MMDL2Sca,MMDL2_10,MMDL2_Q_,MMDL2_A_,MMDL2_J_,MMDL2_K_,MMDL2_Q_,MMDL2_A_,MMDL2HV1,MMDL2_10,MMDL2_A_,MMDL2HV3,MMDL2_Q_,MMDL2_K_,MMDL2HV2,MMDL2_J_,MMDL2_A_,MMDL2_10,MMDL2_Q_,MMDL2HV3,MMDL2_J_,MMDL2_K_,MMDL2HV4,MMDL2_Q_,MMDL2_K_,MMDL2_A_,MMDL2_J_,MMDL2HV3,MMDL2_K_,MMDL2_Q_,MMDL2HV3,MMDL2_K_,MMDL2_10,MMDL2HV2,MMDL2_Q_,MMDL2_K_",

        "MMDL2_K_,MMDL2_10,MMDL2_Q_,MMDL2_K_,MMDL2_10,MMDL2_J_,MMDL2_A_,MMDL2_K_,MMDL2_10,MMDL2_Q_,MMDL2HV2,MMDL2_K_,MMDL2_J_,MMDL2HV4,MMDL2_10,MMDL2_K_,MMDL2HV4,MMDL2_J_,MMDL2_A_,MMDL2_K_,MMDL2HV2,MMDL2_J_,MMDL2_10,MMDL2_A_,MMDL2Sca,MMDL2_Q_,MMDL2_J_,MMDL2_10,MMDL2_Q_,MMDL2_K_,MMDL2_10,MMDL2_J_,MMDL2HV3,MMDL2_A_,MMDL2_K_,MMDL2_J_,MMDL2HV4,MMDL2_10,MMDL2_J_,MMDL2_Q_,MMDL2HV1,MMDL2_K_,MMDL2_10,MMDL2_J_,MMDL2HV4,MMDL2_Q_,MMDL2_A_",
        "MMDL2_A_,MMDL2_Q_,MMDL2_K_,MMDL2Sca,MMDL2_J_,MMDL2HV4,MMDL2_10,MMDL2_K_,MMDL2HV3,MMDL2_Q_,MMDL2_10,MMDL2_K_,MMDL2_A_,MMDL2_10,MMDL2HV4,MMDL2_J_,MMDL2_Q_,MMDL2_A_,MMDL2_J_,MMDL2HV2,MMDL2_10,MMDL2_Q_,MMDL2_J_,MMDL2_A_,MMDL2HV3,MMDL2_K_,MMDL2_10,MMDL2_A_,MMDL2Sca,MMDL2_Q_,MMDL2_J_,MMDL2HV4,MMDL2_A_,MMDL2_J_,MMDL2HV1,MMDL2_Q_,MMDL2_10",
        "MMDL2_K_,MMDL2_10,MMDL2_J_,MMDL2_K_,MMDL2_10,MMDL2_J_,MMDL2_A_,MMDL2_K_,MMDL2_10,MMDL2_Q_,MMDL2HV2,MMDL2_K_,MMDL2_J_,MMDL2HV4,MMDL2_10,MMDL2_K_,MMDL2HV4,MMDL2_J_,MMDL2_A_,MMDL2_K_,MMDL2HV2,MMDL2_J_,MMDL2_10,MMDL2_A_,MMDL2Sca,MMDL2_Q_,MMDL2_J_,MMDL2_10,MMDL2_Q_,MMDL2_K_,MMDL2_10,MMDL2_J_,MMDL2HV3,MMDL2_A_,MMDL2_K_,MMDL2_J_,MMDL2HV4,MMDL2_10,MMDL2_J_,MMDL2_Q_,MMDL2HV1,MMDL2_K_,MMDL2_10,MMDL2_J_,MMDL2HV4",

        "MMDL2_J_,MMDL2HV2,MMDL2_10,MMDL2_J_,MMDL2HV1,MMDL2_A_,MMDL2_K_,MMDL2HV3,MMDL2_A_,MMDL2_Q_,MMDL2HV3,MMDL2_10,MMDL2_J_,MMDL2HV1,MMDL2_Q_,MMDL2_10,MMDL2HV2,MMDL2_Q_,MMDL2_A_,MMDL2HV2,MMDL2_K_,MMDL2_10,MMDL2Sca,MMDL2_A_,MMDL2_J_,MMDL2HV4,MMDL2_10,MMDL2_Q_,MMDL2_J_,MMDL2HV4,MMDL2_A_,MMDL2_10,MMDL2HV3,MMDL2_Q_,MMDL2_J_,MMDL2HV4,MMDL2_10,MMDL2_A_,MMDL2_K_,MMDL2HV2,MMDL2_10,MMDL2_J_,MMDL2_Q_,MMDL2HV4,MMDL2_10,MMDL2_A_,MMDL2HV3,MMDL2_Q_,MMDL2_K_",
        "MMDL2HV1,MMDL2_A_,MMDL2_Q_,MMDL2HV4,MMDL2_K_,MMDL2_J_,MMDL2HV3,MMDL2_Q_,MMDL2_J_,MMDL2_K_,MMDL2HV1,MMDL2_10,MMDL2_Q_,MMDL2HV1,MMDL2_A_,MMDL2_J_,MMDL2_K_,MMDL2HV3,MMDL2_Q_,MMDL2_10,MMDL2HV2,MMDL2_J_,MMDL2_K_,MMDL2_10,MMDL2Sca,MMDL2_A_,MMDL2_J_,MMDL2_10,MMDL2_K_,MMDL2_J_,MMDL2_A_,MMDL2_Q_,MMDL2HV2,MMDL2_K_,MMDL2_A_,MMDL2_10",
        "MMDL2_J_,MMDL2HV2,MMDL2_10,MMDL2_J_,MMDL2HV1,MMDL2_A_,MMDL2_K_,MMDL2HV3,MMDL2_A_,MMDL2_Q_,MMDL2HV3,MMDL2_10,MMDL2_J_,MMDL2HV1,MMDL2_Q_,MMDL2_10,MMDL2HV2,MMDL2_Q_,MMDL2_A_,MMDL2HV2,MMDL2_K_,MMDL2_10,MMDL2Sca,MMDL2_A_,MMDL2_J_,MMDL2_10,MMDL2_Q_,MMDL2_J_,MMDL2HV4,MMDL2_A_,MMDL2_10,MMDL2HV3,MMDL2_Q_,MMDL2_J_,MMDL2HV4,MMDL2_10,MMDL2_A_,MMDL2_K_,MMDL2HV2,MMDL2_10,MMDL2_J_,MMDL2_Q_,MMDL2HV4,MMDL2_10,MMDL2_A_,MMDL2_Q_",

        "MMDL2_Q_,MMDL2HV3,MMDL2_A_,MMDL2_K_,MMDL2HV3,MMDL2_Q_,MMDL2_10,MMDL2HV1,MMDL2_J_,MMDL2_K_,MMDL2HV3,MMDL2_A_,MMDL2_J_,MMDL2HV2,MMDL2_Q_,MMDL2_A_,MMDL2HV1,MMDL2_K_,MMDL2_10,MMDL2Sca,MMDL2_J_,MMDL2_Q_,MMDL2HV4,MMDL2_A_,MMDL2_10,MMDL2HV3,MMDL2_Q_,MMDL2_J_,MMDL2_10,MMDL2HV2,MMDL2_K_,MMDL2_Q_,MMDL2HV4,MMDL2_10,MMDL2_J_,MMDL2HV4,MMDL2_A_,MMDL2_10,MMDL2HV3,MMDL2_K_,MMDL2_10,MMDL2HV2,MMDL2_J_,MMDL2_A_,MMDL2HV4,MMDL2_K_,MMDL2_J_,MMDL2HV2,MMDL2_10,MMDL2_Q_,MMDL2HV4,MMDL2_A_,MMDL2_Q_,MMDL2Sca,MMDL2_K_,MMDL2_A_,MMDL2HV4,MMDL2_J_",
        "MMDL2_J_,MMDL2_Q_,MMDL2HV2,MMDL2_K_,MMDL2HV4,MMDL2_Q_,MMDL2_K_,MMDL2_10,MMDL2Sca,MMDL2_J_,MMDL2_Q_,MMDL2HV4,MMDL2_10,MMDL2_K_,MMDL2HV3,MMDL2_10,MMDL2_K_,MMDL2Sca,MMDL2_A_,MMDL2_J_,MMDL2HV1,MMDL2_10,MMDL2_J_,MMDL2_A_,MMDL2HV4,MMDL2_10,MMDL2_Q_,MMDL2HV3,MMDL2_K_,MMDL2_10,MMDL2HV4,MMDL2_Q_,MMDL2_K_,MMDL2HV3,MMDL2_Q_,MMDL2_A_,MMDL2HV1",
        "MMDL2_Q_,MMDL2HV3,MMDL2_A_,MMDL2_K_,MMDL2HV3,MMDL2_Q_,MMDL2_10,MMDL2HV1,MMDL2_J_,MMDL2_K_,MMDL2HV3,MMDL2_A_,MMDL2HV2,MMDL2_Q_,MMDL2_A_,MMDL2HV1,MMDL2_K_,MMDL2_10,MMDL2Sca,MMDL2_J_,MMDL2_Q_,MMDL2_A_,MMDL2_10,MMDL2HV3,MMDL2_Q_,MMDL2_J_,MMDL2_10,MMDL2HV2,MMDL2_K_,MMDL2_Q_,MMDL2_10,MMDL2_J_,MMDL2HV4,MMDL2_A_,MMDL2_10,MMDL2HV3,MMDL2_K_,MMDL2_Q_,MMDL2_J_,MMDL2_A_,MMDL2HV4,MMDL2_K_,MMDL2HV2,MMDL2_10,MMDL2_Q_,MMDL2HV4,MMDL2_A_,MMDL2_Q_,MMDL2Sca,MMDL2_K_",

        "MMDL2_A_,MMDL2HV1,MMDL2_J_,MMDL2_K_,MMDL2HV3,MMDL2_10,MMDL2_J_,MMDL2HV1,MMDL2_Q_,MMDL2_A_,MMDL2HV2,MMDL2_K_,MMDL2_Q_,MMDL2HV4,MMDL2_10,MMDL2_A_,MMDL2HV4,MMDL2_Q_,MMDL2_J_,MMDL2HV3,MMDL2_K_,MMDL2_A_,MMDL2HV2,MMDL2_J_,MMDL2_Q_,MMDL2Sca,MMDL2_10,MMDL2_A_,MMDL2HV3,MMDL2_Q_,MMDL2_10,MMDL2HV2,MMDL2_J_,MMDL2_10,MMDL2HV4,MMDL2_A_,MMDL2_Q_,MMDL2HV4,MMDL2_10,MMDL2_Q_,MMDL2_K_,MMDL2HV3,MMDL2_A_,MMDL2_Q_,MMDL2HV3,MMDL2_J_,MMDL2_K_,MMDL2Sca,MMDL2_J_,MMDL2_10,MMDL2HV4,MMDL2_K_,MMDL2_A_,MMDL2HV4,MMDL2_10,MMDL2_K_,MMDL2HV2,MMDL2_J_,MMDL2_K_",
        "MMDL2HV2,MMDL2_Q_,MMDL2HV4,MMDL2_K_,MMDL2HV3,MMDL2_Q_,MMDL2HV2,MMDL2_10,MMDL2HV4,MMDL2_K_,MMDL2HV1,MMDL2_A_,MMDL2HV3,MMDL2_10,MMDL2_J_,MMDL2HV1,MMDL2_A_,MMDL2_J_,MMDL2HV3,MMDL2_A_,MMDL2HV2,MMDL2_J_,MMDL2_K_,MMDL2Sca,MMDL2_J_,MMDL2_10,MMDL2HV3,MMDL2_A_,MMDL2_Q_,MMDL2HV2,MMDL2_K_,MMDL2Sca,MMDL2_10,MMDL2HV4,MMDL2_Q_,MMDL2HV1,MMDL2_10",
        "MMDL2_A_,MMDL2HV1,MMDL2_J_,MMDL2_K_,MMDL2HV3,MMDL2_10,MMDL2_J_,MMDL2HV1,MMDL2_Q_,MMDL2HV2,MMDL2_K_,MMDL2HV4,MMDL2_10,MMDL2_A_,MMDL2HV4,MMDL2_Q_,MMDL2HV3,MMDL2_K_,MMDL2_A_,MMDL2HV2,MMDL2_J_,MMDL2_Q_,MMDL2Sca,MMDL2_10,MMDL2_A_,MMDL2HV3,MMDL2_Q_,MMDL2HV2,MMDL2_J_,MMDL2HV4,MMDL2_A_,MMDL2_Q_,MMDL2HV4,MMDL2_10,MMDL2_Q_,MMDL2_K_,MMDL2HV3,MMDL2_A_,MMDL2_Q_,MMDL2HV3,MMDL2_J_,MMDL2_K_,MMDL2Sca,MMDL2_J_,MMDL2_10,MMDL2_K_",
    };

    for (int i = 0; i < m_vecReelStripPlan.size(); i++) {
        ReelSet set;
        for (int j = 0; j < m_nReel; j++) {
            ReelStrip strip;
            std::stringstream ss(mmdl2ReelStrip[j * m_vecReelStripPlan.size() + i]);
            std::string item;
            while (std::getline(ss, item, ',')) {
                strip.push_back(item);
            }
            set.push_back(strip);
        }
        m_vecReelStripSets.push_back(set);
    }

    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_05_tmp;
    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_10_tmp;

    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_BonusFree_05_tmp;
    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_BonusFree_10_tmp;
    for (int i = 0; i < m_vecBetSteps_05_tmp.size(); i++) {
        std::map<std::string, std::map<UINT8, BONUS>> perSym;
        std::map<UINT8, BONUS> e;
        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 25; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[5].ag = 0;
        perSym["MMDL2_10"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 25; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[5].ag = 0;
        perSym["MMDL2_J_"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 25; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[5].ag = 0;
        perSym["MMDL2_Q_"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 40; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 150; e[5].ag = 0;
        perSym["MMDL2_K_"] = e;

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 40; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 150; e[5].ag = 0;
        perSym["MMDL2_A_"] = e;
        e.clear();

        e[2].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[2].ag = 0;
        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 30; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 750; e[5].ag = 0;
        perSym["MMDL2HV4"] = e;
        e.clear();

        e[2].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[2].ag = 0;
        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 30; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 750; e[5].ag = 0;
        perSym["MMDL2HV3"] = e;
        e.clear();

        e[2].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[2].ag = 0;
        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 40; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 400; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 2000; e[5].ag = 0;
        perSym["MMDL2HV2"] = e;
        e.clear();

        e[2].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 10; e[2].ag = 0;
        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 1000; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5000; e[5].ag = 0;
        perSym["MMDL2HV1"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 1000; e[5].ag = 0;
        perSym["MMDL2Sca"] = e;
        e.clear();

        m_Bonus_05_tmp[i] = perSym;
    }    

    m_Bonus_05_tmp[6]["MMDL2HV1"][5].coin = 50000; m_Bonus_05_tmp[6]["MMDL2HV1"][5].ag = 10; // 60
    m_Bonus_05_tmp[7]["MMDL2HV1"][5].coin = 50000; m_Bonus_05_tmp[7]["MMDL2HV1"][5].ag = 30; // 80
    m_Bonus_05_tmp[8]["MMDL2HV1"][5].coin = 50000; m_Bonus_05_tmp[8]["MMDL2HV1"][5].ag = 50; // 100
    m_Bonus_05_tmp[9]["MMDL2HV1"][5].coin = 50000; m_Bonus_05_tmp[9]["MMDL2HV1"][5].ag = 100; // 150
    m_Bonus_05_tmp[9]["MMDL2HV2"][5].coin = 50000; m_Bonus_05_tmp[9]["MMDL2HV2"][5].ag = 10;
    m_Bonus_05_tmp[10]["MMDL2HV1"][5].coin = 50000; m_Bonus_05_tmp[10]["MMDL2HV1"][5].ag = 100; // 200
    m_Bonus_05_tmp[10]["MMDL2HV2"][5].coin = 50000; m_Bonus_05_tmp[10]["MMDL2HV2"][5].ag = 30;
    m_Bonus_05_tmp[11]["MMDL2Sca"][5].coin = 50000; m_Bonus_05_tmp[11]["MMDL2Sca"][5].ag = 50; // 500
    m_Bonus_05_tmp[11]["MMDL2HV1"][5].coin = 50000; m_Bonus_05_tmp[11]["MMDL2HV1"][5].ag = 450; 
    m_Bonus_05_tmp[11]["MMDL2HV1"][4].coin = 50000; m_Bonus_05_tmp[11]["MMDL2HV1"][4].ag = 50; 
    m_Bonus_05_tmp[11]["MMDL2HV2"][5].coin = 50000; m_Bonus_05_tmp[11]["MMDL2HV2"][5].ag = 150;
    m_Bonus_05_tmp[11]["MMDL2HV3"][5].coin = 50000; m_Bonus_05_tmp[11]["MMDL2HV3"][5].ag = 25;
    m_Bonus_05_tmp[11]["MMDL2HV4"][5].coin = 50000; m_Bonus_05_tmp[11]["MMDL2HV4"][5].ag = 25;
    m_Bonus_05_tmp[12]["MMDL2Sca"][5].coin = 50000; m_Bonus_05_tmp[12]["MMDL2Sca"][5].ag = 150; // 1000
    m_Bonus_05_tmp[12]["MMDL2HV1"][5].coin = 50000; m_Bonus_05_tmp[12]["MMDL2HV1"][5].ag = 950; 
    m_Bonus_05_tmp[12]["MMDL2HV1"][4].coin = 50000; m_Bonus_05_tmp[12]["MMDL2HV1"][4].ag = 150; 
    m_Bonus_05_tmp[12]["MMDL2HV2"][5].coin = 50000; m_Bonus_05_tmp[12]["MMDL2HV2"][5].ag = 350;
    m_Bonus_05_tmp[12]["MMDL2HV2"][4].coin = 50000; m_Bonus_05_tmp[12]["MMDL2HV2"][4].ag = 30;
    m_Bonus_05_tmp[12]["MMDL2HV3"][5].coin = 50000; m_Bonus_05_tmp[12]["MMDL2HV3"][5].ag = 100;
    m_Bonus_05_tmp[12]["MMDL2HV4"][5].coin = 50000; m_Bonus_05_tmp[12]["MMDL2HV4"][5].ag = 100;

    m_BonusFree_05_tmp = m_Bonus_05_tmp;
    m_BonusFree_05_tmp[0]["MMDL2HV1"][5].coin = 0;      m_BonusFree_05_tmp[0]["MMDL2HV1"][5].ag = 5; // 5
    m_BonusFree_05_tmp[0]["MMDL2HV1"][4].coin = 0;      m_BonusFree_05_tmp[0]["MMDL2HV1"][4].ag = 1;
    m_BonusFree_05_tmp[0]["MMDL2HV2"][5].coin = 0;      m_BonusFree_05_tmp[0]["MMDL2HV2"][5].ag = 2;
    m_BonusFree_05_tmp[0]["MMDL2Sca"][5].coin = 0;      m_BonusFree_05_tmp[0]["MMDL2Sca"][5].ag = 1;
    m_BonusFree_05_tmp[1]["MMDL2HV1"][5].coin = 0;      m_BonusFree_05_tmp[1]["MMDL2HV1"][5].ag = 10; // 10
    m_BonusFree_05_tmp[1]["MMDL2HV1"][4].coin = 0;      m_BonusFree_05_tmp[1]["MMDL2HV1"][4].ag = 2;
    m_BonusFree_05_tmp[1]["MMDL2HV2"][5].coin = 0;      m_BonusFree_05_tmp[1]["MMDL2HV2"][5].ag = 4;
    m_BonusFree_05_tmp[1]["MMDL2Sca"][5].coin = 0;      m_BonusFree_05_tmp[1]["MMDL2Sca"][5].ag = 2;
    m_BonusFree_05_tmp[1]["MMDL2HV3"][5].coin = 500;    m_BonusFree_05_tmp[1]["MMDL2HV3"][5].ag = 1;
    m_BonusFree_05_tmp[1]["MMDL2HV4"][5].coin = 500;    m_BonusFree_05_tmp[1]["MMDL2HV4"][5].ag = 1;
    m_BonusFree_05_tmp[2]["MMDL2HV1"][5].coin = 0;      m_BonusFree_05_tmp[2]["MMDL2HV1"][5].ag = 20; // 20
    m_BonusFree_05_tmp[2]["MMDL2HV1"][4].coin = 0;      m_BonusFree_05_tmp[2]["MMDL2HV1"][4].ag = 4;
    m_BonusFree_05_tmp[2]["MMDL2HV2"][5].coin = 0;      m_BonusFree_05_tmp[2]["MMDL2HV2"][5].ag = 8;
    m_BonusFree_05_tmp[2]["MMDL2HV2"][4].coin = 600;    m_BonusFree_05_tmp[2]["MMDL2HV2"][4].ag = 1;
    m_BonusFree_05_tmp[2]["MMDL2Sca"][5].coin = 0;      m_BonusFree_05_tmp[2]["MMDL2Sca"][5].ag = 4;
    m_BonusFree_05_tmp[2]["MMDL2HV3"][5].coin = 0;      m_BonusFree_05_tmp[2]["MMDL2HV3"][5].ag = 3;
    m_BonusFree_05_tmp[2]["MMDL2HV4"][5].coin = 0;      m_BonusFree_05_tmp[2]["MMDL2HV4"][5].ag = 3;
    m_BonusFree_05_tmp[3]["MMDL2HV1"][5].coin = 0;      m_BonusFree_05_tmp[3]["MMDL2HV1"][5].ag = 30; // 30
    m_BonusFree_05_tmp[3]["MMDL2HV1"][4].coin = 0;      m_BonusFree_05_tmp[3]["MMDL2HV1"][4].ag = 6;
    m_BonusFree_05_tmp[3]["MMDL2HV2"][5].coin = 0;      m_BonusFree_05_tmp[3]["MMDL2HV2"][5].ag = 12;
    m_BonusFree_05_tmp[3]["MMDL2HV2"][4].coin = 400;    m_BonusFree_05_tmp[3]["MMDL2HV2"][4].ag = 2;
    m_BonusFree_05_tmp[3]["MMDL2Sca"][5].coin = 0;      m_BonusFree_05_tmp[3]["MMDL2Sca"][5].ag = 6;
    m_BonusFree_05_tmp[3]["MMDL2HV3"][5].coin = 500;    m_BonusFree_05_tmp[3]["MMDL2HV3"][5].ag = 4;
    m_BonusFree_05_tmp[3]["MMDL2HV4"][5].coin = 500;    m_BonusFree_05_tmp[3]["MMDL2HV4"][5].ag = 4;
    m_BonusFree_05_tmp[4]["MMDL2HV1"][5].coin = 0;      m_BonusFree_05_tmp[4]["MMDL2HV1"][5].ag = 40; // 40
    m_BonusFree_05_tmp[4]["MMDL2HV1"][4].coin = 0;      m_BonusFree_05_tmp[4]["MMDL2HV1"][4].ag = 8;
    m_BonusFree_05_tmp[4]["MMDL2HV2"][5].coin = 0;      m_BonusFree_05_tmp[4]["MMDL2HV2"][5].ag = 16;
    m_BonusFree_05_tmp[4]["MMDL2HV2"][4].coin = 200;    m_BonusFree_05_tmp[4]["MMDL2HV2"][4].ag = 3;
    m_BonusFree_05_tmp[4]["MMDL2Sca"][5].coin = 0;      m_BonusFree_05_tmp[4]["MMDL2Sca"][5].ag = 8;
    m_BonusFree_05_tmp[4]["MMDL2HV3"][5].coin = 0;      m_BonusFree_05_tmp[4]["MMDL2HV3"][5].ag = 6;
    m_BonusFree_05_tmp[4]["MMDL2HV4"][5].coin = 0;      m_BonusFree_05_tmp[4]["MMDL2HV4"][5].ag = 6;
    m_BonusFree_05_tmp[4]["MMDL2_A_"][5].coin = 200;    m_BonusFree_05_tmp[4]["MMDL2_A_"][5].ag = 1;
    m_BonusFree_05_tmp[4]["MMDL2_K_"][5].coin = 200;    m_BonusFree_05_tmp[4]["MMDL2_K_"][5].ag = 1;
    m_BonusFree_05_tmp[5]["MMDL2HV1"][5].coin = 0;      m_BonusFree_05_tmp[5]["MMDL2HV1"][5].ag = 50; // 50
    m_BonusFree_05_tmp[5]["MMDL2HV1"][4].coin = 0;      m_BonusFree_05_tmp[5]["MMDL2HV1"][4].ag = 10;
    m_BonusFree_05_tmp[5]["MMDL2HV1"][3].coin = 0;      m_BonusFree_05_tmp[5]["MMDL2HV1"][3].ag = 1;
    m_BonusFree_05_tmp[5]["MMDL2HV2"][5].coin = 0;      m_BonusFree_05_tmp[5]["MMDL2HV2"][5].ag = 20;
    m_BonusFree_05_tmp[5]["MMDL2HV2"][4].coin = 200;    m_BonusFree_05_tmp[5]["MMDL2HV2"][4].ag = 4;
    m_BonusFree_05_tmp[5]["MMDL2Sca"][5].coin = 0;      m_BonusFree_05_tmp[5]["MMDL2Sca"][5].ag = 10;
    m_BonusFree_05_tmp[5]["MMDL2Sca"][4].coin = 0;      m_BonusFree_05_tmp[5]["MMDL2Sca"][4].ag = 1;
    m_BonusFree_05_tmp[5]["MMDL2HV3"][5].coin = 500;    m_BonusFree_05_tmp[5]["MMDL2HV3"][5].ag = 7;
    m_BonusFree_05_tmp[5]["MMDL2HV3"][4].coin = 0;      m_BonusFree_05_tmp[5]["MMDL2HV3"][4].ag = 1;
    m_BonusFree_05_tmp[5]["MMDL2HV4"][5].coin = 500;    m_BonusFree_05_tmp[5]["MMDL2HV4"][5].ag = 7;
    m_BonusFree_05_tmp[5]["MMDL2HV4"][4].coin = 0;      m_BonusFree_05_tmp[5]["MMDL2HV4"][4].ag = 1;
    m_BonusFree_05_tmp[5]["MMDL2_A_"][5].coin = 500;    m_BonusFree_05_tmp[5]["MMDL2_A_"][5].ag = 1;
    m_BonusFree_05_tmp[5]["MMDL2_K_"][5].coin = 500;    m_BonusFree_05_tmp[5]["MMDL2_K_"][5].ag = 1;
    m_BonusFree_05_tmp[5]["MMDL2_Q_"][5].coin = 0;      m_BonusFree_05_tmp[5]["MMDL2_Q_"][5].ag = 1;
    m_BonusFree_05_tmp[5]["MMDL2_J_"][5].coin = 0;      m_BonusFree_05_tmp[5]["MMDL2_J_"][5].ag = 1;
    m_BonusFree_05_tmp[5]["MMDL2_10"][5].coin = 0;      m_BonusFree_05_tmp[5]["MMDL2_10"][5].ag = 1;
    m_BonusFree_05_tmp[6]["MMDL2HV1"][5].coin = 0;      m_BonusFree_05_tmp[6]["MMDL2HV1"][5].ag = 60; // 60
    m_BonusFree_05_tmp[6]["MMDL2HV1"][4].coin = 0;      m_BonusFree_05_tmp[6]["MMDL2HV1"][4].ag = 12;
    m_BonusFree_05_tmp[6]["MMDL2HV1"][3].coin = 200;    m_BonusFree_05_tmp[6]["MMDL2HV1"][3].ag = 1;
    m_BonusFree_05_tmp[6]["MMDL2HV2"][5].coin = 0;      m_BonusFree_05_tmp[6]["MMDL2HV2"][5].ag = 24;
    m_BonusFree_05_tmp[6]["MMDL2HV2"][4].coin = 800;    m_BonusFree_05_tmp[6]["MMDL2HV2"][4].ag = 4;
    m_BonusFree_05_tmp[6]["MMDL2Sca"][5].coin = 0;      m_BonusFree_05_tmp[6]["MMDL2Sca"][5].ag = 12;
    m_BonusFree_05_tmp[6]["MMDL2Sca"][4].coin = 200;    m_BonusFree_05_tmp[6]["MMDL2Sca"][4].ag = 1;
    m_BonusFree_05_tmp[6]["MMDL2HV3"][5].coin = 0;      m_BonusFree_05_tmp[6]["MMDL2HV3"][5].ag = 9;
    m_BonusFree_05_tmp[6]["MMDL2HV3"][4].coin = 200;    m_BonusFree_05_tmp[6]["MMDL2HV3"][4].ag = 1;
    m_BonusFree_05_tmp[6]["MMDL2HV4"][5].coin = 0;      m_BonusFree_05_tmp[6]["MMDL2HV4"][5].ag = 9;
    m_BonusFree_05_tmp[6]["MMDL2HV4"][4].coin = 200;    m_BonusFree_05_tmp[6]["MMDL2HV4"][4].ag = 1;
    m_BonusFree_05_tmp[6]["MMDL2_A_"][5].coin = 800;    m_BonusFree_05_tmp[6]["MMDL2_A_"][5].ag = 1;
    m_BonusFree_05_tmp[6]["MMDL2_K_"][5].coin = 800;    m_BonusFree_05_tmp[6]["MMDL2_K_"][5].ag = 1;
    m_BonusFree_05_tmp[6]["MMDL2_Q_"][5].coin = 200;    m_BonusFree_05_tmp[6]["MMDL2_Q_"][5].ag = 1;
    m_BonusFree_05_tmp[6]["MMDL2_J_"][5].coin = 200;    m_BonusFree_05_tmp[6]["MMDL2_J_"][5].ag = 1;
    m_BonusFree_05_tmp[6]["MMDL2_10"][5].coin = 200;    m_BonusFree_05_tmp[6]["MMDL2_10"][5].ag = 1;
    m_BonusFree_05_tmp[7]["MMDL2HV1"][5].coin = 0;      m_BonusFree_05_tmp[7]["MMDL2HV1"][5].ag = 80; // 80
    m_BonusFree_05_tmp[7]["MMDL2HV1"][4].coin = 0;      m_BonusFree_05_tmp[7]["MMDL2HV1"][4].ag = 16;
    m_BonusFree_05_tmp[7]["MMDL2HV1"][3].coin = 600;    m_BonusFree_05_tmp[7]["MMDL2HV1"][3].ag = 1;
    m_BonusFree_05_tmp[7]["MMDL2HV2"][5].coin = 0;      m_BonusFree_05_tmp[7]["MMDL2HV2"][5].ag = 32;
    m_BonusFree_05_tmp[7]["MMDL2HV2"][4].coin = 400;    m_BonusFree_05_tmp[7]["MMDL2HV2"][4].ag = 6;
    m_BonusFree_05_tmp[7]["MMDL2Sca"][5].coin = 0;      m_BonusFree_05_tmp[7]["MMDL2Sca"][5].ag = 16;
    m_BonusFree_05_tmp[7]["MMDL2Sca"][4].coin = 600;    m_BonusFree_05_tmp[7]["MMDL2Sca"][4].ag = 1;
    m_BonusFree_05_tmp[7]["MMDL2HV3"][5].coin = 0;      m_BonusFree_05_tmp[7]["MMDL2HV3"][5].ag = 12;
    m_BonusFree_05_tmp[7]["MMDL2HV3"][4].coin = 600;    m_BonusFree_05_tmp[7]["MMDL2HV3"][4].ag = 1;
    m_BonusFree_05_tmp[7]["MMDL2HV4"][5].coin = 0;      m_BonusFree_05_tmp[7]["MMDL2HV4"][5].ag = 12;
    m_BonusFree_05_tmp[7]["MMDL2HV4"][4].coin = 600;    m_BonusFree_05_tmp[7]["MMDL2HV4"][4].ag = 1;
    m_BonusFree_05_tmp[7]["MMDL2_A_"][5].coin = 400;    m_BonusFree_05_tmp[7]["MMDL2_A_"][5].ag = 2;
    m_BonusFree_05_tmp[7]["MMDL2_K_"][5].coin = 400;    m_BonusFree_05_tmp[7]["MMDL2_K_"][5].ag = 2;
    m_BonusFree_05_tmp[7]["MMDL2_Q_"][5].coin = 600;    m_BonusFree_05_tmp[7]["MMDL2_Q_"][5].ag = 1;
    m_BonusFree_05_tmp[7]["MMDL2_J_"][5].coin = 600;    m_BonusFree_05_tmp[7]["MMDL2_J_"][5].ag = 1;
    m_BonusFree_05_tmp[7]["MMDL2_10"][5].coin = 600;    m_BonusFree_05_tmp[7]["MMDL2_10"][5].ag = 1;
    m_BonusFree_05_tmp[8]["MMDL2HV1"][5].coin = 0;      m_BonusFree_05_tmp[8]["MMDL2HV1"][5].ag = 100; // 100
    m_BonusFree_05_tmp[8]["MMDL2HV1"][4].coin = 0;      m_BonusFree_05_tmp[8]["MMDL2HV1"][4].ag = 20;
    m_BonusFree_05_tmp[8]["MMDL2HV1"][3].coin = 0;      m_BonusFree_05_tmp[8]["MMDL2HV1"][3].ag = 2;
    m_BonusFree_05_tmp[8]["MMDL2HV2"][5].coin = 0;      m_BonusFree_05_tmp[8]["MMDL2HV2"][5].ag = 40;
    m_BonusFree_05_tmp[8]["MMDL2HV2"][4].coin = 0;      m_BonusFree_05_tmp[8]["MMDL2HV2"][4].ag = 8;
    m_BonusFree_05_tmp[8]["MMDL2Sca"][5].coin = 0;      m_BonusFree_05_tmp[8]["MMDL2Sca"][5].ag = 20;
    m_BonusFree_05_tmp[8]["MMDL2Sca"][4].coin = 0;      m_BonusFree_05_tmp[8]["MMDL2Sca"][4].ag = 2;
    m_BonusFree_05_tmp[8]["MMDL2HV3"][5].coin = 0;      m_BonusFree_05_tmp[8]["MMDL2HV3"][5].ag = 15;
    m_BonusFree_05_tmp[8]["MMDL2HV3"][4].coin = 0;      m_BonusFree_05_tmp[8]["MMDL2HV3"][4].ag = 2;
    m_BonusFree_05_tmp[8]["MMDL2HV4"][5].coin = 0;      m_BonusFree_05_tmp[8]["MMDL2HV4"][5].ag = 15;
    m_BonusFree_05_tmp[8]["MMDL2HV4"][4].coin = 0;      m_BonusFree_05_tmp[8]["MMDL2HV4"][4].ag = 2;
    m_BonusFree_05_tmp[8]["MMDL2_A_"][5].coin = 0;      m_BonusFree_05_tmp[8]["MMDL2_A_"][5].ag = 3;
    m_BonusFree_05_tmp[8]["MMDL2_K_"][5].coin = 0;      m_BonusFree_05_tmp[8]["MMDL2_K_"][5].ag = 3;
    m_BonusFree_05_tmp[8]["MMDL2_Q_"][5].coin = 0;      m_BonusFree_05_tmp[8]["MMDL2_Q_"][5].ag = 2;
    m_BonusFree_05_tmp[8]["MMDL2_J_"][5].coin = 0;      m_BonusFree_05_tmp[8]["MMDL2_J_"][5].ag = 2;
    m_BonusFree_05_tmp[8]["MMDL2_10"][5].coin = 0;      m_BonusFree_05_tmp[8]["MMDL2_10"][5].ag = 2;
    m_BonusFree_05_tmp[9]["MMDL2HV1"][5].coin = 0;      m_BonusFree_05_tmp[9]["MMDL2HV1"][5].ag = 100; // 150
    m_BonusFree_05_tmp[9]["MMDL2HV1"][4].coin = 0;      m_BonusFree_05_tmp[9]["MMDL2HV1"][4].ag = 30;
    m_BonusFree_05_tmp[9]["MMDL2HV1"][3].coin = 0;      m_BonusFree_05_tmp[9]["MMDL2HV1"][3].ag = 3;
    m_BonusFree_05_tmp[9]["MMDL2HV2"][5].coin = 0;      m_BonusFree_05_tmp[9]["MMDL2HV2"][5].ag = 60;
    m_BonusFree_05_tmp[9]["MMDL2HV2"][4].coin = 0;      m_BonusFree_05_tmp[9]["MMDL2HV2"][4].ag = 12;
    m_BonusFree_05_tmp[9]["MMDL2HV2"][3].coin = 200;    m_BonusFree_05_tmp[9]["MMDL2HV2"][3].ag = 1;
    m_BonusFree_05_tmp[9]["MMDL2Sca"][5].coin = 0;      m_BonusFree_05_tmp[9]["MMDL2Sca"][5].ag = 30;
    m_BonusFree_05_tmp[9]["MMDL2Sca"][4].coin = 0;      m_BonusFree_05_tmp[9]["MMDL2Sca"][4].ag = 3;
    m_BonusFree_05_tmp[9]["MMDL2HV3"][5].coin = 500;    m_BonusFree_05_tmp[9]["MMDL2HV3"][5].ag = 22;
    m_BonusFree_05_tmp[9]["MMDL2HV3"][4].coin = 0;      m_BonusFree_05_tmp[9]["MMDL2HV3"][4].ag = 3;
    m_BonusFree_05_tmp[9]["MMDL2HV4"][5].coin = 500;    m_BonusFree_05_tmp[9]["MMDL2HV4"][5].ag = 22;
    m_BonusFree_05_tmp[9]["MMDL2HV4"][4].coin = 0;      m_BonusFree_05_tmp[9]["MMDL2HV4"][4].ag = 3;
    m_BonusFree_05_tmp[9]["MMDL2_A_"][5].coin = 500;    m_BonusFree_05_tmp[9]["MMDL2_A_"][5].ag = 4;
    m_BonusFree_05_tmp[9]["MMDL2_A_"][4].coin = 200;    m_BonusFree_05_tmp[9]["MMDL2_A_"][4].ag = 1;
    m_BonusFree_05_tmp[9]["MMDL2_K_"][5].coin = 500;    m_BonusFree_05_tmp[9]["MMDL2_K_"][5].ag = 4;
    m_BonusFree_05_tmp[9]["MMDL2_K_"][4].coin = 200;    m_BonusFree_05_tmp[9]["MMDL2_K_"][4].ag = 1;
    m_BonusFree_05_tmp[9]["MMDL2_Q_"][5].coin = 0;      m_BonusFree_05_tmp[9]["MMDL2_Q_"][5].ag = 3;
    m_BonusFree_05_tmp[9]["MMDL2_J_"][5].coin = 0;      m_BonusFree_05_tmp[9]["MMDL2_J_"][5].ag = 3;
    m_BonusFree_05_tmp[9]["MMDL2_10"][5].coin = 0;      m_BonusFree_05_tmp[9]["MMDL2_10"][5].ag = 3;
    m_BonusFree_05_tmp[10]["MMDL2HV1"][5].coin = 0;      m_BonusFree_05_tmp[10]["MMDL2HV1"][5].ag = 100; // 200
    m_BonusFree_05_tmp[10]["MMDL2HV1"][4].coin = 0;      m_BonusFree_05_tmp[10]["MMDL2HV1"][4].ag = 40;
    m_BonusFree_05_tmp[10]["MMDL2HV1"][3].coin = 0;      m_BonusFree_05_tmp[10]["MMDL2HV1"][3].ag = 4;
    m_BonusFree_05_tmp[10]["MMDL2HV2"][5].coin = 0;      m_BonusFree_05_tmp[10]["MMDL2HV2"][5].ag = 80;
    m_BonusFree_05_tmp[10]["MMDL2HV2"][4].coin = 0;      m_BonusFree_05_tmp[10]["MMDL2HV2"][4].ag = 16;
    m_BonusFree_05_tmp[10]["MMDL2HV2"][3].coin = 600;    m_BonusFree_05_tmp[10]["MMDL2HV2"][3].ag = 1;
    m_BonusFree_05_tmp[10]["MMDL2Sca"][5].coin = 0;      m_BonusFree_05_tmp[10]["MMDL2Sca"][5].ag = 40;
    m_BonusFree_05_tmp[10]["MMDL2Sca"][4].coin = 0;      m_BonusFree_05_tmp[10]["MMDL2Sca"][4].ag = 4;
    m_BonusFree_05_tmp[10]["MMDL2HV3"][5].coin = 0;      m_BonusFree_05_tmp[10]["MMDL2HV3"][5].ag = 30;
    m_BonusFree_05_tmp[10]["MMDL2HV3"][4].coin = 0;      m_BonusFree_05_tmp[10]["MMDL2HV3"][4].ag = 4;
    m_BonusFree_05_tmp[10]["MMDL2HV3"][3].coin = 200;    m_BonusFree_05_tmp[10]["MMDL2HV3"][3].ag = 1;
    m_BonusFree_05_tmp[10]["MMDL2HV4"][5].coin = 0;      m_BonusFree_05_tmp[10]["MMDL2HV4"][5].ag = 30;
    m_BonusFree_05_tmp[10]["MMDL2HV4"][4].coin = 0;      m_BonusFree_05_tmp[10]["MMDL2HV4"][4].ag = 4;
    m_BonusFree_05_tmp[10]["MMDL2HV4"][3].coin = 200;    m_BonusFree_05_tmp[10]["MMDL2HV4"][3].ag = 1;
    m_BonusFree_05_tmp[10]["MMDL2_A_"][5].coin = 0;      m_BonusFree_05_tmp[10]["MMDL2_A_"][5].ag = 6;
    m_BonusFree_05_tmp[10]["MMDL2_A_"][4].coin = 600;    m_BonusFree_05_tmp[10]["MMDL2_A_"][4].ag = 1;
    m_BonusFree_05_tmp[10]["MMDL2_K_"][5].coin = 0;      m_BonusFree_05_tmp[10]["MMDL2_K_"][5].ag = 6;
    m_BonusFree_05_tmp[10]["MMDL2_K_"][4].coin = 600;    m_BonusFree_05_tmp[10]["MMDL2_K_"][4].ag = 1;
    m_BonusFree_05_tmp[10]["MMDL2_Q_"][5].coin = 0;      m_BonusFree_05_tmp[10]["MMDL2_Q_"][5].ag = 4;
    m_BonusFree_05_tmp[10]["MMDL2_Q_"][4].coin = 0;      m_BonusFree_05_tmp[10]["MMDL2_Q_"][4].ag = 1;
    m_BonusFree_05_tmp[10]["MMDL2_J_"][5].coin = 0;      m_BonusFree_05_tmp[10]["MMDL2_J_"][5].ag = 4;
    m_BonusFree_05_tmp[10]["MMDL2_J_"][4].coin = 0;      m_BonusFree_05_tmp[10]["MMDL2_J_"][4].ag = 1;
    m_BonusFree_05_tmp[10]["MMDL2_10"][5].coin = 0;      m_BonusFree_05_tmp[10]["MMDL2_10"][5].ag = 4;
    m_BonusFree_05_tmp[10]["MMDL2_10"][4].coin = 0;      m_BonusFree_05_tmp[10]["MMDL2_10"][4].ag = 1;
    m_BonusFree_05_tmp[11]["MMDL2HV1"][5].coin = 0;      m_BonusFree_05_tmp[11]["MMDL2HV1"][5].ag = 500; // 500
    m_BonusFree_05_tmp[11]["MMDL2HV1"][4].coin = 0;      m_BonusFree_05_tmp[11]["MMDL2HV1"][4].ag = 100;
    m_BonusFree_05_tmp[11]["MMDL2HV2"][5].coin = 0;      m_BonusFree_05_tmp[11]["MMDL2HV2"][5].ag = 200;
    m_BonusFree_05_tmp[11]["MMDL2Sca"][5].coin = 0;      m_BonusFree_05_tmp[11]["MMDL2Sca"][5].ag = 100;
    m_BonusFree_05_tmp[11]["MMDL2HV3"][5].coin = 50000;  m_BonusFree_05_tmp[11]["MMDL2HV3"][5].ag = 25;
    m_BonusFree_05_tmp[11]["MMDL2HV4"][5].coin = 50000;  m_BonusFree_05_tmp[11]["MMDL2HV4"][5].ag = 25;
    m_BonusFree_05_tmp[12]["MMDL2HV1"][5].coin = 0;      m_BonusFree_05_tmp[12]["MMDL2HV1"][5].ag = 1000; // 1000
    m_BonusFree_05_tmp[12]["MMDL2HV1"][4].coin = 0;      m_BonusFree_05_tmp[12]["MMDL2HV1"][4].ag = 200;
    m_BonusFree_05_tmp[12]["MMDL2HV2"][5].coin = 0;      m_BonusFree_05_tmp[12]["MMDL2HV2"][5].ag = 400;
    m_BonusFree_05_tmp[12]["MMDL2HV2"][4].coin = 50000;  m_BonusFree_05_tmp[12]["MMDL2HV2"][4].ag = 30;
    m_BonusFree_05_tmp[12]["MMDL2Sca"][5].coin = 0;      m_BonusFree_05_tmp[12]["MMDL2Sca"][5].ag = 200;
    m_BonusFree_05_tmp[12]["MMDL2HV3"][5].coin = 50000;  m_BonusFree_05_tmp[12]["MMDL2HV3"][5].ag = 100;
    m_BonusFree_05_tmp[12]["MMDL2HV4"][5].coin = 50000;  m_BonusFree_05_tmp[12]["MMDL2HV4"][5].ag = 100;

    for (int i = 0; i < m_vecBetSteps_10_tmp.size(); i++) {
        std::map<std::string, std::map<UINT8, BONUS>> perSym;
        std::map<UINT8, BONUS> e;
        e[3].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 25; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 100; e[5].ag = 0;
        perSym["MMDL2_10"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 25; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 100; e[5].ag = 0;
        perSym["MMDL2_J_"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 25; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 100; e[5].ag = 0;
        perSym["MMDL2_Q_"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 40; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 150; e[5].ag = 0;
        perSym["MMDL2_K_"] = e;

        e[3].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 40; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 150; e[5].ag = 0;
        perSym["MMDL2_A_"] = e;
        e.clear();

        e[2].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 5; e[2].ag = 0;
        e[3].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 30; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 750; e[5].ag = 0;
        perSym["MMDL2HV4"] = e;
        e.clear();

        e[2].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 5; e[2].ag = 0;
        e[3].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 30; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 750; e[5].ag = 0;
        perSym["MMDL2HV3"] = e;
        e.clear();

        e[2].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 5; e[2].ag = 0;
        e[3].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 40; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 400; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 2000; e[5].ag = 0;
        perSym["MMDL2HV2"] = e;
        e.clear();

        e[2].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 10; e[2].ag = 0;
        e[3].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 100; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 1000; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 5000; e[5].ag = 0;
        perSym["MMDL2HV1"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 200; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 2000; e[5].ag = 0;
        perSym["MMDL2Sca"] = e;
        e.clear();

        m_Bonus_10_tmp[i] = perSym;
    }

    m_Bonus_10_tmp[8]["MMDL2HV1"][5].coin = 50000; m_Bonus_10_tmp[8]["MMDL2HV1"][5].ag = 25; // 150
    m_Bonus_10_tmp[9]["MMDL2HV1"][5].coin = 50000; m_Bonus_10_tmp[9]["MMDL2HV1"][5].ag = 50; // 200
    m_Bonus_10_tmp[10]["MMDL2HV1"][5].coin = 50000; m_Bonus_10_tmp[10]["MMDL2HV1"][5].ag = 100; // 400
    m_Bonus_10_tmp[10]["MMDL2HV2"][5].coin = 50000; m_Bonus_10_tmp[10]["MMDL2HV2"][5].ag = 30;
    m_Bonus_10_tmp[10]["MMDL2Sca"][5].coin = 50000; m_Bonus_10_tmp[10]["MMDL2Sca"][5].ag = 30;
    m_Bonus_10_tmp[11]["MMDL2Sca"][5].coin = 50000; m_Bonus_10_tmp[11]["MMDL2Sca"][5].ag = 150;  // 1000
    m_Bonus_10_tmp[11]["MMDL2HV1"][5].coin = 50000; m_Bonus_10_tmp[11]["MMDL2HV1"][5].ag = 450; 
    m_Bonus_10_tmp[11]["MMDL2HV1"][4].coin = 50000; m_Bonus_10_tmp[11]["MMDL2HV1"][4].ag = 50; 
    m_Bonus_10_tmp[11]["MMDL2HV2"][5].coin = 50000; m_Bonus_10_tmp[11]["MMDL2HV2"][5].ag = 150;
    m_Bonus_10_tmp[11]["MMDL2HV3"][5].coin = 50000; m_Bonus_10_tmp[11]["MMDL2HV3"][5].ag = 25;
    m_Bonus_10_tmp[11]["MMDL2HV4"][5].coin = 50000; m_Bonus_10_tmp[11]["MMDL2HV4"][5].ag = 25;
    m_Bonus_10_tmp[12]["MMDL2Sca"][5].coin = 50000; m_Bonus_10_tmp[12]["MMDL2Sca"][5].ag = 350;  // 2000
    m_Bonus_10_tmp[12]["MMDL2HV1"][5].coin = 50000; m_Bonus_10_tmp[12]["MMDL2HV1"][5].ag = 950; 
    m_Bonus_10_tmp[12]["MMDL2HV1"][4].coin = 50000; m_Bonus_10_tmp[12]["MMDL2HV1"][4].ag = 150; 
    m_Bonus_10_tmp[12]["MMDL2HV2"][5].coin = 50000; m_Bonus_10_tmp[12]["MMDL2HV2"][5].ag = 350;
    m_Bonus_10_tmp[12]["MMDL2HV2"][4].coin = 50000; m_Bonus_10_tmp[12]["MMDL2HV2"][4].ag = 30;
    m_Bonus_10_tmp[12]["MMDL2HV3"][5].coin = 50000; m_Bonus_10_tmp[12]["MMDL2HV3"][5].ag = 100;
    m_Bonus_10_tmp[12]["MMDL2HV4"][5].coin = 50000; m_Bonus_10_tmp[12]["MMDL2HV4"][5].ag = 100;

    m_BonusFree_10_tmp = m_Bonus_10_tmp;
    m_BonusFree_10_tmp[0]["MMDL2HV1"][5].coin = 0;      m_BonusFree_10_tmp[0]["MMDL2HV1"][5].ag = 5; //10
    m_BonusFree_10_tmp[0]["MMDL2HV1"][4].coin = 0;      m_BonusFree_10_tmp[0]["MMDL2HV1"][4].ag = 1;
    m_BonusFree_10_tmp[0]["MMDL2HV2"][5].coin = 0;      m_BonusFree_10_tmp[0]["MMDL2HV2"][5].ag = 2;
    m_BonusFree_10_tmp[0]["MMDL2Sca"][5].coin = 0;      m_BonusFree_10_tmp[0]["MMDL2Sca"][5].ag = 2;
    m_BonusFree_10_tmp[1]["MMDL2HV1"][5].coin = 0;      m_BonusFree_10_tmp[1]["MMDL2HV1"][5].ag = 10; // 20
    m_BonusFree_10_tmp[1]["MMDL2HV1"][4].coin = 0;      m_BonusFree_10_tmp[1]["MMDL2HV1"][4].ag = 2;
    m_BonusFree_10_tmp[1]["MMDL2HV2"][5].coin = 0;      m_BonusFree_10_tmp[1]["MMDL2HV2"][5].ag = 4;
    m_BonusFree_10_tmp[1]["MMDL2Sca"][5].coin = 0;      m_BonusFree_10_tmp[1]["MMDL2Sca"][5].ag = 4;
    m_BonusFree_10_tmp[1]["MMDL2HV3"][5].coin = 500;    m_BonusFree_10_tmp[1]["MMDL2HV3"][5].ag = 1;
    m_BonusFree_10_tmp[1]["MMDL2HV4"][5].coin = 500;    m_BonusFree_10_tmp[1]["MMDL2HV4"][5].ag = 1;
    m_BonusFree_10_tmp[2]["MMDL2HV1"][5].coin = 0;      m_BonusFree_10_tmp[2]["MMDL2HV1"][5].ag = 15; // 30
    m_BonusFree_10_tmp[2]["MMDL2HV1"][4].coin = 0;      m_BonusFree_10_tmp[2]["MMDL2HV1"][4].ag = 3;
    m_BonusFree_10_tmp[2]["MMDL2HV2"][5].coin = 0;      m_BonusFree_10_tmp[2]["MMDL2HV2"][5].ag = 6;
    m_BonusFree_10_tmp[2]["MMDL2HV2"][5].coin = 200;    m_BonusFree_10_tmp[2]["MMDL2HV2"][5].ag = 1;
    m_BonusFree_10_tmp[2]["MMDL2Sca"][5].coin = 0;      m_BonusFree_10_tmp[2]["MMDL2Sca"][5].ag = 6;
    m_BonusFree_10_tmp[2]["MMDL2HV3"][5].coin = 250;    m_BonusFree_10_tmp[2]["MMDL2HV3"][5].ag = 2;
    m_BonusFree_10_tmp[2]["MMDL2HV4"][5].coin = 250;    m_BonusFree_10_tmp[2]["MMDL2HV4"][5].ag = 2;
    m_BonusFree_10_tmp[3]["MMDL2HV1"][5].coin = 0;      m_BonusFree_10_tmp[3]["MMDL2HV1"][5].ag = 20; // 40
    m_BonusFree_10_tmp[3]["MMDL2HV1"][4].coin = 0;      m_BonusFree_10_tmp[3]["MMDL2HV1"][4].ag = 4;
    m_BonusFree_10_tmp[3]["MMDL2HV2"][5].coin = 0;      m_BonusFree_10_tmp[3]["MMDL2HV2"][5].ag = 8;
    m_BonusFree_10_tmp[3]["MMDL2HV2"][4].coin = 600;    m_BonusFree_10_tmp[3]["MMDL2HV2"][4].ag = 1;
    m_BonusFree_10_tmp[3]["MMDL2Sca"][5].coin = 0;      m_BonusFree_10_tmp[3]["MMDL2Sca"][5].ag = 8;
    m_BonusFree_10_tmp[3]["MMDL2HV3"][5].coin = 0;      m_BonusFree_10_tmp[3]["MMDL2HV3"][5].ag = 3;
    m_BonusFree_10_tmp[3]["MMDL2HV4"][5].coin = 0;      m_BonusFree_10_tmp[3]["MMDL2HV4"][5].ag = 3;
    m_BonusFree_10_tmp[4]["MMDL2HV1"][5].coin = 0;      m_BonusFree_10_tmp[4]["MMDL2HV1"][5].ag = 25; // 50
    m_BonusFree_10_tmp[4]["MMDL2HV1"][4].coin = 0;      m_BonusFree_10_tmp[4]["MMDL2HV1"][4].ag = 5;
    m_BonusFree_10_tmp[4]["MMDL2HV2"][5].coin = 0;      m_BonusFree_10_tmp[4]["MMDL2HV2"][5].ag = 10;
    m_BonusFree_10_tmp[4]["MMDL2HV2"][4].coin = 0;      m_BonusFree_10_tmp[4]["MMDL2HV2"][4].ag = 2;
    m_BonusFree_10_tmp[4]["MMDL2Sca"][5].coin = 0;      m_BonusFree_10_tmp[4]["MMDL2Sca"][5].ag = 10;
    m_BonusFree_10_tmp[4]["MMDL2Sca"][4].coin = 0;      m_BonusFree_10_tmp[4]["MMDL2Sca"][4].ag = 1;
    m_BonusFree_10_tmp[4]["MMDL2HV3"][5].coin = 750;    m_BonusFree_10_tmp[4]["MMDL2HV3"][5].ag = 3;
    m_BonusFree_10_tmp[4]["MMDL2HV4"][5].coin = 750;    m_BonusFree_10_tmp[4]["MMDL2HV4"][5].ag = 3;
    m_BonusFree_10_tmp[5]["MMDL2HV1"][5].coin = 0;      m_BonusFree_10_tmp[5]["MMDL2HV1"][5].ag = 30; // 60
    m_BonusFree_10_tmp[5]["MMDL2HV1"][4].coin = 0;      m_BonusFree_10_tmp[5]["MMDL2HV1"][4].ag = 6;
    m_BonusFree_10_tmp[5]["MMDL2HV2"][5].coin = 0;      m_BonusFree_10_tmp[5]["MMDL2HV2"][5].ag = 12;
    m_BonusFree_10_tmp[5]["MMDL2HV2"][4].coin = 400;    m_BonusFree_10_tmp[5]["MMDL2HV2"][4].ag = 2;
    m_BonusFree_10_tmp[5]["MMDL2Sca"][5].coin = 0;      m_BonusFree_10_tmp[5]["MMDL2Sca"][5].ag = 12;
    m_BonusFree_10_tmp[5]["MMDL2Sca"][4].coin = 200;    m_BonusFree_10_tmp[5]["MMDL2Sca"][4].ag = 1;
    m_BonusFree_10_tmp[5]["MMDL2HV3"][5].coin = 500;    m_BonusFree_10_tmp[5]["MMDL2HV3"][5].ag = 4;
    m_BonusFree_10_tmp[5]["MMDL2HV4"][5].coin = 500;    m_BonusFree_10_tmp[5]["MMDL2HV4"][5].ag = 4;
    m_BonusFree_10_tmp[6]["MMDL2HV1"][5].coin = 0;      m_BonusFree_10_tmp[6]["MMDL2HV1"][5].ag = 40; // 80
    m_BonusFree_10_tmp[6]["MMDL2HV1"][4].coin = 0;      m_BonusFree_10_tmp[6]["MMDL2HV1"][4].ag = 8;
    m_BonusFree_10_tmp[6]["MMDL2HV2"][5].coin = 0;      m_BonusFree_10_tmp[6]["MMDL2HV2"][5].ag = 16;
    m_BonusFree_10_tmp[6]["MMDL2HV2"][4].coin = 200;    m_BonusFree_10_tmp[6]["MMDL2HV2"][4].ag = 3;
    m_BonusFree_10_tmp[6]["MMDL2Sca"][5].coin = 0;      m_BonusFree_10_tmp[6]["MMDL2Sca"][5].ag = 18;
    m_BonusFree_10_tmp[6]["MMDL2Sca"][4].coin = 600;    m_BonusFree_10_tmp[6]["MMDL2Sca"][4].ag = 1;
    m_BonusFree_10_tmp[6]["MMDL2HV3"][5].coin = 0;      m_BonusFree_10_tmp[6]["MMDL2HV3"][5].ag = 6;
    m_BonusFree_10_tmp[6]["MMDL2HV4"][5].coin = 0;      m_BonusFree_10_tmp[6]["MMDL2HV4"][5].ag = 6;
    m_BonusFree_10_tmp[6]["MMDL2_A_"][5].coin = 200;    m_BonusFree_10_tmp[6]["MMDL2_A_"][5].ag = 1;
    m_BonusFree_10_tmp[6]["MMDL2_K_"][5].coin = 200;    m_BonusFree_10_tmp[6]["MMDL2_K_"][5].ag = 1;
    m_BonusFree_10_tmp[7]["MMDL2HV1"][5].coin = 0;      m_BonusFree_10_tmp[7]["MMDL2HV1"][5].ag = 50; // 100
    m_BonusFree_10_tmp[7]["MMDL2HV1"][4].coin = 0;      m_BonusFree_10_tmp[7]["MMDL2HV1"][4].ag = 10;
    m_BonusFree_10_tmp[7]["MMDL2HV1"][3].coin = 0;      m_BonusFree_10_tmp[7]["MMDL2HV1"][3].ag = 1;
    m_BonusFree_10_tmp[7]["MMDL2HV2"][5].coin = 0;      m_BonusFree_10_tmp[7]["MMDL2HV2"][5].ag = 20;
    m_BonusFree_10_tmp[7]["MMDL2HV2"][4].coin = 0;      m_BonusFree_10_tmp[7]["MMDL2HV2"][4].ag = 4;
    m_BonusFree_10_tmp[7]["MMDL2Sca"][5].coin = 0;      m_BonusFree_10_tmp[7]["MMDL2Sca"][5].ag = 20;
    m_BonusFree_10_tmp[7]["MMDL2Sca"][4].coin = 0;      m_BonusFree_10_tmp[7]["MMDL2Sca"][4].ag = 2;
    m_BonusFree_10_tmp[7]["MMDL2HV3"][5].coin = 500;    m_BonusFree_10_tmp[7]["MMDL2HV3"][5].ag = 7;
    m_BonusFree_10_tmp[7]["MMDL2HV3"][4].coin = 0;      m_BonusFree_10_tmp[7]["MMDL2HV3"][4].ag = 1;
    m_BonusFree_10_tmp[7]["MMDL2HV4"][5].coin = 500;    m_BonusFree_10_tmp[7]["MMDL2HV4"][5].ag = 7;
    m_BonusFree_10_tmp[7]["MMDL2HV4"][4].coin = 0;      m_BonusFree_10_tmp[7]["MMDL2HV4"][4].ag = 1;
    m_BonusFree_10_tmp[7]["MMDL2_A_"][5].coin = 500;    m_BonusFree_10_tmp[7]["MMDL2_A_"][5].ag = 1;
    m_BonusFree_10_tmp[7]["MMDL2_K_"][5].coin = 500;    m_BonusFree_10_tmp[7]["MMDL2_K_"][5].ag = 1;
    m_BonusFree_10_tmp[7]["MMDL2_Q_"][5].coin = 0;      m_BonusFree_10_tmp[7]["MMDL2_Q_"][5].ag = 1;
    m_BonusFree_10_tmp[7]["MMDL2_J_"][5].coin = 0;      m_BonusFree_10_tmp[7]["MMDL2_J_"][5].ag = 1;
    m_BonusFree_10_tmp[7]["MMDL2_10"][5].coin = 0;      m_BonusFree_10_tmp[7]["MMDL2_10"][5].ag = 1;
    m_BonusFree_10_tmp[8]["MMDL2HV1"][5].coin = 0;      m_BonusFree_10_tmp[8]["MMDL2HV1"][5].ag = 75; // 150
    m_BonusFree_10_tmp[8]["MMDL2HV1"][4].coin = 0;      m_BonusFree_10_tmp[8]["MMDL2HV1"][4].ag = 15;
    m_BonusFree_10_tmp[8]["MMDL2HV1"][3].coin = 500;    m_BonusFree_10_tmp[8]["MMDL2HV1"][3].ag = 1;
    m_BonusFree_10_tmp[8]["MMDL2HV2"][5].coin = 0;      m_BonusFree_10_tmp[8]["MMDL2HV2"][5].ag = 30;
    m_BonusFree_10_tmp[8]["MMDL2HV2"][4].coin = 0;      m_BonusFree_10_tmp[8]["MMDL2HV2"][4].ag = 6;
    m_BonusFree_10_tmp[8]["MMDL2Sca"][5].coin = 0;      m_BonusFree_10_tmp[8]["MMDL2Sca"][5].ag = 30;
    m_BonusFree_10_tmp[8]["MMDL2Sca"][4].coin = 0;      m_BonusFree_10_tmp[8]["MMDL2Sca"][4].ag = 3;
    m_BonusFree_10_tmp[8]["MMDL2HV3"][5].coin = 250;    m_BonusFree_10_tmp[8]["MMDL2HV3"][5].ag = 11;
    m_BonusFree_10_tmp[8]["MMDL2HV3"][4].coin = 500;    m_BonusFree_10_tmp[8]["MMDL2HV3"][4].ag = 1;
    m_BonusFree_10_tmp[8]["MMDL2HV4"][5].coin = 250;    m_BonusFree_10_tmp[8]["MMDL2HV4"][5].ag = 11;
    m_BonusFree_10_tmp[8]["MMDL2HV4"][4].coin = 500;    m_BonusFree_10_tmp[8]["MMDL2HV4"][4].ag = 1;
    m_BonusFree_10_tmp[8]["MMDL2_A_"][5].coin = 250;    m_BonusFree_10_tmp[8]["MMDL2_A_"][5].ag = 2;
    m_BonusFree_10_tmp[8]["MMDL2_K_"][5].coin = 250;    m_BonusFree_10_tmp[8]["MMDL2_K_"][5].ag = 2;
    m_BonusFree_10_tmp[8]["MMDL2_Q_"][5].coin = 500;    m_BonusFree_10_tmp[8]["MMDL2_Q_"][5].ag = 1;
    m_BonusFree_10_tmp[8]["MMDL2_J_"][5].coin = 500;    m_BonusFree_10_tmp[8]["MMDL2_J_"][5].ag = 1;
    m_BonusFree_10_tmp[8]["MMDL2_10"][5].coin = 500;    m_BonusFree_10_tmp[8]["MMDL2_10"][5].ag = 1;
    m_BonusFree_10_tmp[9]["MMDL2HV1"][5].coin = 0;      m_BonusFree_10_tmp[9]["MMDL2HV1"][5].ag = 100; // 200
    m_BonusFree_10_tmp[9]["MMDL2HV1"][4].coin = 0;      m_BonusFree_10_tmp[9]["MMDL2HV1"][4].ag = 20;
    m_BonusFree_10_tmp[9]["MMDL2HV1"][3].coin = 0;      m_BonusFree_10_tmp[9]["MMDL2HV1"][3].ag = 2;
    m_BonusFree_10_tmp[9]["MMDL2HV2"][5].coin = 0;      m_BonusFree_10_tmp[9]["MMDL2HV2"][5].ag = 40;
    m_BonusFree_10_tmp[9]["MMDL2HV2"][4].coin = 0;      m_BonusFree_10_tmp[9]["MMDL2HV2"][4].ag = 8;
    m_BonusFree_10_tmp[9]["MMDL2Sca"][5].coin = 0;      m_BonusFree_10_tmp[9]["MMDL2Sca"][5].ag = 40;
    m_BonusFree_10_tmp[9]["MMDL2Sca"][4].coin = 0;      m_BonusFree_10_tmp[9]["MMDL2Sca"][4].ag = 4;
    m_BonusFree_10_tmp[9]["MMDL2HV3"][5].coin = 0;      m_BonusFree_10_tmp[9]["MMDL2HV3"][5].ag = 15;
    m_BonusFree_10_tmp[9]["MMDL2HV3"][4].coin = 0;      m_BonusFree_10_tmp[9]["MMDL2HV3"][4].ag = 2;
    m_BonusFree_10_tmp[9]["MMDL2HV4"][5].coin = 0;      m_BonusFree_10_tmp[9]["MMDL2HV4"][5].ag = 15;
    m_BonusFree_10_tmp[9]["MMDL2HV4"][4].coin = 0;      m_BonusFree_10_tmp[9]["MMDL2HV4"][4].ag = 2;
    m_BonusFree_10_tmp[9]["MMDL2_A_"][5].coin = 0;      m_BonusFree_10_tmp[9]["MMDL2_A_"][5].ag = 3;
    m_BonusFree_10_tmp[9]["MMDL2_K_"][5].coin = 0;      m_BonusFree_10_tmp[9]["MMDL2_K_"][5].ag = 3;
    m_BonusFree_10_tmp[9]["MMDL2_Q_"][5].coin = 0;      m_BonusFree_10_tmp[9]["MMDL2_Q_"][5].ag = 2;
    m_BonusFree_10_tmp[9]["MMDL2_J_"][5].coin = 0;      m_BonusFree_10_tmp[9]["MMDL2_J_"][5].ag = 2;
    m_BonusFree_10_tmp[9]["MMDL2_10"][5].coin = 0;      m_BonusFree_10_tmp[9]["MMDL2_10"][5].ag = 2;
    m_BonusFree_10_tmp[10]["MMDL2HV1"][5].coin = 0;      m_BonusFree_10_tmp[10]["MMDL2HV1"][5].ag = 100; // 400
    m_BonusFree_10_tmp[10]["MMDL2HV1"][4].coin = 0;      m_BonusFree_10_tmp[10]["MMDL2HV1"][4].ag = 40;
    m_BonusFree_10_tmp[10]["MMDL2HV1"][3].coin = 0;      m_BonusFree_10_tmp[10]["MMDL2HV1"][3].ag = 4;
    m_BonusFree_10_tmp[10]["MMDL2HV2"][5].coin = 0;      m_BonusFree_10_tmp[10]["MMDL2HV2"][5].ag = 80;
    m_BonusFree_10_tmp[10]["MMDL2HV2"][4].coin = 0;      m_BonusFree_10_tmp[10]["MMDL2HV2"][4].ag = 16;
    m_BonusFree_10_tmp[10]["MMDL2HV2"][3].coin = 600;    m_BonusFree_10_tmp[10]["MMDL2HV2"][3].ag = 1;
    m_BonusFree_10_tmp[10]["MMDL2Sca"][5].coin = 0;      m_BonusFree_10_tmp[10]["MMDL2Sca"][5].ag = 80;
    m_BonusFree_10_tmp[10]["MMDL2Sca"][4].coin = 0;      m_BonusFree_10_tmp[10]["MMDL2Sca"][4].ag = 8;
    m_BonusFree_10_tmp[10]["MMDL2HV3"][5].coin = 0;      m_BonusFree_10_tmp[10]["MMDL2HV3"][5].ag = 30;
    m_BonusFree_10_tmp[10]["MMDL2HV3"][4].coin = 0;      m_BonusFree_10_tmp[10]["MMDL2HV3"][4].ag = 4;
    m_BonusFree_10_tmp[10]["MMDL2HV3"][3].coin = 200;    m_BonusFree_10_tmp[10]["MMDL2HV3"][3].ag = 1;
    m_BonusFree_10_tmp[10]["MMDL2HV4"][5].coin = 0;      m_BonusFree_10_tmp[10]["MMDL2HV4"][5].ag = 30;
    m_BonusFree_10_tmp[10]["MMDL2HV4"][4].coin = 0;      m_BonusFree_10_tmp[10]["MMDL2HV4"][4].ag = 4;
    m_BonusFree_10_tmp[10]["MMDL2HV4"][3].coin = 200;    m_BonusFree_10_tmp[10]["MMDL2HV4"][3].ag = 1;
    m_BonusFree_10_tmp[10]["MMDL2_A_"][5].coin = 0;      m_BonusFree_10_tmp[10]["MMDL2_A_"][5].ag = 6;
    m_BonusFree_10_tmp[10]["MMDL2_A_"][4].coin = 600;    m_BonusFree_10_tmp[10]["MMDL2_A_"][4].ag = 1;
    m_BonusFree_10_tmp[10]["MMDL2_K_"][5].coin = 0;      m_BonusFree_10_tmp[10]["MMDL2_K_"][5].ag = 6;
    m_BonusFree_10_tmp[10]["MMDL2_K_"][4].coin = 600;    m_BonusFree_10_tmp[10]["MMDL2_K_"][4].ag = 1;
    m_BonusFree_10_tmp[10]["MMDL2_Q_"][5].coin = 0;      m_BonusFree_10_tmp[10]["MMDL2_Q_"][5].ag = 4;
    m_BonusFree_10_tmp[10]["MMDL2_Q_"][4].coin = 0;      m_BonusFree_10_tmp[10]["MMDL2_Q_"][4].ag = 1;
    m_BonusFree_10_tmp[10]["MMDL2_J_"][5].coin = 0;      m_BonusFree_10_tmp[10]["MMDL2_J_"][5].ag = 4;
    m_BonusFree_10_tmp[10]["MMDL2_J_"][4].coin = 0;      m_BonusFree_10_tmp[10]["MMDL2_J_"][4].ag = 1;
    m_BonusFree_10_tmp[10]["MMDL2_10"][5].coin = 0;      m_BonusFree_10_tmp[10]["MMDL2_10"][5].ag = 4;
    m_BonusFree_10_tmp[10]["MMDL2_10"][4].coin = 0;      m_BonusFree_10_tmp[10]["MMDL2_10"][4].ag = 1;
    m_BonusFree_10_tmp[11]["MMDL2HV1"][5].coin = 0;      m_BonusFree_10_tmp[11]["MMDL2HV1"][5].ag = 500; // 1000
    m_BonusFree_10_tmp[11]["MMDL2HV1"][4].coin = 0;      m_BonusFree_10_tmp[11]["MMDL2HV1"][4].ag = 100;
    m_BonusFree_10_tmp[11]["MMDL2HV2"][5].coin = 0;      m_BonusFree_10_tmp[11]["MMDL2HV2"][5].ag = 200;
    m_BonusFree_10_tmp[11]["MMDL2Sca"][5].coin = 0;      m_BonusFree_10_tmp[11]["MMDL2Sca"][5].ag = 200;
    m_BonusFree_10_tmp[11]["MMDL2HV3"][5].coin = 50000;  m_BonusFree_10_tmp[11]["MMDL2HV3"][5].ag = 25;
    m_BonusFree_10_tmp[11]["MMDL2HV4"][5].coin = 50000;  m_BonusFree_10_tmp[11]["MMDL2HV4"][5].ag = 25;
    m_BonusFree_10_tmp[12]["MMDL2HV1"][5].coin = 0;      m_BonusFree_10_tmp[12]["MMDL2HV1"][5].ag = 1000; // 2000
    m_BonusFree_10_tmp[12]["MMDL2HV1"][4].coin = 0;      m_BonusFree_10_tmp[12]["MMDL2HV1"][4].ag = 200;
    m_BonusFree_10_tmp[12]["MMDL2HV2"][5].coin = 0;      m_BonusFree_10_tmp[12]["MMDL2HV2"][5].ag = 400;
    m_BonusFree_10_tmp[12]["MMDL2HV2"][4].coin = 50000;  m_BonusFree_10_tmp[12]["MMDL2HV2"][4].ag = 30;
    m_BonusFree_10_tmp[12]["MMDL2Sca"][5].coin = 0;      m_BonusFree_10_tmp[12]["MMDL2Sca"][5].ag = 400;
    m_BonusFree_10_tmp[12]["MMDL2HV3"][5].coin = 50000;  m_BonusFree_10_tmp[12]["MMDL2HV3"][5].ag = 100;
    m_BonusFree_10_tmp[12]["MMDL2HV4"][5].coin = 50000;  m_BonusFree_10_tmp[12]["MMDL2HV4"][5].ag = 100;

    int nSavedBetVal = 10;
    string data;
    PlayDB::GetInstance().LoadCheckPoint(m_strGameName, nSavedBetVal, m_nWinLine, m_strCheckPoint);
    if (nSavedBetVal == -1) {
        nSavedBetVal = 10;
    }
    if (m_nWinLine == -1) {
        m_nWinLine = 5;
    }

    BOOL start = FALSE;
    int idx = 0;
    for (int i = 0; i < m_vecBetSteps_05_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_05_tmp, i) < AT(m_vecBetSteps_05, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps_05, idx) == nSavedBetVal && m_nWinLine == 5) {
            m_nBetStep = idx;
        }

        m_Bonus_05[idx] = m_Bonus_05_tmp[i];
        m_BonusFree_05[idx] = m_BonusFree_05_tmp[i];
        idx++;
        if (AT(m_vecBetSteps_05_tmp, i) == AT(m_vecBetSteps_05, m_vecBetSteps_05.size() - 1)) {
            break;
        }
    }
    start = FALSE;
    idx = 0;
    for (int i = 0; i < m_vecBetSteps_10_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_10_tmp, i) < AT(m_vecBetSteps_10, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps_10, idx) == nSavedBetVal && m_nWinLine == 10) {
            m_nBetStep = idx;
        }

        m_Bonus_10[idx] = m_Bonus_10_tmp[i];
        m_BonusFree_10[idx] = m_BonusFree_10_tmp[i];
        idx++;
        if (AT(m_vecBetSteps_10_tmp, i) == AT(m_vecBetSteps_10, m_vecBetSteps_10.size() - 1)) {
            break;
        }
    }
    m_Bonus = (m_nWinLine == 5 ? m_Bonus_05 : m_Bonus_10);
    m_vecBetSteps = (m_nWinLine == 5 ? m_vecBetSteps_05 : m_vecBetSteps_10);

    PrintAllBonus();
    PrintBonusSet("================== FreeMode Bonus Line 5 ==========================",
        m_vecBetSteps_05, m_BonusFree_05);
    PrintBonusSet("================== FreeMode Bonus Line 10 ==========================",
        m_vecBetSteps_10, m_BonusFree_10);

    m_vWinLineSounds["MMDL2_10_3"] = SMP_MMDL2_win_tiny;
    m_vWinLineSounds["MMDL2_10_4"] = SMP_MMDL2_win_small;
    m_vWinLineSounds["MMDL2_10_5"] = SMP_MMDL2_win_middle;
    m_vWinLineSounds["MMDL2_J__3"] = SMP_MMDL2_win_tiny;
    m_vWinLineSounds["MMDL2_J__4"] = SMP_MMDL2_win_small;
    m_vWinLineSounds["MMDL2_J__5"] = SMP_MMDL2_win_middle;
    m_vWinLineSounds["MMDL2_Q__3"] = SMP_MMDL2_win_tiny;
    m_vWinLineSounds["MMDL2_Q__4"] = SMP_MMDL2_win_small;
    m_vWinLineSounds["MMDL2_Q__5"] = SMP_MMDL2_win_middle;
    m_vWinLineSounds["MMDL2_K__3"] = SMP_MMDL2_win_tiny;
    m_vWinLineSounds["MMDL2_K__4"] = SMP_MMDL2_win_small;
    m_vWinLineSounds["MMDL2_K__5"] = SMP_MMDL2_win_middle;
    m_vWinLineSounds["MMDL2_A__3"] = SMP_MMDL2_win_tiny;
    m_vWinLineSounds["MMDL2_A__4"] = SMP_MMDL2_win_small;
    m_vWinLineSounds["MMDL2_A__5"] = SMP_MMDL2_win_middle;
    m_vWinLineSounds["MMDL2HV4_2"] = SMP_MMDL2_win_tiny;
    m_vWinLineSounds["MMDL2HV4_3"] = SMP_MMDL2_win_small;
    m_vWinLineSounds["MMDL2HV4_4"] = SMP_MMDL2_win_hv_middle;
    m_vWinLineSounds["MMDL2HV4_5"] = SMP_MMDL2_win_hv_middle;
    m_vWinLineSounds["MMDL2HV3_2"] = SMP_MMDL2_win_tiny;
    m_vWinLineSounds["MMDL2HV3_3"] = SMP_MMDL2_win_small;
    m_vWinLineSounds["MMDL2HV3_4"] = SMP_MMDL2_win_hv_middle;
    m_vWinLineSounds["MMDL2HV3_5"] = SMP_MMDL2_win_hv_middle;
    m_vWinLineSounds["MMDL2HV2_2"] = SMP_MMDL2_win_tiny;
    m_vWinLineSounds["MMDL2HV2_3"] = SMP_MMDL2_win_small;
    m_vWinLineSounds["MMDL2HV2_4"] = SMP_MMDL2_win_hv_huge;
    m_vWinLineSounds["MMDL2HV2_5"] = SMP_MMDL2_win_hv_huge;
    m_vWinLineSounds["MMDL2HV1_2"] = SMP_MMDL2_win_tiny;
    m_vWinLineSounds["MMDL2HV1_3"] = SMP_MMDL2_win_small;
    m_vWinLineSounds["MMDL2HV1_4"] = SMP_MMDL2_win_maxwin;
    m_vWinLineSounds["MMDL2HV1_5"] = SMP_MMDL2_win_maxwin;
    m_vWinLineSounds["MMDL2Sca_3"] = SMP_MMDL2_feature_trigger;
    m_vWinLineSounds["MMDL2Sca_4"] = SMP_MMDL2_feature_trigger;
    m_vWinLineSounds["MMDL2Sca_5"] = SMP_MMDL2_feature_trigger;
}

UINT16 RgMagicMirrorDeluxe2::Run() {
    m_nCurrentReelPlan = 1 + (myRandom() % (m_vecReelStripPlan.size() - 1));
#ifdef TEST_FREE_MODE
    m_nCurrentReelPlan = 0;
#endif
    m_shCurrentReelStrip = static_cast<uint16_t>(std::stoi(AT(m_vecReelStripPlan, m_nCurrentReelPlan)));
    return m_shCurrentReelStrip;
}

void RgMagicMirrorDeluxe2::ChangeReelStrip(UINT16 NewReelPlan) {
    m_nCurrentReelPlan = NewReelPlan;
    m_shCurrentReelStrip = static_cast<uint16_t>(std::stoi(AT(m_vecReelStripPlan, m_nCurrentReelPlan)));
}

UINT8 RgMagicMirrorDeluxe2::CardCount(std::string card) {
    int n = 0;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int col = 0; col < m_nReel; col++) {
        int k = 0;
        for (; k < 3; k++) {
            std::string s = AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k);
            if (s == card) {
                n++;
            }
        }
    }
    return n;
}

BOOL RgMagicMirrorDeluxe2::DragonInCol(int col) {
    return CardNumInCol(col, RgMagicMirrorDeluxe2_mirror);
}

UINT8 RgMagicMirrorDeluxe2::CardNumInCol(int col, std::string card) {
    int n = 0;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int k = 0; k < 3; k++) {
        std::string s = AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k);
        if (s == card) {
            n++;
        }
    }
    return n;
}

UINT8 RgMagicMirrorDeluxe2::CardNumInCol(int col, std::string card, myVector<UINT8> result) {
    int n = 0;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int k = 0; k < 3; k++) {
        std::string s = AT(AT(reelSet, col), AT(result, col) - 1 + k);
        if (s == card) {
            n++;
        }
    }
    return n;
}

myVector<int> pickRandom2or3(int pool[], int poolSize, int count) {// 2 or 3 
    myVector<int> result;
    for (int i = 0; i < count; i++)
    {
        int idx = myRandom() % poolSize;   // 0 .. poolSize-1
        result.push_back(pool[idx]);

        // swap-remove to avoid duplicates
        pool[idx] = pool[poolSize - 1];
        --poolSize;
    }

    return result;
}

myVector<UINT8> RgMagicMirrorDeluxe2::Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) {
    m_nMagicCount = 0;
    m_bPrevSpinMatchedActive = FALSE;

    myVector<UINT8> result;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);

    if (bTest) {
        std::string matchSymbol = AT(m_vecSymbols, myRandom() % (m_vecSymbols.size() - 1));
        int line = (myRandom() % m_nWinLine);
        int weight = 1 + (myRandom() % 5);

        BOOL bForceFree = (myRandom() % 10 == 0);
        for (int i = 0; i < m_nReel; i++) {
            ReelStrip reelStrip = AT(reelSet, i);
            int len = reelStrip.size() - 3;

            int valid_i[0x100];
            int valid_count = 0;

            myVector<int> freeSymbols;
            for (int j = 0; j <= len; j++) {
                if (weight > i) {
                    if (matchSymbol == AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                else {
                    if (matchSymbol != AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                if (AT(reelStrip, j) == RgMagicMirrorDeluxe2_mirror && m_bFreeMode == FALSE) {
                    freeSymbols.push_back(j);
                }
            }
            if (valid_count > 0) {
                int rand_index = myRandom() % valid_count;
                int chosen_i = valid_i[rand_index];
                result.push_back(chosen_i + 1);
            }
            else {
                result.push_back((myRandom() % (len - 1)) + 1);
            }
            {
                int pool[5] = { 0, 2, 4 };
                auto v = pickRandom2or3(pool, 3, 3);
                if (bForceFree && m_bFreeMode == FALSE && freeSymbols.size() > 0 && std::find(v.begin(), v.end(), i) != v.end()) {
                    AT(result, result.size() - 1) =
                        AT(freeSymbols, myRandom() % freeSymbols.size()) - (myRandom() % 2) + 1;
                }
            }
        }
        
    }
    else {
        result = _result;
        m_vWinResult = result;

        BOOL mmcode = mmcode_get_active_status();
        if (mmcode) {
            mmcode_set_deactive();
            if (m_bFreeMode == FALSE) {
                for (int j = 0; j < 5; j ++) {
                    myVector<int> candidateIndices;
                    for (int i = 2; i < AT(reelSet, j).size() - 3; ++i) {
                        if (j%2 == 0 && AT(AT(reelSet, j), i) == RgMagicMirrorDeluxe2_mirror) {
                            int offset = myRandom() % 3;
                            int selectedIndex = i - 2 + offset;
                            candidateIndices.push_back(selectedIndex);
                        }
                        if (j%2 == 1 && AT(AT(reelSet, j), i) != RgMagicMirrorDeluxe2_mirror
                                    && AT(AT(reelSet, j), i-2) != RgMagicMirrorDeluxe2_mirror
                                    && AT(AT(reelSet, j), i-1) != RgMagicMirrorDeluxe2_mirror
                                    && AT(AT(reelSet, j), i+1) != RgMagicMirrorDeluxe2_mirror
                                    && AT(AT(reelSet, j), i+2) != RgMagicMirrorDeluxe2_mirror) {
                            int offset = myRandom() % 3;
                            int selectedIndex = i - 2 + offset;
                            candidateIndices.push_back(selectedIndex);
                        }
                    }
                    if (!candidateIndices.empty()) {
#ifdef BIGBET_ACTIVE
                        int chosenIndex = AT(candidateIndices, 0);
#else
                        int chosenIndex = AT(candidateIndices, myRandom() % candidateIndices.size());
#endif
                        AT(result, j) = chosenIndex + 1;
                    }
                }
            }
        }
        if (m_bFreeMode && ((myRandom() % 3) == 0)) {
            int pool[5] = { 0, 1, 2, 3, 4 };
            int existCnt = 0;
            // get exists
            // check wild symbol
            for (int col = 0; col < 5; col++) {
                if (CardNumInCol(col, m_strSelectedcard) > 0) {
                    existCnt++;
                }
            }
            if (existCnt < m_mapSymbolMinMatch[m_strSelectedcard]) {
                int poolSize = 0;
                for (int col = 0; col < 5; col++) {
                    if (CardNumInCol(col, m_strSelectedcard) == 0) {
                        pool[poolSize] = col;
                        poolSize++;
                    }
                }
                myVector<int> selectedReels = pickRandom2or3(pool, poolSize, m_mapSymbolMinMatch[m_strSelectedcard] - existCnt);
                for (int j = 0; j < selectedReels.size(); j++) {
                    int reel = AT(selectedReels, j);
                    ReelStrip reelStrip = AT(reelSet, reel);
                    for (int i = 3; i < reelStrip.size() - 2; i++) {
                        if (AT(reelStrip, i) == m_strSelectedcard) {
                            AT(result, reel) = i - (myRandom() % 3) + 1;
                            break;
                        }
                    }
                }
            }
        }
    }

    m_vWinResult = result;

    normalMeter = 0;
    maxMeter = 0;
    BONUS totalBonus = {0, 0};
    int maxMirrorMatchCount = 0;
    int Mirror5Matched = 0;
    for (int i = 0; i < m_nWinLine; i++) {
        int j = 1;
        UINT16 meter = ((UINT16)1 << (2 - g_match_lines_10_5[i][0]));
        std::string firstSymbol = AT(AT(reelSet, 0), AT(result, 0) - 1 + g_match_lines_10_5[i][0]);
        maxMirrorMatchCount = 0;

        for (; j < m_nMaxMatch; j++) {
            std::string prev_symbol = AT(AT(reelSet, j - 1), AT(result, j - 1) - 1 + g_match_lines_10_5[i][j - 1]);
            std::string cur_symbol = AT(AT(reelSet, j), AT(result, j) - 1 + g_match_lines_10_5[i][j]);

            if (cur_symbol == RgMagicMirrorDeluxe2_mirror) {
                maxMirrorMatchCount++;
            }
            if (firstSymbol == RgMagicMirrorDeluxe2_mirror) { // scatter
                firstSymbol = cur_symbol;
            }

            if (firstSymbol == cur_symbol || cur_symbol == RgMagicMirrorDeluxe2_mirror) {
                meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
                continue;
            }
            break;
        }

        if (j < m_mapSymbolMinMatch[firstSymbol] || m_mapSymbolMinMatch[firstSymbol] == 0) {
            continue;
        }
        if (firstSymbol == RgMagicMirrorDeluxe2_mirror) {
            Mirror5Matched = 1;
        }

        // monitor 2 meter
        std::string meterStr = m_mapSymbolMeterGoc[firstSymbol];
        size_t pos = meterStr.find('$');
        if (pos != std::string::npos) {
            meterStr = meterStr.replace(pos, 1, std::to_string(j));
        }

        WinMeter e;
        e.line = i;
        e.meter = meter;
        e.meter2 = g_GrafficObjList.Str2GOCID(meterStr);
        e.symbol = firstSymbol;
        e.weight = j;
        e.start = 0;
        e.bonus = m_Bonus[BetStep()][firstSymbol][j];
        e.sound = MAX_SOUND_IDS;

        totalBonus.coin += e.bonus.coin;
        totalBonus.ag += e.bonus.ag;

        if (e.meter2 != -1) {
            meters.push_back(e);
        }
        if (j == m_nMaxMatch) {
            maxMeter |= meter;
        }
        else {
            normalMeter |= meter;
        }

        if (bTest == FALSE) {
            m_bPrevSpinMatchedActive = TRUE;
        }
    }

    int nMirror = CardCount(RgMagicMirrorDeluxe2_mirror);
    if (nMirror >= 3) {
        bCanFreeMode = TRUE;

        // not match Mirror 5, and Mirror match contains other match
        if (Mirror5Matched == 0 && maxMirrorMatchCount < nMirror) {
            UINT16 meter = 0;
            for (int i = 0; i < 3; i++) {
                for (int col = 0; col < m_nReel; col++) {
                    std::string cur_symbol = AT(AT(reelSet, col), AT(result, col) - 1 + i);
                    if (cur_symbol == RgMagicMirrorDeluxe2_mirror) {
                        meter |= ((UINT16)1 << (3 * col + (2 - i)));
                    }
                }
            }

            WinMeter e;
            e.line = 10;
            e.meter = meter;
            e.meter2 = g_GrafficObjList.Str2GOCID("MMDL2ScaMirror" + std::to_string(nMirror) + "x");
            e.symbol = RgMagicMirrorDeluxe2_mirror;
            e.weight = nMirror;
            e.start = 0;
            e.bonus = m_Bonus[BetStep()][RgMagicMirrorDeluxe2_mirror][nMirror];
            e.sound = MAX_SOUND_IDS;

            normalMeter |= meter;

            totalBonus.coin += e.bonus.coin;
            totalBonus.ag += e.bonus.ag;

            meters.push_back(e);

            if (bTest == FALSE) {
                m_bPrevSpinMatchedActive = TRUE;
            }
        }
    }
    if (m_bFreeMode) {
        int colCount = 0;
        int symbolToConvert = 0;
        for (int col = 0; col < m_nReel; col++) {
            int n = CardNumInCol(col, m_strSelectedcard);
            if (n > 0) {
                colCount++;
                symbolToConvert += (3 - n);
            }
        }
        if (colCount >= m_mapSymbolMinMatch[m_strSelectedcard] && m_mapSymbolMinMatch[m_strSelectedcard] > 0) {
            // convert
            UINT32 convertDelay = symbolToConvert * 300;
            WinMeter e;
            e.line = 0xFF;
            e.bonus = {0, 0};

            std::map<std::string, std::string> grayMap;
            grayMap["MMDL2HV3"] = "MMDL2HV3Fg";
            grayMap["MMDL2HV4"] = "MMDL2HV4Fg";
            grayMap["MMDL2_A_"] = "MMDL2_A_Fg";
            grayMap["MMDL2_K_"] = "MMDL2_K_Fg";
            grayMap["MMDL2_Q_"] = "MMDL2_Q_Fg";
            grayMap["MMDL2_J_"] = "MMDL2_J_Fg";
            grayMap["MMDL2_10"] = "MMDL2_10Fg";

            UINT16 cgoc = g_GrafficObjList.Str2GOCID(grayMap[m_strSelectedcard]);
            e.IntWinbonus.push_back({
                0,
                convertDelay,
                {
                    //0x06, 0xC5, 0x31, 0x01, 0x02, 0x31, 0x00, 0x02, 0x00, 0xC5, 0x31, 0xCE, 0xED, 0x31, 0x04
                    0x01, 0x02, 0x31, 0x00, 0x02, 0x00, 0xc5, 0x31, 0xce, 
                    static_cast<BYTE>(cgoc & 0xFF), static_cast<BYTE>((cgoc >> 8) & 0xFF), 0x04
                } });

            //
            myVector<uint8_t> pkt = {
                0x01, 0x02, 0x31, 0x00, 0x08, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x9c, 0x15, 0x00
            };
            int pktLen = 0;

            myVector<WinMeter> FreeMeters;
            UINT16 FreeNormalMeter = 0;

            // get win match after convert
            for (int i = 0; i < m_nWinLine; i++) {
                UINT16 meter = 0;// ((UINT16)1 << (2 - g_match_lines_10_5[i][0]));
                for (int j = 0; j < m_nMaxMatch; j++) {
                    if (!CardNumInCol(j, m_strSelectedcard)) {
                        continue;
                    }
                    meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
                }
                std::string meterStr = m_mapSymbolMeterGoc[m_strSelectedcard];
                size_t pos = meterStr.find('$');
                if (pos != std::string::npos) {
                    meterStr = meterStr.replace(pos, 1, std::to_string(colCount));
                }

                WinMeter ele;
                ele.line = i;
                ele.meter = meter;
                ele.meter2 = g_GrafficObjList.Str2GOCID(meterStr);
                ele.symbol = m_strSelectedcard;
                ele.weight = colCount;
                ele.start = 0;
                ele.bonus = m_Bonus[BetStep()][m_strSelectedcard][colCount];
                ele.sound = MAX_SOUND_IDS;

                totalBonus.coin += ele.bonus.coin;
                totalBonus.ag += ele.bonus.ag;
                FreeMeters.push_back(ele);

                FreeNormalMeter |= meter;

                pkt.push_back(ele.line);
                pkt.push_back(static_cast<BYTE>(ele.meter & 0xFF));
                pkt.push_back(static_cast<BYTE>((ele.meter >> 8) & 0xFF));
                pkt.push_back(static_cast<BYTE>(ele.meter2 & 0xFF));
                pkt.push_back(static_cast<BYTE>((ele.meter2 >> 8) & 0xFF));
                pkt.push_back(0x01);
                pkt.push_back(0x00);
                pktLen += 7;
            }
            AT(pkt, 4) = 1 + pktLen; //len
            AT(pkt, pkt.size() - 1) = 0x04;
            // refresh meters
            e.IntWinbonus.push_back({ 0, 0, pkt });
            meters.push_back(e);
            meters.insert(meters.end(), FreeMeters.begin(), FreeMeters.end());
        }
    }
    m_vWinMeters = meters;
    m_nMagicCount = totalBonus.ag;
    if (bTest == FALSE) {
        updateCheckPoint();

        if (totalBonus.coin > 0 || totalBonus.ag > 0) {
            if (m_bFreeMode) {
                m_nFreeModeTotalBonus.coin += totalBonus.coin;
                m_nFreeModeTotalBonus.ag += totalBonus.ag;
            }
            BonusSound = getSoundByID(m_vWinLineSounds[AT(m_vWinMeters, m_vWinMeters.size() - 1).symbol + "_" + std::to_string(AT(m_vWinMeters, m_vWinMeters.size() - 1).weight)]);
            BonusSound.soundID = MAX_SOUND_IDS;
        }
    }
    return result;
}

UINT16 RgMagicMirrorDeluxe2::LineSound(UINT Line, std::string symbol, UINT8 weight) {
    return MAX_SOUND_IDS;
}

int RgMagicMirrorDeluxe2::LineSwapDelay(int WinIdx) {
    // when converted match in freemode
    if (m_bFreeMode) {
        for (int i = 0; i <= min((m_vWinMeters.size() - 1), WinIdx); i++) {
            if (AT(m_vWinMeters, i).line == 0xFF) {
                return 300;
            }
        }
    }

    if (m_vWinMeters.size() <= WinIdx) {
        return 1000;
    }
    auto soundItem = getSoundByID(m_vWinLineSounds[AT(m_vWinMeters, WinIdx).symbol + "_" + std::to_string(AT(m_vWinMeters, WinIdx).weight)]);
    return soundItem.duration;
}

UINT16 RgMagicMirrorDeluxe2::SpinTime_MS() {
    if (CardCount(RgMagicMirrorDeluxe2_mirror) >= 3) {
        return 3500;
    }
    if (CardCount(RgMagicMirrorDeluxe2_mirror) == 2 && DragonInCol(4) == FALSE) {
        return 3500;
    }
    return 2000;
}

BOOL RgMagicMirrorDeluxe2::CanFreeMode() {    
    if (CardCount(RgMagicMirrorDeluxe2_mirror) >= 3) {
        return TRUE;
    }
    return FALSE;
}

myVector<InterruptPacketData> RgMagicMirrorDeluxe2::EnterFreeGame(std::string check) {
    m_bFreeMode = TRUE;
    m_nFreeModeTotalSpin = 10;
    m_nFreeModeGoneSpin = 0;
    m_nFreeModeTotalBonus = {0, 0};

    m_BonusCp = m_Bonus;
    m_Bonus = m_nWinLine == 5 ? m_BonusFree_05 : m_BonusFree_10;

    // show selecting dialog
    m_strSelectedcard = AT(m_vSelectableSymbols, myRandom() % m_vSelectableSymbols.size());
    UINT16 goc = g_GrafficObjList.Str2GOCID(m_strSelectedcard);

    myVector<InterruptPacketData> packets;
    // stop all sound
    packets.push_back({
        0,
        0,
        {0x01, 0x02, 0x35, 0x00, 0x00, 0x00, 0x04} });

    if (check != "") {
        myVector<int> values = ParseCheckPoint(check, "F", 5);
        if (values.size() == 5) {
            m_strSelectedcard = AT(m_vSelectableSymbols, AT(values, 0));
            m_nFreeModeTotalSpin = AT(values, 1);
            m_nFreeModeGoneSpin = AT(values, 2);
            m_nFreeModeTotalBonus.coin = AT(values, 3);
            m_nFreeModeTotalBonus.ag = AT(values, 4);

            goc = g_GrafficObjList.Str2GOCID(m_strSelectedcard);
            UINT8 gone = (m_nFreeModeGoneSpin ? m_nFreeModeGoneSpin : 1);
            packets.push_back({
               0,
               0,
               {0x01, 0x02, 0x30, 0x00, 0xc5, 0x31, gone, 0x00, m_nFreeModeTotalSpin, 0x00, 0x00, 0x00,
               static_cast<BYTE>(goc & 0xFF), static_cast<BYTE>((goc >> 8) & 0xFF),
               0xa3, 0x04} });
            return packets;
        }
    }
    else {
        updateCheckPoint();
    }
   
    // show freespin intro dialog
    packets.push_back({
        500,
        4000,
        {0x06, 0x23, 0x59, 0x01, 0x02, 0x30, 0x00, 0xc5, 0x31, 0x0a, 0x00, 0x01, 0x00, 0x0a, 0x00, 
        static_cast<BYTE>(goc & 0xFF), static_cast<BYTE>((goc >> 8) & 0xFF), 0xa6, 0x04} });

    // move symbol to next windows
    packets.push_back({
        0,
        10000,
        {0x01, 0x02, 0x30, 0x00, 0xc5, 0x31, 0x0a, 0x00, 0x01, 0x00, 0x0a, 0x00, 
        static_cast<BYTE>(goc & 0xFF), static_cast<BYTE>((goc >> 8) & 0xFF),
        0xa7, 0x04} });
    return packets;
}

myVector<InterruptPacketData> RgMagicMirrorDeluxe2::InterruptBeforeSpin() {
    myVector<InterruptPacketData> packets;
    if (!m_bFreeMode) {
        return packets;
    }
    m_nFreeModeGoneSpin++;
    updateCheckPoint();

    UINT8 gone = (m_nFreeModeGoneSpin ? m_nFreeModeGoneSpin : 1);

    // display total & remain free spin count
    packets.push_back({
        0,
        0,
        {            
            0x01, 0x02, 0x30, 0x00, 0xc5, 0x31, gone, 0x00, m_nFreeModeTotalSpin, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa5, 0x04
        }
        });
    return packets;
}


myVector<InterruptPacketData> RgMagicMirrorDeluxe2::InterruptAfterMoveBonus(BOOL& EndFree) {
    myVector<InterruptPacketData> packets;
    if (m_nFreeModeGoneSpin >= m_nFreeModeTotalSpin) { // ref EyeOfHorus
        EndFree = TRUE;
        m_bFreeMode = FALSE;

        m_Bonus = m_BonusCp;
        // show freemode result dialog and return to main game
        packets.push_back({
            100,
            2000,
            {0x06, 0xc5, 0x31, 0x01, 0x02, 0x30, 0x00, 0xc5, 0x31, 0x00, 0x00, 
            static_cast<BYTE>(m_nFreeModeTotalBonus.coin & 0xFF), 
            static_cast<BYTE>((m_nFreeModeTotalBonus.coin >> 8) & 0xFF),
            static_cast<BYTE>((m_nFreeModeTotalBonus.coin >> 16) & 0xFF),
            static_cast<BYTE>((m_nFreeModeTotalBonus.coin >> 24) & 0xFF),
            0x0a, 0x00, 0xab, 0x04} });
        updateCheckPoint();

        return packets;
    }
    EndFree = FALSE;

    //m_nFreeModeGoneSpin++;
    updateCheckPoint();

    return packets;
}

UINT16 RgMagicMirrorDeluxe2::MagicCount() {
    if (m_bFreeMode) {
        return 0;
    }
    else {
        return m_nMagicCount;
    }
}

myVector<InterruptPacketData> RgMagicMirrorDeluxe2::MousePressed(MousePosition p) {
    myVector<InterruptPacketData> packets;

    MousePosition a{
       {RgMagicMirrorDeluxe2_MP_ChangeLine_LB_x_reel, RgMagicMirrorDeluxe2_MP_ChangeLine_LB_x_pos },
       {RgMagicMirrorDeluxe2_MP_ChangeLine_LB_y_row, RgMagicMirrorDeluxe2_MP_ChangeLine_LB_y_pos }
    };
    MousePosition b{
        {RgMagicMirrorDeluxe2_MP_ChangeLine_RT_x_reel, RgMagicMirrorDeluxe2_MP_ChangeLine_RT_x_pos },
        {RgMagicMirrorDeluxe2_MP_ChangeLine_RT_y_row, RgMagicMirrorDeluxe2_MP_ChangeLine_RT_y_pos }
    };
    if (IsMouseWithin(p, a, b)) {
        m_nWinLine = (m_nWinLine == 5) ? 10 : 5;
        if (m_bPrevSpinMatchedActive) {
            // hide win lines
            packets.push_back({ 0, 0, {0x01, 0x02, 0x31, 0x00, 0x01, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x02, 0x00, 0x04} });
            m_bPrevSpinMatchedActive = FALSE;
        }
        UINT16 newBetValue = 0;
        if (m_nWinLine == 5) {
            m_Bonus = m_Bonus_05;
            m_vecBetSteps = m_vecBetSteps_05;
            newBetValue = AT(m_vecBetSteps_10, m_nBetStep) / 2;
            // lines
            packets.push_back({ 0, 0, {0x01, 0x02, 0x31, 0x00, 0x04, 0x00,
                static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x9d, 0x1f, 0x00, 0x00, 0x00, 0x04} });
        }
        else {
            m_Bonus = m_Bonus_10;
            m_vecBetSteps = m_vecBetSteps_10;
            newBetValue = AT(m_vecBetSteps_05, m_nBetStep) * 2;
            // lines
            packets.push_back({ 0, 0, {0x01, 0x02, 0x31, 0x00, 0x04, 0x00, static_cast<BYTE>(m_nGameID & 0xFF),
                static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x9d, 0xff, 0x03, 0x00, 0x00, 0x04} });
        }
        BOOL flag = FALSE;
        for (int i = 0; i < m_vecBetSteps.size(); i++) {
            if (AT(m_vecBetSteps, i) == newBetValue) {
                m_nBetStep = i;
                flag = TRUE;
                break;
            }
        }
        if (flag == FALSE) {
            m_nBetStep = 0;
        }
        // play button sound
        packets.push_back({ 0, 0, {0x01, 0x02, 0x34, 0x00, 0xf7, 0x00, 0x04} });
        // change line button
        packets.push_back({ 0, 0, {0x01, 0x02, 0x28, 0x00,
            static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), static_cast<BYTE>(m_nWinLine), 0x00, 0x00, 0x00, 0x04} });
        // set bet
        UINT16 bet = AT(m_vecBetSteps, m_nBetStep) / 5;
        packets.push_back({ 0, 0, {0x01, 0x02, 0x30, 0x00, 0x25, 0x53, 
            static_cast<BYTE>(bet & 0xFF), static_cast<BYTE>((bet >> 8) & 0xFF),
             0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04, 0x04} });
    }
    return packets;
}


myVector<UINT8> RgMagicMirrorDeluxe2::ShowTotalWinLines(myVector<WinMeter> SpinMeters) {
    myVector<uint8_t> packet = {
        0x06, 0x30, 0x59, 0x01, 0x02, 0x31, 0x00,
        0x0F, 0x00,  // Placeholder for length 
        0x0F, 0x11, // GameID
        0x9C, 0x19, 0x01
    };
    myVector<UINT8> TotalMatch;
    for (int i = 0; i < SpinMeters.size(); i++) {
        if (AT(SpinMeters, i).line == 0xFF) { // clear after convert action
            TotalMatch.clear();
            continue;
        }
        TotalMatch.push_back(AT(SpinMeters, i).line);
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter >> 8) & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter2 & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter2 >> 8) & 0xFF));
    }
    if (TotalMatch.size() < 10) {
        myVector<UINT8> _;
        return _;
    }
    UINT16 pktLen = 1 + (TotalMatch.size() / 5) * 7;
    AT(packet, 7) = static_cast<BYTE>(pktLen & 0xFF);
    AT(packet, 8) = static_cast<BYTE>((pktLen >> 8) & 0xFF);
    AT(packet, 9) = static_cast<BYTE>(m_nGameID & 0xFF);
    AT(packet, 10) = static_cast<BYTE>((m_nGameID >> 8) & 0xFF);
    int entryCount = static_cast<int>(TotalMatch.size() / 5);
    for (int i = 0; i < entryCount; ++i) {
        packet.push_back(AT(TotalMatch, i * 5 + 0)); // Line
        packet.push_back(AT(TotalMatch, i * 5 + 1)); // Meter low byte
        packet.push_back(AT(TotalMatch, i * 5 + 2)); // Meter high byte
        packet.push_back(AT(TotalMatch, i * 5 + 3)); // Meter2 low byte
        packet.push_back(AT(TotalMatch, i * 5 + 4)); // Meter2 high byte
        packet.push_back(0x01);      // Status or flag 1
        packet.push_back(0x01);      // Status or flag 2
    }
    // Mark the end of the packet
    packet.back() = 0x04;
    return packet;
}

BOOL RgMagicMirrorDeluxe2::SelectedableReelsInFreeGame(myVector<UINT8> result) {
    if (m_bFreeMode == FALSE) {
        return TRUE;
    }
    myVector<UINT8> cp = m_vWinResult;
    m_vWinResult = result;
    int n = CardCount(RgMagicMirrorDeluxe2_mirror);
    m_vWinResult = cp;
    if (n >= 3) {
        return FALSE;
    }
    return TRUE;
}

bool RgMagicMirrorDeluxe2::RTP_force_bigWin() {
    return (myRandom() % 80 == 0); // 1.25%
}

void RgMagicMirrorDeluxe2::updateCheckPoint() {
    std::ostringstream oss;
    oss << " P" << m_nCurrentReelPlan
        << " B"
        << static_cast<int>(AT(m_vWinResult, 0)) << ":"
        << static_cast<int>(AT(m_vWinResult, 1)) << ":"
        << static_cast<int>(AT(m_vWinResult, 2)) << ":"
        << static_cast<int>(AT(m_vWinResult, 3)) << ":"
        << static_cast<int>(AT(m_vWinResult, 4)) << " ";

    if (m_bFreeMode) {
        int idx = 0;
        auto it = std::find(m_vSelectableSymbols.begin(), m_vSelectableSymbols.end(), m_strSelectedcard);
        if (it != m_vSelectableSymbols.end()) {
            idx = std::distance(m_vSelectableSymbols.begin(), it);
        }
        oss << " F"
            << static_cast<int>(idx) << ":"
            << static_cast<int>(m_nFreeModeTotalSpin) << ":"
            << static_cast<int>(m_nFreeModeGoneSpin) << ":"
            << static_cast<int>(m_nFreeModeTotalBonus.coin) << ":"
            << static_cast<int>(m_nFreeModeTotalBonus.ag) << " ";
    }
    m_strCheckPoint = oss.str();
}