#pragma once

#include "ReelGame.h"

class RgMerkurMagnus : public ReelGame
{
public:
	RgMerkurMagnus::RgMerkurMagnus();

	myVector<UINT8> Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) override;
};
