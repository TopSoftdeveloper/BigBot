#include "stdafx.h"
#include "RgGoldCup.h"

#define RgGoldCup_wild "gocuWILD_____"
#define RgGoldCup_top "gocuFussbaler"
RgGoldCup::RgGoldCup() {
    m_nReel = 5;
    m_nWinLine = 5;
    m_nMaxMatch = 5;
    m_nBetStep = 0;

    m_strGameName = "RgGoldCup";

    myVector<UINT16> m_vecBetSteps_tmp;
    m_vecBetSteps_tmp.push_back(5);
    m_vecBetSteps_tmp.push_back(10);
    m_vecBetSteps_tmp.push_back(20);
    m_vecBetSteps_tmp.push_back(30);
    m_vecBetSteps_tmp.push_back(40);
    m_vecBetSteps_tmp.push_back(50);
    m_vecBetSteps_tmp.push_back(60);
    m_vecBetSteps_tmp.push_back(80);
    m_vecBetSteps_tmp.push_back(100);
    m_vecBetSteps_tmp.push_back(150);
    m_vecBetSteps_tmp.push_back(200);
#ifdef BIGBET_ACTIVE
    m_vecBetSteps_tmp.push_back(500);
    m_vecBetSteps_tmp.push_back(1000);
#endif
    LoadBets();

    m_vecSymbols.push_back("gocuFussbaler");
    m_vecSymbols.push_back("gocuBall_____");
    m_vecSymbols.push_back("gocuTor______");
    m_vecSymbols.push_back("gocuTrikot_11");
    m_vecSymbols.push_back("gocuTrikot_10");
    m_vecSymbols.push_back("gocuTrikot_09");
    m_vecSymbols.push_back("gocuTrikot_08");

    m_vecSymbols.push_back("gocuWILD_____");

    m_mapSymbolMinMatch["gocuFussbaler"] = 3;
    m_mapSymbolMinMatch["gocuBall_____"] = 3;
    m_mapSymbolMinMatch["gocuTor______"] = 3;
    m_mapSymbolMinMatch["gocuTrikot_11"] = 3;
    m_mapSymbolMinMatch["gocuTrikot_10"] = 3;
    m_mapSymbolMinMatch["gocuTrikot_09"] = 3;
    m_mapSymbolMinMatch["gocuTrikot_08"] = 3;

    m_mapSymbolMeterGoc["gocuFussbaler"] = "gocuFuss$x";
    m_mapSymbolMeterGoc["gocuBall_____"] = "gocuBalTor$x";
    m_mapSymbolMeterGoc["gocuTor______"] = "gocuBalTor$x";
    m_mapSymbolMeterGoc["gocuTrikot_11"] = "gocuTri_11_10_$x";
    m_mapSymbolMeterGoc["gocuTrikot_10"] = "gocuTri_11_10_$x";
    m_mapSymbolMeterGoc["gocuTrikot_09"] = "gocuTri_09_08_$x";
    m_mapSymbolMeterGoc["gocuTrikot_08"] = "gocuTri_09_08_$x";

    m_vecWinLines.push_back("gocuWinline1");
    m_vecWinLines.push_back("gocuWinline2");
    m_vecWinLines.push_back("gocuWinline3");
    m_vecWinLines.push_back("gocuWinline4");
    m_vecWinLines.push_back("gocuWinline5");

    
    m_vecLineSounds.push_back(SMP_GOCU_5Winlines_L1);
    m_vecLineSounds.push_back(SMP_GOCU_5Winlines_L2);
    m_vecLineSounds.push_back(SMP_GOCU_5Winlines_L3);
    m_vecLineSounds.push_back(SMP_GOCU_5Winlines_L4);
    m_vecLineSounds.push_back(SMP_GOCU_5Winlines_L5);

    m_vecWinSounds.push_back(SMP_GOCU_GoldCupSM_VeryTiny);
    m_vecWinSounds.push_back(SMP_GOCU_GoldCupSM_Tiny);
    m_vecWinSounds.push_back(SMP_GOCU_GoldCupSM_Mid);
    m_vecWinSounds.push_back(SMP_GOCU_GoldCupBig);
    m_vecWinSounds.push_back(SMP_GOCU_GoldCupSM_Huge);
    m_vecWinSounds.push_back(SMP_GOCU_GoldCupHuge);
    m_vecWinSounds.push_back(SMP_GOCU_GoldCupTop);
           
    m_vecReelStripPlan.push_back("Walze1GOCU");
    
    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));

    /*
    "gocuTrikot_09,gocuVAR______,gocuVAR______,gocuVAR______,gocuVAR______,gocuTrikot_09,gocuTrikot_09,gocuTrikot_09,gocuTrikot_08,gocuTrikot_08,gocuTor______,gocuBall_____,gocuTrikot_11,gocuTrikot_11,gocuTrikot_11,gocuTrikot_09,gocuTrikot_09,gocuTrikot_10,gocuTrikot_10,gocuTrikot_10,gocuTrikot_09,gocuTrikot_09,gocuTrikot_09,gocuTrikot_09,gocuTrikot_10,gocuTrikot_10,gocuTrikot_10,gocuTor______,gocuTrikot_10,gocuTrikot_10,gocuTrikot_09,gocuTrikot_09,gocuTrikot_09,gocuTrikot_09,gocuTrikot_08,gocuTrikot_08,gocuTrikot_08,gocuFussbaler,gocuTrikot_10,gocuTrikot_10,gocuTrikot_10,gocuTrikot_11,gocuBall_____,gocuBall_____,gocuTrikot_10,gocuTrikot_10,gocuTrikot_10,gocuTrikot_09,gocuTrikot_09,gocuTrikot_09,gocuTrikot_11,gocuTrikot_11,gocuTrikot_11,gocuTrikot_10,gocuTrikot_10,gocuTrikot_09,gocuTrikot_09,gocuTrikot_09",
    "gocuTrikot_08,gocuVAR______,gocuVAR______,gocuVAR______,gocuVAR______,gocuVAR______,gocuTrikot_10,gocuFussbaler,gocuTrikot_08,gocuTrikot_08,gocuTrikot_08,gocuBall_____,gocuBall_____,gocuBall_____,gocuTrikot_11,gocuTrikot_11,gocuTrikot_11,gocuTrikot_11,gocuTrikot_08,gocuTrikot_08,gocuTrikot_08,gocuTrikot_08,gocuTor______,gocuTor______,gocuTor______,gocuBall_____,gocuBall_____,gocuTrikot_11,gocuTrikot_09,gocuTrikot_09,gocuWILD_____,gocuTrikot_09,gocuTrikot_09,gocuTrikot_10,gocuTrikot_10,gocuTrikot_10,gocuFussbaler,gocuFussbaler,gocuTrikot_11,gocuTrikot_11,gocuTrikot_11,gocuTrikot_08,gocuTrikot_08,gocuTrikot_08,gocuTrikot_08,gocuBall_____,gocuBall_____,gocuTrikot_11,gocuTrikot_11,gocuTrikot_10,gocuTrikot_10,gocuTor______,gocuTor______,gocuTor______,gocuTrikot_08,gocuTrikot_08,gocuTrikot_08,gocuTrikot_11,gocuTrikot_11,gocuTrikot_09,gocuTrikot_09,gocuTrikot_08,gocuTrikot_08,gocuTrikot_08,gocuFussbaler,gocuFussbaler,gocuBall_____,gocuBall_____,gocuTrikot_08,gocuTrikot_08,gocuTrikot_08",
    "gocuTrikot_09,gocuVAR______,gocuVAR______,gocuVAR______,gocuVAR______,gocuVAR______,gocuTrikot_11,gocuTrikot_11,gocuBall_____,gocuTrikot_08,gocuTrikot_08,gocuTrikot_09,gocuTrikot_09,gocuTrikot_09,gocuTor______,gocuTor______,gocuTor______,gocuFussbaler,gocuFussbaler,gocuTrikot_10,gocuTrikot_10,gocuTrikot_10,gocuTor______,gocuTrikot_09,gocuTrikot_09,gocuTrikot_09,gocuBall_____,gocuBall_____,gocuTrikot_08,gocuTor______,gocuTor______,gocuWILD_____,gocuTor______,gocuTor______,gocuBall_____,gocuBall_____,gocuBall_____,gocuTor______,gocuTor______,gocuTor______,gocuTrikot_08,gocuTrikot_08,gocuTrikot_08,gocuTrikot_10,gocuTrikot_08,gocuFussbaler,gocuTrikot_11,gocuTrikot_11,gocuTrikot_11,gocuTrikot_09,gocuTrikot_09,gocuTrikot_09,gocuTrikot_11,gocuTrikot_09,gocuTrikot_09,gocuTrikot_08,gocuTor______,gocuTor______,gocuTrikot_10,gocuTrikot_10,gocuTrikot_10,gocuTrikot_09,gocuTrikot_09,gocuFussbaler,gocuTor______",
    "gocuTrikot_09,gocuVAR______,gocuVAR______,gocuVAR______,gocuVAR______,gocuVAR______,gocuVAR______,gocuTrikot_09,gocuTrikot_09,gocuTrikot_09,gocuTrikot_11,gocuTrikot_11,gocuTrikot_11,gocuTrikot_08,gocuTrikot_08,gocuTrikot_08,gocuTrikot_08,gocuFussbaler,gocuFussbaler,gocuTor______,gocuTrikot_11,gocuTrikot_11,gocuTrikot_11,gocuTrikot_09,gocuTrikot_09,gocuTrikot_08,gocuTrikot_11,gocuTrikot_11,gocuWILD_____,gocuTrikot_10,gocuTrikot_10,gocuTrikot_08,gocuTrikot_08,gocuBall_____,gocuBall_____,gocuBall_____,gocuTrikot_11,gocuTrikot_11,gocuTrikot_09,gocuTrikot_09,gocuTrikot_09,gocuTrikot_10,gocuTrikot_10,gocuTrikot_10,gocuTrikot_08,gocuTrikot_08,gocuTrikot_11,gocuBall_____,gocuTrikot_08,gocuTrikot_08,gocuTrikot_08,gocuTrikot_11,gocuTrikot_10,gocuTrikot_10,gocuTrikot_10,gocuTor______,gocuTrikot_10,gocuTrikot_09,gocuTrikot_09,gocuTrikot_09,gocuTrikot_08,gocuTrikot_08,gocuTrikot_08,gocuTrikot_11,gocuTor______,gocuTrikot_09,gocuTrikot_08,gocuTrikot_08",
    "gocuFussbaler,gocuVAR______,gocuVAR______,gocuVAR______,gocuVAR______,gocuVAR______,gocuVAR______,gocuVAR______,gocuVAR______,gocuTrikot_11,gocuTrikot_11,gocuTrikot_11,gocuTor______,gocuTor______,gocuTrikot_10,gocuTrikot_10,gocuTrikot_10,gocuBall_____,gocuTrikot_08,gocuTrikot_10,gocuTrikot_10,gocuTrikot_10,gocuTrikot_09,gocuTrikot_09,gocuTrikot_11,gocuFussbaler,gocuFussbaler,gocuTrikot_11,gocuTrikot_11,gocuBall_____,gocuBall_____,gocuTrikot_10,gocuTor______,gocuTor______,gocuTrikot_11,gocuTrikot_11,gocuTrikot_11,gocuTrikot_11,gocuTrikot_10,gocuTor______,gocuTor______,gocuTor______,gocuTrikot_10,gocuTrikot_09,gocuTrikot_09,gocuTrikot_09,gocuBall_____,gocuBall_____,gocuTrikot_10,gocuTrikot_08,gocuTrikot_08,gocuTrikot_08,gocuTrikot_11,gocuTrikot_11,gocuTor______,gocuTor______,gocuTrikot_10,gocuTrikot_10,gocuTrikot_09,gocuTrikot_11,gocuTrikot_11,gocuTrikot_11,gocuFussbaler,gocuTor______"
    */
    char* gocuReelStrip[] = {
         "gocuTrikot_09,gocuFussbaler,gocuFussbaler,gocuFussbaler,gocuFussbaler,gocuTrikot_09,gocuTrikot_09,gocuTrikot_09,gocuTrikot_08,gocuTrikot_08,gocuTor______,gocuBall_____,gocuTrikot_11,gocuTrikot_11,gocuTrikot_11,gocuTrikot_09,gocuTrikot_09,gocuTrikot_10,gocuTrikot_10,gocuTrikot_10,gocuTrikot_09,gocuTrikot_09,gocuTrikot_09,gocuTrikot_09,gocuTrikot_10,gocuTrikot_10,gocuTrikot_10,gocuTor______,gocuTrikot_10,gocuTrikot_10,gocuTrikot_09,gocuTrikot_09,gocuTrikot_09,gocuTrikot_09,gocuTrikot_08,gocuTrikot_08,gocuTrikot_08,gocuFussbaler,gocuTrikot_10,gocuTrikot_10,gocuTrikot_10,gocuTrikot_11,gocuBall_____,gocuBall_____,gocuTrikot_10,gocuTrikot_10,gocuTrikot_10,gocuTrikot_09,gocuTrikot_09,gocuTrikot_09,gocuTrikot_11,gocuTrikot_11,gocuTrikot_11,gocuTrikot_10,gocuTrikot_10,gocuTrikot_09,gocuTrikot_09,gocuTrikot_09",
         "gocuTrikot_08,gocuFussbaler,gocuFussbaler,gocuFussbaler,gocuFussbaler,gocuFussbaler,gocuTrikot_10,gocuFussbaler,gocuTrikot_08,gocuTrikot_08,gocuTrikot_08,gocuBall_____,gocuBall_____,gocuBall_____,gocuTrikot_11,gocuTrikot_11,gocuTrikot_11,gocuTrikot_11,gocuTrikot_08,gocuTrikot_08,gocuTrikot_08,gocuTrikot_08,gocuTor______,gocuTor______,gocuTor______,gocuBall_____,gocuBall_____,gocuTrikot_11,gocuTrikot_09,gocuTrikot_09,gocuWILD_____,gocuTrikot_09,gocuTrikot_09,gocuTrikot_10,gocuTrikot_10,gocuTrikot_10,gocuFussbaler,gocuFussbaler,gocuTrikot_11,gocuTrikot_11,gocuTrikot_11,gocuTrikot_08,gocuTrikot_08,gocuTrikot_08,gocuTrikot_08,gocuBall_____,gocuBall_____,gocuTrikot_11,gocuTrikot_11,gocuTrikot_10,gocuTrikot_10,gocuTor______,gocuTor______,gocuTor______,gocuTrikot_08,gocuTrikot_08,gocuTrikot_08,gocuTrikot_11,gocuTrikot_11,gocuTrikot_09,gocuTrikot_09,gocuTrikot_08,gocuTrikot_08,gocuTrikot_08,gocuFussbaler,gocuFussbaler,gocuBall_____,gocuBall_____,gocuTrikot_08,gocuTrikot_08,gocuTrikot_08",
         "gocuTrikot_09,gocuFussbaler,gocuFussbaler,gocuFussbaler,gocuFussbaler,gocuFussbaler,gocuTrikot_11,gocuTrikot_11,gocuBall_____,gocuTrikot_08,gocuTrikot_08,gocuTrikot_09,gocuTrikot_09,gocuTrikot_09,gocuTor______,gocuTor______,gocuTor______,gocuFussbaler,gocuFussbaler,gocuTrikot_10,gocuTrikot_10,gocuTrikot_10,gocuTor______,gocuTrikot_09,gocuTrikot_09,gocuTrikot_09,gocuBall_____,gocuBall_____,gocuTrikot_08,gocuTor______,gocuTor______,gocuWILD_____,gocuTor______,gocuTor______,gocuBall_____,gocuBall_____,gocuBall_____,gocuTor______,gocuTor______,gocuTor______,gocuTrikot_08,gocuTrikot_08,gocuTrikot_08,gocuTrikot_10,gocuTrikot_08,gocuFussbaler,gocuTrikot_11,gocuTrikot_11,gocuTrikot_11,gocuTrikot_09,gocuTrikot_09,gocuTrikot_09,gocuTrikot_11,gocuTrikot_09,gocuTrikot_09,gocuTrikot_08,gocuTor______,gocuTor______,gocuTrikot_10,gocuTrikot_10,gocuTrikot_10,gocuTrikot_09,gocuTrikot_09,gocuFussbaler,gocuTor______",
         "gocuTrikot_09,gocuFussbaler,gocuFussbaler,gocuFussbaler,gocuFussbaler,gocuFussbaler,gocuFussbaler,gocuTrikot_09,gocuTrikot_09,gocuTrikot_09,gocuTrikot_11,gocuTrikot_11,gocuTrikot_11,gocuTrikot_08,gocuTrikot_08,gocuTrikot_08,gocuTrikot_08,gocuFussbaler,gocuFussbaler,gocuTor______,gocuTrikot_11,gocuTrikot_11,gocuTrikot_11,gocuTrikot_09,gocuTrikot_09,gocuTrikot_08,gocuTrikot_11,gocuTrikot_11,gocuWILD_____,gocuTrikot_10,gocuTrikot_10,gocuTrikot_08,gocuTrikot_08,gocuBall_____,gocuBall_____,gocuBall_____,gocuTrikot_11,gocuTrikot_11,gocuTrikot_09,gocuTrikot_09,gocuTrikot_09,gocuTrikot_10,gocuTrikot_10,gocuTrikot_10,gocuTrikot_08,gocuTrikot_08,gocuTrikot_11,gocuBall_____,gocuTrikot_08,gocuTrikot_08,gocuTrikot_08,gocuTrikot_11,gocuTrikot_10,gocuTrikot_10,gocuTrikot_10,gocuTor______,gocuTrikot_10,gocuTrikot_09,gocuTrikot_09,gocuTrikot_09,gocuTrikot_08,gocuTrikot_08,gocuTrikot_08,gocuTrikot_11,gocuTor______,gocuTrikot_09,gocuTrikot_08,gocuTrikot_08",
         "gocuFussbaler,gocuFussbaler,gocuFussbaler,gocuFussbaler,gocuFussbaler,gocuFussbaler,gocuFussbaler,gocuFussbaler,gocuFussbaler,gocuTrikot_11,gocuTrikot_11,gocuTrikot_11,gocuTor______,gocuTor______,gocuTrikot_10,gocuTrikot_10,gocuTrikot_10,gocuBall_____,gocuTrikot_08,gocuTrikot_10,gocuTrikot_10,gocuTrikot_10,gocuTrikot_09,gocuTrikot_09,gocuTrikot_11,gocuFussbaler,gocuFussbaler,gocuTrikot_11,gocuTrikot_11,gocuBall_____,gocuBall_____,gocuTrikot_10,gocuTor______,gocuTor______,gocuTrikot_11,gocuTrikot_11,gocuTrikot_11,gocuTrikot_11,gocuTrikot_10,gocuTor______,gocuTor______,gocuTor______,gocuTrikot_10,gocuTrikot_09,gocuTrikot_09,gocuTrikot_09,gocuBall_____,gocuBall_____,gocuTrikot_10,gocuTrikot_08,gocuTrikot_08,gocuTrikot_08,gocuTrikot_11,gocuTrikot_11,gocuTor______,gocuTor______,gocuTrikot_10,gocuTrikot_10,gocuTrikot_09,gocuTrikot_11,gocuTrikot_11,gocuTrikot_11,gocuFussbaler,gocuTor______",
    };

    int idx = 0;
    for (int i = 0; i < m_vecReelStripPlan.size(); i++) {
        ReelSet set;
        for (int j = 0; j < m_nReel; j++) {
            ReelStrip strip;
            std::stringstream ss(gocuReelStrip[idx]);
            std::string item;
            while (std::getline(ss, item, ',')) {
                strip.push_back(item);
            }
            set.push_back(strip);
            idx++;
        }
        m_vecReelStripSets.push_back(set);
    }

    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_tmp;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        std::map<std::string, std::map<UINT8, BONUS>> perSym;
        std::map<UINT8, BONUS> e;
        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 500; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5000; e[5].ag = 0;
        perSym["gocuFussbaler"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 150; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 500; e[5].ag = 0;
        perSym["gocuBall_____"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 150; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 500; e[5].ag = 0;
        perSym["gocuTor______"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 40; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 150; e[5].ag = 0;
        perSym["gocuTrikot_11"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 40; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 150; e[5].ag = 0;
        perSym["gocuTrikot_10"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 25; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[5].ag = 0;
        perSym["gocuTrikot_09"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 25; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[5].ag = 0;
        perSym["gocuTrikot_08"] = e;
        e.clear();

        m_Bonus_tmp[i] = perSym;
    }

    m_Bonus_tmp[m_vecBetSteps_tmp.size() - 1 - BIGBET_BETSTEP_EXTRA_COUNT]["gocuFussbaler"][5].coin = 80000;
    m_Bonus_tmp[m_vecBetSteps_tmp.size() - 1 - BIGBET_BETSTEP_EXTRA_COUNT]["gocuFussbaler"][4].coin = 42500;
    m_Bonus_tmp[m_vecBetSteps_tmp.size() - 2 - BIGBET_BETSTEP_EXTRA_COUNT]["gocuFussbaler"][5].coin = 80000;
    m_Bonus_tmp[m_vecBetSteps_tmp.size() - 2 - BIGBET_BETSTEP_EXTRA_COUNT]["gocuFussbaler"][4].coin = 28000;
    m_Bonus_tmp[m_vecBetSteps_tmp.size() - 3 - BIGBET_BETSTEP_EXTRA_COUNT]["gocuFussbaler"][5].coin = 80000;
    m_Bonus_tmp[m_vecBetSteps_tmp.size() - 3 - BIGBET_BETSTEP_EXTRA_COUNT]["gocuFussbaler"][4].coin = 14000;

    int nSavedBetVal = 10;
    int _line = 0;
    string data;
    PlayDB::GetInstance().LoadCheckPoint(m_strGameName, nSavedBetVal, _line, m_strCheckPoint);
    if (nSavedBetVal == -1) {
        nSavedBetVal = 10;
    }

    BOOL start = FALSE;
    idx = 0;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_tmp, i) < AT(m_vecBetSteps, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps, idx) == nSavedBetVal) {
            m_nBetStep = idx;
        }

        m_Bonus[idx++] = m_Bonus_tmp[i];
        if (AT(m_vecBetSteps_tmp, i) == AT(m_vecBetSteps, m_vecBetSteps.size() - 1)) {
            break;
        }
    }

    m_vecBetSteps_05.clear();
    m_vecBetSteps_10.clear();
    PrintAllBonus();
}

myVector<UINT8> RgGoldCup::Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) {
    myVector<UINT8> result;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);

    BOOL mmcode = FALSE;
    if (bTest == FALSE) {
        mmcode = mmcode_get_active_status();
    }
    if (bTest == TRUE || mmcode == TRUE) {
        // avoid wild card
        std::string matchSymbol = AT(m_vecSymbols, myRandom() % (m_vecSymbols.size() - 1));
        int line = (myRandom() % m_nWinLine);
        int weight = 1 + (myRandom() % 5);
        
        if (mmcode) {
            mmcode_set_deactive();
            weight = m_nMaxMatch;
            matchSymbol = RgGoldCup_top;
        }
        for (int i = 0; i < m_nReel; i++) {
            ReelStrip reelStrip = AT(reelSet, i);
            int len = reelStrip.size() - 3;

            int valid_i[0x100];
            int valid_count = 0;
            for (int j = 0; j <= len; j++) {
                if (weight > i) {
                    if (matchSymbol == AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                else {
                    if (matchSymbol != AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
            }
            if (valid_count > 0) {
                int rand_index = myRandom() % valid_count;
                int chosen_i = valid_i[rand_index];
                result.push_back(chosen_i + 1);
            }
            else {
                result.push_back((myRandom() % (len - 1)) + 1);
            }
        }

        if ((myRandom() & 1) == 0 && mmcode == FALSE) {
            int reel = 1 + (myRandom() % 3);
            ReelStrip reelStrip = AT(reelSet, reel);
            for (int i = 3; i < reelStrip.size() - 2; i++) {
                if (AT(reelStrip, i) == RgGoldCup_wild) {
                    AT(result, reel) = i - (myRandom() % 3) + 1;
                    break;
                }
            }
        }
    }
    else {
        result = _result;
    }
    m_vWinResult = result;

    normalMeter = 0;
    maxMeter = 0;
    UINT32 totalBonus = 0;
    for (int i = 0; i < m_nWinLine; i++) {
        int j = 1;
        UINT16 meter = ((UINT16)1 << (2 - g_match_lines_10_5[i][0]));
        std::string firstSymbol = AT(AT(reelSet, 0), AT(result, 0) - 1 + g_match_lines_10_5[i][0]);
        for (; j < m_nMaxMatch; j++) {
            std::string prev_symbol = AT(AT(reelSet, j - 1), AT(result, j - 1) - 1 + g_match_lines_10_5[i][j - 1]);
            std::string cur_symbol = AT(AT(reelSet, j), AT(result, j) - 1 + g_match_lines_10_5[i][j]);

            if (WildcountInCol(j, result)) {
                meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
                continue;
            }
            if (firstSymbol == cur_symbol) {
                meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
                continue;
            }
            break;
        }

        if (j < m_mapSymbolMinMatch[firstSymbol] || m_mapSymbolMinMatch[firstSymbol] == 0) {
            continue;
        }

        // monitor 2 meter
        std::string meterStr = m_mapSymbolMeterGoc[firstSymbol];
        size_t pos = meterStr.find('$');
        if (pos != std::string::npos) {
            meterStr = meterStr.replace(pos, 1, std::to_string(j));
        }
        WinMeter e;
        e.line = i;
        e.meter = meter;
        e.meter2 = g_GrafficObjList.Str2GOCID(meterStr);
        e.symbol = firstSymbol;
        e.weight = j;
        e.start = 0;
        e.bonus = m_Bonus[BetStep()][firstSymbol][j];
        e.sound = MAX_SOUND_IDS;

        totalBonus += e.bonus.coin;

        if (e.meter2 != -1) {
            meters.push_back(e);
        }
        if (j == m_nMaxMatch) {
            maxMeter |= meter;
        }
        else {
            normalMeter |= meter;
        }
    }
    m_vWinMeters = meters;
    if (bTest == FALSE) {
        updateCheckPoint();
    }
    if (totalBonus > 0) {
        BonusSound = getSoundByID(WinSound(totalBonus));
    }
    return result;
}

BOOL RgGoldCup::WildcountInCol(UINT8 col, myVector<UINT8> result) {
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    // check wild symbol
    int k = 0;
    for (; k < 3; k++) {
        std::string s = AT(AT(reelSet, col), AT(result, col) - 1 + k);
        if (s == RgGoldCup_wild) {
            return TRUE;
        }
    }
    return FALSE;
}

UINT8 RgGoldCup::Wildcount() {
    UINT8 n = 0;
    for (int i = 0; i < m_nReel; i++) {
        if (WildcountInCol(i, m_vWinResult)) {
            n++;
        }
    }
    return n;
}

myVector<InterruptPacketData> RgGoldCup::InterruptAfterSpin() {
    myVector<InterruptPacketData> packets;
    
    // request for expand gold-cup wild-card
    // 06 03 00 00
    // 02 01 c6 22

    // resp
    if (m_vWinMeters.size() > 0 && Wildcount() > 0) { // only expand when match
        packets.push_back({
            0,
            2000,
            {0x06, 0xc6, 0x22, 0x01, 0x02, 0x31, 0x00, 0x00, 0x00, 0xc6, 0x22, 0xce, 0x04} });
    }

    return packets;
}

myVector<UINT8> RgGoldCup::ShowTotalWinLines(myVector<WinMeter> SpinMeters) {
    myVector<uint8_t> packet = {
        0x06, 0x30, 0x59, 0x01, 0x02, 0x31, 0x00,
        0x0F, 0x00,  // Placeholder for length 
        0x0F, 0x11, // GameID
        0x9C, 0x19, 0x01
    };
    myVector<UINT8> TotalMatch;
    for (int i = 0; i < SpinMeters.size(); i++) {
        TotalMatch.push_back(AT(SpinMeters, i).line);
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter >> 8) & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter2 & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter2 >> 8) & 0xFF));
    }
    if (TotalMatch.size() < 10) {
        myVector<UINT8> _;
        return _;
    }
    UINT16 pktLen = 1 + (TotalMatch.size() / 5) * 7;
    AT(packet, 7) = static_cast<BYTE>(pktLen & 0xFF);
    AT(packet, 8) = static_cast<BYTE>((pktLen >> 8) & 0xFF);
    AT(packet, 9) = static_cast<BYTE>(m_nGameID & 0xFF);
    AT(packet, 10) = static_cast<BYTE>((m_nGameID >> 8) & 0xFF);
    int entryCount = static_cast<int>(TotalMatch.size() / 5);
    for (int i = 0; i < entryCount; ++i) {
        packet.push_back(AT(TotalMatch, i * 5 + 0)); // Line
        packet.push_back(AT(TotalMatch, i * 5 + 1)); // Meter low byte
        packet.push_back(AT(TotalMatch, i * 5 + 2)); // Meter high byte
        packet.push_back(AT(TotalMatch, i * 5 + 3)); // Meter2 low byte
        packet.push_back(AT(TotalMatch, i * 5 + 4)); // Meter2 high byte
        packet.push_back(0x01);      // Status or flag 1
        packet.push_back(0x01);      // Status or flag 2
    }
    // Mark the end of the packet
    packet.back() = 0x04;
    return packet;
}

bool RgGoldCup::RTP_force_bigWin() {
    return (myRandom() % 100 == 0); // 1%
}
