#pragma once

#include "ReelGame.h"

class RgMultiWild243 : public ReelGame
{
public:
	std::map<std::string, UINT16> m_mapLineSounds;
	myVector<WinMeter> m_vWinMeters;

	RgMultiWild243::RgMultiWild243();

	myVector<UINT8> Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& WinSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) override;
	int LineSwapDelay(int WinIdx) override;
	BOOL stopAllSoundBeforeMove() override;
	UINT16 LineSound(UINT Line, std::string symbol, UINT8 weight) override;
	UINT16 MagicCount() override;

	myVector<UINT8> ShowTotalWinLines(myVector<WinMeter> SpinMeters) override;
};
