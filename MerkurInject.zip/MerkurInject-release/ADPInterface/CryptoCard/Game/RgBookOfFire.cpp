#include "stdafx.h"
#include "RgBookOfFire.h"

#define RgBookOfFire_MP_ChangeLine_LB_x_reel   0x03
#define RgBookOfFire_MP_ChangeLine_LB_x_pos    0x25
#define RgBookOfFire_MP_ChangeLine_LB_y_row    0x02
#define RgBookOfFire_MP_ChangeLine_LB_y_pos    0x16
#define RgBookOfFire_MP_ChangeLine_RT_x_reel   0x03
#define RgBookOfFire_MP_ChangeLine_RT_x_pos    0x62
#define RgBookOfFire_MP_ChangeLine_RT_y_row    0x02
#define RgBookOfFire_MP_ChangeLine_RT_y_pos    0x50

#define RgBookOfFire_book    "bofBOOK____"
RgBookOfFire::RgBookOfFire() {
    m_nReel = 5;
    m_nWinLine = 5;
    m_nMaxMatch = 5;
    m_nBetStep = 0;

    m_strGameName = "RgBookOfFire";

    m_bFreeMode = FALSE;

    myVector<UINT16> m_vecBetSteps_05_tmp;
    myVector<UINT16> m_vecBetSteps_10_tmp;

    m_vecBetSteps_05_tmp.push_back(5);
    m_vecBetSteps_05_tmp.push_back(10);
    m_vecBetSteps_05_tmp.push_back(15);
    m_vecBetSteps_05_tmp.push_back(20);
    m_vecBetSteps_05_tmp.push_back(25);
    m_vecBetSteps_05_tmp.push_back(30);
    m_vecBetSteps_05_tmp.push_back(40);
    m_vecBetSteps_05_tmp.push_back(50);
    m_vecBetSteps_05_tmp.push_back(60);
    m_vecBetSteps_05_tmp.push_back(80);
    m_vecBetSteps_05_tmp.push_back(100);

    m_vecBetSteps_10_tmp.push_back(10);
    m_vecBetSteps_10_tmp.push_back(20);
    m_vecBetSteps_10_tmp.push_back(30);
    m_vecBetSteps_10_tmp.push_back(40);
    m_vecBetSteps_10_tmp.push_back(50);
    m_vecBetSteps_10_tmp.push_back(60);
    m_vecBetSteps_10_tmp.push_back(80);
    m_vecBetSteps_10_tmp.push_back(100);
    m_vecBetSteps_10_tmp.push_back(120);
    m_vecBetSteps_10_tmp.push_back(160);
    m_vecBetSteps_10_tmp.push_back(200);

#ifdef BIGBET_ACTIVE
    m_vecBetSteps_05_tmp.push_back(200);
    m_vecBetSteps_05_tmp.push_back(500);
    m_vecBetSteps_10_tmp.push_back(400);
    m_vecBetSteps_10_tmp.push_back(1000);
#endif
    LoadBets();

    m_vecBetSteps = m_vecBetSteps_05;

    m_vecSymbols.push_back("bofTEN_____");
    m_vecSymbols.push_back("bofJ_______");
    m_vecSymbols.push_back("bofQ_______");
    m_vecSymbols.push_back("bofK_______");
    m_vecSymbols.push_back("bofA_______");
    m_vecSymbols.push_back("bofPARCH___");
    m_vecSymbols.push_back("bofVIAL____");
    m_vecSymbols.push_back("bofBIRD____");
    m_vecSymbols.push_back("bofMAN_____");
    m_vecSymbols.push_back("bofBOOK____");
    
    m_mapSymbolMinMatch["bofTEN_____"] = 3;
    m_mapSymbolMinMatch["bofJ_______"] = 3;
    m_mapSymbolMinMatch["bofQ_______"] = 3;
    m_mapSymbolMinMatch["bofK_______"] = 3;
    m_mapSymbolMinMatch["bofA_______"] = 3;
    m_mapSymbolMinMatch["bofPARCH___"] = 2;
    m_mapSymbolMinMatch["bofVIAL____"] = 2;
    m_mapSymbolMinMatch["bofBIRD____"] = 2;
    m_mapSymbolMinMatch["bofMAN_____"] = 2;
    m_mapSymbolMinMatch["bofBOOK____"] = 3;

    m_mapSymbolMeterGoc["bofTEN_____"] = "bof_JT_$x";
    m_mapSymbolMeterGoc["bofJ_______"] = "bof_JT_$x";
    m_mapSymbolMeterGoc["bofQ_______"] = "bof_Q_$x";
    m_mapSymbolMeterGoc["bofK_______"] = "bof_K_$x";
    m_mapSymbolMeterGoc["bofA_______"] = "bof_A_$x";
    m_mapSymbolMeterGoc["bofPARCH___"] = "bofVialPa$x";
    m_mapSymbolMeterGoc["bofVIAL____"] = "bofVialPa$x";
    m_mapSymbolMeterGoc["bofBIRD____"] = "bofBird$x";
    m_mapSymbolMeterGoc["bofMAN_____"] = "bofMan$x";
    m_mapSymbolMeterGoc["bofBOOK____"] = "bofBook$x";

    m_vecWinLines.push_back("bofWinline1");
    m_vecWinLines.push_back("bofWinline2");
    m_vecWinLines.push_back("bofWinline3");
    m_vecWinLines.push_back("bofWinline4");
    m_vecWinLines.push_back("bofWinline5");
    m_vecWinLines.push_back("bofWinline6");
    m_vecWinLines.push_back("bofWinline7");
    m_vecWinLines.push_back("bofWinline8");
    m_vecWinLines.push_back("bofWinline9");
    m_vecWinLines.push_back("bofWinline10");
    m_vecWinLines.push_back("bofWinlineScat");

    m_vecLineSounds.push_back(SMP_BoFWinStep1);
    m_vecLineSounds.push_back(SMP_BoFWinStep2);
    m_vecLineSounds.push_back(SMP_BoFWinStep3);
    m_vecLineSounds.push_back(SMP_BoFWinStep4);
    m_vecLineSounds.push_back(SMP_BoFWinStep5);
    m_vecLineSounds.push_back(SMP_BoFWinStep6);
    m_vecLineSounds.push_back(SMP_BoFWinStep7);
    m_vecLineSounds.push_back(SMP_BoFWinStep8);
    m_vecLineSounds.push_back(SMP_BoFWinStep9);
    m_vecLineSounds.push_back(SMP_BoFWinStep10);

    m_vecWinSounds.push_back(SMP_BoFWin1);
    m_vecWinSounds.push_back(SMP_BoFWin2);
    m_vecWinSounds.push_back(SMP_BoFWin3);
    m_vecWinSounds.push_back(SMP_BoFWin4);
    m_vecWinSounds.push_back(SMP_BoFWin5);
    m_vecWinSounds.push_back(SMP_BoFWin6);
    m_vecWinSounds.push_back(SMP_BoFWin7);
    m_vecWinSounds.push_back(SMP_BoFWin8);
    m_vecWinSounds.push_back(SMP_BoFWin9);
    m_vecWinSounds.push_back(SMP_BoFWin10);

    m_vecReelStripPlan.push_back("0");
    m_vecReelStripPlan.push_back("1");
    m_vecReelStripPlan.push_back("2");
    m_vecReelStripPlan.push_back("3");
    m_vecReelStripPlan.push_back("4");

    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));

    char* bofReelStrip[] = {
        "bofTEN_____,bofK_______,bofVIAL____,bofA_______,bofQ_______,bofBIRD____,bofA_______,bofJ_______,bofPARCH___,bofA_______,bofK_______,bofTEN_____,bofBOOK____,bofJ_______,bofK_______,bofQ_______,bofPARCH___,bofK_______,bofA_______,bofQ_______,bofVIAL____,bofA_______,bofQ_______,bofBOOK____,bofA_______,bofQ_______,bofTEN_____,bofVIAL____,bofK_______,bofQ_______,bofA_______,bofMAN_____,bofJ_______,bofK_______,bofQ_______,bofA_______,bofVIAL____,bofK_______,bofQ_______,bofA_______,bofVIAL____,bofK_______,bofJ_______,bofMAN_____,bofQ_______,bofJ_______,bofBIRD____,bofTEN_____,bofJ_______,bofK_______",
        "bofTEN_____,bofK_______,bofVIAL____,bofA_______,bofQ_______,bofBIRD____,bofA_______,bofJ_______,bofPARCH___,bofA_______,bofK_______,bofTEN_____,bofBOOK____,bofJ_______,bofK_______,bofQ_______,bofPARCH___,bofK_______,bofA_______,bofQ_______,bofVIAL____,bofA_______,bofQ_______,bofBOOK____,bofA_______,bofQ_______,bofTEN_____,bofVIAL____,bofK_______,bofQ_______,bofA_______,bofMAN_____,bofJ_______,bofK_______,bofQ_______,bofA_______,bofVIAL____,bofK_______,bofQ_______,bofA_______,bofVIAL____,bofK_______,bofJ_______,bofMAN_____,bofQ_______,bofJ_______,bofBIRD____,bofTEN_____,bofJ_______,bofK_______",
        "bofQ_______,bofTEN_____,bofBOOK____,bofJ_______,bofA_______,bofVIAL____,bofTEN_____,bofQ_______,bofVIAL____,bofJ_______,bofA_______,bofMAN_____,bofQ_______,bofK_______,bofPARCH___,bofA_______,bofJ_______,bofTEN_____,bofQ_______,bofBIRD____,bofTEN_____,bofK_______,bofPARCH___,bofQ_______,bofK_______,bofBIRD____,bofJ_______,bofA_______,bofQ_______,bofMAN_____,bofTEN_____,bofJ_______,bofPARCH___",
        "bofTEN_____,bofK_______,bofVIAL____,bofA_______,bofQ_______,bofBIRD____,bofA_______,bofJ_______,bofPARCH___,bofA_______,bofK_______,bofTEN_____,bofBOOK____,bofJ_______,bofK_______,bofQ_______,bofPARCH___,bofK_______,bofA_______,bofQ_______,bofVIAL____,bofA_______,bofQ_______,bofBOOK____,bofA_______,bofQ_______,bofTEN_____,bofVIAL____,bofK_______,bofQ_______,bofA_______,bofMAN_____,bofJ_______,bofK_______,bofQ_______,bofA_______,bofVIAL____,bofK_______,bofQ_______,bofA_______,bofVIAL____,bofK_______,bofJ_______,bofMAN_____,bofQ_______,bofJ_______,bofBIRD____,bofTEN_____,bofJ_______,bofK_______",
        "bofQ_______,bofTEN_____,bofBOOK____,bofJ_______,bofA_______,bofVIAL____,bofTEN_____,bofQ_______,bofVIAL____,bofJ_______,bofA_______,bofMAN_____,bofQ_______,bofK_______,bofPARCH___,bofA_______,bofJ_______,bofTEN_____,bofQ_______,bofBIRD____,bofTEN_____,bofK_______,bofPARCH___,bofQ_______,bofK_______,bofBIRD____,bofJ_______,bofA_______,bofQ_______,bofMAN_____,bofTEN_____,bofJ_______,bofPARCH___",

        "bofK_______,bofJ_______,bofTEN_____,bofK_______,bofJ_______,bofVIAL____,bofTEN_____,bofQ_______,bofPARCH___,bofJ_______,bofQ_______,bofPARCH___,bofJ_______,bofK_______,bofBOOK____,bofTEN_____,bofK_______,bofJ_______,bofA_______,bofTEN_____,bofQ_______,bofPARCH___,bofJ_______,bofK_______,bofQ_______,bofBIRD____,bofTEN_____,bofK_______,bofBOOK____,bofTEN_____,bofA_______,bofQ_______,bofK_______,bofJ_______,bofA_______,bofMAN_____,bofK_______,bofJ_______,bofTEN_____,bofK_______,bofBIRD____,bofJ_______,bofA_______,bofTEN_____",
        "bofK_______,bofJ_______,bofTEN_____,bofK_______,bofJ_______,bofVIAL____,bofTEN_____,bofQ_______,bofPARCH___,bofJ_______,bofQ_______,bofPARCH___,bofJ_______,bofK_______,bofBOOK____,bofTEN_____,bofK_______,bofJ_______,bofA_______,bofTEN_____,bofQ_______,bofPARCH___,bofJ_______,bofK_______,bofQ_______,bofBIRD____,bofTEN_____,bofK_______,bofBOOK____,bofTEN_____,bofA_______,bofQ_______,bofK_______,bofJ_______,bofA_______,bofMAN_____,bofK_______,bofJ_______,bofTEN_____,bofK_______,bofBIRD____,bofJ_______,bofA_______,bofTEN_____",
        "bofJ_______,bofQ_______,bofBOOK____,bofA_______,bofTEN_____,bofVIAL____,bofA_______,bofTEN_____,bofBIRD____,bofJ_______,bofPARCH___,bofK_______,bofTEN_____,bofBOOK____,bofQ_______,bofK_______,bofBIRD____,bofQ_______,bofTEN_____,bofVIAL____,bofA_______,bofJ_______,bofPARCH___,bofK_______,bofA_______,bofVIAL____,bofTEN_____,bofPARCH___,bofJ_______,bofQ_______,bofK_______,bofMAN_____,bofQ_______,bofA_______,bofVIAL____",
        "bofK_______,bofJ_______,bofTEN_____,bofK_______,bofJ_______,bofVIAL____,bofTEN_____,bofQ_______,bofPARCH___,bofJ_______,bofQ_______,bofPARCH___,bofJ_______,bofK_______,bofBOOK____,bofTEN_____,bofK_______,bofJ_______,bofA_______,bofTEN_____,bofQ_______,bofPARCH___,bofJ_______,bofK_______,bofQ_______,bofBIRD____,bofTEN_____,bofK_______,bofBOOK____,bofTEN_____,bofA_______,bofQ_______,bofK_______,bofJ_______,bofA_______,bofMAN_____,bofK_______,bofJ_______,bofTEN_____,bofK_______,bofBIRD____,bofJ_______,bofA_______,bofTEN_____",
        "bofJ_______,bofQ_______,bofBOOK____,bofA_______,bofTEN_____,bofVIAL____,bofA_______,bofTEN_____,bofBIRD____,bofJ_______,bofPARCH___,bofK_______,bofTEN_____,bofBOOK____,bofQ_______,bofK_______,bofBIRD____,bofQ_______,bofTEN_____,bofVIAL____,bofA_______,bofJ_______,bofPARCH___,bofK_______,bofA_______,bofVIAL____,bofTEN_____,bofPARCH___,bofJ_______,bofQ_______,bofK_______,bofMAN_____,bofQ_______,bofA_______,bofVIAL____",

        "bofPARCH___,bofA_______,bofTEN_____,bofVIAL____,bofA_______,bofJ_______,bofQ_______,bofMAN_____,bofA_______,bofVIAL____,bofQ_______,bofA_______,bofPARCH___,bofQ_______,bofTEN_____,bofA_______,bofK_______,bofMAN_____,bofQ_______,bofTEN_____,bofBIRD____,bofQ_______,bofK_______,bofBOOK____,bofQ_______,bofJ_______,bofBIRD____,bofA_______,bofTEN_____,bofQ_______,bofA_______,bofBOOK____,bofQ_______,bofJ_______,bofTEN_____,bofBIRD____,bofA_______,bofTEN_____,bofQ_______,bofVIAL____,bofTEN_____,bofJ_______,bofPARCH___,bofK_______,bofTEN_____,bofJ_______",
        "bofPARCH___,bofA_______,bofTEN_____,bofVIAL____,bofA_______,bofJ_______,bofQ_______,bofMAN_____,bofA_______,bofVIAL____,bofQ_______,bofA_______,bofPARCH___,bofQ_______,bofTEN_____,bofA_______,bofK_______,bofMAN_____,bofQ_______,bofTEN_____,bofBIRD____,bofQ_______,bofK_______,bofBOOK____,bofQ_______,bofJ_______,bofBIRD____,bofA_______,bofTEN_____,bofQ_______,bofA_______,bofBOOK____,bofQ_______,bofJ_______,bofTEN_____,bofBIRD____,bofA_______,bofTEN_____,bofQ_______,bofVIAL____,bofTEN_____,bofJ_______,bofPARCH___,bofK_______,bofTEN_____,bofJ_______",
        "bofJ_______,bofA_______,bofBOOK____,bofK_______,bofTEN_____,bofBIRD____,bofA_______,bofQ_______,bofBIRD____,bofTEN_____,bofK_______,bofMAN_____,bofJ_______,bofTEN_____,bofVIAL____,bofQ_______,bofJ_______,bofVIAL____,bofK_______,bofJ_______,bofBOOK____,bofTEN_____,bofQ_______,bofPARCH___,bofJ_______,bofK_______,bofA_______,bofTEN_____,bofPARCH___,bofQ_______",
        "bofPARCH___,bofA_______,bofTEN_____,bofVIAL____,bofA_______,bofJ_______,bofQ_______,bofMAN_____,bofA_______,bofVIAL____,bofQ_______,bofA_______,bofPARCH___,bofQ_______,bofTEN_____,bofA_______,bofK_______,bofMAN_____,bofQ_______,bofTEN_____,bofBIRD____,bofQ_______,bofK_______,bofBOOK____,bofQ_______,bofJ_______,bofBIRD____,bofA_______,bofTEN_____,bofQ_______,bofA_______,bofBOOK____,bofQ_______,bofJ_______,bofTEN_____,bofBIRD____,bofA_______,bofTEN_____,bofQ_______,bofVIAL____,bofTEN_____,bofJ_______,bofPARCH___,bofK_______,bofTEN_____,bofJ_______",
        "bofJ_______,bofA_______,bofBOOK____,bofK_______,bofTEN_____,bofBIRD____,bofA_______,bofQ_______,bofBIRD____,bofTEN_____,bofK_______,bofMAN_____,bofJ_______,bofTEN_____,bofVIAL____,bofQ_______,bofJ_______,bofVIAL____,bofK_______,bofJ_______,bofBOOK____,bofTEN_____,bofQ_______,bofPARCH___,bofJ_______,bofK_______,bofA_______,bofTEN_____,bofPARCH___,bofQ_______",

        "bofTEN_____,bofA_______,bofPARCH___,bofQ_______,bofTEN_____,bofBIRD____,bofK_______,bofA_______,bofQ_______,bofVIAL____,bofTEN_____,bofQ_______,bofPARCH___,bofJ_______,bofK_______,bofTEN_____,bofBIRD____,bofK_______,bofA_______,bofMAN_____,bofJ_______,bofQ_______,bofBOOK____,bofA_______,bofK_______,bofPARCH___,bofQ_______,bofVIAL____,bofA_______,bofQ_______,bofK_______,bofTEN_____,bofBOOK____,bofJ_______,bofVIAL____,bofA_______,bofK_______,bofMAN_____,bofTEN_____,bofVIAL____,bofJ_______",
        "bofTEN_____,bofA_______,bofPARCH___,bofQ_______,bofTEN_____,bofBIRD____,bofK_______,bofA_______,bofQ_______,bofVIAL____,bofTEN_____,bofQ_______,bofPARCH___,bofJ_______,bofK_______,bofTEN_____,bofBIRD____,bofK_______,bofA_______,bofMAN_____,bofJ_______,bofQ_______,bofBOOK____,bofA_______,bofK_______,bofPARCH___,bofQ_______,bofVIAL____,bofA_______,bofQ_______,bofK_______,bofTEN_____,bofBOOK____,bofJ_______,bofVIAL____,bofA_______,bofK_______,bofMAN_____,bofTEN_____,bofVIAL____,bofJ_______",
        "bofPARCH___,bofJ_______,bofA_______,bofBOOK____,bofTEN_____,bofK_______,bofMAN_____,bofA_______,bofQ_______,bofPARCH___,bofA_______,bofTEN_____,bofVIAL____,bofK_______,bofJ_______,bofMAN_____,bofTEN_____,bofQ_______,bofVIAL____,bofJ_______,bofA_______,bofQ_______,bofVIAL____,bofTEN_____,bofK_______,bofBOOK____,bofJ_______,bofA_______,bofPARCH___,bofQ_______,bofTEN_____,bofBIRD____,bofJ_______,bofK_______",
        "bofTEN_____,bofA_______,bofPARCH___,bofQ_______,bofTEN_____,bofBIRD____,bofK_______,bofA_______,bofQ_______,bofVIAL____,bofTEN_____,bofQ_______,bofPARCH___,bofJ_______,bofK_______,bofTEN_____,bofBIRD____,bofK_______,bofA_______,bofMAN_____,bofJ_______,bofQ_______,bofBOOK____,bofA_______,bofK_______,bofPARCH___,bofQ_______,bofVIAL____,bofA_______,bofQ_______,bofK_______,bofTEN_____,bofBOOK____,bofJ_______,bofVIAL____,bofA_______,bofK_______,bofMAN_____,bofTEN_____,bofVIAL____,bofJ_______",
        "bofPARCH___,bofJ_______,bofA_______,bofBOOK____,bofTEN_____,bofK_______,bofMAN_____,bofA_______,bofQ_______,bofPARCH___,bofA_______,bofTEN_____,bofVIAL____,bofK_______,bofJ_______,bofMAN_____,bofTEN_____,bofQ_______,bofVIAL____,bofJ_______,bofA_______,bofQ_______,bofVIAL____,bofTEN_____,bofK_______,bofBOOK____,bofJ_______,bofA_______,bofPARCH___,bofQ_______,bofTEN_____,bofBIRD____,bofJ_______,bofK_______",

        "bofJ_______,bofBOOK____,bofQ_______,bofVIAL____,bofK_______,bofJ_______,bofMAN_____,bofQ_______,bofA_______,bofPARCH___,bofQ_______,bofVIAL____,bofA_______,bofTEN_____,bofQ_______,bofVIAL____,bofA_______,bofJ_______,bofPARCH___,bofQ_______,bofK_______,bofA_______,bofVIAL____,bofTEN_____,bofA_______,bofBOOK____,bofJ_______,bofPARCH___,bofK_______,bofA_______,bofMAN_____,bofK_______,bofVIAL____,bofQ_______,bofA_______,bofBIRD____,bofK_______,bofJ_______,bofQ_______,bofPARCH___,bofJ_______,bofBIRD____,bofTEN_____,bofK_______,bofMAN_____,bofTEN_____",
        "bofJ_______,bofBOOK____,bofQ_______,bofVIAL____,bofK_______,bofJ_______,bofMAN_____,bofQ_______,bofA_______,bofPARCH___,bofQ_______,bofVIAL____,bofA_______,bofTEN_____,bofQ_______,bofVIAL____,bofA_______,bofJ_______,bofPARCH___,bofQ_______,bofK_______,bofA_______,bofVIAL____,bofTEN_____,bofA_______,bofBOOK____,bofJ_______,bofPARCH___,bofK_______,bofA_______,bofMAN_____,bofK_______,bofVIAL____,bofQ_______,bofA_______,bofBIRD____,bofK_______,bofJ_______,bofQ_______,bofPARCH___,bofJ_______,bofBIRD____,bofTEN_____,bofK_______,bofMAN_____,bofTEN_____",
        "bofTEN_____,bofJ_______,bofBOOK____,bofK_______,bofJ_______,bofBIRD____,bofQ_______,bofTEN_____,bofVIAL____,bofK_______,bofTEN_____,bofPARCH___,bofQ_______,bofA_______,bofBIRD____,bofTEN_____,bofQ_______,bofVIAL____,bofA_______,bofTEN_____,bofBOOK____,bofQ_______,bofJ_______,bofMAN_____,bofA_______,bofK_______,bofVIAL____,bofQ_______,bofPARCH___,bofK_______,bofTEN_____,bofPARCH___,bofK_______",
        "bofJ_______,bofBOOK____,bofQ_______,bofVIAL____,bofK_______,bofJ_______,bofMAN_____,bofQ_______,bofA_______,bofPARCH___,bofQ_______,bofVIAL____,bofA_______,bofTEN_____,bofQ_______,bofVIAL____,bofA_______,bofJ_______,bofPARCH___,bofQ_______,bofK_______,bofA_______,bofVIAL____,bofTEN_____,bofA_______,bofBOOK____,bofJ_______,bofPARCH___,bofK_______,bofA_______,bofMAN_____,bofK_______,bofVIAL____,bofQ_______,bofA_______,bofBIRD____,bofK_______,bofJ_______,bofQ_______,bofPARCH___,bofJ_______,bofBIRD____,bofTEN_____,bofK_______,bofMAN_____,bofTEN_____",
        "bofTEN_____,bofJ_______,bofBOOK____,bofK_______,bofJ_______,bofBIRD____,bofQ_______,bofTEN_____,bofVIAL____,bofK_______,bofTEN_____,bofPARCH___,bofQ_______,bofA_______,bofBIRD____,bofTEN_____,bofQ_______,bofVIAL____,bofA_______,bofTEN_____,bofBOOK____,bofQ_______,bofJ_______,bofMAN_____,bofA_______,bofK_______,bofVIAL____,bofQ_______,bofPARCH___,bofK_______,bofTEN_____,bofPARCH___,bofK_______",
    };

    for (int i = 0; i < m_vecReelStripPlan.size(); i++) {
        ReelSet set;
        for (int j = 0; j < m_nReel; j++) {
            ReelStrip strip;
            std::stringstream ss(bofReelStrip[j * m_vecReelStripPlan.size() + i]);
            std::string item;
            while (std::getline(ss, item, ',')) {
                strip.push_back(item);
            }
            set.push_back(strip);
        }
        m_vecReelStripSets.push_back(set);
    }

    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_05_tmp;
    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_10_tmp;
    for (int i = 0; i < m_vecBetSteps_05_tmp.size(); i++) {
        std::map<std::string, std::map<UINT8, BONUS>> perSym;
        std::map<UINT8, BONUS> e;
        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 25; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[5].ag = 0;
        perSym["bofTEN_____"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 25; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[5].ag = 0;
        perSym["bofJ_______"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 25; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[5].ag = 0;
        perSym["bofQ_______"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 40; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 150; e[5].ag = 0;
        perSym["bofK_______"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 40; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 150; e[5].ag = 0;
        perSym["bofA_______"] = e;
        e.clear();

        e[2].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[2].ag = 0;
        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 30; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 750; e[5].ag = 0;
        perSym["bofPARCH___"] = e;
        e.clear();

        e[2].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[2].ag = 0;
        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 30; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 750; e[5].ag = 0;
        perSym["bofVIAL____"] = e;
        e.clear();

        e[2].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[2].ag = 0;
        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 50; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 500; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 2000; e[5].ag = 0;
        perSym["bofBIRD____"] = e;
        e.clear();

        e[2].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 10; e[2].ag = 0;
        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 1000; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5000; e[5].ag = 0;
        perSym["bofMAN_____"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 1000; e[5].ag = 0;
        perSym["bofBOOK____"] = e;
        e.clear();

        m_Bonus_05_tmp[i] = perSym;
    }

    m_Bonus_05_tmp[1]["bofMAN_____"][5].coin = 0; m_Bonus_05_tmp[1]["bofMAN_____"][5].ag = 10; // 10
    m_Bonus_05_tmp[2]["bofMAN_____"][5].coin = 0; m_Bonus_05_tmp[2]["bofMAN_____"][5].ag = 15; // 15
    m_Bonus_05_tmp[3]["bofMAN_____"][5].coin = 0; m_Bonus_05_tmp[3]["bofMAN_____"][5].ag = 20; // 20
    m_Bonus_05_tmp[4]["bofMAN_____"][5].coin = 0; m_Bonus_05_tmp[4]["bofMAN_____"][5].ag = 25; // 25
    m_Bonus_05_tmp[4]["bofBIRD____"][5].coin = 0; m_Bonus_05_tmp[4]["bofBIRD____"][5].ag = 10;
    m_Bonus_05_tmp[5]["bofMAN_____"][5].coin = 0; m_Bonus_05_tmp[5]["bofMAN_____"][5].ag = 30; // 30
    m_Bonus_05_tmp[5]["bofBIRD____"][5].coin = 0; m_Bonus_05_tmp[5]["bofBIRD____"][5].ag = 12;
    m_Bonus_05_tmp[6]["bofMAN_____"][5].coin = 0; m_Bonus_05_tmp[6]["bofMAN_____"][5].ag = 40; // 40
    m_Bonus_05_tmp[6]["bofBIRD____"][5].coin = 0; m_Bonus_05_tmp[6]["bofBIRD____"][5].ag = 16;
    m_Bonus_05_tmp[7]["bofMAN_____"][5].coin = 0; m_Bonus_05_tmp[7]["bofMAN_____"][5].ag = 50; // 50
    m_Bonus_05_tmp[7]["bofMAN_____"][4].coin = 0; m_Bonus_05_tmp[7]["bofMAN_____"][4].ag = 10;
    m_Bonus_05_tmp[7]["bofBIRD____"][5].coin = 0; m_Bonus_05_tmp[7]["bofBIRD____"][5].ag = 20;
    m_Bonus_05_tmp[7]["bofBOOK____"][5].coin = 0; m_Bonus_05_tmp[7]["bofBOOK____"][5].ag = 10;
    m_Bonus_05_tmp[8]["bofMAN_____"][5].coin = 0; m_Bonus_05_tmp[8]["bofMAN_____"][5].ag = 60; // 60
    m_Bonus_05_tmp[8]["bofMAN_____"][4].coin = 0; m_Bonus_05_tmp[8]["bofMAN_____"][4].ag = 12;
    m_Bonus_05_tmp[8]["bofBIRD____"][5].coin = 0; m_Bonus_05_tmp[8]["bofBIRD____"][5].ag = 24;
    m_Bonus_05_tmp[8]["bofBOOK____"][5].coin = 0; m_Bonus_05_tmp[8]["bofBOOK____"][5].ag = 12;
    m_Bonus_05_tmp[9]["bofMAN_____"][5].coin = 0; m_Bonus_05_tmp[9]["bofMAN_____"][5].ag = 80; // 80
    m_Bonus_05_tmp[9]["bofMAN_____"][4].coin = 0; m_Bonus_05_tmp[9]["bofMAN_____"][4].ag = 16;
    m_Bonus_05_tmp[9]["bofBIRD____"][5].coin = 0; m_Bonus_05_tmp[9]["bofBIRD____"][5].ag = 32;
    m_Bonus_05_tmp[9]["bofBOOK____"][5].coin = 0; m_Bonus_05_tmp[9]["bofBOOK____"][5].ag = 16;
    m_Bonus_05_tmp[9]["bofPARCH___"][5].coin = 0; m_Bonus_05_tmp[9]["bofPARCH___"][5].ag = 12;
    m_Bonus_05_tmp[9]["bofVIAL____"][5].coin = 0; m_Bonus_05_tmp[9]["bofVIAL____"][5].ag = 12;
    m_Bonus_05_tmp[10]["bofMAN_____"][5].coin = 0; m_Bonus_05_tmp[10]["bofMAN_____"][5].ag = 100; // 100
    m_Bonus_05_tmp[10]["bofMAN_____"][4].coin = 0; m_Bonus_05_tmp[10]["bofMAN_____"][4].ag = 20;
    m_Bonus_05_tmp[10]["bofBIRD____"][5].coin = 0; m_Bonus_05_tmp[10]["bofBIRD____"][5].ag = 40;
    m_Bonus_05_tmp[10]["bofBIRD____"][4].coin = 0; m_Bonus_05_tmp[10]["bofBIRD____"][4].ag = 10;
    m_Bonus_05_tmp[10]["bofBOOK____"][5].coin = 0; m_Bonus_05_tmp[10]["bofBOOK____"][5].ag = 20;
    m_Bonus_05_tmp[10]["bofPARCH___"][5].coin = 0; m_Bonus_05_tmp[10]["bofPARCH___"][5].ag = 15;
    m_Bonus_05_tmp[10]["bofVIAL____"][5].coin = 0; m_Bonus_05_tmp[10]["bofVIAL____"][5].ag = 15;
    m_Bonus_05_tmp[11]["bofMAN_____"][5].coin = 0; m_Bonus_05_tmp[11]["bofMAN_____"][5].ag = 100; // 200
    m_Bonus_05_tmp[11]["bofMAN_____"][4].coin = 0; m_Bonus_05_tmp[11]["bofMAN_____"][4].ag = 40;
    m_Bonus_05_tmp[11]["bofBIRD____"][5].coin = 0; m_Bonus_05_tmp[11]["bofBIRD____"][5].ag = 80;
    m_Bonus_05_tmp[11]["bofBIRD____"][4].coin = 0; m_Bonus_05_tmp[11]["bofBIRD____"][4].ag = 20;
    m_Bonus_05_tmp[11]["bofBOOK____"][5].coin = 0; m_Bonus_05_tmp[11]["bofBOOK____"][5].ag = 40;
    m_Bonus_05_tmp[11]["bofPARCH___"][5].coin = 0; m_Bonus_05_tmp[11]["bofPARCH___"][5].ag = 30;
    m_Bonus_05_tmp[11]["bofVIAL____"][5].coin = 0; m_Bonus_05_tmp[11]["bofVIAL____"][5].ag = 30;
    m_Bonus_05_tmp[12]["bofMAN_____"][5].coin = 0; m_Bonus_05_tmp[12]["bofMAN_____"][5].ag = 100; // 500
    m_Bonus_05_tmp[12]["bofMAN_____"][4].coin = 0; m_Bonus_05_tmp[12]["bofMAN_____"][4].ag = 100;
    m_Bonus_05_tmp[12]["bofMAN_____"][3].coin = 0; m_Bonus_05_tmp[12]["bofMAN_____"][3].ag = 10;
    m_Bonus_05_tmp[12]["bofBIRD____"][5].coin = 0; m_Bonus_05_tmp[12]["bofBIRD____"][5].ag = 100;
    m_Bonus_05_tmp[12]["bofBIRD____"][4].coin = 0; m_Bonus_05_tmp[12]["bofBIRD____"][4].ag = 50;
    m_Bonus_05_tmp[12]["bofBOOK____"][5].coin = 0; m_Bonus_05_tmp[12]["bofBOOK____"][5].ag = 100;
    m_Bonus_05_tmp[12]["bofBOOK____"][4].coin = 0; m_Bonus_05_tmp[12]["bofBOOK____"][4].ag = 10;
    m_Bonus_05_tmp[12]["bofPARCH___"][5].coin = 0; m_Bonus_05_tmp[12]["bofPARCH___"][5].ag = 75;
    m_Bonus_05_tmp[12]["bofVIAL____"][5].coin = 0; m_Bonus_05_tmp[12]["bofVIAL____"][5].ag = 75;
    m_Bonus_05_tmp[12]["bofPARCH___"][4].coin = 0; m_Bonus_05_tmp[12]["bofPARCH___"][4].ag = 10;
    m_Bonus_05_tmp[12]["bofVIAL____"][4].coin = 0; m_Bonus_05_tmp[12]["bofVIAL____"][4].ag = 10;
    m_Bonus_05_tmp[12]["bofJ_______"][5].coin = 0; m_Bonus_05_tmp[12]["bofJ_______"][5].ag = 10;
    m_Bonus_05_tmp[12]["bofQ_______"][5].coin = 0; m_Bonus_05_tmp[12]["bofQ_______"][5].ag = 10;
    m_Bonus_05_tmp[12]["bofK_______"][5].coin = 0; m_Bonus_05_tmp[12]["bofK_______"][5].ag = 15;
    m_Bonus_05_tmp[12]["bofA_______"][5].coin = 0; m_Bonus_05_tmp[12]["bofA_______"][5].ag = 15;
    m_Bonus_05_tmp[13]["bofMAN_____"][5].coin = 0; m_Bonus_05_tmp[13]["bofMAN_____"][5].ag = 100; // 1000
    m_Bonus_05_tmp[13]["bofMAN_____"][4].coin = 0; m_Bonus_05_tmp[13]["bofMAN_____"][4].ag = 100;
    m_Bonus_05_tmp[13]["bofMAN_____"][3].coin = 0; m_Bonus_05_tmp[13]["bofMAN_____"][3].ag = 20;
    m_Bonus_05_tmp[13]["bofBIRD____"][5].coin = 0; m_Bonus_05_tmp[13]["bofBIRD____"][5].ag = 100;
    m_Bonus_05_tmp[13]["bofBIRD____"][4].coin = 0; m_Bonus_05_tmp[13]["bofBIRD____"][4].ag = 100;
    m_Bonus_05_tmp[13]["bofBIRD____"][3].coin = 0; m_Bonus_05_tmp[13]["bofBIRD____"][3].ag = 10;
    m_Bonus_05_tmp[13]["bofBOOK____"][5].coin = 0; m_Bonus_05_tmp[13]["bofBOOK____"][5].ag = 100;
    m_Bonus_05_tmp[13]["bofBOOK____"][4].coin = 0; m_Bonus_05_tmp[13]["bofBOOK____"][4].ag = 20;
    m_Bonus_05_tmp[13]["bofPARCH___"][5].coin = 0; m_Bonus_05_tmp[13]["bofPARCH___"][5].ag = 100;
    m_Bonus_05_tmp[13]["bofVIAL____"][5].coin = 0; m_Bonus_05_tmp[13]["bofVIAL____"][5].ag = 100;
    m_Bonus_05_tmp[13]["bofPARCH___"][4].coin = 0; m_Bonus_05_tmp[13]["bofPARCH___"][4].ag = 20;
    m_Bonus_05_tmp[13]["bofVIAL____"][4].coin = 0; m_Bonus_05_tmp[13]["bofVIAL____"][4].ag = 20;
    m_Bonus_05_tmp[13]["bofJ_______"][5].coin = 0; m_Bonus_05_tmp[13]["bofJ_______"][5].ag = 20;
    m_Bonus_05_tmp[13]["bofQ_______"][5].coin = 0; m_Bonus_05_tmp[13]["bofQ_______"][5].ag = 20;
    m_Bonus_05_tmp[13]["bofK_______"][5].coin = 0; m_Bonus_05_tmp[13]["bofK_______"][5].ag = 30;
    m_Bonus_05_tmp[13]["bofA_______"][5].coin = 0; m_Bonus_05_tmp[13]["bofA_______"][5].ag = 30;


    m_Bonus_10_tmp = m_Bonus_05_tmp;
    for (int i = 0; i < m_vecBetSteps_10_tmp.size(); i++) {
        m_Bonus_10_tmp[i]["bofBOOK____"][3].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 20;
        m_Bonus_10_tmp[i]["bofBOOK____"][4].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 200;
        m_Bonus_10_tmp[i]["bofBOOK____"][5].coin = AT(m_vecBetSteps_10_tmp, i) / AT(m_vecBetSteps_10_tmp, 0) * 2000;
    }
    m_Bonus_10_tmp[4]["bofBOOK____"][5].coin = 0; m_Bonus_10_tmp[4]["bofBOOK____"][5].ag = 10; // 50
    m_Bonus_10_tmp[5]["bofBOOK____"][5].coin = 0; m_Bonus_10_tmp[5]["bofBOOK____"][5].ag = 12; // 60
    m_Bonus_10_tmp[6]["bofBOOK____"][5].coin = 0; m_Bonus_10_tmp[6]["bofBOOK____"][5].ag = 16; // 80
    m_Bonus_10_tmp[7]["bofBOOK____"][5].coin = 0; m_Bonus_10_tmp[7]["bofBOOK____"][5].ag = 20; // 100
    m_Bonus_10_tmp[8]["bofBOOK____"][5].coin = 0; m_Bonus_10_tmp[8]["bofBOOK____"][5].ag = 24; // 120
    m_Bonus_10_tmp[9]["bofBOOK____"][5].coin = 0; m_Bonus_10_tmp[9]["bofBOOK____"][5].ag = 32; // 160
    m_Bonus_10_tmp[10]["bofBOOK____"][5].coin = 0; m_Bonus_10_tmp[10]["bofBOOK____"][5].ag = 40; // 200
    m_Bonus_10_tmp[11]["bofBOOK____"][5].coin = 0; m_Bonus_10_tmp[11]["bofBOOK____"][5].ag = 80; // 400
    m_Bonus_10_tmp[12]["bofBOOK____"][4].coin = 0; m_Bonus_10_tmp[12]["bofBOOK____"][4].ag = 20; // 1000
    m_Bonus_10_tmp[13]["bofBOOK____"][4].coin = 0; m_Bonus_10_tmp[13]["bofBOOK____"][4].ag = 40; // 2000


    int nSavedBetVal = 10;
    string data;
    PlayDB::GetInstance().LoadCheckPoint(m_strGameName, nSavedBetVal, m_nWinLine, m_strCheckPoint);
    if (nSavedBetVal == -1) {
        nSavedBetVal = 10;
    }
    if (m_nWinLine == -1) {
        m_nWinLine = 5;
    }

    BOOL start = FALSE;
    int idx = 0;
    for (int i = 0; i < m_vecBetSteps_05_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_05_tmp, i) < AT(m_vecBetSteps_05, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps_05, idx) == nSavedBetVal && m_nWinLine == 5) {
            m_nBetStep = idx;
        }

        m_Bonus_05[idx++] = m_Bonus_05_tmp[i];
        if (AT(m_vecBetSteps_05_tmp, i) == AT(m_vecBetSteps_05, m_vecBetSteps_05.size() - 1)) {
            break;
        }
    }
    start = FALSE;
    idx = 0;
    for (int i = 0; i < m_vecBetSteps_10_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_10_tmp, i) < AT(m_vecBetSteps_10, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps_10, idx) == nSavedBetVal && m_nWinLine == 10) {
            m_nBetStep = idx;
        }

        m_Bonus_10[idx++] = m_Bonus_10_tmp[i];
        if (AT(m_vecBetSteps_10_tmp, i) == AT(m_vecBetSteps_10, m_vecBetSteps_10.size() - 1)) {
            break;
        }
    }
    m_Bonus = (m_nWinLine == 5 ? m_Bonus_05 : m_Bonus_10);
    m_vecBetSteps = (m_nWinLine == 5 ? m_vecBetSteps_05 : m_vecBetSteps_10);
    PrintAllBonus();
}

UINT16 RgBookOfFire::Run() {
    m_nCurrentReelPlan = 4;// (myRandom() % m_vecReelStripPlan.size()); // 0 ~ 3 dont match with client
    m_shCurrentReelStrip = static_cast<uint16_t>(std::stoi(AT(m_vecReelStripPlan, m_nCurrentReelPlan)));
    return m_shCurrentReelStrip;
}

void RgBookOfFire::ChangeReelStrip(UINT16 NewReelPlan) {
    m_nCurrentReelPlan = NewReelPlan;
    m_shCurrentReelStrip = static_cast<uint16_t>(std::stoi(AT(m_vecReelStripPlan, m_nCurrentReelPlan)));
}

UINT8 RgBookOfFire::CardCount(std::string card) {
    int n = 0;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int col = 0; col < m_nReel; col++) {
        int k = 0;
        for (; k < 3; k++) {
            std::string s = AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k);
            if (s == card) {
                n++;
            }
        }
    }
    return n;
}

BOOL RgBookOfFire::BookInCol(int col) {
    return CardNumInCol(col, RgBookOfFire_book);
}

UINT8 RgBookOfFire::CardNumInCol(int col, std::string card) {
    int n = 0;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int k = 0; k < 3; k++) {
        std::string s = AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k);
        if (s == card) {
            n++;
        }
    }
    return n;
}

myVector<UINT8> RgBookOfFire::Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) {
    m_bPrevSpinMatchedActive = FALSE;
    m_nMagicCount = 0;
    
    myVector<UINT8> result;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);

    if (bTest) {
        std::string matchSymbol = AT(m_vecSymbols, myRandom() % (m_vecSymbols.size() - 1));
        int line = (myRandom() % m_nWinLine);
        int weight = 1 + (myRandom() % 5);

        BOOL bForceFree = (myRandom() % 10 == 0);
        for (int i = 0; i < m_nReel; i++) {
            ReelStrip reelStrip = AT(reelSet, i);
            int len = reelStrip.size() - 3;

            int valid_i[0x100];
            int valid_count = 0;
            
            myVector<int> freeSymbols;
            for (int j = 0; j <= len; j++) {
                if (weight > i) {
                    if (matchSymbol == AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                else {
                    if (matchSymbol != AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }

                if (AT(reelStrip, j) == RgBookOfFire_book && m_bFreeMode == FALSE) {
                    freeSymbols.push_back(j);
                }
            }
            if (valid_count > 0) {
                int rand_index = myRandom() % valid_count;
                int chosen_i = valid_i[rand_index];
                result.push_back(chosen_i + 1);
            }
            else {
                result.push_back((myRandom() % (len - 1)) + 1);
            }

            if (bForceFree && m_bFreeMode == FALSE && (i == 0 || i == 2 || i == 4) && freeSymbols.size() > 0) {
                AT(result, result.size() - 1) =
                    AT(freeSymbols, myRandom() % freeSymbols.size()) - 1 * (myRandom() & 1) + 1;
            }
        }
    }
    else {
        result = _result;
        BOOL mmcode = mmcode_get_active_status();
        if (mmcode) {
            mmcode_set_deactive();
            if (m_bFreeMode == FALSE) {
                for (int j = 0; j < 5; j ++) {
                    myVector<int> candidateIndices;
                    for (int i = 2; i < AT(reelSet, j).size() - 3; ++i) {
                        if (j%2 == 0 && AT(AT(reelSet, j), i) == RgBookOfFire_book) {
                            int offset = myRandom() % 3;
                            int selectedIndex = i - 2 + offset;
                            candidateIndices.push_back(selectedIndex);
                        }
                        if (j%2 == 1 && AT(AT(reelSet, j), i) != RgBookOfFire_book
                                    && AT(AT(reelSet, j), i-2) != RgBookOfFire_book
                                    && AT(AT(reelSet, j), i-1) != RgBookOfFire_book
                                    && AT(AT(reelSet, j), i+1) != RgBookOfFire_book
                                    && AT(AT(reelSet, j), i+2) != RgBookOfFire_book) {
                            int offset = myRandom() % 3;
                            int selectedIndex = i - 2 + offset;
                            candidateIndices.push_back(selectedIndex);
                        }
                    }
                    if (!candidateIndices.empty()) {
                        //int chosenIndex = AT(candidateIndices, myRandom() % candidateIndices.size());
#ifdef BIGBET_ACTIVE
                        int chosenIndex = AT(candidateIndices, 0);
#else
                        int chosenIndex = AT(candidateIndices, myRandom() % candidateIndices.size());
#endif
                        AT(result, j) = chosenIndex + 1;
                    }
                }
            }
        }
        m_vWinResult = result;
        if (m_bFreeMode && ((myRandom() % 3) == 0)) {
            int pool[5] = { 0, 1, 2, 3, 4 };
            int existCnt = 0;
            // get exists
            // check wild symbol
            for (int col = 0; col < 5; col++) {
                if (CardNumInCol(col, m_strSelectedcard) > 0) {
                    existCnt++;
                }
            }
            if (existCnt < m_mapSymbolMinMatch[m_strSelectedcard]) {
                int poolSize = 0;
                for (int col = 0; col < 5; col++) {
                    if (CardNumInCol(col, m_strSelectedcard) == 0) {
                        pool[poolSize] = col;
                        poolSize++;
                    }
                }
                myVector<int> selectedReels = pickRandom2or3(pool, poolSize, m_mapSymbolMinMatch[m_strSelectedcard] - existCnt);
                for (int j = 0; j < selectedReels.size(); j++) {
                    int reel = AT(selectedReels, j);
                    ReelStrip reelStrip = AT(reelSet, reel);
                    for (int i = 3; i < reelStrip.size() - 2; i++) {
                        if (AT(reelStrip, i) == m_strSelectedcard) {
                            AT(result, reel) = i - (myRandom() % 3) + 1;
                            break;
                        }
                    }
                }
            }
        }
    }
    m_vWinResult = result;

    normalMeter = 0;
    maxMeter = 0;
    BONUS totalBonus = {0, 0};
    int maxBookMatchCount = 0;
    int Book5Matched = 0;
    for (int i = 0; i < m_nWinLine; i++) {
        int j = 1;
        UINT16 meter = ((UINT16)1 << (2 - g_match_lines_10_5[i][0]));
        std::string firstSymbol = AT(AT(reelSet, 0), AT(result, 0) - 1 + g_match_lines_10_5[i][0]);
        maxBookMatchCount = 0;

        for (; j < m_nMaxMatch; j++) {
            std::string prev_symbol = AT(AT(reelSet, j - 1), AT(result, j - 1) - 1 + g_match_lines_10_5[i][j - 1]);
            std::string cur_symbol = AT(AT(reelSet, j), AT(result, j) - 1 + g_match_lines_10_5[i][j]);

            if (cur_symbol == RgBookOfFire_book) {
                maxBookMatchCount++;
            }
            if (firstSymbol == RgBookOfFire_book) { // scatter
                firstSymbol = cur_symbol;
            }

            if (firstSymbol == cur_symbol || cur_symbol == RgBookOfFire_book) {
                meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
                continue;
            }
            break;
        }

        if (j < m_mapSymbolMinMatch[firstSymbol] || m_mapSymbolMinMatch[firstSymbol] == 0) {
            continue;
        }
        if (firstSymbol == RgBookOfFire_book) {
            Book5Matched = 1;
        }

        // monitor 2 meter
        std::string meterStr = m_mapSymbolMeterGoc[firstSymbol];
        size_t pos = meterStr.find('$');
        if (pos != std::string::npos) {
            meterStr = meterStr.replace(pos, 1, std::to_string(j));
        }

        WinMeter e;
        e.line = i;
        e.meter = meter;
        e.meter2 = g_GrafficObjList.Str2GOCID(meterStr);
        e.symbol = firstSymbol;
        e.weight = j;
        e.start = 0;
        e.bonus = m_Bonus[BetStep()][firstSymbol][j];
        e.sound = MAX_SOUND_IDS;
        totalBonus.coin += e.bonus.coin;
        totalBonus.ag += e.bonus.ag;

        if (e.meter2 != -1) {
            meters.push_back(e);
        }
        if (j == m_nMaxMatch) {
            maxMeter |= meter;
        }
        else {
            normalMeter |= meter;
        }
        if (bTest == FALSE) {
            m_bPrevSpinMatchedActive = TRUE;
        }
    }
    int nBook = CardCount(RgBookOfFire_book);
    if (nBook >= 3) {
        bCanFreeMode = TRUE;

        // not match Book 5, and Book match contains other match
        if (Book5Matched == 0 && maxBookMatchCount < nBook) {
            UINT16 meter = 0;
            for (int i = 0; i < 3; i++) {
                for (int col = 0; col < m_nReel; col++) {
                    std::string cur_symbol = AT(AT(reelSet, col), AT(result, col) - 1 + i);
                    if (cur_symbol == RgBookOfFire_book) {
                        meter |= ((UINT16)1 << (3 * col + (2 - i)));
                    }
                }
            }

            WinMeter e;
            e.line = 10;
            e.meter = meter;
            e.meter2 = g_GrafficObjList.Str2GOCID("bofBook" + std::to_string(nBook) + "x");
            e.symbol = RgBookOfFire_book;
            e.weight = nBook;
            e.start = 0;
            e.bonus = m_Bonus[BetStep()][RgBookOfFire_book][nBook];
            e.sound = MAX_SOUND_IDS;

            normalMeter |= meter;
            totalBonus.coin += e.bonus.coin;
            totalBonus.ag += e.bonus.ag;

            meters.push_back(e);

            if (bTest == FALSE) {
                m_bPrevSpinMatchedActive = TRUE;
            }
        }
    }
    if (m_bFreeMode) {
        int colCount = 0;
        int symbolToConvert = 0;
        for (int col = 0; col < m_nReel; col++) {
            int n = CardNumInCol(col, m_strSelectedcard);
            if (n > 0) {
                colCount++;
                symbolToConvert += (3 - n);
            }
        }
        if (colCount >= m_mapSymbolMinMatch[m_strSelectedcard] && m_mapSymbolMinMatch[m_strSelectedcard] > 0) {
            UINT16 cgoc = g_GrafficObjList.Str2GOCID(m_strSelectedcard);
            // convert
            UINT32 convertDelay = symbolToConvert * 300;
            WinMeter e;
            e.line = 0xFF;
            e.bonus.coin = 0;
            e.bonus.ag = 0;
            e.IntWinbonus.push_back({
                 0,
                 convertDelay,
                 {0x01, 0x02, 0x31, 0x00, 0x02, 0x00, 0x6f, 0x11, 0xce, 
                 static_cast<BYTE>(cgoc & 0xFF), static_cast<BYTE>((cgoc >> 8) & 0xFF), 0x04} });
            
            //
            myVector<uint8_t> pkt = {
                0x01, 0x02, 0x31, 0x00, 0x08, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x9c, 0x15, 0x00
            };
            int pktLen = 0;

            myVector<WinMeter> FreeMeters;
            UINT16 FreeNormalMeter = 0;
            // get win match after convert
            for (int i = 0; i < m_nWinLine; i++) {
                UINT16 meter = 0; // ((UINT16)1 << (2 - g_match_lines_10_5[i][0]));
                for (int j = 0; j < m_nMaxMatch; j++) {
                    if (!CardNumInCol(j, m_strSelectedcard)) {
                        continue;
                    }
                    meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
                }
                std::string meterStr = m_mapSymbolMeterGoc[m_strSelectedcard];
                size_t pos = meterStr.find('$');
                if (pos != std::string::npos) {
                    meterStr = meterStr.replace(pos, 1, std::to_string(colCount));
                }

                WinMeter ele;
                ele.line = i;
                ele.meter = meter;
                ele.meter2 = g_GrafficObjList.Str2GOCID(meterStr);
                ele.symbol = m_strSelectedcard;
                ele.weight = colCount;
                ele.start = 0;
                ele.bonus = m_Bonus[BetStep()][m_strSelectedcard][colCount];
                ele.sound = MAX_SOUND_IDS;
                
                totalBonus.coin += ele.bonus.coin;
                totalBonus.ag += ele.bonus.ag;
                FreeMeters.push_back(ele);
                
                FreeNormalMeter |= meter;

                pkt.push_back(ele.line);
                pkt.push_back(static_cast<BYTE>(ele.meter & 0xFF));
                pkt.push_back(static_cast<BYTE>((ele.meter >> 8) & 0xFF));
                pkt.push_back(static_cast<BYTE>(ele.meter2 & 0xFF));
                pkt.push_back(static_cast<BYTE>((ele.meter2 >> 8) & 0xFF));
                pkt.push_back(0x01);
                pkt.push_back(0x00);
                pktLen += 7;
            }         
            AT(pkt, 4) = 1 + pktLen; //len
            AT(pkt, pkt.size() - 1) = 0x04;
            // refresh meters
            e.IntWinbonus.push_back({0, 0, pkt });
            meters.push_back(e);
            meters.insert(meters.end(), FreeMeters.begin(), FreeMeters.end());
        }
    }

    m_vWinMeters = meters;
    m_nMagicCount = totalBonus.ag;
    if (bTest == FALSE) {
        updateCheckPoint();
        if (totalBonus.coin > 0 || totalBonus.ag > 0) {
            if (m_bFreeMode) {
                m_nFreeModeTotalBonus.coin += totalBonus.coin;
                m_nFreeModeTotalBonus.ag += totalBonus.ag;
            }
            BonusSound = getSoundByID(WinSound(totalBonus.coin + totalBonus.ag * 1000));
        }
    }
    return result;
}

UINT16 RgBookOfFire::MagicCount() {
    if (m_bFreeMode) {
        return 0;
    }
    else {
        return m_nMagicCount;
    }
}

int RgBookOfFire::LineSwapDelay(int WinIdx) {
    return 500;
}

UINT16 RgBookOfFire::SpinTime_MS() {
    if (CardCount(RgBookOfFire_book) >= 3) {
        return 4200;
    }
    if (CardCount(RgBookOfFire_book) == 2 && BookInCol(4) == FALSE) {
        return 4200;
    }
    return 2300;
}

BOOL RgBookOfFire::CanFreeMode() {
    if (CardCount(RgBookOfFire_book) >= 3) {
        return TRUE;
    }
    return FALSE;
}

myVector<InterruptPacketData> RgBookOfFire::EnterFreeGame(std::string check) {
    m_nFreeModeTotalSpin = 10;
    m_nFreeModeGoneSpin = 0;
    m_nFreeModeTotalBonus.coin = 0;
    m_nFreeModeTotalBonus.ag = 0;

    int randIdx = myRandom() % (m_vecSymbols.size() - 2);
    m_strSelectedcard = AT(m_vecSymbols, randIdx);
    UINT16 selectedGOC = g_GrafficObjList.Str2GOCID(m_strSelectedcard);


    m_bFreeMode = TRUE;
    myVector<InterruptPacketData> packets;
    // stop all sound
    packets.push_back({
        0,
        0,
        {0x01, 0x02, 0x35, 0x00, 0x00, 0x00, 0x04} });

    if (check != "") {
        myVector<int> values = ParseCheckPoint(check, "F", 5);
        if (values.size() == 5) {
            m_strSelectedcard = AT(m_vecSymbols, AT(values, 0));
            m_nFreeModeTotalSpin = AT(values, 1);
            m_nFreeModeGoneSpin = AT(values, 2);
            m_nFreeModeTotalBonus.coin = AT(values, 3);
            m_nFreeModeTotalBonus.ag = AT(values, 4);
            
            selectedGOC = g_GrafficObjList.Str2GOCID(m_strSelectedcard);

            UINT8 gone = m_nFreeModeGoneSpin ? m_nFreeModeGoneSpin : 1;
            packets.push_back({
                0,
                0,
                {0x01, 0x02, 0x30, 0x00, 0x6f, 0x11, gone, 0x00, m_nFreeModeTotalSpin, 0x00, 0x00, 0x00,
                static_cast<BYTE>(selectedGOC & 0xFF), static_cast<BYTE>((selectedGOC >> 8) & 0xFF),
                0xa3, 0x04} });
            return packets;
        }
    }
    else {
        updateCheckPoint();
    }
    // show freespin intro dialog
    packets.push_back({
        0,
        6000,
        {0x01, 0x02, 0x30, 0x00, 0x6f, 0x11, 0x00, 0x00, 0x01, 0x00, m_nFreeModeTotalSpin, 0x00,
        static_cast<BYTE>(selectedGOC & 0xFF), static_cast<BYTE>((selectedGOC >> 8) & 0xFF),
        0xa6, 0x04} });

    // show selecting dialog    
    packets.push_back({
            0,
            6000,
            {0x01, 0x02, 0x28, 0x00, 0x6f, 0x11, 0x01, 0x00, 0x00, 0x00, 0x04} });

    // hide dlg
    packets.push_back({
            0,
            500,
            {0x01, 0x02, 0x30, 0x00, 0x6f, 0x11, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xac, 0x04} });
    
    return packets;
}

myVector<InterruptPacketData> RgBookOfFire::InterruptBeforeSpin() {
  
    myVector<InterruptPacketData> packets;
    if (!m_bFreeMode) {
        return packets;
    }
    m_nFreeModeGoneSpin++;
    updateCheckPoint();

    UINT8 gone = (m_nFreeModeGoneSpin ? m_nFreeModeGoneSpin : 1);

    // display total & remain free spin count
    packets.push_back({
        0,
        0,
        {
            0x01, 0x02, 0x30, 0x00, 0x6f, 0x11, gone, 0x00, m_nFreeModeTotalSpin, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa5, 0x04
        }
        });
    return packets;
}

myVector<InterruptPacketData> RgBookOfFire::InterruptAfterMoveBonus(BOOL& EndFree) {
    myVector<InterruptPacketData> packets;

    int n = CardCount(RgBookOfFire_book);
    if (n >= 3) {
        UINT8 gone = (m_nFreeModeGoneSpin ? m_nFreeModeGoneSpin : 1);
        m_nFreeModeTotalSpin += 10;

        UINT16 cgoc = g_GrafficObjList.Str2GOCID(m_strSelectedcard);
        // show additional spin
        packets.push_back({ 0, 3000, {0x06, 0x23, 0x59, 0x01, 0x02, 0x30, 0x00, 0x6F, 0x11, 0x00, 0x00, gone, 0x00, m_nFreeModeTotalSpin, 0x00, 
            static_cast<BYTE>(cgoc & 0xFF), static_cast<BYTE>((cgoc >> 8) & 0xFF), 0xA6, 0x04} });
        // hide
        packets.push_back({ 1000, 0, {0x01, 0x02, 0x30, 0x00, 0x6F, 0x11, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xAC, 0x04} });
        // update status
        packets.push_back({
            0,
            500,
            {
                0x01, 0x02, 0x30, 0x00, 0x6f, 0x11, gone, 0x00, m_nFreeModeTotalSpin, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa5, 0x04
            }
        });
    }

    if (m_nFreeModeGoneSpin >= m_nFreeModeTotalSpin) { // ref EyeOfHorus
        EndFree = TRUE;
        m_bFreeMode = FALSE;

        // show result dlg
        packets.push_back({
             100,
             0,
             {0x06, 0x6f, 0x11, 0x01, 0x02, 0x30, 0x00, 0x6f, 0x11, 0x00, 0x00, 
             static_cast<BYTE>(m_nFreeModeTotalBonus.coin & 0xFF), 
             static_cast<BYTE>((m_nFreeModeTotalBonus.coin >> 8) & 0xFF), 
             static_cast<BYTE>((m_nFreeModeTotalBonus.coin >> 16) & 0xFF),
             static_cast<BYTE>((m_nFreeModeTotalBonus.coin >> 24) & 0xFF),
             0x14, 0x00, 0xab, 0x04} });

        // return to main game
        packets.push_back({
                    0,
                    2000,
                    {0x01, 0x02, 0x30, 0x00, 0x6f, 0x11, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa4, 0x04} });

        // hide result dlg
        packets.push_back({
                    0,
                    500,
                    {0x01, 0x02, 0x30, 0x00, 0x6f, 0x11, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xac, 0x04} });
        updateCheckPoint();
        return packets;
    }
    EndFree = FALSE;

    //m_nFreeModeGoneSpin++;
    updateCheckPoint();
    return packets;
}

myVector<InterruptPacketData> RgBookOfFire::MousePressed(MousePosition p) {
    myVector<InterruptPacketData> packets;

    MousePosition a{
       {RgBookOfFire_MP_ChangeLine_LB_x_reel, RgBookOfFire_MP_ChangeLine_LB_x_pos },
       {RgBookOfFire_MP_ChangeLine_LB_y_row, RgBookOfFire_MP_ChangeLine_LB_y_pos }
    };
    MousePosition b{
        {RgBookOfFire_MP_ChangeLine_RT_x_reel, RgBookOfFire_MP_ChangeLine_RT_x_pos },
        {RgBookOfFire_MP_ChangeLine_RT_y_row, RgBookOfFire_MP_ChangeLine_RT_y_pos }
    };
    if (IsMouseWithin(p, a, b)) {
        m_nWinLine = (m_nWinLine == 5) ? 10 : 5;
        if (m_bPrevSpinMatchedActive) {
            // hide win lines
            packets.push_back({ 0, 0, {0x01, 0x02, 0x31, 0x00, 0x01, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x02, 0x00, 0x04} });
            m_bPrevSpinMatchedActive = FALSE;
        }
        UINT16 newBetValue = 0;
        if (m_nWinLine == 5) {
            m_Bonus = m_Bonus_05;
            m_vecBetSteps = m_vecBetSteps_05;
            newBetValue = AT(m_vecBetSteps_10, m_nBetStep) / 2;
            // lines
            packets.push_back({ 0, 0, {0x01, 0x02, 0x31, 0x00, 0x04, 0x00,
                static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x9d, 0x1f, 0x00, 0x00, 0x00, 0x04} });
        }
        else {
            m_Bonus = m_Bonus_10;
            m_vecBetSteps = m_vecBetSteps_10;
            newBetValue = AT(m_vecBetSteps_05, m_nBetStep) * 2;
            // lines
            packets.push_back({ 0, 0, {0x01, 0x02, 0x31, 0x00, 0x04, 0x00, static_cast<BYTE>(m_nGameID & 0xFF),
                static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x9d, 0xff, 0x03, 0x00, 0x00, 0x04} });
        }
        BOOL flag = FALSE;
        for (int i = 0; i < m_vecBetSteps.size(); i++) {
            if (AT(m_vecBetSteps, i) == newBetValue) {
                m_nBetStep = i;
                flag = TRUE;
                break;
            }
        }
        if (flag == FALSE) {
            m_nBetStep = 0;
        }
        // play button sound
        packets.push_back({ 0, 0, {0x01, 0x02, 0x34, 0x00, 0xf7, 0x00, 0x04} });
        // change line button
        packets.push_back({ 0, 0, {0x01, 0x02, 0x28, 0x00,
            static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), static_cast<BYTE>(m_nWinLine), 0x00, 0x00, 0x00, 0x04} });
        // set bet
        UINT16 bet = AT(m_vecBetSteps, m_nBetStep) / 5;
        packets.push_back({ 0, 0, {0x01, 0x02, 0x30, 0x00, 0x25, 0x53, 
            static_cast<BYTE>(bet & 0xFF), static_cast<BYTE>((bet >> 8) & 0xFF), 
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04, 0x04} });
    }
    return packets;
}

myVector<UINT8> RgBookOfFire::ShowTotalWinLines(myVector<WinMeter> SpinMeters) {
    myVector<uint8_t> packet = {
        0x06, 0x30, 0x59, 0x01, 0x02, 0x31, 0x00,
        0x0F, 0x00,  // Placeholder for length 
        0x0F, 0x11, // GameID
        0x9C, 0x19, 0x01
    };
    myVector<UINT8> TotalMatch;
    for (int i = 0; i < SpinMeters.size(); i++) {
        if (AT(SpinMeters, i).line == 0xFF) { // clear after convert action
            TotalMatch.clear();
            continue;
        }
        TotalMatch.push_back(AT(SpinMeters, i).line);
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter >> 8) & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter2 & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter2 >> 8) & 0xFF));
    }
    if (TotalMatch.size() < 10) {
        myVector<UINT8> _;
        return _;
    }
    UINT16 pktLen = 1 + (TotalMatch.size() / 5) * 7;
    AT(packet, 7) = static_cast<BYTE>(pktLen & 0xFF);
    AT(packet, 8) = static_cast<BYTE>((pktLen >> 8) & 0xFF);
    AT(packet, 9) = static_cast<BYTE>(m_nGameID & 0xFF);
    AT(packet, 10) = static_cast<BYTE>((m_nGameID >> 8) & 0xFF);
    int entryCount = static_cast<int>(TotalMatch.size() / 5);
    for (int i = 0; i < entryCount; ++i) {
        packet.push_back(AT(TotalMatch, i * 5 + 0)); // Line
        packet.push_back(AT(TotalMatch, i * 5 + 1)); // Meter low byte
        packet.push_back(AT(TotalMatch, i * 5 + 2)); // Meter high byte
        packet.push_back(AT(TotalMatch, i * 5 + 3)); // Meter2 low byte
        packet.push_back(AT(TotalMatch, i * 5 + 4)); // Meter2 high byte
        packet.push_back(0x01);      // Status or flag 1
        packet.push_back(0x01);      // Status or flag 2
    }
    // Mark the end of the packet
    packet.back() = 0x04;
    return packet;
}

bool RgBookOfFire::RTP_force_bigWin() {
    return (myRandom() % 65 == 0); // 1.53%
}

BOOL RgBookOfFire::SelectedableReelsInFreeGame(myVector<UINT8> result) {
    if (m_bFreeMode == FALSE) {
        return TRUE;
    }
    myVector<UINT8> cp = m_vWinResult;
    m_vWinResult = result;
    int n = CardCount(RgBookOfFire_book);
    m_vWinResult = cp;
    if (n >= 3) {
        return FALSE;
    }
    return TRUE;
}

BOOL RgBookOfFire::stopAllSoundBeforeMove() {
    return FALSE;
}


void RgBookOfFire::updateCheckPoint() {
    std::ostringstream oss;
    oss << " P" << m_nCurrentReelPlan
        << " B"
        << static_cast<int>(AT(m_vWinResult, 0)) << ":"
        << static_cast<int>(AT(m_vWinResult, 1)) << ":"
        << static_cast<int>(AT(m_vWinResult, 2)) << ":"
        << static_cast<int>(AT(m_vWinResult, 3)) << ":"
        << static_cast<int>(AT(m_vWinResult, 4)) << " ";

    if (m_bFreeMode) {
        int idx = 0;
        auto it = std::find(m_vecSymbols.begin(), m_vecSymbols.end(), m_strSelectedcard);
        if (it != m_vecSymbols.end()) {
            idx = std::distance(m_vecSymbols.begin(), it);
        }
        oss << " F"
            << static_cast<int>(idx) << ":"
            << static_cast<int>(m_nFreeModeTotalSpin) << ":"
            << static_cast<int>(m_nFreeModeGoneSpin) << ":"
            << static_cast<int>(m_nFreeModeTotalBonus.coin) << ":"
            << static_cast<int>(m_nFreeModeTotalBonus.ag)
            << " ";
    }
    m_strCheckPoint = oss.str();
}