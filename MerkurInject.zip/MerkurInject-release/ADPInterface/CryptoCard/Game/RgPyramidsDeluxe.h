#pragma once

#include "ReelGame.h"

class RgPyramidsDeluxe : public ReelGame
{
public:
	UINT8 m_nFreeModeTotalSpin;
	UINT8 m_nFreeModeGoneSpin;
	BONUS m_nFreeModeTotalBonus;
	BOOL m_bFreeMode;

	myVector<WinMeter> m_vWinMeters;

	RgPyramidsDeluxe::RgPyramidsDeluxe();
	UINT8 CardCount(std::string card);
	UINT8 NumberOfScatter();
	BOOL NumberInCol(int col);
	void ChangeReelStrip(BOOL forFreeMode);

	UINT16 Run() override;
	int LineSwapDelay(int WinIdx) override;
	UINT16 MagicCount() override;
	myVector<UINT8> Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& WinSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) override;
	UINT16 SpinTime_MS() override;
	BOOL CanFreeMode() override;
	myVector<InterruptPacketData> EnterFreeGame(std::string) override;
	myVector<InterruptPacketData> InterruptBeforeSpin() override;
	myVector<InterruptPacketData> InterruptAfterMoveBonus(BOOL& EndFree) override;

	myVector<InterruptPacketData> MousePressed(MousePosition p) override;
	myVector<UINT8> ShowTotalWinLines(myVector<WinMeter> SpinMeters) override;

	bool RTP_force_bigWin() override;
	BOOL SelectedableReelsInFreeGame(myVector<UINT8> result) override;

	void ChangeReelStrip(UINT16 NewReelPlan) override;
	BOOL NoFunInFreeMode() override;
	void updateCheckPoint() override;
};
