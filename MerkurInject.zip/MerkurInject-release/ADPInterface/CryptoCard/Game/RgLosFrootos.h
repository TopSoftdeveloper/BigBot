#pragma once

#include "ReelGame.h"
#include "RgLosFrootosPS1.h"
#include "RgLosFrootosPS2.h"
#include "RgLosFrootosPS3.h"
#include "RgLosFrootosPS4.h"

class RgLosFrootos : public ReelGame
{
public:
	UINT8 m_nMultiGoTotalCount;
	UINT8 m_nMultiGoGone;
	UINT8 m_nMultiLoop;

	RgLosFrootosPS1 m_PS1;
	RgLosFrootosPS2 m_PS2;
	RgLosFrootosPS3 m_PS3;
	RgLosFrootosPS4 m_PS4;

	myVector<UINT8> m_vPSPlans;

	myVector<WinMeter> m_vWinMeters;

	RgLosFrootos::RgLosFrootos();
	UINT16 GetTotalBonus();

	UINT16 Run() override;
	int LineSwapDelay(int WinIdx) override;
	myVector<UINT16> CurrentReelStrip() override;
	myVector<UINT8> Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) override;
	void MultiGoGoneAndRemain(UINT8& gone, UINT8& total, UINT8& loop) override;
	myVector<InterruptPacketData> InterruptBeforeSpin() override;

	BOOL CanMultiGo() override;
	myVector<InterruptPacketData> EnterMultiGo(UINT32& bonusErfolg, BOOL bIitMultiBet) override;
	myVector<InterruptPacketData> CloseMultiGo(UINT32& bonusErfolg, BOOL force) override;
	myVector<InterruptPacketData> BetUpMultiGo(UINT32& bonusErfolg) override;
	myVector<InterruptPacketData> BetDownMultiGo(UINT32& bonusErfolg) override;
	UINT16 MiltiGoBet() override;
	UINT8 RgLosFrootos::MultiGoBetStep() override;
	void SetMultiGoBetStep(UINT8 newStep) override;
	BOOL GetMultiGoEnable()  override;
	void SetMultiGoEnable(BOOL status) override;
	void GetMultiGoReelPlanIdx(int& p0, int& p1, int& p2, int& p3) override;
	void SetMultiGoReelPlanIdx(int p0, int p1, int p2, int p3) override;

	myVector<InterruptPacketData> InterruptAfterSpin() override;

	myVector<UINT8> ShowTotalWinLines(myVector<WinMeter> SpinMeters) override;
	void ChangeReelStrip(UINT16 NewReelPlan) override;
};
