#pragma once

#include "ReelGame.h"

class RgFruitinator : public ReelGame
{
public:
	RgFruitinator::RgFruitinator();

	myVector<UINT8> Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) override;
	myVector<UINT8> ShowTotalWinLines(myVector<WinMeter> SpinMeters) override;
};
