#pragma once

#include "ReelGame.h"

class RgBlazingSun : public ReelGame
{
public:
	RgBlazingSun::RgBlazingSun();

	myVector<UINT8> Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) override;
};
