#include "stdafx.h"
#include "RgPyramidOfPower.h"

#define RgPyramidOfPower_wild "PYRAMPY"
RgPyramidOfPower::RgPyramidOfPower() {
    m_nReel = 5;
    m_nWinLine = 16;
    m_nMaxMatch = 5;
    m_nBetStep = 0;

    m_strGameName = "RgPyramidOfPower";

    myVector<UINT16> m_vecBetSteps_tmp;
    m_vecBetSteps_tmp.push_back(10);
    m_vecBetSteps_tmp.push_back(20);
    m_vecBetSteps_tmp.push_back(30);
    m_vecBetSteps_tmp.push_back(40);
    m_vecBetSteps_tmp.push_back(50);
    m_vecBetSteps_tmp.push_back(60);
    m_vecBetSteps_tmp.push_back(80);
    m_vecBetSteps_tmp.push_back(100);
    m_vecBetSteps_tmp.push_back(150);
    m_vecBetSteps_tmp.push_back(200);
#ifdef BIGBET_ACTIVE
    m_vecBetSteps_tmp.push_back(500);
    m_vecBetSteps_tmp.push_back(1000);
#endif
    LoadBets();

    m_vecSymbols.push_back("TEN__PY");
    m_vecSymbols.push_back("JACK_PY");
    m_vecSymbols.push_back("QUEENPY");
    m_vecSymbols.push_back("KING_PY");
    m_vecSymbols.push_back("ACE__PY");
    m_vecSymbols.push_back("SCARAPY");
    m_vecSymbols.push_back("HORUSPY");
    m_vecSymbols.push_back("ANUBIPY");
    m_vecSymbols.push_back("PHARAPY");
    m_vecSymbols.push_back("PYRAMPY");

    m_mapSymbolMinMatch["TEN__PY"] = 3;
    m_mapSymbolMinMatch["JACK_PY"] = 3;
    m_mapSymbolMinMatch["QUEENPY"] = 3;
    m_mapSymbolMinMatch["KING_PY"] = 3;
    m_mapSymbolMinMatch["ACE__PY"] = 3;
    m_mapSymbolMinMatch["SCARAPY"] = 3;
    m_mapSymbolMinMatch["HORUSPY"] = 3;
    m_mapSymbolMinMatch["ANUBIPY"] = 3;
    m_mapSymbolMinMatch["PHARAPY"] = 3;

    m_mapSymbolMeterGoc["TEN__PY"] = "pyQJT$x";
    m_mapSymbolMeterGoc["JACK_PY"] = "pyQJT$x";
    m_mapSymbolMeterGoc["QUEENPY"] = "pyQJT$x";
    m_mapSymbolMeterGoc["KING_PY"] = "pyAK$x";
    m_mapSymbolMeterGoc["ACE__PY"] = "pyAK$x";
    m_mapSymbolMeterGoc["SCARAPY"] = "pySkarab$x";
    m_mapSymbolMeterGoc["HORUSPY"] = "pyHorus$x";
    m_mapSymbolMeterGoc["ANUBIPY"] = "pyAnubis$x";
    m_mapSymbolMeterGoc["PHARAPY"] = "pyPharao$x";

    m_vecWinLines.push_back("pyWinline1");
    m_vecWinLines.push_back("pyWinline2");
    m_vecWinLines.push_back("pyWinline3");
    m_vecWinLines.push_back("pyWinline4");
    m_vecWinLines.push_back("pyWinline5");
    m_vecWinLines.push_back("pyWinline6");
    m_vecWinLines.push_back("pyWinline7");
    m_vecWinLines.push_back("pyWinline8");
    m_vecWinLines.push_back("pyWinline9");
    m_vecWinLines.push_back("pyWinline10");
    m_vecWinLines.push_back("pyWinline11");
    m_vecWinLines.push_back("pyWinline12");
    m_vecWinLines.push_back("pyWinline13");
    m_vecWinLines.push_back("pyWinline14");
    m_vecWinLines.push_back("pyWinline15");
    m_vecWinLines.push_back("pyWinline16");

    m_vecLineSounds.push_back(SMP_PY_WinPart_1);
    m_vecLineSounds.push_back(SMP_PY_WinPart_2);
    m_vecLineSounds.push_back(SMP_PY_WinPart_3);
    m_vecLineSounds.push_back(SMP_PY_WinPart_4);
    m_vecLineSounds.push_back(SMP_PY_WinPart_5);
    m_vecLineSounds.push_back(SMP_PY_WinPart_6);
    m_vecLineSounds.push_back(SMP_PY_WinPart_7);
    m_vecLineSounds.push_back(SMP_PY_WinPart_8);
    m_vecLineSounds.push_back(SMP_PY_WinPart_9);
    m_vecLineSounds.push_back(SMP_PY_WinPart_10);
    m_vecLineSounds.push_back(SMP_PY_WinPart_11);
    m_vecLineSounds.push_back(SMP_PY_WinPart_12);
    m_vecLineSounds.push_back(SMP_PY_WinPart_13);
    m_vecLineSounds.push_back(SMP_PY_WinPart_14);
    m_vecLineSounds.push_back(SMP_PY_WinPart_15);
    m_vecLineSounds.push_back(SMP_PY_WinPart_16);

    m_vecWinSounds.push_back(SMP_PY_WinVeryTiny);
    m_vecWinSounds.push_back(SMP_PY_WinTiny);
    m_vecWinSounds.push_back(SMP_PY_WinVerySmall);
    m_vecWinSounds.push_back(SMP_PY_WinSmall);
    m_vecWinSounds.push_back(SMP_PY_WinMediocre);
    m_vecWinSounds.push_back(SMP_PY_WinMedium);
    m_vecWinSounds.push_back(SMP_PY_WinBig);
    m_vecWinSounds.push_back(SMP_PY_WinHuge);
    m_vecWinSounds.push_back(SMP_PY_WinTop);

    m_vecReelStripPlan.push_back("pyW1A");
    m_vecReelStripPlan.push_back("pyW1B");
    m_vecReelStripPlan.push_back("pyW1C");
    m_vecReelStripPlan.push_back("pyW1D");
    m_vecReelStripPlan.push_back("pyW1E");

    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));

    char* pyReelStrip[] = {
        "KING_PY,ACE__PY,PHARAPY,QUEENPY,JACK_PY,KING_PY,ACE__PY,HORUSPY,JACK_PY,KING_PY,TEN__PY,ACE__PY,SCARAPY,KING_PY,QUEENPY,ACE__PY,JACK_PY,HORUSPY,KING_PY,ACE__PY,JACK_PY,KING_PY,HORUSPY,ACE__PY,JACK_PY,KING_PY,QUEENPY,ANUBIPY,ACE__PY,JACK_PY,QUEENPY,KING_PY,SCARAPY,JACK_PY,ACE__PY,TEN__PY,KING_PY,HORUSPY,JACK_PY,TEN__PY", // moved 3 to forwrad
        "QUEENPY,PHARAPY,JACK_PY,QUEENPY,SCARAPY,TEN__PY,ANUBIPY,KING_PY,SCARAPY,TEN__PY,ACE__PY,HORUSPY,TEN__PY,SCARAPY,QUEENPY,HORUSPY,TEN__PY,ANUBIPY,QUEENPY,KING_PY,JACK_PY,SCARAPY,TEN__PY,QUEENPY,ANUBIPY,ACE__PY,KING_PY,SCARAPY,TEN__PY,HORUSPY,JACK_PY,ACE__PY", // moved 2 to forwrad
        "PHARAPY,TEN__PY,KING_PY,QUEENPY,ANUBIPY,TEN__PY,JACK_PY,QUEENPY,HORUSPY,JACK_PY,TEN__PY,ACE__PY,SCARAPY,QUEENPY,KING_PY,TEN__PY,ANUBIPY,ACE__PY,JACK_PY,TEN__PY,HORUSPY,ACE__PY,TEN__PY,JACK_PY,SCARAPY,QUEENPY,TEN__PY,JACK_PY,ANUBIPY,TEN__PY,QUEENPY,JACK_PY", // moved 1 to forwrad
        "KING_PY,JACK_PY,ANUBIPY,KING_PY,SCARAPY,TEN__PY,HORUSPY,KING_PY,SCARAPY,KING_PY,JACK_PY,SCARAPY,ACE__PY,KING_PY,SCARAPY,KING_PY,ACE__PY,HORUSPY,ACE__PY,TEN__PY,HORUSPY,TEN__PY,ACE__PY,HORUSPY,ACE__PY,HORUSPY,TEN__PY,HORUSPY,QUEENPY,PHARAPY",
        "TEN__PY,TEN__PY,TEN__PY,TEN__PY,JACK_PY,JACK_PY,JACK_PY,JACK_PY,JACK_PY,QUEENPY,QUEENPY,QUEENPY,QUEENPY,QUEENPY,KING_PY,KING_PY,KING_PY,KING_PY,ACE__PY,ACE__PY,ACE__PY,ACE__PY,SCARAPY,SCARAPY,SCARAPY,HORUSPY,HORUSPY,HORUSPY,ANUBIPY,ANUBIPY,PHARAPY,TEN__PY", // moved 1 to back
        
        "ACE__PY,JACK_PY,PHARAPY,KING_PY,ACE__PY,TEN__PY,SCARAPY,QUEENPY,ACE__PY,HORUSPY,TEN__PY,QUEENPY,SCARAPY,ACE__PY,JACK_PY,HORUSPY,QUEENPY,KING_PY,ANUBIPY,ACE__PY,QUEENPY,SCARAPY,TEN__PY,ACE__PY,KING_PY,HORUSPY,QUEENPY,JACK_PY,SCARAPY,KING_PY,JACK_PY,HORUSPY,KING_PY,ACE__PY,TEN__PY,ANUBIPY,QUEENPY,ACE__PY,KING_PY,SCARAPY",
        "QUEENPY,PHARAPY,JACK_PY,KING_PY,TEN__PY,ANUBIPY,QUEENPY,HORUSPY,ACE__PY,KING_PY,ANUBIPY,JACK_PY,TEN__PY,SCARAPY,QUEENPY,ACE__PY,JACK_PY,SCARAPY,TEN__PY,KING_PY,JACK_PY,HORUSPY,ACE__PY,SCARAPY,KING_PY,QUEENPY,SCARAPY,ACE__PY,TEN__PY,HORUSPY,KING_PY,ACE__PY",
        "PHARAPY,QUEENPY,ACE__PY,TEN__PY,SCARAPY,QUEENPY,KING_PY,JACK_PY,HORUSPY,ACE__PY,TEN__PY,SCARAPY,KING_PY,ACE__PY,ANUBIPY,KING_PY,SCARAPY,TEN__PY,ACE__PY,JACK_PY,HORUSPY,KING_PY,QUEENPY,JACK_PY,SCARAPY,QUEENPY,KING_PY,ANUBIPY,ACE__PY,KING_PY,HORUSPY,JACK_PY",
        "JACK_PY,TEN__PY,SCARAPY,TEN__PY,KING_PY,SCARAPY,KING_PY,TEN__PY,SCARAPY,TEN__PY,KING_PY,SCARAPY,KING_PY,ACE__PY,HORUSPY,ACE__PY,QUEENPY,HORUSPY,QUEENPY,ACE__PY,HORUSPY,ACE__PY,TEN__PY,ANUBIPY,TEN__PY,QUEENPY,ANUBIPY,QUEENPY,TEN__PY,PHARAPY",
        "TEN__PY,TEN__PY,TEN__PY,TEN__PY,JACK_PY,JACK_PY,JACK_PY,JACK_PY,JACK_PY,QUEENPY,QUEENPY,QUEENPY,QUEENPY,QUEENPY,KING_PY,KING_PY,KING_PY,KING_PY,ACE__PY,ACE__PY,ACE__PY,ACE__PY,SCARAPY,SCARAPY,SCARAPY,HORUSPY,HORUSPY,HORUSPY,ANUBIPY,ANUBIPY,PHARAPY,TEN__PY",
       
        "KING_PY,ACE__PY,PHARAPY,QUEENPY,KING_PY,ACE__PY,ANUBIPY,KING_PY,JACK_PY,HORUSPY,TEN__PY,KING_PY,ACE__PY,QUEENPY,SCARAPY,JACK_PY,ACE__PY,QUEENPY,SCARAPY,JACK_PY,ACE__PY,KING_PY,TEN__PY,HORUSPY,JACK_PY,KING_PY,ANUBIPY,ACE__PY,JACK_PY,SCARAPY,QUEENPY,ACE__PY,KING_PY,JACK_PY,HORUSPY,TEN__PY,KING_PY,JACK_PY,HORUSPY,TEN__PY",
        "QUEENPY,PHARAPY,JACK_PY,KING_PY,TEN__PY,SCARAPY,QUEENPY,HORUSPY,ACE__PY,KING_PY,ANUBIPY,JACK_PY,TEN__PY,HORUSPY,QUEENPY,ACE__PY,JACK_PY,ANUBIPY,TEN__PY,KING_PY,JACK_PY,HORUSPY,TEN__PY,SCARAPY,KING_PY,QUEENPY,HORUSPY,ACE__PY,TEN__PY,SCARAPY,JACK_PY,ACE__PY",
        "PHARAPY,QUEENPY,SCARAPY,TEN__PY,KING_PY,ANUBIPY,JACK_PY,QUEENPY,PYRAMPY,JACK_PY,QUEENPY,ACE__PY,SCARAPY,QUEENPY,KING_PY,TEN__PY,HORUSPY,ACE__PY,ANUBIPY,TEN__PY,ACE__PY,HORUSPY,TEN__PY,KING_PY,SCARAPY,QUEENPY,ACE__PY,JACK_PY,HORUSPY,TEN__PY,KING_PY,JACK_PY",
        "JACK_PY,TEN__PY,SCARAPY,TEN__PY,KING_PY,SCARAPY,KING_PY,TEN__PY,SCARAPY,TEN__PY,KING_PY,SCARAPY,KING_PY,ACE__PY,HORUSPY,ACE__PY,QUEENPY,HORUSPY,QUEENPY,ACE__PY,HORUSPY,ACE__PY,TEN__PY,ANUBIPY,TEN__PY,QUEENPY,ANUBIPY,QUEENPY,TEN__PY,PHARAPY",
        "TEN__PY,TEN__PY,TEN__PY,TEN__PY,JACK_PY,JACK_PY,JACK_PY,JACK_PY,JACK_PY,QUEENPY,QUEENPY,QUEENPY,QUEENPY,QUEENPY,KING_PY,KING_PY,KING_PY,KING_PY,ACE__PY,ACE__PY,ACE__PY,ACE__PY,SCARAPY,SCARAPY,SCARAPY,HORUSPY,HORUSPY,HORUSPY,ANUBIPY,ANUBIPY,PHARAPY,TEN__PY",
        
        "ACE__PY,JACK_PY,PHARAPY,KING_PY,ACE__PY,TEN__PY,SCARAPY,QUEENPY,ACE__PY,TEN__PY,SCARAPY,QUEENPY,ACE__PY,KING_PY,JACK_PY,HORUSPY,QUEENPY,KING_PY,ANUBIPY,ACE__PY,QUEENPY,SCARAPY,TEN__PY,ACE__PY,KING_PY,QUEENPY,HORUSPY,JACK_PY,KING_PY,QUEENPY,HORUSPY,JACK_PY,KING_PY,ACE__PY,TEN__PY,SCARAPY,QUEENPY,ACE__PY,ANUBIPY,KING_PY",
        "QUEENPY,PHARAPY,JACK_PY,KING_PY,QUEENPY,HORUSPY,TEN__PY,KING_PY,SCARAPY,JACK_PY,ACE__PY,HORUSPY,TEN__PY,SCARAPY,QUEENPY,ACE__PY,TEN__PY,ANUBIPY,QUEENPY,KING_PY,JACK_PY,SCARAPY,TEN__PY,QUEENPY,ANUBIPY,ACE__PY,KING_PY,SCARAPY,JACK_PY,HORUSPY,TEN__PY,ACE__PY",
        "PHARAPY,QUEENPY,ACE__PY,TEN__PY,SCARAPY,QUEENPY,KING_PY,JACK_PY,HORUSPY,ACE__PY,TEN__PY,SCARAPY,KING_PY,TEN__PY,ANUBIPY,KING_PY,SCARAPY,TEN__PY,ACE__PY,JACK_PY,HORUSPY,KING_PY,QUEENPY,JACK_PY,PYRAMPY,QUEENPY,JACK_PY,ANUBIPY,ACE__PY,TEN__PY,HORUSPY,JACK_PY",
        "TEN__PY,JACK_PY,ANUBIPY,JACK_PY,TEN__PY,ANUBIPY,TEN__PY,KING_PY,SCARAPY,KING_PY,JACK_PY,SCARAPY,JACK_PY,KING_PY,SCARAPY,KING_PY,ACE__PY,HORUSPY,ACE__PY,TEN__PY,HORUSPY,TEN__PY,ACE__PY,HORUSPY,ACE__PY,TEN__PY,HORUSPY,TEN__PY,QUEENPY,PHARAPY",
        "TEN__PY,TEN__PY,TEN__PY,TEN__PY,JACK_PY,JACK_PY,JACK_PY,JACK_PY,JACK_PY,QUEENPY,QUEENPY,QUEENPY,QUEENPY,QUEENPY,KING_PY,KING_PY,KING_PY,KING_PY,ACE__PY,ACE__PY,ACE__PY,ACE__PY,SCARAPY,SCARAPY,SCARAPY,HORUSPY,HORUSPY,HORUSPY,ANUBIPY,ANUBIPY,PHARAPY,TEN__PY",
        
        "ACE__PY,JACK_PY,PHARAPY,KING_PY,ACE__PY,TEN__PY,SCARAPY,JACK_PY,TEN__PY,KING_PY,ACE__PY,PHARAPY,QUEENPY,JACK_PY,KING_PY,ACE__PY,HORUSPY,TEN__PY,KING_PY,ACE__PY,PHARAPY,QUEENPY,KING_PY,ACE__PY,ANUBIPY,KING_PY,SCARAPY,ACE__PY,JACK_PY,PHARAPY,KING_PY,ACE__PY,TEN__PY,SCARAPY,QUEENPY,ACE__PY,TEN__PY,SCARAPY,QUEENPY,ACE__PY,KING_PY,JACK_PY,HORUSPY,QUEENPY,KING_PY,ANUBIPY,ACE__PY,QUEENPY,SCARAPY,TEN__PY,ACE__PY,KING_PY,QUEENPY,HORUSPY,JACK_PY,KING_PY,TEN__PY,JACK_PY,QUEENPY,KING_PY,ACE__PY,TEN__PY,SCARAPY,QUEENPY,ACE__PY,ANUBIPY,KING_PY",
        "QUEENPY,PHARAPY,JACK_PY,KING_PY,QUEENPY,JACK_PY,ACE__PY,QUEENPY,PHARAPY,JACK_PY,QUEENPY,SCARAPY,KING_PY,ACE__PY,QUEENPY,PHARAPY,JACK_PY,KING_PY,TEN__PY,HORUSPY,KING_PY,TEN__PY,SCARAPY,JACK_PY,ACE__PY,HORUSPY,TEN__PY,SCARAPY,QUEENPY,ACE__PY,TEN__PY,ANUBIPY,QUEENPY,KING_PY,JACK_PY,SCARAPY,TEN__PY,QUEENPY,ANUBIPY,ACE__PY,KING_PY,SCARAPY,JACK_PY,HORUSPY,TEN__PY,ACE__PY",
        "PHARAPY,QUEENPY,ACE__PY,TEN__PY,KING_PY,ACE__PY,QUEENPY,JACK_PY,PHARAPY,TEN__PY,KING_PY,ACE__PY,HORUSPY,KING_PY,JACK_PY,PHARAPY,QUEENPY,SCARAPY,JACK_PY,QUEENPY,PYRAMPY,JACK_PY,QUEENPY,TEN__PY,SCARAPY,QUEENPY,KING_PY,JACK_PY,HORUSPY,ACE__PY,TEN__PY,SCARAPY,KING_PY,TEN__PY,ANUBIPY,KING_PY,SCARAPY,TEN__PY,ACE__PY,JACK_PY,HORUSPY,KING_PY,QUEENPY,JACK_PY,PYRAMPY,QUEENPY,JACK_PY,ANUBIPY,ACE__PY,TEN__PY,HORUSPY,JACK_PY",
        "TEN__PY,QUEENPY,PHARAPY,KING_PY,TEN__PY,PHARAPY,JACK_PY,TEN__PY,ANUBIPY,JACK_PY,TEN__PY,ANUBIPY,TEN__PY,KING_PY,SCARAPY,KING_PY,JACK_PY,SCARAPY,JACK_PY,KING_PY,SCARAPY,KING_PY,ACE__PY,HORUSPY,ACE__PY,TEN__PY,HORUSPY,TEN__PY,ACE__PY,HORUSPY,ACE__PY,TEN__PY,HORUSPY,TEN__PY,QUEENPY,PHARAPY",
        "JACK_PY,QUEENPY,KING_PY,ACE__PY,SCARAPY,HORUSPY,ANUBIPY,PHARAPY,TEN__PY",
    };

    int idx = 0;
    for (int i = 0; i < m_vecReelStripPlan.size(); i++) {
        ReelSet set;
        for (int j = 0; j < m_nReel; j++) {
            ReelStrip strip;
            std::stringstream ss(pyReelStrip[idx]);
            std::string item;
            while (std::getline(ss, item, ',')) {
                strip.push_back(item);
            }
            set.push_back(strip);
            idx++;
        }
        m_vecReelStripSets.push_back(set);
    }

    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_tmp;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        std::map<std::string, std::map<UINT8, BONUS>> perSym;
        std::map<UINT8, BONUS> e;
        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[5].ag = 0;
        perSym["TEN__PY"] = e;

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[5].ag = 0;
        perSym["JACK_PY"] = e;

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[5].ag = 0;
        perSym["QUEENPY"] = e;

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 40; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 150; e[5].ag = 0;
        perSym["KING_PY"] = e;

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 40; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 150; e[5].ag = 0;
        perSym["ACE__PY"] = e;

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 250; e[5].ag = 0;
        perSym["SCARAPY"] = e;

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 250; e[5].ag = 0;
        perSym["HORUSPY"] = e;

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 150; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 500; e[5].ag = 0;
        perSym["ANUBIPY"] = e;

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 500; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 2000; e[5].ag = 0;
        perSym["PHARAPY"] = e;

        e.clear();
        m_Bonus_tmp[i] = perSym;
    }

    int nSavedBetVal = 10;
    int _line = 0;
    string data;
    PlayDB::GetInstance().LoadCheckPoint(m_strGameName, nSavedBetVal, _line, m_strCheckPoint);
    if (nSavedBetVal == -1) {
        nSavedBetVal = 10;
    }

    BOOL start = FALSE;
    idx = 0;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_tmp, i) < AT(m_vecBetSteps, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps, idx) == nSavedBetVal) {
            m_nBetStep = idx;
        }

        m_Bonus[idx++] = m_Bonus_tmp[i];
        if (AT(m_vecBetSteps_tmp, i) == AT(m_vecBetSteps, m_vecBetSteps.size() - 1)) {
            break;
        }
    }

    m_vecBetSteps_05.clear();
    m_vecBetSteps_10.clear();
    PrintAllBonus();
}

UINT16 RgPyramidOfPower::Run() {
    m_nCurrentReelPlan = (2 + (myRandom() % 3));
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));
    return m_shCurrentReelStrip;
}

myVector<UINT8> RgPyramidOfPower::Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) {
    myVector<UINT8> result;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    
    BOOL mmcode = FALSE;
    if (bTest == FALSE) {
        mmcode = mmcode_get_active_status();
    }
    if (bTest == TRUE || mmcode == TRUE) {
        std::string matchSymbol = AT(m_vecSymbols, myRandom() % (m_vecSymbols.size() - 1));
        int line = (myRandom() % m_nWinLine);
        int weight = 1 + (myRandom() % 5);

        if (mmcode
#ifdef TEST_WILD
            && 0
#endif
            ) {
            mmcode_set_deactive();
            weight = m_nMaxMatch;
            matchSymbol = "ANUBIPY";
        }
        for (int i = 0; i < m_nReel; i++) {
            ReelStrip reelStrip = AT(reelSet, i);

            int movedFromBack = 0;
            const int movedMap[] = { 3, 2, 1 };
            if (i >= 0 && i < 3) {
                movedFromBack = movedMap[i];
            }

            int len = reelStrip.size() - (5 - i) - movedFromBack - 2;

            int valid_i[0x100];
            int valid_count = 0;
            for (int j = 0; j <= len; j++) {
                if (weight > i) {
                    if (matchSymbol == AT(reelStrip, j + g_match_lines_pyramid[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                else {
                    if (matchSymbol != AT(reelStrip, j + g_match_lines_pyramid[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
            }
            if (valid_count > 0) {
                int rand_index = myRandom() % valid_count;
                int chosen_i = valid_i[rand_index];
                result.push_back(chosen_i + 1);
            }
            else {
                result.push_back((myRandom() % (len - 1)) + 1);
            }
        }

        if ((myRandom() % 3) == 0) {
            // force wild
            ReelStrip reelStrip = AT(reelSet, 2);
            int movedFromBack = 0;
            const int movedMap[] = { 3, 2, 1 };
            movedFromBack = movedMap[2];
            int len = reelStrip.size() - (5 - /*i*/2) - movedFromBack - 2;

            for (int j = 0; j <= len; j++) {
                if (AT(reelStrip, j) == RgPyramidOfPower_wild) {
                    int r = myRandom() % 100;
                    if (r < 33) {
                        AT(result, 2) = j + 1;
                    }
                    else if (r < 66) {
                        AT(result, 2) = j;
                    }
                    else {
                        AT(result, 2) = j - 1;
                    }
                    break;
                }
            }
        }
    }
    else {
        result = _result;
#if 0
        int percent = 0;
        auto& playDB = PlayDB::GetInstance();
		auto variant = playDB.GetGameVariant();
        if (variant == VARIANT_HIGH) {
            percent = 1;
        }
        else if (variant == VARIANT_MIDDLE) {
            percent = 1;
        }
#ifdef TEST_WILD
        if ((myRandom() % 100) < 90) {
#else
        if ((myRandom() % 100) < 1) {
#endif
            // force wild
            ReelStrip reelStrip = AT(reelSet, 2);
            int movedFromBack = 0;
            const int movedMap[] = { 3, 2, 1 };
            movedFromBack = movedMap[2];
            int len = reelStrip.size() - (5 - /*i*/2) - movedFromBack - 2;

            for (int j = 0; j <= len; j++) {
                if (AT(reelStrip, j) == RgPyramidOfPower_wild) {
#ifdef TEST_WILD
                    int tmp = (myRandom() % 3);
                    if (tmp == 0) {
                        AT(result, 2) = j;
                    }
                    else if (tmp == 1) {
                        AT(result, 2) = j + 1;
                    }
                    else {
                        AT(result, 2) = j - 1;
                    }
#else
                    AT(result, 2) = (myRandom() & 1) ?  (j + 1) : (j - 1);
#endif
                    break;
                }
            }
        }
#endif
    }

    m_vWinResult = result;
    SetWildPos();

    normalMeter = 0;
    maxMeter = 0;
    UINT32 totalBonus = 0;
    for (int i = 0; i < m_nWinLine; i++) {
        int j = 1;
        UINT16 meter = ((UINT16)1 << (4 - g_match_lines_pyramid[i][0]));
        std::string firstSymbol = AT(AT(reelSet, 0), AT(result, 0) - 1 + g_match_lines_pyramid[i][0]);

        if (IsWild(0, g_match_lines_pyramid[i][0])) {
            firstSymbol = RgPyramidOfPower_wild;
        }

        for (; j < m_nMaxMatch; j++) {
            std::string prev_symbol = AT(AT(reelSet, j - 1), AT(result, j - 1) - 1 + g_match_lines_pyramid[i][j - 1]);
            std::string cur_symbol = AT(AT(reelSet, j), AT(result, j) - 1 + g_match_lines_pyramid[i][j]);

            int cur_reel = j;
            int cur_row = g_match_lines_pyramid[i][j];

            if (firstSymbol == RgPyramidOfPower_wild) {
                firstSymbol = cur_symbol;
            }
            int sum = 0;
            int num = 5 - j;
            for (int padding = num + 1; padding <= 5; padding++) {
                sum += padding;
            }

            if (firstSymbol == cur_symbol || IsWild(cur_reel, cur_row)) {
                meter |= ((UINT16)1 << (sum + (num - 1) - g_match_lines_pyramid[i][j]));
                continue;
            }
            break;
        }
        if (j < m_mapSymbolMinMatch[firstSymbol]) {
            continue;
        }

        // monitor 2 meter
        std::string meterStr = m_mapSymbolMeterGoc[firstSymbol];
        size_t pos = meterStr.find('$');
        if (pos != std::string::npos) {
            meterStr = meterStr.replace(pos, 1, std::to_string(j));
        }

        WinMeter e;
        e.line = i;
        e.meter = meter;
        e.meter2 = g_GrafficObjList.Str2GOCID(meterStr);
        e.symbol = firstSymbol;
        e.weight = j;
        e.start = 0;
        e.bonus = m_Bonus[BetStep()][firstSymbol][j];
        e.sound = MAX_SOUND_IDS;

        totalBonus += e.bonus.coin;

        meters.push_back(e);
        if (j == m_nMaxMatch) {
            maxMeter |= meter;
        }
        else {
            normalMeter |= meter;
        }
    }
    
    if (totalBonus > 0) {
        BonusSound = getSoundByID(WinSound(totalBonus));
    }
    else {
        BonusSound.duration = 0;
        BonusSound.soundID = MAX_SOUND_IDS;
    }
    return result;
}

BOOL RgPyramidOfPower::IsWild(int cur_reel, int cur_row) {
    if (!WildExist()) {
        return FALSE;
    }

    if (cur_reel == m_nExtrWildReel && cur_row == m_nExtrWildRow) {
        return TRUE;
    }
    int w_reel = -1;
    int w_row = -1;

    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int reel = 0; reel < 5; reel++) {
        int rowCont = 5 - reel;
        for (int row = 0; row < rowCont; row++) {
            std::string s = AT(AT(reelSet, reel), AT(m_vWinResult, reel) - 1 + row);
            if (s == RgPyramidOfPower_wild) {
                w_reel = reel;
                w_row = row;
                break;
            }
        }
        if (w_reel != -1 && w_row != -1) {
            break;
        }
    }
    if (cur_reel == w_reel && cur_row == w_row) {
        return TRUE;
    }
    if (cur_reel == (w_reel - 1) && (cur_row == w_row || cur_row == (w_row + 1))) {
        return TRUE;
    }
    return FALSE;
}

UINT16 RgPyramidOfPower::SpinTime_MS() {
    if (WildExist()) {
        return 5200;
    }
    return 1800;
}

int RgPyramidOfPower::LineSwapDelay(int WinIdx) {
    return 600;
}

BOOL RgPyramidOfPower::WildExist() {
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    int reel = 2;
    int rowCont = 3;
    for (int row = 0; row < rowCont; row++) {
        std::string s = AT(AT(reelSet, reel), AT(m_vWinResult, reel) - 1 + row);
        if (s == RgPyramidOfPower_wild) {
            return TRUE;
        }
    }
    return FALSE;
}

// 0x33: top, 0x2a: right or left
void RgPyramidOfPower::SetWildPos() {
    m_vecAdditionalParam.clear();
    if (!WildExist()) {
        m_vecAdditionalParam.push_back(0x00);
        return;
    }
    // (2, 0)
    if (IsWild(2, 0) || IsWild(2, 1)) {
        m_vecAdditionalParam.push_back(((myRandom() % 5) == 0) ? 0x2A : 0x33);
        if (AT(m_vecAdditionalParam, 0) == 0x2A) {
            m_nExtrWildReel = 3;
            m_nExtrWildRow = 0;
        }
    }
    else if (IsWild(2, 2)) {
        m_vecAdditionalParam.push_back((myRandom() & 1) ? 0x33 : 0x33);
        if (AT(m_vecAdditionalParam, 0) == 0x2A) {
            m_nExtrWildReel = 3;
            m_nExtrWildRow = 1;
        }
    }
    if (AT(m_vecAdditionalParam, 0) == 0x33) {
        m_nExtrWildReel = 4;
        m_nExtrWildRow = 0;
    }
}

myVector<UINT8> RgPyramidOfPower::ShowTotalWinLines(myVector<WinMeter> SpinMeters) {
    myVector<uint8_t> packet = {
        0x06, 0x30, 0x59, 0x01, 0x02, 0x31, 0x00,
        0x0F, 0x00,  // Placeholder for length 
        0x0F, 0x11, // GameID
        0x9C, 0x19, 0x01
    };
    myVector<UINT8> TotalMatch;
    for (int i = 0; i < SpinMeters.size(); i++) {
        if (AT(SpinMeters, i).line == 0xFF) { // clear after convert action
            continue;
        }
        TotalMatch.push_back(AT(SpinMeters, i).line);
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter >> 8) & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter2 & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter2 >> 8) & 0xFF));
    }
    if (TotalMatch.size() < 10) {
        myVector<UINT8> _;
        return _;
    }
    UINT16 pktLen = 1 + (TotalMatch.size() / 5) * 7;
    AT(packet, 7) = static_cast<BYTE>(pktLen & 0xFF);
    AT(packet, 8) = static_cast<BYTE>((pktLen >> 8) & 0xFF);
    AT(packet, 9) = static_cast<BYTE>(m_nGameID & 0xFF);
    AT(packet, 10) = static_cast<BYTE>((m_nGameID >> 8) & 0xFF);
    int entryCount = static_cast<int>(TotalMatch.size() / 5);
    for (int i = 0; i < entryCount; ++i) {
        packet.push_back(AT(TotalMatch, i * 5 + 0)); // Line
        packet.push_back(AT(TotalMatch, i * 5 + 1)); // Meter low byte
        packet.push_back(AT(TotalMatch, i * 5 + 2)); // Meter high byte
        packet.push_back(AT(TotalMatch, i * 5 + 3)); // Meter2 low byte
        packet.push_back(AT(TotalMatch, i * 5 + 4)); // Meter2 high byte
        packet.push_back(0x01);      // Status or flag 1
        packet.push_back(0x01);      // Status or flag 2
    }
    // Mark the end of the packet
    packet.back() = 0x04;
    return packet;
}

bool RgPyramidOfPower::RTP_force_bigWin() {
    return (myRandom() % 80 == 0);
}
