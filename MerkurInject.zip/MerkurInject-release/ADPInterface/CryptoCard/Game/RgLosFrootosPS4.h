#pragma once

#include "ReelGame.h"

class RgLosFrootosPS4 : public ReelGame
{
public:
	myVector<WinMeter> m_vWinMeters;

	RgLosFrootosPS4::RgLosFrootosPS4();

	UINT16 Init(UINT8 betStep);
	myVector<UINT8> Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) override;
	myVector<InterruptPacketData> InterruptAfterSpin() override;
	void ChangeReelStrip(UINT16 NewReelPlan) override;

	std::string m_TransSymbol;
	UINT16 GetTransSymbolGOC();
};
