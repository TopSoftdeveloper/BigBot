#include "stdafx.h"
#include "RgIndianRuby.h"

#define RgIndianRuby_scatter "iruRUBY____"
#define RgIndianRuby_ele "iruELEPHANT"

#define RgIndianRuby_MP_ChangeLine_LB_x_reel   0x03
#define RgIndianRuby_MP_ChangeLine_LB_x_pos    0x27
#define RgIndianRuby_MP_ChangeLine_LB_y_row    0x02
#define RgIndianRuby_MP_ChangeLine_LB_y_pos    0x18
#define RgIndianRuby_MP_ChangeLine_RT_x_reel   0x03
#define RgIndianRuby_MP_ChangeLine_RT_x_pos    0x62
#define RgIndianRuby_MP_ChangeLine_RT_y_row    0x02
#define RgIndianRuby_MP_ChangeLine_RT_y_pos    0x4F

RgIndianRuby::RgIndianRuby() {
    m_nReel = 5;
    m_nWinLine = 5;
    m_nMaxMatch = 5;
    m_nBetStep = 0;

    m_strGameName = "RgIndianRuby";

    m_bFreeMode = FALSE;
    myVector<UINT16> m_vecBetSteps_05_tmp;
    myVector<UINT16> m_vecBetSteps_10_tmp;

    m_vecBetSteps_05_tmp.push_back(5);
    m_vecBetSteps_05_tmp.push_back(10);
    m_vecBetSteps_05_tmp.push_back(20);
    m_vecBetSteps_05_tmp.push_back(30);
    m_vecBetSteps_05_tmp.push_back(40);
    m_vecBetSteps_05_tmp.push_back(50);
    m_vecBetSteps_05_tmp.push_back(60);
    m_vecBetSteps_05_tmp.push_back(80);
    m_vecBetSteps_05_tmp.push_back(100);

    m_vecBetSteps_10_tmp.push_back(10);
    m_vecBetSteps_10_tmp.push_back(20);
    m_vecBetSteps_10_tmp.push_back(40);
    m_vecBetSteps_10_tmp.push_back(60);
    m_vecBetSteps_10_tmp.push_back(80);
    m_vecBetSteps_10_tmp.push_back(100);
    m_vecBetSteps_10_tmp.push_back(120);
    m_vecBetSteps_10_tmp.push_back(160);
    m_vecBetSteps_10_tmp.push_back(200);
#ifdef BIGBET_ACTIVE
    m_vecBetSteps_05_tmp.push_back(200);
    m_vecBetSteps_05_tmp.push_back(500);
    m_vecBetSteps_10_tmp.push_back(400);
    m_vecBetSteps_10_tmp.push_back(1000);
#endif
    LoadBets();

    m_vecBetSteps = m_vecBetSteps_05;

    m_vecSymbols.push_back("iruELEPHANT");
    m_vecSymbols.push_back("iruNECKLACE");
    m_vecSymbols.push_back("iruSPICES__");
    m_vecSymbols.push_back("iruJUG_____");
    m_vecSymbols.push_back("iruA_______");
    m_vecSymbols.push_back("iruK_______");
    m_vecSymbols.push_back("iruQ_______");
    m_vecSymbols.push_back("iruJ_______");
    m_vecSymbols.push_back("iruTEN_____");

    m_vecSymbols.push_back("iruRUBY____");

    m_mapSymbolMinMatch["iruELEPHANT"] = 2;
    m_mapSymbolMinMatch["iruNECKLACE"] = 3;
    m_mapSymbolMinMatch["iruSPICES__"] = 3;
    m_mapSymbolMinMatch["iruJUG_____"] = 3;
    m_mapSymbolMinMatch["iruA_______"] = 3;
    m_mapSymbolMinMatch["iruK_______"] = 3;
    m_mapSymbolMinMatch["iruQ_______"] = 3;
    m_mapSymbolMinMatch["iruJ_______"] = 3;
    m_mapSymbolMinMatch["iruTEN_____"] = 3;

    m_mapSymbolMeterGoc["iruELEPHANT"] = "iruTop$x";
    m_mapSymbolMeterGoc["iruNECKLACE"] = "iruHV_$x";
    m_mapSymbolMeterGoc["iruSPICES__"] = "iruLV_$x";
    m_mapSymbolMeterGoc["iruJUG_____"] = "iruLV_$x";
    m_mapSymbolMeterGoc["iruA_______"] = "iruHR_$x";
    m_mapSymbolMeterGoc["iruK_______"] = "iruHR_$x";
    m_mapSymbolMeterGoc["iruQ_______"] = "iruLR_$x";
    m_mapSymbolMeterGoc["iruJ_______"] = "iruLR_$x";
    m_mapSymbolMeterGoc["iruTEN_____"] = "iruLR_$x";

    m_vecWinLines.push_back("iruWinline1");
    m_vecWinLines.push_back("iruWinline2");
    m_vecWinLines.push_back("iruWinline3");
    m_vecWinLines.push_back("iruWinline4");
    m_vecWinLines.push_back("iruWinline5");
    m_vecWinLines.push_back("iruWinline6");
    m_vecWinLines.push_back("iruWinline7");
    m_vecWinLines.push_back("iruWinline8");
    m_vecWinLines.push_back("iruWinline9");
    m_vecWinLines.push_back("iruWinline10");

    m_vecLineSounds.push_back(SMP_IRuWinStep1);
    m_vecLineSounds.push_back(SMP_IRuWinStep2);
    m_vecLineSounds.push_back(SMP_IRuWinStep3);
    m_vecLineSounds.push_back(SMP_IRuWinStep4);
    m_vecLineSounds.push_back(SMP_IRuWinStep5);
    m_vecLineSounds.push_back(SMP_IRuWinStep6);
    m_vecLineSounds.push_back(SMP_IRuWinStep7);
    m_vecLineSounds.push_back(SMP_IRuWinStep8);
    m_vecLineSounds.push_back(SMP_IRuWinStep9);
    m_vecLineSounds.push_back(SMP_IRuWinStep10);

    m_vecWinSounds.push_back(SMP_IRuWin1);
    m_vecWinSounds.push_back(SMP_IRuWin2);
    m_vecWinSounds.push_back(SMP_IRuWin3);
    m_vecWinSounds.push_back(SMP_IRuWin4);
    m_vecWinSounds.push_back(SMP_IRuWin5);
    m_vecWinSounds.push_back(SMP_IRuWin6);
    m_vecWinSounds.push_back(SMP_IRuWin7);
    m_vecWinSounds.push_back(SMP_IRuWin8);
    m_vecWinSounds.push_back(SMP_IRuWin9);
    m_vecWinSounds.push_back(SMP_IRuWin10);

    m_vecEWinSounds.push_back(SMP_IRuEWin1);
    m_vecEWinSounds.push_back(SMP_IRuEWin2);
    m_vecEWinSounds.push_back(SMP_IRuEWin3);
    m_vecEWinSounds.push_back(SMP_IRuEWin4);
    m_vecEWinSounds.push_back(SMP_IRuEWin5);
    m_vecEWinSounds.push_back(SMP_IRuEWin6);
    m_vecEWinSounds.push_back(SMP_IRuEWin7);
    m_vecEWinSounds.push_back(SMP_IRuEWin8);
    m_vecEWinSounds.push_back(SMP_IRuEWin9);
    m_vecEWinSounds.push_back(SMP_IRuEWin10);

    m_vecReelStripPlan.push_back("0");
    m_vecReelStripPlan.push_back("1");
    m_vecReelStripPlan.push_back("2");
    m_vecReelStripPlan.push_back("3");
    m_vecReelStripPlan.push_back("4");
    m_vecReelStripPlan.push_back("5");
    
    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));

    char* iruReelStrip[] = {
        "iruELEPHANT,iruTEN_____,iruJ_______,iruSPICES__,iruQ_______,iruK_______,iruJ_______,iruSPICES__,iruQ_______,iruTEN_____,iruJ_______,iruQ_______,iruTEN_____,iruJUG_____,iruJ_______,iruA_______,iruTEN_____,iruJ_______,iruNECKLACE,iruQ_______,iruTEN_____,iruJ_______,iruQ_______",
        "iruELEPHANT,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGA______,iruGK______,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGNECKLAC,iruGJ______,iruELEPHANT,iruGJUG____,iruGK______,iruELEPHANT,iruGJ______,iruGA______,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGTEN____,iruGNECKLAC,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGQ______,iruGTEN____,iruELEPHANT,iruELEPHANT,iruGJ______,iruGTEN____,iruELEPHANT,iruGSPICES_,iruGQ______,iruELEPHANT,iruGTEN____,iruGA______,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGNECKLAC,iruGK______,iruELEPHANT,iruGJUG____,iruGQ______,iruELEPHANT,iruGJ______,iruGTEN____,iruELEPHANT,iruELEPHANT,iruGSPICES_,iruGK______,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGSPICES_,iruGA______,iruELEPHANT,iruGJUG____,iruGQ______",
        "iruELEPHANT,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGTEN____,iruGK______,iruGJUG____,iruGJ______,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGA______,iruGQ______,iruELEPHANT,iruELEPHANT,iruGK______,iruGSPICES_,iruGJ______,iruELEPHANT,iruGK______,iruGNECKLAC,iruGTEN____,iruELEPHANT,iruGA______,iruGQ______,iruGNECKLAC,iruGJ______,iruGSPICES_,iruGK______,iruGA______,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGTEN____,iruGQ______,iruELEPHANT,iruELEPHANT,iruGJ______,iruGJUG____,iruGNECKLAC,iruELEPHANT,iruELEPHANT,iruGTEN____,iruGSPICES_,iruGQ______,iruGJUG____,iruGA______,iruELEPHANT,iruELEPHANT,iruGTEN____",
        "iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGTEN____,iruGQ______,iruELEPHANT,iruGSPICES_,iruGJ______,iruELEPHANT,iruGA______,iruGQ______,iruELEPHANT,iruGJUG____,iruGTEN____,iruELEPHANT,iruGQ______,iruGJ______,iruELEPHANT,iruGK______,iruGQ______,iruELEPHANT,iruGNECKLAC,iruGJ______,iruELEPHANT,iruGTEN____,iruGK______,iruELEPHANT,iruGA______,iruGJUG____,iruELEPHANT,iruGA______,iruGTEN____,iruELEPHANT,iruGK______,iruGNECKLAC,iruGJ______,iruGTEN____,iruELEPHANT,iruELEPHANT,iruGQ______,iruGJUG____,iruGJ______,iruGSPICES_,iruGK______,iruGA______",
        "iruELEPHANT,iruJ_______,iruK_______,iruNECKLACE,iruTEN_____,iruQ_______,iruJUG_____,iruA_______,iruK_______,iruNECKLACE,iruQ_______,iruTEN_____,iruSPICES__,iruK_______,iruJ_______,iruJUG_____,iruA_______,iruTEN_____,iruSPICES__,iruJ_______,iruQ_______,iruNECKLACE,iruA_______,iruJ_______,iruJUG_____,iruK_______,iruTEN_____,iruSPICES__,iruA_______,iruQ_______",
        "iruELEPHANT,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGA______,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGNECKLAC,iruGK______,iruGTEN____,iruELEPHANT,iruELEPHANT,iruGSPICES_,iruGQ______,iruELEPHANT,iruGJ______,iruELEPHANT,iruGJUG____",

        "iruRUBY____,iruJ_______,iruQ_______,iruSPICES__,iruTEN_____,iruA_______,iruK_______,iruJUG_____,iruA_______,iruTEN_____,iruELEPHANT,iruJ_______,iruQ_______,iruK_______,iruTEN_____,iruJ_______,iruJUG_____,iruA_______,iruK_______,iruTEN_____,iruNECKLACE,iruJ_______,iruTEN_____,iruQ_______,iruJ_______,iruK_______,iruQ_______,iruNECKLACE,iruTEN_____,iruA_______,iruJUG_____,iruK_______,iruTEN_____,iruJ_______,iruA_______,iruQ_______,iruNECKLACE,iruTEN_____,iruK_______,iruA_______,iruNECKLACE,iruJ_______,iruQ_______,iruA_______,iruK_______,iruJUG_____,iruQ_______,iruJ_______,iruK_______,iruA_______",
        "iruELEPHANT,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGQ______,iruGSPICES_,iruELEPHANT,iruGA______,iruGNECKLAC,iruRUBY____,iruGK______,iruGJ______,iruELEPHANT,iruELEPHANT,iruGJUG____,iruGNECKLAC,iruELEPHANT,iruGA______,iruGK______,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGJ______,iruGTEN____,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGSPICES_,iruGA______,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGK______,iruGJ______,iruELEPHANT,iruELEPHANT,iruGTEN____,iruGJUG____,iruELEPHANT,iruELEPHANT,iruGSPICES_,iruGQ______,iruELEPHANT,iruRUBY____,iruELEPHANT,iruELEPHANT,iruGQ______,iruGTEN____,iruELEPHANT,iruELEPHANT,iruGNECKLAC,iruGK______,iruRUBY____,iruGJ______,iruGTEN____,iruELEPHANT,iruELEPHANT,iruGJUG____,iruGQ______",
        "iruELEPHANT,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGNECKLAC,iruGA______,iruELEPHANT,iruGK______,iruGJUG____,iruELEPHANT,iruGQ______,iruGA______,iruELEPHANT,iruELEPHANT,iruGK______,iruGTEN____,iruRUBY____,iruGA______,iruGNECKLAC,iruGTEN____,iruELEPHANT,iruELEPHANT,iruGK______,iruGQ______,iruRUBY____,iruGJ______,iruGTEN____,iruELEPHANT,iruGJUG____,iruGK______,iruELEPHANT,iruELEPHANT,iruGSPICES_,iruGJ______,iruELEPHANT,iruELEPHANT,iruGNECKLAC,iruGJ______,iruELEPHANT,iruGJUG____,iruGQ______,iruELEPHANT,iruGJ______,iruGTEN____,iruELEPHANT,iruGQ______,iruGSPICES_,iruELEPHANT,iruELEPHANT,iruGA______,iruGSPICES_,iruGTEN____",
        "iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGA______,iruGJUG____,iruGTEN____,iruELEPHANT,iruGQ______,iruGJ______,iruELEPHANT,iruGK______,iruGTEN____,iruELEPHANT,iruGA______,iruGNECKLAC,iruGQ______,iruELEPHANT,iruGJ______,iruGSPICES_,iruGK______,iruELEPHANT,iruELEPHANT,iruGTEN____,iruGA______,iruGJUG____,iruGK______,iruGQ______,iruGSPICES_,iruGTEN____,iruGK______,iruELEPHANT,iruELEPHANT,iruGQ______,iruGJUG____,iruGJ______,iruGK______,iruELEPHANT,iruELEPHANT,iruGA______,iruGNECKLAC,iruGTEN____,iruELEPHANT,iruGJ______,iruGA______,iruELEPHANT",
        "iruRUBY____,iruJ_______,iruTEN_____,iruNECKLACE,iruK_______,iruQ_______,iruSPICES__,iruJ_______,iruTEN_____,iruJUG_____,iruA_______,iruK_______,iruELEPHANT,iruJ_______,iruQ_______,iruSPICES__,iruTEN_____,iruK_______,iruNECKLACE,iruA_______,iruQ_______,iruJUG_____,iruJ_______,iruK_______,iruSPICES__,iruTEN_____,iruA_______,iruJUG_____,iruQ_______,iruA_______",
        "iruELEPHANT,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruRUBY____,iruELEPHANT,iruELEPHANT,iruGA______,iruGNECKLAC,iruGK______,iruELEPHANT,iruGTEN____,iruGSPICES_,iruELEPHANT,iruGQ______,iruGJUG____,iruRUBY____,iruGJ______",

        "iruRUBY____,iruA_______,iruK_______,iruNECKLACE,iruA_______,iruK_______,iruSPICES__,iruQ_______,iruJ_______,iruJUG_____,iruA_______,iruNECKLACE,iruK_______,iruJUG_____,iruA_______,iruSPICES__,iruK_______,iruJUG_____,iruA_______,iruNECKLACE,iruK_______,iruJUG_____,iruTEN_____,iruA_______,iruSPICES__,iruK_______,iruELEPHANT,iruTEN_____,iruNECKLACE,iruQ_______,iruSPICES__,iruK_______,iruJUG_____,iruJ_______,iruNECKLACE,iruA_______,iruK_______",
        "iruELEPHANT,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGK______,iruGJUG____,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGTEN____,iruGSPICES_,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGJUG____,iruGJ______,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGTEN____,iruGNECKLAC,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGSPICES_,iruGQ______,iruELEPHANT,iruGK______,iruGNECKLAC,iruRUBY____,iruGA______,iruGK______,iruELEPHANT,iruELEPHANT,iruGJ______,iruGTEN____,iruELEPHANT,iruGJUG____,iruGA______,iruRUBY____,iruGQ______,iruGTEN____,iruELEPHANT,iruELEPHANT,iruGJ______,iruGNECKLAC,iruELEPHANT,iruGA______,iruGSPICES_,iruELEPHANT,iruGQ______,iruGJ______,iruELEPHANT,iruRUBY____,iruELEPHANT,iruGK______,iruGQ______",
        "iruELEPHANT,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGJ______,iruGNECKLAC,iruGA______,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGK______,iruGQ______,iruELEPHANT,iruELEPHANT,iruGK______,iruGJUG____,iruGJ______,iruGTEN____,iruGNECKLAC,iruGK______,iruGQ______,iruGSPICES_,iruGTEN____,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGJ______,iruGJUG____,iruRUBY____,iruGTEN____,iruGA______,iruELEPHANT,iruGSPICES_,iruGQ______,iruELEPHANT,iruELEPHANT,iruGJ______,iruGSPICES_,iruELEPHANT,iruGA______,iruGTEN____,iruRUBY____,iruGJUG____,iruGQ______,iruELEPHANT,iruELEPHANT,iruGTEN____,iruGK______,iruGNECKLAC,iruGA______",
        "iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGA______,iruGNECKLAC,iruGJ______,iruGSPICES_,iruGK______,iruGTEN____,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGJUG____,iruGA______,iruELEPHANT,iruELEPHANT,iruGK______,iruGQ______,iruELEPHANT,iruELEPHANT,iruGJ______,iruGTEN____,iruELEPHANT,iruGA______,iruGJUG____,iruGQ______,iruELEPHANT,iruELEPHANT,iruGK______,iruGQ______,iruELEPHANT,iruGTEN____,iruGSPICES_,iruELEPHANT,iruGJ______,iruGTEN____,iruELEPHANT,iruELEPHANT,iruGA______,iruGK______,iruELEPHANT,iruGQ______,iruGJUG____,iruELEPHANT,iruGQ______,iruGK______,iruELEPHANT,iruELEPHANT,iruGTEN____,iruGNECKLAC,iruGJ______",
        "iruRUBY____,iruQ_______,iruK_______,iruJUG_____,iruJ_______,iruTEN_____,iruA_______,iruSPICES__,iruK_______,iruJ_______,iruJUG_____,iruTEN_____,iruA_______,iruELEPHANT,iruQ_______,iruNECKLACE,iruK_______,iruJ_______,iruJUG_____,iruTEN_____,iruA_______,iruSPICES__,iruQ_______,iruA_______,iruNECKLACE,iruQ_______,iruJ_______,iruSPICES__,iruTEN_____,iruK_______",
        "iruELEPHANT,iruELEPHANT,iruELEPHANT,iruRUBY____,iruGJ______,iruELEPHANT,iruELEPHANT,iruGNECKLAC,iruGK______,iruELEPHANT,iruELEPHANT,iruRUBY____,iruELEPHANT,iruELEPHANT,iruGJUG____,iruGTEN____,iruELEPHANT,iruGA______,iruGSPICES_,iruGQ______",

        "iruRUBY____,iruA_______,iruJ_______,iruNECKLACE,iruK_______,iruTEN_____,iruA_______,iruQ_______,iruJ_______,iruJUG_____,iruK_______,iruTEN_____,iruNECKLACE,iruA_______,iruQ_______,iruJUG_____,iruK_______,iruJ_______,iruSPICES__,iruTEN_____,iruA_______,iruQ_______,iruJ_______,iruK_______,iruJUG_____,iruTEN_____,iruQ_______,iruK_______,iruA_______,iruJ_______,iruSPICES__,iruTEN_____,iruQ_______",
        "iruGNECKLAC,iruGA______,iruGTEN____,iruGSPICES_,iruGJ______,iruGK______,iruGJUG____,iruGQ______,iruGA______,iruGSPICES_,iruGTEN____,iruGK______,iruGJUG____,iruGQ______,iruGJ______",
        "iruELEPHANT,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGSPICES_,iruGTEN____,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGA______,iruGJ______,iruRUBY____,iruGK______,iruGJUG____,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGK______,iruGQ______,iruELEPHANT,iruELEPHANT,iruGTEN____,iruGNECKLAC,iruELEPHANT,iruGQ______,iruGJ______",
        "iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGTEN____,iruGNECKLAC,iruELEPHANT,iruGA______,iruGK______,iruELEPHANT,iruELEPHANT,iruGQ______,iruGA______,iruELEPHANT,iruGJUG____,iruGK______,iruELEPHANT,iruGJ______,iruGTEN____,iruELEPHANT,iruGSPICES_,iruGQ______,iruELEPHANT,iruGA______,iruGTEN____,iruELEPHANT,iruGJ______,iruGQ______,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGK______,iruGJUG____,iruELEPHANT,iruGQ______,iruGJ______,iruELEPHANT,iruELEPHANT,iruGTEN____,iruGA______,iruELEPHANT,iruGK______,iruGQ______,iruELEPHANT,iruGJ______,iruGA______,iruELEPHANT,iruGTEN____,iruGK______,iruELEPHANT,iruELEPHANT,iruGA______,iruGJ______",
        "iruRUBY____,iruQ_______,iruTEN_____,iruNECKLACE,iruK_______,iruJ_______,iruELEPHANT,iruA_______,iruTEN_____,iruSPICES__,iruQ_______,iruA_______,iruNECKLACE,iruK_______,iruJ_______,iruJUG_____,iruQ_______,iruTEN_____,iruSPICES__,iruJ_______",
        "iruELEPHANT,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGTEN____,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruRUBY____,iruGK______,iruGNECKLAC,iruELEPHANT,iruGA______,iruELEPHANT,iruGJ______,iruGJUG____,iruGQ______,iruELEPHANT,iruELEPHANT,iruGSPICES_",

        "iruNECKLACE,iruA_______,iruSPICES__,iruK_______,iruJUG_____,iruTEN_____,iruA_______,iruSPICES__,iruTEN_____,iruQ_______,iruNECKLACE,iruA_______,iruK_______,iruJUG_____,iruQ_______,iruJ_______,iruNECKLACE,iruA_______,iruK_______,iruSPICES__,iruJ_______,iruQ_______,iruJUG_____,iruA_______,iruTEN_____",
        "iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGNECKLAC,iruGTEN____,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGJ______,iruGJUG____,iruELEPHANT,iruGK______,iruGJ______,iruELEPHANT,iruELEPHANT,iruGJUG____,iruGA______,iruELEPHANT,iruGQ______,iruGTEN____,iruELEPHANT,iruGQ______,iruGSPICES_,iruELEPHANT,iruGQ______,iruGSPICES_,iruELEPHANT,iruGK______,iruGJUG____,iruELEPHANT,iruELEPHANT,iruGA______,iruGJ______,iruGNECKLAC,iruGTEN____",
        "iruGNECKLAC,iruGA______,iruGTEN____,iruGSPICES_,iruGJ______,iruGK______,iruGJUG____,iruGQ______,iruGA______,iruGSPICES_,iruGTEN____,iruGK______,iruGJUG____,iruGQ______,iruGJ______",
        "iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGA______,iruELEPHANT,iruELEPHANT,iruGK______,iruGTEN____,iruELEPHANT,iruELEPHANT,iruGA______,iruGNECKLAC,iruELEPHANT,iruGJ______,iruGQ______,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGK______,iruGTEN____,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGA______,iruGK______,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGTEN____,iruGSPICES_,iruELEPHANT,iruGA______,iruGQ______,iruELEPHANT,iruGJUG____,iruGTEN____,iruELEPHANT,iruELEPHANT,iruGJ______,iruGQ______,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGSPICES_,iruGQ______,iruELEPHANT,iruELEPHANT,iruGJ______,iruGK______,iruELEPHANT,iruELEPHANT,iruGJUG____,iruGJ______,iruELEPHANT",
        "iruNECKLACE,iruA_______,iruQ_______,iruSPICES__,iruK_______,iruTEN_____,iruJUG_____,iruK_______,iruA_______,iruSPICES__,iruJ_______,iruTEN_____,iruELEPHANT,iruQ_______,iruJ_______",
        "iruELEPHANT,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruELEPHANT,iruGSPICES_,iruELEPHANT,iruGA______,iruELEPHANT,iruELEPHANT,iruGK______,iruGNECKLAC,iruELEPHANT,iruELEPHANT,iruGJ______,iruELEPHANT,iruELEPHANT,iruGTEN____,iruGJUG____,iruGQ______",
    };

    for (int i = 0; i < m_vecReelStripPlan.size(); i++) {
        ReelSet set;
        for (int j = 0; j < m_nReel; j++) {
            ReelStrip strip;
            std::stringstream ss(iruReelStrip[j * m_vecReelStripPlan.size() + i]);
            std::string item;
            while (std::getline(ss, item, ',')) {
                strip.push_back(item);
            }
            set.push_back(strip);
        }
        m_vecReelStripSets.push_back(set);
    }

    m_mapSymbolMinMatch["iruELEPHANT"] = 2;
    m_mapSymbolMinMatch["iruNECKLACE"] = 3;
    m_mapSymbolMinMatch["iruSPICES__"] = 3;
    m_mapSymbolMinMatch["iruJUG_____"] = 3;
    m_mapSymbolMinMatch["iruA_______"] = 3;
    m_mapSymbolMinMatch["iruK_______"] = 3;
    m_mapSymbolMinMatch["iruQ_______"] = 3;
    m_mapSymbolMinMatch["iruJ_______"] = 3;
    m_mapSymbolMinMatch["iruTEN_____"] = 3;

    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_05_tmp;
    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_10_tmp;
    for (int i = 0; i < m_vecBetSteps_05_tmp.size(); i++) {
        std::map<std::string, std::map<UINT8, BONUS>> perSym;
        std::map<UINT8, BONUS> e;
        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 25; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[5].ag = 0;
        perSym["iruTEN_____"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 25; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[5].ag = 0;
        perSym["iruJ_______"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 25; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[5].ag = 0;
        perSym["iruQ_______"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 25; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[5].ag = 0;
        perSym["iruK_______"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 25; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[5].ag = 0;
        perSym["iruA_______"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 75; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 250; e[5].ag = 0;
        perSym["iruJUG_____"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 75; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 250; e[5].ag = 0;
        perSym["iruSPICES__"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 25; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 500; e[5].ag = 0;
        perSym["iruNECKLACE"] = e;
        e.clear();

        e[2].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 10; e[3].ag = 0;
        e[3].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 50; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 200; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_05_tmp, i) / AT(m_vecBetSteps_05_tmp, 0) * 1000; e[5].ag = 0;
        perSym["iruELEPHANT"] = e;
        e.clear();

        m_Bonus_05_tmp[i] = perSym;
    }

    m_Bonus_05_tmp[5]["iruELEPHANT"][5].coin = 0; m_Bonus_05_tmp[5]["iruELEPHANT"][5].ag = 10; // 50
    m_Bonus_05_tmp[6]["iruELEPHANT"][5].coin = 0; m_Bonus_05_tmp[6]["iruELEPHANT"][5].ag = 12; // 60
    m_Bonus_05_tmp[7]["iruELEPHANT"][5].coin = 0; m_Bonus_05_tmp[7]["iruELEPHANT"][5].ag = 16; // 80
    m_Bonus_05_tmp[8]["iruELEPHANT"][5].coin = 0; m_Bonus_05_tmp[8]["iruELEPHANT"][5].ag = 20; // 100
    m_Bonus_05_tmp[8]["iruNECKLACE"][5].coin = 0; m_Bonus_05_tmp[8]["iruNECKLACE"][5].ag = 10;
    m_Bonus_05_tmp[9]["iruELEPHANT"][5].coin = 0; m_Bonus_05_tmp[9]["iruELEPHANT"][5].ag = 40; // 200
    m_Bonus_05_tmp[9]["iruNECKLACE"][5].coin = 0; m_Bonus_05_tmp[9]["iruNECKLACE"][5].ag = 20;
    m_Bonus_05_tmp[9]["iruSPICES__"][5].coin = 0; m_Bonus_05_tmp[9]["iruSPICES__"][5].ag = 10; 
    m_Bonus_05_tmp[9]["iruJUG_____"][5].coin = 0; m_Bonus_05_tmp[9]["iruJUG_____"][5].ag = 10; 
    m_Bonus_05_tmp[10]["iruELEPHANT"][5].coin = 0; m_Bonus_05_tmp[10]["iruELEPHANT"][5].ag = 100; // 500
    m_Bonus_05_tmp[10]["iruELEPHANT"][4].coin = 0; m_Bonus_05_tmp[10]["iruELEPHANT"][4].ag = 20; 
    m_Bonus_05_tmp[10]["iruNECKLACE"][5].coin = 0; m_Bonus_05_tmp[10]["iruNECKLACE"][5].ag = 50;
    m_Bonus_05_tmp[10]["iruNECKLACE"][4].coin = 0; m_Bonus_05_tmp[10]["iruNECKLACE"][4].ag = 10;
    m_Bonus_05_tmp[10]["iruSPICES__"][5].coin = 0; m_Bonus_05_tmp[10]["iruSPICES__"][5].ag = 25; 
    m_Bonus_05_tmp[10]["iruJUG_____"][5].coin = 0; m_Bonus_05_tmp[10]["iruJUG_____"][5].ag = 25; 
    m_Bonus_05_tmp[10]["iruA_______"][5].coin = 0; m_Bonus_05_tmp[10]["iruA_______"][5].ag = 10; 
    m_Bonus_05_tmp[10]["iruK_______"][5].coin = 0; m_Bonus_05_tmp[10]["iruK_______"][5].ag = 10; 
    m_Bonus_05_tmp[10]["iruQ_______"][5].coin = 0; m_Bonus_05_tmp[10]["iruQ_______"][5].ag = 10; 
    m_Bonus_05_tmp[10]["iruJ_______"][5].coin = 0; m_Bonus_05_tmp[10]["iruJ_______"][5].ag = 10; 
    m_Bonus_05_tmp[10]["iruTEN_____"][5].coin = 0; m_Bonus_05_tmp[10]["iruTEN_____"][5].ag = 10; 

    m_Bonus_10_tmp = m_Bonus_05_tmp;

    int nSavedBetVal = 10;
    string data;
    PlayDB::GetInstance().LoadCheckPoint(m_strGameName, nSavedBetVal, m_nWinLine, m_strCheckPoint);
    if (nSavedBetVal == -1) {
        nSavedBetVal = 10;
    }
    if (m_nWinLine == -1) {
        m_nWinLine = 5;
    }

    BOOL start = FALSE;
    int idx = 0;
    for (int i = 0; i < m_vecBetSteps_05_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_05_tmp, i) < AT(m_vecBetSteps_05, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps_05, idx) == nSavedBetVal && m_nWinLine == 5) {
            m_nBetStep = idx;
        }

        m_Bonus_05[idx++] = m_Bonus_05_tmp[i];
        if (AT(m_vecBetSteps_05_tmp, i) == AT(m_vecBetSteps_05, m_vecBetSteps_05.size() - 1)) {
            break;
        }
    }
    start = FALSE;
    idx = 0;
    for (int i = 0; i < m_vecBetSteps_10_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_10_tmp, i) < AT(m_vecBetSteps_10, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps_10, idx) == nSavedBetVal && m_nWinLine == 10) {
            m_nBetStep = idx;
        }

        m_Bonus_10[idx++] = m_Bonus_10_tmp[i];
        if (AT(m_vecBetSteps_10_tmp, i) == AT(m_vecBetSteps_10, m_vecBetSteps_10.size() - 1)) {
            break;
        }
    }
    m_Bonus = (m_nWinLine == 5 ? m_Bonus_05 : m_Bonus_10);
    m_vecBetSteps = (m_nWinLine == 5 ? m_vecBetSteps_05 : m_vecBetSteps_10);
    
    PrintAllBonus();
}

UINT16 RgIndianRuby::Run() {
    ChangeReelStrip(0);
    return m_shCurrentReelStrip;
}

void RgIndianRuby::ChangeReelStrip(UINT16 NewReelPlan) {
    m_nCurrentReelPlan = NewReelPlan;
    m_shCurrentReelStrip = static_cast<uint16_t>(std::stoi(AT(m_vecReelStripPlan, m_nCurrentReelPlan)));
}

UINT16 RgIndianRuby::SpinTime_MS() {
    if (m_bFreeMode) {
        return 13500;
    }
    return 2500;
}

myVector<UINT8> RgIndianRuby::Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) {
    m_bPrevSpinMatchedActive = FALSE;
    m_nMagicCount = 0;

    myVector<UINT8> result;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);

    if (bTest) {
        // avoid scatter
    _LOOP:
        std::string matchSymbol = AT(m_vecSymbols, myRandom() % (m_vecSymbols.size() - 1));
        int line = (myRandom() % m_nWinLine);
        int weight = 1 + (myRandom() % 5);
        if (m_bFreeMode) {
            matchSymbol = RgIndianRuby_ele;
            weight = 3 + (myRandom() % 3);
        }
        int eleCnt = 0;
        for (int i = 0; i < m_nReel; i++) {
            ReelStrip reelStrip = AT(reelSet, i);
            int len = reelStrip.size() - 3;

            int valid_i[0x100];
            int valid_count = 0;
            for (int j = 0; j <= len; j++) {
                if (weight > i) {
                    if (matchSymbol == AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                else {
                    if (matchSymbol != AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
            }
            if (valid_count > 0) {
                int rand_index = myRandom() % valid_count;
                int chosen_i = valid_i[rand_index];
                result.push_back(chosen_i + 1);
            }
            else {
                result.push_back((myRandom() % (len - 1)) + 1);
            }
            if (AT(reelStrip, AT(result, i) - 1 + 0) == RgIndianRuby_ele) {
                eleCnt++;
            }
            if (AT(reelStrip, AT(result, i) - 1 + 1) == RgIndianRuby_ele) {
                eleCnt++;
            }
            if (AT(reelStrip, AT(result, i) - 1 + 2) == RgIndianRuby_ele) {
                eleCnt++;
            }
        }
        if ((myRandom() % 100) < 70) {
            if (eleCnt >= 2) {
                result.clear();
                goto _LOOP;
            }
        }
    }
    else {
        result = _result;

        BOOL mmcode = mmcode_get_active_status();
        if (mmcode) {
            mmcode_set_deactive();
            if (m_bFreeMode == FALSE) {
                for (int j = 0; j < 5; j++) {
                    myVector<int> candidateIndices;
                    for (int i = 2; i < AT(reelSet, j).size() - 3; ++i) {
                        if (AT(AT(reelSet, j), i) == RgIndianRuby_ele) {
                            int offset = myRandom() % 3;
                            int selectedIndex = i - 2 + offset;
                            candidateIndices.push_back(selectedIndex);
                        }
                    }
                    if (!candidateIndices.empty()) {
                        int chosenIndex = AT(candidateIndices, myRandom() % candidateIndices.size());
                        AT(result, j) = chosenIndex + 1;
                    }
                }
            }
        }
    }
    m_vWinResult = result;

    if (CardCount(RgIndianRuby_ele) >= 2) {
        bCanFreeMode = TRUE;
    }

    normalMeter = 0;
    maxMeter = 0;
    BONUS totalBonus = {0, 0};
    for (int i = 0; i < m_nWinLine; i++) {
        int j = 1;
        UINT16 meter = ((UINT16)1 << (2 - g_match_lines_10_5[i][0]));
        std::string firstSymbol = AT(AT(reelSet, 0), AT(result, 0) - 1 + g_match_lines_10_5[i][0]);
        if (firstSymbol != RgIndianRuby_ele) {
            if (IsEle(0, g_match_lines_10_5[i][0])) {
                firstSymbol = RgIndianRuby_ele;
            }
        }
        int multi = 1;
        for (; j < m_nMaxMatch; j++) {
            std::string prev_symbol = AT(AT(reelSet, j - 1), AT(result, j - 1) - 1 + g_match_lines_10_5[i][j - 1]);
            std::string cur_symbol = AT(AT(reelSet, j), AT(result, j) - 1 + g_match_lines_10_5[i][j]);

            if (prev_symbol != RgIndianRuby_ele) {
                if (IsEle(j - 1, g_match_lines_10_5[i][j - 1])) {
                    prev_symbol = RgIndianRuby_ele;
                }
            }
            if (cur_symbol != RgIndianRuby_ele) {
                if (IsEle(j, g_match_lines_10_5[i][j])) {
                    cur_symbol = RgIndianRuby_ele;
                }
            }

            if (cur_symbol == RgIndianRuby_scatter) {
                multi = 2;
            }
            if (firstSymbol == RgIndianRuby_scatter) { // scatter
                firstSymbol = cur_symbol;
            }
            if (firstSymbol == cur_symbol || cur_symbol == RgIndianRuby_scatter) {
                meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
                continue;
            }
            break;
        }
        if (j < m_mapSymbolMinMatch[firstSymbol] || m_mapSymbolMinMatch[firstSymbol] == 0) {
            continue;
        }

        // monitor 2 meter
        std::string meterStr = m_mapSymbolMeterGoc[firstSymbol];
        size_t pos = meterStr.find('$');
        if (pos != std::string::npos) {
            meterStr = meterStr.replace(pos, 1, std::to_string(j));
        }

        WinMeter e;
        e.line = i;
        e.meter = meter;
        e.meter2 = g_GrafficObjList.Str2GOCID(meterStr);
        e.symbol = firstSymbol;
        e.weight = j;
        e.start = 0;
        e.bonus.coin = m_Bonus[BetStep()][firstSymbol][j].coin * multi;
        e.bonus.ag = m_Bonus[BetStep()][firstSymbol][j].ag * multi;
        e.sound = MAX_SOUND_IDS;

        totalBonus.coin += e.bonus.coin;
        totalBonus.ag += e.bonus.ag;

        meters.push_back(e);        
        if (j == m_nMaxMatch) {
            maxMeter |= meter;
        }
        else {
            normalMeter |= meter;
        }
        if (bTest == FALSE) {
            m_bPrevSpinMatchedActive = TRUE;
        }
    }
    if (bTest == FALSE) {
        updateCheckPoint();
    }
    m_nMagicCount = totalBonus.ag;
    if (totalBonus.coin > 0 || totalBonus.ag > 0) {
        BonusSound = getSoundByID(WinSound(totalBonus.coin + totalBonus.ag * 1000));
    }
    return result;
}

UINT8 RgIndianRuby::CardCount(std::string card) {
    int n = 0;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int col = 0; col < m_nReel; col++) {
        int k = 0;
        for (; k < 3; k++) {
            std::string s = AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k);
            if (s == card) {
                n++;
            }
        }
    }
    return n;
}

BOOL RgIndianRuby::IsEle(int col, int row) {
    if (!m_bFreeMode) {
        return FALSE;
    }
    for (int i = 0; i < m_vEle.size(); i++) {
        if (AT(m_vEle, i).row == row && AT(m_vEle, i).reel == col) {
            return TRUE;
        }
    }
    return FALSE;
}

BOOL RgIndianRuby::CanFreeMode() {
    if (CardCount(RgIndianRuby_ele) >= 2) {
        return TRUE;
    }
    return FALSE;
}

myVector<InterruptPacketData> RgIndianRuby::EnterFreeGame(std::string check) {
    m_bFreeMode = TRUE;

    m_vEle.clear();
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int col = 0; col < m_nReel; col++) {
        for (int k = 0; k < 3; k++) {
            if (AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k) == RgIndianRuby_ele) {
                Position p;
                p.reel = col;
                p.row = k;
                m_vEle.push_back(p);
            }
        }
    }
    ChangeReelStrip(1 + (myRandom() & 1));

    myVector<InterruptPacketData> _;
    return _;
}

myVector<InterruptPacketData> RgIndianRuby::InterruptAfterMoveBonus(BOOL& EndFree) {
    EndFree = TRUE;
    m_bFreeMode = FALSE;
    ChangeReelStrip(0);

    myVector<InterruptPacketData> _;
    return _;
}

int RgIndianRuby::LineSwapDelay(int WinIdx) {
    return 400;
}

UINT16 RgIndianRuby::MagicCount() {
    if (m_bFreeMode) {
        return 0;
    }
    else {
        return m_nMagicCount;
    }
}

myVector<InterruptPacketData> RgIndianRuby::MousePressed(MousePosition p) {
    myVector<InterruptPacketData> packets;

    // change line
    MousePosition a{
        {RgIndianRuby_MP_ChangeLine_LB_x_reel, RgIndianRuby_MP_ChangeLine_LB_x_pos },
        {RgIndianRuby_MP_ChangeLine_LB_y_row, RgIndianRuby_MP_ChangeLine_LB_y_pos }
    };
    MousePosition b{
        {RgIndianRuby_MP_ChangeLine_RT_x_reel, RgIndianRuby_MP_ChangeLine_RT_x_pos },
        {RgIndianRuby_MP_ChangeLine_RT_y_row, RgIndianRuby_MP_ChangeLine_RT_y_pos }
    };
    if (IsMouseWithin(p, a, b)) {
        m_nWinLine = (m_nWinLine == 5) ? 10 : 5;
        if (m_bPrevSpinMatchedActive) {
            // hide win lines
            packets.push_back({ 0, 0, {0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 
                static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x02, 0x00, 0x04} });
            m_bPrevSpinMatchedActive = FALSE;
        }
        UINT16 newBetValue = 0;
        if (m_nWinLine == 5) {
            m_Bonus = m_Bonus_05;
            m_vecBetSteps = m_vecBetSteps_05;
            newBetValue = AT(m_vecBetSteps_10, m_nBetStep) / 2;
            // lines
            packets.push_back({ 0, 0, {0x01, 0x02, 0x31, 0x00, 0x04, 0x00, 
                static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x9d, 0x1f, 0x00, 0x00, 0x00, 0x04} });
        }
        else {
            m_Bonus = m_Bonus_10;
            m_vecBetSteps = m_vecBetSteps_10;
            newBetValue = AT(m_vecBetSteps_05, m_nBetStep) * 2;
            // lines
            packets.push_back({ 0, 0, {0x01, 0x02, 0x31, 0x00, 0x04, 0x00, 
                static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x9d, 0xff, 0x03, 0x00, 0x00, 0x04} });
        }      
        BOOL flag = FALSE;
        for (int i = 0; i < m_vecBetSteps.size(); i++) {
            if (AT(m_vecBetSteps, i) == newBetValue) {
                m_nBetStep = i;
                flag = TRUE;
                break;
            }
        }
        if (flag == FALSE) {
            m_nBetStep = 0;
        }
        // play button sound
        packets.push_back({ 0, 0, {0x01, 0x02, 0x34, 0x00, 0xf7, 0x00, 0x04} });
        // change line button
        packets.push_back({ 0, 0, {0x01, 0x02, 0x28, 0x00,
            static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), static_cast<BYTE>(m_nWinLine), 0x00, 0x00, 0x00, 0x04}});
        // set bet
        UINT16 bet = AT(m_vecBetSteps, m_nBetStep) / 5;
        packets.push_back({ 0, 0, {0x01, 0x02, 0x30, 0x00, 0x25, 0x53, 
            static_cast<BYTE>(bet & 0xFF), static_cast<BYTE>((bet >> 8) & 0xFF), 
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04, 0x04} });
    }
    return packets;
}


myVector<UINT8> RgIndianRuby::ShowTotalWinLines(myVector<WinMeter> SpinMeters) {
    myVector<uint8_t> packet = {
        0x06, 0x30, 0x59, 0x01, 0x02, 0x31, 0x00,
        0x0F, 0x00,  // Placeholder for length 
        0x0F, 0x11, // GameID
        0x9C, 0x19, 0x01
    };
    myVector<UINT8> TotalMatch;
    for (int i = 0; i < SpinMeters.size(); i++) {
        if (AT(SpinMeters, i).line == 0xFF) { // clear after convert action
            TotalMatch.clear();
            continue;
        }
        TotalMatch.push_back(AT(SpinMeters, i).line);
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter >> 8) & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter2 & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter2 >> 8) & 0xFF));
    }
    if (TotalMatch.size() < 10) {
        myVector<UINT8> _;
        return _;
    }
    UINT16 pktLen = 1 + (TotalMatch.size() / 5) * 7;
    AT(packet, 7) = static_cast<BYTE>(pktLen & 0xFF);
    AT(packet, 8) = static_cast<BYTE>((pktLen >> 8) & 0xFF);
    AT(packet, 9) = static_cast<BYTE>(m_nGameID & 0xFF);
    AT(packet, 10) = static_cast<BYTE>((m_nGameID >> 8) & 0xFF);
    int entryCount = static_cast<int>(TotalMatch.size() / 5);
    for (int i = 0; i < entryCount; ++i) {
        packet.push_back(AT(TotalMatch, i * 5 + 0)); // Line
        packet.push_back(AT(TotalMatch, i * 5 + 1)); // Meter low byte
        packet.push_back(AT(TotalMatch, i * 5 + 2)); // Meter high byte
        packet.push_back(AT(TotalMatch, i * 5 + 3)); // Meter2 low byte
        packet.push_back(AT(TotalMatch, i * 5 + 4)); // Meter2 high byte
        packet.push_back(0x01);      // Status or flag 1
        packet.push_back(0x01);      // Status or flag 2
    }
    // Mark the end of the packet
    packet.back() = 0x04;
    return packet;
}

bool RgIndianRuby::RTP_force_bigWin() {
    return (myRandom() % 40 == 0); // 2.5%
}

void RgIndianRuby::updateCheckPoint() {
    if (m_bFreeMode) {
        return;
    }
    std::ostringstream oss;
    oss << " P" << m_nCurrentReelPlan
        << " B"
        << static_cast<int>(AT(m_vWinResult, 0)) << ":"
        << static_cast<int>(AT(m_vWinResult, 1)) << ":"
        << static_cast<int>(AT(m_vWinResult, 2)) << ":"
        << static_cast<int>(AT(m_vWinResult, 3)) << ":"
        << static_cast<int>(AT(m_vWinResult, 4)) << " ";
    m_strCheckPoint = oss.str();
}
