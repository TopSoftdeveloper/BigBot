#include "stdafx.h"
#include "RgDragonsTreas.h"

#define RgDragonsTreas_dragon    "drtrDRAGON"
RgDragonsTreas::RgDragonsTreas() {
    m_nReel = 5;
    m_nWinLine = 5;
    m_nMaxMatch = 5;
    m_nBetStep = 0;

    m_bFreeMode = FALSE;

    m_strGameName = "RgDragonsTreasure";
    
    myVector<UINT16> m_vecBetSteps_tmp;
    m_vecBetSteps_tmp.push_back(5);
    m_vecBetSteps_tmp.push_back(10);
    m_vecBetSteps_tmp.push_back(20);
    m_vecBetSteps_tmp.push_back(30);
    m_vecBetSteps_tmp.push_back(40);
    m_vecBetSteps_tmp.push_back(50);
    m_vecBetSteps_tmp.push_back(60);
    m_vecBetSteps_tmp.push_back(80);
    m_vecBetSteps_tmp.push_back(100);
#ifdef BIGBET_ACTIVE
    m_vecBetSteps_tmp.push_back(200);
    m_vecBetSteps_tmp.push_back(500);
#endif
    LoadBets();
    m_vecBetSteps = m_vecBetSteps_05;

    m_vecSymbols.push_back("drtrSIEGFR");
    m_vecSymbols.push_back("drtrHAGEN_");
    m_vecSymbols.push_back("drtrSCHATZ");
    m_vecSymbols.push_back("drtrSCHWER");
    m_vecSymbols.push_back("drtrA_____");
    m_vecSymbols.push_back("drtrK_____");
    m_vecSymbols.push_back("drtrQ_____");
    m_vecSymbols.push_back("drtrJ_____");
    m_vecSymbols.push_back("drtrTEN___");
    m_vecSymbols.push_back("drtrDRAGON");

    m_mapSymbolMinMatch["drtrSIEGFR"] = 2;
    m_mapSymbolMinMatch["drtrHAGEN_"] = 2;
    m_mapSymbolMinMatch["drtrSCHATZ"] = 2;
    m_mapSymbolMinMatch["drtrSCHWER"] = 2;
    m_mapSymbolMinMatch["drtrA_____"] = 3;
    m_mapSymbolMinMatch["drtrK_____"] = 3;
    m_mapSymbolMinMatch["drtrQ_____"] = 3;
    m_mapSymbolMinMatch["drtrJ_____"] = 3;
    m_mapSymbolMinMatch["drtrTEN___"] = 3;
    m_mapSymbolMinMatch["drtrDRAGON"] = 3;

    m_mapSymbolMeterGoc["drtrSIEGFR"] = "drtrSiegfried$x";
    m_mapSymbolMeterGoc["drtrHAGEN_"] = "drtrHagen$x";
    m_mapSymbolMeterGoc["drtrSCHATZ"] = "drtrSchatz$x";
    m_mapSymbolMeterGoc["drtrSCHWER"] = "drtrSchwert$x";
    m_mapSymbolMeterGoc["drtrA_____"] = "drtrAS_$x";
    m_mapSymbolMeterGoc["drtrK_____"] = "drtrK_$x";
    m_mapSymbolMeterGoc["drtrQ_____"] = "drtrQ_$x";
    m_mapSymbolMeterGoc["drtrJ_____"] = "drtrJ_$x";
    m_mapSymbolMeterGoc["drtrTEN___"] = "drtr10_$x";
    m_mapSymbolMeterGoc["drtrDRAGON"] = "drtrDragon$x";

    m_vecWinLines.push_back("drtrWinL1");
    m_vecWinLines.push_back("drtrWinL2");
    m_vecWinLines.push_back("drtrWinL3");
    m_vecWinLines.push_back("drtrWinL4");
    m_vecWinLines.push_back("drtrWinL5");
    m_vecWinLines.push_back("drtrWinScat");

    m_vecLineSounds.push_back(SMP_DRTR_Winline1);
    m_vecLineSounds.push_back(SMP_DRTR_Winline2);
    m_vecLineSounds.push_back(SMP_DRTR_Winline3);
    m_vecLineSounds.push_back(SMP_DRTR_Winline4);
    m_vecLineSounds.push_back(SMP_DRTR_Winline5);

    m_vecWinSounds.push_back(SMP_DRTR_DragonsTreasureWinVerySmall);
    m_vecWinSounds.push_back(SMP_DRTR_DragonsTreasureWinTiny);
    m_vecWinSounds.push_back(SMP_DRTR_DragonsTreasureWinSmall);
    m_vecWinSounds.push_back(SMP_DRTR_DragonsTreasureWinMedium);
    m_vecWinSounds.push_back(SMP_DRTR_DragonsTreasureWinBig);
    m_vecWinSounds.push_back(SMP_DRTR_DragonsTreasureWinHuge);
    m_vecWinSounds.push_back(SMP_DRTR_DragonsTreasureWinTop);

    m_vecReelStripPlan.push_back("drtrWalze1A");
    m_vecReelStripPlan.push_back("drtrWalze1B");
    
    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));

    char* drtrReelStrip[] = {        
        "drtrJ_____,drtrK_____,drtrSCHATZ,drtrA_____,drtrK_____,drtrSIEGFR,drtrQ_____,drtrA_____,drtrSCHATZ,drtrJ_____,drtrA_____,drtrDRAGON,drtrTEN___,drtrQ_____,drtrA_____,drtrJ_____,drtrK_____,drtrQ_____,drtrA_____,drtrSIEGFR,drtrTEN___,drtrA_____,drtrSCHATZ,drtrQ_____,drtrK_____,drtrHAGEN_,drtrJ_____,drtrA_____,drtrTEN___,drtrQ_____,drtrSCHATZ,drtrJ_____,drtrK_____,drtrSCHWER,drtrQ_____,drtrK_____,drtrA_____,drtrJ_____,drtrSCHATZ,drtrK_____,drtrQ_____,drtrSCHATZ,drtrK_____,drtrTEN___,drtrHAGEN_,drtrK_____,drtrQ_____",
        "drtrK_____,drtrTEN___,drtrJ_____,drtrSCHWER,drtrK_____,drtrTEN___,drtrJ_____,drtrA_____,drtrK_____,drtrTEN___,drtrQ_____,drtrHAGEN_,drtrK_____,drtrJ_____,drtrSCHWER,drtrTEN___,drtrK_____,drtrSCHWER,drtrJ_____,drtrA_____,drtrK_____,drtrHAGEN_,drtrA_____,drtrTEN___,drtrJ_____,drtrDRAGON,drtrQ_____,drtrJ_____,drtrTEN___,drtrQ_____,drtrK_____,drtrTEN___,drtrJ_____,drtrSCHATZ,drtrA_____,drtrJ_____,drtrK_____,drtrA_____,drtrSCHWER,drtrTEN___,drtrJ_____,drtrQ_____,drtrSIEGFR,drtrK_____,drtrTEN___,drtrJ_____,drtrSCHWER",
        "drtrSCHWER,drtrK_____,drtrHAGEN_,drtrTEN___,drtrQ_____,drtrSIEGFR,drtrJ_____,drtrA_____,drtrSCHATZ,drtrQ_____,drtrA_____,drtrSCHATZ,drtrTEN___,drtrJ_____,drtrSIEGFR,drtrQ_____,drtrTEN___,drtrHAGEN_,drtrQ_____,drtrSCHATZ,drtrA_____,drtrHAGEN_,drtrK_____,drtrTEN___,drtrDRAGON,drtrQ_____,drtrJ_____,drtrTEN___,drtrA_____,drtrJ_____,drtrSCHWER,drtrA_____,drtrTEN___,drtrSCHATZ,drtrQ_____,drtrJ_____,drtrSCHWER,drtrTEN___,drtrA_____,drtrK_____,drtrHAGEN_,drtrTEN___,drtrJ_____,drtrQ_____,drtrSCHWER,drtrTEN___,drtrA_____,drtrQ_____",
        "drtrTEN___,drtrA_____,drtrK_____,drtrSCHATZ,drtrQ_____,drtrTEN___,drtrSIEGFR,drtrJ_____,drtrK_____,drtrA_____,drtrHAGEN_,drtrQ_____,drtrA_____,drtrSIEGFR,drtrTEN___,drtrK_____,drtrDRAGON,drtrJ_____,drtrQ_____,drtrA_____,drtrTEN___,drtrSCHATZ,drtrQ_____,drtrJ_____,drtrTEN___,drtrHAGEN_,drtrK_____,drtrQ_____,drtrTEN___,drtrJ_____,drtrSCHWER,drtrA_____,drtrTEN___,drtrSCHATZ,drtrK_____,drtrQ_____,drtrJ_____,drtrA_____,drtrSCHWER,drtrK_____,drtrHAGEN_,drtrTEN___,drtrQ_____,drtrSCHWER,drtrA_____,drtrTEN___,drtrDRAGON,drtrK_____",
        "drtrA_____,drtrSIEGFR,drtrQ_____,drtrJ_____,drtrK_____,drtrSCHWER,drtrTEN___,drtrJ_____,drtrSIEGFR,drtrA_____,drtrQ_____,drtrHAGEN_,drtrK_____,drtrSCHWER,drtrTEN___,drtrA_____,drtrSCHWER,drtrQ_____,drtrSCHATZ,drtrK_____,drtrA_____,drtrHAGEN_,drtrQ_____,drtrJ_____,drtrDRAGON,drtrQ_____,drtrA_____,drtrSCHATZ,drtrTEN___,drtrHAGEN_,drtrJ_____,drtrSCHWER,drtrA_____,drtrK_____,drtrSCHWER,drtrTEN___,drtrQ_____,drtrK_____,drtrSCHATZ,drtrA_____,drtrQ_____,drtrSCHATZ,drtrJ_____,drtrK_____,drtrDRAGON,drtrJ_____,drtrK_____,drtrTEN___",
    
        "drtrSIEGFR,drtrA_____,drtrTEN___,drtrSCHATZ,drtrA_____,drtrK_____,drtrSIEGFR,drtrQ_____,drtrDRAGON,drtrJ_____,drtrTEN___,drtrSCHATZ,drtrQ_____,drtrTEN___,drtrSCHWER,drtrJ_____,drtrTEN___,drtrHAGEN_,drtrK_____,drtrA_____,drtrSCHWER,drtrQ_____,drtrTEN___,drtrHAGEN_,drtrJ_____,drtrTEN___,drtrDRAGON,drtrA_____,drtrQ_____,drtrSIEGFR,drtrJ_____,drtrTEN___,drtrSCHATZ,drtrQ_____,drtrK_____,drtrSCHWER,drtrA_____,drtrK_____",
        "drtrSIEGFR,drtrQ_____,drtrK_____,drtrDRAGON,drtrTEN___,drtrQ_____,drtrK_____,drtrSCHWER,drtrTEN___,drtrK_____,drtrA_____,drtrSCHATZ,drtrQ_____,drtrTEN___,drtrSCHWER,drtrQ_____,drtrJ_____,drtrSCHATZ,drtrQ_____,drtrA_____,drtrTEN___,drtrHAGEN_,drtrJ_____,drtrTEN___,drtrK_____,drtrSCHWER,drtrQ_____,drtrTEN___,drtrSCHATZ,drtrK_____,drtrA_____,drtrDRAGON,drtrQ_____,drtrJ_____,drtrHAGEN_,drtrTEN___,drtrA_____,drtrJ_____",
        "drtrSIEGFR,drtrJ_____,drtrA_____,drtrHAGEN_,drtrTEN___,drtrQ_____,drtrSCHWER,drtrK_____,drtrTEN___,drtrHAGEN_,drtrQ_____,drtrA_____,drtrSCHWER,drtrQ_____,drtrK_____,drtrHAGEN_,drtrJ_____,drtrA_____,drtrSCHATZ,drtrK_____,drtrTEN___,drtrSCHWER,drtrA_____,drtrJ_____,drtrQ_____,drtrHAGEN_,drtrA_____,drtrJ_____,drtrQ_____,drtrSCHWER,drtrK_____,drtrQ_____,drtrDRAGON,drtrJ_____,drtrK_____,drtrSCHWER,drtrTEN___,drtrQ_____",
        "drtrSIEGFR,drtrJ_____,drtrK_____,drtrHAGEN_,drtrJ_____,drtrQ_____,drtrSCHWER,drtrK_____,drtrTEN___,drtrDRAGON,drtrJ_____,drtrA_____,drtrSCHWER,drtrTEN___,drtrJ_____,drtrSCHATZ,drtrQ_____,drtrK_____,drtrDRAGON,drtrA_____,drtrJ_____,drtrSIEGFR,drtrA_____,drtrQ_____,drtrJ_____,drtrSCHWER,drtrTEN___,drtrQ_____,drtrSCHATZ,drtrK_____,drtrJ_____,drtrHAGEN_,drtrA_____,drtrK_____,drtrSCHATZ,drtrTEN___,drtrA_____",
        "drtrSIEGFR,drtrA_____,drtrJ_____,drtrSCHATZ,drtrK_____,drtrA_____,drtrHAGEN_,drtrJ_____,drtrK_____,drtrDRAGON,drtrJ_____,drtrTEN___,drtrSCHATZ,drtrA_____,drtrQ_____,drtrHAGEN_,drtrJ_____,drtrTEN___,drtrSCHATZ,drtrQ_____,drtrK_____,drtrSIEGFR,drtrJ_____,drtrA_____,drtrDRAGON,drtrQ_____,drtrK_____,drtrSCHATZ,drtrTEN___,drtrA_____,drtrJ_____,drtrSCHWER,drtrTEN___,drtrQ_____,drtrSCHATZ,drtrJ_____,drtrK_____,drtrTEN___",
    };

    int idx = 0;
    for (int i = 0; i < m_vecReelStripPlan.size(); i++) {
        ReelSet set;
        for (int j = 0; j < m_nReel; j++) {
            ReelStrip strip;
            std::stringstream ss(drtrReelStrip[idx]);
            std::string item;
            while (std::getline(ss, item, ',')) {
                strip.push_back(item);
            }
            set.push_back(strip);
            idx++;
        }
        m_vecReelStripSets.push_back(set);
    }

    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_tmp;
    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_BonusFree_tmp;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        std::map<std::string, std::map<UINT8, BONUS>> perSym;
        std::map<UINT8, BONUS> e;
        e[2].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 10; e[2].ag = 0;
        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 1000; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5000; e[5].ag = 0;
        perSym["drtrSIEGFR"] = e;
        e.clear();

        e[2].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5; e[2].ag = 0;
        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 40; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 400; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 2000; e[5].ag = 0;
        perSym["drtrHAGEN_"] = e;
        e.clear();

        e[2].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5; e[2].ag = 0;
        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 30; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 750; e[5].ag = 0;
        perSym["drtrSCHATZ"] = e;
        e.clear();

        e[2].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5; e[2].ag = 0;
        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 30; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 750; e[5].ag = 0;
        perSym["drtrSCHWER"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 40; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 150; e[5].ag = 0;
        perSym["drtrA_____"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 40; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 150; e[5].ag = 0;
        perSym["drtrK_____"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 25; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[5].ag = 0;
        perSym["drtrQ_____"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 25; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[5].ag = 0;
        perSym["drtrJ_____"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 25; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[5].ag = 0;
        perSym["drtrTEN___"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 1000; e[5].ag = 0;
        perSym["drtrDRAGON"] = e;
        e.clear();

        m_Bonus_tmp[i] = perSym;
    }
    m_Bonus_tmp[m_vecBetSteps_tmp.size() - 1 - BIGBET_BETSTEP_EXTRA_COUNT]["drtrSIEGFR"][5].coin = 80000;
    m_Bonus_tmp[m_vecBetSteps_tmp.size() - 1 - BIGBET_BETSTEP_EXTRA_COUNT]["drtrSIEGFR"][4].coin = 22000;

    m_BonusFree_tmp = m_Bonus_tmp;

    m_BonusFree_tmp[0]["drtrHAGEN_"][2].coin = 5;
    m_BonusFree_tmp[0]["drtrHAGEN_"][3].coin = 40;
    m_BonusFree_tmp[0]["drtrHAGEN_"][4].coin = 400;
    m_BonusFree_tmp[0]["drtrHAGEN_"][5].coin = 2200;
    m_BonusFree_tmp[1]["drtrHAGEN_"][2].coin = 10;
    m_BonusFree_tmp[1]["drtrHAGEN_"][3].coin = 80;
    m_BonusFree_tmp[1]["drtrHAGEN_"][4].coin = 800;
    m_BonusFree_tmp[1]["drtrHAGEN_"][5].coin = 4400;
    m_BonusFree_tmp[2]["drtrHAGEN_"][2].coin = 20;
    m_BonusFree_tmp[2]["drtrHAGEN_"][3].coin = 160;
    m_BonusFree_tmp[2]["drtrHAGEN_"][4].coin = 1600;
    m_BonusFree_tmp[2]["drtrHAGEN_"][5].coin = 8800;
    m_BonusFree_tmp[3]["drtrHAGEN_"][2].coin = 30;
    m_BonusFree_tmp[3]["drtrHAGEN_"][3].coin = 240;
    m_BonusFree_tmp[3]["drtrHAGEN_"][4].coin = 2400;
    m_BonusFree_tmp[3]["drtrHAGEN_"][5].coin = 12000;
    m_BonusFree_tmp[4]["drtrHAGEN_"][2].coin = 40;
    m_BonusFree_tmp[4]["drtrHAGEN_"][3].coin = 320;
    m_BonusFree_tmp[4]["drtrHAGEN_"][4].coin = 3280;
    m_BonusFree_tmp[4]["drtrHAGEN_"][5].coin = 16000;
    m_BonusFree_tmp[5]["drtrHAGEN_"][2].coin = 50;
    m_BonusFree_tmp[5]["drtrHAGEN_"][3].coin = 400;
    m_BonusFree_tmp[5]["drtrHAGEN_"][4].coin = 4100;
    m_BonusFree_tmp[5]["drtrHAGEN_"][5].coin = 16000;
    m_BonusFree_tmp[6]["drtrHAGEN_"][2].coin = 60;
    m_BonusFree_tmp[6]["drtrHAGEN_"][3].coin = 480;
    m_BonusFree_tmp[6]["drtrHAGEN_"][4].coin = 5100;
    m_BonusFree_tmp[6]["drtrHAGEN_"][5].coin = 16000;
    m_BonusFree_tmp[7]["drtrHAGEN_"][2].coin = 80;
    m_BonusFree_tmp[7]["drtrHAGEN_"][3].coin = 640;
    m_BonusFree_tmp[7]["drtrHAGEN_"][4].coin = 7040;
    m_BonusFree_tmp[7]["drtrHAGEN_"][5].coin = 16000;
    m_BonusFree_tmp[8]["drtrHAGEN_"][2].coin = 100;
    m_BonusFree_tmp[8]["drtrHAGEN_"][3].coin = 800;
    m_BonusFree_tmp[8]["drtrHAGEN_"][4].coin = 9020;
    m_BonusFree_tmp[8]["drtrHAGEN_"][5].coin = 16000;
    m_BonusFree_tmp[9]["drtrHAGEN_"][2].coin = 40;     //200
    m_BonusFree_tmp[9]["drtrHAGEN_"][3].coin = 320;
    m_BonusFree_tmp[9]["drtrHAGEN_"][4].coin = 3200;
    m_BonusFree_tmp[9]["drtrHAGEN_"][5].coin = 16000;
    m_BonusFree_tmp[10]["drtrHAGEN_"][2].coin = 100;     //500
    m_BonusFree_tmp[10]["drtrHAGEN_"][3].coin = 800;
    m_BonusFree_tmp[10]["drtrHAGEN_"][4].coin = 8000;
    m_BonusFree_tmp[10]["drtrHAGEN_"][5].coin = 40000;

    m_BonusFree_tmp[0]["drtrSIEGFR"][2].coin = 10; // 5
    m_BonusFree_tmp[0]["drtrSIEGFR"][3].coin = 100;
    m_BonusFree_tmp[0]["drtrSIEGFR"][4].coin = 1100;
    m_BonusFree_tmp[0]["drtrSIEGFR"][5].coin = 7000;
    m_BonusFree_tmp[1]["drtrSIEGFR"][2].coin = 20; // 10
    m_BonusFree_tmp[1]["drtrSIEGFR"][3].coin = 200;
    m_BonusFree_tmp[1]["drtrSIEGFR"][4].coin = 2200;
    m_BonusFree_tmp[1]["drtrSIEGFR"][5].coin = 14000;
    m_BonusFree_tmp[2]["drtrSIEGFR"][2].coin = 40; // 20
    m_BonusFree_tmp[2]["drtrSIEGFR"][3].coin = 400;
    m_BonusFree_tmp[2]["drtrSIEGFR"][4].coin = 4720;
    m_BonusFree_tmp[2]["drtrSIEGFR"][5].coin = 16000;
    m_BonusFree_tmp[3]["drtrSIEGFR"][2].coin = 60; // 30
    m_BonusFree_tmp[3]["drtrSIEGFR"][3].coin = 600;
    m_BonusFree_tmp[3]["drtrSIEGFR"][4].coin = 7200;
    m_BonusFree_tmp[3]["drtrSIEGFR"][5].coin = 16000;
    m_BonusFree_tmp[4]["drtrSIEGFR"][2].coin = 80; // 40
    m_BonusFree_tmp[4]["drtrSIEGFR"][3].coin = 800;
    m_BonusFree_tmp[4]["drtrSIEGFR"][4].coin = 9800;
    m_BonusFree_tmp[4]["drtrSIEGFR"][5].coin = 16000;
    m_BonusFree_tmp[5]["drtrSIEGFR"][2].coin = 100; // 50
    m_BonusFree_tmp[5]["drtrSIEGFR"][3].coin = 1000;
    m_BonusFree_tmp[5]["drtrSIEGFR"][4].coin = 12200;
    m_BonusFree_tmp[5]["drtrSIEGFR"][5].coin = 16000;
    m_BonusFree_tmp[6]["drtrSIEGFR"][2].coin = 120; // 60
    m_BonusFree_tmp[6]["drtrSIEGFR"][3].coin = 1200;
    m_BonusFree_tmp[6]["drtrSIEGFR"][4].coin = 14940;
    m_BonusFree_tmp[6]["drtrSIEGFR"][5].coin = 16000;
    m_BonusFree_tmp[7]["drtrSIEGFR"][2].coin = 160; // 80
    m_BonusFree_tmp[7]["drtrSIEGFR"][3].coin = 1610;
    m_BonusFree_tmp[7]["drtrSIEGFR"][4].coin = 16000;
    m_BonusFree_tmp[7]["drtrSIEGFR"][5].coin = 16000;
    m_BonusFree_tmp[8]["drtrSIEGFR"][2].coin = 200; // 100
    m_BonusFree_tmp[8]["drtrSIEGFR"][3].coin = 2400;
    m_BonusFree_tmp[8]["drtrSIEGFR"][4].coin = 16000;
    m_BonusFree_tmp[8]["drtrSIEGFR"][5].coin = 16000;
    m_BonusFree_tmp[9]["drtrSIEGFR"][2].coin = 80; // 200
    m_BonusFree_tmp[9]["drtrSIEGFR"][3].coin = 800;
    m_BonusFree_tmp[9]["drtrSIEGFR"][4].coin = 8000;
    m_BonusFree_tmp[9]["drtrSIEGFR"][5].coin = 40000;
    m_BonusFree_tmp[10]["drtrSIEGFR"][2].coin = 200; // 500
    m_BonusFree_tmp[10]["drtrSIEGFR"][3].coin = 2000;
    m_BonusFree_tmp[10]["drtrSIEGFR"][4].coin = 20000;
    m_BonusFree_tmp[10]["drtrSIEGFR"][5].coin = 100000;

    int nSavedBetVal = 10;
    int _line = 0;
    string data;
    PlayDB::GetInstance().LoadCheckPoint(m_strGameName, nSavedBetVal, _line, m_strCheckPoint);
    if (nSavedBetVal == -1) {
        nSavedBetVal = 10;
    }

    BOOL start = FALSE;
    idx = 0;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_tmp, i) < AT(m_vecBetSteps, 0)) {
                continue;
            }
            start = TRUE;
        }

        // set betstep by saved value
        if (AT(m_vecBetSteps, idx) == nSavedBetVal) {
            m_nBetStep = idx;
        }

        m_Bonus[idx] = m_Bonus_tmp[i];
        m_FreeModeBonus[idx] = m_BonusFree_tmp[i];
        idx++;
        if (AT(m_vecBetSteps_tmp, i) == AT(m_vecBetSteps, m_vecBetSteps.size() - 1)) {
            break;
        }
    }

    m_BonusCp = m_Bonus;

    m_vecBetSteps_05.clear();
    m_vecBetSteps_10.clear();
    PrintAllBonus();

    PrintBonusSet("================== FreeMode Bonus ==========================",
        m_vecBetSteps, m_FreeModeBonus);
}

UINT16 RgDragonsTreas::Run() {
    m_nCurrentReelPlan = (myRandom() % m_vecReelStripPlan.size());
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));
    return m_shCurrentReelStrip;
}

myVector<UINT8> RgDragonsTreas::Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) {
    myVector<UINT8> result;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);

    if (bTest) {
        std::string matchSymbol = AT(m_vecSymbols, myRandom() % (m_vecSymbols.size() - 1));
        int line = (myRandom() % m_nWinLine);
        int weight = 1 + (myRandom() % 5);
        BOOL bForceFree = (myRandom() % 10 == 0);
        for (int i = 0; i < m_nReel; i++) {
            ReelStrip reelStrip = AT(reelSet, i);
            int len = reelStrip.size() - 3;

            int valid_i[0x100];
            int valid_count = 0;
            myVector<int> freeSymbols;
            for (int j = 0; j <= len; j++) {
                if (weight > i) {
                    if (matchSymbol == AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                else {
                    if (matchSymbol != AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                if (AT(reelStrip, j) == RgDragonsTreas_dragon && m_bFreeMode == FALSE) {
                    freeSymbols.push_back(j);
                }
            }
            if (valid_count > 0) {
                int rand_index = myRandom() % valid_count;
                int chosen_i = valid_i[rand_index];
                result.push_back(chosen_i + 1);
            }
            else {
                result.push_back((myRandom() % (len - 1)) + 1);
            }
            if (bForceFree && m_bFreeMode == FALSE && (i == 0 || i == 2 || i == 4) && freeSymbols.size() > 0) {
                AT(result, result.size() - 1) =
                    AT(freeSymbols, myRandom() % freeSymbols.size()) - (myRandom() % 2) + 1;
            }
        }
    }
    else {
        result = _result;
        m_vWinResult = result;

        BOOL mmcode = mmcode_get_active_status();
        if (mmcode) {
            mmcode_set_deactive();
            if (m_bFreeMode == FALSE) {
                for (int j = 0; j < 5; j ++) {
                    myVector<int> candidateIndices;
                    for (int i = 2; i < AT(reelSet, j).size() - 3; ++i) {
                        if (j%2 == 0 && AT(AT(reelSet, j), i) == RgDragonsTreas_dragon) {
                            int offset = myRandom() % 3;
                            int selectedIndex = i - 2 + offset;
                            candidateIndices.push_back(selectedIndex);
                        }
                        if (j%2 == 1 && AT(AT(reelSet, j), i) != RgDragonsTreas_dragon
                                    && AT(AT(reelSet, j), i-2) != RgDragonsTreas_dragon
                                    && AT(AT(reelSet, j), i-1) != RgDragonsTreas_dragon
                                    && AT(AT(reelSet, j), i+1) != RgDragonsTreas_dragon
                                    && AT(AT(reelSet, j), i+2) != RgDragonsTreas_dragon) {
                            int offset = myRandom() % 3;
                            int selectedIndex = i - 2 + offset;
                            candidateIndices.push_back(selectedIndex);
                        }
                    }
                    if (!candidateIndices.empty()) {
#ifdef BIGBET_ACTIVE
                        int chosenIndex = AT(candidateIndices, (candidateIndices.size()<3?myRandom() % candidateIndices.size():myRandom() % 3));
#else
                        int chosenIndex = AT(candidateIndices, myRandom() % candidateIndices.size());
#endif
                        AT(result, j) = chosenIndex + 1;
                    }
                }
            }
        }
        if (m_bFreeMode && ((myRandom() % 3) == 0)) {
            int pool[5] = { 0, 1, 2, 3, 4 };
            int existCnt = 0;
            // get exists
            // check wild symbol
            for (int col = 0; col < 5; col++) {
                if (CardNumInCol(col, m_strSelectedcard) > 0) {
                    existCnt++;
                }
            }
            if (existCnt < m_mapSymbolMinMatch[m_strSelectedcard]) {
                int poolSize = 0;
                for (int col = 0; col < 5; col++) {
                    if (CardNumInCol(col, m_strSelectedcard) == 0) {
                        pool[poolSize] = col;
                        poolSize++;
                    }
                }
                myVector<int> selectedReels = pickRandom2or3(pool, poolSize, m_mapSymbolMinMatch[m_strSelectedcard] - existCnt);
                for (int j = 0; j < selectedReels.size(); j++) {
                    int reel = AT(selectedReels, j);
                    ReelStrip reelStrip = AT(reelSet, reel);
                    for (int i = 3; i < reelStrip.size() - 2; i++) {
                        if (AT(reelStrip, i) == m_strSelectedcard) {
                            AT(result, reel) = i - (myRandom() % 3) + 1;
                            break;
                        }
                    }
                }
            }
        }
    }
    m_vWinResult = result;

    normalMeter = 0;
    maxMeter = 0;
    BONUS totalBonus = {0, 0};
    int maxDragonMatchCount = 0;
    int Dragon5Matched = 0;
    for (int i = 0; i < m_nWinLine; i++) {
        int j = 1;
        UINT16 meter = ((UINT16)1 << (2 - g_match_lines_10_5[i][0]));
        std::string firstSymbol = AT(AT(reelSet, 0), AT(result, 0) - 1 + g_match_lines_10_5[i][0]);
        maxDragonMatchCount = 0;

        for (; j < m_nMaxMatch; j++) {
            std::string prev_symbol = AT(AT(reelSet, j - 1), AT(result, j - 1) - 1 + g_match_lines_10_5[i][j - 1]);
            std::string cur_symbol = AT(AT(reelSet, j), AT(result, j) - 1 + g_match_lines_10_5[i][j]);

            if (cur_symbol == RgDragonsTreas_dragon) {
                maxDragonMatchCount++;
            }
            if (firstSymbol == RgDragonsTreas_dragon) { // scatter
                firstSymbol = cur_symbol;
            }

            if (firstSymbol == cur_symbol || cur_symbol == RgDragonsTreas_dragon) {
                meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
                continue;
            }
            break;
        }

        if (j < m_mapSymbolMinMatch[firstSymbol] || m_mapSymbolMinMatch[firstSymbol] == 0) {
            continue;
        }
        if (firstSymbol == RgDragonsTreas_dragon) {
            Dragon5Matched = 1;
        }

        // monitor 2 meter
        std::string meterStr = m_mapSymbolMeterGoc[firstSymbol];
        size_t pos = meterStr.find('$');
        if (pos != std::string::npos) {
            meterStr = meterStr.replace(pos, 1, std::to_string(j));
        }

        WinMeter e;
        e.line = i;
        e.meter = meter;
        e.meter2 = g_GrafficObjList.Str2GOCID(meterStr);
        e.symbol = firstSymbol;
        e.weight = j;
        e.start = 0;
        e.bonus = m_Bonus[BetStep()][firstSymbol][j];
        e.sound = MAX_SOUND_IDS;

        totalBonus.coin += e.bonus.coin;
        totalBonus.ag += e.bonus.ag;

        if (e.meter2 != -1) {
            meters.push_back(e);
        }
        if (j == m_nMaxMatch) {
            maxMeter |= meter;
        }
        else {
            normalMeter |= meter;
        }
    }

    int nDragon = CardCount(RgDragonsTreas_dragon);
    if (nDragon >= 3) {
        bCanFreeMode = TRUE;

        // not match dragon 5, and dragon match contains other match
        if (Dragon5Matched == 0 && maxDragonMatchCount < nDragon) {
            UINT16 meter = 0;
            for (int i = 0; i < 3; i++) {
                for (int col = 0; col < m_nReel; col++) {
                    std::string cur_symbol = AT(AT(reelSet, col), AT(result, col) - 1 + i);
                    if (cur_symbol == RgDragonsTreas_dragon) {
                        meter |= ((UINT16)1 << (3 * col + (2 - i)));
                    }
                }
            }

            WinMeter e;
            e.line = 5;
            e.meter = meter;
            e.meter2 = g_GrafficObjList.Str2GOCID("drtrDragon" + std::to_string(nDragon) + "x");
            e.symbol = RgDragonsTreas_dragon;
            e.weight = nDragon;
            e.start = 0;
            e.bonus = m_Bonus[BetStep()][RgDragonsTreas_dragon][nDragon];
            e.sound = MAX_SOUND_IDS;

            normalMeter |= meter;
            totalBonus.coin += e.bonus.coin;
            totalBonus.ag += e.bonus.ag;

            meters.push_back(e);
        }
    }

    if (m_bFreeMode) {
        int colCount = 0;
        int symbolToConvert = 0;
        for (int col = 0; col < m_nReel; col++) {
            int n = CardNumInCol(col, m_strSelectedcard);
            if (n > 0) {
                colCount++;
                symbolToConvert += (3 - n);
            }
        }
        if (colCount >= m_mapSymbolMinMatch[m_strSelectedcard] && m_mapSymbolMinMatch[m_strSelectedcard] > 0) {
            // convert
            UINT32 convertDelay = symbolToConvert * 400;
            WinMeter e;
            e.line = 0xFF;
            e.bonus = {0, 0};
            e.IntWinbonus.push_back({
                0,
                convertDelay,
                {0x01, 0x02, 0x31, 0x00, 0x02, 0x00, 0xb7, 0x17, 0xce, 0x01, 0x00, 0x04} });

            //
            myVector<uint8_t> pkt = {
                0x01, 0x02, 0x31, 0x00, 0x08, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x9c, 0x15, 0x00
            };
            int pktLen = 0;

            // get win match after convert
            myVector<WinMeter> FreeMeters;
            UINT16 FreeNormalMeter = 0;
            for (int i = 0; i < m_nWinLine; i++) {
                UINT16 meter = 0;// ((UINT16)1 << (2 - g_match_lines_10_5[i][0]));
                for (int j = 0; j < m_nMaxMatch; j++) {
                    if (!CardNumInCol(j, m_strSelectedcard)) {
                        continue;
                    }
                    meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
                }
                std::string meterStr = m_mapSymbolMeterGoc[m_strSelectedcard];
                size_t pos = meterStr.find('$');
                if (pos != std::string::npos) {
                    meterStr = meterStr.replace(pos, 1, std::to_string(colCount));
                }

                WinMeter ele;
                ele.line = i;
                ele.meter = meter;
                ele.meter2 = g_GrafficObjList.Str2GOCID(meterStr);
                ele.symbol = m_strSelectedcard;
                ele.weight = colCount;
                ele.start = 0;
                ele.bonus = m_Bonus[BetStep()][m_strSelectedcard][colCount];
                ele.sound = MAX_SOUND_IDS;

                totalBonus.coin += ele.bonus.coin;
                totalBonus.ag += ele.bonus.ag;
                FreeMeters.push_back(ele);

                FreeNormalMeter |= meter;

                pkt.push_back(ele.line);
                pkt.push_back(static_cast<BYTE>(ele.meter & 0xFF));
                pkt.push_back(static_cast<BYTE>((ele.meter >> 8) & 0xFF));
                pkt.push_back(static_cast<BYTE>(ele.meter2 & 0xFF));
                pkt.push_back(static_cast<BYTE>((ele.meter2 >> 8) & 0xFF));
                pkt.push_back(0x01);
                pkt.push_back(0x00);
                pktLen += 7;
            }
            AT(pkt, 4) = 1 + pktLen; //len
            AT(pkt, pkt.size() - 1) = 0x04;
            // refresh meters
            e.IntWinbonus.push_back({ 0, 0, pkt }); 
            meters.push_back(e);
            meters.insert(meters.end(), FreeMeters.begin(), FreeMeters.end());
        }
    }
    m_vWinMeters = meters;
    if (bTest == FALSE) {
        updateCheckPoint();
        if (totalBonus.coin > 0 || totalBonus.ag > 0) {
            m_nFreeModeTotalBonus.coin += totalBonus.coin;
            m_nFreeModeTotalBonus.ag += totalBonus.ag;
            if (meters.size() > 1) {
                BonusSound = getSoundByID(WinSound(totalBonus.coin + totalBonus.ag * 1000));
            }
            else {
                if (AT(meters, 0).line < m_vecLineSounds.size()) {
                    BonusSound = getSoundByID(AT(m_vecLineSounds, AT(meters, 0).line));
                }
                else {
                    BonusSound.duration = 0;
                    BonusSound.soundID = MAX_SOUND_IDS;
                }
            }
        }
    }
    return result;
}

UINT16 RgDragonsTreas::LineSound(UINT Line, std::string symbol, UINT8 weight) {
    if (m_vecLineSounds.size() <= Line) {
        return MAX_SOUND_IDS;
    }
    if (m_vWinMeters.size() <= 1) {
        return MAX_SOUND_IDS;
    }
    return AT(m_vecLineSounds, Line);
}

UINT8 RgDragonsTreas::CardCount(std::string card) {
    int n = 0;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int col = 0; col < m_nReel; col++) {
        int k = 0;
        for (; k < 3; k++) {
            std::string s = AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k);
            if (s == card) {
                n++;
            }
        }
    }
    return n;
}

BOOL RgDragonsTreas::DragonInCol(int col) {
    return CardNumInCol(col, RgDragonsTreas_dragon);   
}

UINT8 RgDragonsTreas::CardNumInCol(int col, std::string card) {
    int n = 0;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);
    for (int k = 0; k < 3; k++) {
        std::string s = AT(AT(reelSet, col), AT(m_vWinResult, col) - 1 + k);
        if (s == card) {
            n++;
        }
    }
    return n;
}

UINT16 RgDragonsTreas::SpinTime_MS() {
    if (CardCount(RgDragonsTreas_dragon) >= 3) {
        return 3500;
    }
    if (CardCount(RgDragonsTreas_dragon) == 2 && DragonInCol(4) == FALSE) {
        return 3500;
    }
    return 2000;
}

BOOL RgDragonsTreas::CanFreeMode() {
    if (CardCount(RgDragonsTreas_dragon) >= 3) {
        return TRUE;
    }
    return FALSE;
}

myVector<InterruptPacketData> RgDragonsTreas::InterruptBeforeSpin() {
    myVector<InterruptPacketData> packets;
    if (!m_bFreeMode) {
        return packets;
    }
    m_nFreeModeGoneSpin++;
    updateCheckPoint();

    UINT8 gone = (m_nFreeModeGoneSpin ? m_nFreeModeGoneSpin : 1);

    // display total & remain free spin count
    packets.push_back({
        0,
        0,
        {
            0x01, 0x02, 0x30, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), gone, 0x00, m_nFreeModeTotalSpin, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa5, 0x04
        }
        });
    return packets;
}

myVector<InterruptPacketData> RgDragonsTreas::InterruptAfterMoveBonus(BOOL& EndFree) {
    myVector<InterruptPacketData> packets;
    if (m_nFreeModeGoneSpin >= m_nFreeModeTotalSpin) {
        EndFree = TRUE;
        m_bFreeMode = FALSE;

        m_Bonus = m_BonusCp;

        packets.push_back({
            100,
            0,
            {0x06, 0xb7, 0x17, 0x01, 0x02, 0x30, 0x00, 0xb7, 0x17, 0x01, 0x00, 
            static_cast<BYTE>(m_nFreeModeTotalBonus.coin & 0xFF), 
            static_cast<BYTE>((m_nFreeModeTotalBonus.coin >> 8) & 0xFF), 
            static_cast<BYTE>((m_nFreeModeTotalBonus.coin >> 16) & 0xFF),
            static_cast<BYTE>((m_nFreeModeTotalBonus.coin >> 24) & 0xFF),
            0x0a, 0x00, 0xab, 0x04} });
        
        packets.push_back({
            2000,
            0,
            {0x01, 0x02, 0x30, 0x00, 0xb7, 0x17, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xac, 0x04} });
        updateCheckPoint();
        return packets;
    }
    EndFree = FALSE;

    //m_nFreeModeGoneSpin++;
    updateCheckPoint();
    return packets;
}


myVector<InterruptPacketData> RgDragonsTreas::EnterFreeGame(std::string check) {
    m_bFreeMode = TRUE;

    m_nFreeModeTotalSpin = 10;
    m_nFreeModeGoneSpin = 0;

    m_nFreeModeTotalBonus = {0, 0};

    m_Bonus = m_FreeModeBonus;

    myVector<InterruptPacketData> packets;
    if (check != "") {
        myVector<int> values = ParseCheckPoint(check, "F", 5);
        if (values.size() == 5) {
            m_strSelectedcard = AT(m_vecSymbols, AT(values, 0));
            m_nFreeModeTotalSpin = AT(values, 1);
            m_nFreeModeGoneSpin = AT(values, 2);
            m_nFreeModeTotalBonus.coin = AT(values, 3);
            m_nFreeModeTotalBonus.ag = AT(values, 4);

            UINT16 selectedGOC = g_GrafficObjList.Str2GOCID(m_strSelectedcard);

            UINT8 gone = (m_nFreeModeGoneSpin ? m_nFreeModeGoneSpin : 1);
            packets.push_back({
                0,
                0,
                {0x01, 0x02, 0x30, 0x00, 0xb7, 0x17, gone, 0x00, m_nFreeModeTotalSpin, 0x00, 0x00, 0x00,
                static_cast<BYTE>(selectedGOC & 0xFF), static_cast<BYTE>((selectedGOC >> 8) & 0xFF),
                0xa3, 0x04} });
            return packets;
        }
    }
    else {
        updateCheckPoint();
    }
    // show select dialog
    packets.push_back({
        500,
        9500,
        {0x06, 0x23, 0x59, 0x01, 0x02, 0x30, 0x00, 0xb7, 0x17, 0x0a, 0x00, 0x01, 0x00, 0x0a, 0x00, 0x00, 0x00, 0xa6, 0x04} }
    );
    
    return packets;
}

int RgDragonsTreas::LineSwapDelay(int WinIdx) {
    return 400;
}


myVector<UINT8> RgDragonsTreas::ShowTotalWinLines(myVector<WinMeter> SpinMeters) {
    myVector<uint8_t> packet = {
        0x06, 0x30, 0x59, 0x01, 0x02, 0x31, 0x00,
        0x0F, 0x00,  // Placeholder for length 
        0x0F, 0x11, // GameID
        0x9C, 0x13, 0x01
    };
    myVector<UINT8> TotalMatch;
    for (int i = 0; i < SpinMeters.size(); i++) {
        if (AT(SpinMeters, i).line == 0xFF) { // clear after convert action
            TotalMatch.clear();
            continue;
        }
        TotalMatch.push_back(AT(SpinMeters, i).line);
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter >> 8) & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>(AT(SpinMeters, i).meter2 & 0xFF));
        TotalMatch.push_back(static_cast<BYTE>((AT(SpinMeters, i).meter2 >> 8) & 0xFF));
    }
    if (TotalMatch.size() < 10) {
        myVector<UINT8> _;
        return _;
    }
    UINT16 pktLen = 1 + (TotalMatch.size() / 5) * 7;
    AT(packet, 7) = static_cast<BYTE>(pktLen & 0xFF);
    AT(packet, 8) = static_cast<BYTE>((pktLen >> 8) & 0xFF);
    AT(packet, 9) = static_cast<BYTE>(m_nGameID & 0xFF);
    AT(packet, 10) = static_cast<BYTE>((m_nGameID >> 8) & 0xFF);
    int entryCount = static_cast<int>(TotalMatch.size() / 5);
    for (int i = 0; i < entryCount; ++i) {
        packet.push_back(AT(TotalMatch, i * 5 + 0)); // Line
        packet.push_back(AT(TotalMatch, i * 5 + 1)); // Meter low byte
        packet.push_back(AT(TotalMatch, i * 5 + 2)); // Meter high byte
        packet.push_back(AT(TotalMatch, i * 5 + 3)); // Meter2 low byte
        packet.push_back(AT(TotalMatch, i * 5 + 4)); // Meter2 high byte
        packet.push_back(0x01);      // Status or flag 1
        packet.push_back(0x01);      // Status or flag 2
    }
    // Mark the end of the packet
    packet.back() = 0x04;
    return packet;
}

myVector<InterruptPacketData> RgDragonsTreas::SelectSymbol(std::string symbol) {
    m_strSelectedcard = symbol;
    UINT16 symbolGOC = g_GrafficObjList.Str2GOCID(m_strSelectedcard);
    myVector<InterruptPacketData> packets;
    // selected symbol
    packets.push_back({
        0,
        6500,
        {0x01, 0x02, 0x30, 0x00, 0xb7, 0x17, 0x0a, 0x00, 0x01, 0x00, 0x00, 0x00, 
        static_cast<BYTE>(symbolGOC & 0xFF), static_cast<BYTE>((symbolGOC >> 8) & 0xFF), 0xa7, 0x04 } });
    return packets;
}

bool RgDragonsTreas::RTP_force_bigWin() {
    return (myRandom() % 100 == 0); // 1.2%
}

BOOL RgDragonsTreas::SelectedableReelsInFreeGame(myVector<UINT8> result) {
    if (m_bFreeMode == FALSE) {
        return TRUE;
    }
    myVector<UINT8> cp = m_vWinResult;
    m_vWinResult = result;
    int n = CardCount(RgDragonsTreas_dragon);
    m_vWinResult = cp;
    if (n >= 3) {
        return FALSE;
    }
    return TRUE;
}

void RgDragonsTreas::updateCheckPoint() {
    std::ostringstream oss;
    oss << " P" << m_nCurrentReelPlan
        << " B"
        << static_cast<int>(AT(m_vWinResult, 0)) << ":"
        << static_cast<int>(AT(m_vWinResult, 1)) << ":"
        << static_cast<int>(AT(m_vWinResult, 2)) << ":"
        << static_cast<int>(AT(m_vWinResult, 3)) << ":"
        << static_cast<int>(AT(m_vWinResult, 4)) << " ";

    if (m_bFreeMode) {
        int idx = 0;
        auto it = std::find(m_vecSymbols.begin(), m_vecSymbols.end(), m_strSelectedcard);
        if (it != m_vecSymbols.end()) {
            idx = std::distance(m_vecSymbols.begin(), it);
        }
        oss << " F"
            << static_cast<int>(idx) << ":"
            << static_cast<int>(m_nFreeModeTotalSpin) << ":"
            << static_cast<int>(m_nFreeModeGoneSpin) << ":"
            << static_cast<int>(m_nFreeModeTotalBonus.coin) << ":"
            << static_cast<int>(m_nFreeModeTotalBonus.ag)
            << " ";
    }
    m_strCheckPoint = oss.str();
}