#include "stdafx.h"
#include "RgLosFrootosPS1.h"
#include <set>

RgLosFrootosPS1::RgLosFrootosPS1() {
    m_nReel = 5;
    m_nWinLine = 10;
    m_nMaxMatch = 5;
    m_nBetStep = 0;

    m_strGameName = "RgLosFrootos";

    myVector<UINT16> m_vecBetSteps_tmp;
    m_vecBetSteps_tmp.push_back(10);
    m_vecBetSteps_tmp.push_back(20);
    m_vecBetSteps_tmp.push_back(30);
    m_vecBetSteps_tmp.push_back(40);
    m_vecBetSteps_tmp.push_back(50);
    m_vecBetSteps_tmp.push_back(60);
    m_vecBetSteps_tmp.push_back(80);
    m_vecBetSteps_tmp.push_back(100);
    m_vecBetSteps_tmp.push_back(150);
    m_vecBetSteps_tmp.push_back(200);
#ifdef BIGBET_ACTIVE
    m_vecBetSteps_tmp.push_back(500);
    m_vecBetSteps_tmp.push_back(1000);
#endif
    LoadBets();

    m_vecSymbols.push_back("lofrHV1_PS");
    m_vecSymbols.push_back("lofrHV2_PS");
    m_vecSymbols.push_back("lofrHV3_PS");
    m_vecSymbols.push_back("lofrHV4_PS");
    m_vecSymbols.push_back("lofrHV5_PS");
    m_vecSymbols.push_back("lofrHV6_PS");
    m_vecSymbols.push_back("lofrHV7_PS");

    m_mapSymbolMinMatch["lofrHV1_PS"] = 3;
    m_mapSymbolMinMatch["lofrHV2_PS"] = 3;
    m_mapSymbolMinMatch["lofrHV3_PS"] = 3;
    m_mapSymbolMinMatch["lofrHV4_PS"] = 3;
    m_mapSymbolMinMatch["lofrHV5_PS"] = 3;
    m_mapSymbolMinMatch["lofrHV6_PS"] = 3;
    m_mapSymbolMinMatch["lofrHV7_PS"] = 3;

    m_mapSymbolMeterGoc["lofrHV1_PS"] = "lofrHV1_$x";
    m_mapSymbolMeterGoc["lofrHV2_PS"] = "lofrHV2_$x";
    m_mapSymbolMeterGoc["lofrHV3_PS"] = "lofrHV3_$x";
    m_mapSymbolMeterGoc["lofrHV4_PS"] = "lofrHV4_$x";
    m_mapSymbolMeterGoc["lofrHV5_PS"] = "lofrH56_$x";
    m_mapSymbolMeterGoc["lofrHV6_PS"] = "lofrH56_$x";
    m_mapSymbolMeterGoc["lofrHV7_PS"] = "lofrHV7_$x";

    m_vecWinLines.push_back("lofrWinline01_01");
    m_vecWinLines.push_back("lofrWinline01_02");
    m_vecWinLines.push_back("lofrWinline01_03");
    m_vecWinLines.push_back("lofrWinline01_04");
    m_vecWinLines.push_back("lofrWinline01_05");
    m_vecWinLines.push_back("lofrWinline01_06");
    m_vecWinLines.push_back("lofrWinline01_07");
    m_vecWinLines.push_back("lofrWinline01_08");
    m_vecWinLines.push_back("lofrWinline01_09");
    m_vecWinLines.push_back("lofrWinline01_10");

    m_vecLineSounds.push_back(SMP_LOFR_MW_1);
    m_vecLineSounds.push_back(SMP_LOFR_MW_2);
    m_vecLineSounds.push_back(SMP_LOFR_MW_3);
    m_vecLineSounds.push_back(SMP_LOFR_MW_4);
    m_vecLineSounds.push_back(SMP_LOFR_MW_5);
    m_vecLineSounds.push_back(SMP_LOFR_MW_6);
    m_vecLineSounds.push_back(SMP_LOFR_MW_7);
    m_vecLineSounds.push_back(SMP_LOFR_MW_8);
    m_vecLineSounds.push_back(SMP_LOFR_MW_9);
    m_vecLineSounds.push_back(SMP_LOFR_MW_10);

    m_vecReelStripPlan.push_back("0");
    m_vecReelStripPlan.push_back("1");
    m_vecReelStripPlan.push_back("2");
    m_vecReelStripPlan.push_back("3");
    
    m_nCurrentReelPlan = 0;
    m_shCurrentReelStrip = g_GrafficObjList.Str2GOCID(AT(m_vecReelStripPlan, m_nCurrentReelPlan));

    char* lofrReelStrip[] = {
        "lofrHV1_PS,lofrHV4_PS,lofrHV4_PS,lofrHV4_PS,lofrHV3_PS,lofrHV1_PS,lofrHV3_PS,lofrHV3_PS,lofrHV6_PS,lofrHV6_PS,lofrHV7_PS,lofrHV7_PS,lofrHV7_PS,lofrHV4_PS,lofrHV1_PS,lofrHV6_PS,lofrHV6_PS,lofrHV6_PS,lofrHV2_PS,lofrHV5_PS,lofrHV2_PS,lofrHV5_PS,lofrHV5_PS,lofrHV5_PS,lofrHV5_PS,lofrHV4_PS",
        "lofrHV1_PS,lofrHV4_PS,lofrHV7_PS,lofrHV7_PS,lofrHV7_PS,lofrHV3_PS,lofrHV1_PS,lofrHV3_PS,lofrHV3_PS,lofrHV6_PS,lofrHV6_PS,lofrHV7_PS,lofrHV7_PS,lofrHV7_PS,lofrHV5_PS,lofrHV5_PS,lofrHV5_PS,lofrHV7_PS,lofrHV7_PS,lofrHV2_PS,lofrHV5_PS,lofrHV2_PS,lofrHV5_PS,lofrHV5_PS,lofrHV5_PS,lofrHV5_PS,lofrHV4_PS",
        "lofrHV1_PS,lofrHV4_PS,lofrHV4_PS,lofrHV4_PS,lofrHV3_PS,lofrHV1_PS,lofrHV3_PS,lofrHV3_PS,lofrHV6_PS,lofrHV6_PS,lofrHV4_PS,lofrHV4_PS,lofrHV4_PS,lofrHV4_PS,lofrHV6_PS,lofrHV6_PS,lofrHV6_PS,lofrHV7_PS,lofrHV7_PS,lofrHV2_PS,lofrHV5_PS,lofrHV2_PS,lofrHV5_PS,lofrHV6_PS,lofrHV6_PS,lofrHV6_PS,lofrHV4_PS",
        "lofrHV4_PS,lofrHV4_PS,lofrHV4_PS,lofrHV3_PS,lofrHV2_PS,lofrHV6_PS,lofrHV6_PS,lofrHV6_PS,lofrHV1_PS,lofrHV5_PS,lofrHV5_PS,lofrHV5_PS,lofrHV2_PS,lofrHV7_PS,lofrHV7_PS,lofrHV7_PS,lofrHV1_PS",

        "lofrHV1_PS,lofrHV5_PS,lofrHV5_PS,lofrHV5_PS,lofrHV2_PS,lofrHV2_PS,lofrHV1_PS,lofrHV2_PS,lofrHV7_PS,lofrHV7_PS,lofrHV7_PS,lofrHV1_PS,lofrHV4_PS,lofrHV4_PS,lofrHV4_PS,lofrHV6_PS,lofrHV6_PS,lofrHV4_PS,lofrHV4_PS,lofrHV3_PS,lofrHV6_PS,lofrHV6_PS,lofrHV6_PS,lofrHV5_PS,lofrHV3_PS,lofrHV3_PS,lofrHV5_PS",
        "lofrHV1_PS,lofrHV4_PS,lofrHV4_PS,lofrHV4_PS,lofrHV2_PS,lofrHV2_PS,lofrHV1_PS,lofrHV2_PS,lofrHV6_PS,lofrHV6_PS,lofrHV4_PS,lofrHV4_PS,lofrHV4_PS,lofrHV5_PS,lofrHV6_PS,lofrHV6_PS,lofrHV6_PS,lofrHV4_PS,lofrHV4_PS,lofrHV6_PS,lofrHV6_PS,lofrHV6_PS,lofrHV3_PS,lofrHV6_PS,lofrHV7_PS,lofrHV3_PS,lofrHV3_PS,lofrHV5_PS",
        "lofrHV1_PS,lofrHV5_PS,lofrHV5_PS,lofrHV5_PS,lofrHV2_PS,lofrHV2_PS,lofrHV1_PS,lofrHV2_PS,lofrHV7_PS,lofrHV7_PS,lofrHV7_PS,lofrHV7_PS,lofrHV5_PS,lofrHV5_PS,lofrHV5_PS,lofrHV5_PS,lofrHV7_PS,lofrHV4_PS,lofrHV4_PS,lofrHV7_PS,lofrHV7_PS,lofrHV7_PS,lofrHV3_PS,lofrHV7_PS,lofrHV6_PS,lofrHV3_PS,lofrHV3_PS,lofrHV5_PS",
        "lofrHV4_PS,lofrHV4_PS,lofrHV4_PS,lofrHV3_PS,lofrHV2_PS,lofrHV6_PS,lofrHV6_PS,lofrHV6_PS,lofrHV1_PS,lofrHV5_PS,lofrHV5_PS,lofrHV5_PS,lofrHV2_PS,lofrHV7_PS,lofrHV7_PS,lofrHV7_PS,lofrHV1_PS",

        "lofrHV1_PS,lofrHV6_PS,lofrHV7_PS,lofrHV7_PS,lofrHV7_PS,lofrHV1_PS,lofrHV5_PS,lofrHV5_PS,lofrHV5_PS,lofrHV1_PS,lofrHV5_PS,lofrHV2_PS,lofrHV2_PS,lofrHV6_PS,lofrHV2_PS,lofrHV6_PS,lofrHV6_PS,lofrHV6_PS,lofrHV3_PS,lofrHV3_PS,lofrHV4_PS,lofrHV3_PS,lofrHV4_PS,lofrHV4_PS,lofrHV4_PS",
        "lofrHV1_PS,lofrHV6_PS,lofrHV6_PS,lofrHV7_PS,lofrHV7_PS,lofrHV7_PS,lofrHV5_PS,lofrHV5_PS,lofrHV5_PS,lofrHV1_PS,lofrHV5_PS,lofrHV2_PS,lofrHV2_PS,lofrHV7_PS,lofrHV2_PS,lofrHV7_PS,lofrHV7_PS,lofrHV7_PS,lofrHV3_PS,lofrHV3_PS,lofrHV4_PS,lofrHV3_PS,lofrHV5_PS,lofrHV5_PS,lofrHV5_PS",
        "lofrHV1_PS,lofrHV6_PS,lofrHV6_PS,lofrHV6_PS,lofrHV7_PS,lofrHV7_PS,lofrHV4_PS,lofrHV4_PS,lofrHV4_PS,lofrHV1_PS,lofrHV5_PS,lofrHV2_PS,lofrHV2_PS,lofrHV6_PS,lofrHV2_PS,lofrHV6_PS,lofrHV6_PS,lofrHV6_PS,lofrHV3_PS,lofrHV3_PS,lofrHV4_PS,lofrHV3_PS,lofrHV4_PS,lofrHV4_PS,lofrHV4_PS",
        "lofrHV4_PS,lofrHV4_PS,lofrHV4_PS,lofrHV3_PS,lofrHV2_PS,lofrHV6_PS,lofrHV6_PS,lofrHV6_PS,lofrHV1_PS,lofrHV5_PS,lofrHV5_PS,lofrHV5_PS,lofrHV2_PS,lofrHV7_PS,lofrHV7_PS,lofrHV7_PS,lofrHV1_PS",

        "lofrHV1_PS,lofrHV4_PS,lofrHV4_PS,lofrHV4_PS,lofrHV7_PS,lofrHV1_PS,lofrHV4_PS,lofrHV5_PS,lofrHV5_PS,lofrHV5_PS,lofrHV3_PS,lofrHV3_PS,lofrHV7_PS,lofrHV7_PS,lofrHV7_PS,lofrHV6_PS,lofrHV4_PS,lofrHV1_PS,lofrHV6_PS,lofrHV6_PS,lofrHV6_PS,lofrHV5_PS,lofrHV5_PS,lofrHV2_PS,lofrHV2_PS,lofrHV6_PS",
        "lofrHV1_PS,lofrHV4_PS,lofrHV4_PS,lofrHV4_PS,lofrHV4_PS,lofrHV1_PS,lofrHV4_PS,lofrHV5_PS,lofrHV5_PS,lofrHV5_PS,lofrHV3_PS,lofrHV3_PS,lofrHV7_PS,lofrHV7_PS,lofrHV7_PS,lofrHV6_PS,lofrHV7_PS,lofrHV6_PS,lofrHV6_PS,lofrHV6_PS,lofrHV5_PS,lofrHV5_PS,lofrHV2_PS,lofrHV2_PS,lofrHV6_PS",
        "lofrHV1_PS,lofrHV4_PS,lofrHV4_PS,lofrHV4_PS,lofrHV4_PS,lofrHV1_PS,lofrHV4_PS,lofrHV5_PS,lofrHV5_PS,lofrHV5_PS,lofrHV3_PS,lofrHV3_PS,lofrHV7_PS,lofrHV7_PS,lofrHV7_PS,lofrHV6_PS,lofrHV7_PS,lofrHV6_PS,lofrHV6_PS,lofrHV6_PS,lofrHV5_PS,lofrHV5_PS,lofrHV2_PS,lofrHV2_PS,lofrHV6_PS",
        "lofrHV4_PS,lofrHV4_PS,lofrHV4_PS,lofrHV3_PS,lofrHV2_PS,lofrHV6_PS,lofrHV6_PS,lofrHV6_PS,lofrHV1_PS,lofrHV5_PS,lofrHV5_PS,lofrHV5_PS,lofrHV2_PS,lofrHV7_PS,lofrHV7_PS,lofrHV7_PS,lofrHV1_PS",

        "lofrHV1_PS,lofrHV4_PS,lofrHV4_PS,lofrHV6_PS,lofrHV6_PS,lofrHV6_PS,lofrHV1_PS,lofrHV7_PS,lofrHV7_PS,lofrHV2_PS,lofrHV2_PS,lofrHV5_PS,lofrHV5_PS,lofrHV5_PS,lofrHV3_PS,lofrHV3_PS,lofrHV4_PS,lofrHV4_PS,lofrHV4_PS,lofrHV6_PS,lofrHV6_PS,lofrHV1_PS,lofrHV7_PS,lofrHV7_PS,lofrHV7_PS,lofrHV5_PS,lofrHV5_PS",
        "lofrHV1_PS,lofrHV4_PS,lofrHV4_PS,lofrHV6_PS,lofrHV6_PS,lofrHV6_PS,lofrHV7_PS,lofrHV7_PS,lofrHV2_PS,lofrHV2_PS,lofrHV5_PS,lofrHV5_PS,lofrHV5_PS,lofrHV3_PS,lofrHV3_PS,lofrHV4_PS,lofrHV4_PS,lofrHV4_PS,lofrHV6_PS,lofrHV6_PS,lofrHV1_PS,lofrHV7_PS,lofrHV7_PS,lofrHV7_PS,lofrHV5_PS,lofrHV5_PS",
        "lofrHV1_PS,lofrHV4_PS,lofrHV4_PS,lofrHV6_PS,lofrHV6_PS,lofrHV6_PS,lofrHV7_PS,lofrHV7_PS,lofrHV2_PS,lofrHV2_PS,lofrHV5_PS,lofrHV5_PS,lofrHV5_PS,lofrHV3_PS,lofrHV3_PS,lofrHV4_PS,lofrHV4_PS,lofrHV4_PS,lofrHV6_PS,lofrHV6_PS,lofrHV1_PS,lofrHV7_PS,lofrHV7_PS,lofrHV7_PS,lofrHV5_PS,lofrHV5_PS",
        "lofrHV4_PS,lofrHV4_PS,lofrHV4_PS,lofrHV3_PS,lofrHV2_PS,lofrHV6_PS,lofrHV6_PS,lofrHV6_PS,lofrHV1_PS,lofrHV5_PS,lofrHV5_PS,lofrHV5_PS,lofrHV2_PS,lofrHV7_PS,lofrHV7_PS,lofrHV7_PS,lofrHV1_PS",
    };

    for (int i = 0; i < m_vecReelStripPlan.size(); i++) {
        ReelSet set;
        for (int j = 0; j < m_nReel; j++) {
            ReelStrip strip;
            std::stringstream ss(lofrReelStrip[j * m_vecReelStripPlan.size() + i]);
            std::string item;
            while (std::getline(ss, item, ',')) {
                strip.push_back(item);
            }
            set.push_back(strip);
        }
        m_vecReelStripSets.push_back(set);
    }

    std::map<UINT8, std::map<std::string, std::map<UINT8, BONUS>>> m_Bonus_tmp;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        std::map<std::string, std::map<UINT8, BONUS>> perSym;
        std::map<UINT8, BONUS> e;
        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 10; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 30; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 150; e[5].ag = 0;
        perSym["lofrHV7_PS"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 200; e[5].ag = 0;
        perSym["lofrHV6_PS"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 200; e[5].ag = 0;
        perSym["lofrHV5_PS"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 20; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 200; e[5].ag = 0;
        perSym["lofrHV4_PS"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 50; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 200; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 500; e[5].ag = 0;
        perSym["lofrHV3_PS"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 75; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 500; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 1500; e[5].ag = 0;
        perSym["lofrHV2_PS"] = e;
        e.clear();

        e[3].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 100; e[3].ag = 0;
        e[4].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 1000; e[4].ag = 0;
        e[5].coin = AT(m_vecBetSteps_tmp, i) / AT(m_vecBetSteps_tmp, 0) * 5000; e[5].ag = 0;
        perSym["lofrHV1_PS"] = e;
        e.clear();

        m_Bonus_tmp[i] = perSym;
    }

    BOOL start = FALSE;
    int idx = 0;
    for (int i = 0; i < m_vecBetSteps_tmp.size(); i++) {
        if (start == FALSE) {
            // check start point
            if (AT(m_vecBetSteps_tmp, i) < AT(m_vecBetSteps, 0)) {
                continue;
            }
            start = TRUE;
        }
        m_Bonus[idx++] = m_Bonus_tmp[i];
        if (AT(m_vecBetSteps_tmp, i) == AT(m_vecBetSteps, m_vecBetSteps.size() - 1)) {
            break;
        }
    }

    m_vecBetSteps_05.clear();
    m_vecBetSteps_10.clear();
    PrintAllBonus();
}

UINT16 RgLosFrootosPS1::Init(UINT8 betStep) {
    m_nBetStep = betStep;
    m_nCurrentReelPlan = (myRandom() % m_vecReelStripPlan.size());
    m_shCurrentReelStrip = static_cast<uint16_t>(std::stoi(AT(m_vecReelStripPlan, m_nCurrentReelPlan)));
    return m_shCurrentReelStrip;
}

void RgLosFrootosPS1::ChangeReelStrip(UINT16 NewReelPlan) {
    m_nCurrentReelPlan = NewReelPlan;
    m_shCurrentReelStrip = static_cast<uint16_t>(std::stoi(AT(m_vecReelStripPlan, m_nCurrentReelPlan)));
}

myVector<UINT8> RgLosFrootosPS1::Win(myVector<WinMeter>& meters, UINT64& normalMeter, UINT64& maxMeter, SoundItem& BonusSound, BOOL bTest, myVector<UINT8> _result, BOOL& bCanFreeMode) {
    m_bPrevSpinMatchedActive = FALSE;

    myVector<UINT8> result;
    ReelSet reelSet = AT(m_vecReelStripSets, m_nCurrentReelPlan);

    if (bTest) {
        std::string matchSymbol = AT(m_vecSymbols, myRandom() % m_vecSymbols.size());
        int line = (myRandom() % m_nWinLine);
        int weight = 1 + (myRandom() % 5);
        for (int i = 0; i < m_nReel; i++) {
            ReelStrip reelStrip = AT(reelSet, i);
            int len = reelStrip.size() - 3;

            int valid_i[0x100];
            int valid_count = 0;
            for (int j = 0; j <= len; j++) {
                if (weight > i) {
                    if (matchSymbol == AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
                else {
                    if (matchSymbol != AT(reelStrip, j + g_match_lines_10_5[line][i])) {
                        valid_i[valid_count++] = j;
                    }
                }
            }
            if (valid_count > 0) {
                int rand_index = myRandom() % valid_count;
                int chosen_i = valid_i[rand_index];
                result.push_back(chosen_i + 1);
            }
            else {
                result.push_back((myRandom() % (len - 1)) + 1);
            }
        }
    }
    else {
        result = _result;
    }
    m_vWinResult = result;

    normalMeter = 0;
    maxMeter = 0;
    UINT16 totalBonus = 0;
    for (int i = 0; i < m_nWinLine; i++) {
        int j = 1;
        UINT16 meter = ((UINT16)1 << (2 - g_match_lines_10_5[i][0]));

        for (; j < m_nMaxMatch; j++) {
            if (AT(AT(reelSet, j - 1), AT(result, j - 1) - 1 + g_match_lines_10_5[i][j - 1]) == AT(AT(reelSet, j), AT(result, j) - 1 + g_match_lines_10_5[i][j])) {

                meter |= ((UINT16)1 << (3 * j + 2 - g_match_lines_10_5[i][j]));
                continue;
            }
            break;
        }
        std::string firstSymbol = AT(AT(reelSet, 0), AT(result, 0) - 1 + g_match_lines_10_5[i][0]);
        if (j < m_mapSymbolMinMatch[firstSymbol]) {
            continue;
        }

        // monitor 2 meter
        std::string meterStr = m_mapSymbolMeterGoc[firstSymbol];
        size_t pos = meterStr.find('$');
        if (pos != std::string::npos) {
            meterStr = meterStr.replace(pos, 1, std::to_string(j));
        }

        WinMeter e;
        e.line = i;
        e.meter = meter;
        e.meter2 = g_GrafficObjList.Str2GOCID(meterStr);

        e.symbol = firstSymbol;
        e.weight = j;
        e.start = 0;
        e.bonus = m_Bonus[BetStep()][firstSymbol][j];
        e.sound = MAX_SOUND_IDS;

        e.gameId = GOC_RgLosFrootosPS1;
        e.gamePlan = m_shCurrentReelStrip;
        e.psIdx = 0;

        totalBonus += e.bonus.coin;

        if (e.meter2 != -1) {
            meters.push_back(e);
        }
        if (j == m_nMaxMatch) {
            maxMeter |= meter;
        }
        else {
            normalMeter |= meter;
        }
        if (bTest == FALSE) {
            m_bPrevSpinMatchedActive = TRUE;
        }
    }
    if (bTest == FALSE) {
        myVector<std::string> winSymbols;
        for (int i = 0; i < meters.size(); i++) {
            winSymbols.push_back(AT(meters, i).symbol);
        }
        m_TransSymbol = "";
        if (winSymbols.size() > 0) {
            if ((myRandom() & 2) == 0) {
                m_TransSymbol = AT(winSymbols, myRandom() % winSymbols.size());
            }
        }
        m_bPrevSpinMatchedActive = TRUE;
    }
    m_vWinMeters = meters;
    return result;
}

UINT16 RgLosFrootosPS1::GetTransSymbolGOC() {
    if (m_TransSymbol != "") {
        return g_GrafficObjList.Str2GOCID(m_TransSymbol);
    }
    return 0;
}

myVector<InterruptPacketData> RgLosFrootosPS1::InterruptAfterSpin() {
    myVector<InterruptPacketData> pkt;
    if (m_TransSymbol != "") {
        UINT16 goc = g_GrafficObjList.Str2GOCID(m_TransSymbol);
        pkt.push_back({ 0, 0, {0x01, 0x02, 0x28, 0x00, 0x69, 0x0B, 0x01, 0x00,
            static_cast<BYTE>(goc & 0xFF), static_cast<BYTE>((goc >> 8) & 0xFF), 0x04, 0x06, 0xac, 0x38} });
    }
    return pkt;
}