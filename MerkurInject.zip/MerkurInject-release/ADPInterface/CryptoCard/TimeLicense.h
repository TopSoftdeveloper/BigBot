#pragma once

#include <Windows.h>
#include <atomic>
#include <cstdint>

namespace TimeLicense {

/// Full path: game exe directory plus "\\dialog\\time.io" (same base folder as dialog assets).
const wchar_t* GetLicenseFilePath();

void OnInitSerialDone();

/// Cached 8-digit machine id (hash of BIOS serial + MAC).
uint32_t GetMachineId8();

bool IsLicensedOk();

/// Request showing license dialog (e.g. from RunNewGame or monitor thread). Consumed from StateMachine::Loop when status is STATUS_Lobby.
void RequestLicenseDialog();

/// Shows modal only when called; caller should invoke from lobby (see StateMachine::Loop).
void PollLicenseDialogQueue();

/// Validate 12-digit code for this machine and write dialog\\time.io next to the game exe. Optional errMsg explains failure.
bool ValidateAndApplyEnteredCode(uint64_t code12, wchar_t* errMsg = nullptr, size_t errCch = 0);

/// Load/refresh license file and clock monotonicity.
void RefreshFromDisk();

/// Fills buf with a line like "Valid until: April 2026" when the license file is valid for this machine.
bool TryGetValidUntilDisplayText(wchar_t* buf, size_t cch);

void StartMonitorThread();

} // namespace TimeLicense
