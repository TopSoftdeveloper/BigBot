#ifndef __PlayDB_H__
#define __PlayDB_H__

#include "Windows.h"
#include <map>
#include <string>
#include <sqlite3.h>

using namespace std;

class PlayDB
{
public:
    enum GameVariant
    {
        GAME_VARIANT_A,
        GAME_VARIANT_B,
        GAME_VARIANT_C,
    };

private:
    struct BetInfo
    {
        string gameID;
        int betMin5;
        int betMax5;
        int betMin10;
        int betMax10;
        int betSteps5[20];
        int betSteps10[20];
        bool isMMcode;
    };

    struct GameSettings
    {
        int gameCount;
        BetInfo betInfo[MAX_GAME_COUNT];
        GameVariant gameVariant;
        string settingpassword;
        string bookkeepingpassword;
        string gameNames[MAX_GAME_COUNT];
    };

    struct GamePlaySettings
    {
        double gameCredit;
        int mmcodeDate;
    };

    struct GameBookKeeping
    {
        string gameID;
        double playedpoints;
        double wonpoints;
        int spins;
    };

    struct GameBookKeepingList
    {
        GameBookKeeping gameBookKeeping[MAX_GAME_COUNT];
        string beginDate;
        double totalin;
        double totalout;
        int mmcodeCount;
    };

public:

	static PlayDB& GetInstance();
    string GetSettingPassword();
    string GetBookkeepingPassword();
    void SetSettingPassword(const string& password);
    void SetBookkeepingPassword(const string& password);
    int GetGameCount();
    int GetGameID(string gameID);
    string GetGameName(int index);
    void GetBetInfo(int index, int betSteps5[20], int betSteps10[20], int& betMin5, int& betMax5, int& betMin10, int& betMax10);
    void SetBetInfo(int index, int betSteps5[20], int betSteps10[20], int betMin5, int betMax5, int betMin10, int betMax10);
    PlayDB::GameVariant GetGameVariant();
    void SetGameVariant(GameVariant variant);
    void ResetGameSettings();
    void ResetMainBookData();
    void ResetSubBookData();
    void SaveResettedAny();
    void AddGamePlayData(string gameID, double playedpoints, double wonpoints, int spins);
    void AddPayinData(int credit);
    void AddPayoutData();
    void AddMMCodeCount();
    void SetPayoutCallback(void (*callback)());
    void CallPayoutCallback();
    void SetGameCreditData(double credit);
    double GetGameCreditData();
    time_t GetMMcodeDate();
    void SetMMcodeDate();
    void ClearMMcodeDate();
    void Save();
    void Load();
    
    // Bookkeeping data access methods
    string GetMainBookBeginDate();
    double GetMainBookTotalIn();
    double GetMainBookTotalOut();
    string GetMainBookGameID(int index);
    double GetMainBookPlayedPoints(int index);
    double GetMainBookWonPoints(int index);
    int GetMainBookSpins(int index);
    int GetMainBookMMCodeCount();
    int GetMainBookTotalSpins();
    void GetMainBookTotalBetandWin(double& totalBet, double& totalWin);
    
    string GetSubBookBeginDate();
    double GetSubBookTotalIn();
    double GetSubBookTotalOut();
    string GetSubBookGameID(int index);
    double GetSubBookPlayedPoints(int index);
    double GetSubBookWonPoints(int index);
    int GetSubBookSpins(int index);
    int GetSubBookMMCodeCount();
    int GetSubBookTotalSpins();

    void GetSubBookTotalBetandWin(double& totalBet, double& totalWin);

    void LoadCheckPoint(string gameId, int& bet, int& line, string& data);
    void SaveCheckPoint(string gameId, int bet, int line, string data);
    void SaveCheckPoint(int value);   // save single int globally
    int LoadCheckPoint();             // load single int globally
    void ClearCheckPoints();

    // Helper function for calculating bet limits
    static void CalculateBetLimits(int betSteps[], int count, int& betMin, int& betMax);

private:
    struct CheckPoint
    {
        int bet;
        int line;
        string data;
    };

    GameSettings gameSettings;
    GamePlaySettings gamePlaySettings;
    GameBookKeepingList mainBookKeepingList;
    GameBookKeepingList subBookKeepingList;
    map<string, CheckPoint> checkPoints;
    int globalCheckpointValue;
    sqlite3* db;
    void (*payoutCallback)();
    bool isDataValid;

    // Thread-related members
    HANDLE saveThread;
    bool stopSaveThread;
    HANDLE saveMutex;    // Mutex to protect Save() from race conditions
    HANDLE saveEvent;    // Auto-reset event: signalled whenever data is dirtied
    static DWORD WINAPI SaveThreadProc(LPVOID lpParam);
    void MarkDirty();    // Signal saveEvent so the thread flushes on next wake
    
	PlayDB();
	~PlayDB();
	PlayDB(const PlayDB&) = delete;
	PlayDB& operator=(const PlayDB&) = delete;


};

#endif