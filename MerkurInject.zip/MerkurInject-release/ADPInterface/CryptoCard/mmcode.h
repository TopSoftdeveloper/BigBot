#pragma once
#include "Utils.h"
#include "myVector.h"

struct MMCodeStatus {
	int year;
	int month;
	int day;

	bool enable;
	int matchStep;

	bool active;
	std::string activeString;
	/** If true, mmcode was armed via sunny mouse hotspot; next mmcode_set_deactive clears enable (bet serial required again). */
	bool activeFromMouseHotspot;
};

void mmcode_init();
bool mmcode_get_enable_status();
void mmcode_enable_go(uint8_t betval);
myVector<uint8_t> mmcode_generate();

bool mmcode_get_active_status();
void mmcode_active_go(char c, bool fromMouseHotspot = false);
void mmcode_set_deactive();
