#ifndef __KomProtocol__H_
#define __KomProtocol__H__
#include "Windows.h"
#include "DB.h"
#include <vector>
#pragma once

enum PROTOKOLLSTATES
{
    ERROR_PROTO = 0x0,
    NOTINIT = 0x1,
    WAIT_SOH = 0x2,
    WAIT_EOT_STX = 0x3,
    WAIT_COMMAND = 0x4,
    WAIT_PARAM = 0x5,
    WAIT_PARAM_SIZE = 0x6,
    WORKOUT_COMLIST = 0x7,
    WORKOUT_COMLIST_AFTER_ERROR = 0x8,
    WAITFORNEWSTART = 0x9,
    WAIT_DB_ACK = 0xA,
    SEND_ANSWER_PREVIOUSCOMMAND = 0xB,
    PTB_GRAPHICS_TO_USB = 0xC,
    SEND_ANSWER_SYSTEMINFO = 0xD,
    SEND_ANSWER_OF_GET_GO_PROP = 0xE,
    COPY_LOGFILES = 0xF,
    SEND_ANSWER_GAMEINFO = 0x10,
    DB_PRINTOUT_TO_TEXT = 0x11,
    WAIT_FOR_VERIFICATION_TOOL = 0x12,
    WAIT_FOR_USBSTICK_BEFORE_INIT = 0x13,
};

enum BYTETYPE
{
    BYTETYPE_INIT = 0x1,
    BYTETYPE_SOH = 0x2,
    BYTETYPE_EOT = 0x4,
};

struct PACKET
{
	int sleeptime;
	std::vector<BYTE> data;
};


class KomProtocol
{
public:
    int mIsInitVideoCommand;
    int mCommandID;
    int mIsVariableParameterLaenge;
    int mNumParaBytesToWait;
    int mTotalParaBytes;
    PROTOKOLLSTATES mState;
	RUNSTATE mRunState;
	BOOL mJustNextFLAG;
    BOOL mIsWaitingToStartGame;

	int DBindex;
	int mGameID;
	DB& myDB;

    KomProtocol();
    PROTOKOLLSTATES DefineStateParam(int commandID);
    void CalculateFixedParamSize();
	void ManualSleep();

	BOOL mInterrupt;
	std::vector<PACKET>mInterruptAns;
    CRITICAL_SECTION m_InterruptAnsMutex;

    int ComposeData(BYTE *data);
	void ReadData(BYTE* data, int pReadSize);
	
	void SendInputMoney(int Money);
	void BetChange();
    void MaxBet();
    void Numpad0();
    void Numpad1();
    void Numpad2();
    void ReturnToMenu();
    void ToogleAutoSpin();

	void Spin();
    void FastSpin();
    
	void RunNewGame();
    void MousePressed(UINT8 reel, UINT8 x, UINT8 row, UINT8 y);

	BOOL IsInterrupt();

    void MakePacket(const std::vector<UINT8>& data);
    void MakePacket(const UINT8* data, int len);
};

#endif