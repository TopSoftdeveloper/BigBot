#pragma once
#include <Windows.h>
#include <map>
#include <string>

enum RUNSTATE
{
	RUNSTATE_NONE,
	RUNSTATE_INIT,
	RUNSTATE_GAME
};


class DB {
public:
	static constexpr int NUM_ROWS = 200;
	BYTE* gDBData[NUM_ROWS];
	int gDBDataSizes[NUM_ROWS] = {0};
	int gDBWaitTime[NUM_ROWS] = { 0 };
	std::map<RUNSTATE, int> gStateINDEX;
	std::map <std::string, int> gGameObjID;
	int gCredit;
	int gBetStep;
	std::map<std::string, int> gGameName;

	static DB& GetInstance();  // Singleton accessor

	int CalcCredit(int value);
	int ChangeBetStep();
private:
	DB();                         // Private constructor
	DB(const DB&) = delete;       // No copy
	DB& operator=(const DB&) = delete; // No assign
	void ConstructIDs();
};
