#include "stdafx.h"
#include "PlayDB.h"
#include "Utils.h"
#include <iostream>
#include <fstream>
#include <vector>
#include <cstring>
#include <algorithm>

using namespace std;

// Helper function to calculate min/max from bet steps array
void PlayDB::CalculateBetLimits(int betSteps[], int count, int& betMin, int& betMax) {
    if (count == 0) {
        betMin = -1;
        betMax = -1;
        return;
    }
    
    betMin = betSteps[0];
    betMax = betSteps[0];
    
    for (int i = 1; i < count; i++) {
        if (betSteps[i] < betMin) betMin = betSteps[i];
        if (betSteps[i] > betMax) betMax = betSteps[i];
    }
}

#ifdef BIGBET_ACTIVE
namespace {
void BigBetAppendUnique(vector<int>& steps, const vector<int>& extras) {
    for (int v : extras) {
        if (find(steps.begin(), steps.end(), v) == steps.end())
            steps.push_back(v);
    }
    sort(steps.begin(), steps.end());
}

// Category 1: ladder ends at 100 — add 200, 500
void BigBetCat1_max100(vector<int>& v) {
    BigBetAppendUnique(v, {200, 500});
}
// Category 2: ladder ends at 200 (no 300/400 on this line) — add 500, 1000
void BigBetCat2_max200(vector<int>& v) {
    BigBetAppendUnique(v, {500, 1000});
}
// Category 3: line already includes 300 or 400 — add 500, 1000, 2000
void BigBetCat3_has300or400(vector<int>& v) {
    BigBetAppendUnique(v, {500, 1000, 2000});
}
// Category 4a: paired 5/10 with 5-line max 100 and 10-line max 200 — 5: +200,+500,+1000; 10: +400,+1000,+2000
void BigBetPaired_M5_100_M10_200(vector<int>& v5, vector<int>& v10) {
    BigBetAppendUnique(v5, {200, 500});
    BigBetAppendUnique(v10, {400, 1000});
}
// Category 4b: paired with 5-line max 200 and 10-line max 400 — double the high 5-line extension on 10-line
void BigBetPaired_M5_200_M10_400(vector<int>& v5, vector<int>& v10) {
    BigBetCat2_max200(v5);
    BigBetAppendUnique(v10, {1000, 2000});
}
} // namespace
#endif


PlayDB& PlayDB::GetInstance()
{
	static PlayDB instance;
	return instance;
}

string PlayDB::GetSettingPassword()
{
    return gameSettings.settingpassword;
}

string PlayDB::GetBookkeepingPassword()
{
    return gameSettings.bookkeepingpassword;
}

void PlayDB::SetSettingPassword(const string& password)
{
    gameSettings.settingpassword = password;
    MarkDirty();
}

void PlayDB::SetBookkeepingPassword(const string& password)
{
    gameSettings.bookkeepingpassword = password;
    MarkDirty();
}

int PlayDB::GetGameCount()
{
    return gameSettings.gameCount;
}

int PlayDB::GetGameID(string gameID)
{
    for (int i = 0; i < gameSettings.gameCount; i++) {
        if (gameSettings.betInfo[i].gameID == gameID) {
            return i;
        }
    }
    return -1;
}

string PlayDB::GetGameName(int index)
{
    if (index >= 0 && index < gameSettings.gameCount) {
        return gameSettings.gameNames[index];
    }
    return "";
}

void PlayDB::GetBetInfo(int index, int betSteps5[20], int betSteps10[20], int& betMin5, int& betMax5, int& betMin10, int& betMax10)
{
    if (index >= 0 && index < gameSettings.gameCount) {
        // Copy bet steps arrays
        for (int i = 0; i < 20; i++) {
            betSteps5[i] = gameSettings.betInfo[index].betSteps5[i];
            betSteps10[i] = gameSettings.betInfo[index].betSteps10[i];
        }
        
        // Copy min/max values
        betMin5 = gameSettings.betInfo[index].betMin5;
        betMax5 = gameSettings.betInfo[index].betMax5;
        betMin10 = gameSettings.betInfo[index].betMin10;
        betMax10 = gameSettings.betInfo[index].betMax10;
    }
}

void PlayDB::SetBetInfo(int index, int betSteps5[20], int betSteps10[20], int betMin5, int betMax5, int betMin10, int betMax10)
{
    if (index >= 0 && index < gameSettings.gameCount) {
        for (int i = 0; i < 20; i++) {
            gameSettings.betInfo[index].betSteps5[i] = betSteps5[i];
            gameSettings.betInfo[index].betSteps10[i] = betSteps10[i];
        }
        gameSettings.betInfo[index].betMin5 = betMin5;
        gameSettings.betInfo[index].betMax5 = betMax5;
        gameSettings.betInfo[index].betMin10 = betMin10;
        gameSettings.betInfo[index].betMax10 = betMax10;
        MarkDirty();
    }
}

void PlayDB::SetGameVariant(GameVariant variant)
{
#ifdef VARIANTBC_ACTIVE
    gameSettings.gameVariant = variant;
#else
    (void)variant;
    gameSettings.gameVariant = GAME_VARIANT_A;
#endif
    MarkDirty();
}

PlayDB::GameVariant PlayDB::GetGameVariant()
{
#ifdef VARIANTBC_ACTIVE
    return gameSettings.gameVariant;
#else
    return GAME_VARIANT_A;
#endif
}

PlayDB::PlayDB() : db(nullptr), payoutCallback(nullptr), saveThread(nullptr), stopSaveThread(false), saveEvent(NULL), globalCheckpointValue(0)
{
    gamePlaySettings.gameCredit = 0.0;
    gamePlaySettings.mmcodeDate = 0;

    saveMutex = CreateMutex(NULL, FALSE, NULL);
    if (saveMutex == NULL) {
        DebugPrintf("Failed to create save mutex: %lu\n", static_cast<unsigned long>(GetLastError()));
    }

    // Auto-reset event: each Set fires it; SaveThreadProc consumes one signal per flush
    saveEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
    if (saveEvent == NULL) {
        DebugPrintf("Failed to create save event: %lu\n", static_cast<unsigned long>(GetLastError()));
    }

    stopSaveThread = false;
    saveThread = CreateThread(NULL, 0, SaveThreadProc, this, 0, NULL);
    if (saveThread == NULL) {
        DebugPrintf("Failed to create save thread: %lu\n", static_cast<unsigned long>(GetLastError()));
    } else {
        SetThreadPriority(saveThread, THREAD_PRIORITY_NORMAL);
    }
    isDataValid = true;
}

PlayDB::~PlayDB()
{
    if (saveThread != NULL) {
        stopSaveThread = true;
        // Wake the thread so it sees stopSaveThread immediately
        if (saveEvent != NULL) SetEvent(saveEvent);
        WaitForSingleObject(saveThread, 5000);
        CloseHandle(saveThread);
        saveThread = NULL;
    }

    if (saveEvent != NULL) {
        CloseHandle(saveEvent);
        saveEvent = NULL;
    }

    if (saveMutex != NULL) {
        CloseHandle(saveMutex);
        saveMutex = NULL;
    }

    if (db) {
        sqlite3_close(db);
        db = nullptr;
    }
}

void PlayDB::ResetMainBookData()
{
    mainBookKeepingList.totalin = 0;
    mainBookKeepingList.totalout = 0;
    mainBookKeepingList.mmcodeCount = 0;
    
    time_t now = time(0);
    struct tm timeinfo;
    localtime_s(&timeinfo, &now);
    char buffer[20];
    strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M", &timeinfo);
    mainBookKeepingList.beginDate = string(buffer);
    
    for (int i = 0; i < MAX_GAME_COUNT; i++) {
        if (i < gameSettings.gameCount) {
            mainBookKeepingList.gameBookKeeping[i].gameID = gameSettings.gameNames[i];
        } else {
            mainBookKeepingList.gameBookKeeping[i].gameID = "";
        }
        mainBookKeepingList.gameBookKeeping[i].playedpoints = 0;
        mainBookKeepingList.gameBookKeeping[i].wonpoints = 0;
        mainBookKeepingList.gameBookKeeping[i].spins = 0;
    }
}

void PlayDB::ResetSubBookData()
{
    subBookKeepingList.totalin = 0;
    subBookKeepingList.totalout = 0;
    subBookKeepingList.mmcodeCount = 0;
    
    time_t now = time(0);
    struct tm timeinfo;
    localtime_s(&timeinfo, &now);
    char buffer[20];
    strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M", &timeinfo);
    subBookKeepingList.beginDate = string(buffer);
    
    for (int i = 0; i < MAX_GAME_COUNT; i++) {
        if (i < gameSettings.gameCount) {
            subBookKeepingList.gameBookKeeping[i].gameID = gameSettings.gameNames[i];
        } else {
            subBookKeepingList.gameBookKeeping[i].gameID = "";
        }
        subBookKeepingList.gameBookKeeping[i].playedpoints = 0;
        subBookKeepingList.gameBookKeeping[i].wonpoints = 0;
        subBookKeepingList.gameBookKeeping[i].spins = 0;
    }
}

void PlayDB::ResetGameSettings()
{
    // Set default passwords and variant.
    // Default variant is B when VARIANTBC_ACTIVE is enabled, otherwise A.
    gameSettings.settingpassword = "2025";
    gameSettings.bookkeepingpassword = "2026";
#ifdef VARIANTBC_ACTIVE
    gameSettings.gameVariant = GAME_VARIANT_B;
#else
    gameSettings.gameVariant = GAME_VARIANT_A;
#endif
    gameSettings.gameCount = 30; // We have 30 games configured
    
    // Initialize game names
    gameSettings.gameNames[0] = "RgEyeOfHorus";
    gameSettings.gameNames[1] = "RgLosFrootos";
    gameSettings.gameNames[2] = "RgLuckyPharaoh";
    gameSettings.gameNames[3] = "RgGongHei";
    gameSettings.gameNames[4] = "RgMultiWild243";
    gameSettings.gameNames[5] = "RgPyramidsDeluxe";
    gameSettings.gameNames[6] = "RgGoldCup";
    gameSettings.gameNames[7] = "RgMagicMirrorDeluxe2";
    gameSettings.gameNames[8] = "RgKongsTemple";
    gameSettings.gameNames[9] = "RgMultiSevenWild";
    gameSettings.gameNames[10] = "RgDoppelBuch";
    gameSettings.gameNames[11] = "RgElToreroMG";
    gameSettings.gameNames[12] = "RgFruitinator";
    gameSettings.gameNames[13] = "RgHotFrootastic";
    gameSettings.gameNames[14] = "RgTripleTripleChance";
    gameSettings.gameNames[15] = "RgMerkurMagnus";
    gameSettings.gameNames[16] = "RgTotemChiefPlus";
    gameSettings.gameNames[17] = "RgJokersCap";
    gameSettings.gameNames[18] = "RgBlazingStar";
    gameSettings.gameNames[19] = "RgDragonsTreasure";
    gameSettings.gameNames[20] = "RgBookOfFire";
    gameSettings.gameNames[21] = "RgExtraWild";
    gameSettings.gameNames[22] = "RgCairoCasino";
    gameSettings.gameNames[23] = "RgRisingLiner";
    gameSettings.gameNames[24] = "RgKeyOfTheNile";
    gameSettings.gameNames[25] = "RgPyramidOfPower";
    gameSettings.gameNames[26] = "RgConvertusAurum";
    gameSettings.gameNames[27] = "RgGladiators";
    gameSettings.gameNames[28] = "RgLegacyOfFire";
    gameSettings.gameNames[29] = "RgIndianRuby";
    
    // Set gameIDs from gameNames array
    for (int i = 0; i < gameSettings.gameCount; i++) {
        gameSettings.betInfo[i].gameID = gameSettings.gameNames[i];
    }
    
    // Initialize all games with default values
    for (int i = 0; i < MAX_GAME_COUNT; i++)
    {
        // gameID is already set from gameNames array above
        gameSettings.betInfo[i].betMin5 = 0;
        gameSettings.betInfo[i].betMax5 = 0;
        gameSettings.betInfo[i].betMin10 = -1;
        gameSettings.betInfo[i].betMax10 = -1;
        gameSettings.betInfo[i].isMMcode = false;
        for (int j = 0; j < 20; j++) {
            gameSettings.betInfo[i].betSteps5[j] = -1;
            gameSettings.betInfo[i].betSteps10[j] = -1;
        }
    }
    
    // Game 0: RgEyeOfHorus
    int gameIndex = 0;
    vector<int> eyeOfHorus5 = {5, 10, 20, 30, 40, 50, 75, 100, 200};
    vector<int> eyeOfHorus10 = {10, 20, 40, 60, 80, 100, 150, 200, 400};
#ifdef BIGBET_ACTIVE
    BigBetPaired_M5_200_M10_400(eyeOfHorus5, eyeOfHorus10);
#endif
    for (size_t i = 0; i < eyeOfHorus5.size(); i++) gameSettings.betInfo[gameIndex].betSteps5[i] = eyeOfHorus5[i];
    for (size_t i = 0; i < eyeOfHorus10.size(); i++) gameSettings.betInfo[gameIndex].betSteps10[i] = eyeOfHorus10[i];
    CalculateBetLimits(eyeOfHorus5.data(), static_cast<int>(eyeOfHorus5.size()), gameSettings.betInfo[gameIndex].betMin5, gameSettings.betInfo[gameIndex].betMax5);
    CalculateBetLimits(eyeOfHorus10.data(), static_cast<int>(eyeOfHorus10.size()), gameSettings.betInfo[gameIndex].betMin10, gameSettings.betInfo[gameIndex].betMax10);
    
    // Game 1: RgLosFrootos
    gameIndex = 1;
    vector<int> losFrootos10 = {10, 20, 30, 40, 50, 60, 80, 100, 150, 200};
#ifdef BIGBET_ACTIVE
    BigBetCat2_max200(losFrootos10);
#endif
    for (size_t i = 0; i < losFrootos10.size(); i++) gameSettings.betInfo[gameIndex].betSteps10[i] = losFrootos10[i];
    CalculateBetLimits(losFrootos10.data(), static_cast<int>(losFrootos10.size()), gameSettings.betInfo[gameIndex].betMin10, gameSettings.betInfo[gameIndex].betMax10);
    
    // Game 2: RgLuckyPharaoh
    gameIndex = 2;
    vector<int> pharosGold10 = {10, 20, 30, 40, 50, 60, 80, 100, 150, 200};
#ifdef BIGBET_ACTIVE
    BigBetCat2_max200(pharosGold10);
#endif
    for (size_t i = 0; i < pharosGold10.size(); i++) gameSettings.betInfo[gameIndex].betSteps10[i] = pharosGold10[i];
    CalculateBetLimits(pharosGold10.data(), static_cast<int>(pharosGold10.size()), gameSettings.betInfo[gameIndex].betMin10, gameSettings.betInfo[gameIndex].betMax10);
    
    // Game 3: RgGongHei
    gameIndex = 3;
    vector<int> gongHei5 = {5, 10, 15, 20, 25, 30, 40, 50, 60, 80, 100};
    vector<int> gongHei10 = {10, 20, 30, 40, 50, 60, 80, 100, 120, 160, 200};
#ifdef BIGBET_ACTIVE
    BigBetPaired_M5_100_M10_200(gongHei5, gongHei10);
#endif
    for (size_t i = 0; i < gongHei5.size(); i++) gameSettings.betInfo[gameIndex].betSteps5[i] = gongHei5[i];
    for (size_t i = 0; i < gongHei10.size(); i++) gameSettings.betInfo[gameIndex].betSteps10[i] = gongHei10[i];
    CalculateBetLimits(gongHei5.data(), static_cast<int>(gongHei5.size()), gameSettings.betInfo[gameIndex].betMin5, gameSettings.betInfo[gameIndex].betMax5);
    CalculateBetLimits(gongHei10.data(), static_cast<int>(gongHei10.size()), gameSettings.betInfo[gameIndex].betMin10, gameSettings.betInfo[gameIndex].betMax10);
    
    // Game 4: RgMultiWild243
    gameIndex = 4;
    vector<int> multiWild2435 = {10, 20, 30, 40, 50, 60, 80, 100, 150, 200, 300, 400};
#ifdef BIGBET_ACTIVE
    //BigBetPaired_M5_200_M10_400(multiWild2435);
#endif
    for (size_t i = 0; i < multiWild2435.size(); i++) gameSettings.betInfo[gameIndex].betSteps5[i] = multiWild2435[i];
    CalculateBetLimits(multiWild2435.data(), static_cast<int>(multiWild2435.size()), gameSettings.betInfo[gameIndex].betMin5, gameSettings.betInfo[gameIndex].betMax5);
    
    // Game 5: RgPyramidsDeluxe
    gameIndex = 5;
    vector<int> pyramidsDeluxe5 = {5, 10, 15, 20, 25, 30, 40, 50, 60, 80, 100};
    vector<int> pyramidsDeluxe10 = {10, 20, 30, 40, 50, 60, 80, 100, 120, 160, 200};
#ifdef BIGBET_ACTIVE
    BigBetPaired_M5_100_M10_200(pyramidsDeluxe5, pyramidsDeluxe10);
#endif
    for (size_t i = 0; i < pyramidsDeluxe5.size(); i++) gameSettings.betInfo[gameIndex].betSteps5[i] = pyramidsDeluxe5[i];
    for (size_t i = 0; i < pyramidsDeluxe10.size(); i++) gameSettings.betInfo[gameIndex].betSteps10[i] = pyramidsDeluxe10[i];
    CalculateBetLimits(pyramidsDeluxe5.data(), static_cast<int>(pyramidsDeluxe5.size()), gameSettings.betInfo[gameIndex].betMin5, gameSettings.betInfo[gameIndex].betMax5);
    CalculateBetLimits(pyramidsDeluxe10.data(), static_cast<int>(pyramidsDeluxe10.size()), gameSettings.betInfo[gameIndex].betMin10, gameSettings.betInfo[gameIndex].betMax10);
    
    // Game 6: RgGoldCup
    gameIndex = 6;
    vector<int> goldCup5 = {5, 10, 20, 30, 40, 50, 60, 80, 100, 150, 200};
#ifdef BIGBET_ACTIVE
    BigBetCat2_max200(goldCup5);
#endif
    for (size_t i = 0; i < goldCup5.size(); i++) gameSettings.betInfo[gameIndex].betSteps5[i] = goldCup5[i];
    CalculateBetLimits(goldCup5.data(), static_cast<int>(goldCup5.size()), gameSettings.betInfo[gameIndex].betMin5, gameSettings.betInfo[gameIndex].betMax5);
    
    // Game 7: RgMagicMirrorDeluxe2
    gameIndex = 7;
    vector<int> magicMirror5 = {5, 10, 20, 30, 40, 50, 60, 80, 100, 150, 200};
    vector<int> magicMirror10 = {10, 20, 30, 40, 50, 60, 80, 100, 150, 200, 400};
#ifdef BIGBET_ACTIVE
    BigBetPaired_M5_200_M10_400(magicMirror5, magicMirror10);
#endif
    for (size_t i = 0; i < magicMirror5.size(); i++) gameSettings.betInfo[gameIndex].betSteps5[i] = magicMirror5[i];
    for (size_t i = 0; i < magicMirror10.size(); i++) gameSettings.betInfo[gameIndex].betSteps10[i] = magicMirror10[i];
    CalculateBetLimits(magicMirror5.data(), static_cast<int>(magicMirror5.size()), gameSettings.betInfo[gameIndex].betMin5, gameSettings.betInfo[gameIndex].betMax5);
    CalculateBetLimits(magicMirror10.data(), static_cast<int>(magicMirror10.size()), gameSettings.betInfo[gameIndex].betMin10, gameSettings.betInfo[gameIndex].betMax10);
    
    // Game 8: RgKongsTemple
    gameIndex = 8;
    vector<int> kongsTemple5 = {5, 10, 20, 30, 40, 50, 60, 80, 100};
    vector<int> kongsTemple10 = {10, 20, 40, 60, 80, 100, 120, 160, 200};
#ifdef BIGBET_ACTIVE
    BigBetPaired_M5_100_M10_200(kongsTemple5, kongsTemple10);
#endif
    for (size_t i = 0; i < kongsTemple5.size(); i++) gameSettings.betInfo[gameIndex].betSteps5[i] = kongsTemple5[i];
    for (size_t i = 0; i < kongsTemple10.size(); i++) gameSettings.betInfo[gameIndex].betSteps10[i] = kongsTemple10[i];
    CalculateBetLimits(kongsTemple5.data(), static_cast<int>(kongsTemple5.size()), gameSettings.betInfo[gameIndex].betMin5, gameSettings.betInfo[gameIndex].betMax5);
    CalculateBetLimits(kongsTemple10.data(), static_cast<int>(kongsTemple10.size()), gameSettings.betInfo[gameIndex].betMin10, gameSettings.betInfo[gameIndex].betMax10);
    
    // Game 9: RgMultiSevenWild
    gameIndex = 9;
    vector<int> multiSevenWild5 = {5, 10, 20, 30, 40, 50, 60, 80, 100, 150, 200};
    vector<int> multiSevenWild10 = {10, 20, 40, 60, 80, 100, 120, 160, 200, 300, 400};
#ifdef BIGBET_ACTIVE
    BigBetPaired_M5_200_M10_400(multiSevenWild5, multiSevenWild10);
#endif
    for (size_t i = 0; i < multiSevenWild5.size(); i++) gameSettings.betInfo[gameIndex].betSteps5[i] = multiSevenWild5[i];
    for (size_t i = 0; i < multiSevenWild10.size(); i++) gameSettings.betInfo[gameIndex].betSteps10[i] = multiSevenWild10[i];
    CalculateBetLimits(multiSevenWild5.data(), static_cast<int>(multiSevenWild5.size()), gameSettings.betInfo[gameIndex].betMin5, gameSettings.betInfo[gameIndex].betMax5);
    CalculateBetLimits(multiSevenWild10.data(), static_cast<int>(multiSevenWild10.size()), gameSettings.betInfo[gameIndex].betMin10, gameSettings.betInfo[gameIndex].betMax10);
    
    // Game 10: RgDoppelBuch
    gameIndex = 10;
    vector<int> doubleBookS = {5, 10, 20, 30, 40, 50, 60, 80, 100};
    vector<int> doubleBookD = {10, 20, 40, 60, 80, 100, 120, 160, 200};
#ifdef BIGBET_ACTIVE
    BigBetPaired_M5_100_M10_200(doubleBookS, doubleBookD);
#endif
    for (size_t i = 0; i < doubleBookS.size(); i++) gameSettings.betInfo[gameIndex].betSteps5[i] = doubleBookS[i];
    for (size_t i = 0; i < doubleBookD.size(); i++) gameSettings.betInfo[gameIndex].betSteps10[i] = doubleBookD[i];
    CalculateBetLimits(doubleBookS.data(), static_cast<int>(doubleBookS.size()), gameSettings.betInfo[gameIndex].betMin5, gameSettings.betInfo[gameIndex].betMax5);
    CalculateBetLimits(doubleBookD.data(), static_cast<int>(doubleBookD.size()), gameSettings.betInfo[gameIndex].betMin10, gameSettings.betInfo[gameIndex].betMax10);
    
    // Game 11: RgElToreroMG
    gameIndex = 11;
    vector<int> elTorero10 = {10, 20, 30, 40, 50, 60, 80, 100, 150, 200};
#ifdef BIGBET_ACTIVE
    BigBetCat2_max200(elTorero10);
#endif
    for (size_t i = 0; i < elTorero10.size(); i++) gameSettings.betInfo[gameIndex].betSteps10[i] = elTorero10[i];
    CalculateBetLimits(elTorero10.data(), static_cast<int>(elTorero10.size()), gameSettings.betInfo[gameIndex].betMin10, gameSettings.betInfo[gameIndex].betMax10);
    
    // Game 12: RgFruitinator
    gameIndex = 12;
    vector<int> fruitinator5 = {5, 10, 20, 30, 40, 50, 60, 80, 100};
#ifdef BIGBET_ACTIVE
    BigBetCat1_max100(fruitinator5);
#endif
    for (size_t i = 0; i < fruitinator5.size(); i++) gameSettings.betInfo[gameIndex].betSteps5[i] = fruitinator5[i];
    CalculateBetLimits(fruitinator5.data(), static_cast<int>(fruitinator5.size()), gameSettings.betInfo[gameIndex].betMin5, gameSettings.betInfo[gameIndex].betMax5);
    
    // Game 13: RgHotFrootastic
    gameIndex = 13;
    vector<int> hotFrootastic10 = {10, 20, 30, 40, 50, 60, 80, 100, 150, 200};
#ifdef BIGBET_ACTIVE
    BigBetCat2_max200(hotFrootastic10);
#endif
    for (size_t i = 0; i < hotFrootastic10.size(); i++) gameSettings.betInfo[gameIndex].betSteps10[i] = hotFrootastic10[i];
    CalculateBetLimits(hotFrootastic10.data(), static_cast<int>(hotFrootastic10.size()), gameSettings.betInfo[gameIndex].betMin10, gameSettings.betInfo[gameIndex].betMax10);
    
    // Game 14: RgTripleTripleChance
    gameIndex = 14;
    vector<int> tripleTripleChance5 = {5, 10, 20, 30, 40, 50, 60, 80, 100, 150, 200};
#ifdef BIGBET_ACTIVE
    BigBetCat2_max200(tripleTripleChance5);
#endif
    for (size_t i = 0; i < tripleTripleChance5.size(); i++) gameSettings.betInfo[gameIndex].betSteps5[i] = tripleTripleChance5[i];
    CalculateBetLimits(tripleTripleChance5.data(), static_cast<int>(tripleTripleChance5.size()), gameSettings.betInfo[gameIndex].betMin5, gameSettings.betInfo[gameIndex].betMax5);
    
    // Game 15: RgMerkurMagnus
    gameIndex = 15;
    vector<int> merkurMagnus5 = {5, 10, 20, 30, 40, 50, 60, 80, 100, 150, 200};
#ifdef BIGBET_ACTIVE
    BigBetCat2_max200(merkurMagnus5);
#endif
    for (size_t i = 0; i < merkurMagnus5.size(); i++) gameSettings.betInfo[gameIndex].betSteps5[i] = merkurMagnus5[i];
    CalculateBetLimits(merkurMagnus5.data(), static_cast<int>(merkurMagnus5.size()), gameSettings.betInfo[gameIndex].betMin5, gameSettings.betInfo[gameIndex].betMax5);
    
    // Game 16: RgTotemChiefPlus
    gameIndex = 16;
    vector<int> totemChief5 = {5, 10, 20, 30, 40, 50, 75, 100, 200};
    vector<int> totemChief10 = {10, 20, 40, 60, 80, 100, 150, 200, 400};
#ifdef BIGBET_ACTIVE
    BigBetPaired_M5_200_M10_400(totemChief5, totemChief10);
#endif
    for (size_t i = 0; i < totemChief5.size(); i++) gameSettings.betInfo[gameIndex].betSteps5[i] = totemChief5[i];
    for (size_t i = 0; i < totemChief10.size(); i++) gameSettings.betInfo[gameIndex].betSteps10[i] = totemChief10[i];
    CalculateBetLimits(totemChief5.data(), static_cast<int>(totemChief5.size()), gameSettings.betInfo[gameIndex].betMin5, gameSettings.betInfo[gameIndex].betMax5);
    CalculateBetLimits(totemChief10.data(), static_cast<int>(totemChief10.size()), gameSettings.betInfo[gameIndex].betMin10, gameSettings.betInfo[gameIndex].betMax10);
    
    // Game 17: RgJokersCap
    gameIndex = 17;
    vector<int> jokersCap5 = {5, 10, 20, 30, 40, 50, 60, 80, 100, 150, 200};
#ifdef BIGBET_ACTIVE
    BigBetCat2_max200(jokersCap5);
#endif
    for (size_t i = 0; i < jokersCap5.size(); i++) gameSettings.betInfo[gameIndex].betSteps5[i] = jokersCap5[i];
    CalculateBetLimits(jokersCap5.data(), static_cast<int>(jokersCap5.size()), gameSettings.betInfo[gameIndex].betMin5, gameSettings.betInfo[gameIndex].betMax5);
    
    // Game 18: RgBlazingStar
    gameIndex = 18;
    vector<int> blazingSun5 = {5, 10, 20, 30, 40, 50, 60, 80, 100, 150, 200};
    //vector<int> blazingSun5 = {5, 10, 20, 30, 40, 50, 60, 80, 100, 150, 200, 2000};
#ifdef BIGBET_ACTIVE
    BigBetCat2_max200(blazingSun5);
#endif
    for (size_t i = 0; i < blazingSun5.size(); i++) gameSettings.betInfo[gameIndex].betSteps5[i] = blazingSun5[i];
    CalculateBetLimits(blazingSun5.data(), static_cast<int>(blazingSun5.size()), gameSettings.betInfo[gameIndex].betMin5, gameSettings.betInfo[gameIndex].betMax5);
    
    // Game 19: RgDragonsTreasure
    gameIndex = 19;
    vector<int> dragonsTreas5 = {5, 10, 20, 30, 40, 50, 60, 80, 100};
#ifdef BIGBET_ACTIVE
    BigBetCat1_max100(dragonsTreas5);
#endif
    for (size_t i = 0; i < dragonsTreas5.size(); i++) gameSettings.betInfo[gameIndex].betSteps5[i] = dragonsTreas5[i];
    CalculateBetLimits(dragonsTreas5.data(), static_cast<int>(dragonsTreas5.size()), gameSettings.betInfo[gameIndex].betMin5, gameSettings.betInfo[gameIndex].betMax5);
    
    // Game 20: RgBookOfFire
    gameIndex = 20;
    vector<int> bookOfFire5 = {5, 10, 15, 20, 25, 30, 40, 50, 60, 80, 100};
    vector<int> bookOfFire10 = {10, 20, 30, 40, 50, 60, 80, 100, 120, 160, 200};
#ifdef BIGBET_ACTIVE
    BigBetPaired_M5_100_M10_200(bookOfFire5, bookOfFire10);
#endif
    for (size_t i = 0; i < bookOfFire5.size(); i++) gameSettings.betInfo[gameIndex].betSteps5[i] = bookOfFire5[i];
    for (size_t i = 0; i < bookOfFire10.size(); i++) gameSettings.betInfo[gameIndex].betSteps10[i] = bookOfFire10[i];
    CalculateBetLimits(bookOfFire5.data(), static_cast<int>(bookOfFire5.size()), gameSettings.betInfo[gameIndex].betMin5, gameSettings.betInfo[gameIndex].betMax5);
    CalculateBetLimits(bookOfFire10.data(), static_cast<int>(bookOfFire10.size()), gameSettings.betInfo[gameIndex].betMin10, gameSettings.betInfo[gameIndex].betMax10);
    
    // Game 21: RgExtraWild
    gameIndex = 21;
    vector<int> extraWild10 = {5, 10, 20, 30, 40, 50, 60, 80, 100, 150, 200};
#ifdef BIGBET_ACTIVE
    BigBetCat2_max200(extraWild10);
#endif
    for (size_t i = 0; i < extraWild10.size(); i++) gameSettings.betInfo[gameIndex].betSteps10[i] = extraWild10[i];
    CalculateBetLimits(extraWild10.data(), static_cast<int>(extraWild10.size()), gameSettings.betInfo[gameIndex].betMin10, gameSettings.betInfo[gameIndex].betMax10);
    
    // Game 22: RgCairoCasino
    gameIndex = 22;
    vector<int> cairoCasino5 = {10, 20, 30, 40, 50, 60, 80, 100, 150, 200};
#ifdef BIGBET_ACTIVE
    BigBetCat1_max100(cairoCasino5);
#endif
    for (size_t i = 0; i < cairoCasino5.size(); i++) gameSettings.betInfo[gameIndex].betSteps5[i] = cairoCasino5[i];
    CalculateBetLimits(cairoCasino5.data(), static_cast<int>(cairoCasino5.size()), gameSettings.betInfo[gameIndex].betMin5, gameSettings.betInfo[gameIndex].betMax5);
    
    // Game 23: RgRisingLiner
    gameIndex = 23;
    vector<int> risingLiner5 = {5, 10, 20, 30, 40, 50, 60, 80, 100, 150, 200};
#ifdef BIGBET_ACTIVE
    BigBetCat2_max200(risingLiner5);
#endif
    for (size_t i = 0; i < risingLiner5.size(); i++) gameSettings.betInfo[gameIndex].betSteps5[i] = risingLiner5[i];
    CalculateBetLimits(risingLiner5.data(), static_cast<int>(risingLiner5.size()), gameSettings.betInfo[gameIndex].betMin5, gameSettings.betInfo[gameIndex].betMax5);
    
    // Game 24: RgKeyOfTheNile
    gameIndex = 24;
    vector<int> keyOfTheNile10 = {10, 20, 30, 40, 50, 60, 80, 100, 150, 200};
#ifdef BIGBET_ACTIVE
    BigBetCat2_max200(keyOfTheNile10);
#endif
    for (size_t i = 0; i < keyOfTheNile10.size(); i++) gameSettings.betInfo[gameIndex].betSteps10[i] = keyOfTheNile10[i];
    CalculateBetLimits(keyOfTheNile10.data(), static_cast<int>(keyOfTheNile10.size()), gameSettings.betInfo[gameIndex].betMin10, gameSettings.betInfo[gameIndex].betMax10);
    
    // Game 25: RgPyramidOfPower
    gameIndex = 25;
    vector<int> pyramidOfPower5 = {10, 20, 30, 40, 50, 60, 80, 100, 150, 200};
#ifdef BIGBET_ACTIVE
    BigBetCat2_max200(pyramidOfPower5);
#endif
    for (size_t i = 0; i < pyramidOfPower5.size(); i++) gameSettings.betInfo[gameIndex].betSteps5[i] = pyramidOfPower5[i];
    CalculateBetLimits(pyramidOfPower5.data(), static_cast<int>(pyramidOfPower5.size()), gameSettings.betInfo[gameIndex].betMin5, gameSettings.betInfo[gameIndex].betMax5);
    
    // Game 26: RgConvertusAurum
    gameIndex = 26;
    vector<int> convertusAurum5 = {5, 10, 20, 30, 40, 50, 75, 100};
    vector<int> convertusAurum10 = {10, 20, 40, 60, 80, 100, 150, 200};
#ifdef BIGBET_ACTIVE
    BigBetPaired_M5_100_M10_200(convertusAurum5, convertusAurum10);
#endif
    for (size_t i = 0; i < convertusAurum5.size(); i++) gameSettings.betInfo[gameIndex].betSteps5[i] = convertusAurum5[i];
    for (size_t i = 0; i < convertusAurum10.size(); i++) gameSettings.betInfo[gameIndex].betSteps10[i] = convertusAurum10[i];
    CalculateBetLimits(convertusAurum5.data(), static_cast<int>(convertusAurum5.size()), gameSettings.betInfo[gameIndex].betMin5, gameSettings.betInfo[gameIndex].betMax5);
    CalculateBetLimits(convertusAurum10.data(), static_cast<int>(convertusAurum10.size()), gameSettings.betInfo[gameIndex].betMin10, gameSettings.betInfo[gameIndex].betMax10);
    
    // Game 27: RgGladiators
    gameIndex = 27;
    vector<int> gl5 = {5, 10, 20, 30, 40, 50, 60, 80, 100};
#ifdef BIGBET_ACTIVE
    BigBetCat1_max100(gl5);
#endif
    for (size_t i = 0; i < gl5.size(); i++) gameSettings.betInfo[gameIndex].betSteps5[i] = gl5[i];
    CalculateBetLimits(gl5.data(), static_cast<int>(gl5.size()), gameSettings.betInfo[gameIndex].betMin5, gameSettings.betInfo[gameIndex].betMax5);
    
    // Game 28: RgLegacyOfFire
    gameIndex = 28;
    vector<int> legacyOfFire5 = {5, 10, 20, 30, 40, 50, 60, 80, 100};
#ifdef BIGBET_ACTIVE
    BigBetCat1_max100(legacyOfFire5);
#endif
    for (size_t i = 0; i < legacyOfFire5.size(); i++) gameSettings.betInfo[gameIndex].betSteps5[i] = legacyOfFire5[i];
    CalculateBetLimits(legacyOfFire5.data(), static_cast<int>(legacyOfFire5.size()), gameSettings.betInfo[gameIndex].betMin5, gameSettings.betInfo[gameIndex].betMax5);
    
    // Game 29: RgIndianRuby
    gameIndex = 29;
    vector<int> indianRuby5 = {5, 10, 20, 30, 40, 50, 60, 80, 100};
    vector<int> indianRuby10 = {10, 20, 40, 60, 80, 100, 120, 160, 200};
#ifdef BIGBET_ACTIVE
    BigBetPaired_M5_100_M10_200(indianRuby5, indianRuby10);
#endif
    for (size_t i = 0; i < indianRuby5.size(); i++) gameSettings.betInfo[gameIndex].betSteps5[i] = indianRuby5[i];
    for (size_t i = 0; i < indianRuby10.size(); i++) gameSettings.betInfo[gameIndex].betSteps10[i] = indianRuby10[i];
    CalculateBetLimits(indianRuby5.data(), static_cast<int>(indianRuby5.size()), gameSettings.betInfo[gameIndex].betMin5, gameSettings.betInfo[gameIndex].betMax5);
    CalculateBetLimits(indianRuby10.data(), static_cast<int>(indianRuby10.size()), gameSettings.betInfo[gameIndex].betMin10, gameSettings.betInfo[gameIndex].betMax10);
}

void PlayDB::Save()
{
    // Acquire mutex to prevent race conditions
    if (saveMutex != NULL) {
        DWORD waitResult = WaitForSingleObject(saveMutex, INFINITE);
        if (waitResult != WAIT_OBJECT_0) {
            DebugPrintf("Failed to acquire save mutex: %lu\n", static_cast<unsigned long>(GetLastError()));
            return;
        }
    }
    
    int rc = sqlite3_open("play.db", &db);
    if (rc) {
        DebugPrintf("Can't open database: %s\n", sqlite3_errmsg(db));
        // Release mutex before early return
        if (saveMutex != NULL) {
            ReleaseMutex(saveMutex);
        }
        return;
    }

    // Set PRAGMAs for crash safety: FULL sync ensures data is durable before commit
    rc = sqlite3_exec(db, "PRAGMA journal_mode = WAL;", 0, 0, 0);
    if (rc != SQLITE_OK) {
        DebugPrintf("Failed to set PRAGMA journal_mode=WAL: %s\n", sqlite3_errmsg(db));
    }
    rc = sqlite3_exec(db, "PRAGMA synchronous = FULL;", 0, 0, 0);
    if (rc != SQLITE_OK) {
        DebugPrintf("Failed to set PRAGMA synchronous=FULL: %s\n", sqlite3_errmsg(db));
    }

    // Single transaction: if process dies mid-save, DB rolls back to previous state (no corruption)
    rc = sqlite3_exec(db, "BEGIN IMMEDIATE;", 0, 0, 0);
    if (rc != SQLITE_OK) {
        DebugPrintf("Failed to BEGIN transaction: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        if (saveMutex != NULL) ReleaseMutex(saveMutex);
        return;
    }

    // Create general settings table
    const char* createGeneralTableSQL = 
        "CREATE TABLE IF NOT EXISTS general_settings ("
        "id INTEGER PRIMARY KEY, "
        "game_count INTEGER, "
        "game_variant INTEGER, "
        "setting_password TEXT, "
        "bookkeeping_password TEXT"
        ");";
    
    rc = sqlite3_exec(db, createGeneralTableSQL, 0, 0, 0);
    if (rc != SQLITE_OK) {
        DebugPrintf("SQL error creating general_settings table: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        // Release mutex before early return
        if (saveMutex != NULL) {
            ReleaseMutex(saveMutex);
        }
        return;
    }

    // Create bet info table
    const char* createBetInfoTableSQL = 
        "CREATE TABLE IF NOT EXISTS bet_info ("
        "id INTEGER PRIMARY KEY, "
        "game_id TEXT, "
        "game_name TEXT, "
        "bet_min_5 INTEGER, "
        "bet_max_5 INTEGER, "
        "bet_min_10 INTEGER, "
        "bet_max_10 INTEGER, "
        "bet_steps_5 TEXT, "
        "bet_steps_10 TEXT, "
        "is_mm_code INTEGER"
        ");";
    
    rc = sqlite3_exec(db, createBetInfoTableSQL, 0, 0, 0);
    if (rc != SQLITE_OK) {
        DebugPrintf("SQL error creating bet_info table: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        // Release mutex before early return
        if (saveMutex != NULL) {
            ReleaseMutex(saveMutex);
        }
        return;
    }

    // Create mainbook table
    const char* createMainBookTableSQL = 
        "CREATE TABLE IF NOT EXISTS mainbook ("
        "id INTEGER PRIMARY KEY, "
        "game_id TEXT, "
        "played_points INTEGER, "
        "won_points INTEGER, "
        "spins INTEGER, "
        "begin_date TEXT, "
        "total_in INTEGER, "
        "total_out INTEGER"
        ");";
    
    rc = sqlite3_exec(db, createMainBookTableSQL, 0, 0, 0);
    if (rc != SQLITE_OK) {
        DebugPrintf("SQL error creating mainbook table: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        // Release mutex before early return
        if (saveMutex != NULL) {
            ReleaseMutex(saveMutex);
        }
        return;
    }

    // Create subbook table
    const char* createSubBookTableSQL = 
        "CREATE TABLE IF NOT EXISTS subbook ("
        "id INTEGER PRIMARY KEY, "
        "game_id TEXT, "
        "played_points INTEGER, "
        "won_points INTEGER, "
        "spins INTEGER, "
        "begin_date TEXT, "
        "total_in INTEGER, "
        "total_out INTEGER"
        ");";
    
    rc = sqlite3_exec(db, createSubBookTableSQL, 0, 0, 0);
    if (rc != SQLITE_OK) {
        DebugPrintf("SQL error creating subbook table: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        // Release mutex before early return
        if (saveMutex != NULL) {
            ReleaseMutex(saveMutex);
        }
        return;
    }

    // Create gameplay settings table
    const char* createGamePlayTableSQL = 
        "CREATE TABLE IF NOT EXISTS gameplay_settings ("
        "id INTEGER PRIMARY KEY, "
        "game_credit INTEGER, "
        "mmcode_date INTEGER"
        ");";
    
    rc = sqlite3_exec(db, createGamePlayTableSQL, 0, 0, 0);
    if (rc != SQLITE_OK) {
        DebugPrintf("SQL error creating gameplay_settings table: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        // Release mutex before early return
        if (saveMutex != NULL) {
            ReleaseMutex(saveMutex);
        }
        return;
    }

    const char* createMMCodeBookTableSQL =
        "CREATE TABLE IF NOT EXISTS mmcode_bookkeeping ("
        "id INTEGER PRIMARY KEY, "
        "main_count INTEGER, "
        "sub_count INTEGER"
        ");";
    rc = sqlite3_exec(db, createMMCodeBookTableSQL, 0, 0, 0);
    if (rc != SQLITE_OK) {
        DebugPrintf("SQL error creating mmcode_bookkeeping table: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        if (saveMutex != NULL) {
            ReleaseMutex(saveMutex);
        }
        return;
    }

    // Create checkpoint table
    const char* createCheckpointTableSQL =
        "CREATE TABLE IF NOT EXISTS saved_game_state ("
        "game_id TEXT PRIMARY KEY, "
        "bet INTEGER, "
        "line INTEGER, "
        "data TEXT"
        ");";

    rc = sqlite3_exec(db, createCheckpointTableSQL, 0, 0, 0);
    if (rc != SQLITE_OK) {
        DebugPrintf("SQL error creating saved_game_state table: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        if (saveMutex != NULL) {
            ReleaseMutex(saveMutex);
        }
        return;
    }

    // Create global_values table (key-value for single int storage)
    const char* createGlobalValuesTableSQL =
        "CREATE TABLE IF NOT EXISTS global_values ("
        "key TEXT PRIMARY KEY, "
        "value INTEGER"
        ");";
    rc = sqlite3_exec(db, createGlobalValuesTableSQL, 0, 0, 0);
    if (rc != SQLITE_OK) {
        DebugPrintf("SQL error creating global_values table: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        if (saveMutex != NULL) {
            ReleaseMutex(saveMutex);
        }
        return;
    }

    // Clear existing data
    sqlite3_exec(db, "DELETE FROM general_settings", 0, 0, 0);
    sqlite3_exec(db, "DELETE FROM bet_info", 0, 0, 0);
    sqlite3_exec(db, "DELETE FROM mainbook", 0, 0, 0);
    sqlite3_exec(db, "DELETE FROM subbook", 0, 0, 0);
    sqlite3_exec(db, "DELETE FROM gameplay_settings", 0, 0, 0);
    sqlite3_exec(db, "DELETE FROM mmcode_bookkeeping", 0, 0, 0);
    sqlite3_exec(db, "DELETE FROM saved_game_state", 0, 0, 0);

    // Insert general settings
    const char* insertGeneralSQL = 
        "INSERT INTO general_settings (game_count, game_variant, setting_password, bookkeeping_password) "
        "VALUES (?, ?, ?, ?);";
    
    sqlite3_stmt* generalStmt;
    rc = sqlite3_prepare_v2(db, insertGeneralSQL, -1, &generalStmt, NULL);
    if (rc != SQLITE_OK) {
        DebugPrintf("Failed to prepare general settings insert statement: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        // Release mutex before early return
        if (saveMutex != NULL) {
            ReleaseMutex(saveMutex);
        }
        return;
    }

    sqlite3_bind_int(generalStmt, 1, gameSettings.gameCount);
    sqlite3_bind_int(generalStmt, 2, (int)gameSettings.gameVariant);
    sqlite3_bind_text(generalStmt, 3, gameSettings.settingpassword.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(generalStmt, 4, gameSettings.bookkeepingpassword.c_str(), -1, SQLITE_STATIC);

    rc = sqlite3_step(generalStmt);
    if (rc != SQLITE_DONE) {
        DebugPrintf("SQL error inserting general settings: %s\n", sqlite3_errmsg(db));
    }
    sqlite3_finalize(generalStmt);

    // Insert bet info for each game
    const char* insertBetInfoSQL = 
        "INSERT INTO bet_info (game_id, game_name, bet_min_5, bet_max_5, bet_min_10, bet_max_10, "
        "bet_steps_5, bet_steps_10, is_mm_code) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);";
    
    sqlite3_stmt* betInfoStmt;
    rc = sqlite3_prepare_v2(db, insertBetInfoSQL, -1, &betInfoStmt, NULL);
    if (rc != SQLITE_OK) {
        DebugPrintf("Failed to prepare bet info insert statement: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        // Release mutex before early return
        if (saveMutex != NULL) {
            ReleaseMutex(saveMutex);
        }
        return;
    }

    for (int i = 0; i < MAX_GAME_COUNT; i++) {
        if (!gameSettings.betInfo[i].gameID.empty()) {
            // Convert bet steps arrays to comma-separated strings
            string steps5Str = "";
            string steps10Str = "";
            for (int j = 0; j < 20; j++) {
                if (j > 0) {
                    steps5Str += ",";
                    steps10Str += ",";
                }
                steps5Str += to_string(gameSettings.betInfo[i].betSteps5[j]);
                steps10Str += to_string(gameSettings.betInfo[i].betSteps10[j]);
            }

            // Bind parameters
            sqlite3_bind_text(betInfoStmt, 1, gameSettings.betInfo[i].gameID.c_str(), -1, SQLITE_STATIC);
            sqlite3_bind_text(betInfoStmt, 2, gameSettings.gameNames[i].c_str(), -1, SQLITE_STATIC);
            sqlite3_bind_int(betInfoStmt, 3, gameSettings.betInfo[i].betMin5);
            sqlite3_bind_int(betInfoStmt, 4, gameSettings.betInfo[i].betMax5);
            sqlite3_bind_int(betInfoStmt, 5, gameSettings.betInfo[i].betMin10);
            sqlite3_bind_int(betInfoStmt, 6, gameSettings.betInfo[i].betMax10);
            sqlite3_bind_text(betInfoStmt, 7, steps5Str.c_str(), -1, SQLITE_STATIC);
            sqlite3_bind_text(betInfoStmt, 8, steps10Str.c_str(), -1, SQLITE_STATIC);
            sqlite3_bind_int(betInfoStmt, 9, gameSettings.betInfo[i].isMMcode ? 1 : 0);

            rc = sqlite3_step(betInfoStmt);
            if (rc != SQLITE_DONE) {
                DebugPrintf("SQL error inserting bet info: %s\n", sqlite3_errmsg(db));
            }

            sqlite3_reset(betInfoStmt);
        }
    }

    sqlite3_finalize(betInfoStmt);

    // Insert mainbook data
    const char* insertMainBookSQL = 
        "INSERT INTO mainbook (game_id, played_points, won_points, spins, begin_date, total_in, total_out) "
        "VALUES (?, ?, ?, ?, ?, ?, ?);";
    
    sqlite3_stmt* mainBookStmt;
    rc = sqlite3_prepare_v2(db, insertMainBookSQL, -1, &mainBookStmt, NULL);
    if (rc != SQLITE_OK) {
        DebugPrintf("Failed to prepare mainbook insert statement: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        // Release mutex before early return
        if (saveMutex != NULL) {
            ReleaseMutex(saveMutex);
        }
        return;
    }

    for (int i = 0; i < MAX_GAME_COUNT; i++) {
        if (!mainBookKeepingList.gameBookKeeping[i].gameID.empty()) {
            sqlite3_bind_text(mainBookStmt, 1, mainBookKeepingList.gameBookKeeping[i].gameID.c_str(), -1, SQLITE_STATIC);
            sqlite3_bind_double(mainBookStmt, 2, mainBookKeepingList.gameBookKeeping[i].playedpoints);
            sqlite3_bind_double(mainBookStmt, 3, mainBookKeepingList.gameBookKeeping[i].wonpoints);
            sqlite3_bind_int(mainBookStmt, 4, mainBookKeepingList.gameBookKeeping[i].spins);
            sqlite3_bind_text(mainBookStmt, 5, mainBookKeepingList.beginDate.c_str(), -1, SQLITE_STATIC);
            sqlite3_bind_double(mainBookStmt, 6, mainBookKeepingList.totalin);
            sqlite3_bind_double(mainBookStmt, 7, mainBookKeepingList.totalout);

            rc = sqlite3_step(mainBookStmt);
            if (rc != SQLITE_DONE) {
                DebugPrintf("SQL error inserting mainbook data: %s\n", sqlite3_errmsg(db));
            }
            sqlite3_reset(mainBookStmt);
        }
    }
    sqlite3_finalize(mainBookStmt);

    // Insert subbook data
    const char* insertSubBookSQL = 
        "INSERT INTO subbook (game_id, played_points, won_points, spins, begin_date, total_in, total_out) "
        "VALUES (?, ?, ?, ?, ?, ?, ?);";
    
    sqlite3_stmt* subBookStmt;
    rc = sqlite3_prepare_v2(db, insertSubBookSQL, -1, &subBookStmt, NULL);
    if (rc != SQLITE_OK) {
        DebugPrintf("Failed to prepare subbook insert statement: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        // Release mutex before early return
        if (saveMutex != NULL) {
            ReleaseMutex(saveMutex);
        }
        return;
    }

    for (int i = 0; i < MAX_GAME_COUNT; i++) {
        if (!subBookKeepingList.gameBookKeeping[i].gameID.empty()) {
            sqlite3_bind_text(subBookStmt, 1, subBookKeepingList.gameBookKeeping[i].gameID.c_str(), -1, SQLITE_STATIC);
            sqlite3_bind_double(subBookStmt, 2, subBookKeepingList.gameBookKeeping[i].playedpoints);
            sqlite3_bind_double(subBookStmt, 3, subBookKeepingList.gameBookKeeping[i].wonpoints);
            sqlite3_bind_int(subBookStmt, 4, subBookKeepingList.gameBookKeeping[i].spins);
            sqlite3_bind_text(subBookStmt, 5, subBookKeepingList.beginDate.c_str(), -1, SQLITE_STATIC);
            sqlite3_bind_double(subBookStmt, 6, subBookKeepingList.totalin);
            sqlite3_bind_double(subBookStmt, 7, subBookKeepingList.totalout);

            rc = sqlite3_step(subBookStmt);
            if (rc != SQLITE_DONE) {
                DebugPrintf("SQL error inserting subbook data: %s\n", sqlite3_errmsg(db));
            }
            sqlite3_reset(subBookStmt);
        }
    }
    sqlite3_finalize(subBookStmt);

    // Insert gameplay settings data
    const char* insertGamePlaySQL = 
        "INSERT INTO gameplay_settings (game_credit, mmcode_date) "
        "VALUES (?, ?);";
    
    sqlite3_stmt* gamePlayStmt;
    rc = sqlite3_prepare_v2(db, insertGamePlaySQL, -1, &gamePlayStmt, NULL);
    if (rc != SQLITE_OK) {
        DebugPrintf("Failed to prepare gameplay settings insert statement: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        // Release mutex before early return
        if (saveMutex != NULL) {
            ReleaseMutex(saveMutex);
        }
        return;
    }

    sqlite3_bind_double(gamePlayStmt, 1, gamePlaySettings.gameCredit);
    sqlite3_bind_int(gamePlayStmt, 2, gamePlaySettings.mmcodeDate);

    rc = sqlite3_step(gamePlayStmt);
    if (rc != SQLITE_DONE) {
        DebugPrintf("SQL error inserting gameplay settings: %s\n", sqlite3_errmsg(db));
    }
    sqlite3_finalize(gamePlayStmt);

    const char* insertMMCodeBookSQL =
        "INSERT INTO mmcode_bookkeeping (main_count, sub_count) VALUES (?, ?);";
    sqlite3_stmt* mmcodeBookStmt;
    rc = sqlite3_prepare_v2(db, insertMMCodeBookSQL, -1, &mmcodeBookStmt, NULL);
    if (rc == SQLITE_OK) {
        sqlite3_bind_int(mmcodeBookStmt, 1, mainBookKeepingList.mmcodeCount);
        sqlite3_bind_int(mmcodeBookStmt, 2, subBookKeepingList.mmcodeCount);
        rc = sqlite3_step(mmcodeBookStmt);
        if (rc != SQLITE_DONE) {
            DebugPrintf("SQL error inserting mmcode_bookkeeping data: %s\n", sqlite3_errmsg(db));
        }
        sqlite3_finalize(mmcodeBookStmt);
    }
    else {
        DebugPrintf("Failed to prepare mmcode_bookkeeping insert statement: %s\n", sqlite3_errmsg(db));
    }

    // Insert checkpoint data
    const char* insertCheckpointSQL =
        "INSERT INTO saved_game_state (game_id, bet, line, data) "
        "VALUES (?, ?, ?, ?);";

    sqlite3_stmt* checkpointStmtInsert;
    rc = sqlite3_prepare_v2(db, insertCheckpointSQL, -1, &checkpointStmtInsert, NULL);
    if (rc != SQLITE_OK) {
        DebugPrintf("Failed to prepare checkpoint insert statement: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        if (saveMutex != NULL) {
            ReleaseMutex(saveMutex);
        }
        return;
    }

    for (const auto& kv : checkPoints) {
        const string& gameId = kv.first;
        const CheckPoint& cp = kv.second;

        sqlite3_bind_text(checkpointStmtInsert, 1, gameId.c_str(), -1, SQLITE_STATIC);
        sqlite3_bind_int(checkpointStmtInsert, 2, cp.bet);
        sqlite3_bind_int(checkpointStmtInsert, 3, cp.line);
        sqlite3_bind_text(checkpointStmtInsert, 4, cp.data.c_str(), -1, SQLITE_STATIC);

        rc = sqlite3_step(checkpointStmtInsert);
        if (rc != SQLITE_DONE) {
            DebugPrintf("SQL error inserting checkpoint data: %s\n", sqlite3_errmsg(db));
        }

        sqlite3_reset(checkpointStmtInsert);
    }
    sqlite3_finalize(checkpointStmtInsert);

    // Insert global checkpoint value
    const char* insertGlobalCheckpointSQL =
        "INSERT OR REPLACE INTO global_values (key, value) VALUES ('checkpoint', ?);";
    sqlite3_stmt* globalCheckpointStmt;
    rc = sqlite3_prepare_v2(db, insertGlobalCheckpointSQL, -1, &globalCheckpointStmt, NULL);
    if (rc == SQLITE_OK) {
        sqlite3_bind_int(globalCheckpointStmt, 1, globalCheckpointValue);
        rc = sqlite3_step(globalCheckpointStmt);
        if (rc != SQLITE_DONE) {
            DebugPrintf("SQL error inserting global checkpoint: %s\n", sqlite3_errmsg(db));
        }
        sqlite3_finalize(globalCheckpointStmt);
    } else {
        DebugPrintf("Failed to prepare global checkpoint insert: %s\n", sqlite3_errmsg(db));
    }

    rc = sqlite3_exec(db, "COMMIT;", 0, 0, 0);
    if (rc != SQLITE_OK) {
        DebugPrintf("Failed to COMMIT: %s\n", sqlite3_errmsg(db));
        sqlite3_exec(db, "ROLLBACK;", 0, 0, 0);
    }

    sqlite3_close(db);
    
    // Release mutex
    if (saveMutex != NULL) {
        ReleaseMutex(saveMutex);
    }
}

void PlayDB::Load()
{
    // First, set default values
    ResetGameSettings();
    
    // Reset bookkeeping data first
    ResetMainBookData();
    ResetSubBookData();
    
    // Check if play.db file exists before trying to open it
    ifstream file("play.db");
    if (!file.good()) {
        // File doesn't exist, just use default values
        return;
    }
    file.close();
    
    int rc = sqlite3_open("play.db", &db);
    if (rc) {
        DebugPrintf("Can't open database: %s\n", sqlite3_errmsg(db));
        // Database can't be opened, use default values
        if (db) { sqlite3_close(db); db = nullptr; }
        return;
    }

    // Reject corrupt DB so we don't overwrite good in-memory state with garbage
    char **integrityResult = 0;
    int nRow = 0, nCol = 0;
    rc = sqlite3_get_table(db, "PRAGMA integrity_check;", &integrityResult, &nRow, &nCol, 0);
    if (rc != SQLITE_OK || nRow < 1 || nCol < 1 || strcmp(integrityResult[nCol], "ok") != 0) {
        DebugPrintf("Database integrity check failed, using defaults\n");
        if (integrityResult) sqlite3_free_table(integrityResult);
        sqlite3_close(db);
        db = nullptr;
        return;
    }
    sqlite3_free_table(integrityResult);

    // Set performance-related PRAGMAs
    rc = sqlite3_exec(db, "PRAGMA journal_mode = WAL;", 0, 0, 0);
    if (rc != SQLITE_OK) {
        DebugPrintf("Failed to set PRAGMA journal_mode=WAL: %s\n", sqlite3_errmsg(db));
    }
    rc = sqlite3_exec(db, "PRAGMA synchronous = NORMAL;", 0, 0, 0);
    if (rc != SQLITE_OK) {
        DebugPrintf("Failed to set PRAGMA synchronous=NORMAL: %s\n", sqlite3_errmsg(db));
    }

    // Load general settings first
    const char* selectGeneralSQL = "SELECT * FROM general_settings LIMIT 1";
    sqlite3_stmt* generalStmt;
    
    rc = sqlite3_prepare_v2(db, selectGeneralSQL, -1, &generalStmt, NULL);
    if (rc == SQLITE_OK && sqlite3_step(generalStmt) == SQLITE_ROW) {
        // Get general settings data
        gameSettings.gameCount = sqlite3_column_int(generalStmt, 1);
        const int storedVariant = sqlite3_column_int(generalStmt, 2);
#ifdef VARIANTBC_ACTIVE
        // Honor whatever was stored, but clamp to the valid enum range.
        // Fall back to Variant B (the new default) when the stored value is bogus.
        if (storedVariant >= GAME_VARIANT_A && storedVariant <= GAME_VARIANT_C) {
            gameSettings.gameVariant = (GameVariant)storedVariant;
        } else {
            gameSettings.gameVariant = GAME_VARIANT_B;
        }
#else
        (void)storedVariant;
        gameSettings.gameVariant = GAME_VARIANT_A;
#endif
        const char* settingPassword = (const char*)sqlite3_column_text(generalStmt, 3);
        const char* bookkeepingPassword = (const char*)sqlite3_column_text(generalStmt, 4);
        
        if (settingPassword) gameSettings.settingpassword = settingPassword;
        if (bookkeepingPassword) gameSettings.bookkeepingpassword = bookkeepingPassword;
    }
    sqlite3_finalize(generalStmt);

    // Load bet info data
    const char* selectBetInfoSQL = "SELECT * FROM bet_info";
    sqlite3_stmt* betInfoStmt;
    
    rc = sqlite3_prepare_v2(db, selectBetInfoSQL, -1, &betInfoStmt, NULL);
    if (rc != SQLITE_OK) {
        DebugPrintf("Failed to prepare bet info statement: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        db = nullptr;
        return;
    }

    int index = 0;
    while (sqlite3_step(betInfoStmt) == SQLITE_ROW && index < MAX_GAME_COUNT) {
        // Get bet info data from columns
        const char* gameID = (const char*)sqlite3_column_text(betInfoStmt, 1);
        const char* gameName = (const char*)sqlite3_column_text(betInfoStmt, 2);
        int betMin5 = sqlite3_column_int(betInfoStmt, 3);
        int betMax5 = sqlite3_column_int(betInfoStmt, 4);
        int betMin10 = sqlite3_column_int(betInfoStmt, 5);
        int betMax10 = sqlite3_column_int(betInfoStmt, 6);
        const char* steps5Str = (const char*)sqlite3_column_text(betInfoStmt, 7);
        const char* steps10Str = (const char*)sqlite3_column_text(betInfoStmt, 8);
        int isMMcode = sqlite3_column_int(betInfoStmt, 9);

        if (gameID) {
            gameSettings.betInfo[index].gameID = gameID;
            if (gameName) gameSettings.gameNames[index] = gameName;
            gameSettings.betInfo[index].betMin5 = betMin5;
            gameSettings.betInfo[index].betMax5 = betMax5;
            gameSettings.betInfo[index].betMin10 = betMin10;
            gameSettings.betInfo[index].betMax10 = betMax10;
            gameSettings.betInfo[index].isMMcode = (isMMcode == 1);
            
            // Parse bet steps from comma-separated strings
            if (steps5Str) {
                string steps5 = steps5Str;
                string delimiter = ",";
                size_t pos = 0;
                int stepIndex = 0;
                while ((pos = steps5.find(delimiter)) != string::npos && stepIndex < 20) {
                    if(gameSettings.betInfo[index].betSteps5[stepIndex] != stoi(steps5.substr(0, pos)))
                    {
                        isDataValid = false;
                    }
                    steps5.erase(0, pos + delimiter.length());
                    stepIndex++;
                }
                if (stepIndex < 20 && !steps5.empty()) {
                    if(gameSettings.betInfo[index].betSteps5[stepIndex] != stoi(steps5.substr(0, pos)))
                    {
                        isDataValid = false;
                    }
                }
            }
            
            if (steps10Str) {
                string steps10 = steps10Str;
                string delimiter = ",";
                size_t pos = 0;
                int stepIndex = 0;
                while ((pos = steps10.find(delimiter)) != string::npos && stepIndex < 20) {
                    if(gameSettings.betInfo[index].betSteps10[stepIndex] != stoi(steps10.substr(0, pos)))
                    {
                        isDataValid = false;
                    }
                    steps10.erase(0, pos + delimiter.length());
                    stepIndex++;
                }
                if (stepIndex < 20 && !steps10.empty()) {
                    if(gameSettings.betInfo[index].betSteps10[stepIndex] != stoi(steps10.substr(0, pos)))
                    {
                        isDataValid = false;
                    }
                }
            }
        }
        index++;
    }

    sqlite3_finalize(betInfoStmt);

    // Load mainbook data
    const char* selectMainBookSQL = "SELECT * FROM mainbook";
    sqlite3_stmt* mainBookStmt;
    
    rc = sqlite3_prepare_v2(db, selectMainBookSQL, -1, &mainBookStmt, NULL);
    if (rc == SQLITE_OK) {
        int index = 0;
        while (sqlite3_step(mainBookStmt) == SQLITE_ROW && index < MAX_GAME_COUNT) {
            const char* gameID = (const char*)sqlite3_column_text(mainBookStmt, 1);
            double playedPoints = sqlite3_column_double(mainBookStmt, 2);
            double wonPoints = sqlite3_column_double(mainBookStmt, 3);
            int spins = sqlite3_column_int(mainBookStmt, 4);
            const char* beginDate = (const char*)sqlite3_column_text(mainBookStmt, 5);
            double totalIn = sqlite3_column_double(mainBookStmt, 6);
            double totalOut = sqlite3_column_double(mainBookStmt, 7);

            if (gameID) {
                mainBookKeepingList.gameBookKeeping[index].gameID = gameID;
                mainBookKeepingList.gameBookKeeping[index].playedpoints = playedPoints;
                mainBookKeepingList.gameBookKeeping[index].wonpoints = wonPoints;
                mainBookKeepingList.gameBookKeeping[index].spins = spins;
                if (beginDate) mainBookKeepingList.beginDate = beginDate;
                mainBookKeepingList.totalin = totalIn;
                mainBookKeepingList.totalout = totalOut;
            }
            index++;
        }
    }
    sqlite3_finalize(mainBookStmt);

    // Load subbook data
    const char* selectSubBookSQL = "SELECT * FROM subbook";
    sqlite3_stmt* subBookStmt;
    
    rc = sqlite3_prepare_v2(db, selectSubBookSQL, -1, &subBookStmt, NULL);
    if (rc == SQLITE_OK) {
        int index = 0;
        while (sqlite3_step(subBookStmt) == SQLITE_ROW && index < MAX_GAME_COUNT) {
            const char* gameID = (const char*)sqlite3_column_text(subBookStmt, 1);
            double playedPoints = sqlite3_column_double(subBookStmt, 2);
            double wonPoints = sqlite3_column_double(subBookStmt, 3);
            int spins = sqlite3_column_int(subBookStmt, 4);
            const char* beginDate = (const char*)sqlite3_column_text(subBookStmt, 5);
            double totalIn = sqlite3_column_double(subBookStmt, 6);
            double totalOut = sqlite3_column_double(subBookStmt, 7);

            if (gameID) {
                subBookKeepingList.gameBookKeeping[index].gameID = gameID;
                subBookKeepingList.gameBookKeeping[index].playedpoints = playedPoints;
                subBookKeepingList.gameBookKeeping[index].wonpoints = wonPoints;
                subBookKeepingList.gameBookKeeping[index].spins = spins;
                if (beginDate) subBookKeepingList.beginDate = beginDate;
                subBookKeepingList.totalin = totalIn;
                subBookKeepingList.totalout = totalOut;
            }
            index++;
        }
    }
    sqlite3_finalize(subBookStmt);

    // Load gameplay settings data
    const char* selectGamePlaySQL = "SELECT * FROM gameplay_settings LIMIT 1";
    sqlite3_stmt* gamePlayStmt;
    gamePlaySettings.gameCredit = 0.0;
    gamePlaySettings.mmcodeDate = 0;
    
    rc = sqlite3_prepare_v2(db, selectGamePlaySQL, -1, &gamePlayStmt, NULL);
    if (rc == SQLITE_OK && sqlite3_step(gamePlayStmt) == SQLITE_ROW) {
        // Get gameplay settings data
        gamePlaySettings.gameCredit = sqlite3_column_double(gamePlayStmt, 1);
        gamePlaySettings.mmcodeDate = sqlite3_column_int(gamePlayStmt, 2);
    }
    sqlite3_finalize(gamePlayStmt);

    const char* selectMMCodeBookSQL = "SELECT main_count, sub_count FROM mmcode_bookkeeping LIMIT 1";
    sqlite3_stmt* mmcodeBookStmt;
    rc = sqlite3_prepare_v2(db, selectMMCodeBookSQL, -1, &mmcodeBookStmt, NULL);
    if (rc == SQLITE_OK && sqlite3_step(mmcodeBookStmt) == SQLITE_ROW) {
        mainBookKeepingList.mmcodeCount = sqlite3_column_int(mmcodeBookStmt, 0);
        subBookKeepingList.mmcodeCount = sqlite3_column_int(mmcodeBookStmt, 1);
    }
    sqlite3_finalize(mmcodeBookStmt);

    // Load checkpoint data into memory
    checkPoints.clear();
    const char* selectCheckpointSQL = "SELECT game_id, bet, line, data FROM saved_game_state";
    sqlite3_stmt* checkpointStmt;
    rc = sqlite3_prepare_v2(db, selectCheckpointSQL, -1, &checkpointStmt, NULL);
    if (rc == SQLITE_OK) {
        while (sqlite3_step(checkpointStmt) == SQLITE_ROW) {
            const char* gameIdText = (const char*)sqlite3_column_text(checkpointStmt, 0);
            if (gameIdText) {
                CheckPoint cp;
                cp.bet = sqlite3_column_int(checkpointStmt, 1);
                cp.line = sqlite3_column_int(checkpointStmt, 2);
                const unsigned char* dataText = sqlite3_column_text(checkpointStmt, 3);
                cp.data = dataText ? reinterpret_cast<const char*>(dataText) : "";
                checkPoints[gameIdText] = cp;
            }
        }
    } else {
        DebugPrintf("Failed to prepare checkpoint select statement: %s\n", sqlite3_errmsg(db));
    }
    sqlite3_finalize(checkpointStmt);

    // Load global checkpoint value
    const char* selectGlobalCheckpointSQL = "SELECT value FROM global_values WHERE key='checkpoint' LIMIT 1";
    sqlite3_stmt* globalCheckpointStmt;
    rc = sqlite3_prepare_v2(db, selectGlobalCheckpointSQL, -1, &globalCheckpointStmt, NULL);
    if (rc == SQLITE_OK && sqlite3_step(globalCheckpointStmt) == SQLITE_ROW) {
        globalCheckpointValue = sqlite3_column_int(globalCheckpointStmt, 0);
    }
    sqlite3_finalize(globalCheckpointStmt);

    sqlite3_close(db);
    db = nullptr;

    if(!isDataValid)
    {
        DebugPrintf("***Data validation failed after load, resetting data***\n");
        ResetGameSettings();
        SaveResettedAny();
        //ResetMainBookData();
        //ResetSubBookData();
    }
    else
    {
        DebugPrintf("***Data validation passed after load***\n");
    }
}

void PlayDB::AddGamePlayData(string gameID, double playedpoints, double wonpoints, int spins)
{
    int gameIndex = GetGameID(gameID);
    if (gameIndex >= 0 && gameIndex < MAX_GAME_COUNT) {
        mainBookKeepingList.gameBookKeeping[gameIndex].playedpoints += playedpoints;
        mainBookKeepingList.gameBookKeeping[gameIndex].wonpoints += wonpoints;
        mainBookKeepingList.gameBookKeeping[gameIndex].spins += spins;
        
        subBookKeepingList.gameBookKeeping[gameIndex].playedpoints += playedpoints;
        subBookKeepingList.gameBookKeeping[gameIndex].wonpoints += wonpoints;
        subBookKeepingList.gameBookKeeping[gameIndex].spins += spins;
        MarkDirty();
    }
}

void PlayDB::AddPayinData(int credit)
{
    mainBookKeepingList.totalin += credit;
    subBookKeepingList.totalin += credit;
    MarkDirty();
}

void PlayDB::AddPayoutData()
{
    mainBookKeepingList.totalout += gamePlaySettings.gameCredit;
    subBookKeepingList.totalout += gamePlaySettings.gameCredit;
    MarkDirty();
}

void PlayDB::AddMMCodeCount()
{
    mainBookKeepingList.mmcodeCount++;
    subBookKeepingList.mmcodeCount++;
    MarkDirty();
}

void PlayDB::SetGameCreditData(double credit)
{
    gamePlaySettings.gameCredit = credit;
    MarkDirty();
}

void PlayDB::SetMMcodeDate()
{
    gamePlaySettings.mmcodeDate = (int)time(0);
    MarkDirty();
}

void PlayDB::ClearMMcodeDate()
{
    gamePlaySettings.mmcodeDate = 0;
    MarkDirty();
}

void PlayDB::SetPayoutCallback(void (*callback)())
{
    // Store the callback function pointer
    payoutCallback = callback;
}

void PlayDB::CallPayoutCallback()
{
    if (payoutCallback != nullptr) {
        payoutCallback();
        ClearCheckPoints();
    }
}

void PlayDB::ClearCheckPoints()
{
    checkPoints.clear();
    MarkDirty();
}

double PlayDB::GetGameCreditData()
{
    // Return the current game credit value
    return gamePlaySettings.gameCredit;
}

time_t PlayDB::GetMMcodeDate()
{
    // Return the stored timestamp as time_t
    return (time_t)gamePlaySettings.mmcodeDate;
}

// Bookkeeping data access methods for Main Book
string PlayDB::GetMainBookBeginDate()
{
    return mainBookKeepingList.beginDate;
}

double PlayDB::GetMainBookTotalIn()
{
    return mainBookKeepingList.totalin;
}

double PlayDB::GetMainBookTotalOut()
{
    return mainBookKeepingList.totalout;
}

string PlayDB::GetMainBookGameID(int index)
{
    if (index >= 0 && index < MAX_GAME_COUNT) {
        return mainBookKeepingList.gameBookKeeping[index].gameID;
    }
    return "";
}

double PlayDB::GetMainBookPlayedPoints(int index)
{
    if (index >= 0 && index < MAX_GAME_COUNT) {
        return mainBookKeepingList.gameBookKeeping[index].playedpoints;
    }
    return 0.0;
}

double PlayDB::GetMainBookWonPoints(int index)
{
    if (index >= 0 && index < MAX_GAME_COUNT) {
        return mainBookKeepingList.gameBookKeeping[index].wonpoints;
    }
    return 0.0;
}

int PlayDB::GetMainBookSpins(int index)
{
    if (index >= 0 && index < MAX_GAME_COUNT) {
        return mainBookKeepingList.gameBookKeeping[index].spins;
    }
    return 0;
}

int PlayDB::GetMainBookMMCodeCount()
{
    return mainBookKeepingList.mmcodeCount;
}

int PlayDB::GetMainBookTotalSpins()
{
    int totalspins = 0;
    for (int i = 0; i < MAX_GAME_COUNT; i++) {
        if (!mainBookKeepingList.gameBookKeeping[i].gameID.empty()) {
            totalspins += mainBookKeepingList.gameBookKeeping[i].spins;
        }
    }
    return totalspins;
}

void PlayDB::GetMainBookTotalBetandWin(double& totalBet, double& totalWin)
{
    totalBet = 0.0;
    totalWin = 0.0;
    for (int i = 0; i < MAX_GAME_COUNT; i++) {
        if (!mainBookKeepingList.gameBookKeeping[i].gameID.empty()) {
            totalBet += mainBookKeepingList.gameBookKeeping[i].playedpoints;
            totalWin += mainBookKeepingList.gameBookKeeping[i].wonpoints;
        }
    }
}

// Bookkeeping data access methods for Sub Book
string PlayDB::GetSubBookBeginDate()
{
    return subBookKeepingList.beginDate;
}

double PlayDB::GetSubBookTotalIn()
{
    return subBookKeepingList.totalin;
}

double PlayDB::GetSubBookTotalOut()
{
    return subBookKeepingList.totalout;
}

string PlayDB::GetSubBookGameID(int index)
{
    if (index >= 0 && index < MAX_GAME_COUNT) {
        return subBookKeepingList.gameBookKeeping[index].gameID;
    }
    return "";
}

double PlayDB::GetSubBookPlayedPoints(int index)
{
    if (index >= 0 && index < MAX_GAME_COUNT) {
        return subBookKeepingList.gameBookKeeping[index].playedpoints;
    }
    return 0.0;
}

double PlayDB::GetSubBookWonPoints(int index)
{
    if (index >= 0 && index < MAX_GAME_COUNT) {
        return subBookKeepingList.gameBookKeeping[index].wonpoints;
    }
    return 0.0;
}

int PlayDB::GetSubBookSpins(int index)
{
    if (index >= 0 && index < MAX_GAME_COUNT) {
        return subBookKeepingList.gameBookKeeping[index].spins;
    }
    return 0;
}

int PlayDB::GetSubBookMMCodeCount()
{
    return subBookKeepingList.mmcodeCount;
}

int PlayDB::GetSubBookTotalSpins()
{
    int totalspins = 0;

    // Sum up all spins from all games
    for (int i = 0; i < MAX_GAME_COUNT; i++) {
        if (!subBookKeepingList.gameBookKeeping[i].gameID.empty()) {
            totalspins += subBookKeepingList.gameBookKeeping[i].spins;
        }
    }

    return totalspins;
}

void PlayDB::GetSubBookTotalBetandWin(double& totalBet, double& totalWin)
{
    totalBet = 0.0;
    totalWin = 0.0;
    
    // Sum up all playedpoints and wonpoints from all games
    for (int i = 0; i < MAX_GAME_COUNT; i++) {
        if (!subBookKeepingList.gameBookKeeping[i].gameID.empty()) {
            totalBet += subBookKeepingList.gameBookKeeping[i].playedpoints;
            totalWin += subBookKeepingList.gameBookKeeping[i].wonpoints;
        }
    }
}

void PlayDB::LoadCheckPoint(string gameId, int& bet, int& line, string& data) {
    // Default values when nothing has been stored yet
    bet = -1;
    line = -1;
    data.clear();

    if (gameId.empty()) {
        return;
    }

    auto it = checkPoints.find(gameId);
    if (it != checkPoints.end()) {
        bet = it->second.bet;
        line = it->second.line;
        data = it->second.data;
    }
}

void PlayDB::SaveCheckPoint(string gameId, int bet, int line, string data) {
    if (gameId.empty()) {
        return;
    }

    CheckPoint cp;
    cp.bet = bet;
    cp.line = line;
    cp.data = data;
    checkPoints[gameId] = cp;
    MarkDirty();
}

void PlayDB::SaveCheckPoint(int value) {
    globalCheckpointValue = value;
    MarkDirty();
}

int PlayDB::LoadCheckPoint() {
    return globalCheckpointValue;
}


void PlayDB::MarkDirty()
{
    if (saveEvent != NULL) {
        SetEvent(saveEvent);
    }
}

void PlayDB::SaveResettedAny()
{
    MarkDirty();
}

DWORD WINAPI PlayDB::SaveThreadProc(LPVOID lpParam)
{
    PlayDB* pPlayDB = static_cast<PlayDB*>(lpParam);

    while (!pPlayDB->stopSaveThread) {
        // Wait for save requests, but also periodically enforce game window topmost.
        DWORD waitResult = WaitForSingleObject(pPlayDB->saveEvent, 10000);

        if (pPlayDB->stopSaveThread) {
            break;
        }

        if (waitResult == WAIT_OBJECT_0) {
            pPlayDB->Save();
            DebugPrintf("***Save completed***\n");
            KeepGameWindowTopmostTick();
        }
        else if (waitResult == WAIT_TIMEOUT) {
            KeepGameWindowTopmostTick();
        }
    }

    return 0;
}