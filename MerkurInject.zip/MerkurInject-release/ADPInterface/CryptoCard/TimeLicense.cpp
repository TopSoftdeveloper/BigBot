#include "stdafx.h"
#include "TimeLicense.h"
#include "Utils.h"

#define _WIN32_DCOM
#include <Wbemidl.h>

#include <iphlpapi.h>
#include <bcrypt.h>
#include <wincrypt.h>
#include <stdio.h>

void TimeLicense_ShowModalDialog();

#include <chrono>
#include <cstring>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

namespace TimeLicense {

const wchar_t* GetLicenseFilePath()
{
	static std::wstring s;
	static std::once_flag once;
	std::call_once(once, [] {
		wchar_t buf[MAX_PATH] = {};
		if (GetModuleFileNameW(nullptr, buf, MAX_PATH) > 0) {
			wchar_t* slash = wcsrchr(buf, L'\\');
			if (slash)
				*slash = L'\0';
			s = buf;
			s += L"\\dialog\\time.io";
		} else {
			s = L"dialog\\time.io";
		}
	});
	return s.c_str();
}

} // namespace TimeLicense

#pragma comment(lib, "iphlpapi.lib")
#pragma comment(lib, "bcrypt.lib")
#pragma comment(lib, "crypt32.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "wbemuuid.lib")
#pragma comment(lib, "ole32.lib")
#pragma comment(lib, "oleaut32.lib")

namespace {

constexpr char kMagicBytes[4] = { 'T', 'L', 'F', '1' };
constexpr uint32_t kBlobVersion = 1;

#pragma pack(push, 1)
struct LicensePayload {
	char magic[4];
	uint32_t version;
	FILETIME lastGoodUtc;
	uint64_t licenseCode12;
	uint32_t expiryYymm;
	uint32_t machineId8;
};
#pragma pack(pop)

std::atomic<bool> g_licensedOk{ false };
std::atomic<bool> g_wantLicenseDialog{ false };
std::once_flag g_monitorOnce;
std::once_flag g_initSerialOnce;

std::mutex g_idMutex;
uint32_t g_cachedMachineId8 = 0;
bool g_machineIdReady = false;

std::mutex g_hwFingerprintMutex;
std::string g_cachedHardwareFingerprint;
bool g_hwFingerprintCached = false;

BCRYPT_ALG_HANDLE g_sha256 = nullptr;

bool EnsureSha256() {
	if (g_sha256)
		return true;
	return BCRYPT_SUCCESS(BCryptOpenAlgorithmProvider(&g_sha256, BCRYPT_SHA256_ALGORITHM, nullptr, 0));
}

void Sha256Raw(const void* data, ULONG len, uint8_t out32[32]) {
	memset(out32, 0, 32);
	if (!EnsureSha256())
		return;
	BCRYPT_HASH_HANDLE h = nullptr;
	DWORD cb = 0;
	DWORD objLen = 0;
	BCryptGetProperty(g_sha256, BCRYPT_OBJECT_LENGTH, (PUCHAR)&objLen, sizeof(objLen), &cb, 0);
	std::vector<UCHAR> obj(objLen);
	if (!BCRYPT_SUCCESS(BCryptCreateHash(g_sha256, &h, obj.data(), objLen, nullptr, 0, 0)))
		return;
	BCryptHashData(h, (PUCHAR)data, len, 0);
	BCryptFinishHash(h, out32, 32, 0);
	BCryptDestroyHash(h);
}

std::wstring ReadRegSz(HKEY root, const wchar_t* sub, const wchar_t* value) {
	DWORD type = 0;
	DWORD need = 0;
	if (RegGetValueW(root, sub, value, RRF_RT_REG_SZ, &type, nullptr, &need) != ERROR_SUCCESS)
		return L"";
	std::wstring s(need / sizeof(wchar_t) + 2, L'\0');
	if (RegGetValueW(root, sub, value, RRF_RT_REG_SZ, &type, &s[0], &need) != ERROR_SUCCESS)
		return L"";
	s.resize(wcslen(s.c_str()));
	return s;
}

std::string NormalizeSerial(std::wstring w) {
	while (!w.empty() && (w.back() == L' ' || w.back() == L'\t'))
		w.pop_back();
	while (!w.empty() && (w[0] == L' ' || w[0] == L'\t'))
		w.erase(w.begin());
	for (auto& c : w)
		if (c >= L'A' && c <= L'Z')
			c = (wchar_t)(c - L'A' + L'a');
	std::string o;
	o.reserve(w.size());
	for (wchar_t c : w) {
		if (c < 128)
			o.push_back((char)c);
	}
	return o;
}

std::wstring WmiQueryFirstString(IWbemServices* pSvc, const wchar_t* wql, const wchar_t* propName) {
	std::wstring out;
	if (!pSvc)
		return out;
	IEnumWbemClassObject* pEnum = nullptr;
	BSTR lang = SysAllocString(L"WQL");
	BSTR query = SysAllocString(wql);
	if (!lang || !query) {
		if (lang)
			SysFreeString(lang);
		if (query)
			SysFreeString(query);
		return out;
	}
	HRESULT hr = pSvc->ExecQuery(lang, query, WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, nullptr, &pEnum);
	SysFreeString(query);
	SysFreeString(lang);
	if (FAILED(hr) || !pEnum)
		return out;
	IWbemClassObject* pObj = nullptr;
	ULONG uReturn = 0;
	hr = pEnum->Next(WBEM_INFINITE, 1, &pObj, &uReturn);
	pEnum->Release();
	if (FAILED(hr) || uReturn == 0 || !pObj)
		return out;
	VARIANT vt;
	VariantInit(&vt);
	hr = pObj->Get(propName, 0, &vt, nullptr, nullptr);
	pObj->Release();
	if (SUCCEEDED(hr) && vt.vt == VT_BSTR && vt.bstrVal && vt.bstrVal[0])
		out = vt.bstrVal;
	VariantClear(&vt);
	return out;
}

IWbemServices* OpenLocalWmiCimv2(bool* coUninitWhenDone) {
	*coUninitWhenDone = false;
	HRESULT hr = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
	if (FAILED(hr) && hr != RPC_E_CHANGED_MODE)
		return nullptr;
	if (hr == S_OK)
		*coUninitWhenDone = true;

	CoInitializeSecurity(nullptr, -1, nullptr, nullptr, RPC_C_AUTHN_LEVEL_DEFAULT,
		RPC_C_IMP_LEVEL_IMPERSONATE, nullptr, EOAC_NONE, nullptr);

	IWbemLocator* pLoc = nullptr;
	hr = CoCreateInstance(CLSID_WbemLocator, nullptr, CLSCTX_INPROC_SERVER, IID_IWbemLocator, (void**)&pLoc);
	if (FAILED(hr) || !pLoc) {
		if (*coUninitWhenDone) {
			CoUninitialize();
			*coUninitWhenDone = false;
		}
		return nullptr;
	}

	IWbemServices* pSvc = nullptr;
	BSTR ns = SysAllocString(L"ROOT\\CIMV2");
	hr = pLoc->ConnectServer(ns, nullptr, nullptr, nullptr, 0, nullptr, nullptr, &pSvc);
	SysFreeString(ns);
	pLoc->Release();
	if (FAILED(hr) || !pSvc) {
		if (*coUninitWhenDone) {
			CoUninitialize();
			*coUninitWhenDone = false;
		}
		return nullptr;
	}

	hr = CoSetProxyBlanket(pSvc, RPC_C_AUTHN_WINNT, RPC_C_AUTHZ_NONE, nullptr,
		RPC_C_AUTHN_LEVEL_CALL, RPC_C_IMP_LEVEL_IMPERSONATE, nullptr, EOAC_NONE);
	if (FAILED(hr)) {
		pSvc->Release();
		if (*coUninitWhenDone) {
			CoUninitialize();
			*coUninitWhenDone = false;
		}
		return nullptr;
	}
	return pSvc;
}

std::string BuildHardwareFingerprint() {
	bool comUninit = false;
	IWbemServices* pSvc = OpenLocalWmiCimv2(&comUninit);
	std::wstring wBios, wUuid, wBoard;
	if (pSvc) {
		wBios = WmiQueryFirstString(pSvc, L"SELECT SerialNumber FROM Win32_BIOS", L"SerialNumber");
		DebugPrintfWT(LogTag::Fingerprint, L"TimeLicense: Win32_BIOS.SerialNumber (WMI)=%ls",
			wBios.empty() ? L"(empty)" : wBios.c_str());
		wUuid = WmiQueryFirstString(pSvc, L"SELECT UUID FROM Win32_ComputerSystemProduct", L"UUID");
		DebugPrintfWT(LogTag::Fingerprint, L"TimeLicense: Win32_ComputerSystemProduct.UUID (WMI)=%ls",
			wUuid.empty() ? L"(empty)" : wUuid.c_str());
		wBoard = WmiQueryFirstString(pSvc, L"SELECT SerialNumber FROM Win32_BaseBoard", L"SerialNumber");
		DebugPrintfWT(LogTag::Fingerprint, L"TimeLicense: Win32_BaseBoard.SerialNumber (WMI)=%ls",
			wBoard.empty() ? L"(empty)" : wBoard.c_str());
		pSvc->Release();
	} else {
		DebugPrintfT(LogTag::Fingerprint, "TimeLicense: WMI unavailable, hardware id uses registry/defaults where needed");
	}
	if (comUninit)
		CoUninitialize();

	if (wBios.empty())
		wBios = ReadRegSz(HKEY_LOCAL_MACHINE, L"HARDWARE\\DESCRIPTION\\System\\BIOS", L"SystemSerialNumber");
	if (wBios.empty())
		wBios = ReadRegSz(HKEY_LOCAL_MACHINE, L"HARDWARE\\DESCRIPTION\\System\\BIOS", L"BaseBoardSerialNumber");
	if (wBoard.empty())
		wBoard = ReadRegSz(HKEY_LOCAL_MACHINE, L"HARDWARE\\DESCRIPTION\\System\\BIOS", L"BaseBoardSerialNumber");

	std::string bios = NormalizeSerial(std::move(wBios));
	std::string uuid = NormalizeSerial(std::move(wUuid));
	std::string board = NormalizeSerial(std::move(wBoard));
	if (bios.empty())
		bios = "unknownbios";
	if (uuid.empty())
		uuid = "unknownuuid";
	if (board.empty())
		board = "unknownboard";

	ULONG bufLen = sizeof(IP_ADAPTER_INFO);
	std::vector<BYTE> buf(bufLen);
	DWORD r = GetAdaptersInfo((PIP_ADAPTER_INFO)buf.data(), &bufLen);
	if (r == ERROR_BUFFER_OVERFLOW) {
		buf.resize(bufLen);
		r = GetAdaptersInfo((PIP_ADAPTER_INFO)buf.data(), &bufLen);
	}
	std::string macPart = "nomac";
	if (r == NO_ERROR) {
		for (PIP_ADAPTER_INFO a = (PIP_ADAPTER_INFO)buf.data(); a; a = a->Next) {
			if (a->Type == MIB_IF_TYPE_LOOPBACK)
				continue;
			if (a->AddressLength < 6)
				continue;
			char tmp[32];
			sprintf_s(tmp, "%02x-%02x-%02x-%02x-%02x-%02x",
				a->Address[0], a->Address[1], a->Address[2],
				a->Address[3], a->Address[4], a->Address[5]);
			macPart = tmp;
			break;
		}
	}

	DebugPrintfT(LogTag::Fingerprint, "TimeLicense: hwfp BIOS(normalized)=%s", bios.c_str());
	DebugPrintfT(LogTag::Fingerprint, "TimeLicense: hwfp UUID(normalized)=%s", uuid.c_str());
	DebugPrintfT(LogTag::Fingerprint, "TimeLicense: hwfp BaseBoard(normalized)=%s", board.c_str());
	DebugPrintfT(LogTag::Fingerprint, "TimeLicense: hwfp MAC=%s", macPart.c_str());
	std::string fp = bios + "|" + uuid + "|" + board + "|" + macPart;
	DebugPrintfT(LogTag::Fingerprint, "TimeLicense: hwfp full=%s", fp.c_str());
	return fp;
}

std::string GetHardwareFingerprint() {
	std::lock_guard<std::mutex> lock(g_hwFingerprintMutex);
	if (!g_hwFingerprintCached) {
		g_cachedHardwareFingerprint = BuildHardwareFingerprint();
		g_hwFingerprintCached = true;
	}
	return g_cachedHardwareFingerprint;
}

uint32_t ComputeMachineId8() {
	std::string fp = GetHardwareFingerprint();
	uint8_t h[32];
	Sha256Raw(fp.data(), (ULONG)fp.size(), h);
	uint32_t v = 0;
	for (int i = 0; i < 4; i++)
		v = (v << 8) | h[i];
	v ^= (uint32_t)h[4] | ((uint32_t)h[5] << 8) | ((uint32_t)h[6] << 16) | ((uint32_t)h[7] << 24);
	return v % 100000000u;
}

bool GetEntropyBytes(std::vector<BYTE>& out) {
	uint32_t mid = ComputeMachineId8();
	char s[16];
	sprintf_s(s, "%08u", mid);
	out.assign(s, s + 8);
	return true;
}

bool ProtectBlob(const BYTE* plain, DWORD plainLen, std::vector<BYTE>& out) {
	std::vector<BYTE> entropy;
	GetEntropyBytes(entropy);
	DATA_BLOB in{ plainLen, (BYTE*)plain };
	DATA_BLOB ent{ (DWORD)entropy.size(), entropy.data() };
	DATA_BLOB outb{ 0, nullptr };
	if (!CryptProtectData(&in, L"MerkurTimeLicense", &ent, nullptr, nullptr, 0, &outb))
		return false;
	out.assign(outb.pbData, outb.pbData + outb.cbData);
	if (outb.pbData)
		LocalFree(outb.pbData);
	return true;
}

bool UnprotectBlob(const BYTE* enc, DWORD encLen, std::vector<BYTE>& plain) {
	std::vector<BYTE> entropy;
	GetEntropyBytes(entropy);
	DATA_BLOB in{ encLen, (BYTE*)enc };
	DATA_BLOB ent{ (DWORD)entropy.size(), entropy.data() };
	DATA_BLOB out{ 0, nullptr };
	if (!CryptUnprotectData(&in, nullptr, &ent, nullptr, nullptr, 0, &out))
		return false;
	plain.assign(out.pbData, out.pbData + out.cbData);
	if (out.pbData)
		LocalFree(out.pbData);
	return true;
}

uint64_t GenerateLicenseCode(uint32_t machineId8, uint32_t yymm) {
	char buf[64];
	sprintf_s(buf, "MerkurTLv1|%08u|%04u", machineId8, yymm % 10000u);
	uint8_t h[32];
	Sha256Raw(buf, (ULONG)strlen(buf), h);
	uint64_t v = 0;
	memcpy(&v, h, sizeof(v));
	uint64_t v2 = 0;
	memcpy(&v2, h + 8, sizeof(v2));
	v ^= v2;
	return v % 1000000000000ULL;
}

int MonthIndexFromYymm(uint32_t yymm) {
	int yy = (int)(yymm / 100);
	int mm = (int)(yymm % 100);
	int fullYear = 2000 + yy;
	if (mm < 1 || mm > 12)
		return -1;
	return fullYear * 12 + (mm - 1);
}

bool CurrentMonthNotAfterExpiry(uint32_t expiryYymm) {
	SYSTEMTIME st{};
	GetLocalTime(&st);
	int cur = st.wYear * 12 + (st.wMonth - 1);
	int ex = MonthIndexFromYymm(expiryYymm);
	if (ex < 0)
		return false;
	return cur <= ex;
}

static void AddCalendarMonths(int& year, int& month, int deltaMonths) {
	month += deltaMonths;
	while (month <= 0) {
		month += 12;
		year--;
	}
	while (month > 12) {
		month -= 12;
		year++;
	}
}

/// First calendar month (YYMM) in search order whose hash matches code12 — ignores expiry (used to distinguish wrong code vs expired).
bool FindRawYymmForCode(uint64_t code12, uint32_t machineId8, uint32_t* outYymm) {
	SYSTEMTIME st{};
	GetLocalTime(&st);
	const int anchorY = (int)st.wYear;
	const int anchorM = (int)st.wMonth;
	for (int abs = 0; abs <= 120; abs++) {
		if (abs == 0) {
			int y = anchorY;
			int m = anchorM;
			uint32_t yymm = (uint32_t)((y % 100) * 100 + m);
			if (GenerateLicenseCode(machineId8, yymm) == code12) {
				*outYymm = yymm;
				return true;
			}
			continue;
		}
		for (int sign : {-1, 1}) {
			int y = anchorY;
			int m = anchorM;
			AddCalendarMonths(y, m, sign * abs);
			uint32_t yymm = (uint32_t)((y % 100) * 100 + m);
			if (GenerateLicenseCode(machineId8, yymm) == code12) {
				*outYymm = yymm;
				return true;
			}
		}
	}
	return false;
}

/// Monotonic wall-clock in UTC for license anti-tamper. Prefer this over local time + TZ conversion:
/// if TzSpecificLocalTimeToSystemTime fails (seen in some elevated runs), treating local as UTC skews FILETIME
/// and falsely triggers "clock before lastGoodUtc" vs a lastGoodUtc written when conversion succeeded.
static FILETIME UtcNowFileTime() {
	FILETIME ft{};
	GetSystemTimeAsFileTime(&ft);
	return ft;
}

static uint64_t FileTimeToUInt64(const FILETIME& ft) {
	ULARGE_INTEGER u;
	u.LowPart = ft.dwLowDateTime;
	u.HighPart = ft.dwHighDateTime;
	return u.QuadPart;
}

static void LogLicensePayloadAndUtcNow(LogTag tag, const char* ctx, size_t plainBlobBytes, const LicensePayload* p, const FILETIME& ftNowUtc) {
	SYSTEMTIME stLocal{};
	GetLocalTime(&stLocal);
	SYSTEMTIME stLastUtc{};
	SYSTEMTIME stNowUtc{};
	const BOOL okLast = FileTimeToSystemTime(&p->lastGoodUtc, &stLastUtc);
	const BOOL okNow = FileTimeToSystemTime(&ftNowUtc, &stNowUtc);
	DebugPrintfT(tag,
		"TimeLicense: %s after decrypt plain=%zu payload machineId8=%08u expiryYymm=%u code=%012llu "
		"lastGoodUtc=%016llx (%s %04u-%02u-%02u %02u:%02u:%02uZ) nowUtc=%016llx (%s %04u-%02u-%02u %02u:%02u:%02uZ) "
		"localWall=%04u-%02u-%02u %02u:%02u:%02u",
		ctx,
		plainBlobBytes,
		p->machineId8,
		p->expiryYymm,
		(unsigned long long)p->licenseCode12,
		(unsigned long long)FileTimeToUInt64(p->lastGoodUtc),
		okLast ? "ok" : "ft2st_fail",
		okLast ? stLastUtc.wYear : 0u,
		okLast ? stLastUtc.wMonth : 0u,
		okLast ? stLastUtc.wDay : 0u,
		okLast ? stLastUtc.wHour : 0u,
		okLast ? stLastUtc.wMinute : 0u,
		okLast ? stLastUtc.wSecond : 0u,
		(unsigned long long)FileTimeToUInt64(ftNowUtc),
		okNow ? "ok" : "ft2st_fail",
		okNow ? stNowUtc.wYear : 0u,
		okNow ? stNowUtc.wMonth : 0u,
		okNow ? stNowUtc.wDay : 0u,
		okNow ? stNowUtc.wHour : 0u,
		okNow ? stNowUtc.wMinute : 0u,
		okNow ? stNowUtc.wSecond : 0u,
		(unsigned int)stLocal.wYear,
		(unsigned int)stLocal.wMonth,
		(unsigned int)stLocal.wDay,
		(unsigned int)stLocal.wHour,
		(unsigned int)stLocal.wMinute,
		(unsigned int)stLocal.wSecond);
}

bool FileTimeLess(const FILETIME& a, const FILETIME& b) {
	ULARGE_INTEGER ua, ub;
	ua.LowPart = a.dwLowDateTime;
	ua.HighPart = a.dwHighDateTime;
	ub.LowPart = b.dwLowDateTime;
	ub.HighPart = b.dwHighDateTime;
	return ua.QuadPart < ub.QuadPart;
}

// Rollback check at hour granularity: ignore minute/second/sub-second drift so that
// normal wall-clock jitter (NTP, DST-ish adjustments, monitor-loop timing) does not
// falsely trip the "clock moved backward" branch. The monthly expiry is still enforced
// elsewhere, so date+hour resolution is sufficient for duration tamper detection.
static uint64_t FileTimeToHourBucket(const FILETIME& ft) {
	ULARGE_INTEGER u;
	u.LowPart = ft.dwLowDateTime;
	u.HighPart = ft.dwHighDateTime;
	// FILETIME is in 100 ns units; 1 hour = 3600 * 10'000'000 ticks.
	return u.QuadPart / 36000000000ULL;
}

static bool FileTimeLessByHour(const FILETIME& a, const FILETIME& b) {
	return FileTimeToHourBucket(a) < FileTimeToHourBucket(b);
}

bool GetValidUntilTextImpl(wchar_t* buf, size_t cch) {
	if (!buf || cch < 32)
		return false;
	buf[0] = 0;
	HANDLE hf = CreateFileW(TimeLicense::GetLicenseFilePath(), GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
	if (hf == INVALID_HANDLE_VALUE)
		return false;
	LARGE_INTEGER sz{};
	if (!GetFileSizeEx(hf, &sz) || sz.QuadPart <= 0 || sz.QuadPart > 1 << 20) {
		CloseHandle(hf);
		return false;
	}
	std::vector<BYTE> enc((size_t)sz.QuadPart);
	DWORD rd = 0;
	if (!ReadFile(hf, enc.data(), (DWORD)enc.size(), &rd, nullptr) || rd != enc.size()) {
		CloseHandle(hf);
		return false;
	}
	CloseHandle(hf);
	std::vector<BYTE> plain;
	if (!UnprotectBlob(enc.data(), (DWORD)enc.size(), plain))
		return false;
	if (plain.size() < sizeof(LicensePayload))
		return false;
	LicensePayload* p = (LicensePayload*)plain.data();
	if (memcmp(p->magic, kMagicBytes, 4) != 0 || p->version != kBlobVersion)
		return false;
	if (p->machineId8 != TimeLicense::GetMachineId8())
		return false;
	const FILETIME ftNow = UtcNowFileTime();
	if (FileTimeLessByHour(ftNow, p->lastGoodUtc))
		return false;
	if (!CurrentMonthNotAfterExpiry(p->expiryYymm))
		return false;
	if (GenerateLicenseCode(p->machineId8, p->expiryYymm) != p->licenseCode12)
		return false;
	const int yy = (int)(p->expiryYymm / 100);
	const int mm = (int)(p->expiryYymm % 100);
	if (mm < 1 || mm > 12)
		return false;
	static const wchar_t* const kMonths[12] = {
		L"January", L"February", L"March", L"April", L"May", L"June",
		L"July", L"August", L"September", L"October", L"November", L"December"
	};
	const int fullYear = 2000 + yy;
	swprintf_s(buf, cch, L"Valid until: %s %d", kMonths[mm - 1], fullYear);
	return true;
}

} // namespace

namespace TimeLicense {

uint32_t GetMachineId8() {
	std::lock_guard<std::mutex> lock(g_idMutex);
	if (!g_machineIdReady) {
		g_cachedMachineId8 = ComputeMachineId8();
		g_machineIdReady = true;
		DebugPrintfT(LogTag::Fingerprint, "TimeLicense: machineId8=%08u", g_cachedMachineId8);
	}
	return g_cachedMachineId8;
}

bool IsLicensedOk() {
	return g_licensedOk.load();
}

void RequestLicenseDialog() {
	g_wantLicenseDialog.store(true);
}

void PollLicenseDialogQueue() {
	if (!g_wantLicenseDialog.load())
		return;
	RefreshFromDisk();
	if (g_licensedOk.load()) {
		g_wantLicenseDialog.store(false);
		DebugPrintfT(LogTag::Fingerprint, "TimeLicense: PollLicenseDialogQueue cleared (licensed after refresh)");
		return;
	}
	if (!g_wantLicenseDialog.exchange(false))
		return;
	DebugPrintfT(LogTag::Fingerprint, "TimeLicense: PollLicenseDialogQueue showing modal");
	TimeLicense_ShowModalDialog();
}

void OnInitSerialDone() {
	std::call_once(g_initSerialOnce, [] {
		GetMachineId8();
		RefreshFromDisk();
		if (!g_licensedOk.load()) {
			DebugPrintfT(LogTag::Fingerprint, "TimeLicense: OnInitSerialDone not licensed, requesting dialog");
			RequestLicenseDialog();
		} else {
			DebugPrintfT(LogTag::Fingerprint, "TimeLicense: OnInitSerialDone licensed OK");
		}
		StartMonitorThread();
	});
}

void RefreshFromDisk() {
	g_licensedOk.store(false);

	HANDLE hf = CreateFileW(GetLicenseFilePath(), GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
	if (hf == INVALID_HANDLE_VALUE) {
		DebugPrintfWT(LogTag::Fingerprint, L"TimeLicense: RefreshFromDisk no file (err=%lu) path=%ls",
			GetLastError(), GetLicenseFilePath());
		return;
	}
	LARGE_INTEGER sz{};
	if (!GetFileSizeEx(hf, &sz) || sz.QuadPart <= 0 || sz.QuadPart > 1 << 20) {
		CloseHandle(hf);
		DebugPrintfT(LogTag::Fingerprint, "TimeLicense: RefreshFromDisk bad file size");
		return;
	}
	std::vector<BYTE> enc((size_t)sz.QuadPart);
	DWORD rd = 0;
	if (!ReadFile(hf, enc.data(), (DWORD)enc.size(), &rd, nullptr) || rd != enc.size()) {
		CloseHandle(hf);
		DebugPrintfT(LogTag::Fingerprint, "TimeLicense: RefreshFromDisk read incomplete");
		return;
	}
	CloseHandle(hf);

	std::vector<BYTE> plain;
	if (!UnprotectBlob(enc.data(), (DWORD)enc.size(), plain)) {
		DebugPrintfT(LogTag::Fingerprint, "TimeLicense: RefreshFromDisk CryptUnprotectData failed");
		return;
	}
	DebugPrintfT(LogTag::Fingerprint, "TimeLicense: RefreshFromDisk decrypt ok encFile=%zu plain=%zu",
		enc.size(), plain.size());
	if (plain.size() < sizeof(LicensePayload)) {
		DebugPrintfT(LogTag::Fingerprint, "TimeLicense: RefreshFromDisk plain too small (%zu)", plain.size());
		return;
	}
	LicensePayload* p = (LicensePayload*)plain.data();
	if (memcmp(p->magic, kMagicBytes, 4) != 0 || p->version != kBlobVersion) {
		DebugPrintfT(LogTag::Fingerprint, "TimeLicense: RefreshFromDisk bad magic/version");
		return;
	}
	const uint32_t mid = GetMachineId8();
	if (p->machineId8 != mid) {
		DebugPrintfT(LogTag::Fingerprint, "TimeLicense: RefreshFromDisk machineId mismatch file=%08u current=%08u",
			p->machineId8, mid);
		return;
	}

	const FILETIME ftNow = UtcNowFileTime();
	LogLicensePayloadAndUtcNow(LogTag::Fingerprint, "RefreshFromDisk", plain.size(), p, ftNow);

	if (FileTimeLessByHour(ftNow, p->lastGoodUtc)) {
		// Clock moved backward by at least one hour vs persisted time.
		g_licensedOk.store(false);
		const long long delta100ns = (long long)FileTimeToUInt64(ftNow) - (long long)FileTimeToUInt64(p->lastGoodUtc);
		DebugPrintfT(LogTag::Fingerprint,
			"TimeLicense: RefreshFromDisk clock before lastGoodUtc (hour) delta100ns=%lld (negative => now < lastGood)",
			delta100ns);
		RequestLicenseDialog();
		return;
	}

	if (!CurrentMonthNotAfterExpiry(p->expiryYymm)) {
		g_licensedOk.store(false);
		DebugPrintfT(LogTag::Fingerprint, "TimeLicense: RefreshFromDisk expired expiryYymm=%u", p->expiryYymm);
		RequestLicenseDialog();
		return;
	}

	const uint64_t expected = GenerateLicenseCode(p->machineId8, p->expiryYymm);
	if (expected != p->licenseCode12) {
		DebugPrintfT(LogTag::Fingerprint,
			"TimeLicense: RefreshFromDisk licenseCode mismatch stored=%012llu expected=%012llu expiryYymm=%u",
			(unsigned long long)p->licenseCode12, (unsigned long long)expected, p->expiryYymm);
		return;
	}

	g_licensedOk.store(true);
	DebugPrintfT(LogTag::Fingerprint,
		"TimeLicense: RefreshFromDisk OK machineId8=%08u expiryYymm=%u code=%012llu",
		p->machineId8, p->expiryYymm, (unsigned long long)p->licenseCode12);
}

static void EnsureLicenseFileDirectoryExists()
{
	const wchar_t* path = GetLicenseFilePath();
	if (!path || !path[0])
		return;
	std::wstring p(path);
	const size_t pos = p.find_last_of(L'\\');
	if (pos != std::wstring::npos && pos > 0)
		CreateDirectoryW(p.substr(0, pos).c_str(), nullptr);
}

bool TryGetValidUntilDisplayText(wchar_t* buf, size_t cch) {
	return GetValidUntilTextImpl(buf, cch);
}

bool ValidateAndApplyEnteredCode(uint64_t code12, wchar_t* errMsg, size_t errCch) {
	auto setErr = [&](const wchar_t* s) {
		if (errMsg && errCch)
			wcsncpy_s(errMsg, errCch, s, _TRUNCATE);
	};

	uint32_t mid = GetMachineId8();
	uint32_t yymm = 0;
	if (!FindRawYymmForCode(code12, mid, &yymm)) {
		DebugPrintfT(LogTag::Fingerprint,
			"TimeLicense: ValidateAndApplyEnteredCode no yymm for code=%012llu machineId8=%08u",
			(unsigned long long)code12, mid);
		setErr(L"License code does not match this machine ID.");
		return false;
	}
	if (!CurrentMonthNotAfterExpiry(yymm)) {
		DebugPrintfT(LogTag::Fingerprint,
			"TimeLicense: ValidateAndApplyEnteredCode code month expired yymm=%u machineId8=%08u",
			yymm, mid);
		setErr(L"This license month has expired (check Windows date is within the licensed month).");
		return false;
	}

	const FILETIME ftNow = UtcNowFileTime();

	LicensePayload pay{};
	memcpy(pay.magic, kMagicBytes, 4);
	pay.version = kBlobVersion;
	pay.lastGoodUtc = ftNow;
	pay.licenseCode12 = code12;
	pay.expiryYymm = yymm;
	pay.machineId8 = mid;

	std::vector<BYTE> enc;
	if (!ProtectBlob((const BYTE*)&pay, sizeof(pay), enc)) {
		DebugPrintfT(LogTag::Fingerprint, "TimeLicense: ValidateAndApplyEnteredCode ProtectBlob failed");
		setErr(L"Could not encrypt license (DPAPI).");
		return false;
	}

	EnsureLicenseFileDirectoryExists();
	HANDLE hf = CreateFileW(GetLicenseFilePath(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
	if (hf == INVALID_HANDLE_VALUE) {
		DebugPrintfWT(LogTag::Fingerprint, L"TimeLicense: ValidateAndApplyEnteredCode open write failed err=%lu path=%ls",
			GetLastError(), GetLicenseFilePath());
		setErr(L"Cannot write dialog\\time.io next to the game (check folder permissions).");
		return false;
	}
	DWORD wr = 0;
	BOOL ok = WriteFile(hf, enc.data(), (DWORD)enc.size(), &wr, nullptr);
	CloseHandle(hf);
	if (!ok || wr != enc.size()) {
		DebugPrintfT(LogTag::Fingerprint, "TimeLicense: ValidateAndApplyEnteredCode WriteFile incomplete ok=%d wr=%lu size=%zu",
			(int)ok, (unsigned long)wr, enc.size());
		setErr(L"Could not save license file completely.");
		return false;
	}

	g_licensedOk.store(true);
	DebugPrintfT(LogTag::Fingerprint,
		"TimeLicense: ValidateAndApplyEnteredCode OK wrote time.io machineId8=%08u yymm=%u code=%012llu",
		mid, yymm, (unsigned long long)code12);
	return true;
}

static void MonitorLoop() {
	for (;;) {
		RefreshFromDisk();
		if (!g_licensedOk.load()) {
			RequestLicenseDialog();
		} else {
			HANDLE hf = CreateFileW(GetLicenseFilePath(), GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
			if (hf == INVALID_HANDLE_VALUE) {
				DebugPrintfT(LogTag::Fingerprint, "TimeLicense: MonitorLoop licensed but file missing err=%lu", GetLastError());
				g_licensedOk.store(false);
				RequestLicenseDialog();
			} else {
				LARGE_INTEGER sz{};
				if (!GetFileSizeEx(hf, &sz) || sz.QuadPart <= 0) {
					CloseHandle(hf);
					DebugPrintfT(LogTag::Fingerprint, "TimeLicense: MonitorLoop licensed but file size invalid");
					g_licensedOk.store(false);
					RequestLicenseDialog();
				} else {
					std::vector<BYTE> enc((size_t)sz.QuadPart);
					DWORD rd = 0;
					ReadFile(hf, enc.data(), (DWORD)enc.size(), &rd, nullptr);
					CloseHandle(hf);

					std::vector<BYTE> plain;
					if (!UnprotectBlob(enc.data(), (DWORD)enc.size(), plain) || plain.size() < sizeof(LicensePayload)) {
						DebugPrintfT(LogTag::Fingerprint, "TimeLicense: MonitorLoop decrypt/payload size fail");
						g_licensedOk.store(false);
						RequestLicenseDialog();
					} else {
						LicensePayload* p = (LicensePayload*)plain.data();
						if (memcmp(p->magic, kMagicBytes, 4) != 0 || p->version != kBlobVersion
							|| p->machineId8 != GetMachineId8()
							|| GenerateLicenseCode(p->machineId8, p->expiryYymm) != p->licenseCode12
							|| !CurrentMonthNotAfterExpiry(p->expiryYymm)) {
							DebugPrintfT(LogTag::Fingerprint, "TimeLicense: MonitorLoop payload invalid (magic/machine/code/expiry)");
							g_licensedOk.store(false);
							RequestLicenseDialog();
						} else {
							const FILETIME ftNow = UtcNowFileTime();
							if (FileTimeLessByHour(ftNow, p->lastGoodUtc)) {
								const long long delta100ns = (long long)FileTimeToUInt64(ftNow) - (long long)FileTimeToUInt64(p->lastGoodUtc);
								DebugPrintfT(LogTag::Fingerprint,
									"TimeLicense: MonitorLoop clock before lastGoodUtc (hour) delta100ns=%lld",
									delta100ns);
								g_licensedOk.store(false);
								RequestLicenseDialog();
							} else {
								p->lastGoodUtc = ftNow;
								std::vector<BYTE> enc2;
								if (!ProtectBlob((const BYTE*)p, sizeof(LicensePayload), enc2)) {
									DebugPrintfT(LogTag::Fingerprint, "TimeLicense: MonitorLoop ProtectBlob(lastGoodUtc) failed");
									g_licensedOk.store(false);
								} else {
									EnsureLicenseFileDirectoryExists();
									HANDLE hw = CreateFileW(GetLicenseFilePath(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
									if (hw == INVALID_HANDLE_VALUE) {
										DebugPrintfT(LogTag::Fingerprint, "TimeLicense: MonitorLoop write lastGoodUtc open failed err=%lu",
											GetLastError());
										g_licensedOk.store(false);
									} else {
										DWORD wr = 0;
										WriteFile(hw, enc2.data(), (DWORD)enc2.size(), &wr, nullptr);
										CloseHandle(hw);
										g_licensedOk.store(true);
									}
								}
							}
						}
					}
				}
			}
		}
		std::this_thread::sleep_for(std::chrono::seconds(60));
	}
}

void StartMonitorThread() {
	std::call_once(g_monitorOnce, [] {
		std::thread(MonitorLoop).detach();
	});
}

} // namespace TimeLicense
