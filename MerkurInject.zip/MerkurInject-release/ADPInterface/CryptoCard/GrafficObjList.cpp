#include "stdafx.h"
#include "GrafficObjList.h"
#include "Utils.h"

GrafficObjList g_GrafficObjList;


GrafficObjList::GrafficObjList() {
	m_bInitialized = FALSE;

    m_mapGame2GOC.insert(std::make_pair("RgFruitinator", "CFRT"));
}

int GrafficObjList::Load() {
	if (m_bInitialized) {
		return 0;
	}

    FILE* fp = NULL;
    fopen_s(&fp, "graficObjList.txt", "rb");

    if (!fp) {
        DebugPrintf("failed to open file graficObjList.txt\n");
        return -1;
    }
    char line[0x400] = { 0 };

    typedef struct {
        int id;
        char label[0x100];
        char type[0x100];
    } Entry;

    while (fgets(line, sizeof(line), fp)) {
        line[strcspn(line, "\n")] = '\0';
        if (strlen(line) == 0) {
            continue;
        }
        Entry e;
        if (sscanf(line, "%d %99s %99s", &e.id, e.label, e.type) == 3) {
            grafficObjType objType = Str2Type(e.type);

            grafficObj o;
            memset(&o, 0, sizeof(grafficObj));
            o.t = objType;
            strcpy(o.id, e.label);
            m_vecObj.push_back(o);
        }
        else {
            DebugPrintf("Failed to parse line: %s\n", line);
        }
    }

    //PrintList();

    m_bInitialized = TRUE;
    return 0;
}

grafficObjType GrafficObjList::Str2Type(char* str) {
    if (strcmp(str, "StartUpText") == 0) {
        return grafficObjType::StartUpText;
    }
    else if (strcmp(str, "ErrorMeldung") == 0) {
        return grafficObjType::ErrorMeldung;
    }
    else if (strcmp(str, "ReelGame") == 0) {
        return grafficObjType::ReelGame;
    }
    else if (strcmp(str, "Button") == 0) {
        return grafficObjType::Button;
    }
    else if (strcmp(str, "Sprite") == 0) {
        return grafficObjType::Sprite;
    }
    else if (strcmp(str, "Video") == 0) {
        return grafficObjType::Video;
    }
    else if (strcmp(str, "WinLine") == 0) {
        return grafficObjType::WinLine;
    }
    else if (strcmp(str, "ReelContainer") == 0) {
        return grafficObjType::ReelContainer;
    }
    else if (strcmp(str, "Meter") == 0) {
        return grafficObjType::Meter;
    }
    else if (strcmp(str, "Meter2") == 0) {
        return grafficObjType::Meter2;
    }
    else if (strcmp(str, "MerkurFont") == 0) {
        return grafficObjType::MerkurFont;
    }
    else if (strcmp(str, "ReelStrip") == 0) {
        return grafficObjType::ReelStrip;
    }
    else if (strcmp(str, "FeatureGame") == 0) {
        return grafficObjType::FeatureGame;
    }
    else if (strcmp(str, "BinkVideo") == 0) {
        return grafficObjType::BinkVideo;
    }
    else if (strcmp(str, "CompositeMeter") == 0) {
        return grafficObjType::CompositeMeter;
    }
    else if (strcmp(str, "SpriteFont") == 0) {
        return grafficObjType::SpriteFont;
    }
    else if (strcmp(str, "MultiGo") == 0) {
        return grafficObjType::MultiGo;
    }
    else if (strcmp(str, "Event") == 0) {
        return grafficObjType::Event;
    }
    else if (strcmp(str, "VideoBink") == 0) {
        return grafficObjType::VideoBink;
    }
    else if (strcmp(str, "Game") == 0) {
        return grafficObjType::Game;
    }
    else if (strcmp(str, "Disc") == 0) {
        return grafficObjType::Disc;
    }
    else if (strcmp(str, "Layer") == 0) {
        return grafficObjType::Layer;
    }
    else if (strcmp(str, "Service") == 0) {
        return grafficObjType::Service;
    }
    else if (strcmp(str, "Menue") == 0) {
        return grafficObjType::Menue;
    }
    else if (strcmp(str, "Meter2Scroll") == 0) {
        return grafficObjType::Meter2Scroll;
    }
    else if (strcmp(str, "Meter2Scroll2") == 0) {
        return grafficObjType::Meter2Scroll2;
    }
    else if (strcmp(str, "Sound") == 0) {
        return grafficObjType::Sound;
    }
    else if (strcmp(str, "TextBox") == 0) {
        return grafficObjType::TextBox;
    }
    else if (strcmp(str, "PanelMeter") == 0) {
        return grafficObjType::PanelMeter;
    }

    printf("failed to convert string to graffic object type\n");
    return grafficObjType::MAX_TYPE_NUM;
}

void GrafficObjList::PrintList() {
    for (size_t i = 0; i < m_vecObj.size(); ++i) {
        DebugPrintf("%zu  %s\n", i, Type2Str(AT(m_vecObj, i).t));
    }
}

char* GrafficObjList::Type2Str(grafficObjType type) {
    if (grafficObjType::StartUpText == type) {
        return (char*)"StartUpText";
    }
    else if (grafficObjType::ErrorMeldung == type) {
        return (char*)"ErrorMeldung";
    }
    else if (grafficObjType::ReelGame == type) {
        return (char*)"ReelGame";
    }
    else if (grafficObjType::Button == type) {
        return (char*)"Button";
    }
    else if (grafficObjType::Sprite == type) {
        return (char*)"Sprite";
    }
    else if (grafficObjType::Video == type) {
        return (char*)"Video";
    }
    else if (grafficObjType::WinLine == type) {
        return (char*)"WinLine";
    }
    else if (grafficObjType::ReelContainer == type) {
        return (char*)"ReelContainer";
    }
    else if (grafficObjType::Meter == type) {
        return (char*)"Meter";
    }
    else if (grafficObjType::Meter2 == type) {
        return (char*)"Meter2";
    }
    else if (grafficObjType::MerkurFont == type) {
        return (char*)"MerkurFont";
    }
    else if (grafficObjType::ReelStrip == type) {
        return (char*)"ReelStrip";
    }
    else if (grafficObjType::FeatureGame == type) {
        return (char*)"FeatureGame";
    }
    else if (grafficObjType::BinkVideo == type) {
        return (char*)"BinkVideo";
    }
    else if (grafficObjType::CompositeMeter == type) {
        return (char*)"CompositeMeter";
    }
    else if (grafficObjType::SpriteFont == type) {
        return (char*)"SpriteFont";
    }
    else if (grafficObjType::MultiGo == type) {
        return (char*)"MultiGo";
    }
    else if (grafficObjType::Event == type) {
        return (char*)"Event";
    }
    else if (grafficObjType::VideoBink == type) {
        return (char*)"VideoBink";
    }
    else if (grafficObjType::Game == type) {
        return (char*)"Game";
    }
    else if (grafficObjType::Disc == type) {
        return (char*)"Disc";
    }
    else if (grafficObjType::Layer == type) {
        return (char*)"Layer";
    }
    else if (grafficObjType::Service == type) {
        return (char*)"Service";
    }
    else if (grafficObjType::Menue == type) {
        return (char*)"Menue";
    }
    else if (grafficObjType::Meter2Scroll == type) {
        return (char*)"Meter2Scroll";
    }
    else if (grafficObjType::Meter2Scroll2 == type) {
        return (char*)"Meter2Scroll2";
    }
    else if (grafficObjType::Sound == type) {
        return (char*)"Sound";
    }
    else if (grafficObjType::TextBox == type) {
        return (char*)"TextBox";
    }
    else if (grafficObjType::PanelMeter == type) {
        return (char*)"PanelMeter";
    }
    return 0;
}

std::string GrafficObjList::ReelGame2GOC(const std::string reelGame) {
    auto it = m_mapGame2GOC.find(reelGame);
    if (it != m_mapGame2GOC.end()) {
        return it->second;
    }
    else {
        return "";
    }
}

int GrafficObjList::Str2GOCID(const std::string id) {
    int index = 0;
    for (const auto& obj : m_vecObj) {
        if (obj.id == id) {
            return index;
        }
        ++index;
    }
    return -1;
}

std::string ConvertSymbolAutoPrefix(const std::string& symbol) {
    // Find position of first underscore
    size_t pos = symbol.find('_');
    if (pos == std::string::npos) {
        // No underscore found: just return lowercased symbol
        std::string lowerSymbol = symbol;
        std::transform(lowerSymbol.begin(), lowerSymbol.end(), lowerSymbol.begin(), ::tolower);
        return lowerSymbol;
    }

    // The prefix includes the underscore itself (e.g. "CFRT_")
    std::string prefix = symbol.substr(0, pos + 1);

    // The core part after the prefix
    std::string core = symbol.substr(pos + 1);

    // Remove trailing underscores from core
    while (!core.empty() && core.back() == '_') {
        core.pop_back();
    }

    // Capitalize first letter of core, lowercase the rest
    if (!core.empty()) {
        core[0] = std::toupper(core[0]);
        for (size_t i = 1; i < core.size(); ++i) {
            core[i] = std::tolower(core[i]);
        }
    }

    // Lowercase prefix and remove underscores from prefix for camelCase style
    std::string lowerPrefix;
    for (char ch : prefix) {
        if (ch != '_') {
            lowerPrefix.push_back(std::tolower(ch));
        }
    }

    return lowerPrefix + core;
}