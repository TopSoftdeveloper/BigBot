#include "stdafx.h"
#include "StateMachine.h"
#include "GrafficObjList.h"
#include "KomProtocol.h"
#include "Game/RgFruitinator.h"
#include "Game/RgDragonsTreas.h"
#include <chrono>
#include "Utils.h"
#include "headerSoundIds.h"
#include "CryptoCard/Cryptocard.h"
#include <limits>
#include "mmcode.h"
#include "OneMinitorManipulation.h"
#include "TimeLicense.h"
#include <algorithm> // for std::min/max (not clamp)
#include <cmath>

#define CHANGE_STATUS(x) SetStatusAndDebug(__FILE__, __LINE__, __func__, x)

UINT8 gGambleCards[] = {
	0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, // diamond, red card
	0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2a, 0x2b, 0x2c, 0x2d, 0x2e, // heart, red card
	0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4a, 0x4b, 0x4c, 0x4d, 0x4e, // black
	0x82, 0x83, 0x84, 0x85, 0x86, 0x87, 0x88, 0x89, 0x8a, 0x8b, 0x8c, 0x8d, 0x8e // black
};

std::atomic<double> gTotalWin{0.0};
std::atomic<double> gTotalBet{0.0};
double gTargetRTP = VARIANT_A;

#define AUTO_RETURN_TO_MENU_TIME	(60 * 1000)
#define AUTO_MOVE_BONUS_TIME		(60 * 1000)

#define Magic_MP_AG_LB_x_reel   0x01
#define Magic_MP_AG_LB_x_pos    0x11
#define Magic_MP_AG_LB_y_row    0x01
#define Magic_MP_AG_LB_y_pos    0x5E
#define Magic_MP_AG_RT_x_reel   0x02
#define Magic_MP_AG_RT_x_pos    0xAA
#define Magic_MP_AG_RT_y_row    0x01
#define Magic_MP_AG_RT_y_pos    0xC6
#define Magic_MP_1000_LB_x_reel   0x01
#define Magic_MP_1000_LB_x_pos    0x11
#define Magic_MP_1000_LB_y_row    0x00
#define Magic_MP_1000_LB_y_pos    0xC7
#define Magic_MP_1000_RT_x_reel   0x02
#define Magic_MP_1000_RT_x_pos    0xAA
#define Magic_MP_1000_RT_y_row    0x01
#define Magic_MP_1000_RT_y_pos    0x26

#define CardGamble_MP_half_LB_x_reel   0x02
#define CardGamble_MP_half_LB_x_pos    0xD9
#define CardGamble_MP_half_LB_y_row    0x00
#define CardGamble_MP_half_LB_y_pos    0xCC
#define CardGamble_MP_half_RT_x_reel   0x03
#define CardGamble_MP_half_RT_x_pos    0x2B
#define CardGamble_MP_half_RT_y_row    0x00
#define CardGamble_MP_half_RT_y_pos    0xF4

#define CardGamble_MP_risiko_LB_x_reel   0x02
#define CardGamble_MP_risiko_LB_x_pos    0xD7
#define CardGamble_MP_risiko_LB_y_row    0x00
#define CardGamble_MP_risiko_LB_y_pos    0x95
#define CardGamble_MP_risiko_RT_x_reel   0x03
#define CardGamble_MP_risiko_RT_x_pos    0x2B
#define CardGamble_MP_risiko_RT_y_row    0x00
#define CardGamble_MP_risiko_RT_y_pos    0xBD

#define CardGamble_MP_black_LB_x_reel   0x02
#define CardGamble_MP_black_LB_x_pos    0x2B
#define CardGamble_MP_black_LB_y_row    0x00
#define CardGamble_MP_black_LB_y_pos    0x9C
#define CardGamble_MP_black_RT_x_reel   0x02
#define CardGamble_MP_black_RT_x_pos    0x84
#define CardGamble_MP_black_RT_y_row    0x00
#define CardGamble_MP_black_RT_y_pos    0xF3

#define CardGamble_MP_red_LB_x_reel   0x01
#define CardGamble_MP_red_LB_x_pos    0xA8
#define CardGamble_MP_red_LB_y_row    0x00
#define CardGamble_MP_red_LB_y_pos    0x9B
#define CardGamble_MP_red_RT_x_reel   0x02
#define CardGamble_MP_red_RT_x_pos    0x02
#define CardGamble_MP_red_RT_y_row    0x00
#define CardGamble_MP_red_RT_y_pos    0xF3

#define Risiko_MP_card_LB_x_reel   0x03
#define Risiko_MP_card_LB_x_pos    0x13
#define Risiko_MP_card_LB_y_row    0x00
#define Risiko_MP_card_LB_y_pos    0x9a
#define Risiko_MP_card_RT_x_reel   0x03
#define Risiko_MP_card_RT_x_pos    0x67
#define Risiko_MP_card_RT_y_row    0x00
#define Risiko_MP_card_RT_y_pos    0xc1

#define Risiko_MP_down_LB_x_reel   0x02
#define Risiko_MP_down_LB_x_pos    0x47
#define Risiko_MP_down_LB_y_row    0x00
#define Risiko_MP_down_LB_y_pos    0x99
#define Risiko_MP_down_RT_x_reel   0x02
#define Risiko_MP_down_RT_x_pos    0x9A
#define Risiko_MP_down_RT_y_row    0x00
#define Risiko_MP_down_RT_y_pos    0xc2

#define RgLosFrootos_MP_betup_LB_x_reel   0x02
#define RgLosFrootos_MP_betup_LB_x_pos    0x4E
#define RgLosFrootos_MP_betup_LB_y_row    0x00
#define RgLosFrootos_MP_betup_LB_y_pos    0xD0
#define RgLosFrootos_MP_betup_RT_x_reel   0x02
#define RgLosFrootos_MP_betup_RT_x_pos    0x6F
#define RgLosFrootos_MP_betup_RT_y_row    0x00
#define RgLosFrootos_MP_betup_RT_y_pos    0xE6

#define RgLosFrootos_MP_betdown_LB_x_reel   0x01
#define RgLosFrootos_MP_betdown_LB_x_pos    0x56
#define RgLosFrootos_MP_betdown_LB_y_row    0x00
#define RgLosFrootos_MP_betdown_LB_y_pos    0xCD
#define RgLosFrootos_MP_betdown_RT_x_reel   0x01
#define RgLosFrootos_MP_betdown_RT_x_pos    0x77
#define RgLosFrootos_MP_betdown_RT_y_row    0x00
#define RgLosFrootos_MP_betdown_RT_y_pos    0xE6

#define RgLosFrootos_MP_close_LB_x_reel   0x01
#define RgLosFrootos_MP_close_LB_x_pos    0x3D
#define RgLosFrootos_MP_close_LB_y_row    0x01
#define RgLosFrootos_MP_close_LB_y_pos    0x0D
#define RgLosFrootos_MP_close_RT_x_reel   0x01
#define RgLosFrootos_MP_close_RT_x_pos    0x93
#define RgLosFrootos_MP_close_RT_y_row    0x01
#define RgLosFrootos_MP_close_RT_y_pos    0x3A

#define RgLosFrootos_MP_go_LB_x_reel   0x02
#define RgLosFrootos_MP_go_LB_x_pos    0x2F
#define RgLosFrootos_MP_go_LB_y_row    0x01
#define RgLosFrootos_MP_go_LB_y_pos    0x0B
#define RgLosFrootos_MP_go_RT_x_reel   0x02
#define RgLosFrootos_MP_go_RT_x_pos    0x85
#define RgLosFrootos_MP_go_RT_y_row    0x01
#define RgLosFrootos_MP_go_RT_y_pos    0x3C

#define RgPharosGoldBase_MP_betup_LB_x_reel 0x02
#define RgPharosGoldBase_MP_betup_LB_x_pos 0x3F
#define RgPharosGoldBase_MP_betup_LB_y_row 0x00
#define RgPharosGoldBase_MP_betup_LB_y_pos 0xC1
#define RgPharosGoldBase_MP_betup_RT_x_reel 0x02 
#define RgPharosGoldBase_MP_betup_RT_x_pos 0x92
#define RgPharosGoldBase_MP_betup_RT_y_row 0x01
#define RgPharosGoldBase_MP_betup_RT_y_pos 0x44
#define RgPharosGoldBase_MP_betdown_LB_x_reel 0x01
#define RgPharosGoldBase_MP_betdown_LB_x_pos 0x3A
#define RgPharosGoldBase_MP_betdown_LB_y_row 0x00
#define RgPharosGoldBase_MP_betdown_LB_y_pos 0xC1
#define RgPharosGoldBase_MP_betdown_RT_x_reel 0x01
#define RgPharosGoldBase_MP_betdown_RT_x_pos 0x81
#define RgPharosGoldBase_MP_betdown_RT_y_row 0x00
#define RgPharosGoldBase_MP_betdown_RT_y_pos 0xF3
#define RgPharosGoldBase_MP_close_LB_x_reel 0x01
#define RgPharosGoldBase_MP_close_LB_x_pos 0x2C
#define RgPharosGoldBase_MP_close_LB_y_row 0x01
#define RgPharosGoldBase_MP_close_LB_y_pos 0x07
#define RgPharosGoldBase_MP_close_RT_x_reel 0x01
#define RgPharosGoldBase_MP_close_RT_x_pos 0xA7
#define RgPharosGoldBase_MP_close_RT_y_row 0x01
#define RgPharosGoldBase_MP_close_RT_y_pos 0x42
#define RgPharosGoldBase_MP_go_LB_x_reel 0x02
#define RgPharosGoldBase_MP_go_LB_x_pos 0x1A
#define RgPharosGoldBase_MP_go_LB_y_row 0x01
#define RgPharosGoldBase_MP_go_LB_y_pos 0x07
#define RgPharosGoldBase_MP_go_RT_x_reel 0x02
#define RgPharosGoldBase_MP_go_RT_x_pos 0x93
#define RgPharosGoldBase_MP_go_RT_y_row 0x01
#define RgPharosGoldBase_MP_go_RT_y_pos 0x42

#define RgDragonsTreas_MP_free_SCHATZ_LB_x_reel   0x01
#define RgDragonsTreas_MP_free_SCHATZ_LB_x_pos    0x20
#define RgDragonsTreas_MP_free_SCHATZ_LB_y_row    0x01
#define RgDragonsTreas_MP_free_SCHATZ_LB_y_pos    0x7A
#define RgDragonsTreas_MP_free_SCHATZ_RT_x_reel   0x01
#define RgDragonsTreas_MP_free_SCHATZ_RT_x_pos    0x7F
#define RgDragonsTreas_MP_free_SCHATZ_RT_y_row    0x01
#define RgDragonsTreas_MP_free_SCHATZ_RT_y_pos    0xD6

#define RgDragonsTreas_MP_free_SIEGFR_LB_x_reel   0x01
#define RgDragonsTreas_MP_free_SIEGFR_LB_x_pos    0xAA
#define RgDragonsTreas_MP_free_SIEGFR_LB_y_row    0x01
#define RgDragonsTreas_MP_free_SIEGFR_LB_y_pos    0x84
#define RgDragonsTreas_MP_free_SIEGFR_RT_x_reel   0x02
#define RgDragonsTreas_MP_free_SIEGFR_RT_x_pos    0x17
#define RgDragonsTreas_MP_free_SIEGFR_RT_y_row    0x01
#define RgDragonsTreas_MP_free_SIEGFR_RT_y_pos    0xE8

#define RgDragonsTreas_MP_free_SCHWER_LB_x_reel   0x02
#define RgDragonsTreas_MP_free_SCHWER_LB_x_pos    0x41
#define RgDragonsTreas_MP_free_SCHWER_LB_y_row    0x01
#define RgDragonsTreas_MP_free_SCHWER_LB_y_pos    0x7C
#define RgDragonsTreas_MP_free_SCHWER_RT_x_reel   0x02
#define RgDragonsTreas_MP_free_SCHWER_RT_x_pos    0x9E
#define RgDragonsTreas_MP_free_SCHWER_RT_y_row    0x01
#define RgDragonsTreas_MP_free_SCHWER_RT_y_pos    0xDA

#define RgDragonsTreas_MP_free_A_LB_x_reel   0x01
#define RgDragonsTreas_MP_free_A_LB_x_pos    0x21
#define RgDragonsTreas_MP_free_A_LB_y_row    0x01
#define RgDragonsTreas_MP_free_A_LB_y_pos    0x10
#define RgDragonsTreas_MP_free_A_RT_x_reel   0x01
#define RgDragonsTreas_MP_free_A_RT_x_pos    0x77
#define RgDragonsTreas_MP_free_A_RT_y_row    0x01
#define RgDragonsTreas_MP_free_A_RT_y_pos    0x66

#define RgDragonsTreas_MP_free_HAGEN_LB_x_reel   0x01
#define RgDragonsTreas_MP_free_HAGEN_LB_x_pos    0xB0
#define RgDragonsTreas_MP_free_HAGEN_LB_y_row    0x01
#define RgDragonsTreas_MP_free_HAGEN_LB_y_pos    0x1B
#define RgDragonsTreas_MP_free_HAGEN_RT_x_reel   0x02
#define RgDragonsTreas_MP_free_HAGEN_RT_x_pos    0x15
#define RgDragonsTreas_MP_free_HAGEN_RT_y_row    0x01
#define RgDragonsTreas_MP_free_HAGEN_RT_y_pos    0x78

#define RgDragonsTreas_MP_free_K_LB_x_reel   0x02
#define RgDragonsTreas_MP_free_K_LB_x_pos    0x44
#define RgDragonsTreas_MP_free_K_LB_y_row    0x01
#define RgDragonsTreas_MP_free_K_LB_y_pos    0x10
#define RgDragonsTreas_MP_free_K_RT_x_reel   0x02
#define RgDragonsTreas_MP_free_K_RT_x_pos    0x93
#define RgDragonsTreas_MP_free_K_RT_y_row    0x01
#define RgDragonsTreas_MP_free_K_RT_y_pos    0x6A

#define RgDragonsTreas_MP_free_Q_LB_x_reel   0x01
#define RgDragonsTreas_MP_free_Q_LB_x_pos    0x31
#define RgDragonsTreas_MP_free_Q_LB_y_row    0x00
#define RgDragonsTreas_MP_free_Q_LB_y_pos    0xB6
#define RgDragonsTreas_MP_free_Q_RT_x_reel   0x01
#define RgDragonsTreas_MP_free_Q_RT_x_pos    0x77
#define RgDragonsTreas_MP_free_Q_RT_y_row    0x01
#define RgDragonsTreas_MP_free_Q_RT_y_pos    0x06

#define RgDragonsTreas_MP_free_J_LB_x_reel   0x01
#define RgDragonsTreas_MP_free_J_LB_x_pos    0xBD
#define RgDragonsTreas_MP_free_J_LB_y_row    0x00
#define RgDragonsTreas_MP_free_J_LB_y_pos    0xBE
#define RgDragonsTreas_MP_free_J_RT_x_reel   0x02
#define RgDragonsTreas_MP_free_J_RT_x_pos    0x08
#define RgDragonsTreas_MP_free_J_RT_y_row    0x01
#define RgDragonsTreas_MP_free_J_RT_y_pos    0x12

#define RgDragonsTreas_MP_free_10_LB_x_reel   0x02
#define RgDragonsTreas_MP_free_10_LB_x_pos    0x45
#define RgDragonsTreas_MP_free_10_LB_y_row    0x00
#define RgDragonsTreas_MP_free_10_LB_y_pos    0xB5
#define RgDragonsTreas_MP_free_10_RT_x_reel   0x02
#define RgDragonsTreas_MP_free_10_RT_x_pos    0x9A
#define RgDragonsTreas_MP_free_10_RT_y_row    0x01
#define RgDragonsTreas_MP_free_10_RT_y_pos    0x07


#define MMCODE_sunny_LB_x_reel   0x02
#define MMCODE_sunny_LB_x_pos    0x11
#define MMCODE_sunny_LB_y_row    0x00
#define MMCODE_sunny_LB_y_pos    0x3E
#define MMCODE_sunny_RT_x_reel   0x02
#define MMCODE_sunny_RT_x_pos    0x25
#define MMCODE_sunny_RT_y_row    0x00
#define MMCODE_sunny_RT_y_pos    0x58

StateMachine g_StateMachine;
ReelGame* CreateReelGameObject(UINT16 GameID);

#define LOCK_MUTEX(x) do { \
	EnterCriticalSection(&x); \
} while(0)

#define UNLOCK_MUTEX(x) do { \
	LeaveCriticalSection(&x); \
} while(0)

// Note: These macros are only used in StateMachine member functions where 'this' is available
#define ACTION_PUSH_BACK(cmd) do { \
	LOCK_MUTEX(this->m_vecActionMutex); \
	this->m_vecAction.push_back(cmd); \
	UNLOCK_MUTEX(this->m_vecActionMutex); \
} while(0)

#define ACTIONS_CLEAR() do {	\
		LOCK_MUTEX(this->m_vecActionMutex); \
		this->m_vecAction.clear();	\
		UNLOCK_MUTEX(this->m_vecActionMutex); \
	} while(0)

#define ACTION_PACKET(tick, ...)											\
    do {																	\
		StateMachineCmd cmd;												\
		cmd.cmd = CMD_SendPacket;											\
        const UINT8 tmp[] = { __VA_ARGS__ };								\
		cmd.at = (tick);													\
        cmd.o.st_SendPacket.len = (int)(sizeof(tmp) / sizeof(tmp[0]));      \
        memcpy(cmd.o.st_SendPacket.data, tmp, cmd.o.st_SendPacket.len);		\
		ACTION_PUSH_BACK(cmd); \
    } while (0)

#define ACTION_PACKET_VEC(tick, ...)										\
    do {																	\
        StateMachineCmd cmd;												\
        cmd.cmd = CMD_SendPacket;											\
        myVector<UINT8> tmp = { __VA_ARGS__ };							\
        cmd.at = (tick);													\
        cmd.o.st_SendPacket.len = static_cast<int>(tmp.size());			\
        memcpy(cmd.o.st_SendPacket.data, tmp._data(), cmd.o.st_SendPacket.len);	\
        LOCK_MUTEX(this->m_vecActionMutex); \
        this->m_vecAction.push_back(cmd);										\
        UNLOCK_MUTEX(this->m_vecActionMutex); \
    } while (0)

void InitRTP() {
	gTotalWin.store(0.0);
	gTotalBet.store(0.0);
}

static inline void AtomicAdd(std::atomic<double>& target, double delta) {
	double expected = target.load(std::memory_order_relaxed);
	while (!target.compare_exchange_weak(
		expected,
		expected + delta,
		std::memory_order_relaxed,
		std::memory_order_relaxed)) {
	}
}

StateMachine::StateMachine() {

	CHANGE_STATUS(STATUS_Init);

	m_alreadySent = FALSE;

	m_bLoopGuard = FALSE;

	m_nGameID = 0;
	m_nBankBit = 0;
	m_nBonusBit = {0, 0};
	m_nWinBit = 0;

	m_bAutoSpin = FALSE;
	ResetHalfAutoSpin();
	m_bFreeMode = FALSE;
	m_bMultoGo = FALSE;
	m_nMultiGoTotalLoop = 0;

	m_bNeedHideShowLines = FALSE;
	m_bSpinFast = FALSE;

	InitializeCriticalSection(&m_vecCmdMutex);
	InitializeCriticalSection(&m_vecActionMutex);

	InitRTP();
	m_nSpinWDT = 0;

	cg_init();
	rsk_init();
}

int StateMachine::GetStatus() {
	return m_nStatus.load();
}

void StateMachine::SetStatusAndDebug(const char* file, int line, const char* func, int new_status) {
	DebugPrintf("Status changed from %d to %d: %s() in %s:%d\n", m_nStatus.load(), new_status, func, file, line);

	m_nStatus.store(new_status);
}

BOOL StateMachine::KeyEventEnable() {
	if (m_nStatus.load() < STATUS_PendingSpin) {
		DebugPrintf("KeyEventEnable: FALSE -> In Lobby");
		return FALSE;
	}
	UINT64 curTick = current_time_ms();
	if (curTick <= m_nOpenGameTick) {
		return FALSE;
	}
	if ((curTick - m_nOpenGameTick) < 2000) {
		return FALSE;
	}	
	return TRUE;
}

void StateMachine::SetStatus(int status) {
	CHANGE_STATUS(status);
	if (m_nStatus.load() == STATUS_PendingSpin && (m_bAutoSpin || m_bHalfAutoSpin)) {
		Spin();
	}
	if (m_nStatus.load() == STATUS_PendingSpinAndGo) {
		CHANGE_STATUS(STATUS_PendingSpin);
		Spin();
	}
#if 0
	if (m_nStatus.load() == STATUS_SpinRunning) {
		FastSpin();
	}
#endif
}

int StateMachine::RunGame(UINT16 gameId) {
	if (m_nStatus.load() != STATUS_Lobby) {
		return -1;
	}
	if (g_ReelGame) {
		delete g_ReelGame;
		g_ReelGame = NULL;
	}
	if (g_ReelGameTmp) {
		delete g_ReelGameTmp;
		g_ReelGameTmp = NULL;
	}

	g_ReelGame = CreateReelGameObject(gameId);
	if (g_ReelGame == NULL) {
		return -1;
	}
	g_ReelGameTmp = CreateReelGameObject(gameId);

	PlayDB& playDB = PlayDB::GetInstance();
	{
		const double credit = static_cast<double>(playDB.GetGameCreditData());
		const double safeCredit = (credit < 0.0) ? 0.0 : credit;
		m_nBankBit = static_cast<UINT32>(std::lround(safeCredit));
	}

	mmcode_init();
#ifdef VARIANTBC_ACTIVE
	switch (playDB.GetGameVariant()) {
	case PlayDB::GAME_VARIANT_A:
		gTargetRTP = VARIANT_A;
		break;
	case PlayDB::GAME_VARIANT_B:
		gTargetRTP = VARIANT_B;
		break;
	case PlayDB::GAME_VARIANT_C:
		gTargetRTP = VARIANT_C;
		break;
	default:
		// Default variant when B/C are active is Variant B.
		gTargetRTP = VARIANT_B;
		break;
	}
#else
	// Variants B/C disabled. Always use Variant A RTP.
	gTargetRTP = VARIANT_A;
#endif
	DebugPrintf("+++++++++++++++++++++ Variant = %f", gTargetRTP);
	//m_nBankBit = static_cast<UINT16>(playDB.GetGameCreditData());

	CHANGE_STATUS(STATUS_InitGame);

	m_nGameID = gameId;
	m_bAutoSpin = FALSE;
	ResetHalfAutoSpin();
	m_bFreeMode = FALSE;
	m_bNeedHideShowLines = TRUE;

	StateMachineCmd cmd;
	cmd.cmd = CMD_RunGame;
	cmd.o.st_RunGame.gameId = gameId;

	LOCK_MUTEX(m_vecCmdMutex);
	m_vecCmd.push_back(cmd);
	UNLOCK_MUTEX(m_vecCmdMutex);

	return 0;
}

#include <sstream>
#include <iostream>
void StateMachine::RunGame_pkt(UINT16 gameId) {
	InitCache();
	m_nGamePlan = g_ReelGame->Run();
	myVector<int> startSymbols = g_ReelGame->GetStartInfo();

	// load checkpoint: reelstrip, board
	
	{
		std::istringstream iss(g_ReelGame->CheckPoint());
		std::string token;
		myVector<int> tmpSymbols;

		while (iss >> token) {
			if (token.empty()) {
				continue;
			}
			if (token[0] == 'P') {
				g_ReelGame->ChangeReelStrip(std::stoi(token.substr(1)));
				m_nGamePlan = AT(g_ReelGame->CurrentReelStrip(), 0);
			}
			else if (token[0] == 'B') {
				size_t start = 1;
				while (start < token.size()) {
					size_t pos = token.find(':', start);
					if (pos == std::string::npos) {
						tmpSymbols.push_back(
							std::stoi(token.substr(start))
						);
						break;
					}
					tmpSymbols.push_back(
						std::stoi(token.substr(start, pos - start))
					);
					start = pos + 1;
				}
			}
		}

		if (tmpSymbols.size() == startSymbols.size()) {
			startSymbols = tmpSymbols;
		}
	}

	double fTotalBet = 0.0;
	double fTotalWin = 0.0;
	PlayDB::GetInstance().GetMainBookTotalBetandWin(fTotalBet, fTotalWin);
	gTotalBet.store(fTotalBet);
	gTotalWin.store(fTotalWin);

	UINT64 tick = current_time_ms();
	ACTION_PACKET(tick, 0x01, 0x02, 0x2f, 0x00, 0x84, 0x5a, 0x00, 0x04);
	ACTION_PACKET(tick, 0x01, 0x02, 0x29, 0x00, 0x84, 0x5a, 0x00, 0x04);
	ACTION_PACKET(tick, 0x01, 0x02, 0x2f, 0x00, 0x84, 0x5a, 0x00, 0x04);
	
	if (gameId == GOC_RgGongHei) {
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x0c, 0x00, 0x25, 0x53, 0x67, static_cast<BYTE>(gameId & 0xFF), static_cast<BYTE>((gameId >> 8) & 0xFF), 0x01, 
			//0x02, 0x06, 0x0f, 0x23, 0x1f, 
			AT(startSymbols, 0), AT(startSymbols, 1), AT(startSymbols, 2), AT(startSymbols, 3), AT(startSymbols, 4),
			static_cast<BYTE>(m_nGamePlan & 0xFF), static_cast<BYTE>((m_nGamePlan >> 8) & 0xFF), 0x00, 0x00, 0x04);
	}
	else if (gameId == GOC_RgPyramidOfPower) {
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x0c, 0x00, 0x25, 0x53, 0x67, static_cast<BYTE>(gameId & 0xFF), static_cast<BYTE>((gameId >> 8) & 0xFF), 0x01, 
			//0x27, 0x16, 0x06, 0x0f, 0x1a, 
			AT(startSymbols, 0), AT(startSymbols, 1), AT(startSymbols, 2), AT(startSymbols, 3), AT(startSymbols, 4),
			static_cast<BYTE>(m_nGamePlan & 0xFF), static_cast<BYTE>((m_nGamePlan >> 8) & 0xFF), 0x00, 0x00, 0x04);
	}
	else if (gameId == GOC_RgLosFrootos) {
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x0c, 0x00, 0x25, 0x53, 0x67, static_cast<BYTE>(gameId & 0xFF), static_cast<BYTE>((gameId >> 8) & 0xFF),  0x01, 
			//0x0d, 0x19, 0x07, 0x06, 0x16, 
			AT(startSymbols, 0), AT(startSymbols, 1), AT(startSymbols, 2), AT(startSymbols, 3), AT(startSymbols, 4),
			static_cast<BYTE>(m_nGamePlan & 0xFF), static_cast<BYTE>((m_nGamePlan >> 8) & 0xFF), 0x00, 0x00, 0x04);
	}
	else if (gameId == GOC_RgPharosGoldBase) {
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x0c, 0x00, 0x25, 0x53, 0x67, 0xac, 0x38, 0x01, 
			//0x48, 0x3f, 0x1e, 0x12, 0x4f, 
			AT(startSymbols, 0), AT(startSymbols, 1), AT(startSymbols, 2), AT(startSymbols, 3), AT(startSymbols, 4),
			static_cast<BYTE>(m_nGamePlan & 0xFF), static_cast<BYTE>((m_nGamePlan >> 8) & 0xFF), 0x00, 0x00, 0x04);
	}
	else if (gameId == GOC_RgCairoCasino) {
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x17, 0x00, 0x25, 0x53, 0x67, static_cast<BYTE>(gameId & 0xFF), static_cast<BYTE>((gameId >> 8) & 0xFF), 0x01, 
			//0x13, 0x06, 0x00, 0x14, 0x16, 0x16, 0x00, 0x08, 0x13, 0x0b, 0x0b, 0x0c, 0x01, 0x10, 0x15, 0x06, 
			myRandom() % 0x10, myRandom() % 0x10, myRandom() % 0x10, myRandom() % 0x10, 
			myRandom() % 0x10, myRandom() % 0x10, myRandom() % 0x10, myRandom() % 0x10,
			myRandom() % 0x10, myRandom() % 0x10, myRandom() % 0x10, myRandom() % 0x10,
			myRandom() % 0x10, myRandom() % 0x10, myRandom() % 0x10, myRandom() % 0x10,
			static_cast<BYTE>(m_nGamePlan & 0xFF), static_cast<BYTE>((m_nGamePlan >> 8) & 0xFF), 0x00, 0x00, 0x04);
	}
	else if (gameId == GOC_RgTripleTripleChance) {
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x0c, 0x00, 0x25, 0x53, 0x67, static_cast<BYTE>(gameId & 0xFF), static_cast<BYTE>((gameId >> 8) & 0xFF), 0x01,
			//0x04, 0x14, 0x08, 0x16, 0x19, 
			AT(startSymbols, 0), AT(startSymbols, 1), AT(startSymbols, 2), 0x16, 0x19,
			static_cast<BYTE>(m_nGamePlan & 0xFF), static_cast<BYTE>((m_nGamePlan >> 8) & 0xFF), 0x01, 0x00, 0x04);
	}
	else if (gameId == GOC_RgRisingLiner) {
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x0c, 0x00, 0x25, 0x53, 0x67, static_cast<BYTE>(gameId & 0xFF), static_cast<BYTE>((gameId >> 8) & 0xFF), 0x01,
			//0x04, 0x14, 0x08, 0x16, 0x19, 
			AT(startSymbols, 0), AT(startSymbols, 1), AT(startSymbols, 2), AT(startSymbols, 3), AT(startSymbols, 4),
			static_cast<BYTE>(m_nGamePlan & 0xFF), static_cast<BYTE>((m_nGamePlan >> 8) & 0xFF), (myRandom() % 15), 0x00, 0x04);
	}
	else if (gameId == GOC_RgElToreroMG) {
		// load fixed symbols from checkpoint
		UINT16 mask = 0;
		std::string check = g_ReelGame->CheckPoint();
		if (check != "") {
			myVector<int> values = g_ReelGame->ParseCheckPoint(check, "F", 5);
			if (values.size() == 5) {
				mask = AT(values, 4);
			}
		}
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x0e, 0x00, 0x25, 0x53, 0x67, 0xb4, 0x19, 0x01, 
			AT(startSymbols, 0), AT(startSymbols, 1), AT(startSymbols, 2), AT(startSymbols, 3), AT(startSymbols, 4), 
			static_cast<BYTE>(m_nGamePlan & 0xFF), static_cast<BYTE>((m_nGamePlan >> 8) & 0xFF), 
			static_cast<BYTE>(mask & 0xFF), static_cast<BYTE>((mask >> 8) & 0xFF),
			0x01, 0x00, 0x04);
	}
	else if (gameId == GOC_RgKeyOfTheNile) {
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x0c, 0x00, 0x25, 0x53, 0x67, static_cast<BYTE>(gameId & 0xFF), static_cast<BYTE>((gameId >> 8) & 0xFF), 0x01,
			AT(startSymbols, 0), AT(startSymbols, 1), AT(startSymbols, 2), AT(startSymbols, 3), AT(startSymbols, 4),
			static_cast<BYTE>(m_nGamePlan & 0xFF), static_cast<BYTE>((m_nGamePlan >> 8) & 0xFF), 0x01, 0x00, 0x04);
		//ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x0a, 0x00, 0x25, 0x53, 0x11, 0x00, 0x01, 0x00, 0x01, 0x00, 0x00, 0x00, 0x03, 0x03, 0x00, 0x04); tick += 1000;
	}
	else {
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x0c, 0x00, 0x25, 0x53, 0x67, static_cast<BYTE>(gameId & 0xFF), static_cast<BYTE>((gameId >> 8) & 0xFF), 0x01, 
			AT(startSymbols, 0), AT(startSymbols, 1), AT(startSymbols, 2), AT(startSymbols, 3), AT(startSymbols, 4),
			static_cast<BYTE>(m_nGamePlan & 0xFF), static_cast<BYTE>((m_nGamePlan >> 8) & 0xFF), 0x01, 0x00, 0x04);
	}

	StateMachineCmd setStatusCmd;
	setStatusCmd.cmd = CMD_SetSatus;
	setStatusCmd.at = tick;
	setStatusCmd.o.st_SetStatus.status = STATUS_LoadingContents;
	ACTION_PUSH_BACK(setStatusCmd);
	//SetStatus(STATUS_LoadingContents);
}

void StateMachine::PostGameStartEvent() {
	SetStatus(STATUS_LoadedContents);

	UINT64 tick = current_time_ms();
	UINT8 nWinLine = g_ReelGame->WinLine();
	tick += 200;
	if (m_nGameID == GOC_RgPyramidOfPower) {
		ACTION_PACKET(tick, 0x02, 0x02, 0xd4, 0x3b, 0x25, 0x53);
		ACTION_PACKET(tick, 0x06, 0x25, 0x53, 0x01, 0x02, 0x28, 0x00, 0xa0, 0x5a, 0x01, 0x00, 0x00, 0x00, 0x04);
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0x25, 0x53, 0x85, 0x01, 0x04);
		ACTION_PACKET(tick, 0x01, 0x02, 0x28, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), nWinLine, 0x00, 0x00, 0x00, 0x04);
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x0a, 0x00, 0x25, 0x53, 0x11, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04, 0x03, 0x00, 0x04);
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x04, 0x00, 0xd4, 0x3b, 0x9d, 0xff, 0xff, 0x00, 0x00, 0x04);
	}
	else {
		ACTION_PACKET(tick, 0x01, 0x02, 0x2c, 0x00, 0x8b, 0x5a, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x04, 0x06, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF));
		ACTION_PACKET(tick, 0x01, 0x02, 0x28, 0x00, 0xa0, 0x5a, 0x01, 0x00, 0x00, 0x00, 0x04);
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0x25, 0x53, 0x85, 0x01, 0x04);
		ACTION_PACKET(tick, 0x01, 0x02, 0x28, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), nWinLine, 0x00, 0x00, 0x00, 0x04);
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x0a, 0x00, 0x25, 0x53, 0x11, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x03, 0x03, 0x00, 0x04);
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x04, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x9d, 0x1f, 0x00, 0x00, 0x00, 0x04);
	}

	if (m_nGameID == GOC_RgDoubleBook) { // RgDoubleBook, change to single mode
		ACTION_PACKET(tick, 0x01, 0x02, 0x28, 0x00, 0x03, 0x16, g_ReelGame->GameMode(), 0x00, 0x00, 0x00, 0x04);
	}
	UINT16 betval = g_ReelGame->BetBit() / 5;
	ACTION_PACKET(tick, 0x01, 0x02, 0x30, 0x00, 0x25, 0x53, 
		static_cast<BYTE>(betval & 0xFF), static_cast<BYTE>((betval >> 8) & 0xFF), 
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04, 0x04);

	ShowWinLines(tick);

	std::string lastCheckPoint = g_ReelGame->CheckPoint();
	if (lastCheckPoint.find("F") != std::string::npos) { // abnormal terminated in freemode
		// enter freegame force
		m_bFreeMode = TRUE;
		myVector<InterruptPacketData> IntPackets = g_ReelGame->EnterFreeGame(lastCheckPoint);
		for (int i = 0; i < IntPackets.size(); i++) {
			tick += AT(IntPackets, i).preDelay;
			ACTION_PACKET_VEC(tick, AT(IntPackets, i).data);
			tick += AT(IntPackets, i).postDelay;
		}
		{
			StateMachineCmd cmd;
			cmd.cmd = CMD_CalcRTP;
			cmd.at = tick;
			m_vecAction.push_back(cmd);
		}
		//if (m_nGameID == GOC_RgCairoCasino) {
		//	SetVisibleByGOC(tick, LATEST_LABEL_GOC, FALSE);
		//	DisplayMoney(tick, BONUS_BIT_GOC, m_nBonusBit.coin, 0);
		//}
	}
	else if (lastCheckPoint.find("A") != std::string::npos) {
		size_t pos = lastCheckPoint.find("A");
		std::string f_data = lastCheckPoint.substr(pos + 1);
		int value = std::stoi(f_data);
		if (value > 0) {
			HideWinLines(tick);
			m_nMagicCount = value;
			EnterMagicGame();
			return;
		}
	}

	if (m_nGameID == GOC_RgKeyOfTheNile) {
		myVector<InterruptPacketData> IntPackets = g_ReelGame->OnBetUp(g_ReelGame->BetStep(), g_ReelGame->BetStep()); // show saved leds
		for (int i = 0; i < IntPackets.size(); i++) {
			tick += AT(IntPackets, i).preDelay;
			ACTION_PACKET_VEC(tick, AT(IntPackets, i).data);
			tick += AT(IntPackets, i).postDelay;
		}
	}

	m_nOpenGameTick = tick;

	StateMachineCmd setStatusCmd;
	setStatusCmd.cmd = CMD_SetSatus;
	setStatusCmd.at = tick;
	setStatusCmd.o.st_SetStatus.status = STATUS_PendingSpin;
	ACTION_PUSH_BACK(setStatusCmd);	
	m_atAutoReturnToMenu = tick + AUTO_RETURN_TO_MENU_TIME;	
}

int StateMachine::ReturnToMenu() {
	if (m_nStatus.load() != STATUS_PendingSpin) {
		return -1;
	}
	if (m_bAutoSpin || m_bHalfAutoSpin) {
		return -1;
	}
	if (m_bFreeMode) {
		return -1;
	}
	if (m_CardGamble.bOpen) {
		return -1;
	}
	if (m_Risiko.bOpen) {
		return -1;
	}

	if(KeyEventEnable() == FALSE) return -1;

	CHANGE_STATUS(STATUS_ReturnToMenu);

	StateMachineCmd cmd;
	cmd.cmd = CMD_ReturnToMenu;	

	LOCK_MUTEX(m_vecCmdMutex);
	m_vecCmd.push_back(cmd);
	UNLOCK_MUTEX(m_vecCmdMutex);

	// reset checkpoint
	/*PlayDB::GetInstance().SaveCheckPoint(g_ReelGame->GetGameName(), AT(g_ReelGame->Bets(), g_ReelGame->BetStep()),
		m_nGameID == GOC_RgDoubleBook ? g_ReelGame->GameMode() : g_ReelGame->WinLine(),
		"");*/
	return 0;
}

void StateMachine::ReturnToMenu_pkt() {
	UINT64 tick = current_time_ms();
	ACTION_PACKET(tick, 0x01, 0x02, 0x2f, 0x00, 0x84, 0x5a, 0x00, 0x04);
	ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0x25, 0x53, 0x85, 0x00, 0x04);
	ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x02, 0x00, 0xd0, 0x58, 0x06, 0x00, 0x00, 0x04);
	ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x01, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x02, 0x00, 0x04);
	ACTION_PACKET(tick, 0x01, 0x02, 0x34, 0x00, 0xad, 0x00, 0x04);
	ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x04, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x9d, 0x00, 0x00, 0x00, 0x00, 0x04);
	ACTION_PACKET(tick, 0x01, 0x02, 0x2f, 0x00, 0x3f, 0x5a, 0x00, 0x04);
	ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0xd0, 0x58, 0x01, 0x04, 0x04);
	ACTION_PACKET(tick, 0x01, 0x02, 0x2c, 0x00, 0x8b, 0x5a, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x04);
	ACTION_PACKET(tick, 0x01, 0x02, 0x2c, 0x00, 0x8a, 0x5a, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x04);
	ACTION_PACKET(tick, 0x01, 0x02, 0x2f, 0x00, 0x84, 0x5a, 0x00, 0x04);
	ACTION_PACKET(tick, 0x01, 0x02, 0x30, 0x00, 0x25, 0x53, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x65, 0x04);

	StateMachineCmd setStatusCmd;
	setStatusCmd.cmd = CMD_SetSatus;
	setStatusCmd.at = tick;
	setStatusCmd.o.st_SetStatus.status = STATUS_Lobby;
	ACTION_PUSH_BACK(setStatusCmd);

	//Click Mouse
	LeftClickAt(50, 50, 1000);
}

void StateMachine::ChargeCredit(UINT32 Amount) {
	StateMachineCmd cmd;
	cmd.cmd = CMD_ChargeCredit;
	cmd.o.st_ChargeCredit.amount = Amount;

	LOCK_MUTEX(m_vecCmdMutex);
	m_vecCmd.push_back(cmd);
	UNLOCK_MUTEX(m_vecCmdMutex);
}

void StateMachine::ToogleAutoSpin() {
	if (m_nStatus.load() <= STATUS_InitGame) {
		return;
	}
	if (m_CardGamble.bOpen) {
		return;
	}
	if (m_Risiko.bOpen) {
		return;
	}
	UINT64 tick = current_time_ms();
	if (m_bHalfAutoSpin) {
		m_bHalfAutoSpin = FALSE;
		PlaySound(tick, SMP_Autostart_OFF, TRUE);
		return;
	}
	m_bHalfAutoSpin = FALSE;
	m_bAutoSpin = !m_bAutoSpin;
	if (m_bFreeMode == FALSE && m_bMultoGo == FALSE) {
		if (g_ReelGame->BetBit() > m_nBankBit) {
			m_bAutoSpin = FALSE;
		}
	}
	
	if (m_bAutoSpin) {
		PlaySound(tick, SMP_Autostart_ON, TRUE);
		Spin();
	}
	else {
		PlaySound(tick, SMP_Autostart_OFF, TRUE);
	}
}

void StateMachine::ResetHalfAutoSpin() {
	UINT64 tick = current_time_ms();
	if (m_bHalfAutoSpin == TRUE) {
		PlaySound(tick, SMP_Autostart_OFF, TRUE);
	}
	m_bHalfAutoSpin = FALSE;
}

void StateMachine::ResetAutoSpin() {
	UINT64 tick = current_time_ms();
	if (m_bAutoSpin == TRUE) {
		PlaySound(tick, SMP_Autostart_OFF, TRUE);
	}
	m_bAutoSpin = FALSE;
}

void StateMachine::ToogleHalfAutoSpin() {
	if (m_nStatus.load() <= STATUS_InitGame) {
		return;
	}
	if (m_CardGamble.bOpen) {
		return;
	}
	if (m_Risiko.bOpen) {
		return;
	}
	m_bAutoSpin = FALSE;
	m_bHalfAutoSpin = TRUE;// !m_bHalfAutoSpin;

	if (m_bFreeMode == FALSE && m_bMultoGo == FALSE) {
		if (g_ReelGame->BetBit() > m_nBankBit) {
			m_bHalfAutoSpin = FALSE;
			return;
		}
	}

	UINT64 tick = current_time_ms();
	if (m_bHalfAutoSpin) {
		PlaySound(tick, SMP_Autostart_ON, TRUE);
		Spin();
	}
	else {
		//PlaySound(tick, SMP_Autostart_OFF, TRUE);
	}
}

void StateMachine::ChargeCredit_pkt(UINT32 Amount) {
	m_nBankBit += Amount;
	PlayDB::GetInstance().SetGameCreditData(static_cast<double>(m_nBankBit));
	PlayDB::GetInstance().AddPayinData(Amount);

	UINT64 tick = current_time_ms();
	KomProtocol* pKom = CryptoCard::GetInstance().GetKomProtocol();
	BYTE data[] = { 0x01, 0x02, 0x2C, 0x00,
	  static_cast<BYTE>(BANK_BIT_GOC & 0xFF),
	  static_cast<BYTE>((BANK_BIT_GOC >> 8) & 0xFF),
	  static_cast<BYTE>(m_nBankBit & 0xFF),
	  static_cast<BYTE>((m_nBankBit >> 8) & 0xFF),
	  static_cast<BYTE>((m_nBankBit >> 16) & 0xFF),
	  static_cast<BYTE>((m_nBankBit >> 24) & 0xFF),
	  0x00, 0x00,
	  0x00, 0x00, 0x01,
	  0x04 };
	pKom->MakePacket(data, sizeof(data));
	PlaySound(tick, SMP_Button1, TRUE);
}

void StateMachine::UpdateBankBitInGame(int delta) {
	m_nBankBit += delta;
	if (delta > 0) {
		AtomicAdd(gTotalWin, static_cast<double>(delta));
	}
	else {
		AtomicAdd(gTotalBet, static_cast<double>(std::abs(delta)));
	}
	PlayDB::GetInstance().SetGameCreditData(static_cast<double>(m_nBankBit));
}

UINT16 StateMachine::BonusMoveDelay_ms(int bonus) {
	UINT16 delay_ms = 0;
	if (bonus > 50000) {
		delay_ms = 4000;
	}
	else if (bonus > 5000) {
		delay_ms = 3000;
	}
	else if (bonus > 1000) {
		delay_ms = 2800;
	}
	else if (bonus > 200) {
		delay_ms = 2000;
	}
	else if (bonus > 50) {
		delay_ms = 1500;
	}
	else if (bonus > 10) {
		delay_ms = 800;
	}
	else if (bonus > 0){
		delay_ms = 200;
	}
	else {
		delay_ms = 0;
	}
	return delay_ms;
}

void StateMachine::MoveBonus(UINT64& tick, UINT32 amount, BOOL fast) {
	PlayDB::GetInstance().AddGamePlayData(g_ReelGame->GetGameName(), 0.0, static_cast<double>(amount), 0);
	PlayDB::GetInstance().SaveCheckPoint(0);

	if (!fast) {
		// play moving sound
		PlaySound(tick, SMP_phgo_UmbuchWinGeld);
	}
	// hide latest erfolg label
	SetVisibleByGOC(tick, LATEST_LABEL_GOC, FALSE);
	// m_nBankBit += amount;
	UpdateBankBitInGame(amount);
	if (!fast) {
		// decrease bonus bit
		DisplayMoney(tick, BONUS_BIT_GOC, 0, 10);
	}
	// increase bank bit
	DisplayMoney(tick, BANK_BIT_GOC, m_nBankBit, fast ? 0 : 5);
	if (!fast) {
		// ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x04, 0x00, 0x25, 0x53, 0x0A, 
		// 	static_cast<BYTE>(amount & 0xFF), static_cast<BYTE>((amount >> 8) & 0xFF),
		// 	0x00, 0x00, 0x04, 0x06, 0x30, 0x59); // show sunnie around ani

		// delay depend on bonus
		tick += BonusMoveDelay_ms(amount);
		// stop moving sound
		StopSound(tick, SMP_phgo_UmbuchWinGeld);

		//DisplayMoney(tick, BANK_BIT_GOC, m_nBankBit, 0); // to prevent for long inc or dec when big value
		StateMachineCmd cmd;
		cmd.cmd = CMD_UpdateBankBit;
		cmd.at = tick;
		m_vecAction.push_back(cmd);

		// hide bonus bit
		SetVisibleByGOC(tick, BONUS_BIT_GOC, FALSE);
		tick += 300;
	}
	// show latest bonus label
	SetVisibleByGOC(tick, LATEST_LABEL_GOC, TRUE);
	// display latest bonus
	DisplayMoney(tick, BONUS_BIT_GOC, amount, 0);
	// play cik
	PlaySound(tick, SMP_RisikoPot_addValue);
	tick += 200;
}

int StateMachine::Spin() {	
	if (m_nStatus.load() == STATUS_MagicGame) {
		return 0;
	}
	if (m_nStatus.load() == STATUS_PendingMultiGo) {
		HideMultiGoAndStart();
		return 0;
	}
	if (m_nStatus.load() == STATUS_Risiko) {
		if (m_CardGamble.bOpen) {
			ACTIONS_CLEAR();
			cg_takeBonusAndExit();
		}
		if (m_Risiko.bOpen) {
			ACTIONS_CLEAR();
			rsk_takeBonusAndExit();
		}
		return 0;
	}
	if (m_nStatus.load() < STATUS_PendingSpin) {
		return -1;
	}
	if (m_CardGamble.bOpen) {
		return -1;
	}
	if (m_Risiko.bOpen) {
		return -1;
	}
	m_bNeedHideShowLines = TRUE;

	UINT64 tick = current_time_ms();
	m_nSpinBetBit = g_ReelGame->BetBit();
	if (m_bMultoGo) {
		m_nSpinBetBit = 0;
	}
	if (m_nStatus.load() == STATUS_PlayingBonusSound || m_nStatus.load() == STATUS_WaitActionBonusSound) { // Move Bonus		
		if (m_nStatus.load() == STATUS_PlayingBonusSound) {
			if (m_nMagicCount) {
				EnterMagicGame();
				return 0;
			}
		}
		// prevent move bonus before spin in multigo
		if (m_bMultoGo) {
			CHANGE_STATUS(STATUS_PendingSpin);
			Spin();
			return 0;
		}
		CHANGE_STATUS(STATUS_StartMoveBonus);

		// hide top and show banner before move
		// RgTripleTripleChance
		if (m_nGameID == GOC_RgTripleTripleChance) {
			ACTION_PACKET(tick, 0x06, 0x23, 0x59, 0x01, 0x02, 0x2f, 0x00, 0xeb, 0x58, 0x00, 0x04);
		}
		if (g_ReelGame->stopAllSoundBeforeMove()) {
			StopAllSound(tick);
		}
		else {
			StopSound(tick, m_nBonusSoundID);
			StopSound(tick, SMP_VorauswahlRisiko);
		}

		if (m_nBonusBit.coin && m_bMultoGo == FALSE) {
			// spinning total win lines
			SpinningTottalLines();
			MoveBonus(tick, m_nBonusBit.coin, FALSE);
		}

		if (m_nGameID == GOC_RgExtraWild) { // RgExtraWild: hide top bonus banner
			ACTION_PACKET(tick, 0x06, 0x30, 0x59, 0x01, 0x02, 0x2f, 0x00, 0xeb, 0x58, 0x00, 0x04);
		}
		// Stop sunnier ani
		UINT16 sunnieGOC = SUNNIER_GOC;
		ACTION_PACKET(tick, 0x01, 0x02, 0x29, 0x00, static_cast<BYTE>(sunnieGOC & 0xFF), static_cast<BYTE>((sunnieGOC >> 8) & 0xFF), 0x00, 0x04);

		if (m_bFreeMode == FALSE) {
			if (g_ReelGame->CanFreeMode()) {
				m_bFreeMode = TRUE;
				
				myVector<InterruptPacketData> IntPackets = g_ReelGame->EnterFreeGame("");
				
				for (int i = 0; i < IntPackets.size(); i++) {
					tick += AT(IntPackets, i).preDelay;
					ACTION_PACKET_VEC(tick, AT(IntPackets, i).data);
					tick += AT(IntPackets, i).postDelay;
				}
				PlayDB::GetInstance().SaveCheckPoint(g_ReelGame->GetGameName(), AT(g_ReelGame->Bets(), g_ReelGame->BetStep()),
					m_nGameID == GOC_RgDoubleBook ? g_ReelGame->GameMode() : g_ReelGame->WinLine(),
					g_ReelGame->CheckPoint());

				{
					StateMachineCmd cmd;
					cmd.cmd = CMD_CalcRTP;
					cmd.at = tick;
					m_vecAction.push_back(cmd);
				}
				if (m_nGameID == GOC_RgCairoCasino) {
					SetVisibleByGOC(tick, LATEST_LABEL_GOC, FALSE);
					DisplayMoney(tick, BONUS_BIT_GOC, m_nBonusBit.coin, 0);
				}
				
				if (m_nGameID == GOC_RgDragonsTreas) {
					m_atCanMouseAction = tick;
					SetStatus(STATUS_PenddingWaitMouseAction);
					return 0;
				}
			}
		}
		else {
			BOOL EndFree = FALSE;
			myVector<InterruptPacketData> IntPackets = g_ReelGame->InterruptAfterMoveBonus(EndFree);
			for (int i = 0; i < IntPackets.size(); i++) {
				tick += AT(IntPackets, i).preDelay;
				ACTION_PACKET_VEC(tick, AT(IntPackets, i).data);
				tick += AT(IntPackets, i).postDelay;
			}
			m_bFreeMode = !EndFree;
			if (m_bFreeMode == FALSE) {
				StateMachineCmd cmd;
				cmd.cmd = CMD_CalcRTP;
				cmd.at = tick;
				m_vecAction.push_back(cmd);
			}
			if (m_bFreeMode == FALSE && m_nGameID == GOC_RgCairoCasino) { // when finish move bonus
				MoveBonus(tick, m_nBonusBit.coin, FALSE);
			}
			PlayDB::GetInstance().SaveCheckPoint(g_ReelGame->GetGameName(), AT(g_ReelGame->Bets(), g_ReelGame->BetStep()),
				m_nGameID == GOC_RgDoubleBook ? g_ReelGame->GameMode() : g_ReelGame->WinLine(),
				g_ReelGame->CheckPoint());
		}
		
		StateMachineCmd setStatusCmd;
		setStatusCmd.cmd = CMD_SetSatus;
		setStatusCmd.at = tick + 200;
		setStatusCmd.o.st_SetStatus.status = (m_nGameID == GOC_RgIndianRuby && m_bFreeMode) ? STATUS_PendingSpinAndGo : STATUS_PendingSpin;
		ACTION_PUSH_BACK(setStatusCmd);

		m_atAutoReturnToMenu = tick + AUTO_RETURN_TO_MENU_TIME;

		if (m_nBankBit < m_nSpinBetBit && m_bFreeMode == FALSE) {
			if (m_bAutoSpin && m_bHalfAutoSpin == FALSE) {
				PlaySound(tick, SMP_Autostart_OFF, TRUE);
			}
			m_bAutoSpin = FALSE;
			
			ResetHalfAutoSpin();
			ShowWinLines(tick);
		}
		return 0;
	}
	if (m_nStatus.load() != STATUS_PendingSpin) {
		return 0;
	}

	if (m_nBankBit < m_nSpinBetBit && m_bFreeMode == FALSE) {
		return 0;
	}
	CHANGE_STATUS(STATUS_Spin);
	m_bSpinFast = FALSE;

	PlayDB::GetInstance().AddGamePlayData(
		g_ReelGame->GetGameName(),
		(m_bMultoGo || m_bFreeMode) ? 0.0 : static_cast<double>(m_nSpinBetBit),
		0.0,
		1
	);
	// MMCode-->
	if (m_bFreeMode == FALSE && m_bMultoGo == FALSE && m_bAutoSpin == FALSE) {
		mmcode_enable_go(m_nSpinBetBit);
	}
	
	auto result = CalcRTP(TRUE, StateMachine::g_rtpGeneration.load());
	m_vSpinMeters.clear();
	m_nSpinNormalMeter = 0;
	m_nSpinMaxMeter = 0;
	m_SpinBonusSoundItem = { 0, "", 0 };
	BOOL _ = FALSE;
	result = g_ReelGame->Win(m_vSpinMeters, m_nSpinNormalMeter, m_nSpinMaxMeter, m_SpinBonusSoundItem, FALSE, result, _);

	// save checkpoint
	PlayDB::GetInstance().SaveCheckPoint(g_ReelGame->GetGameName(), AT(g_ReelGame->Bets(), g_ReelGame->BetStep()),
		m_nGameID == GOC_RgDoubleBook ? g_ReelGame->GameMode() : g_ReelGame->WinLine(),
		g_ReelGame->CheckPoint());


	m_nSpinStartTick = current_time_ms();
	double currentBet = gTotalBet.load();
	double currentWin = gTotalWin.load();
	if (currentBet <= 0.0) {
		DebugPrintf("******************** RTP: ++ \n");
	}
	else {
		DebugPrintf("******************** RTP: %.2f %% (%.2f, %.2f)\n", (currentWin / currentBet) * 100.0, currentBet, currentWin);
	}	
	// <-- RTP
	m_nMagicCount = g_ReelGame->MagicCount();	
	if (m_bFreeMode == FALSE && m_bMultoGo == FALSE) {
		// m_nBankBit -= m_nSpinBetBit;
		UpdateBankBitInGame(-m_nSpinBetBit);
	}
	myVector<InterruptPacketData> IntPackets = g_ReelGame->InterruptBeforeSpin();
	for (int i = 0; i < IntPackets.size(); i++) {
		tick += AT(IntPackets, i).preDelay;
		ACTION_PACKET_VEC(tick, AT(IntPackets, i).data);
		tick += AT(IntPackets, i).postDelay;
	}
	
	if (m_bMultoGo == FALSE) {
		// Packet 2: Update Credit
		DisplayMoney(tick, BANK_BIT_GOC, m_nBankBit, 5);
	}
	else {
		if (m_SpinBonusSoundItem.soundID < MAX_SOUND_IDS || m_SpinBonusSoundItem.soundID > 0) {
			StopSound(tick, m_SpinBonusSoundItem.soundID);
		}
		//StopAllSound(tick);
	}
	tick += 100;

	myVector<UINT16> plans = g_ReelGame->CurrentReelStrip();
	if (plans.size() == 1) { // no multigo
		m_nGamePlan = AT(plans, 0);
		// Packet 1: CommandWithVariParaNum1
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x01, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x02, 0x00, 0x04);
		if (m_nGameID == GOC_RgGl) {
		}
		else {
			// Packet 3: GameCommand1
			ACTION_PACKET(tick, 0x01, 0x02, 0x30, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x00, 0x00, static_cast<BYTE>(m_nGamePlan & 0xFF), static_cast<BYTE>((m_nGamePlan >> 8) & 0xFF), 0x00, 0x00, 0x00, 0x00, 0xa0, 0x04);
		}
	}
	else {
		for (int i = 0; i < plans.size() / 2; i++) { // check RgLosFrootos::CurrentReepStrip for clear
			UINT16 gid, pid;
			gid = AT(plans, i * 2);
			pid = AT(plans, i * 2 + 1);
			
			// Packet 1: CommandWithVariParaNum1
			if (m_nGameID == GOC_RgPharosGoldBase && 0) {
				if (i == 0) {
					ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0xac, 0x38, 0x02, 0x00, 0x04);
				}
				ACTION_PACKET(tick, 0x01, 0x02, 0x30, 0x00, static_cast<BYTE>(gid & 0xFF), static_cast<BYTE>((gid >> 8) & 0xFF), 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa0, 0x04);
			}
			else {
				ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x01, 0x00, static_cast<BYTE>(gid & 0xFF), static_cast<BYTE>((gid >> 8) & 0xFF), 0x02, 0x00, 0x04);
				ACTION_PACKET(tick, 0x01, 0x02, 0x30, 0x00, static_cast<BYTE>(gid & 0xFF), static_cast<BYTE>((gid >> 8) & 0xFF), 0x00, 0x00, static_cast<BYTE>(pid & 0xFF), static_cast<BYTE>((pid >> 8) & 0xFF), 0x00, 0x00, 0x00, 0x00, 0xa0, 0x04);
			}						
		}
	}
	
	if (m_nGameID == GOC_RgTripleTripleChance) {
		ACTION_PACKET(tick,
			0x01, 0x02, 0x31, 0x00,
			0x0c, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF),
			0x9a, AT(result, 0), AT(result, 1), AT(result, 2), 0x00, 0x00, 0x00, 0x00,
			0x00, 0x00, 0x00, 0x00,
			0x07, 0x04
		);
	}
	else if (m_nGameID == GOC_RgConvertusAurum) {
		myVector<UINT8> param = g_ReelGame->AdditionalParam();
		ACTION_PACKET(tick,
			0x01, 0x02, 0x31, 0x00, 0x0E, 0x00, 0xBB, 0x13, 0x9A,
			AT(result, 0), AT(result, 1), AT(result, 2), AT(result, 3), AT(result, 4),
			AT(param, 0), AT(param, 1),/*(reel, col) in freegame, man position */ 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x07, 0x04
		);
	}
	else if (m_nGameID == GOC_RgRisingLiner) {
		myVector<UINT8> param = g_ReelGame->AdditionalParam();
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x0d, 0x00, 0xff, 0x3d, 0x9a,
			AT(result, 0), AT(result, 1), AT(result, 2), AT(result, 3), AT(result, 4),
			AT(param, 0) /* wild pos */, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x07, 0x04);
	}
	else if (m_nGameID == GOC_RgPyramidOfPower) {
		myVector<UINT8> param = g_ReelGame->AdditionalParam();
		ACTION_PACKET(tick,
			0x01, 0x02, 0x31, 0x00, 0x0d, 0x00, 0xd4, 0x3b, 0x9a,
			AT(result, 0), AT(result, 1), AT(result, 2), AT(result, 3), AT(result, 4),
			AT(param, 0), 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x07, 0x04);
	}
	else if (m_nGameID == GOC_RgKeyOfTheNile) {
		myVector<UINT8> param = g_ReelGame->AdditionalParam();
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x10, 0x00, 0xbb, 0x05, 0x9a,
			AT(result, 0), AT(result, 1), AT(result, 2), AT(result, 3), AT(result, 4),
			0x08, 0x06,
			AT(param, 0) /*low byte of wild card mask*/, AT(param, 1) /*high byte of wild card mask*/,
			0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x07, 0x04);
	}
	else if (m_nGameID == GOC_RgCairoCasino) {
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x17, 0x00, 0xbe, 0x04, 0x9a, 
			AT(result, 0), AT(result, 4), AT(result, 8), AT(result, 12),
			AT(result, 1), AT(result, 5), AT(result, 9), AT(result, 13),
			AT(result, 2), AT(result, 6), AT(result, 10), AT(result, 14),
			AT(result, 3), AT(result, 7), AT(result, 11), AT(result, 15),
			0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x07, 0x04);
	}
	else if (m_nGameID == GOC_RgGl) {
		ACTION_PACKET(tick,
			0x01, 0x02, 0x31, 0x00, 0x0c, 0x00, 0x37, 0x22, 0x9a,
			AT(result, 0), AT(result, 1), AT(result, 2), AT(result, 3), AT(result, 4),
			0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x07, 0x04);
	}
	else {
		if (m_nGameID == GOC_RgLosFrootos && m_bMultoGo && result.size() > 5) { // Multigo in GOC_RgLosFrootos
			ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x0e, 0x00, 0x69, 0x0b, 0x9a,
				AT(result, 0), AT(result, 1), AT(result, 2), AT(result, 3), AT(result, 4),
				AT(result, 20), AT(result, 21), AT(result, 22), 0x00, 0x00, 0x00, 0x00, 0x00, 0x07, 0x04);
			ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x0e, 0x00, 0x6a, 0x0b, 0x9a,
				AT(result, 5), AT(result, 6), AT(result, 7), AT(result, 8), AT(result, 9),
				AT(result, 23), AT(result, 24), AT(result, 25), 0x00, 0x00, 0x00, 0x00, 0x00, 0x07, 0x04);
			ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x0e, 0x00, 0x6b, 0x0b, 0x9a,
				AT(result, 10), AT(result, 11), AT(result, 12), AT(result, 13), AT(result, 14),
				AT(result, 26), AT(result, 27), AT(result, 28), 0x00, 0x00, 0x00, 0x00, 0x00, 0x07, 0x04);
			ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x0e, 0x00, 0x6c, 0x0b, 0x9a,
				AT(result, 15), AT(result, 16), AT(result, 17), AT(result, 18), AT(result, 19),
				AT(result, 29), AT(result, 30), AT(result, 31), 0x00, 0x00, 0x00, 0x00, 0x00, 0x07, 0x04);
		}
		else if (m_nGameID == GOC_RgPharosGoldBase && m_bMultoGo && result.size() > 5) {
			ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x0f, 0x00, 0xad, 0x38, 0x9a,
				AT(result, 0), AT(result, 1), AT(result, 2), AT(result, 3), AT(result, 4),
				AT(result, 20), AT(result, 21), AT(result, 22), 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x07, 0x04);
			ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x0f, 0x00, 0xae, 0x38, 0x9a,
				AT(result, 5), AT(result, 6), AT(result, 7), AT(result, 8), AT(result, 9),
				AT(result, 23), AT(result, 24), AT(result, 25), 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x07, 0x04);
			ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x0f, 0x00, 0xaf, 0x38, 0x9a,
				AT(result, 10), AT(result, 11), AT(result, 12), AT(result, 13), AT(result, 14),
				AT(result, 26), AT(result, 27), AT(result, 28), 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x07, 0x04);
			ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x0f, 0x00, 0xb0, 0x38, 0x9a,
				AT(result, 15), AT(result, 16), AT(result, 17), AT(result, 18), AT(result, 19),
				AT(result, 29), AT(result, 30), AT(result, 31), 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x07, 0x04);
		}
		else {
			ACTION_PACKET(tick,		
				0x01, 0x02, 0x31, 0x00,
				0x0c, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF),
				0x9a, AT(result, 0), AT(result, 1), AT(result, 2), AT(result, 3), AT(result, 4), 0x00, 0x00,
				0x00, 0x00, 0x00, 0x00,
				0x07, 0x04
			);
		}
	}
	StateMachineCmd setStatusCmd;
	setStatusCmd.cmd = CMD_SetSatus;
	setStatusCmd.at = tick;
	setStatusCmd.o.st_SetStatus.status = STATUS_SpinRunning;
	ACTION_PUSH_BACK(setStatusCmd);
}

BOOL StateMachine::AlreadySentFastSpin()
{
	if(m_alreadySent == TRUE) return TRUE;
	
	if(g_StateMachine.GetStatus() == STATUS_SpinRunning)
	{
		m_alreadySent = TRUE;
	}

	return FALSE;
}

void StateMachine::SpinPost() {
	SetStatus(STATUS_SpinFinished);
	m_alreadySent = FALSE;

	m_vecAnimsAfterTake.clear();
	UINT64 tick = current_time_ms();
	// no win
	if (m_vSpinMeters.size() == 0) {
		//tick += g_ReelGame->SpinTime_MS();
		// RgMultiSevenWild - expand wild card
		// RgGoldCup
		// jokerCap - transform 2 symbols
		// glaiadtor - expand wild card
		// extrawild - show multi x2, x3, x6
		{
			myVector<InterruptPacketData> IntPackets = g_ReelGame->InterruptAfterSpin();
			for (int i = 0; i < IntPackets.size(); i++) {
				tick += AT(IntPackets, i).preDelay;
				ACTION_PACKET_VEC(tick, AT(IntPackets, i).data);
				tick += AT(IntPackets, i).postDelay;
			}
			g_ReelGame->updateCheckPoint();
			PlayDB::GetInstance().SaveCheckPoint(g_ReelGame->GetGameName(), AT(g_ReelGame->Bets(), g_ReelGame->BetStep()),
				m_nGameID == GOC_RgDoubleBook ? g_ReelGame->GameMode() : g_ReelGame->WinLine(),
				g_ReelGame->CheckPoint());

			if (m_bFreeMode == TRUE && m_nGameID == GOC_RgCairoCasino) {
				SetVisibleByGOC(tick, LATEST_LABEL_GOC, FALSE);
				DisplayMoney(tick, BONUS_BIT_GOC, m_nBonusBit.coin, 0);
			}
		}

		if (m_bFreeMode == FALSE) {
			if (g_ReelGame->CanFreeMode()) {
				m_bFreeMode = TRUE;

				myVector<InterruptPacketData> IntPackets = g_ReelGame->EnterFreeGame("");
				for (int i = 0; i < IntPackets.size(); i++) {
					tick += AT(IntPackets, i).preDelay;
					ACTION_PACKET_VEC(tick, AT(IntPackets, i).data);
					tick += AT(IntPackets, i).postDelay;
				}
				PlayDB::GetInstance().SaveCheckPoint(g_ReelGame->GetGameName(), AT(g_ReelGame->Bets(), g_ReelGame->BetStep()),
					m_nGameID == GOC_RgDoubleBook ? g_ReelGame->GameMode() : g_ReelGame->WinLine(),
					g_ReelGame->CheckPoint());

				{
					StateMachineCmd cmd;
					cmd.cmd = CMD_CalcRTP;
					cmd.at = tick;
					m_vecAction.push_back(cmd);
				}
				if (m_nGameID == GOC_RgCairoCasino) {
					SetVisibleByGOC(tick, LATEST_LABEL_GOC, FALSE);
					DisplayMoney(tick, BONUS_BIT_GOC, m_nBonusBit.coin, 0);
				}
				if (m_nGameID == GOC_RgDragonsTreas) {
					m_atCanMouseAction = tick;
					SetStatus(STATUS_PenddingWaitMouseAction);
					return;
				}
			}
		}
		else {
			BOOL EndFree = FALSE;
			myVector<InterruptPacketData> IntPackets = g_ReelGame->InterruptAfterMoveBonus(EndFree);
			for (int i = 0; i < IntPackets.size(); i++) {
				tick += AT(IntPackets, i).preDelay;
				ACTION_PACKET_VEC(tick, AT(IntPackets, i).data);
				tick += AT(IntPackets, i).postDelay;
			}
			m_bFreeMode = !EndFree;
			if (m_bFreeMode == FALSE) {
				StateMachineCmd cmd;
				cmd.cmd = CMD_CalcRTP;
				cmd.at = tick;
				m_vecAction.push_back(cmd);
			}
			if (m_bFreeMode == FALSE && m_nGameID == GOC_RgCairoCasino) { // when finish move bonus
				MoveBonus(tick, m_nBonusBit.coin, FALSE);
			}
			PlayDB::GetInstance().SaveCheckPoint(g_ReelGame->GetGameName(), AT(g_ReelGame->Bets(), g_ReelGame->BetStep()),
				m_nGameID == GOC_RgDoubleBook ? g_ReelGame->GameMode() : g_ReelGame->WinLine(),
				g_ReelGame->CheckPoint());
		}
		if (m_bMultoGo) {
			UINT8 total_a = 0, gone_a = 0, loop_a = 0;
			g_ReelGame->MultiGoGoneAndRemain(gone_a, total_a, loop_a);
			if (gone_a >= total_a) {
				goto MULTIGO_END;
			}
		}

		StateMachineCmd setStatusCmd;
		setStatusCmd.cmd = CMD_SetSatus;
		setStatusCmd.at = tick + 200;
		setStatusCmd.o.st_SetStatus.status = (m_nGameID == GOC_RgIndianRuby && m_bFreeMode) ? STATUS_PendingSpinAndGo : STATUS_PendingSpin;
		ACTION_PUSH_BACK(setStatusCmd);

		m_atAutoReturnToMenu = tick + AUTO_RETURN_TO_MENU_TIME;

		if (m_nBankBit < m_nSpinBetBit && m_bFreeMode == FALSE) {
			if (m_bAutoSpin && m_bHalfAutoSpin == FALSE) {
				PlaySound(tick, SMP_Autostart_OFF, TRUE);
			}
			m_bAutoSpin = FALSE;
			ResetHalfAutoSpin();
			ShowWinLines(tick);
		}
		return;
	}
	
	ResetHalfAutoSpin();
	if (m_bMultoGo == FALSE) {
		m_nBonusBit = { 0, 0 };		
	}
	else {
		StopAllSound(tick);
	}
	UINT16 LastLineSound = 0;
	UINT8 total = 0, gone = 0, loop = 0;
	for (int i = 0; i < m_vSpinMeters.size(); i++) {
		UINT16 gId = m_nGameID;
		if (m_bMultoGo) {
			gId = AT(m_vSpinMeters, i).gameId;
		}
		if (i == 0) {
			//tick += g_ReelGame->SpinTime_MS();
			{
				myVector<InterruptPacketData> IntPackets = g_ReelGame->InterruptAfterSpin();
				for (int i = 0; i < IntPackets.size(); i++) {
					tick += AT(IntPackets, i).preDelay;
					ACTION_PACKET_VEC(tick, AT(IntPackets, i).data);
					tick += AT(IntPackets, i).postDelay;
				}
				g_ReelGame->updateCheckPoint();
				PlayDB::GetInstance().SaveCheckPoint(g_ReelGame->GetGameName(), AT(g_ReelGame->Bets(), g_ReelGame->BetStep()),
					m_nGameID == GOC_RgDoubleBook ? g_ReelGame->GameMode() : g_ReelGame->WinLine(),
					g_ReelGame->CheckPoint());

				if (m_bFreeMode == TRUE && m_nGameID == GOC_RgCairoCasino) {
					SetVisibleByGOC(tick, LATEST_LABEL_GOC, FALSE);
					DisplayMoney(tick, BONUS_BIT_GOC, m_nBonusBit.coin, 0);
				}
			}

			if (m_nGameID == GOC_RgGl) { // show matched animation in RgGl
				UINT16 totalMeter = (m_nSpinNormalMeter | m_nSpinMaxMeter);
				ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x02, 0x00, 0x37, 0x22, 0x9e, static_cast<BYTE>(totalMeter & 0xFF), static_cast<BYTE>((totalMeter >> 8) & 0xFF), 0x04);
			}

			// total matched symbols			
			if (m_nGameID == GOC_RgMultiWild243) {
				ACTION_PACKET(tick,
					0x01, 0x02, 0x31, 0x00, 0x08, 0x00, 0x92, 0x35, 0x9c, 0x15, 0x00, 0x00, static_cast<BYTE>(m_nSpinNormalMeter & 0xFF), static_cast<BYTE>((m_nSpinNormalMeter >> 8) & 0xFF), 0x00, 0x00, 0x01, 0x04
				);
			}
			else if (m_nGameID == GOC_RgCairoCasino) {
				ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x08, 0x00, 0xbe, 0x04, 0x9c, 0x15, 0x00, 0x00, 
					static_cast<BYTE>(m_nSpinNormalMeter & 0xFF), static_cast<BYTE>((m_nSpinNormalMeter >> 8) & 0xFF), 0x14, 0x05, 0x01, 0x04);
			}
			else {
				if (m_bMultoGo) {
					for (int i = 0; i < 4; i++) {
						UINT16 normalMeter = (m_nSpinNormalMeter >> (16 * i)) & 0xFFFF;
						UINT16 maxMeter = (m_nSpinMaxMeter >> (16 * i)) & 0xFFFF;
						if (normalMeter == 0 && maxMeter == 0) {
							continue;
						}
						UINT16 tmpGame = m_nGameID + i + 1;
						ACTION_PACKET(tick,
							0x01, 0x02, 0x31, 0x00, 0x0f, 0x00, static_cast<BYTE>(tmpGame & 0xFF), static_cast<BYTE>((tmpGame >> 8) & 0xFF), 0x9c, 0x15, 0x00, 0x00, static_cast<BYTE>(normalMeter & 0xFF), static_cast<BYTE>((normalMeter >> 8) & 0xFF), 0x14, 0x1c, 0x01, 0x00, 0x03, static_cast<BYTE>(maxMeter & 0xFF), static_cast<BYTE>((maxMeter >> 8) & 0xFF), 0x14, 0x1c, 0x01, 0x04
						);
					}
				}
				else {
					if (m_nGameID == GOC_RgMagicMirrorDeluxe2 || 
						m_nGameID == GOC_RgDragonsTreas ||
						m_nGameID == GOC_RgElToreroMG ||
						m_nGameID == GOC_RgCairoCasino ||
						m_nGameID == GOC_RgJokersCap ||
						m_nGameID == GOC_RgBookOfFire ||
						m_nGameID == GOC_RgDoubleBook || 1
						) {
						myVector<uint8_t> pkt = {
							0x01, 0x02, 0x31, 0x00, 0x08, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x9c, 0x15, 0x00
						};
						int length = 0;
						for (int j = 0; j < m_vSpinMeters.size(); j++) {
							if (AT(m_vSpinMeters, j).line == 0xFF) {
								if (m_nGameID == GOC_RgBookOfFire || 
									m_nGameID == GOC_RgDragonsTreas || 
									m_nGameID == GOC_RgDoubleBook ||
									m_nGameID == GOC_RgMagicMirrorDeluxe2) {
									break;
								}
								continue;
							}
							pkt.push_back(AT(m_vSpinMeters, j).line);
							pkt.push_back(static_cast<BYTE>(AT(m_vSpinMeters, j).meter & 0xFF));
							pkt.push_back(static_cast<BYTE>((AT(m_vSpinMeters, j).meter >> 8) & 0xFF));

							pkt.push_back(static_cast<BYTE>(AT(m_vSpinMeters, j).meter2 & 0xFF));
							pkt.push_back(static_cast<BYTE>((AT(m_vSpinMeters, j).meter2 >> 8) & 0xFF));
							pkt.push_back(0x01);
							pkt.push_back(0x00);

							length += 7;
						}
						if (length > 0 && GOC_RgExtraWild != m_nGameID) { // in case of RgExtraWild, this part removes multi ani
							AT(pkt, 4) = 1 + length; //len
							AT(pkt, pkt.size() - 1) = 0x04;
							ACTION_PACKET_VEC(tick, pkt);
						}
					}
					else {
						ACTION_PACKET(tick,
							0x01, 0x02, 0x31, 0x00, 0x0f, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x9c, 0x15, 0x00, 0x00, static_cast<BYTE>(m_nSpinNormalMeter & 0xFF), static_cast<BYTE>((m_nSpinNormalMeter >> 8) & 0xFF), 0x14, 0x1c, 0x01, 0x00, 0x03, static_cast<BYTE>(m_nSpinMaxMeter & 0xFF), static_cast<BYTE>((m_nSpinMaxMeter >> 8) & 0xFF), 0x14, 0x1c, 0x01, 0x04
						);
					}					
				}
			}

			// Run sunnie
			UINT16 sunnieGOC = SUNNIER_GOC;
			ACTION_PACKET(tick, 0x01, 0x02, 0x28, 0x00, static_cast<BYTE>(sunnieGOC & 0xFF), static_cast<BYTE>((sunnieGOC >> 8) & 0xFF), 0x08, 0x00, 0x00, 0x00, 0x04);
			tick += 100;

			// total Bonus sound
			if (g_ReelGame->PlayBonusSoundAfterWinLine() == TRUE) {
				m_nBonusSoundID = m_SpinBonusSoundItem.soundID;
				PlaySound(tick, m_SpinBonusSoundItem.soundID);

				StateMachineCmd setStatusCmd;
				setStatusCmd.cmd = CMD_SetSatus;
				setStatusCmd.at = tick;
				setStatusCmd.o.st_SetStatus.status = STATUS_PlayingBonusSound;
				ACTION_PUSH_BACK(setStatusCmd);

				m_atStopBonusSound = tick + m_SpinBonusSoundItem.duration + 100;
			}
		}
		else {
			if (m_bSpinFast) {				
				tick += 100;
			}
			else {
				tick += g_ReelGame->LineSwapDelay(i - 1);
				LastLineSound = g_ReelGame->LineSwapDelay(i);
			}
		}
		if (AT(m_vSpinMeters, i).line == 0xFF) {
			m_nBonusBit.coin += AT(m_vSpinMeters, i).bonus.coin;
			SaveBonusBit(m_nBonusBit.coin);

			m_nBonusBit.ag += AT(m_vSpinMeters, i).bonus.ag;
			if (m_nBonusBit.coin > 0) {
				SetVisibleByGOC(tick, LATEST_LABEL_GOC, FALSE); // LetzterGewinn
			}
			// interrupt
			myVector<InterruptPacketData> IntPackets = AT(m_vSpinMeters, i).IntWinbonus;
			for (int i = 0; i < IntPackets.size(); i++) {
				tick += AT(IntPackets, i).preDelay;
				ACTION_PACKET_VEC(tick, AT(IntPackets, i).data);
				tick += AT(IntPackets, i).postDelay;
			}
		}
		else {
			if (m_nGameID == GOC_RgMultiWild243 && m_bSpinFast) {
				StopAllSound(tick);
			}
			// match line
			if (m_nGameID == GOC_RgCairoCasino) {
				ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x08, 0x00, 0xbe, 0x04, 0x9c, 0x11, 0x01, AT(m_vSpinMeters, i).line,
					static_cast<BYTE>(AT(m_vSpinMeters, i).meter & 0xFF), static_cast<BYTE>((AT(m_vSpinMeters, i).meter >> 8) & 0xFF),
					static_cast<BYTE>(AT(m_vSpinMeters, i).meter2 & 0xFF), static_cast<BYTE>((AT(m_vSpinMeters, i).meter2 >> 8) & 0xFF), 
					0x01, 0x04);				
			}
			else if (m_nGameID == GOC_RgExtraWild) { // show multi ani
				ACTION_PACKET(tick, 0x06, 0x30, 0x59, 0x01, 0x02, 0x31, 0x00, 0x08, 0x00, 0x4c, 0x1b, 0x9c, 0x00, 0x00,
					AT(m_vSpinMeters, i).line, 
					static_cast<BYTE>(AT(m_vSpinMeters, i).meter & 0xFF), static_cast<BYTE>((AT(m_vSpinMeters, i).meter >> 8) & 0xFF), 
					static_cast<BYTE>(AT(m_vSpinMeters, i).meter2 & 0xFF), static_cast<BYTE>((AT(m_vSpinMeters, i).meter2 >> 8) & 0xFF), 
					AT(m_vSpinMeters, i).multi, 0x04);
			}
			else {
				ACTION_PACKET(tick,
					0x01, 0x02, 0x31, 0x00, 0x08, 0x00, 
					static_cast<BYTE>(gId & 0xFF), static_cast<BYTE>((gId >> 8) & 0xFF), 0x9c, 0x11, 0x01, AT(m_vSpinMeters, i).line, 
					static_cast<BYTE>(AT(m_vSpinMeters, i).meter & 0xFF), static_cast<BYTE>((AT(m_vSpinMeters, i).meter >> 8) & 0xFF), 
					static_cast<BYTE>(AT(m_vSpinMeters, i).meter2 & 0xFF), static_cast<BYTE>((AT(m_vSpinMeters, i).meter2 >> 8) & 0xFF), 0x01, 0x04
				);
			}
			// inc bonus
			m_nBonusBit.coin += AT(m_vSpinMeters, i).bonus.coin;
			SaveBonusBit(m_nBonusBit.coin);

			m_nBonusBit.ag += AT(m_vSpinMeters, i).bonus.ag;
			if (m_nBonusBit.coin > 0) {
				SetVisibleByGOC(tick, LATEST_LABEL_GOC, FALSE); // LetzterGewinn
			}
			if (i == 0 && m_bMultoGo == FALSE) {
				SetVisibleByGOC(tick, BONUS_BIT_GOC, FALSE);
				tick += 200;
			}
			if (m_nBonusBit.coin) {
				DisplayMoney(tick, BONUS_BIT_GOC, m_nBonusBit.coin, 0);
			}

			if (m_bSpinFast == FALSE) {
				// Play match line sound
				if (AT(m_vSpinMeters, i).sound != MAX_SOUND_IDS) {
					if (PlaySound(tick, AT(m_vSpinMeters, i).sound) && i == (m_vSpinMeters.size() - 1)) {
						SoundItem item = getSoundByID(AT(m_vSpinMeters, i).sound);
						LastLineSound = item.duration;
					}
				}
				else {
					UINT16 SoundID = g_ReelGame->LineSound(AT(m_vSpinMeters, i).line, AT(m_vSpinMeters, i).symbol, AT(m_vSpinMeters, i).weight);
					if (PlaySound(tick, SoundID) && i == (m_vSpinMeters.size() - 1)) {
						SoundItem item = getSoundByID(SoundID);
						LastLineSound = item.duration;
					}
				}
			}
		}
	}

	total = 0;
	gone = 0;
	loop = 0;
	g_ReelGame->MultiGoGoneAndRemain(gone, total, loop);
	if (m_bMultoGo && gone >= total) {
MULTIGO_END:
		UINT multiBet = g_ReelGame->MiltiGoBet();
		if (m_nMultiGoTotalLoop < 3 && m_nBonusBit.coin >= multiBet * 4) {
			// show multigo dialog;
			auto IntPackets = g_ReelGame->EnterMultiGo(m_nBonusBit.coin, FALSE);
			for (int i = 0; i < IntPackets.size(); i++) {
				tick += AT(IntPackets, i).preDelay;
				if (i == 0) {
					tick += 1000;
				}
				ACTION_PACKET_VEC(tick, AT(IntPackets, i).data);
				tick += AT(IntPackets, i).postDelay;
			}
			// update bonus bit
			DisplayMoney(tick, BONUS_BIT_GOC, m_nBonusBit.coin, 0);
			CalcRTP(FALSE, StateMachine::g_rtpGeneration.load());

			m_atAutoNormalInMultigo = tick + AUTO_RETURN_TO_MENU_TIME;
			// set status for multigo dialog
			StateMachineCmd setStatusCmd;
			setStatusCmd.cmd = CMD_SetSatus;
			setStatusCmd.at = tick;
			setStatusCmd.o.st_SetStatus.status = STATUS_PendingMultiGo;
			ACTION_PUSH_BACK(setStatusCmd);

		}
		else {
			UINT32 temp = 0;
			auto IntPackets = g_ReelGame->CloseMultiGo(m_nBonusBit.coin, FALSE);
			for (int i = 0; i < IntPackets.size(); i++) {
				tick += AT(IntPackets, i).preDelay;
				if (i == 0) {
					tick += 1000;
				}
				ACTION_PACKET_VEC(tick, AT(IntPackets, i).data);
				tick += AT(IntPackets, i).postDelay;
			}
			m_bMultoGo = FALSE;
			DisplayMoney(tick, BONUS_BIT_GOC, m_nBonusBit.coin, 0);
			CalcRTP(FALSE, StateMachine::g_rtpGeneration.load());
			//SetVisibleByGOC(tick, LATEST_LABEL_GOC, m_nBonusBit.coin ? TRUE : FALSE);

			StateMachineCmd setStatusCmd;
			setStatusCmd.cmd = CMD_SetSatus;
			setStatusCmd.at = tick;
			setStatusCmd.o.st_SetStatus.status = m_nBonusBit.coin == 0 ? STATUS_PendingSpin : STATUS_WaitActionBonusSound;
			ACTION_PUSH_BACK(setStatusCmd);

			StopAllSound(tick);
			if (m_bAutoSpin) {
				Spin();
				return;
			}
			if (m_nBonusBit.coin) {				
				PlaySound(tick, SMP_VorauswahlRisiko);
				m_atStopWaitAction_40s = tick + AUTO_MOVE_BONUS_TIME + 10 * 1000;
			}
		}
		return;
	}
	
	// show total win lines
	tick += LastLineSound;
	myVector<UINT8> packet = g_ReelGame->ShowTotalWinLines(m_vSpinMeters);
	if (packet.size()) {
		if ((m_nGameID == GOC_RgDragonsTreas && m_bFreeMode) ||
			(m_nGameID == GOC_RgMagicMirrorDeluxe2 && m_bFreeMode) ||
			m_nGameID == GOC_RgLosFrootos) {
		}
		else {
			if (m_nGameID == GOC_RgExtraWild) {
				ACTION_PACKET(tick, 0x06, 0x30, 0x59, 0x01, 0x02, 0x31, 0x00, 0x08, 0x00, 0x4c, 0x1b, 0x9c, 0x00, 0x00, 0x09,
					AT(packet, packet.size() - 4), AT(packet, packet.size() - 3), 
					AT(packet, packet.size() - 2), AT(packet, packet.size() - 1), 0x01, 0x04);

				myVector<UINT8> subVec;
				subVec.assign(packet.begin(), packet.end() - 4);
				ACTION_PACKET_VEC(tick, subVec);
			}
			else {
				ACTION_PACKET_VEC(tick, packet);
			}
			tick += 500;
		}
		AT(packet, 12) = 0x19;
		m_vecAnimsAfterTake = packet;
	}

	// total Bonus sound	
	if (g_ReelGame->PlayBonusSoundAfterWinLine() == FALSE) {
		m_nBonusSoundID = m_SpinBonusSoundItem.soundID;
		PlaySound(tick, m_SpinBonusSoundItem.soundID);

		StateMachineCmd setStatusCmd;
		setStatusCmd.cmd = CMD_SetSatus;
		setStatusCmd.at = tick;
		setStatusCmd.o.st_SetStatus.status = STATUS_PlayingBonusSound;
		ACTION_PUSH_BACK(setStatusCmd);

		m_atStopBonusSound = tick + m_SpinBonusSoundItem.duration + 100;
	}
}

void StateMachine::FastSpin() {
	if (GetStatus() != STATUS_SpinRunning) {
		return;
	}
	if (m_bMultoGo) {
		return;
	}
	if (m_nGameID == GOC_RgIndianRuby && m_bFreeMode) {
		return;
	}
	UINT64 tick = current_time_ms();
	KomProtocol* pKom = CryptoCard::GetInstance().GetKomProtocol();
	BYTE data[] = { 0x01, 0x02, 0x30, 0x00,
		static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF),
		0xff, 0xff, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x9b, 0x04 };
	if (pKom) {
		pKom->MakePacket(data, sizeof(data));
		m_bSpinFast = TRUE;
	}
}

BOOL StateMachine::PlaySound(UINT64 tick, UINT16 SoundId, BOOL RightNow) {
	if (SoundId >= MAX_SOUND_IDS) {
		return FALSE;
	}
	if (!RightNow) {
		ACTION_PACKET(tick,
			0x01, 0x02, 0x34, 0x00,
			static_cast<BYTE>(SoundId & 0xFF), static_cast<BYTE>((SoundId >> 8) & 0xFF),
			0x04
		);
		return TRUE;
	}

	KomProtocol* pKom = CryptoCard::GetInstance().GetKomProtocol();
	BYTE data[] = { 0x01, 0x02, 0x34, 0x00,
		static_cast<BYTE>(SoundId & 0xFF), static_cast<BYTE>((SoundId >> 8) & 0xFF),
		0x04 };
	pKom->MakePacket(data, sizeof(data));
	return TRUE;
}

void StateMachine::StopSound(UINT64 tick, UINT16 SoundId) {
	ACTION_PACKET(tick,
		0x01, 0x02, 0x35, 0x00,
		static_cast<BYTE>(SoundId & 0xFF), static_cast<BYTE>((SoundId >> 8) & 0xFF),
		0x04
	);
}

void StateMachine::StopAllSound(UINT64 tick) {
	ACTION_PACKET(tick, 0x01, 0x02, 0x35, 0x00, 0x00, 0x00, 0x04);
}

void StateMachine::BetUp() {
	if (m_nStatus.load() != STATUS_PendingSpin) {
		if (m_nStatus.load() != STATUS_PlayingBonusSound && m_nStatus.load() != STATUS_WaitActionBonusSound && m_nStatus.load() != STATUS_Risiko && m_nStatus.load() != STATUS_RisikoAss) {
			return;
		}
		if (m_bMultoGo) {
			return;
		}
		if (m_bAutoSpin || m_bHalfAutoSpin) {
			return;
		}
		if (m_nBonusBit.ag > 0) {
			return;
		}
		if (m_Risiko.bOpen) {	
			rsk_go();
		}
		else {
			if (m_CardGamble.bOpen) {
				cg_go(TRUE); // select red
			}
			else {
				rsk_open();
			}
		}
		return;
	}
	if (m_CardGamble.bOpen || m_Risiko.bOpen) {
		return;
	}
	if (m_bFreeMode) {
		return;
	}
	if (m_bMultoGo) {
		return;
	}
	StateMachineCmd cmd;
	cmd.cmd = CMD_BetUp;
	++StateMachine::g_rtpGeneration;  //for cancellation previous CalcRTP
	DebugPrintf("FAST g_rtpGeneration added %d", StateMachine::g_rtpGeneration.load());

	LOCK_MUTEX(m_vecCmdMutex);
	m_vecCmd.push_back(cmd);
	UNLOCK_MUTEX(m_vecCmdMutex);

	UINT64 tick = current_time_ms();
	m_atAutoReturnToMenu = tick + AUTO_RETURN_TO_MENU_TIME;
}

void StateMachine::MaxBet() {
	if (m_nStatus.load() != STATUS_PendingSpin) {
		return;
	}
	if (m_CardGamble.bOpen || m_Risiko.bOpen) {
		return;
	}
	if (m_bFreeMode) {
		return;
	}
	if (m_bMultoGo) {
		return;
	}
	StateMachineCmd cmd;
	cmd.cmd = CMD_MaxBet;

	LOCK_MUTEX(m_vecCmdMutex);
	m_vecCmd.push_back(cmd);
	UNLOCK_MUTEX(m_vecCmdMutex);

	UINT64 tick = current_time_ms();
	m_atAutoReturnToMenu = tick + AUTO_RETURN_TO_MENU_TIME;
}

void StateMachine::BetUp_pkt() {
	int OrgBetStep = g_ReelGame->BetStep();
	myVector<UINT16> bets = g_ReelGame->Bets();
	UINT8 betstep = g_ReelGame->BetUp();
	UINT16 betval = AT(bets, betstep) / 5;
	UINT64 tick = current_time_ms();
	ShowWinLines(tick);
	ACTION_PACKET(tick,
		0x01, 0x02, 0x30, 0x00, 0x25, 0x53,
		static_cast<BYTE>(betval & 0xFF), static_cast<BYTE>((betval >> 8) & 0xFF), 
		0x00, 0x00, 0x00,
		0x00, 0x00, 0x00, 0x04, 0x04
	);
	if (betstep == (bets.size() - 1)) {
		PlaySound(tick, SMP_Maxbet_Button);
	}
	else {
		PlaySound(tick, SMP_Bet1);
	}

	if (betstep != OrgBetStep) {
		// update leds per bet on RgKeyOfTheNail
		auto IntPackets = g_ReelGame->OnBetUp(OrgBetStep, betstep);
		for (int i = 0; i < IntPackets.size(); i++) {
			tick += AT(IntPackets, i).preDelay;
			ACTION_PACKET_VEC(tick, AT(IntPackets, i).data);
			tick += AT(IntPackets, i).postDelay;
		}

		PlayDB::GetInstance().SaveCheckPoint(g_ReelGame->GetGameName(), AT(g_ReelGame->Bets(), g_ReelGame->BetStep()),
			m_nGameID == GOC_RgDoubleBook ? g_ReelGame->GameMode() : g_ReelGame->WinLine(),
			g_ReelGame->CheckPoint());

	}

	StateMachineCmd cmd;
	cmd.cmd = CMD_CalcRTP;
	cmd.at = tick;
	ACTION_PUSH_BACK(cmd);
	//CalcRTP(FALSE);
}

void StateMachine::MaxBet_pkt() {
	UINT8 oldBetStep = g_ReelGame->BetStep();

	myVector<UINT16> bets = g_ReelGame->Bets();
	UINT8 betstep = g_ReelGame->MaxBet();
	if (oldBetStep == betstep) {
		return;
	}
	UINT16 betval = AT(bets, betstep) / 5;
	UINT64 tick = current_time_ms();
	ShowWinLines(tick);
	ACTION_PACKET(tick,
		0x01, 0x02, 0x30, 0x00, 0x25, 0x53,
		static_cast<BYTE>(betval & 0xFF), static_cast<BYTE>((betval >> 8) & 0xFF), 
		0x00, 0x00, 0x00,
		0x00, 0x00, 0x00, 0x04, 0x04
	);
	PlaySound(tick, SMP_Maxbet_Button);

	PlayDB::GetInstance().SaveCheckPoint(g_ReelGame->GetGameName(), AT(g_ReelGame->Bets(), g_ReelGame->BetStep()),
		m_nGameID == GOC_RgDoubleBook ? g_ReelGame->GameMode() : g_ReelGame->WinLine(),
		g_ReelGame->CheckPoint());

	// update leds per bet on RgKeyOfTheNail
	auto IntPackets = g_ReelGame->OnBetUp(oldBetStep, betstep);
	for (int i = 0; i < IntPackets.size(); i++) {
		tick += AT(IntPackets, i).preDelay;
		ACTION_PACKET_VEC(tick, AT(IntPackets, i).data);
		tick += AT(IntPackets, i).postDelay;
	}
	StateMachineCmd cmd;
	cmd.cmd = CMD_CalcRTP;
	cmd.at = tick;
	ACTION_PUSH_BACK(cmd);
	//CalcRTP(FALSE);
}

void StateMachine::Numpad0() {
	return;
	if (m_nStatus.load() != STATUS_Risiko) {
		return;
	}
	if (m_nBonusBit.ag > 0) {
		return;
	}
	if (m_CardGamble.bOpen) {
		cg_go(FALSE);// select back color
		return;
	}
}

void StateMachine::Numpad1() {
	if (m_nStatus.load() == STATUS_PendingSpin) {
		MaxBet();
		return;
	}
	if (m_nStatus.load() != STATUS_PlayingBonusSound && m_nStatus.load() != STATUS_WaitActionBonusSound && m_nStatus.load() != STATUS_Risiko) {
		return;
	}
	if (m_bMultoGo) {
		return;
	}
	if (m_bAutoSpin || m_bHalfAutoSpin) {
		return;
	}
	if (m_nBonusBit.ag > 0) {
		return;
	}
	if (m_CardGamble.bOpen) {
		cg_go(FALSE); // select red color
	}
	else {
		cg_open();
	}
}

void StateMachine::Numpad2() {
	return;
	if (m_nStatus.load() != STATUS_PlayingBonusSound && m_nStatus.load() != STATUS_WaitActionBonusSound && m_nStatus.load() != STATUS_Risiko) {
		return;
	}
	if (m_bMultoGo) {
		return;
	}
	if (m_bAutoSpin || m_bHalfAutoSpin) {
		return;
	}
	if (m_nBonusBit.ag > 0) {
		return;
	}
	if (m_Risiko.bOpen) {
		rsk_go();
	}
	else {
		rsk_open();
	}
}

void StateMachine::StopPlayingBonusSound() {
	if (m_nStatus.load() != STATUS_PlayingBonusSound) {
		return;
	}
	if (m_nMagicCount) {
		EnterMagicGame();
		return;
	}
	UINT64 tick = current_time_ms();
	StopSound(tick, m_nBonusSoundID);

	if (g_ReelGame->CanMultiGo()) {
		m_atAutoNormalInMultigo = tick + AUTO_RETURN_TO_MENU_TIME;
		CHANGE_STATUS(STATUS_PendingMultiGo);

		auto IntPackets = g_ReelGame->EnterMultiGo(m_nBonusBit.coin, TRUE);
		for (int i = 0; i < IntPackets.size(); i++) {
			tick += AT(IntPackets, i).preDelay;
			ACTION_PACKET_VEC(tick, AT(IntPackets, i).data);
			tick += AT(IntPackets, i).postDelay;
		}
		DisplayMoney(tick, BONUS_BIT_GOC, m_nBonusBit.coin, 0);
		CalcRTP(FALSE, StateMachine::g_rtpGeneration.load());
		return;
	}

	if (m_bAutoSpin || (m_bFreeMode == FALSE && g_ReelGame->CanFreeMode())) {
		Spin();
		return;
	}

	if (m_bFreeMode == FALSE && m_bMultoGo == FALSE) {
		// background
		PlaySound(tick, SMP_VorauswahlRisiko);
	}
	SpinningTottalLines();
	CHANGE_STATUS(STATUS_WaitActionBonusSound);
	m_atStopWaitAction_40s = tick + AUTO_MOVE_BONUS_TIME;
}

void StateMachine::SpinningTottalLines() {
	UINT64 tick = current_time_ms();
	if (m_vecAnimsAfterTake.size() > 0) {
		if (m_nGameID == GOC_RgBlazingSun ||
			m_nGameID == GOC_RgDragonsTreas ||
			m_nGameID == GOC_RgHotFrootastic ||
			m_nGameID == GOC_RgMerkurMagnus ||
			m_nGameID == GOC_RgKeyOfTheNile ||
			m_nGameID == GOC_RgRisingLiner) { // show spinning winlines from total show
			ACTION_PACKET_VEC(tick, m_vecAnimsAfterTake);
		}
	}
}

void StateMachine::DisplayMoney(UINT64 tick, UINT16 gocID, UINT32 amount, UINT8 stepSizeTime) {
	ACTION_PACKET(tick,
		0x01, 0x02, 0x2C, 0x00,
		static_cast<BYTE>(gocID & 0xFF),
		static_cast<BYTE>((gocID >> 8) & 0xFF),
		static_cast<BYTE>(amount & 0xFF),
		static_cast<BYTE>((amount >> 8) & 0xFF),
		static_cast<BYTE>((amount >> 16) & 0xFF), 
		static_cast<BYTE>((amount >> 24) & 0xFF),
		stepSizeTime, 0x00,
		0x00, 0x00, 0x01,
		0x04
	);
}

void StateMachine::SetVisibleByGOC(UINT64 tick, UINT16 gocID, BOOL visible) {	
	ACTION_PACKET(tick, 0x01, 0x02, 0x2f, 0x00, static_cast<BYTE>(gocID & 0xFF),
		static_cast<BYTE>((gocID >> 8) & 0xFF), static_cast<BYTE>(visible), 0x04);
}

void StateMachine::ShowWinLines(UINT64 tick) {
	if (m_bNeedHideShowLines) {
		HideWinLines(tick);
	}
	if (m_nGameID == GOC_RgPyramidOfPower) {
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x04, 0x00, 0xd4, 0x3b, 0x9d, 0xff, 0xff, 0x00, 0x00, 0x04);
	}
	else {
		if (g_ReelGame->WinLine() == 10) {
			ACTION_PACKET(tick,
				0x01, 0x02, 0x31, 0x00, 0x04, 0x00, 
				static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x9d, 0xff, 
				0x03, 0x00, 0x00, 0x04
			);
		}
		else {
			ACTION_PACKET(tick,
				0x01, 0x02, 0x31, 0x00, 0x04, 0x00,
				static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x9D, 0x1F,
				0x00, 0x00, 0x00, 0x04
			);
		}
	}	
}

void StateMachine::HideWinLines(UINT64 tick) {
	ACTION_PACKET(tick,
		0x01, 0x02, 0x31, 0x00, 0x01, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x02, 0x00, 0x04
	);
	m_bNeedHideShowLines = FALSE;
}

void StateMachine::MousePressed(UINT8 reel, UINT8 x, UINT8 row, UINT8 y) {
	if (!g_ReelGame) {
		return;
	}
	UINT64 tick = current_time_ms();
	MousePosition p{ {reel, x}, {row, y} };
	if (GetStatus() >= STATUS_PendingSpin) {
		MousePosition aa{
			{MMCODE_sunny_LB_x_reel   , MMCODE_sunny_LB_x_pos    },
			{MMCODE_sunny_LB_y_row    , MMCODE_sunny_LB_y_pos    }
		 };
		 MousePosition ba{
			{MMCODE_sunny_RT_x_reel   , MMCODE_sunny_RT_x_pos    },
			{MMCODE_sunny_RT_y_row    , MMCODE_sunny_RT_y_pos    }
		 };

		 if (IsMouseWithin(p, aa, ba)) {
#ifdef MMCODE_BY_SUNNY
			mmcode_active_go('m', true);
			mmcode_active_go('m', true);
			mmcode_active_go('c', true);
			mmcode_active_go('o', true);
			mmcode_active_go('d', true);
			mmcode_active_go('e', true);
#endif
		}
	}

	if (GetStatus() == STATUS_MagicGame) {
		MousePosition a_1000{
		   {Magic_MP_1000_LB_x_reel, Magic_MP_1000_LB_x_pos },
		   {Magic_MP_1000_LB_y_row, Magic_MP_1000_LB_y_pos }
		};
		MousePosition b_1000{
		   {Magic_MP_1000_RT_x_reel, Magic_MP_1000_RT_x_pos },
		   {Magic_MP_1000_RT_y_row, Magic_MP_1000_RT_y_pos }
		};
		MousePosition a_ag{
		   {Magic_MP_AG_LB_x_reel, Magic_MP_AG_LB_x_pos },
		   {Magic_MP_AG_LB_y_row, Magic_MP_AG_LB_y_pos }
		};
		MousePosition b_ag{
		   {Magic_MP_AG_RT_x_reel, Magic_MP_AG_RT_x_pos },
		   {Magic_MP_AG_RT_y_row, Magic_MP_AG_RT_y_pos }
		};

		if (IsMouseWithin(p, a_1000, b_1000)) {
			TakeMagicBonus();
			return;
		}
		else if (IsMouseWithin(p, a_ag, b_ag)) {
			GoMagicGame();
			return;
		}
		return;
	}
	if (GetStatus() == STATUS_Risiko) {
		if (m_CardGamble.bOpen == TRUE && m_CardGamble.bFinished == FALSE) {
			MousePosition a_half{
			   {CardGamble_MP_half_LB_x_reel, CardGamble_MP_half_LB_x_pos},
			   {CardGamble_MP_half_LB_y_row, CardGamble_MP_half_LB_y_pos}
			};
			MousePosition b_half{
			   {CardGamble_MP_half_RT_x_reel, CardGamble_MP_half_RT_x_pos},
			   {CardGamble_MP_half_RT_y_row, CardGamble_MP_half_RT_y_pos}
			};

			MousePosition a_risiko{
			   {CardGamble_MP_risiko_LB_x_reel, CardGamble_MP_risiko_LB_x_pos},
			   {CardGamble_MP_risiko_LB_y_row, CardGamble_MP_risiko_LB_y_pos}
			};
			MousePosition b_risiko{
			   {CardGamble_MP_risiko_RT_x_reel, CardGamble_MP_risiko_RT_x_pos},
			   {CardGamble_MP_risiko_RT_y_row, CardGamble_MP_risiko_RT_y_pos}
			};

			MousePosition a_red{
			   {CardGamble_MP_red_LB_x_reel, CardGamble_MP_red_LB_x_pos},
			   {CardGamble_MP_red_LB_y_row, CardGamble_MP_red_LB_y_pos}
			};
			MousePosition b_red{
			   {CardGamble_MP_red_RT_x_reel, CardGamble_MP_red_RT_x_pos},
			   {CardGamble_MP_red_RT_y_row, CardGamble_MP_red_RT_y_pos}
			};

			MousePosition a_black{
			   {CardGamble_MP_black_LB_x_reel, CardGamble_MP_black_LB_x_pos},
			   {CardGamble_MP_black_LB_y_row, CardGamble_MP_black_LB_y_pos}
			};
			MousePosition b_black{
			   {CardGamble_MP_black_RT_x_reel, CardGamble_MP_black_RT_x_pos},
			   {CardGamble_MP_black_RT_y_row, CardGamble_MP_black_RT_y_pos}
			};

			if (IsMouseWithin(p, a_half, b_half)) {	
				if (m_CardGamble.nRisikoLevel >= 20) {
					UINT16 half = m_CardGamble.nRisikoLevel / 2;
					if (half > 0) {
						m_CardGamble.nRisikoLevel -= half;
						m_CardGamble.nRisikoErfolg = m_CardGamble.nRisikoLevel * 2;
						cg_moveRestErfolg(tick);

						// disable half button
						if (m_CardGamble.nRisikoLevel <= 20) {
							ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0xa1, 0x52, 0x71, 0x00, 0x04);
						}
					}
				}
				return;
			}
			if (IsMouseWithin(p, a_risiko, b_risiko)) {
				m_CardGamble.bOpen = FALSE;
				StopAllSound(tick);
				// close card gamble
				ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0xa1, 0x52, 0x70, 0x00, 0x04);
				//CHANGE_STATUS(STATUS_PlayingBonusSound);
				rsk_open(TRUE);
				return;
			}
			if (IsMouseWithin(p, a_red, b_red)) {
				cg_go(TRUE);
				return;
			}
			if (IsMouseWithin(p, a_black, b_black)) {
				cg_go(FALSE);
				return;
			}
			return;
		}
		if (m_Risiko.bOpen == TRUE && m_Risiko.bFinished == FALSE && m_nBonusBit.coin < 14000 && m_Risiko.bOpening == FALSE && m_Risiko.bUpgrading == FALSE) {
			MousePosition a_card{
			   {Risiko_MP_card_LB_x_reel, Risiko_MP_card_LB_x_pos},
			   {Risiko_MP_card_LB_y_row, Risiko_MP_card_LB_y_pos}
			};
			MousePosition b_card{
			   {Risiko_MP_card_RT_x_reel, Risiko_MP_card_RT_x_pos},
			   {Risiko_MP_card_RT_y_row, Risiko_MP_card_RT_y_pos}
			};
			MousePosition a_down{
			   {Risiko_MP_down_LB_x_reel, Risiko_MP_down_LB_x_pos},
			   {Risiko_MP_down_LB_y_row, Risiko_MP_down_LB_y_pos}
			};
			MousePosition b_down{
			   {Risiko_MP_down_RT_x_reel, Risiko_MP_down_RT_x_pos},
			   {Risiko_MP_down_RT_y_row, Risiko_MP_down_RT_y_pos}
			};
			if (IsMouseWithin(p, a_card, b_card)) {
				m_Risiko.bOpen = FALSE;
				StopAllSound(tick);
				// close risiko
				ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0xb1, 0x52, 0x68, 0x00, 0x04);
				//CHANGE_STATUS(STATUS_PlayingBonusSound);
				cg_open(TRUE);
				return;
			}
			if (IsMouseWithin(p, a_down, b_down)) {
				if (rsk_downable()) {
					ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x02, 0x00, 0xb1, 0x52, 0x67, 0x01, 0x02, 0x04); tick += 50; // highlight
					ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x02, 0x00, 0xb1, 0x52, 0x67, 0x01, 0x01, 0x04); // enable
					int target = rsk_down();
					// set target
					ACTION_PACKET(tick, 0x01, 0x02, 0x40, 0x00, 0xb1, 0x52, 0x06, static_cast<BYTE>(target), 0x00, 0x00, 0x00, 0x04);
					if (!rsk_downable()) {
						// disable down button
						ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x02, 0x00, 0xb1, 0x52, 0x67, 0x01, 0x03, 0x04);
					}
				}
				return;
			}
		}
		return;
	}
	
	if (GetStatus() == STATUS_WaitMouseAction) {
		MousePosition a_SIEGFR{
		   {RgDragonsTreas_MP_free_SIEGFR_LB_x_reel, RgDragonsTreas_MP_free_SIEGFR_LB_x_pos},
		   {RgDragonsTreas_MP_free_SIEGFR_LB_y_row, RgDragonsTreas_MP_free_SIEGFR_LB_y_pos}
		};
		MousePosition b_SIEGFR{
		   {RgDragonsTreas_MP_free_SIEGFR_RT_x_reel, RgDragonsTreas_MP_free_SIEGFR_RT_x_pos},
		   {RgDragonsTreas_MP_free_SIEGFR_RT_y_row, RgDragonsTreas_MP_free_SIEGFR_RT_y_pos}
		};

		MousePosition a_HAGEN{
		   {RgDragonsTreas_MP_free_HAGEN_LB_x_reel, RgDragonsTreas_MP_free_HAGEN_LB_x_pos},
		   {RgDragonsTreas_MP_free_HAGEN_LB_y_row, RgDragonsTreas_MP_free_HAGEN_LB_y_pos}
		};
		MousePosition b_HAGEN{
		   {RgDragonsTreas_MP_free_HAGEN_RT_x_reel, RgDragonsTreas_MP_free_HAGEN_RT_x_pos},
		   {RgDragonsTreas_MP_free_HAGEN_RT_y_row, RgDragonsTreas_MP_free_HAGEN_RT_y_pos}
		};

		MousePosition a_SCHATZ{
		   {RgDragonsTreas_MP_free_SCHATZ_LB_x_reel, RgDragonsTreas_MP_free_SCHATZ_LB_x_pos},
		   {RgDragonsTreas_MP_free_SCHATZ_LB_y_row, RgDragonsTreas_MP_free_SCHATZ_LB_y_pos}
		};
		MousePosition b_SCHATZ{
		   {RgDragonsTreas_MP_free_SCHATZ_RT_x_reel, RgDragonsTreas_MP_free_SCHATZ_RT_x_pos},
		   {RgDragonsTreas_MP_free_SCHATZ_RT_y_row, RgDragonsTreas_MP_free_SCHATZ_RT_y_pos}
		};

		MousePosition a_SCHWER{
		   {RgDragonsTreas_MP_free_SCHWER_LB_x_reel, RgDragonsTreas_MP_free_SCHWER_LB_x_pos},
		   {RgDragonsTreas_MP_free_SCHWER_LB_y_row, RgDragonsTreas_MP_free_SCHWER_LB_y_pos}
		};
		MousePosition b_SCHWER{
		   {RgDragonsTreas_MP_free_SCHWER_RT_x_reel, RgDragonsTreas_MP_free_SCHWER_RT_x_pos},
		   {RgDragonsTreas_MP_free_SCHWER_RT_y_row, RgDragonsTreas_MP_free_SCHWER_RT_y_pos}
		};

		MousePosition a_A{
		   {RgDragonsTreas_MP_free_A_LB_x_reel, RgDragonsTreas_MP_free_A_LB_x_pos},
		   {RgDragonsTreas_MP_free_A_LB_y_row, RgDragonsTreas_MP_free_A_LB_y_pos}
		};
		MousePosition b_A{
		   {RgDragonsTreas_MP_free_A_RT_x_reel, RgDragonsTreas_MP_free_A_RT_x_pos},
		   {RgDragonsTreas_MP_free_A_RT_y_row, RgDragonsTreas_MP_free_A_RT_y_pos}
		};

		MousePosition a_K{
		   {RgDragonsTreas_MP_free_K_LB_x_reel, RgDragonsTreas_MP_free_K_LB_x_pos},
		   {RgDragonsTreas_MP_free_K_LB_y_row, RgDragonsTreas_MP_free_K_LB_y_pos}
		};
		MousePosition b_K{
		   {RgDragonsTreas_MP_free_K_RT_x_reel, RgDragonsTreas_MP_free_K_RT_x_pos},
		   {RgDragonsTreas_MP_free_K_RT_y_row, RgDragonsTreas_MP_free_K_RT_y_pos}
		};

		MousePosition a_Q{
		   {RgDragonsTreas_MP_free_Q_LB_x_reel, RgDragonsTreas_MP_free_Q_LB_x_pos},
		   {RgDragonsTreas_MP_free_Q_LB_y_row, RgDragonsTreas_MP_free_Q_LB_y_pos}
		};
		MousePosition b_Q{
		   {RgDragonsTreas_MP_free_Q_RT_x_reel, RgDragonsTreas_MP_free_Q_RT_x_pos},
		   {RgDragonsTreas_MP_free_Q_RT_y_row, RgDragonsTreas_MP_free_Q_RT_y_pos}
		};

		MousePosition a_J{
		   {RgDragonsTreas_MP_free_J_LB_x_reel, RgDragonsTreas_MP_free_J_LB_x_pos},
		   {RgDragonsTreas_MP_free_J_LB_y_row, RgDragonsTreas_MP_free_J_LB_y_pos}
		};
		MousePosition b_J{
		   {RgDragonsTreas_MP_free_J_RT_x_reel, RgDragonsTreas_MP_free_J_RT_x_pos},
		   {RgDragonsTreas_MP_free_J_RT_y_row, RgDragonsTreas_MP_free_J_RT_y_pos}
		};

		MousePosition a_10{
		   {RgDragonsTreas_MP_free_10_LB_x_reel, RgDragonsTreas_MP_free_10_LB_x_pos},
		   {RgDragonsTreas_MP_free_10_LB_y_row, RgDragonsTreas_MP_free_10_LB_y_pos}
		};
		MousePosition b_10{
		   {RgDragonsTreas_MP_free_10_RT_x_reel, RgDragonsTreas_MP_free_10_RT_x_pos},
		   {RgDragonsTreas_MP_free_10_RT_y_row, RgDragonsTreas_MP_free_10_RT_y_pos}
		};
		myVector<InterruptPacketData> IntPackets;
		if (IsMouseWithin(p, a_SIEGFR, b_SIEGFR)) {
			IntPackets = g_ReelGame->SelectSymbol("drtrSIEGFR");
		}
		else if (IsMouseWithin(p, a_HAGEN, b_HAGEN)) {
			IntPackets = g_ReelGame->SelectSymbol("drtrHAGEN_");
		}
		else if (IsMouseWithin(p, a_SCHATZ, b_SCHATZ)) {
			IntPackets = g_ReelGame->SelectSymbol("drtrSCHATZ");
		}
		else if (IsMouseWithin(p, a_SCHWER, b_SCHWER)) {
			IntPackets = g_ReelGame->SelectSymbol("drtrSCHWER");
		}
		else if (IsMouseWithin(p, a_A, b_A)) {
			IntPackets = g_ReelGame->SelectSymbol("drtrA_____");
		}
		else if (IsMouseWithin(p, a_K, b_K)) {
			IntPackets = g_ReelGame->SelectSymbol("drtrK_____");
		}
		else if (IsMouseWithin(p, a_Q, b_Q)) {
			IntPackets = g_ReelGame->SelectSymbol("drtrQ_____");
		}
		else if (IsMouseWithin(p, a_J, b_J)) {
			IntPackets = g_ReelGame->SelectSymbol("drtrJ_____");
		}
		else if (IsMouseWithin(p, a_10, b_10)) {
			IntPackets = g_ReelGame->SelectSymbol("drtrTEN___");
		}
		else {
			return;
		}
		for (int i = 0; i < IntPackets.size(); i++) {
			tick += AT(IntPackets, i).preDelay;
			ACTION_PACKET_VEC(tick, AT(IntPackets, i).data);
			tick += AT(IntPackets, i).postDelay;
		}
		m_atMovingFinished = tick + 100;
		CHANGE_STATUS(STATUS_MovingSymbol);
		return;
	}
	
	if (GetStatus() == STATUS_PendingMultiGo) {
		if (m_nGameID == GOC_RgLosFrootos || m_nGameID == GOC_RgPharosGoldBase) {
			MousePosition a_up{
			   {m_nGameID == GOC_RgLosFrootos ? RgLosFrootos_MP_betup_LB_x_reel : RgPharosGoldBase_MP_betup_LB_x_reel, m_nGameID == GOC_RgLosFrootos ? RgLosFrootos_MP_betup_LB_x_pos : RgPharosGoldBase_MP_betup_LB_x_pos},
			   {m_nGameID == GOC_RgLosFrootos ? RgLosFrootos_MP_betup_LB_y_row : RgPharosGoldBase_MP_betup_LB_y_row, m_nGameID == GOC_RgLosFrootos ? RgLosFrootos_MP_betup_LB_y_pos : RgPharosGoldBase_MP_betup_LB_y_pos}
			};
			MousePosition b_up{
			   {m_nGameID == GOC_RgLosFrootos ? RgLosFrootos_MP_betup_RT_x_reel : RgPharosGoldBase_MP_betup_RT_x_reel, m_nGameID == GOC_RgLosFrootos ? RgLosFrootos_MP_betup_RT_x_pos : RgPharosGoldBase_MP_betup_RT_x_pos},
			   {m_nGameID == GOC_RgLosFrootos ? RgLosFrootos_MP_betup_RT_y_row : RgPharosGoldBase_MP_betup_RT_y_row, m_nGameID == GOC_RgLosFrootos ? RgLosFrootos_MP_betup_RT_y_pos : RgPharosGoldBase_MP_betup_RT_y_pos}
			};
			MousePosition a_down{
			   {m_nGameID == GOC_RgLosFrootos ? RgLosFrootos_MP_betdown_LB_x_reel : RgPharosGoldBase_MP_betdown_LB_x_reel, m_nGameID == GOC_RgLosFrootos ? RgLosFrootos_MP_betdown_LB_x_pos : RgPharosGoldBase_MP_betdown_LB_x_pos},
			   {m_nGameID == GOC_RgLosFrootos ? RgLosFrootos_MP_betdown_LB_y_row : RgPharosGoldBase_MP_betdown_LB_y_row, m_nGameID == GOC_RgLosFrootos ? RgLosFrootos_MP_betdown_LB_y_pos : RgPharosGoldBase_MP_betdown_LB_y_pos}
			};
			MousePosition b_down{
			   {m_nGameID == GOC_RgLosFrootos ? RgLosFrootos_MP_betdown_RT_x_reel : RgPharosGoldBase_MP_betdown_RT_x_reel, m_nGameID == GOC_RgLosFrootos ? RgLosFrootos_MP_betdown_RT_x_pos : RgPharosGoldBase_MP_betdown_RT_x_pos},
			   {m_nGameID == GOC_RgLosFrootos ? RgLosFrootos_MP_betdown_RT_y_row : RgPharosGoldBase_MP_betdown_RT_y_row, m_nGameID == GOC_RgLosFrootos ? RgLosFrootos_MP_betdown_RT_y_pos : RgPharosGoldBase_MP_betdown_RT_y_pos}
			};
			MousePosition a_close{
			   {m_nGameID == GOC_RgLosFrootos ? RgLosFrootos_MP_close_LB_x_reel : RgPharosGoldBase_MP_close_LB_x_reel, m_nGameID == GOC_RgLosFrootos ? RgLosFrootos_MP_close_LB_x_pos : RgPharosGoldBase_MP_close_LB_x_pos},
			   {m_nGameID == GOC_RgLosFrootos ? RgLosFrootos_MP_close_LB_y_row : RgPharosGoldBase_MP_close_LB_y_row, m_nGameID == GOC_RgLosFrootos ? RgLosFrootos_MP_close_LB_y_pos : RgPharosGoldBase_MP_close_LB_y_pos}
			};
			MousePosition b_close{
			   {m_nGameID == GOC_RgLosFrootos ? RgLosFrootos_MP_close_RT_x_reel : RgPharosGoldBase_MP_close_RT_x_reel, m_nGameID == GOC_RgLosFrootos ? RgLosFrootos_MP_close_RT_x_pos : RgPharosGoldBase_MP_close_RT_x_pos},
			   {m_nGameID == GOC_RgLosFrootos ? RgLosFrootos_MP_close_RT_y_row : RgPharosGoldBase_MP_close_RT_y_row, m_nGameID == GOC_RgLosFrootos ? RgLosFrootos_MP_close_RT_y_pos : RgPharosGoldBase_MP_close_RT_y_pos}
			};
			MousePosition a_go{
			   {m_nGameID == GOC_RgLosFrootos ? RgLosFrootos_MP_go_LB_x_reel : RgPharosGoldBase_MP_go_LB_x_reel, m_nGameID == GOC_RgLosFrootos ? RgLosFrootos_MP_go_LB_x_pos : RgPharosGoldBase_MP_go_LB_x_pos},
			   {m_nGameID == GOC_RgLosFrootos ? RgLosFrootos_MP_go_LB_y_row : RgPharosGoldBase_MP_go_LB_y_row, m_nGameID == GOC_RgLosFrootos ? RgLosFrootos_MP_go_LB_y_pos : RgPharosGoldBase_MP_go_LB_y_pos}
			};
			MousePosition b_go{
			   {m_nGameID == GOC_RgLosFrootos ? RgLosFrootos_MP_go_RT_x_reel : RgPharosGoldBase_MP_go_RT_x_reel, m_nGameID == GOC_RgLosFrootos ? RgLosFrootos_MP_go_RT_x_pos : RgPharosGoldBase_MP_go_RT_x_pos},
			   {m_nGameID == GOC_RgLosFrootos ? RgLosFrootos_MP_go_RT_y_row : RgPharosGoldBase_MP_go_RT_y_row, m_nGameID == GOC_RgLosFrootos ? RgLosFrootos_MP_go_RT_y_pos : RgPharosGoldBase_MP_go_RT_y_pos}
			};

			if (IsMouseWithin(p, a_go, b_go)) {
				HideMultiGoAndStart();
				return;
			}
			if (IsMouseWithin(p, a_close, b_close)) {
				HideMultiGoAndNormal(tick);
				return;				
			}
			if (IsMouseWithin(p, a_up, b_up)) {
				myVector<InterruptPacketData> IntPackets = g_ReelGame->BetUpMultiGo(m_nBonusBit.coin);
				for (int i = 0; i < IntPackets.size(); i++) {
					tick += AT(IntPackets, i).preDelay;
					ACTION_PACKET_VEC(tick, AT(IntPackets, i).data);
					tick += AT(IntPackets, i).postDelay;
				}
				DisplayMoney(tick, BONUS_BIT_GOC, m_nBonusBit.coin, 0);

				++StateMachine::g_rtpGeneration;  //for cancellation previous CalcRTP
				CalcRTP(FALSE, StateMachine::g_rtpGeneration.load());
				return;
			}
			if (IsMouseWithin(p, a_down, b_down)) {
				myVector<InterruptPacketData> IntPackets = g_ReelGame->BetDownMultiGo(m_nBonusBit.coin);
				for (int i = 0; i < IntPackets.size(); i++) {
					tick += AT(IntPackets, i).preDelay;
					ACTION_PACKET_VEC(tick, AT(IntPackets, i).data);
					tick += AT(IntPackets, i).postDelay;
				}
				DisplayMoney(tick, BONUS_BIT_GOC, m_nBonusBit.coin, 0);
				++StateMachine::g_rtpGeneration;  //for cancellation previous CalcRTP
				CalcRTP(FALSE, StateMachine::g_rtpGeneration.load());
				return;
			}
		}
		return;
	}
	{
		myVector<InterruptPacketData> IntPackets;
		if (m_nGameID == GOC_RgIndianRuby ||
			m_nGameID == GOC_RgBookOfFire ||
			m_nGameID == GOC_RgConvertusAurum ||
			m_nGameID == GOC_RgEyeOfHorus ||
			m_nGameID == GOC_RgGongHei ||
			m_nGameID == GOC_RgKongsTemple ||
			m_nGameID == GOC_RgMagicMirrorDeluxe2 ||
			m_nGameID == GOC_RgMultiSevenWild ||
			m_nGameID == GOC_RgPyramidsDeluxe ||
			m_nGameID == GOC_RgTotemChiefPlus ||
			m_nGameID == GOC_RgDoubleBook
			) {
			if (GetStatus() == STATUS_PendingSpin && m_bFreeMode == FALSE) {
				IntPackets = g_ReelGame->MousePressed(p);

			}
		}

		for (int i = 0; i < IntPackets.size(); i++) {
			tick += AT(IntPackets, i).preDelay;
			ACTION_PACKET_VEC(tick, AT(IntPackets, i).data);
			tick += AT(IntPackets, i).postDelay;
		}
		if (IntPackets.size() > 0) {
			PlayDB::GetInstance().SaveCheckPoint(g_ReelGame->GetGameName(), AT(g_ReelGame->Bets(), g_ReelGame->BetStep()),
				m_nGameID == GOC_RgDoubleBook ? g_ReelGame->GameMode() : g_ReelGame->WinLine(),
				g_ReelGame->CheckPoint());

			++StateMachine::g_rtpGeneration;  //for cancellation previous CalcRTP

			StateMachineCmd cmd;
			cmd.cmd = CMD_CalcRTP;
			cmd.at = tick;
			ACTION_PUSH_BACK(cmd);
		}
	}
}

void StateMachine::LOCK_CMD_VEC() {
	LOCK_MUTEX(m_vecCmdMutex);
}

void StateMachine::UNLOCK_CMD_VEC() {
	UNLOCK_MUTEX(m_vecCmdMutex);
}


myVector<StateMachineCmd>& StateMachine::GetCmdVec() {
	return m_vecCmd;
}

myVector<StateMachineCmd>& StateMachine::GetActionVec() {
	return m_vecAction;
}

UINT64 gPrevTick = current_time_ms();
std::atomic<int> StateMachine::g_rtpGeneration{0};

void StateMachine::Loop() {
	if (m_bLoopGuard) {		
		return;
	}
	m_bLoopGuard = TRUE;
	// License modal only in lobby so gameplay / bonus / risiko are not interrupted.
	if (GetStatus() == STATUS_Lobby)
		TimeLicense::PollLicenseDialogQueue();
	KomProtocol* pKom = CryptoCard::GetInstance().GetKomProtocol();
	UINT64 tick = current_time_ms();
	UINT64 delta = tick - gPrevTick;
	gPrevTick = tick;
	
	// swap card gamble led: black, red
	if (m_CardGamble.bOpen && m_CardGamble.bSwapEnable) {
		m_CardGamble.nLedSwapInterval_ms += delta;
		if (m_CardGamble.nLedSwapInterval_ms >= 300) {
			m_CardGamble.nLedSwapInterval_ms = 0;
			m_CardGamble.bRedActive = !m_CardGamble.bRedActive;

			ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0xa1, 0x52, 0x6f,
				static_cast<BYTE>(m_CardGamble.bRedActive), 0x04);
		}
	}

	{
		if (m_Risiko.bOpen ) {
			if (m_Risiko.bUpgrading) {
				m_Risiko.nUpgradingWarmup -= delta;
				if (m_Risiko.nUpgradingWarmup <= 0) {
					m_Risiko.bUpgrading = FALSE;
				}
			}
			if (m_Risiko.bOpening) {
				m_Risiko.nOpeningWarmup -= delta;
				if (m_Risiko.nOpeningWarmup <= 0) {
					m_Risiko.bOpening = FALSE;
				}
			}
		}		
	}

	if (GetStatus() == STATUS_SpinRunning) {
		m_nSpinWDT += delta;
		if (m_nSpinWDT >= (m_nGameID == GOC_RgIndianRuby ? 50000 : 10000)) {
			CHANGE_STATUS(STATUS_PendingSpin);
			Spin();
		}
	}
	else {
		m_nSpinWDT = 0;
	}
	if (m_nStatus.load() == STATUS_WaitActionBonusSound) {
		if (tick >= m_atStopWaitAction_40s) {
			Spin();
			m_bLoopGuard = FALSE;
			return;
		}
	}
	else if (m_nStatus.load() == STATUS_RisikoAss) {
		if (tick >= m_atRisikoAssFinish) {
			CHANGE_STATUS(STATUS_Risiko);
			m_bLoopGuard = FALSE;
			return;
		}
	}
	else if (m_nStatus.load() == STATUS_PlayingBonusSound) {
		if (tick >= m_atStopBonusSound) {
			StopPlayingBonusSound();
		}
	}
	else if (m_nStatus.load() == STATUS_PendingSpin) {
		if (tick >= m_atAutoReturnToMenu && m_bAutoSpin == FALSE && m_bHalfAutoSpin == FALSE && m_CardGamble.bOpen == FALSE && m_Risiko.bOpen == FALSE && m_bMultoGo == FALSE && m_bFreeMode == FALSE) {
			// set kom status
			pKom->ReturnToMenu();
		}
	}	
	// RgDragons
	else if (m_nStatus.load() == STATUS_PenddingWaitMouseAction) {
		if (tick >= m_atCanMouseAction) {
			CHANGE_STATUS(STATUS_WaitMouseAction);
			m_bLoopGuard = FALSE;
			return;
		}
	}
	else if (m_nStatus.load() == STATUS_MovingSymbol) {
		if (tick >= m_atMovingFinished) {			
			ACTION_PACKET(tick + 1000, 0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0xb7, 0x17, 0x02, 0x00, 0x04);
			CHANGE_STATUS(STATUS_PendingSpin);
			m_bLoopGuard = FALSE;
			return;
		}
	}
	// <-- RgDragons
	else if (m_nStatus.load() == STATUS_PendingMultiGo) {
		if (tick >= m_atAutoNormalInMultigo) {
			HideMultiGoAndNormal(tick);
			m_bLoopGuard = FALSE;
			return;
		}
	}	

	LOCK_MUTEX(this->m_vecActionMutex);
	if (this->m_vecAction.size() > 0) {
		if (tick >= AT(m_vecAction, 0).at) {
			BOOL done = FALSE;
			if (AT(this->m_vecAction, 0).cmd == CMD_SendPacket) {
				pKom->MakePacket(AT(this->m_vecAction, 0).o.st_SendPacket.data, AT(this->m_vecAction, 0).o.st_SendPacket.len);
				done = TRUE;
			}
			else if (AT(this->m_vecAction, 0).cmd == CMD_SetSatus) {
				int newStatus = AT(this->m_vecAction, 0).o.st_SetStatus.status;
				UNLOCK_MUTEX(this->m_vecActionMutex);
				SetStatus(newStatus);
				if (newStatus == STATUS_SpinRunning || newStatus == STATUS_LoadingContents) {
					if (m_bFreeMode || m_nGameID == GOC_RgKeyOfTheNile) {
					}
					else {
						CalcRTP(FALSE, StateMachine::g_rtpGeneration.load());
					}
				}
				LOCK_MUTEX(this->m_vecActionMutex);
				done = TRUE;
			}
			else if (AT(this->m_vecAction, 0).cmd == CMD_SetSatusAndResetRsk) {
				int newStatus = AT(this->m_vecAction, 0).o.st_SetStatus.status;
				UNLOCK_MUTEX(this->m_vecActionMutex);
				SetStatus(newStatus);
				rsk_init();
				LOCK_MUTEX(this->m_vecActionMutex);
				done = TRUE;
			}
			else if (AT(this->m_vecAction, 0).cmd == CMD_SetSatusAndResetCg) {
				int newStatus = AT(this->m_vecAction, 0).o.st_SetStatus.status;
				UNLOCK_MUTEX(this->m_vecActionMutex);
				SetStatus(newStatus);
				cg_init();
				LOCK_MUTEX(this->m_vecActionMutex);
				done = TRUE;
			}
			else if (AT(this->m_vecAction, 0).cmd == CMD_CardGambleSwapEnable) {
				m_CardGamble.bSwapEnable = AT(this->m_vecAction, 0).o.st_CardGambleSwapEnable.enable;
				done = TRUE;
			}
			else if (AT(this->m_vecAction, 0).cmd == CMD_CalcRTP) {
				UNLOCK_MUTEX(this->m_vecActionMutex);
				if (m_bFreeMode || m_nGameID == GOC_RgKeyOfTheNile) {
				}
				else {
					DebugPrintf("FAST Next g_rtpGeneration loaded %d", StateMachine::g_rtpGeneration.load());
					CalcRTP(FALSE, StateMachine::g_rtpGeneration.load());
				}
				LOCK_MUTEX(this->m_vecActionMutex);
				done = TRUE;
			}
			else if (AT(this->m_vecAction, 0).cmd == CMD_FinishCardGamble) {
				this->m_vecAction.erase(this->m_vecAction.begin());
				UNLOCK_MUTEX(this->m_vecActionMutex);

				MoveBonus(tick, m_nBonusBit.coin, FALSE);
				// close
				ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0xa1, 0x52, 0x70, 0x00, 0x04);
				// set status
				StateMachineCmd setStatusCmd;
				setStatusCmd.cmd = CMD_SetSatusAndResetCg;
				setStatusCmd.at = tick;
				setStatusCmd.o.st_SetStatus.status = STATUS_PendingSpin;
				ACTION_PUSH_BACK(setStatusCmd);
				m_atAutoReturnToMenu = tick + AUTO_RETURN_TO_MENU_TIME;

				LOCK_MUTEX(this->m_vecActionMutex);
			}
			else if (AT(this->m_vecAction, 0).cmd == CMD_FinishRisiko) {
				this->m_vecAction.erase(this->m_vecAction.begin());
				UNLOCK_MUTEX(this->m_vecActionMutex);

				MoveBonus(tick, m_nBonusBit.coin, FALSE);
				// close risiko
				ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0xb1, 0x52, 0x68, 0x00, 0x04);
				//m_Risiko.bOpen = FALSE;
				StateMachineCmd setStatusCmd;
				setStatusCmd.cmd = CMD_SetSatusAndResetRsk;
				setStatusCmd.at = tick;
				setStatusCmd.o.st_SetStatus.status = STATUS_PendingSpin;
				ACTION_PUSH_BACK(setStatusCmd);
				m_atAutoReturnToMenu = tick + AUTO_RETURN_TO_MENU_TIME;

				LOCK_MUTEX(this->m_vecActionMutex);
			}
			else if (AT(this->m_vecAction, 0).cmd == CMD_UpdateBankBit) {
				BYTE data[] = {
					0x01, 0x02, 0x2C, 0x00,
					static_cast<BYTE>(BANK_BIT_GOC & 0xFF), static_cast<BYTE>((BANK_BIT_GOC >> 8) & 0xFF),
					static_cast<BYTE>(m_nBankBit & 0xFF),
					static_cast<BYTE>((m_nBankBit >> 8) & 0xFF),
					static_cast<BYTE>((m_nBankBit >> 16) & 0xFF),
					static_cast<BYTE>((m_nBankBit >> 24) & 0xFF),
					0x00, 0x00,
					0x00, 0x00, 0x01,
					0x04
				};
				KomProtocol* pKom = CryptoCard::GetInstance().GetKomProtocol();
				pKom->MakePacket(data, sizeof(data));
				done = TRUE;
			}
			else if (AT(this->m_vecAction, 0).cmd == CMD_SaveCheckPointOfAG) {
				int n = AT(this->m_vecAction, 0).o.st_SaveCheckPointOfAG.remain;
				// save checkpoint of action game
				PlayDB::GetInstance().SaveCheckPoint(g_ReelGame->GetGameName(), AT(g_ReelGame->Bets(), g_ReelGame->BetStep()),
					m_nGameID == GOC_RgDoubleBook ? g_ReelGame->GameMode() : g_ReelGame->WinLine(),
					g_ReelGame->CheckPoint() + (n > 0 ? std::string(" A") + std::to_string(n) : ""));

				done = TRUE;
			}
			else if (AT(this->m_vecAction, 0).cmd == CMD_UpdateMagicBit) {
				//m_nBankBit += 1000;
				UpdateBankBitInGame(1000);
				BYTE data[] = {
					0x01, 0x02, 0x2C, 0x00,
					static_cast<BYTE>(BANK_BIT_GOC & 0xFF), static_cast<BYTE>((BANK_BIT_GOC >> 8) & 0xFF),
					static_cast<BYTE>(m_nBankBit & 0xFF),
					static_cast<BYTE>((m_nBankBit >> 8) & 0xFF),
					static_cast<BYTE>((m_nBankBit >> 16) & 0xFF),
					static_cast<BYTE>((m_nBankBit >> 24) & 0xFF),
					0x00, 0x00,
					0x00, 0x00, 0x01,
					0x04
				};
				KomProtocol* pKom = CryptoCard::GetInstance().GetKomProtocol();
				pKom->MakePacket(data, sizeof(data));
				done = TRUE;
			}
			if (done) {
				this->m_vecAction.erase(this->m_vecAction.begin());
			}
		}
	}
	UNLOCK_MUTEX(this->m_vecActionMutex);
	// check command vector
	LOCK_CMD_VEC();
	BOOL done = TRUE;
	if (m_vecCmd.size() == 0) {
		goto CONT;
	}

	// charge credit
	switch (AT(m_vecCmd, 0).cmd) {
	case CMD_ChargeCredit:
		ChargeCredit_pkt(AT(m_vecCmd, 0).o.st_ChargeCredit.amount);
		break;
	case CMD_BetUp:
		BetUp_pkt();
		break;
	case CMD_MaxBet:
		MaxBet_pkt();
		break;
	case CMD_ReturnToMenu:
		ReturnToMenu_pkt();		
		break;	
	default:
		done = FALSE;
	}

	if (done) {
		m_vecCmd.erase(m_vecCmd.begin());
		if (m_vecCmd.size() == 0) {
			goto CONT;
		}
	}

	if (GetStatus() == STATUS_InitGame) {
		if (AT(m_vecCmd, 0).cmd != CMD_RunGame) {
			goto CONT;
		}
		UINT16 GameID = AT(m_vecCmd, 0).o.st_RunGame.gameId;
		m_vecCmd.erase(m_vecCmd.begin());
		RunGame_pkt(GameID);
	}
CONT:
	UNLOCK_CMD_VEC();
	Sleep(2);
	m_bLoopGuard = FALSE;
}

void StateMachine::ReadData(BYTE* data, int pReadSize) {
	if (GetStatus() == STATUS_LoadingContents) {
		BYTE expectedData[4] = { 0x02, 0x01, 0x00, 0x00 };

		expectedData[2] = static_cast<BYTE>(m_nGameID & 0xFF);
		expectedData[3] = static_cast<BYTE>((m_nGameID >> 8) & 0xFF);
		if (memcmp(expectedData, data, sizeof(expectedData)) == 0) {
			PostGameStartEvent();
		}
		else {
			expectedData[1] = 0x02;
			if (memcmp(expectedData, data, sizeof(expectedData)) == 0) {
				PostGameStartEvent();
			}
		}
	}
	else if (GetStatus() == STATUS_SpinRunning) {
		BYTE expectedData[4] = { 0x02, 0x01, 0x00, 0x00 };

		expectedData[2] = static_cast<BYTE>(m_nGameID & 0xFF);
		expectedData[3] = static_cast<BYTE>((m_nGameID >> 8) & 0xFF);
		if (memcmp(expectedData, data, 4) == 0 && pReadSize == 4) {
			if (m_nGameID == GOC_RgKeyOfTheNile) {
				if ((current_time_ms() - m_nSpinStartTick) >= 200) {
					SpinPost();
				}
			}
			else {
				SpinPost();
			}
		}
		else {
			// dont work in RgKeyOfTheNile
			/*expectedData[0] = 0x06;
			expectedData[1] = static_cast<BYTE>(m_nGameID & 0xFF);
			expectedData[2] = static_cast<BYTE>((m_nGameID >> 8) & 0xFF);
			if (memcmp(expectedData, data, 3) == 0) {
				SpinPost();
			}*/
		}
	}
}

// Magic Game
void StateMachine::EnterMagicGame() {
	PlayDB::GetInstance().SaveCheckPoint(g_ReelGame->GetGameName(), AT(g_ReelGame->Bets(), g_ReelGame->BetStep()),
		m_nGameID == GOC_RgDoubleBook ? g_ReelGame->GameMode() : g_ReelGame->WinLine(),
		g_ReelGame->CheckPoint() + std::string(" A") + std::to_string(m_nMagicCount));

	UINT64 tick = current_time_ms();

	SetStatus(STATUS_MagicGame);
	StopAllSound(tick);
	// sometimes, buttons not show
	tick += 100;
	if (m_nBonusBit.coin) {
		tick += 400;
		MoveBonus(tick, m_nBonusBit.coin, TRUE);
	}
	UINT32 bonus = m_nMagicCount * 1000;
	// show magic menu
	ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x0d, 0x00, 0x25, 0x53, 0x7a, 0x00, 0x00, 0x00, 0x00, 0x00,
		static_cast<BYTE>(m_nMagicCount & 0xFF), static_cast<BYTE>((m_nMagicCount >> 8) & 0xFF),
		0x00, 0x00, 
		static_cast<BYTE>(bonus & 0xFF), 
		static_cast<BYTE>((bonus >> 8) & 0xFF),
		static_cast<BYTE>((bonus >> 16) & 0xFF),
		static_cast<BYTE>((bonus >> 24) & 0xFF),		
		0x04);
}

void StateMachine::TakeMagicBonus() {
	PlayDB::GetInstance().SaveCheckPoint(g_ReelGame->GetGameName(), AT(g_ReelGame->Bets(), g_ReelGame->BetStep()),
		m_nGameID == GOC_RgDoubleBook ? g_ReelGame->GameMode() : g_ReelGame->WinLine(),
		g_ReelGame->CheckPoint());

	UINT64 tick = current_time_ms();
	UINT32 erfolg = m_nMagicCount * 1000;
	DisplayMoney(tick, BONUS_BIT_GOC, erfolg, 0);
	// hide latest erfolg label
	SetVisibleByGOC(tick, LATEST_LABEL_GOC, FALSE);
	// 23880
	// selected button
	ACTION_PACKET(tick, 0x01, 0x02, 0x28, 0x00, 0x49, 0x5d, 0x00, 0x00, 0x01, 0x00, 0x04);
	tick += 1000;
	// hide menu
	ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x00, 0x00, 0x25, 0x53, 0x7b, 0x04);
	if (m_bFreeMode) {

	}
	else {
		tick += 300;
		MoveBonus(tick, erfolg, FALSE);

		StateMachineCmd setStatusCmd;
		setStatusCmd.cmd = CMD_SetSatus;
		setStatusCmd.at = tick;
		setStatusCmd.o.st_SetStatus.status = STATUS_PendingSpin;
		ACTION_PUSH_BACK(setStatusCmd);
		m_atAutoReturnToMenu = tick + AUTO_RETURN_TO_MENU_TIME;
	}
}

void StateMachine::GoMagicGame() {
	UINT64 tick = current_time_ms();
	// select ag button
	ACTION_PACKET(tick, 0x01, 0x02, 0x28, 0x00, 0x49, 0x5d, 0x00, 0x00, 0x00, 0x00, 0x04);
	tick += 1000;
	// win lines
	ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x01, 0x00, static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF), 0x02, 0x00, 0x04);
	// hide menu
	ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x00, 0x00, 0x25, 0x53, 0x7b, 0x04);
	// remove winlines
	ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0x6f, 0x11, 0x02, 0x00, 0x04);
	// show ag game
	ACTION_PACKET(tick, 0x01, 0x02, 0x30, 0x00, 0x25, 0x53, 0x03, 0x00, 
		static_cast<BYTE>(m_nMagicCount & 0xFF), static_cast<BYTE>((m_nMagicCount >> 8) & 0xFF), 
		0x00, 0x00, 0x00, 0x00, 0x76, 0x04);
	tick += 2000;

	OneMonitorManipulation::GetInstance().ShowMirrorWindow();

	int magicBonus[] = { 7, 1000, 1000, 0, 1000, 1000, 1000, 1000, 0, 1000, 1000, 1000, 0, 1000, 1000 };
	while (m_nMagicCount) {
		UINT8 idx = (myRandom() % (sizeof(magicBonus) / sizeof(magicBonus[0])));
		// go
		ACTION_PACKET(tick, 01, 0x02, 0x30, 0x00, 0x42, 0x5D, idx, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x78, 0x04);
		tick += 2200;
		
		m_nMagicCount--;
		if (magicBonus[idx] == 7) { // +7
			m_nMagicCount += 7;
			tick += 1600;
		}
		else if (magicBonus[idx] == 1000) {
			// hide latest erfolg label
			SetVisibleByGOC(tick, LATEST_LABEL_GOC, FALSE);
			DisplayMoney(tick, BONUS_BIT_GOC, 1000, 0); tick += 400;
			// add 1000
			StateMachineCmd cmd;
			cmd.cmd = CMD_UpdateMagicBit;
			cmd.at = tick;
			ACTION_PUSH_BACK(cmd);
		}
		else {
		}
		{
			// save checkpoint
			StateMachineCmd cmd;
			cmd.cmd = CMD_SaveCheckPointOfAG;
			cmd.o.st_SaveCheckPointOfAG.remain = m_nMagicCount;
			cmd.at = tick;
			ACTION_PUSH_BACK(cmd);
		}
		

		// show count
		ACTION_PACKET(tick, 0x01, 0x02, 0x30, 0x00, 0x25, 0x53, 0x01, 0x00,
			static_cast<BYTE>(m_nMagicCount & 0xFF), static_cast<BYTE>((m_nMagicCount >> 8) & 0xFF),
			0x00, 0x00, 0x00, 0x00, 0x76, 0x04);
	}

	ACTION_PACKET(tick, 0x01, 0x02, 0x30, 0x00, 0x25, 0x53, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x77, 0x04);
	tick += 2000;

	StateMachineCmd setStatusCmd;
	setStatusCmd.cmd = CMD_SetSatus;
	setStatusCmd.at = tick;
	setStatusCmd.o.st_SetStatus.status = STATUS_PendingSpin;
	ACTION_PUSH_BACK(setStatusCmd);
	m_atAutoReturnToMenu = tick + AUTO_RETURN_TO_MENU_TIME;
}

// Card Gamble
void StateMachine::SelectRandomCard(BOOL pointing, BOOL redCard) {
	const size_t totalCards = sizeof(gGambleCards) / sizeof(gGambleCards[0]);
	while (1) {
		UINT8 cardIndex = myRandom() % totalCards;
		UINT8 selectedCard = gGambleCards[cardIndex];

		BOOL isRed = ((selectedCard & 0xF0) == 0x10 || (selectedCard & 0xF0) == 0x20);
		if (pointing && isRed != redCard) {
			continue;
		}
		if (std::find(m_CardGamble.vSelectedCards.begin(), m_CardGamble.vSelectedCards.end(), selectedCard) != m_CardGamble.vSelectedCards.end()) {
			continue;
		}
		m_CardGamble.vSelectedCards.push_back(selectedCard);
		break;
	}
}

void StateMachine::cg_init() {
	m_CardGamble.bOpen = FALSE;
	m_CardGamble.bFinished = FALSE;
	m_CardGamble.bHighest = FALSE;

	m_CardGamble.bRedActive = FALSE;
	m_CardGamble.nRisikoLevel = 0;
	m_CardGamble.nRisikoErfolg = 0;
	m_CardGamble.nRisikoSpitze = 14000;
	m_CardGamble.nLedSwapInterval_ms = 0;
	m_CardGamble.bSwapEnable = FALSE;
	m_CardGamble.vSelectedCards.clear();
	for (int i = 0; i < 6; i++) {
		SelectRandomCard(FALSE, FALSE);
	}
}

void StateMachine::cg_open(BOOL force) {
	UINT64 tick = current_time_ms();
	if (force == FALSE) {
		if (m_CardGamble.bOpen || m_Risiko.bOpen) {
			return;
		}
		if (m_nBonusBit.coin == 0/* || m_nBonusBit.coin >= 14000 */) {
			return;
		}
		if (m_bAutoSpin || m_bHalfAutoSpin) {
			return;
		}
		
		if (m_nStatus.load() != STATUS_PlayingBonusSound && m_nStatus.load() != STATUS_WaitActionBonusSound) {
			return;
		}
		if (m_bFreeMode || g_ReelGame->CanFreeMode()) {
			return;
		}
	}
	auto IntPackets = g_ReelGame->InterruptBeforeRisiko();
	for (int i = 0; i < IntPackets.size(); i++) {
		tick += AT(IntPackets, i).preDelay;
		ACTION_PACKET_VEC(tick, AT(IntPackets, i).data);
		tick += AT(IntPackets, i).postDelay;
	}

	cg_init();

	m_CardGamble.bOpen = TRUE;
	m_CardGamble.nRisikoLevel = m_nBonusBit.coin > 4000 ? 4000 : m_nBonusBit.coin;
	m_CardGamble.nRisikoErfolg = m_CardGamble.nRisikoLevel == 4000 ? 14000 : 2 * m_CardGamble.nRisikoLevel;
	
	CHANGE_STATUS(STATUS_Risiko);
	StopAllSound(tick);	
	ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 
		static_cast<BYTE>(m_nGameID & 0xFF), static_cast<BYTE>((m_nGameID >> 8) & 0xFF),
		0x02, 0x01, 0x04);

	// 0x24, 0x2b, 0x46, 0x8e, 0x2e, 0x2d
	int n = m_CardGamble.vSelectedCards.size();
	ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x0d, 0x00, 0xa1, 0x52, 0x6b, 
		AT(m_CardGamble.vSelectedCards, n - 6),
		AT(m_CardGamble.vSelectedCards, n - 5),
		AT(m_CardGamble.vSelectedCards, n - 4),
		AT(m_CardGamble.vSelectedCards, n - 3),
		AT(m_CardGamble.vSelectedCards, n - 2),
		AT(m_CardGamble.vSelectedCards, n - 1),
		0xb0, 0x36, 
		static_cast<BYTE>(m_CardGamble.nRisikoErfolg & 0xFF), static_cast<BYTE>((m_CardGamble.nRisikoErfolg >> 8) & 0xFF),
		static_cast<BYTE>(m_CardGamble.nRisikoLevel & 0xFF), static_cast<BYTE>((m_CardGamble.nRisikoLevel >> 8) & 0xFF),
		0x01, 0x04);

	// move rest
	cg_moveRestErfolg(tick);

	if (m_CardGamble.nRisikoLevel <= 20) {
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0xa1, 0x52, 0x71, 0x00, 0x04);
	}

	StateMachineCmd cmd;
	cmd.cmd = CMD_CardGambleSwapEnable;
	cmd.at = tick;
	cmd.o.st_CardGambleSwapEnable.enable = TRUE;
	ACTION_PUSH_BACK(cmd);
}

void StateMachine::AddRisikoStepThreshold(UINT32 level, int& threshold)
{
	static const UINT32 kRisikoTiers[] = { 30, 60, 120, 240, 400, 800, 1200, 2000, 3200, 5200, 8400, 14000, 18000, 22000, 26000 };
	static const int kRisikoDeltas[] = { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2 };
	const size_t n = sizeof(kRisikoTiers) / sizeof(kRisikoTiers[0]);
	for (size_t i = 0; i < n; ++i) {
		if (level >= kRisikoTiers[i]) {
			threshold += kRisikoDeltas[i];
		}
	}
}

void StateMachine::cg_go(BOOL red) {
	UINT64 tick = current_time_ms();
	if (m_CardGamble.bFinished) {
		return;
	}
	if (m_CardGamble.bSwapEnable == FALSE) { // opening new card;
		return;
	}
	
	bool matched = false;
	// Variant -->
	// Compute current RTP (Return to Player) safely
	double currentRTP = 0.0;
	float mainPlayedPointsF = 0.0f;
	float mainWonPointsF = 0.0f;
	double currentBet = gTotalBet.load();
	double currentWin = gTotalWin.load();
	if (currentBet > 0.0) {
		currentRTP = currentWin / currentBet;
	}
	else {
		// Edge case — no bets placed yet
		currentRTP = 0.0;
	}

	// Generate a single random value for probability checks
	int randomValue = myRandom() % 100;
	//int threshold = static_cast<int>(std::lround((1.0 - VARIANT_A) * 100.0));
	int threshold = 50;
	
	if (currentRTP > gTargetRTP) {
		// Dynamic RTP-gap penalty: larger (currentRTP - gTargetRTP) => harder gamble match.
		double rtpGap = currentRTP - gTargetRTP;
		int gapPenalty = static_cast<int>(rtpGap * 100.0 * 1); // +1 threshold per +1% RTP gap
		if (gapPenalty < 0) gapPenalty = 0;
		const int variantPenalty = static_cast<int>(std::lround(15.0 - 10.0 * gTargetRTP)); // 0.7->8, 0.5->10, 0.3->12
		threshold += variantPenalty + gapPenalty;
	}

	// Step-based tightening: keep low steps fun, tighten later.
	AddRisikoStepThreshold(m_CardGamble.nRisikoLevel, threshold);
	threshold = (threshold < 0) ? 100 : threshold;
	DebugPrintfT(LogTag::Risiko, "value=%d randomValue=%d threshold=%d currentRTP=%.4f targetRTP=%.4f", m_CardGamble.nRisikoLevel, randomValue, threshold, currentRTP, gTargetRTP);
	if (randomValue >= threshold) {
		matched = true;
	}
	// for test
	// matched = true;
	// <--
	
	BYTE selectedColor = red;
	SelectRandomCard(TRUE, !(matched ^ selectedColor));
	int n = m_CardGamble.vSelectedCards.size();

	// open selected card
	if (m_CardGamble.nRisikoLevel >= 4000 && matched) {
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x08, 0x00, 0xa1, 0x52, 0x6c,
			AT(m_CardGamble.vSelectedCards, n - 1),
			0xb0, 0x36, 0xb0, 0x36, 0xb0, 0x36, 0x01, 0x04);
	}
	else {
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x08, 0x00, 0xa1, 0x52, 0x6d, 
			AT(m_CardGamble.vSelectedCards, n - 1), 
			0xb0, 0x36, 0xa0, 0x0f, 0xa0, 0x0f, matched, 0x04);
	}	
	// disable swap led
	StateMachineCmd cmd;
	cmd.cmd = CMD_CardGambleSwapEnable;
	cmd.at = tick;
	cmd.o.st_CardGambleSwapEnable.enable = FALSE;
	ACTION_PUSH_BACK(cmd);
	// active selected color
	for (int i = 0; i < 10; i++) {
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0xa1, 0x52, 0x6f, selectedColor, 0x04); tick += 60;
	}
	// show selected color with red
	
	if (matched) {
		m_nBonusBit.coin = m_CardGamble.nRisikoErfolg;
		SaveBonusBit(m_nBonusBit.coin);

		// hide latest label
		SetVisibleByGOC(tick, LATEST_LABEL_GOC, FALSE);
		// update bonus erfolg
		DisplayMoney(tick, BONUS_BIT_GOC, m_nBonusBit.coin, 0);
		if (m_CardGamble.nRisikoLevel >= 4000) { // last bet			
			m_CardGamble.bFinished = TRUE;
			m_CardGamble.bHighest = TRUE;

			tick += 27 * 1000;
			StopAllSound(tick);
			// disable black & red leds;
			ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0xa1, 0x52, 0x6f, 0x02, 0x04);
			// disable step
			ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0xa1, 0x52, 0x71, 0x00, 0x04);
			// disable risiko button and play end sounds
			ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x06, 0x00, 0xa1, 0x52, 0x6e, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04);

			StateMachineCmd setStatusCmd;
			setStatusCmd.cmd = CMD_FinishCardGamble;
			setStatusCmd.at = tick;
			ACTION_PUSH_BACK(setStatusCmd);
			/*
			MoveBonus(tick, m_nBonusBit.coin, FALSE);
			// close
			ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0xa1, 0x52, 0x70, 0x00, 0x04);
			// set status
			StateMachineCmd setStatusCmd;
			setStatusCmd.cmd = CMD_SetSatusAndResetCg;
			setStatusCmd.at = tick;
			setStatusCmd.o.st_SetStatus.status = STATUS_PendingSpin;
			ACTION_PUSH_BACK(setStatusCmd);
			m_atAutoReturnToMenu = tick + AUTO_RETURN_TO_MENU_TIME;
			*/
		}
		else {
			m_CardGamble.nRisikoLevel = m_nBonusBit.coin > 4000 ? 4000 : m_nBonusBit.coin;
			m_CardGamble.nRisikoErfolg = m_CardGamble.nRisikoLevel == 4000 ? 14000 : 2 * m_CardGamble.nRisikoLevel;
			cg_moveRestErfolg(tick);

			if (m_CardGamble.nRisikoLevel > 20) {
				ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0xa1, 0x52, 0x71, 0x01, 0x04);
			}
			// show level & erfolg bit for next
			ACTION_PACKET(tick, 0x06, 0xa1, 0x52, 0x01, 0x02, 0x31, 0x00, 0x06, 0x00, 0xa1, 0x52, 0x72, 0xb0, 0x36,
				static_cast<BYTE>(m_CardGamble.nRisikoErfolg & 0xFF), static_cast<BYTE>((m_CardGamble.nRisikoErfolg >> 8) & 0xFF),
				static_cast<BYTE>(m_CardGamble.nRisikoLevel & 0xFF), static_cast<BYTE>((m_CardGamble.nRisikoLevel >> 8) & 0xFF),
				0x04);
			// enable swap led
			cmd.at = tick;
			cmd.o.st_CardGambleSwapEnable.enable = TRUE;
			ACTION_PUSH_BACK(cmd);
		}
	}
	else {
		CHANGE_STATUS(STATUS_TerminatingRisiko);

		tick += 1000;
		m_CardGamble.bOpen = FALSE;
		m_CardGamble.bFinished = TRUE;
		// hide latest label
		SetVisibleByGOC(tick, LATEST_LABEL_GOC, FALSE);
		// hide bonus
		SetVisibleByGOC(tick, BONUS_BIT_GOC, FALSE);
		// close
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0xa1, 0x52, 0x70, 0x00, 0x04);
		// set status
		StateMachineCmd setStatusCmd;
		setStatusCmd.cmd = CMD_SetSatus;
		setStatusCmd.at = tick;
		setStatusCmd.o.st_SetStatus.status = STATUS_PendingSpin;
		ACTION_PUSH_BACK(setStatusCmd);
		m_atAutoReturnToMenu = tick + AUTO_RETURN_TO_MENU_TIME;
	}
}

void StateMachine::cg_takeBonusAndExit() {
	if (m_nStatus.load() != STATUS_Risiko) {
		return;
	}
	if (m_CardGamble.bOpen == TRUE && ((m_CardGamble.bFinished == FALSE && m_CardGamble.bSwapEnable == TRUE) || (m_CardGamble.bFinished == TRUE && m_CardGamble.bHighest == TRUE))) {
		CHANGE_STATUS(STATUS_TerminatingRisiko);

		cg_init();

		UINT64 tick = current_time_ms();
		StopAllSound(tick);
		// disable black & red leds;
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0xa1, 0x52, 0x6f, 0x02, 0x04);
		// disable step
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0xa1, 0x52, 0x71, 0x00, 0x04);
		// disable risiko button and play end sounds
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x06, 0x00, 0xa1, 0x52, 0x6e, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04);
		MoveBonus(tick, m_nBonusBit.coin, FALSE);
		// close
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0xa1, 0x52, 0x70, 0x00, 0x04);
		// set status
		StateMachineCmd setStatusCmd;
		setStatusCmd.cmd = CMD_SetSatus;
		setStatusCmd.at = tick;
		setStatusCmd.o.st_SetStatus.status = STATUS_PendingSpin;
		ACTION_PUSH_BACK(setStatusCmd);
		m_atAutoReturnToMenu = tick + AUTO_RETURN_TO_MENU_TIME;

	}
}

void StateMachine::cg_moveRestErfolg(UINT64 tick) {
	// move rest
	if (m_nBonusBit.coin > m_CardGamble.nRisikoLevel) {
		UINT32 delta = m_nBonusBit.coin - m_CardGamble.nRisikoLevel;
		m_nBonusBit.coin = m_CardGamble.nRisikoLevel;
		SaveBonusBit(m_nBonusBit.coin);

		//m_nBankBit += delta;
		UpdateBankBitInGame(delta);
		DisplayMoney(tick, BONUS_BIT_GOC, m_nBonusBit.coin, 0);
		DisplayMoney(tick, BANK_BIT_GOC, m_nBankBit, 0);
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x06, 0x00, 0xa1, 0x52, 0x6e, 0xb0, 0x36, 
			static_cast<BYTE>(m_CardGamble.nRisikoErfolg & 0xFF), static_cast<BYTE>((m_CardGamble.nRisikoErfolg >> 8) & 0xFF),
			static_cast<BYTE>(m_CardGamble.nRisikoLevel & 0xFF), static_cast<BYTE>((m_CardGamble.nRisikoLevel >> 8) & 0xFF), 0x04);
		// show level & erfolg bit for next
		/*ACTION_PACKET(tick, 0x06, 0xa1, 0x52, 0x01, 0x02, 0x31, 0x00, 0x06, 0x00, 0xa1, 0x52, 0x72, 0xb0, 0x36,
			static_cast<BYTE>(m_CardGamble.nRisikoErfolg & 0xFF), static_cast<BYTE>((m_CardGamble.nRisikoErfolg >> 8) & 0xFF),
			static_cast<BYTE>(m_CardGamble.nRisikoLevel & 0xFF), static_cast<BYTE>((m_CardGamble.nRisikoLevel >> 8) & 0xFF),
			0x04);*/
	}
}

// Risiko
void StateMachine::rsk_init() {
	m_Risiko.bOpen = FALSE;
	m_Risiko.bFinished = FALSE;
	m_Risiko.bUpgrading = FALSE;
	m_Risiko.bOpening = FALSE;
	m_Risiko.bUpgraded = FALSE;
	m_Risiko.go = 0;
}

UINT16 g_RisikoLevels[] = { 0, 15, 30, 60, 120, 240, 0, 400, 800, 1200, 2000, 3200, 5200, 8400, 14000};
UINT16 g_RisikoLevels_top[] = { 10000, 14000, 18000, 22000, 26000, 30000 };

void StateMachine::rsk_open(BOOL force) {
	UINT64 tick = current_time_ms();
	if (force == FALSE) {
		if (m_Risiko.bOpen || m_CardGamble.bOpen) {
			return;
		}
		if (m_nBonusBit.coin == 0 || m_nBonusBit.coin >= 14000) {
			return;
		}
		if (m_bAutoSpin || m_bHalfAutoSpin) {
			return;
		}
		if (m_nStatus.load() != STATUS_PlayingBonusSound && m_nStatus.load() != STATUS_WaitActionBonusSound) {
			return;
		}
		if (m_bFreeMode || g_ReelGame->CanFreeMode()) {
			return;
		}
	}
	OneMonitorManipulation::GetInstance().AutoSwitchMirrorWindow(m_nBonusBit.coin, FALSE);

	auto IntPackets = g_ReelGame->InterruptBeforeRisiko();
	for (int i = 0; i < IntPackets.size(); i++) {
		tick += AT(IntPackets, i).preDelay;
		ACTION_PACKET_VEC(tick, AT(IntPackets, i).data);
		tick += AT(IntPackets, i).postDelay;
	}

	CHANGE_STATUS(STATUS_Risiko);
	rsk_init();
	m_Risiko.bOpen = TRUE;
	m_Risiko.bOpening = TRUE;
	m_Risiko.nOpeningWarmup = 1000;

	UINT8 top = 0;
	UINT8 bottom = 0;
	BOOL bHalfButton = FALSE;
	for (int i = 0; i < sizeof(g_RisikoLevels) / sizeof(g_RisikoLevels[0]); i++) {
		UINT16 level = (i == 6 ? 400 : g_RisikoLevels[i]);
		if (m_nBonusBit.coin > level) {
			continue;
		}
		else if (m_nBonusBit.coin < level) {
			if (m_nBonusBit.coin > 240 && m_nBonusBit.coin < 400) {
				top = i + 1;
				bottom = i - 1;
			}
			else {
				top = i;
				bottom = i - 1;
			}
		}
		else { // ==
			if (level <= 240) {
				top = i;
				bottom = 0;
			}
			else if (level == 400) {
				top = 7; // 400
				bottom = 0;
			}
			else if (level == 800) {
				top = i;
				bottom = 0;
			}
			else if (level > 800) {
				top = i;
				bottom = 0;
			}
			bHalfButton = TRUE;
		}
		break;
	}
	StopAllSound(tick);
	// stop sunnie
	UINT16 sunnieGOC = SUNNIER_GOC;
	ACTION_PACKET(tick, 0x01, 0x02, 0x29, 0x00, static_cast<BYTE>(sunnieGOC & 0xFF), static_cast<BYTE>((sunnieGOC >> 8) & 0xFF), 0x00, 0x04);
	// play open sound
	ACTION_PACKET(tick, 0x01, 0x02, 0x34, 0x00, 0x32, 0x01, 0x04);
	// open risiko
	if (m_nBonusBit.coin < 15) {
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x06, 0x00, 0xb1, 0x52, 0x65, 0x00, 0x00, 0x01, 0x00, 0x01, 0x00, 0x04);
	}
	else {
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x06, 0x00, 0xb1, 0x52, 0x65, top, 0x00, bottom, 0x00, 0x01, 0x00, 0x04);
	}
	tick += 500;

	

	if (bHalfButton && m_nBonusBit.coin > 15) {
		// show enabled half button
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x02, 0x00, 0xb1, 0x52, 0x67, 0x01, 0x01, 0x04);
	}
	else {
		// show disabled half button
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x02, 0x00, 0xb1, 0x52, 0x67, 0x01, 0x03, 0x04);
	}
}

void StateMachine::rsk_go() {
	UINT64 tick = current_time_ms();
	if (m_Risiko.bFinished) {
		return;
	}
	if (m_Risiko.bUpgrading || m_Risiko.bOpening) {
		return;
	}
	if (m_nStatus.load() == STATUS_RisikoAss) {
		// stop ani
		ACTION_PACKET(tick, 0x01, 0x02, 0x40, 0x00, 0xb1, 0x52, 0x08, 0x07, 0x00, 0x00, 0x00, 0x04);
		CHANGE_STATUS(STATUS_Risiko);
		return;
	}
	UINT16 topErfolg = 0;
	UINT16 bottomErfolg = 0;

	UINT16 topIdx = 0;
	UINT16 bottomIdx = 0;

	if (m_nBonusBit.coin < 14000) {
		for (int i = 1; i < sizeof(g_RisikoLevels) / sizeof(g_RisikoLevels[0]); i++) {
			UINT16 level = (i == 6 ? 400 : g_RisikoLevels[i]);
			if (m_nBonusBit.coin > level) {
				continue;
			}
			else if (m_nBonusBit.coin < level) {
				topErfolg = level;
				topIdx = i;

				bottomIdx = i - 1;
				bottomErfolg = g_RisikoLevels[i - 1];
			}
			else { // ==
				if (level == 240) {
					topErfolg = 400;
					bottomErfolg = 0;
					bottomIdx = 0;
				}
				else if (level < 240) {
					topIdx = i + 1;
					topErfolg = g_RisikoLevels[i + 1];
					bottomErfolg = 0;
					bottomIdx = 0;
				}
				else if (level == 400) {
					topIdx = 8;
					topErfolg = 800; // 400
					bottomErfolg = 0;
					bottomIdx = 0;
				}
				else if (level == 800) {
					topIdx = 9;
					topErfolg = 1200;
					bottomErfolg = 400;
					bottomIdx = 7;
				}
				else if (level > 800) {
					topErfolg = g_RisikoLevels[i + 1];
					topIdx = i + 1;
					bottomErfolg = g_RisikoLevels[i - 2];
					bottomIdx = i - 2;
				}
			}
			break;
		}
	}
	else if (m_nBonusBit.coin < 30000) {
		for (int i = 1; i < sizeof(g_RisikoLevels_top) / sizeof(g_RisikoLevels_top[0]); i++) {
			UINT16 level = g_RisikoLevels_top[i];
			if (m_nBonusBit.coin > level) {
				continue;
			}
			else if (m_nBonusBit.coin < level) {
				topErfolg = level;
				topIdx = i + 0x0f;

				bottomIdx = i - 1 + 0x0f;
				bottomErfolg = g_RisikoLevels_top[i - 1];
			}
			else {
				topErfolg = g_RisikoLevels_top[i + 1];
				topIdx = i + 1 + 0x0f;

				bottomIdx = i - 1 + 0x0f;
				bottomErfolg = g_RisikoLevels_top[i - 1];
			}
			break;
		}
	}

	BOOL match = FALSE;
	// Varient -->
	// Use atomic loads to safely read gTotalBet and gTotalWin
	double currentBet = gTotalBet.load();
	double currentWin = gTotalWin.load();

	// Compute current RTP (Return to Player)
	double currentRTP = 0.0;
	if (currentBet > 0.0) {
		currentRTP = currentWin / currentBet;
	}
	else {
		// Handle edge case — no bets placed yet
		currentRTP = 0.0;
	}

	// Determine match condition by variant + RTP + step.
	// A is most fun, then B, then C.
	int randomValue = myRandom() % 100;

	//int threshold = static_cast<int>(std::lround((1.0 - VARIANT_A) * 100.0));
	int threshold = 50;

	if (currentRTP > gTargetRTP) {
		// Dynamic RTP-gap penalty: larger (currentRTP - gTargetRTP) => harder match.
		const double rtpGap = currentRTP - gTargetRTP;
		int gapPenalty = static_cast<int>(rtpGap * 100.0 * 1); // +1 threshold per +1% RTP gap
		if (gapPenalty < 0) gapPenalty = 0;
		const int variantPenalty = static_cast<int>(std::lround(15.0 - 10.0 * gTargetRTP)); // 0.7->8, 0.5->10, 0.3->12
		threshold += variantPenalty + gapPenalty;
	}

	AddRisikoStepThreshold(m_nBonusBit.coin, threshold);
	threshold = (threshold < 0) ? 100 : threshold;
	DebugPrintfT(LogTag::Risiko, "value=%d randomValue=%d threshold=%d currentRTP=%.4f targetRTP=%.4f", m_nBonusBit.coin, randomValue, threshold, currentRTP, gTargetRTP);
	if (randomValue >= threshold) {
		match = true;
	}
	// for test
	//match = true;
	// <--

	if (match) {
		m_nBonusBit.coin = topErfolg;
		SaveBonusBit(m_nBonusBit.coin);

		DisplayMoney(tick, BONUS_BIT_GOC, m_nBonusBit.coin, 0);
		if (m_nBonusBit.coin == 400) {
			m_atRisikoAssFinish = tick + 1800;
			CHANGE_STATUS(STATUS_RisikoAss);
			ACTION_PACKET(tick, 0x01, 0x02, 0x40, 0x00, 0xb1, 0x52, 0x08, 0x06, 0x00, 0x07, 0x00, 0x04);
		}
		else {
			ACTION_PACKET(tick, 0x01, 0x02, 0x40, 0x00, 0xb1, 0x52, 0x08, topIdx, 0x00, 0x00, 0x00, 0x04);
		}
		if (m_nBonusBit.coin == 14000) {
			m_Risiko.bUpgrading = TRUE;
			m_Risiko.bUpgraded = TRUE;
			m_Risiko.nUpgradingWarmup = 7 * 1000;
		}
	}
	else {
		m_nBonusBit.coin = bottomErfolg;
		SaveBonusBit(m_nBonusBit.coin);

		DisplayMoney(tick, BONUS_BIT_GOC, m_nBonusBit.coin, 0);
		ACTION_PACKET(tick, 0x01, 0x02, 0x40, 0x00, 0xb1, 0x52, 0x08, bottomIdx, 0x00, 0x00, 0x00, 0x04);
	}
	
	OneMonitorManipulation::GetInstance().AutoSwitchMirrorWindow(m_nBonusBit.coin, m_Risiko.bUpgraded);

	if (m_nBonusBit.coin == 0 || m_nBonusBit.coin == 10000 || m_nBonusBit.coin == 30000) {
		m_Risiko.bFinished = TRUE;
		if (m_nBonusBit.coin == 30000 || m_nBonusBit.coin == 10000) {
			tick += (m_nBonusBit.coin == 30000 ? 50 * 1000 : 14 * 1000);
			StopAllSound(tick);
			// disable risiko
			ACTION_PACKET(tick, 0x01, 0x02, 0x40, 0x00, 0xB1, 0x52, 0x05, 0x00, 0x00, 0x00, 0x00, 0x04);

			StateMachineCmd setStatusCmd;
			setStatusCmd.cmd = CMD_FinishRisiko;
			setStatusCmd.at = tick;
			ACTION_PUSH_BACK(setStatusCmd);

			//MoveBonus(tick, m_nBonusBit.coin, FALSE);
			//// close risiko
			//ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0xb1, 0x52, 0x68, 0x00, 0x04);
			////m_Risiko.bOpen = FALSE;
			//StateMachineCmd setStatusCmd;
			//setStatusCmd.cmd = CMD_SetSatusAndResetRsk;
			//setStatusCmd.at = tick;
			//setStatusCmd.o.st_SetStatus.status = STATUS_PendingSpin;
			//ACTION_PUSH_BACK(setStatusCmd);
			//m_atAutoReturnToMenu = tick + AUTO_RETURN_TO_MENU_TIME;
		}
	}
	else {
		if (m_nBonusBit.coin < 14000) {
			if (rsk_downable()) {
				// enable down button
				ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x02, 0x00, 0xb1, 0x52, 0x67, 0x01, 0x01, 0x04);
			}
			else {
				// disable down button
				ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x02, 0x00, 0xb1, 0x52, 0x67, 0x01, 0x03, 0x04);
			}
		}
	}
	if (m_nBonusBit.coin == 0) {
		tick += 1000;
		// show disabled half button
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x02, 0x00, 0xb1, 0x52, 0x67, 0x01, 0x03, 0x04);
		// close risiko
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0xb1, 0x52, 0x68, 0x00, 0x04);
		m_Risiko.bOpen = FALSE;

		StateMachineCmd setStatusCmd;
		setStatusCmd.cmd = CMD_SetSatus;
		setStatusCmd.at = tick;
		setStatusCmd.o.st_SetStatus.status = STATUS_PendingSpin;
		ACTION_PUSH_BACK(setStatusCmd);

		m_atAutoReturnToMenu = tick + AUTO_RETURN_TO_MENU_TIME;
	}
	m_Risiko.go++;
}

void StateMachine::rsk_takeBonusAndExit() {
	UINT64 tick = current_time_ms();
	if (m_nStatus.load() != STATUS_Risiko) {
		return;
	}
	if (m_Risiko.bOpen && m_Risiko.bOpening == FALSE && m_Risiko.bUpgrading == FALSE && m_nBonusBit.coin > 0/* && m_nBonusBit.coin < 30000*/) {
		StopAllSound(tick);
		// disable risiko
		ACTION_PACKET(tick, 0x01, 0x02, 0x40, 0x00, 0xB1, 0x52, 0x05, 0x00, 0x00, 0x00, 0x00, 0x04);
		MoveBonus(tick, m_nBonusBit.coin, FALSE);
		// close risiko
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x01, 0x00, 0xb1, 0x52, 0x68, 0x00, 0x04);
		m_Risiko.bOpen = FALSE;

		StateMachineCmd setStatusCmd;
		setStatusCmd.cmd = CMD_SetSatus;
		setStatusCmd.at = tick;
		setStatusCmd.o.st_SetStatus.status = STATUS_PendingSpin;
		ACTION_PUSH_BACK(setStatusCmd);

		m_atAutoReturnToMenu = tick + AUTO_RETURN_TO_MENU_TIME;
	}
}

BOOL StateMachine::rsk_downable() {
	if (m_nBonusBit.coin < 30 || m_nBonusBit.coin >= 14000) {
		return FALSE;
	}
	if (m_Risiko.bOpen == FALSE || m_Risiko.bFinished == TRUE || m_Risiko.bOpening == TRUE || m_Risiko.bUpgrading == TRUE) {
		return FALSE;
	}
	for (int i = 0; i < sizeof(g_RisikoLevels) / sizeof(g_RisikoLevels[0]); i++) {
		if (m_nBonusBit.coin == g_RisikoLevels[i]) {
			return TRUE;
		}
	}
	return FALSE;
}

int StateMachine::rsk_down() {
	UINT64 tick = current_time_ms();
	for (int i = 2; i < sizeof(g_RisikoLevels) / sizeof(g_RisikoLevels[0]); i++) {
		if (m_nBonusBit.coin == g_RisikoLevels[i]) {
			int target = i - 1;
			if (g_RisikoLevels[target] == 0) { // 400: letter
				target--;
			}
			UINT16 delta = m_nBonusBit.coin - g_RisikoLevels[target];
			//m_nBankBit += delta;
			UpdateBankBitInGame(delta);
			m_nBonusBit.coin = g_RisikoLevels[target];
			SaveBonusBit(m_nBonusBit.coin);

			DisplayMoney(tick, BANK_BIT_GOC, m_nBankBit, 0);
			DisplayMoney(tick, BONUS_BIT_GOC, m_nBonusBit.coin, 0);
			return target;
		}
	}
}
// <- risiko
#define GOC_LosFrootosPopUp (2925)

void StateMachine::HideMultiGoAndNormal(UINT64 &tick) {
	StopAllSound(tick);
	m_bMultoGo = FALSE;
	myVector<InterruptPacketData> IntPackets = g_ReelGame->CloseMultiGo(m_nBonusBit.coin, TRUE);
	for (int i = 0; i < IntPackets.size(); i++) {
		tick += AT(IntPackets, i).preDelay;
		ACTION_PACKET_VEC(tick, AT(IntPackets, i).data);
		tick += AT(IntPackets, i).postDelay;
	}
	DisplayMoney(tick, BONUS_BIT_GOC, m_nBonusBit.coin, 0);
	CalcRTP(FALSE, StateMachine::g_rtpGeneration.load());

	CHANGE_STATUS(STATUS_WaitActionBonusSound);
	m_atStopWaitAction_40s = tick + AUTO_MOVE_BONUS_TIME;
	if (m_bAutoSpin || m_bHalfAutoSpin) {
		Spin();
	}
	else {
		PlaySound(tick, SMP_VorauswahlRisiko);
	}	
}


void StateMachine::HideMultiGoAndStart() {
	UINT64 tick = current_time_ms();
	StopAllSound(tick);
	if (m_bMultoGo == FALSE) {
		m_nMultiGoTotalLoop = 1;
		m_bMultoGo = TRUE;
	}
	else {
		m_nMultiGoTotalLoop++;
	}
	// stop sunnie ani
	UINT16 sunnieGOC = SUNNIER_GOC;
	ACTION_PACKET(tick, 0x01, 0x02, 0x29, 0x00, static_cast<BYTE>(sunnieGOC & 0xFF), static_cast<BYTE>((sunnieGOC >> 8) & 0xFF), 0x00, 0x04);

	UINT8 total = 0, gone = 0, loop = 0;
	g_ReelGame->MultiGoGoneAndRemain(gone, total, loop);

	UINT16 multiGoGOC = 0;
	if (m_nGameID == GOC_RgLosFrootos) {
		multiGoGOC = GOC_LosFrootosPopUp;
	}
	if (m_nGameID == GOC_RgLosFrootos) {
		// close  spin menu
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x0d, 0x00,
			static_cast<BYTE>(multiGoGOC & 0xFF), static_cast<BYTE>((multiGoGOC >> 8) & 0xFF), 0xae, 0xa4, 0x06, 0x00, 0x00,
			total, 0x90, 0x01, 0x00, 0x00, 0x00, 0x01, 0x02, 0x01, 0x04);
	}
	else if (m_nGameID == GOC_RgPharosGoldBase) {
		ACTION_PACKET(tick, 0x01, 0x02, 0x31, 0x00, 0x0b, 0x00, 0xb1, 0x38, 0xce, 0x78, 0x00, 0x00, 0x00, total, 0x01, 0x02, 0x00, 0x50, 0x00, 0x01, 0x04);
	}

	CHANGE_STATUS(STATUS_PendingSpin);

	if (m_bAutoSpin || 1) {
		Spin();
	}
}

void StateMachine::ClearCredit() {
	m_nBankBit = 0;
	PlayDB::GetInstance().SetGameCreditData(0);
	KomProtocol* pKom = CryptoCard::GetInstance().GetKomProtocol();
	BYTE data[] = { 0x01, 0x02, 0x2c, 0x00, 0x89, 0x5a, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04 };
	pKom->MakePacket(data, sizeof(data));
}

void StateMachine::OnPayout() {
	PlayDB::GetInstance().AddPayoutData();
	g_StateMachine.ClearCredit();
}


void StateMachine::SetBonusBit(UINT64 tick, UINT32 bonus) {
	m_nBonusBit.coin = bonus;
	SaveBonusBit(m_nBonusBit.coin);
	//DisplayMoney(tick, BONUS_BIT_GOC, m_nBonusBit.coin, 0);
}

void StateMachine::SaveBonusBit(UINT32 bonus) {
	PlayDB::GetInstance().SaveCheckPoint(bonus);
}