#include "stdafx.h"
#include "CryptoCard.h"
#include "Utils.h"
#include "KomProtocol.h"
#include "mmcode.h"
#include "PlayDB.h"
#include "resource.h"
#include "StateMachine.h"
#include "SharedMutex.h"
#include "OneMinitorManipulation.h"
#include "AIBot/AIBot.h"
#include "TimeLicense.h"
#include "Hook.h"
#include <time.h>
#include <stdlib.h>

extern HINSTANCE g_hInst; // stored in DllMain

HHOOK CryptoCard::gKeyboardHook = NULL;
HWND CryptoCard::gSettingsDialog = NULL;
HWND CryptoCard::gmainWindow = NULL;

static bool g_licenseDialogMode = false;

// Bookkeeping Dialog Static Variables
static bool g_bkPasswordValidated = false; // Bookkeeping password validation state
static wchar_t g_bkEnteredPassword[32] = {0}; // Currently entered password for bookkeeping
static int g_bkDigitPositions[10]; // Random positions for digits 0-9 for bookkeeping
static HWND g_bkDialog = NULL; // Bookkeeping dialog handle
static HFONT g_bkLargeFont = NULL; // Large font for bookkeeping dialog
static HFONT g_bkLargeFontBold = NULL; // Extra-bold font for emphasis rows
static bool g_bkIsMainBookkeeping = true; // true for main (Ctrl+H), false for sub (Ctrl+N)

// Settings Dialog Static Variables
static HFONT g_settingsLargeFont = NULL; // Large font for settings dialog

// Payout Dialog Static Variables
static HWND g_payoutDialog = NULL; // Payout dialog handle
static HFONT g_payoutLargeFont = NULL; // Large font for payout dialog
static int g_asteriskCount = 0; // Count of consecutive asterisks
static DWORD g_lastAsteriskTime = 0; // Time of last asterisk press

INT_PTR CALLBACK MyDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK BookkeepingDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK PayoutDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);

//KomProtocol* GetKomProtocolObj() {
//	return CryptoCard::GetInstance().GetKomProtocol();
//}

// Singleton accessor
CryptoCard& CryptoCard::GetInstance() {
	static CryptoCard instance;
	return instance;
}

CryptoCard::CryptoCard()
{
	mWaitForNext = FALSE;
	m_hReadWakeEvent = CreateEventW(nullptr, FALSE, FALSE, nullptr);
	mStatus = 0;
	mpKomProtocol = new KomProtocol();
	ZeroMemory(mInterruptAns, sizeof(mInterruptAns));
	mLastNumpadAction = std::chrono::steady_clock::now() - std::chrono::milliseconds(500); // Initialize to allow first press
	mNumpad5Pressed = false;
	mLongPressed = false;
	mNumpad6Pressed = false;
}


CryptoCard::~CryptoCard()
{
	if (m_hReadWakeEvent) {
		CloseHandle(m_hReadWakeEvent);
		m_hReadWakeEvent = nullptr;
	}
	delete mpKomProtocol;
	RemoveHook();
}

KomProtocol* CryptoCard::GetKomProtocol() {
	return mpKomProtocol;
}

BOOL CryptoCard::Read(BYTE* data, int pReadSize)
{
	DebugPrintf("**************READ: %d", pReadSize);
	if (pReadSize <= 0) return 1;
	mpKomProtocol->ReadData(data, pReadSize);

	mWaitForNext = FALSE;
	if (m_hReadWakeEvent) {
		SetEvent(m_hReadWakeEvent);
	}
	return -1;
}

BOOL CryptoCard::Write(BYTE* data)
{
	if (mStatus == 0)
	{
		Sleep(1500);
		mStatus = 1;
	}
	int size = mpKomProtocol->ComposeData(data);

	return size;
}

void CryptoCard::WriteDone() {
	mWaitForNext = TRUE;
	if (m_hReadWakeEvent) {
		ResetEvent(m_hReadWakeEvent);
	}
}

//void CryptoCard::WriteReady() {
//	mWaitForNext = FALSE;
//}

void CryptoCard::WaitForSingleObject(HANDLE gSavedEvent, DWORD dwMilliseconds)
{
	(void)gSavedEvent;
	mpKomProtocol->ManualSleep();
	// Slice: when data is ready, Read() SetEvent wakes us immediately. Otherwise we wait up to
	// slice ms before re-checking IsInterrupt — fewer wakeups than Sleep(10), not a fixed 250ms stall.
	const DWORD kMaxSliceMs = 100;
	DWORD sliceMs;
	if (dwMilliseconds == INFINITE) {
		sliceMs = 50;
	}
	else if (dwMilliseconds == 0) {
		sliceMs = 1;
	}
	else {
		sliceMs = (dwMilliseconds < kMaxSliceMs) ? dwMilliseconds : kMaxSliceMs;
	}

	if (!m_hReadWakeEvent) {
		while (mWaitForNext) {
			Sleep(sliceMs);
			if (mpKomProtocol->IsInterrupt()) {
				break;
			}
		}
		return;
	}

	while (mWaitForNext) {
		if (mpKomProtocol->IsInterrupt()) {
			break;
		}
		::WaitForSingleObject(m_hReadWakeEvent, sliceMs);
	}
}

bool CryptoCard::IsPlusKey(DWORD vk) {
	return vk == VK_OEM_PLUS || vk == VK_ADD;
}

void CryptoCard::ProcessKeySequence() {
	if (mKeySequence.size() < 4)
		return;

	int len = static_cast<int>(mKeySequence.size());

	// Step 1: Check last key is Main Enter
	if (mKeySequence[len - 1].first != VK_RETURN || mKeySequence[len - 1].second)
		return;

	std::string digits;
	int digitCount = 0;
	int i = len - 2;

	// Accept only normal digit keys ('0'–'9')
	while (i >= 0 && digitCount < 3) {
		DWORD vk = mKeySequence[i].first;
		if (vk >= '0' && vk <= '9') {
			digits = static_cast<char>(vk) + digits;
			++digitCount;
			--i;
		}
		else {
			break;
		}
	}

	// Step 3: Expect two plus keys just before the digits
	if (i < 1) return;

	DWORD plus1 = mKeySequence[i].first;
	DWORD plus0 = mKeySequence[i - 1].first;

	if (IsPlusKey(plus0) && IsPlusKey(plus1) && !digits.empty()) {
		int number = std::stoi(digits);  // Convert to int
		DebugPrintf(" Process %d money", number);
		
		//Write Back to shared memory 
		writeCreditData(number * 100);

		mpKomProtocol->SendInputMoney(number * 100);

		mKeySequence.clear(); // Optional reset
	}
}

bool CryptoCard::DetectDoubleNumpad5() {
	auto now = std::chrono::steady_clock::now();
	auto diff = std::chrono::duration_cast<std::chrono::milliseconds>(now - mLastSpinPress);

	mLastSpinPress = now;

	// Within 1s → detect double
	if (diff.count() <= 1000) {
		// Only allow one Fast Spin per window
		//if (!mFastSpinTriggered) {
		//	mFastSpinTriggered = true;
		//	mFastSpinExpire = now + std::chrono::milliseconds(1000); // suppress for 1s
			return true;
		//}
	}

	//// Reset if cooldown expired
	//if (now > mFastSpinExpire) {
	//	mFastSpinTriggered = false;
	//}

	return false;
}

void CryptoCard::HandleNumpadAction(DWORD vk) {
	auto now = std::chrono::steady_clock::now();
	
	// Debounce: ignore numpad presses within 0.2 seconds of the last action
	// Exception: VK_NUMPAD5 is processed without delay
	if (vk != VK_NUMPAD5) {
		auto timeSinceLastAction = std::chrono::duration_cast<std::chrono::milliseconds>(now - mLastNumpadAction);
		
		if (timeSinceLastAction.count() < 200) {
			// Ignore this press - too soon after the last one
			return;
		}
	}
	
	// Update the last action time (for all buttons including numpad 5)
	mLastNumpadAction = now;
	
	switch (vk) {
	case VK_NUMPAD0:
		mpKomProtocol->Numpad0();
		break;
	case VK_NUMPAD1:
		mpKomProtocol->Numpad1();
		break;
	case VK_NUMPAD2:
		mpKomProtocol->Numpad2();
		break;
	case VK_NUMPAD3:
		DebugPrintf(" Max Bet\n");
		//mpKomProtocol->MaxBet();
		break;
	case VK_NUMPAD4:
		DebugPrintf(" Bet Change\n");
		mpKomProtocol->BetChange();
		//WriteReady();

		break;
	case VK_NUMPAD5:
		if(this->mLongPressed == false)
			mpKomProtocol->Spin();

		if (DetectDoubleNumpad5()) {
			DebugPrintf(" Fast Spin\n");
			if(!g_StateMachine.AlreadySentFastSpin())
			{
				mpKomProtocol->FastSpin();
			}
		}
		{
			OneMonitorManipulation::GetInstance().HideMirrorWindow();
		}
		break;
	case VK_NUMPAD6:
		if(this->mNumpad6Pressed == true)
			break;
		
		DebugPrintf(" Autospin\n");
		mpKomProtocol->ToogleAutoSpin();
		OneMonitorManipulation::GetInstance().HideMirrorWindow();
		break;
	case VK_NUMPAD7:
		DebugPrintf(" Menu\n");
		mpKomProtocol->ReturnToMenu();
		OneMonitorManipulation::GetInstance().HideMirrorWindow();
		break;
	case VK_NUMPAD8:
		OneMonitorManipulation::GetInstance().ToggleMirrorWindow();
		break;
	}
}

void CryptoCard::HandleCtrlCombinations(DWORD vkCode) {
	if (mpKomProtocol->mRunState == RUNSTATE_GAME)  return;

	// Drop stale HWNDs (e.g. if a dialog was destroyed without clearing the global).
	if (gSettingsDialog && !IsWindow(gSettingsDialog))
		gSettingsDialog = NULL;
	if (g_bkDialog && !IsWindow(g_bkDialog))
		g_bkDialog = NULL;
	if (g_payoutDialog && !IsWindow(g_payoutDialog))
		g_payoutDialog = NULL;

	// Check if any dialog is already open - only one dialog can be open at a time
	if ((gSettingsDialog != NULL && IsWindow(gSettingsDialog)) ||
		(g_bkDialog != NULL && IsWindow(g_bkDialog)) ||
		(g_payoutDialog != NULL && IsWindow(g_payoutDialog))) {
		// A dialog is already open, do not open another one
		DebugPrintf("A dialog is already open, cannot open another dialog\n");
		return;
	}

	switch (vkCode) {
	case 'O':
		OpenSettingsDialog();
		break;
	case 'Q':
		OpenLicenseDialog();
		break;
	case 'H':
		OpenMainBookDialog();
		break;
	case 'N':
		OpenSubBookDialog();
		break;
	}
}


LRESULT CALLBACK CryptoCard::KeyboardProc(int nCode, WPARAM wParam, LPARAM lParam) {
	if (nCode == HC_ACTION) {
		KBDLLHOOKSTRUCT* p = reinterpret_cast<KBDLLHOOKSTRUCT*>(lParam);
		DWORD vkCode = p->vkCode;
		bool isExtended = (p->flags & LLKHF_EXTENDED) != 0;
		CryptoCard& card = GetInstance();

		// Handle key up events for long press detection
		if (wParam == WM_KEYUP || wParam == WM_SYSKEYUP) {
			if (vkCode == VK_NUMPAD5 && card.mNumpad5Pressed) {
				card.mNumpad5Pressed = false;
				card.mLongPressed = false;
			}

			if (vkCode == VK_NUMPAD6 && card.mNumpad6Pressed) {
				card.mNumpad6Pressed = false;
			}

			return CallNextHookEx(gKeyboardHook, nCode, wParam, lParam);
		}

		// Handle key down events
		if (wParam == WM_KEYDOWN || wParam == WM_SYSKEYDOWN) {
			// Duration license gate: when the time-based license is not valid, swallow
			// all in-game key actions. Pass the event to the next hook so normal OS
			// shortcuts keep working, but skip every game-side handler below.
			// Exception: Ctrl+Q must still reach HandleCtrlCombinations so the user
			// can open the license-entry dialog while unlicensed.
			if (!TimeLicense::IsLicensedOk()) {
				const bool ctrlDown = (GetAsyncKeyState(VK_CONTROL) & 0x8000) != 0;
				if (ctrlDown && vkCode == 'Q') {
					card.HandleCtrlCombinations(vkCode);
				}
				return CallNextHookEx(gKeyboardHook, nCode, wParam, lParam);
			}
#ifdef	AIBOT_ACTIVE
			if (vkCode == VK_F9) {
				AIBot_Start();
				return CallNextHookEx(gKeyboardHook, nCode, wParam, lParam);
			}
			if (vkCode == VK_F10) {
				AIBot_Stop();
				return CallNextHookEx(gKeyboardHook, nCode, wParam, lParam);
			}
#endif
			card.mKeySequence.emplace_back(vkCode, isExtended);

			// Track Numpad5 press start time
			if (vkCode == VK_NUMPAD5 && !card.mNumpad5Pressed) {
				card.mNumpad5PressStart = std::chrono::steady_clock::now();
				card.mNumpad5Pressed = true;
			}

			if (vkCode >= VK_NUMPAD0 && vkCode <= VK_NUMPAD9) {
				if (g_StateMachine.KeyEventEnable() == TRUE || vkCode == VK_NUMPAD8) {
					card.HandleNumpadAction(vkCode);
				}
			} else {
				switch (vkCode) {
				case 'M':
					mmcode_active_go('m');
					break;
				case 'C':
					mmcode_active_go('c');
					break;
				case 'O':
					mmcode_active_go('o');
					break;
				case 'D':
					mmcode_active_go('d');
					break;
				case 'E':
					mmcode_active_go('e');
					break;
				default:
					mmcode_active_go('~');
					break;
				};

				// Check for CTRL key combinations
				bool ctrlPressed = (GetAsyncKeyState(VK_CONTROL) & 0x8000) != 0;
				if (ctrlPressed && (vkCode == 'O' || vkCode == 'Q' || vkCode == 'H' || vkCode == 'N')) {
					card.HandleCtrlCombinations(vkCode);
				}
				// Check for three asterisks sequence
				else if (vkCode == VK_MULTIPLY) {
					card.HandleAsteriskSequence();
				}
			}

			// Keep last 10 keys max
			if (card.mKeySequence.size() > 10)
				card.mKeySequence.pop_front();

			//if (vkCode == VK_RETURN && isExtended) {
			if (vkCode == VK_RETURN && !isExtended) {
				card.ProcessKeySequence();
			}

			//handle long press of Numpad5
			if (vkCode == VK_NUMPAD5 && card.mNumpad5Pressed) {
				auto now = std::chrono::steady_clock::now();
				auto pressDuration = std::chrono::duration_cast<std::chrono::milliseconds>(now - card.mNumpad5PressStart);
				
				if (pressDuration.count() >= 1000 && !card.mLongPressed) {
					if (g_StateMachine.GetStatus() == STATUS_SpinRunning)
					{
						card.mLongPressed = true;
						DebugPrintf(" Long Press Numpad5 detected (%lld ms)\n", pressDuration.count());
						g_StateMachine.ToogleHalfAutoSpin();
					}
				}
			}

			//handle long press of Numpad6
			if(vkCode == VK_NUMPAD6 && !card.mNumpad6Pressed) {
				card.mNumpad6Pressed = true;
			}
		}
	}

	return CallNextHookEx(gKeyboardHook, nCode, wParam, lParam);
}

void CryptoCard::SetHook()
{
	if (!gKeyboardHook) {
		gKeyboardHook = SetWindowsHookEx(WH_KEYBOARD_LL, KeyboardProc, NULL, 0);
		if (gKeyboardHook)
			DebugPrintf("[CryptoCard] Keyboard hook installed.\n");
		else
			DebugPrintf("[CryptoCard] Failed to install hook.\n");
	}
}

void CryptoCard::RemoveHook() {
	if (gKeyboardHook) {
		UnhookWindowsHookEx(gKeyboardHook);
		gKeyboardHook = NULL;
		DebugPrintf("[CryptoCard] Hook removed.\n");
	}
}

void CryptoCard::Initialize()
{
	SetHook();
	//PlayDB::GetInstance().Load();
}

/////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////// Dialog based code /////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////
void CryptoCard::OpenSettingsDialog()
{
	g_licenseDialogMode = false;
	// Check if any other dialog is already open - only one dialog can be open at a time
	if ((g_bkDialog != NULL && IsWindow(g_bkDialog)) ||
		(g_payoutDialog != NULL && IsWindow(g_payoutDialog))) {
		// Another dialog is already open, do not open settings dialog
		DebugPrintf("Another dialog is already open, cannot open settings dialog\n");
		return;
	}

	// Check if this dialog is already open
	if (gSettingsDialog != NULL && IsWindow(gSettingsDialog))
	{
		// Dialog is already open, bring it to front
		BringWindowToTop(gSettingsDialog);
		SetActiveWindow(gSettingsDialog);
		DebugPrintf("Settings dialog already open, bringing to front\n");
		return;
	}

	OneMonitorManipulation::GetInstance().HideMirrorWindow();

	const HWND hwndGameForDlg = CryptoCard::gmainWindow;
	// Create modal dialog - this will block until dialog is closed
	// Note: DialogBox doesn't return until the dialog is closed
	INT_PTR result = DialogBox(g_hInst, MAKEINTRESOURCE(IDD_SETTINGS), hwndGameForDlg, MyDlgProc);
	
	// Dialog has been closed, reset the handle
	gSettingsDialog = NULL;
	if (hwndGameForDlg && IsWindow(hwndGameForDlg))
		CryptoCard::gmainWindow = hwndGameForDlg;
	
	if (result == -1)
	{
		DWORD err = GetLastError();
		DebugPrintf("DialogBox failed! Error %lu\n", err);
	}
	else
	{
		DebugPrintf("Settings dialog closed with result: %lld\n", static_cast<long long>(result));
	}
}

static void OpenLicenseDialogWithParent(HWND hParent)
{
	if ((g_bkDialog != NULL && IsWindow(g_bkDialog)) ||
		(g_payoutDialog != NULL && IsWindow(g_payoutDialog))) {
		return;
	}
	if (CryptoCard::gSettingsDialog != NULL && IsWindow(CryptoCard::gSettingsDialog)) {
		BringWindowToTop(CryptoCard::gSettingsDialog);
		SetActiveWindow(CryptoCard::gSettingsDialog);
		return;
	}
	// ScreenMirror's second-monitor overlay sits above the game; it would steal all mouse/touch input from the modal.
	OneMonitorManipulation::GetInstance().HideMirrorWindow();
	Sleep(50);
	const HWND hwndGameSnapshot = CryptoCard::gmainWindow;
	g_licenseDialogMode = true;
	INT_PTR result = DialogBox(g_hInst, MAKEINTRESOURCE(IDD_SETTINGS), hParent, MyDlgProc);
	g_licenseDialogMode = false;
	CryptoCard::gSettingsDialog = NULL;
	if (hwndGameSnapshot && IsWindow(hwndGameSnapshot))
		CryptoCard::gmainWindow = hwndGameSnapshot;
	if (result == -1) {
		DWORD err = GetLastError();
		DebugPrintf("License DialogBox failed! Error %lu\n", err);
	}
}

void CryptoCard::OpenLicenseDialog()
{
	OpenLicenseDialogWithParent(CryptoCard::gmainWindow);
}

void CryptoCard::InjectLicenseDialogHotkey()
{
	INPUT in[4] = {};
	in[0].type = INPUT_KEYBOARD;
	in[0].ki.wVk = VK_CONTROL;
	in[1].type = INPUT_KEYBOARD;
	in[1].ki.wVk = 'Q';
	in[2].type = INPUT_KEYBOARD;
	in[2].ki.wVk = 'Q';
	in[2].ki.dwFlags = KEYEVENTF_KEYUP;
	in[3].type = INPUT_KEYBOARD;
	in[3].ki.wVk = VK_CONTROL;
	in[3].ki.dwFlags = KEYEVENTF_KEYUP;
	const UINT n = static_cast<UINT>(sizeof(in) / sizeof(in[0]));
	const UINT sent = SendInput(n, in, sizeof(INPUT));
	if (sent != n) {
		DebugPrintf("InjectLicenseDialogHotkey SendInput sent %u (expected %u) err %lu\n",
			sent, n, GetLastError());
	}
}

void CryptoCard::OpenMainBookDialog()
{
	// Check if any other dialog is already open - only one dialog can be open at a time
	if ((gSettingsDialog != NULL && IsWindow(gSettingsDialog)) ||
		(g_payoutDialog != NULL && IsWindow(g_payoutDialog))) {
		// Another dialog is already open, do not open bookkeeping dialog
		DebugPrintf("Another dialog is already open, cannot open bookkeeping dialog\n");
		return;
	}

	// Check if this dialog is already open
	if (g_bkDialog != NULL && IsWindow(g_bkDialog))
	{
		// Dialog is already open, bring it to front
		BringWindowToTop(g_bkDialog);
		SetActiveWindow(g_bkDialog);
		DebugPrintf("Bookkeeping dialog already open, bringing to front\n");
		return;
	}

	// Reset password validation state
	g_bkPasswordValidated = false;
	g_bkIsMainBookkeeping = true; // Set to main bookkeeping mode
	
	const HWND hwndGameForBk = CryptoCard::gmainWindow;
	// Create modal dialog - this will block until dialog is closed
	// Note: DialogBox doesn't return until the dialog is closed
	INT_PTR result = DialogBox(g_hInst, MAKEINTRESOURCE(IDD_BOOKKEEPING), hwndGameForBk, BookkeepingDlgProc);
	
	// Dialog has been closed, reset the handle
	g_bkDialog = NULL;
	if (hwndGameForBk && IsWindow(hwndGameForBk))
		CryptoCard::gmainWindow = hwndGameForBk;
	
	if (result == -1)
	{
		DWORD err = GetLastError();
		DebugPrintf("Bookkeeping DialogBox failed! Error %lu\n", err);
	}
	else
	{
		DebugPrintf("Bookkeeping dialog closed with result: %lld\n", static_cast<long long>(result));
	}
}

void CryptoCard::OpenSubBookDialog()
{
	// Check if any other dialog is already open - only one dialog can be open at a time
	if ((gSettingsDialog != NULL && IsWindow(gSettingsDialog)) ||
		(g_payoutDialog != NULL && IsWindow(g_payoutDialog))) {
		// Another dialog is already open, do not open bookkeeping dialog
		DebugPrintf("Another dialog is already open, cannot open bookkeeping dialog\n");
		return;
	}

	// Check if this dialog is already open
	if (g_bkDialog != NULL && IsWindow(g_bkDialog))
	{
		// Dialog is already open, bring it to front
		BringWindowToTop(g_bkDialog);
		SetActiveWindow(g_bkDialog);
		DebugPrintf("Bookkeeping dialog already open, bringing to front\n");
		return;
	}

	// Reset password validation state
	g_bkPasswordValidated = false;
	g_bkIsMainBookkeeping = false; // Set to sub bookkeeping mode
	
	const HWND hwndGameForBk = CryptoCard::gmainWindow;
	// Create modal dialog - this will block until dialog is closed
	// Note: DialogBox doesn't return until the dialog is closed
	INT_PTR result = DialogBox(g_hInst, MAKEINTRESOURCE(IDD_BOOKKEEPING), hwndGameForBk, BookkeepingDlgProc);
	
	// Dialog has been closed, reset the handle
	g_bkDialog = NULL;
	if (hwndGameForBk && IsWindow(hwndGameForBk))
		CryptoCard::gmainWindow = hwndGameForBk;
	
	if (result == -1)
	{
		DWORD err = GetLastError();
		DebugPrintf("Bookkeeping DialogBox failed! Error %lu\n", err);
	}
	else
	{
		DebugPrintf("Bookkeeping dialog closed with result: %lld\n", static_cast<long long>(result));
	}
}

void CryptoCard::HandleAsteriskSequence()
{
	if (mpKomProtocol->mRunState == RUNSTATE_GAME)  return;

	DWORD currentTime = GetTickCount();
	
	// Reset count if more than 2 seconds have passed since last asterisk
	if (currentTime - g_lastAsteriskTime > 2000) {
		g_asteriskCount = 0;
	}
	
	g_asteriskCount++;
	g_lastAsteriskTime = currentTime;
	
	DebugPrintf("Asterisk count: %d\n", g_asteriskCount);
	
	// If three asterisks pressed within 2 seconds, open payout dialog
	if (g_asteriskCount >= 3) {
		g_asteriskCount = 0; // Reset count
		OpenPayoutDialog();
	}
}

void CryptoCard::OpenPayoutDialog()
{
	// Check if any dialog is already open - only one dialog can be open at a time
	if ((gSettingsDialog != NULL && IsWindow(gSettingsDialog)) ||
		(g_bkDialog != NULL && IsWindow(g_bkDialog)) ||
		(g_payoutDialog != NULL && IsWindow(g_payoutDialog))) {
		// A dialog is already open, do not open another one
		DebugPrintf("A dialog is already open, cannot open payout dialog\n");
		return;
	}
	
	const HWND hwndGameForPayout = CryptoCard::gmainWindow;
	// Create modal dialog - this will block until dialog is closed
	// Note: DialogBox doesn't return until the dialog is closed
	INT_PTR result = DialogBox(g_hInst, MAKEINTRESOURCE(IDD_PAYOUT), hwndGameForPayout, PayoutDlgProc);
	
	// Dialog has been closed, reset the handle
	g_payoutDialog = NULL;
	if (hwndGameForPayout && IsWindow(hwndGameForPayout))
		CryptoCard::gmainWindow = hwndGameForPayout;
	
	if (result == -1)
	{
		DWORD err = GetLastError();
		DebugPrintf("Payout DialogBox failed! Error %lu\n", err);
	}
	else
	{
		DebugPrintf("Payout dialog closed with result: %lld\n", static_cast<long long>(result));
	}
}

// Static variable to store the background bitmap
static HBITMAP g_hBackgroundBitmap = NULL;
static HBITMAP g_hBKBackgroundBitmap = NULL;

// Control IDs for dynamic dialog components
#define IDC_PASSWORD_TITLE               1001
#define IDC_PASSWORD_DISPLAY             1002
#define IDC_PASSWORD_OK                  1003
#define IDC_PASSWORD_BTN_0               1004
#define IDC_PASSWORD_BTN_1               1005
#define IDC_PASSWORD_BTN_2               1006
#define IDC_PASSWORD_BTN_3               1007
#define IDC_PASSWORD_BTN_4               1008
#define IDC_PASSWORD_BTN_5               1009
#define IDC_PASSWORD_BTN_6               1010
#define IDC_PASSWORD_BTN_7               1011
#define IDC_PASSWORD_BTN_8               1012
#define IDC_PASSWORD_BTN_9               1013
#define IDC_PASSWORD_CLEAR               1094
#define IDC_PASSWORD_VERSION             1098
#define IDC_LICENSE_MACHINE_ID           1097
#define IDC_LICENSE_STATUS               1096
#define IDC_LICENSE_VALID_UNTIL          1095
#define IDC_LICENSE_CURRENT_DATE         1093
#define IDC_GAMES_LIST_TITLE             1014
#define IDC_GAMES_LIST                   1015
#define IDC_SELECTED_GAME                1016
#define IDC_BET_SETTINGS_TITLE           1017
#define IDC_BET_ROW1_LEFT                1018
#define IDC_BET_ROW1_VALUE               1019
#define IDC_BET_ROW1_RIGHT               1020
#define IDC_BET_ROW2_LEFT                1021
#define IDC_BET_ROW2_VALUE               1022
#define IDC_BET_ROW2_RIGHT               1023
#define IDC_BET_ROW3_LEFT                1024
#define IDC_BET_ROW3_VALUE               1025
#define IDC_BET_ROW3_RIGHT               1026
#define IDC_BET_SAVE                     1027
#define IDC_BET_SAVE_ALL                 1099
#define IDC_VARIANTS_TITLE               1028
#define IDC_VARIANT_LEFT                 1029
#define IDC_VARIANT_VALUE                1030
#define IDC_VARIANT_RIGHT                1031
#define IDC_VARIANT_SAVE                 1032
#define IDC_RESET_BUTTON                 1033
#define IDC_CLOSE_BUTTON                 1034

// Password Change Control IDs
#define IDC_PWD_CHANGE_TITLE             1035
#define IDC_SETTING_PWD_LABEL            1036
#define IDC_SETTING_PWD_DISPLAY          1037
#define IDC_SETTING_PWD_RANDOM           1038
#define IDC_SETTING_PWD_PLUS             1039
#define IDC_SETTING_PWD_MINUS            1040
#define IDC_SETTING_PWD_SAVE             1041
#define IDC_BOOKKEEPING_PWD_LABEL        1042
#define IDC_BOOKKEEPING_PWD_DISPLAY      1043
#define IDC_BOOKKEEPING_PWD_RANDOM       1044
#define IDC_BOOKKEEPING_PWD_PLUS         1045
#define IDC_BOOKKEEPING_PWD_MINUS        1046
#define IDC_BOOKKEEPING_PWD_SAVE         1047

// Settings dialog pagination + page2 keypad (control IDs)
#define IDC_SETTINGS_PAGE_1              1048
#define IDC_SETTINGS_PAGE_2              1049
#define IDC_SETTINGS_PWD_DIGIT_0         1050
#define IDC_SETTINGS_PWD_DIGIT_1         1051
#define IDC_SETTINGS_PWD_DIGIT_2         1052
#define IDC_SETTINGS_PWD_DIGIT_3         1053
#define IDC_SETTINGS_PWD_DIGIT_4         1054
#define IDC_SETTINGS_PWD_DIGIT_5         1055
#define IDC_SETTINGS_PWD_DIGIT_6         1056
#define IDC_SETTINGS_PWD_DIGIT_7         1057
#define IDC_SETTINGS_PWD_DIGIT_8         1058
#define IDC_SETTINGS_PWD_DIGIT_9         1059
#define IDC_SETTINGS_PWD_BACKSPACE       1060
#define IDC_SETTINGS_PWD_CLEAR           1061

// Bookkeeping password keypad (page 2)
#define IDC_SETTINGS_BK_DIGIT_0          1062
#define IDC_SETTINGS_BK_DIGIT_1          1063
#define IDC_SETTINGS_BK_DIGIT_2          1064
#define IDC_SETTINGS_BK_DIGIT_3          1065
#define IDC_SETTINGS_BK_DIGIT_4          1066
#define IDC_SETTINGS_BK_DIGIT_5          1067
#define IDC_SETTINGS_BK_DIGIT_6          1068
#define IDC_SETTINGS_BK_DIGIT_7          1069
#define IDC_SETTINGS_BK_DIGIT_8          1070
#define IDC_SETTINGS_BK_DIGIT_9          1071
#define IDC_SETTINGS_BK_BACKSPACE        1072
#define IDC_SETTINGS_BK_CLEAR            1073
#define IDC_SETTINGS_SAVED_BANNER        1074

// Timer IDs for password display
#define TIMER_SETTING_PWD                2001
#define TIMER_BOOKKEEPING_PWD            2002
#define TIMER_SAVE_BANNER                2003

// Bookkeeping Dialog Control IDs
#define IDC_BK_PASSWORD_TITLE            2001
#define IDC_BK_PASSWORD_DISPLAY           2002
#define IDC_BK_PASSWORD_OK               2003
#define IDC_BK_PASSWORD_BTN_0            2004
#define IDC_BK_PASSWORD_BTN_1            2005
#define IDC_BK_PASSWORD_BTN_2            2006
#define IDC_BK_PASSWORD_BTN_3            2007
#define IDC_BK_PASSWORD_BTN_4            2008
#define IDC_BK_PASSWORD_BTN_5            2009
#define IDC_BK_PASSWORD_BTN_6            2010
#define IDC_BK_PASSWORD_BTN_7            2011
#define IDC_BK_PASSWORD_BTN_8            2012
#define IDC_BK_PASSWORD_BTN_9            2013
#define IDC_BK_LICENSE_VALID_UNTIL       2096
#define IDC_BK_LICENSE_MACHINE_ID        2097
#define IDC_BK_PASSWORD_CLEAR            2095
#define IDC_BK_PASSWORD_VERSION          2098
#define IDC_BK_LEFT_TITLE                2014
#define IDC_BK_BEGIN_LABEL               2015
#define IDC_BK_BEGIN_DATE                2016
#define IDC_BK_TOTAL_IN_LABEL            2017
#define IDC_BK_TOTAL_IN_VALUE            2018
#define IDC_BK_TOTAL_OUT_LABEL            2019
#define IDC_BK_TOTAL_OUT_VALUE           2020
#define IDC_BK_HOLD_LABEL                2040
#define IDC_BK_HOLD_SEPARATOR            2041
#define IDC_BK_REMAINING_VALUE           2021
#define IDC_BK_PLAYED_POINTS_LABEL       2022
#define IDC_BK_PLAYED_POINTS_VALUE       2023
#define IDC_BK_WON_POINTS_LABEL          2024
#define IDC_BK_WON_POINTS_VALUE          2025
#define IDC_BK_GAME_SPIN_LABEL           2026
#define IDC_BK_GAME_SPIN_VALUE           2027
#define IDC_BK_DELETE_BUTTON             2028
#define IDC_BK_CLOSE_BUTTON              2029
#define IDC_BK_RIGHT_TITLE               2030
#define IDC_BK_GAMES_LIST                2031
#define IDC_BK_GAME_LABEL                2032
#define IDC_BK_PLAYED_LABEL              2033
#define IDC_BK_WON_LABEL                 2034
#define IDC_BK_SPINS_LABEL               2035
#define IDC_BK_GAME_LIST                 2036
#define IDC_BK_PLAYED_LIST               2037
#define IDC_BK_WON_LIST                  2038
#define IDC_BK_SPINS_LIST                2039

// Static variables for dialog state
static int g_betValues[3] = {1, 5, 10}; // Initial bet values
static int g_currentVariant = 0; // 0=A, 1=B, 2=C (only A is exposed when VARIANTBC_ACTIVE is undefined)
static int g_selectedGame = 0; // Currently selected game index
static bool g_passwordValidated = false; // Password validation state
static wchar_t g_enteredPassword[32] = {0}; // Currently entered password
static int g_digitPositions[10]; // Random positions for digits 0-9
static const wchar_t* g_variantNames[] = {L"Variant A", L"Variant B", L"Variant C"};
#ifdef VARIANTBC_ACTIVE
static const int g_variantCount = 3;
static const int g_variantDefaultIndex = 1; // Variant B
#else
static const int g_variantCount = 1;
static const int g_variantDefaultIndex = 0; // Variant A
#endif

// Settings dialog paging + password edit state
static int g_settingsPage = 1; // 1 = main settings, 2 = password settings
static int g_pwdEditTarget = 0; // 1 = setting pwd, 2 = bookkeeping pwd

// Bet settings variables
static int g_betMode = 0; // 0=5 Line, 1=10 Line
static int g_minBetIndex = 0; // Current index in 5¢ bet steps array
static int g_maxBetIndex = 0; // Current index in 5¢ bet steps array
static int g_minBetIndex10 = 0; // Current index in 10¢ bet steps array
static int g_maxBetIndex10 = 0; // Current index in 10¢ bet steps array
static int g_currentBetSteps5[20]; // Current game's 5¢ bet steps
static int g_currentBetSteps10[20]; // Current game's 10¢ bet steps
static int g_currentBetStepsCount5 = 0; // Number of valid 5¢ steps
static int g_currentBetStepsCount10 = 0; // Number of valid 10¢ steps
static bool g_hasBetSteps10 = false; // Whether game has 10¢ betting

// User-facing limits for min/max bet edits (values are cents, same as bet step arrays).
static const int kUserMinBetCeilingCents = 20;
static const int kUserMaxBetFloorCents = 100;

// Game list
// Game names are now managed by PlayDB
static int g_gameCount = 0;

// Password change variables
static wchar_t g_settingPwdEntry[8] = {0}; // Currently generated setting password (4 digits + null)
static wchar_t g_bookkeepingPwdEntry[8] = {0}; // Currently generated bookkeeping password (4 digits + null)
static bool g_settingPwdVisible = false; // Whether setting password is currently visible
static bool g_bookkeepingPwdVisible = false; // Whether bookkeeping password is currently visible

// Helper function to get game name from PlayDB and convert to wide string
wstring GetGameNameFromPlayDB(int index) {
    PlayDB& playDB = PlayDB::GetInstance();
    string gameName = playDB.GetGameName(index);
    
    // Convert string to wstring
    wstring wGameName(gameName.begin(), gameName.end());
    return wGameName;
}

// Helper function to format cent values as Euro with German number formatting
wstring FormatCentAsEuro(double centValue) {
    // Convert cents to euros (divide by 100)
    double euroValue = centValue / 100.0;
    
    // Handle zero case
    if (euroValue == 0.0) {
        return L"0";
    }
    
    // Convert to string with 2 decimal places
    wchar_t buffer[64];
    swprintf_s(buffer, L"%.2f", euroValue);
    
    wstring result(buffer);
    
    // Apply German number formatting:
    // - Replace decimal point with comma
    // - Add thousand separators (dots)
    
    // Find the decimal point
    size_t decimalPos = result.find(L'.');
    if (decimalPos != wstring::npos) {
        // Replace decimal point with comma
        result[decimalPos] = L',';
        
        // Add thousand separators to the integer part (must not treat '-' as a digit)
        wstring integerPart = result.substr(0, decimalPos);
        wstring decimalPart = result.substr(decimalPos);
        bool negative = !integerPart.empty() && integerPart[0] == L'-';
        if (negative) {
            integerPart = integerPart.substr(1);
        }
        
        wstring formattedInteger;
        int count = 0;
        for (int i = (int)integerPart.length() - 1; i >= 0; i--) {
            if (count > 0 && count % 3 == 0) {
                formattedInteger = L"." + formattedInteger;
            }
            formattedInteger = integerPart[i] + formattedInteger;
            count++;
        }
        if (negative) {
            formattedInteger = L"-" + formattedInteger;
        }
        
        result = formattedInteger + decimalPart;
    }
    
    return result;
}

// Helper function to update bet value display
void UpdateBetValueDisplay(HWND hDlg, int row, int value) {
    wchar_t buffer[32];
    swprintf_s(buffer, L"%d", value);
    if (row >= 0 && row < 3) {
        SetDlgItemText(hDlg, IDC_BET_ROW1_VALUE + row * 3, buffer);
    }
}

// Helper function to update variant display
void UpdateVariantDisplay(HWND hDlg) {
    int idx = g_currentVariant;
    if (idx < 0 || idx >= g_variantCount) idx = g_variantDefaultIndex;
    g_currentVariant = idx;
    SetDlgItemText(hDlg, IDC_VARIANT_VALUE, g_variantNames[idx]);

    // Disable left arrow at first variant (A) and right arrow at last variant (C).
    HWND hLeft = GetDlgItem(hDlg, IDC_VARIANT_LEFT);
    HWND hRight = GetDlgItem(hDlg, IDC_VARIANT_RIGHT);
    if (hLeft) {
        EnableWindow(hLeft, idx > 0);
    }
    if (hRight) {
        EnableWindow(hRight, idx < g_variantCount - 1);
    }
}

// Forward declarations
void LoadGameBetInfo(int gameIndex);
void UpdateBetSettingsDisplay(HWND hDlg);
void SaveGameBetInfo(int gameIndex);
void SaveVariantInfo();

// Helper function to update selected game display
void UpdateSelectedGameDisplay(HWND hDlg) {
    wstring gameName = GetGameNameFromPlayDB(g_selectedGame);
    SetDlgItemText(hDlg, IDC_SELECTED_GAME, gameName.c_str());
    
    // Load bet information for the selected game
    LoadGameBetInfo(g_selectedGame);
    UpdateBetSettingsDisplay(hDlg);
}

// Helper function to load bet information for a specific game
void LoadGameBetInfo(int gameIndex) {
    PlayDB& playDB = PlayDB::GetInstance();
    
    // Get the game name from PlayDB
    string gameName = playDB.GetGameName(gameIndex);
    
    int i = playDB.GetGameID(gameName);
    if (i != -1) {
        // Load bet steps for this game
        int betSteps5[20], betSteps10[20];
        int betMin5, betMax5, betMin10, betMax10;
        
        playDB.GetBetInfo(i, betSteps5, betSteps10, betMin5, betMax5, betMin10, betMax10);
        
        // Copy bet steps to global arrays
        for (int j = 0; j < 20; j++) {
            g_currentBetSteps5[j] = betSteps5[j];
            g_currentBetSteps10[j] = betSteps10[j];
        }
        
        // Count valid bet steps
        g_currentBetStepsCount5 = 0;
        g_currentBetStepsCount10 = 0;
        for (int j = 0; j < 20; j++) {
            if (betSteps5[j] > 0) g_currentBetStepsCount5++;
            if (betSteps10[j] > 0) g_currentBetStepsCount10++;
        }
        
        // Check if game has 10¢ betting
        g_hasBetSteps10 = (g_currentBetStepsCount10 > 0);
        
        // Set initial bet mode (default to 5¢ if available)
        if(g_currentBetStepsCount5 == 0 && g_currentBetStepsCount10 > 0)
			g_betMode = 1; // Default to 10¢ mode
		else
			g_betMode = 0; // Default to 5¢ mode
        
        // Find min/max indices based on actual database values for 5¢ mode
        g_minBetIndex = 0;
        g_maxBetIndex = 0;
        
        // Find the index of the min value in the 5¢ bet steps array
        for (int j = 0; j < g_currentBetStepsCount5; j++) {
            if (betSteps5[j] == betMin5) {
                g_minBetIndex = j;
                break;
            }
        }
        
        // Find the index of the max value in the 5¢ bet steps array
        for (int j = 0; j < g_currentBetStepsCount5; j++) {
            if (betSteps5[j] == betMax5) {
                g_maxBetIndex = j;
                break;
            }
        }
        
        // Store the 10¢ min/max indices as well
        g_minBetIndex10 = 0;
        g_maxBetIndex10 = 0;
        
        if (g_hasBetSteps10) {
            // Find the index of the min value in the 10¢ bet steps array
            for (int j = 0; j < g_currentBetStepsCount10; j++) {
                if (betSteps10[j] == betMin10) {
                    g_minBetIndex10 = j;
                    break;
                }
            }
            
            // Find the index of the max value in the 10¢ bet steps array
            for (int j = 0; j < g_currentBetStepsCount10; j++) {
                if (betSteps10[j] == betMax10) {
                    g_maxBetIndex10 = j;
                    break;
                }
            }
        }
        
        // Update display values - we'll call this from the dialog handler
        // UpdateBetSettingsDisplay() will be called from UpdateSelectedGameDisplay()
    }
}

// Helper function to update bet settings display
void UpdateBetSettingsDisplay(HWND hDlg) {
    // Update bet mode display (Row 1)
    const bool has5Line = (g_currentBetStepsCount5 > 0);
    const bool has10Line = g_hasBetSteps10;
    const bool bothLineModes = has5Line && has10Line;

    wchar_t betModeText[64];
    if (bothLineModes) {
        swprintf_s(betModeText, L"Bet Mode: %s", g_betMode == 0 ? L"5 Line" : L"10 Line");
    } else if (has5Line) {
        swprintf_s(betModeText, L"Bet Mode: 5 Line");
    } else if (has10Line) {
        swprintf_s(betModeText, L"Bet Mode: 10 Line");
    } else {
        swprintf_s(betModeText, L"Bet Mode: —");
    }
    SetDlgItemText(hDlg, IDC_BET_ROW1_VALUE, betModeText);

    BOOL enableModeLeft = FALSE;
    BOOL enableModeRight = FALSE;
    if (bothLineModes) {
        enableModeLeft = (g_betMode != 0);
        enableModeRight = (g_betMode == 0);
    }
    HWND hModeL = GetDlgItem(hDlg, IDC_BET_ROW1_LEFT);
    HWND hModeR = GetDlgItem(hDlg, IDC_BET_ROW1_RIGHT);
    if (hModeL) EnableWindow(hModeL, enableModeLeft);
    if (hModeR) EnableWindow(hModeR, enableModeRight);

    // For display only: when only one line mode exists, show that mode's steps (g_betMode may stay 0).
    int displayBetMode = g_betMode;
    if (!bothLineModes) {
        if (has5Line) {
            displayBetMode = 0;
        } else if (has10Line) {
            displayBetMode = 1;
        } else {
            displayBetMode = 0;
        }
    }
    
    // Update min bet display (Row 2) - use correct indices based on bet mode
    int* currentSteps = (displayBetMode == 0) ? g_currentBetSteps5 : g_currentBetSteps10;
    int currentCount = (displayBetMode == 0) ? g_currentBetStepsCount5 : g_currentBetStepsCount10;
    int minIndex = (displayBetMode == 0) ? g_minBetIndex : g_minBetIndex10;
    int maxIndex = (displayBetMode == 0) ? g_maxBetIndex : g_maxBetIndex10;
    
    if (minIndex < currentCount) {
        wchar_t minText[32];
        swprintf_s(minText, L"Min: %d", currentSteps[minIndex]);
        SetDlgItemText(hDlg, IDC_BET_ROW2_VALUE, minText);
    }
    
    // Update max bet display (Row 3)
    if (maxIndex < currentCount) {
        wchar_t maxText[32];
        swprintf_s(maxText, L"Max: %d", currentSteps[maxIndex]);
        SetDlgItemText(hDlg, IDC_BET_ROW3_VALUE, maxText);
    }

    // Enable/disable min/max arrow buttons at limits (and when no further step is valid).
    BOOL enableMinLeft = FALSE;
    BOOL enableMinRight = FALSE;
    BOOL enableMaxLeft = FALSE;
    BOOL enableMaxRight = FALSE;
    if (currentCount > 0 && minIndex >= 0 && maxIndex >= 0 && minIndex < currentCount && maxIndex < currentCount) {
        enableMinLeft = (minIndex > 0);
        enableMinRight = (minIndex < maxIndex - 1) && (minIndex + 1 < currentCount)
            && (currentSteps[minIndex + 1] <= kUserMinBetCeilingCents);
        enableMaxLeft = (maxIndex > minIndex + 1) && (currentSteps[maxIndex - 1] >= kUserMaxBetFloorCents);
        enableMaxRight = (maxIndex < currentCount - 1);
    }
    HWND hMinL = GetDlgItem(hDlg, IDC_BET_ROW2_LEFT);
    HWND hMinR = GetDlgItem(hDlg, IDC_BET_ROW2_RIGHT);
    HWND hMaxL = GetDlgItem(hDlg, IDC_BET_ROW3_LEFT);
    HWND hMaxR = GetDlgItem(hDlg, IDC_BET_ROW3_RIGHT);
    if (hMinL) EnableWindow(hMinL, enableMinLeft);
    if (hMinR) EnableWindow(hMinR, enableMinRight);
    if (hMaxL) EnableWindow(hMaxL, enableMaxLeft);
    if (hMaxR) EnableWindow(hMaxR, enableMaxRight);
}

static bool ApplyBetSettingsToAllGames(HWND hDlg) {
    // Capture desired settings from currently selected game context.
    const int desiredMode = g_betMode; // 0=5 Line, 1=10 Line

    int* currentSteps = (desiredMode == 0) ? g_currentBetSteps5 : g_currentBetSteps10;
    int currentCount = (desiredMode == 0) ? g_currentBetStepsCount5 : g_currentBetStepsCount10;
    int minIndex = (desiredMode == 0) ? g_minBetIndex : g_minBetIndex10;
    int maxIndex = (desiredMode == 0) ? g_maxBetIndex : g_maxBetIndex10;
    if (currentCount <= 0 || minIndex < 0 || maxIndex < 0 || minIndex >= currentCount || maxIndex >= currentCount) {
        MessageBox(hDlg, L"Invalid bet settings", L"Error", MB_OK | MB_ICONWARNING);
        return false;
    }
    int desiredMin = currentSteps[minIndex];
    int desiredMax = currentSteps[maxIndex];
    if (desiredMin > desiredMax) {
        int t = desiredMin; desiredMin = desiredMax; desiredMax = t;
    }

    PlayDB& playDB = PlayDB::GetInstance();
    const int originalSelectedGame = g_selectedGame;
    const int originalBetMode = g_betMode;
    const int originalMin5 = g_minBetIndex, originalMax5 = g_maxBetIndex;
    const int originalMin10 = g_minBetIndex10, originalMax10 = g_maxBetIndex10;

    const int totalGames = playDB.GetGameCount();
    for (int gameIndex = 0; gameIndex < totalGames; gameIndex++) {
        string gameName = playDB.GetGameName(gameIndex);
        int i = playDB.GetGameID(gameName);
        if (i == -1) continue;

        int betSteps5[20], betSteps10[20];
        int betMin5, betMax5, betMin10, betMax10;
        playDB.GetBetInfo(i, betSteps5, betSteps10, betMin5, betMax5, betMin10, betMax10);

        // Build sorted list of valid bet step values for target mode
        std::vector<int> steps;
        steps.reserve(20);
        if (desiredMode == 0) {
            for (int j = 0; j < 20; j++) if (betSteps5[j] > 0) steps.push_back(betSteps5[j]);
        } else {
            for (int j = 0; j < 20; j++) if (betSteps10[j] > 0) steps.push_back(betSteps10[j]);
        }
        if (steps.empty()) {
            // Game doesn't support desired bet mode (e.g., no 10-line); skip.
            continue;
        }
        std::sort(steps.begin(), steps.end());
        steps.erase(std::unique(steps.begin(), steps.end()), steps.end());

        // Clamp desiredMin/desiredMax to this game's allowed range, and snap to valid steps.
        int gameMin = steps.front();
        int gameMax = steps.back();
        int clampedMin = (desiredMin < gameMin) ? gameMin : desiredMin;
        int clampedMax = (desiredMax > gameMax) ? gameMax : desiredMax;
        if (clampedMin > clampedMax) clampedMin = clampedMax;

        int snappedMin = gameMin;
        {
            auto it = std::lower_bound(steps.begin(), steps.end(), clampedMin);
            snappedMin = (it == steps.end()) ? gameMax : *it;
        }
        int snappedMax = gameMax;
        {
            auto it = std::upper_bound(steps.begin(), steps.end(), clampedMax);
            if (it == steps.begin()) snappedMax = gameMin;
            else { --it; snappedMax = *it; }
        }
        if (snappedMin > snappedMax) snappedMin = snappedMax;

        if (desiredMode == 0) {
            betMin5 = snappedMin;
            betMax5 = snappedMax;
        } else {
            betMin10 = snappedMin;
            betMax10 = snappedMax;
        }

        playDB.SetBetInfo(i, betSteps5, betSteps10, betMin5, betMax5, betMin10, betMax10);
    }

    // Restore UI to original selected game state.
    g_selectedGame = originalSelectedGame;
    LoadGameBetInfo(g_selectedGame);
    //g_betMode = originalBetMode;
    g_minBetIndex = originalMin5; g_maxBetIndex = originalMax5;
    g_minBetIndex10 = originalMin10; g_maxBetIndex10 = originalMax10;
    UpdateSelectedGameDisplay(hDlg);
    UpdateBetSettingsDisplay(hDlg);

    DebugPrintf("Bet settings saved to ALL games (mode=%d)\n", desiredMode);
    return true;
}


// Helper function to save bet information for a specific game
void SaveGameBetInfo(int gameIndex) {
    PlayDB& playDB = PlayDB::GetInstance();
    
    // Get the game name from PlayDB
    string gameName = playDB.GetGameName(gameIndex);
    
    // Find the game in PlayDB settings using the new GetGameID function
    int i = playDB.GetGameID(gameName);
    if (i != -1) {
        // Get current bet info
        int betSteps5[20], betSteps10[20];
        int betMin5, betMax5, betMin10, betMax10;
        
        playDB.GetBetInfo(i, betSteps5, betSteps10, betMin5, betMax5, betMin10, betMax10);
        
        // Update min/max values based on current selection
        if (g_betMode == 0) { // 5¢ mode
            betMin5 = g_currentBetSteps5[g_minBetIndex];
            betMax5 = g_currentBetSteps5[g_maxBetIndex];
        } else { // 10¢ mode
            betMin10 = g_currentBetSteps10[g_minBetIndex10];
            betMax10 = g_currentBetSteps10[g_maxBetIndex10];
        }
        
        // Save back to PlayDB (will be saved to database when dialog closes)
        playDB.SetBetInfo(i, betSteps5, betSteps10, betMin5, betMax5, betMin10, betMax10);
    }
}

// Helper function to save variant information
void SaveVariantInfo() {
    PlayDB& playDB = PlayDB::GetInstance();

    int idx = g_currentVariant;
    if (idx < 0 || idx >= g_variantCount) idx = g_variantDefaultIndex;
    // Set the current variant in PlayDB (will be saved to database when dialog closes)
    playDB.SetGameVariant((PlayDB::GameVariant)idx);
}

// Helper function to reset all values to defaults
void ResetToDefaults(HWND hDlg) {
    g_betValues[0] = 1;
    g_betValues[1] = 5;
    g_betValues[2] = 10;
    // Default variant is B when VARIANTBC_ACTIVE is enabled, otherwise A.
    g_currentVariant = g_variantDefaultIndex;
    g_selectedGame = 0;
    
    // Load first game's bet info
    LoadGameBetInfo(0);
    
    // Update displays
    for (int i = 0; i < 3; i++) {
        UpdateBetValueDisplay(hDlg, i, g_betValues[i]);
    }
    UpdateVariantDisplay(hDlg);
    UpdateSelectedGameDisplay(hDlg);
    
    // Reset list box selection
    SendDlgItemMessage(hDlg, IDC_GAMES_LIST, LB_SETCURSEL, 0, 0);
}

// Helper function to validate password
bool ValidatePassword(const wchar_t* password, bool isBookkeeping = false) {
    PlayDB& playDB = PlayDB::GetInstance();
    string targetPassword;
    
    if (isBookkeeping) {
        // Use bookkeeping password for Ctrl+H and Ctrl+N
        targetPassword = playDB.GetBookkeepingPassword();
    } else {
        // Use settings password for Ctrl+O
        targetPassword = playDB.GetSettingPassword();
    }
    
    // Convert string to wide string for comparison
    wstring wTargetPassword(targetPassword.begin(), targetPassword.end());
    return wcscmp(password, wTargetPassword.c_str()) == 0;
}

// Helper function to generate random numbers for buttons (keep positions fixed)
void GenerateRandomDigitNumbers() {
    // Initialize numbers array
    for (int i = 0; i < 10; i++) {
        g_digitPositions[i] = i;
    }
    
    // Shuffle the numbers using Fisher-Yates algorithm
    for (int i = 9; i > 0; i--) {
        int j = myRandom() % (i + 1);
        int temp = g_digitPositions[i];
        g_digitPositions[i] = g_digitPositions[j];
        g_digitPositions[j] = temp;
    }
}

// Helper function to add digit to password
void AddDigitToPassword(HWND hDlg, int digit) {
    int len = (int)wcslen(g_enteredPassword);
    const int maxLen = g_licenseDialogMode ? 12 : 10;
    if (len < maxLen) {
        g_enteredPassword[len] = L'0' + digit;
        g_enteredPassword[len + 1] = L'\0';
        if (g_licenseDialogMode) {
            SetDlgItemText(hDlg, IDC_PASSWORD_DISPLAY, g_enteredPassword);
        } else {
            wchar_t display[32];
            for (int i = 0; i < len + 1; i++) {
                display[i] = L'*';
            }
            display[len + 1] = L'\0';
            SetDlgItemText(hDlg, IDC_PASSWORD_DISPLAY, display);
        }
    }
}

// Helper function to clear password
void ClearPassword(HWND hDlg) {
    g_enteredPassword[0] = L'\0';
    SetDlgItemText(hDlg, IDC_PASSWORD_DISPLAY, L"");
}

// Password Change Helper Functions
void GenerateRandomSettingPwd(HWND hDlg) {
    // Generate random 4-digit password
    wchar_t password[8];
    for (int i = 0; i < 4; i++) {
        password[i] = L'0' + (myRandom() % 10);
    }
    password[4] = L'\0';
    
    // Store the password
    wcscpy_s(g_settingPwdEntry, password);
    
    // Show the password in display
    SetDlgItemText(hDlg, IDC_SETTING_PWD_DISPLAY, password);
    g_settingPwdVisible = true;
    
    // Set timer to hide password after 5 seconds (5000ms)
    SetTimer(hDlg, TIMER_SETTING_PWD, 5000, NULL);
}

void GenerateRandomBookkeepingPwd(HWND hDlg) {
    // Generate random 4-digit password
    wchar_t password[8];
    for (int i = 0; i < 4; i++) {
        password[i] = L'0' + (myRandom() % 10);
    }
    password[4] = L'\0';
    
    // Store the password
    wcscpy_s(g_bookkeepingPwdEntry, password);
    
    // Show the password in display
    SetDlgItemText(hDlg, IDC_BOOKKEEPING_PWD_DISPLAY, password);
    g_bookkeepingPwdVisible = true;
    
    // Set timer to hide password after 5 seconds (5000ms)
    SetTimer(hDlg, TIMER_BOOKKEEPING_PWD, 5000, NULL);
}

void HideSettingPwd(HWND hDlg) {
    // Convert to asterisks
    SetDlgItemText(hDlg, IDC_SETTING_PWD_DISPLAY, L"****");
    g_settingPwdVisible = false;
    KillTimer(hDlg, TIMER_SETTING_PWD);
}

void HideBookkeepingPwd(HWND hDlg) {
    // Convert to asterisks
    SetDlgItemText(hDlg, IDC_BOOKKEEPING_PWD_DISPLAY, L"****");
    g_bookkeepingPwdVisible = false;
    KillTimer(hDlg, TIMER_BOOKKEEPING_PWD);
}

void ClearSettingPwd(HWND hDlg) {
    g_settingPwdEntry[0] = L'\0';
    g_settingPwdVisible = false;
    KillTimer(hDlg, TIMER_SETTING_PWD);
    SetDlgItemText(hDlg, IDC_SETTING_PWD_DISPLAY, L"");
}

void ClearBookkeepingPwd(HWND hDlg) {
    g_bookkeepingPwdEntry[0] = L'\0';
    g_bookkeepingPwdVisible = false;
    KillTimer(hDlg, TIMER_BOOKKEEPING_PWD);
    SetDlgItemText(hDlg, IDC_BOOKKEEPING_PWD_DISPLAY, L"");
}

static void AppendPwdDigit(HWND hDlg, int target, int digit) {
    wchar_t* buf = (target == 1) ? g_settingPwdEntry : g_bookkeepingPwdEntry;
    const int maxLen = 4;
    int len = (int)wcslen(buf);
    if (len >= maxLen) return;
    buf[len] = (wchar_t)(L'0' + digit);
    buf[len + 1] = L'\0';

    if (target == 1) {
        SetDlgItemText(hDlg, IDC_SETTING_PWD_DISPLAY, buf);
        g_settingPwdVisible = true;
        KillTimer(hDlg, TIMER_SETTING_PWD);
        SetTimer(hDlg, TIMER_SETTING_PWD, 3000, NULL);
    } else {
        SetDlgItemText(hDlg, IDC_BOOKKEEPING_PWD_DISPLAY, buf);
        g_bookkeepingPwdVisible = true;
        KillTimer(hDlg, TIMER_BOOKKEEPING_PWD);
        SetTimer(hDlg, TIMER_BOOKKEEPING_PWD, 3000, NULL);
    }
}

static void BackspacePwd(HWND hDlg, int target) {
    wchar_t* buf = (target == 1) ? g_settingPwdEntry : g_bookkeepingPwdEntry;
    int len = (int)wcslen(buf);
    if (len <= 0) return;
    buf[len - 1] = L'\0';
    if (target == 1) {
        SetDlgItemText(hDlg, IDC_SETTING_PWD_DISPLAY, buf);
        g_settingPwdVisible = true;
        KillTimer(hDlg, TIMER_SETTING_PWD);
        SetTimer(hDlg, TIMER_SETTING_PWD, 5000, NULL);
    } else {
        SetDlgItemText(hDlg, IDC_BOOKKEEPING_PWD_DISPLAY, buf);
        g_bookkeepingPwdVisible = true;
        KillTimer(hDlg, TIMER_BOOKKEEPING_PWD);
        SetTimer(hDlg, TIMER_BOOKKEEPING_PWD, 5000, NULL);
    }
}

static void ClearPwd(HWND hDlg, int target) {
    if (target == 1) ClearSettingPwd(hDlg);
    else ClearBookkeepingPwd(hDlg);
}

void IncrementSettingPwd(HWND hDlg) {
    // If no password is set, initialize to 0000
    if (wcslen(g_settingPwdEntry) != 4) {
        wcscpy_s(g_settingPwdEntry, L"0000");
    }
    
    // Convert password to integer, increment, and convert back
    int pwdValue = _wtoi(g_settingPwdEntry);
    pwdValue++;
    if (pwdValue > 9999) pwdValue = 0; // Wrap around
    swprintf_s(g_settingPwdEntry, L"%04d", pwdValue);
    
    // Show the password
    SetDlgItemText(hDlg, IDC_SETTING_PWD_DISPLAY, g_settingPwdEntry);
    g_settingPwdVisible = true;
    
    // Set timer to hide password after 5 seconds
    KillTimer(hDlg, TIMER_SETTING_PWD);
    SetTimer(hDlg, TIMER_SETTING_PWD, 5000, NULL);
}

void DecrementSettingPwd(HWND hDlg) {
    // If no password is set, initialize to 9999
    if (wcslen(g_settingPwdEntry) != 4) {
        wcscpy_s(g_settingPwdEntry, L"9999");
    }
    
    // Convert password to integer, decrement, and convert back
    int pwdValue = _wtoi(g_settingPwdEntry);
    pwdValue--;
    if (pwdValue < 0) pwdValue = 9999; // Wrap around
    swprintf_s(g_settingPwdEntry, L"%04d", pwdValue);
    
    // Show the password
    SetDlgItemText(hDlg, IDC_SETTING_PWD_DISPLAY, g_settingPwdEntry);
    g_settingPwdVisible = true;
    
    // Set timer to hide password after 5 seconds
    KillTimer(hDlg, TIMER_SETTING_PWD);
    SetTimer(hDlg, TIMER_SETTING_PWD, 5000, NULL);
}

void IncrementBookkeepingPwd(HWND hDlg) {
    // If no password is set, initialize to 0000
    if (wcslen(g_bookkeepingPwdEntry) != 4) {
        wcscpy_s(g_bookkeepingPwdEntry, L"0000");
    }
    
    // Convert password to integer, increment, and convert back
    int pwdValue = _wtoi(g_bookkeepingPwdEntry);
    pwdValue++;
    if (pwdValue > 9999) pwdValue = 0; // Wrap around
    swprintf_s(g_bookkeepingPwdEntry, L"%04d", pwdValue);
    
    // Show the password
    SetDlgItemText(hDlg, IDC_BOOKKEEPING_PWD_DISPLAY, g_bookkeepingPwdEntry);
    g_bookkeepingPwdVisible = true;
    
    // Set timer to hide password after 5 seconds
    KillTimer(hDlg, TIMER_BOOKKEEPING_PWD);
    SetTimer(hDlg, TIMER_BOOKKEEPING_PWD, 5000, NULL);
}

void DecrementBookkeepingPwd(HWND hDlg) {
    // If no password is set, initialize to 9999
    if (wcslen(g_bookkeepingPwdEntry) != 4) {
        wcscpy_s(g_bookkeepingPwdEntry, L"9999");
    }
    
    // Convert password to integer, decrement, and convert back
    int pwdValue = _wtoi(g_bookkeepingPwdEntry);
    pwdValue--;
    if (pwdValue < 0) pwdValue = 9999; // Wrap around
    swprintf_s(g_bookkeepingPwdEntry, L"%04d", pwdValue);
    
    // Show the password
    SetDlgItemText(hDlg, IDC_BOOKKEEPING_PWD_DISPLAY, g_bookkeepingPwdEntry);
    g_bookkeepingPwdVisible = true;
    
    // Set timer to hide password after 5 seconds
    KillTimer(hDlg, TIMER_BOOKKEEPING_PWD);
    SetTimer(hDlg, TIMER_BOOKKEEPING_PWD, 5000, NULL);
}

/// Page 1 / page 2 share one dialog; when hiding, push behind and force hide bit (see PinPasswordLayerBehindSettings).
static void SetSettingsChildVisiblePinned(HWND hDlg, UINT id, bool show)
{
	HWND w = GetDlgItem(hDlg, id);
	if (!w) return;
	if (show) {
		ShowWindow(w, SW_SHOW);
	} else {
		ShowWindow(w, SW_HIDE);
		SetWindowPos(w, HWND_BOTTOM, 0, 0, 0, 0,
			SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_HIDEWINDOW);
	}
}

// Helper function to show/hide main components (settings page 1)
void ShowMainComponents(HWND hDlg, bool show) {
	SetSettingsChildVisiblePinned(hDlg, IDC_GAMES_LIST_TITLE, show);
	SetSettingsChildVisiblePinned(hDlg, IDC_GAMES_LIST, show);
	SetSettingsChildVisiblePinned(hDlg, IDC_GAMES_UP, show);
	SetSettingsChildVisiblePinned(hDlg, IDC_GAMES_DOWN, show);
	SetSettingsChildVisiblePinned(hDlg, IDC_SELECTED_GAME, show);
	SetSettingsChildVisiblePinned(hDlg, IDC_BET_SETTINGS_TITLE, show);
	SetSettingsChildVisiblePinned(hDlg, IDC_BET_SAVE, show);
	SetSettingsChildVisiblePinned(hDlg, IDC_BET_SAVE_ALL, show);

	for (int i = 0; i < 3; i++) {
		SetSettingsChildVisiblePinned(hDlg, IDC_BET_ROW1_LEFT + i * 3, show);
		SetSettingsChildVisiblePinned(hDlg, IDC_BET_ROW1_VALUE + i * 3, show);
		SetSettingsChildVisiblePinned(hDlg, IDC_BET_ROW1_RIGHT + i * 3, show);
	}

#ifdef VARIANTBC_ACTIVE
	// Show full Variants Settings section (group box, label, arrows, Save) on page 1.
	SetSettingsChildVisiblePinned(hDlg, IDC_VARIANTS_TITLE, show);
	SetSettingsChildVisiblePinned(hDlg, IDC_VARIANT_SAVE, show);
	SetSettingsChildVisiblePinned(hDlg, IDC_VARIANT_LEFT, show);
	SetSettingsChildVisiblePinned(hDlg, IDC_VARIANT_RIGHT, show);
	SetSettingsChildVisiblePinned(hDlg, IDC_VARIANT_VALUE, show);
#else
	// Only Variant A exists in this build; hide the entire Variants Settings section.
	SetSettingsChildVisiblePinned(hDlg, IDC_VARIANTS_TITLE, false);
	SetSettingsChildVisiblePinned(hDlg, IDC_VARIANT_SAVE, false);
	SetSettingsChildVisiblePinned(hDlg, IDC_VARIANT_LEFT, false);
	SetSettingsChildVisiblePinned(hDlg, IDC_VARIANT_RIGHT, false);
	SetSettingsChildVisiblePinned(hDlg, IDC_VARIANT_VALUE, false);
#endif
}

static void ShowPasswordSettingsComponents(HWND hDlg, bool show) {
	SetSettingsChildVisiblePinned(hDlg, IDC_PWD_CHANGE_TITLE, show);
	SetSettingsChildVisiblePinned(hDlg, IDC_SETTING_PWD_LABEL, show);
	SetSettingsChildVisiblePinned(hDlg, IDC_SETTING_PWD_DISPLAY, show);
	SetSettingsChildVisiblePinned(hDlg, IDC_SETTING_PWD_SAVE, show);
	SetSettingsChildVisiblePinned(hDlg, IDC_BOOKKEEPING_PWD_LABEL, show);
	SetSettingsChildVisiblePinned(hDlg, IDC_BOOKKEEPING_PWD_DISPLAY, show);
	SetSettingsChildVisiblePinned(hDlg, IDC_BOOKKEEPING_PWD_SAVE, show);

	for (int i = 0; i <= 9; i++) {
		SetSettingsChildVisiblePinned(hDlg, IDC_SETTINGS_PWD_DIGIT_0 + i, show);
		SetSettingsChildVisiblePinned(hDlg, IDC_SETTINGS_BK_DIGIT_0 + i, show);
	}
	SetSettingsChildVisiblePinned(hDlg, IDC_SETTINGS_PWD_BACKSPACE, show);
	SetSettingsChildVisiblePinned(hDlg, IDC_SETTINGS_PWD_CLEAR, show);
	SetSettingsChildVisiblePinned(hDlg, IDC_SETTINGS_BK_BACKSPACE, show);
	SetSettingsChildVisiblePinned(hDlg, IDC_SETTINGS_BK_CLEAR, show);
}

static void ShowSettingsCommonComponents(HWND hDlg, bool show) {
    int visibility = show ? SW_SHOW : SW_HIDE;
    ShowWindow(GetDlgItem(hDlg, IDC_RESET_BUTTON), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_CLOSE_BUTTON), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_SETTINGS_PAGE_1), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_SETTINGS_PAGE_2), visibility);
}

static int g_saveBannerElapsedMs = 0;
static bool g_saveBannerBlinkVisible = true;

static void ShowSavedNotification(HWND hDlg) {
    HWND hBanner = GetDlgItem(hDlg, IDC_SETTINGS_SAVED_BANNER);
    if (!hBanner) {
        return;
    }
    KillTimer(hDlg, TIMER_SAVE_BANNER);
    g_saveBannerElapsedMs = 0;
    g_saveBannerBlinkVisible = true;
    SetWindowText(hBanner, L"Saved Correctly");
    ShowWindow(hBanner, SW_SHOW);
    SetWindowPos(hBanner, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
    SetTimer(hDlg, TIMER_SAVE_BANNER, 500, NULL);
}

static void RedrawFullSettingsDialog(HWND hDlg)
{
	if (!hDlg || !IsWindow(hDlg))
		return;
	InvalidateRect(hDlg, NULL, TRUE);
	RedrawWindow(hDlg, NULL, NULL, RDW_INVALIDATE | RDW_ERASE | RDW_FRAME | RDW_UPDATENOW | RDW_ALLCHILDREN);
}

/// Shared by WM_PAINT and WM_ERASEBKGND. Returning TRUE from WM_ERASEBKGND without drawing left holes when
/// child controls were hidden (page 1/2 switch): stale pixels stayed until repainted.
static void PaintSettingsClientBackground(HWND hDlg, HDC hdc)
{
	if (!g_hBackgroundBitmap)
		return;
	RECT clientRect{};
	GetClientRect(hDlg, &clientRect);
	HDC hdcMem = CreateCompatibleDC(hdc);
	if (!hdcMem)
		return;
	HBITMAP hOldBitmap = (HBITMAP)SelectObject(hdcMem, g_hBackgroundBitmap);
	BITMAP bmp{};
	GetObject(g_hBackgroundBitmap, sizeof(BITMAP), &bmp);
	StretchBlt(hdc, 0, 0, clientRect.right, clientRect.bottom,
		hdcMem, 0, 0, bmp.bmWidth, bmp.bmHeight, SRCCOPY);
	SelectObject(hdcMem, hOldBitmap);
	DeleteDC(hdcMem);
}

static void SetSettingsPage(HWND hDlg, int page) {
    if (page < 1) page = 1;
    if (page > 2) page = 2;
    g_settingsPage = page;

    const bool showPage1 = (g_settingsPage == 1);
    const bool showPage2 = (g_settingsPage == 2);

    ShowMainComponents(hDlg, showPage1);
    ShowPasswordSettingsComponents(hDlg, showPage2);
    ShowSettingsCommonComponents(hDlg, true);

    EnableWindow(GetDlgItem(hDlg, IDC_SETTINGS_PAGE_1), !showPage1);
    EnableWindow(GetDlgItem(hDlg, IDC_SETTINGS_PAGE_2), !showPage2);

#ifdef VARIANTBC_ACTIVE
    // Refresh variant display + arrow enabled state whenever page 1 becomes visible.
    if (showPage1) {
        UpdateVariantDisplay(hDlg);
    }
#endif

	RedrawFullSettingsDialog(hDlg);
}

static void ApplyMerkurLicenseValidUntilLine(HWND hDlg, int idValidUntilCtrl)
{
	HWND hw = GetDlgItem(hDlg, idValidUntilCtrl);
	if (!hw)
		return;
	wchar_t buf[192];
	if (TimeLicense::TryGetValidUntilDisplayText(buf, sizeof(buf) / sizeof(buf[0]))) {
		SetWindowTextW(hw, buf);
		ShowWindow(hw, SW_SHOW);
	} else {
		SetWindowTextW(hw, L"");
		ShowWindow(hw, SW_HIDE);
	}
}

/// After hiding the password keypad, push those controls behind the settings UI so they cannot paint or
/// receive hits above the main panel (stale pixels / z-order when switching to the settings pages).
static void PinPasswordLayerBehindSettings(HWND hDlg)
{
	static const UINT kPwdChrome[] = {
		IDC_PASSWORD_TITLE, IDC_PASSWORD_DISPLAY, IDC_PASSWORD_CLEAR, IDC_PASSWORD_OK,
		IDC_PASSWORD_VERSION, IDC_LICENSE_VALID_UNTIL, IDC_LICENSE_MACHINE_ID, IDC_LICENSE_CURRENT_DATE,
		IDC_LICENSE_STATUS,
	};
	for (UINT id : kPwdChrome) {
		HWND w = GetDlgItem(hDlg, id);
		if (w)
			SetWindowPos(w, HWND_BOTTOM, 0, 0, 0, 0,
				SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_HIDEWINDOW);
	}
	for (int i = 0; i < 10; i++) {
		HWND w = GetDlgItem(hDlg, IDC_PASSWORD_BTN_0 + i);
		if (w)
			SetWindowPos(w, HWND_BOTTOM, 0, 0, 0, 0,
				SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_HIDEWINDOW);
	}
}

// Helper function to show/hide password components
void ShowPasswordComponents(HWND hDlg, bool show) {
    int visibility = show ? SW_SHOW : SW_HIDE;
    
    ShowWindow(GetDlgItem(hDlg, IDC_PASSWORD_TITLE), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_PASSWORD_DISPLAY), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_PASSWORD_CLEAR), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_PASSWORD_OK), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_PASSWORD_VERSION), visibility);
    HWND hLicMid = GetDlgItem(hDlg, IDC_LICENSE_MACHINE_ID);
    if (hLicMid) {
        ShowWindow(hLicMid, visibility);
        if (show) {
            wchar_t midLine[64];
            swprintf_s(midLine, L"Machine ID: %08u", TimeLicense::GetMachineId8());
            SetWindowTextW(hLicMid, midLine);
        }
    }
    HWND hLicVu = GetDlgItem(hDlg, IDC_LICENSE_VALID_UNTIL);
    if (hLicVu) {
        ShowWindow(hLicVu, visibility);
        if (show)
            ApplyMerkurLicenseValidUntilLine(hDlg, IDC_LICENSE_VALID_UNTIL);
    }
    HWND hLicDate = GetDlgItem(hDlg, IDC_LICENSE_CURRENT_DATE);
    if (hLicDate)
        ShowWindow(hLicDate, (show && g_licenseDialogMode) ? SW_SHOW : SW_HIDE);
    HWND hLicSt = GetDlgItem(hDlg, IDC_LICENSE_STATUS);
    if (hLicSt)
        ShowWindow(hLicSt, (show && g_licenseDialogMode) ? SW_SHOW : SW_HIDE);
    
    // Show/hide digit buttons
    for (int i = 0; i < 10; i++) {
        ShowWindow(GetDlgItem(hDlg, IDC_PASSWORD_BTN_0 + i), visibility);
    }

	if (!show) {
		PinPasswordLayerBehindSettings(hDlg);
		RedrawFullSettingsDialog(hDlg);
	}
}

// Bookkeeping Dialog Helper Functions
void GenerateRandomDigitNumbersBK() {
    // Initialize numbers array
    for (int i = 0; i < 10; i++) {
        g_bkDigitPositions[i] = i;
    }
    
    // Shuffle the numbers using Fisher-Yates algorithm
    for (int i = 9; i > 0; i--) {
        int j = myRandom() % (i + 1);
        int temp = g_bkDigitPositions[i];
        g_bkDigitPositions[i] = g_bkDigitPositions[j];
        g_bkDigitPositions[j] = temp;
    }
}

void AddDigitToPasswordBK(HWND hDlg, int digit) {
    int len = wcslen(g_bkEnteredPassword);
    if (len < 10) { // Limit password length
        g_bkEnteredPassword[len] = L'0' + digit;
        g_bkEnteredPassword[len + 1] = L'\0';
        
        // Update display with asterisks
        wchar_t display[32];
        for (int i = 0; i < len + 1; i++) {
            display[i] = L'*';
        }
        display[len + 1] = L'\0';
        SetDlgItemText(hDlg, IDC_BK_PASSWORD_DISPLAY, display);
    }
}

void ClearPasswordBK(HWND hDlg) {
    g_bkEnteredPassword[0] = L'\0';
    SetDlgItemText(hDlg, IDC_BK_PASSWORD_DISPLAY, L"");
}

void PopulateBookkeepingData(HWND hDlg) {
    PlayDB& playDB = PlayDB::GetInstance();
    
    // Update title based on mode
    wstring titleText = g_bkIsMainBookkeeping ? L"Main Book Keeping" : L"Sub Book Keeping";
    SetDlgItemText(hDlg, IDC_BK_LEFT_TITLE, titleText.c_str());
    
    // Update Begin date
    string beginDate = g_bkIsMainBookkeeping ? playDB.GetMainBookBeginDate() : playDB.GetSubBookBeginDate();
    wstring wBeginDate(beginDate.begin(), beginDate.end());
    SetDlgItemText(hDlg, IDC_BK_BEGIN_DATE, wBeginDate.c_str());
    
    // Update Total In and Total Out
    double totalIn = g_bkIsMainBookkeeping ? playDB.GetMainBookTotalIn() : playDB.GetSubBookTotalIn();
    double totalOut = g_bkIsMainBookkeeping ? playDB.GetMainBookTotalOut() : playDB.GetSubBookTotalOut();
    wstring totalInText = FormatCentAsEuro(totalIn);
    wstring totalOutText = FormatCentAsEuro(totalOut);
    SetDlgItemText(hDlg, IDC_BK_TOTAL_IN_VALUE, totalInText.c_str());
    SetDlgItemText(hDlg, IDC_BK_TOTAL_OUT_VALUE, totalOutText.c_str());
    
    // Calculate and update remaining value (totalIn - totalOut)
    double remaining = totalIn - totalOut;
    wstring remainingText = FormatCentAsEuro(remaining);
    SetDlgItemText(hDlg, IDC_BK_REMAINING_VALUE, remainingText.c_str());
    
    // Calculate totals for played points, won points, and spins
    double totalPlayedPoints = 0.0;
    double totalWonPoints = 0.0;
    int totalSpins = 0;
    
    // Clear existing listbox data
    SendDlgItemMessage(hDlg, IDC_BK_GAME_LIST, LB_RESETCONTENT, 0, 0);
    SendDlgItemMessage(hDlg, IDC_BK_PLAYED_LIST, LB_RESETCONTENT, 0, 0);
    SendDlgItemMessage(hDlg, IDC_BK_WON_LIST, LB_RESETCONTENT, 0, 0);
    SendDlgItemMessage(hDlg, IDC_BK_SPINS_LIST, LB_RESETCONTENT, 0, 0);
    
    // Populate listboxes with actual data
    for (int i = 0; i < MAX_GAME_COUNT; i++) {
        string gameID = g_bkIsMainBookkeeping ? playDB.GetMainBookGameID(i) : playDB.GetSubBookGameID(i);
        if (!gameID.empty()) {
            // Add game name
            wstring gameName(gameID.begin(), gameID.end());
            SendDlgItemMessage(hDlg, IDC_BK_GAME_LIST, LB_ADDSTRING, 0, (LPARAM)gameName.c_str());
            
            // Get game data
            double playedPoints = g_bkIsMainBookkeeping ? playDB.GetMainBookPlayedPoints(i) : playDB.GetSubBookPlayedPoints(i);
            double wonPoints = g_bkIsMainBookkeeping ? playDB.GetMainBookWonPoints(i) : playDB.GetSubBookWonPoints(i);
            int spins = g_bkIsMainBookkeeping ? playDB.GetMainBookSpins(i) : playDB.GetSubBookSpins(i);
            
            // Add played points
            wstring playedText = FormatCentAsEuro(playedPoints);
            SendDlgItemMessage(hDlg, IDC_BK_PLAYED_LIST, LB_ADDSTRING, 0, (LPARAM)playedText.c_str());
            
            // Add won points
            wstring wonText = FormatCentAsEuro(wonPoints);
            SendDlgItemMessage(hDlg, IDC_BK_WON_LIST, LB_ADDSTRING, 0, (LPARAM)wonText.c_str());
            
            // Add spins
            wstring spinsText = to_wstring(spins);
            SendDlgItemMessage(hDlg, IDC_BK_SPINS_LIST, LB_ADDSTRING, 0, (LPARAM)spinsText.c_str());
            
            // Accumulate totals
            totalPlayedPoints += playedPoints;
            totalWonPoints += wonPoints;
            totalSpins += spins;
        }
    }

    // Update summary values
    wstring playedText = FormatCentAsEuro(totalPlayedPoints);
    wstring wonText = FormatCentAsEuro(totalWonPoints);
    wstring spinsText = to_wstring(totalSpins);
    SetDlgItemText(hDlg, IDC_BK_PLAYED_POINTS_VALUE, playedText.c_str());
    SetDlgItemText(hDlg, IDC_BK_WON_POINTS_VALUE, wonText.c_str());
    SetDlgItemText(hDlg, IDC_BK_GAME_SPIN_VALUE, spinsText.c_str());
    
    // Calculate and display percentage
    double percentage = 0.0;
    if (totalPlayedPoints > 0) {
        percentage = (double)totalWonPoints / (double)totalPlayedPoints * 100.0;
    }
    
    // Format percentage with German number formatting (comma as decimal separator)
    wchar_t percentageBuffer[32];
    swprintf_s(percentageBuffer, L"%.2f", percentage);
    wstring percentageText(percentageBuffer);
    // Replace decimal point with comma for German formatting
    size_t decimalPos = percentageText.find(L'.');
    if (decimalPos != wstring::npos) {
        percentageText[decimalPos] = L',';
    }
    percentageText += L"%";
    
    wstring wonWithPercentage = wonText + L" (" + percentageText + L")";
    SetDlgItemText(hDlg, IDC_BK_WON_POINTS_VALUE, wonWithPercentage.c_str());
}

void ShowMainComponentsBK(HWND hDlg, bool show) {
    int visibility = show ? SW_SHOW : SW_HIDE;
    
    // Show/hide all main components
    ShowWindow(GetDlgItem(hDlg, IDC_BK_LEFT_TITLE), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_BK_BEGIN_LABEL), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_BK_BEGIN_DATE), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_BK_TOTAL_IN_LABEL), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_BK_TOTAL_IN_VALUE), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_BK_TOTAL_OUT_LABEL), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_BK_TOTAL_OUT_VALUE), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_BK_HOLD_LABEL), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_BK_REMAINING_VALUE), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_BK_HOLD_SEPARATOR), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_BK_PLAYED_POINTS_LABEL), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_BK_PLAYED_POINTS_VALUE), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_BK_WON_POINTS_LABEL), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_BK_WON_POINTS_VALUE), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_BK_GAME_SPIN_LABEL), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_BK_GAME_SPIN_VALUE), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_BK_DELETE_BUTTON), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_BK_CLOSE_BUTTON), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_BK_RIGHT_TITLE), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_BK_GAME_LABEL), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_BK_PLAYED_LABEL), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_BK_WON_LABEL), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_BK_SPINS_LABEL), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_BK_GAME_LIST), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_BK_PLAYED_LIST), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_BK_WON_LIST), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_BK_SPINS_LIST), visibility);
}

void ShowPasswordComponentsBK(HWND hDlg, bool show) {
    int visibility = show ? SW_SHOW : SW_HIDE;
    
    ShowWindow(GetDlgItem(hDlg, IDC_BK_PASSWORD_TITLE), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_BK_PASSWORD_DISPLAY), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_BK_PASSWORD_CLEAR), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_BK_PASSWORD_OK), visibility);
    ShowWindow(GetDlgItem(hDlg, IDC_BK_PASSWORD_VERSION), visibility);
    HWND hBkMid = GetDlgItem(hDlg, IDC_BK_LICENSE_MACHINE_ID);
    if (hBkMid) {
        ShowWindow(hBkMid, visibility);
        if (show) {
            wchar_t midLine[64];
            swprintf_s(midLine, L"Machine ID: %08u", TimeLicense::GetMachineId8());
            SetWindowTextW(hBkMid, midLine);
        }
    }
    HWND hBkVu = GetDlgItem(hDlg, IDC_BK_LICENSE_VALID_UNTIL);
    if (hBkVu) {
        ShowWindow(hBkVu, visibility);
        if (show)
            ApplyMerkurLicenseValidUntilLine(hDlg, IDC_BK_LICENSE_VALID_UNTIL);
    }
    
    // Show/hide digit buttons
    for (int i = 0; i < 10; i++) {
        ShowWindow(GetDlgItem(hDlg, IDC_BK_PASSWORD_BTN_0 + i), visibility);
    }
}

INT_PTR CALLBACK MyDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_INITDIALOG:
		// Store the dialog handle when it's created
		CryptoCard::gSettingsDialog = hDlg;

		// Always require password on each open
		g_passwordValidated = false;
		g_settingsPage = 1;
		g_pwdEditTarget = 1;
		
		// Load background bitmap
		g_hBackgroundBitmap = (HBITMAP)LoadImage(NULL, L"dialog/signin/bg.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
		if (g_hBackgroundBitmap == NULL) {
			DebugPrintf("Failed to load background bitmap: %lu\n", static_cast<unsigned long>(GetLastError()));
		}
		
		// Set dialog to full screen with no title bar or padding
		{
			// Get screen dimensions
			int screenWidth = GetSystemMetrics(SM_CXSCREEN);
			int screenHeight = GetSystemMetrics(SM_CYSCREEN);
			
			// Full-screen custom bitmap: do NOT use WS_CLIPCHILDREN. With it, WM_PAINT excludes visible child
			// rects from the parent DC; the page-2 BS_GROUPBOX covers most of the client, so the parent never
			// draws bg.bmp under it and transparent groupbox interiors show stale page-1 pixels (listbox hid
			// itself; statics/buttons did not). Parent paints full client first; children paint on top.
			SetWindowLong(hDlg, GWL_STYLE, WS_POPUP);
			SetWindowLong(hDlg, GWL_EXSTYLE, 0);
			
			// License modal must be above any remaining overlays (mirror, etc.)
			SetWindowPos(hDlg, g_licenseDialogMode ? HWND_TOPMOST : HWND_TOP, 0, 0, screenWidth, screenHeight,
				SWP_FRAMECHANGED | SWP_SHOWWINDOW);
		}
		
		// Load current game variant from PlayDB
		{
			PlayDB& playDB = PlayDB::GetInstance();
			g_currentVariant = (int)playDB.GetGameVariant();
			if (g_currentVariant < 0 || g_currentVariant >= g_variantCount) {
				g_currentVariant = g_variantDefaultIndex;
			}
		}

		// Create large font for all components (except password)
		g_settingsLargeFont = CreateFont(24, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
			DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
			DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, L"Arial");
		
		// Create all components programmatically
		{
			// Clear password when dialog is shown
			ClearPassword(hDlg);
			ShowMainComponents(hDlg, false);
			ShowPasswordComponents(hDlg, true);
			
			// Get client area for layout calculations
			RECT clientRect;
			GetClientRect(hDlg, &clientRect);
			int clientWidth = clientRect.right - clientRect.left;
			int clientHeight = clientRect.bottom - clientRect.top;
			
			// Calculate column widths (2:3 ratio)
			int leftWidth = (clientWidth * 2) / 5;
			int rightWidth = (clientWidth * 3) / 5;
			int rightStartX = leftWidth + 20; // 20px gap

			// Machine ID + license validity:
			// - license dialog (no valid license / Ctrl+Q): keep near date area (centered, above Date)
			// - normal password dialog: bottom-left above version
			const int licInfoX = g_licenseDialogMode ? (clientWidth / 2 - 150) : 10;
			const int licInfoW = g_licenseDialogMode ? 300 : (clientWidth - 20);
			const int licMidY = g_licenseDialogMode ? (clientHeight / 2 - 232) : (clientHeight - 80);
			const int licVuY = g_licenseDialogMode ? (clientHeight / 2 - 256) : (clientHeight - 54);
			const DWORD licAlignStyle = g_licenseDialogMode ? SS_CENTER : SS_LEFT;
			{
				wchar_t midLine[64];
				swprintf_s(midLine, L"Machine ID: %08u", TimeLicense::GetMachineId8());
				CreateWindow(L"STATIC", midLine,
					WS_CHILD | WS_VISIBLE | licAlignStyle | SS_NOPREFIX,
					licInfoX, licMidY, licInfoW, 24,
					hDlg, (HMENU)IDC_LICENSE_MACHINE_ID, g_hInst, NULL);
			}
			CreateWindow(L"STATIC", L"",
				WS_CHILD | licAlignStyle | SS_NOPREFIX,
				licInfoX, licVuY, licInfoW, 22,
				hDlg, (HMENU)IDC_LICENSE_VALID_UNTIL, g_hInst, NULL);
			ApplyMerkurLicenseValidUntilLine(hDlg, IDC_LICENSE_VALID_UNTIL);
			
			// Digit generation uses myRandom(), which is self-seeded.
			GenerateRandomDigitNumbers();
			
			// Create Password Dialog Components (calculator style)
			CreateWindow(L"STATIC", L"Enter Password:",
				WS_CHILD | WS_VISIBLE | SS_CENTER,
				clientWidth/2 - 150, clientHeight/2 - 200, 300, 30,
				hDlg, (HMENU)IDC_PASSWORD_TITLE, g_hInst, NULL);
			
			// Password display field
			CreateWindow(L"STATIC", L"",
				WS_CHILD | WS_VISIBLE | SS_CENTER | WS_BORDER,
				clientWidth/2 - 150, clientHeight/2 - 160, 300, 30,
				hDlg, (HMENU)IDC_PASSWORD_DISPLAY, g_hInst, NULL);
			
			// Create digit buttons in fixed calculator positions (3x4 grid)
			// Calculate button size to fit within password box width (200px)
			int totalWidth = 300; // Same as password display
			int buttonSpacing = 5;
			int buttonSize = (totalWidth - 2 * buttonSpacing) / 3; // 3 buttons per row
			int startX = clientWidth/2 - 150; // Password display starts here
			int startY = clientHeight/2 - 120;
			
			// Fixed calculator layout positions
			int buttonPositions[10][2] = {
				{1, 3}, // Button 0: Bottom center
				{0, 0}, // Button 1: Top left
				{1, 0}, // Button 2: Top center
				{2, 0}, // Button 3: Top right
				{0, 1}, // Button 4: Middle left
				{1, 1}, // Button 5: Middle center
				{2, 1}, // Button 6: Middle right
				{0, 2}, // Button 7: Bottom left
				{1, 2}, // Button 8: Bottom center
				{2, 2}  // Button 9: Bottom right
			};
			
			for (int i = 0; i < 10; i++) {
				int col = buttonPositions[i][0];
				int row = buttonPositions[i][1];
				
				int x = startX + col * (buttonSize + buttonSpacing);
				int y = startY + row * (buttonSize + buttonSpacing);
				
				// Use random number for button text
				wchar_t buttonText[4];
				swprintf_s(buttonText, L"%d", g_digitPositions[i]);
				CreateWindow(L"BUTTON", buttonText,
					WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
					x, y, buttonSize, buttonSize,
					hDlg, (HMENU)(IDC_PASSWORD_BTN_0 + i), g_hInst, NULL);
			}
			
			// Clear + OK below keypad (same row, full width 300)
			{
				const int rowY = startY + 4 * (buttonSize + buttonSpacing) + 30;
				const int btnH = 60;
				const int gap = 10;
				const int halfW = (300 - gap) / 2;
				CreateWindow(L"BUTTON", L"Clear",
					WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
					startX, rowY, halfW, btnH,
					hDlg, (HMENU)IDC_PASSWORD_CLEAR, g_hInst, NULL);
				CreateWindow(L"BUTTON", L"OK",
					WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
					startX + halfW + gap, rowY, halfW, btnH,
					hDlg, (HMENU)IDC_PASSWORD_OK, g_hInst, NULL);
			}

			// Version (bottom-left; shown only while password UI is visible)
			CreateWindow(L"STATIC", MERKUR_APP_VERSION_STRING,
				WS_CHILD | WS_VISIBLE | SS_LEFT | SS_NOPREFIX,
				10, clientHeight - 28, clientWidth - 20, 24,
				hDlg, (HMENU)IDC_PASSWORD_VERSION, g_hInst, NULL);

			if (g_licenseDialogMode) {
				CreateWindow(L"STATIC", L"",
					WS_CHILD | WS_VISIBLE | SS_CENTER,
					clientWidth / 2 - 150, clientHeight / 2 - 275, 300, 36,
					hDlg, (HMENU)IDC_LICENSE_STATUS, g_hInst, NULL);
				{
					SYSTEMTIME st{};
					GetLocalTime(&st);
					wchar_t dateLine[64];
					swprintf_s(dateLine, L"Date: %02u/%04u", (unsigned)st.wMonth, (unsigned)st.wYear);
					CreateWindow(L"STATIC", dateLine,
						WS_CHILD | WS_VISIBLE | SS_CENTER,
						clientWidth / 2 - 150, clientHeight / 2 - 204, 300, 24,
						hDlg, (HMENU)IDC_LICENSE_CURRENT_DATE, g_hInst, NULL);
				}
				SetWindowTextW(GetDlgItem(hDlg, IDC_PASSWORD_TITLE), L"Enter license code:");
			}
			
			// Create Games List Title (Left Column) - initially hidden
			HWND hGamesListTitle = CreateWindow(L"STATIC", L"Games List",
				WS_CHILD | SS_LEFT,
				30, 30, leftWidth - 60, 50,
				hDlg, (HMENU)IDC_GAMES_LIST_TITLE, g_hInst, NULL);
			SendMessage(hGamesListTitle, WM_SETFONT, (WPARAM)g_settingsLargeFont, TRUE);
			
			// Create Games List (Left Column) - initially hidden
			HWND hGamesList = CreateWindow(L"LISTBOX", L"",
				WS_CHILD | WS_VSCROLL | WS_BORDER | LBS_NOTIFY,
				30, 90, leftWidth - 60, clientHeight - 200,
				hDlg, (HMENU)IDC_GAMES_LIST, g_hInst, NULL);
			SendMessage(hGamesList, WM_SETFONT, (WPARAM)g_settingsLargeFont, TRUE);
			
			// Create Up and Down Arrow buttons for Games List - initially hidden
			int listBottomY = 90 + (clientHeight - 200) + 10; // 10px gap below list
			HWND hGamesUpButton = CreateWindow(L"BUTTON", L"Up",
				WS_CHILD | BS_PUSHBUTTON,
				30, listBottomY, 80, 80,
				hDlg, (HMENU)IDC_GAMES_UP, g_hInst, NULL);
			SendMessage(hGamesUpButton, WM_SETFONT, (WPARAM)g_settingsLargeFont, TRUE);
			
			HWND hGamesDownButton = CreateWindow(L"BUTTON", L"Down",
				WS_CHILD | BS_PUSHBUTTON,
				120, listBottomY, 80, 80,
				hDlg, (HMENU)IDC_GAMES_DOWN, g_hInst, NULL);
			SendMessage(hGamesDownButton, WM_SETFONT, (WPARAM)g_settingsLargeFont, TRUE);
			

			
			// Create Bet Settings Group Box with Border - initially hidden
			HWND hBetSettingsTitle = CreateWindow(L"BUTTON", L"Bet Settings",
				WS_CHILD | BS_GROUPBOX,
				rightStartX - 10, 80, rightWidth - 20, 360,
				hDlg, (HMENU)IDC_BET_SETTINGS_TITLE, g_hInst, NULL);
			SendMessage(hBetSettingsTitle, WM_SETFONT, (WPARAM)g_settingsLargeFont, TRUE);
			
			// Create Selected Game Display inside Bet Settings section - initially hidden
			wstring initialGameName = GetGameNameFromPlayDB(g_selectedGame);
			HWND hSelectedGame = CreateWindow(L"STATIC", initialGameName.c_str(),
				WS_CHILD | SS_CENTER,
				rightStartX, 110, rightWidth - 40, 30,
				hDlg, (HMENU)IDC_SELECTED_GAME, g_hInst, NULL);
			SendMessage(hSelectedGame, WM_SETFONT, (WPARAM)g_settingsLargeFont, TRUE);
			
			// Create Bet Rows (3 rows) - positioned inside the group box - initially hidden
			for (int row = 0; row < 3; row++) {
				int y = 150 + row * 80;
				
				// Left arrow button
				HWND hLeftButton = CreateWindow(L"BUTTON", L"<",
					WS_CHILD | BS_PUSHBUTTON,
					rightStartX, y, 80, 50,
					hDlg, (HMENU)(IDC_BET_ROW1_LEFT + row * 3), g_hInst, NULL);
				SendMessage(hLeftButton, WM_SETFONT, (WPARAM)g_settingsLargeFont, TRUE);
				
				// Value display - increased width for better visibility
				wchar_t buffer[32];
				swprintf_s(buffer, L"%d", g_betValues[row]);
				HWND hValueDisplay = CreateWindow(L"STATIC", buffer,
					WS_CHILD | SS_CENTER,
					rightStartX + 90, y + 10, 220, 40,
					hDlg, (HMENU)(IDC_BET_ROW1_VALUE + row * 3), g_hInst, NULL);
				SendMessage(hValueDisplay, WM_SETFONT, (WPARAM)g_settingsLargeFont, TRUE);
				
				// Right arrow button
				HWND hRightButton = CreateWindow(L"BUTTON", L">",
					WS_CHILD | BS_PUSHBUTTON,
					rightStartX + 310, y, 80, 50,
					hDlg, (HMENU)(IDC_BET_ROW1_RIGHT + row * 3), g_hInst, NULL);
				SendMessage(hRightButton, WM_SETFONT, (WPARAM)g_settingsLargeFont, TRUE);
			}
			
			// Create Bet Save Button - initially hidden
			HWND hBetSaveButton = CreateWindow(L"BUTTON", L"Save",
				WS_CHILD | BS_PUSHBUTTON,
				rightStartX, 380, 150, 50,
				hDlg, (HMENU)IDC_BET_SAVE, g_hInst, NULL);
			SendMessage(hBetSaveButton, WM_SETFONT, (WPARAM)g_settingsLargeFont, TRUE);

			// Create Bet Save to ALL Button - initially hidden
			HWND hBetSaveAllButton = CreateWindow(L"BUTTON", L"Save to ALL",
				WS_CHILD | BS_PUSHBUTTON,
				rightStartX + 170, 380, 220, 50,
				hDlg, (HMENU)IDC_BET_SAVE_ALL, g_hInst, NULL);
			SendMessage(hBetSaveAllButton, WM_SETFONT, (WPARAM)g_settingsLargeFont, TRUE);

			// Create Variants Settings Group Box with Border - initially hidden
			HWND hVariantsTitle = CreateWindow(L"BUTTON", L"Variants Settings",
				WS_CHILD | BS_GROUPBOX,
				rightStartX - 10, 480, rightWidth - 20, 180,
				hDlg, (HMENU)IDC_VARIANTS_TITLE, g_hInst, NULL);
			SendMessage(hVariantsTitle, WM_SETFONT, (WPARAM)g_settingsLargeFont, TRUE);

			// Create Variant Row - positioned inside the group box - initially hidden
			int variantY = 520;

			// Left arrow button (only meaningful when VARIANTBC_ACTIVE)
			HWND hVariantLeftButton = CreateWindow(L"BUTTON", L"<",
				WS_CHILD | BS_PUSHBUTTON,
				rightStartX, variantY, 80, 50,
				hDlg, (HMENU)IDC_VARIANT_LEFT, g_hInst, NULL);
			SendMessage(hVariantLeftButton, WM_SETFONT, (WPARAM)g_settingsLargeFont, TRUE);

			// Variant display
			{
				int initialIdx = g_currentVariant;
				if (initialIdx < 0 || initialIdx >= g_variantCount) initialIdx = 0;
				HWND hVariantDisplay = CreateWindow(L"STATIC", g_variantNames[initialIdx],
					WS_CHILD | SS_CENTER,
					rightStartX + 90, variantY + 10, 220, 40,
					hDlg, (HMENU)IDC_VARIANT_VALUE, g_hInst, NULL);
				SendMessage(hVariantDisplay, WM_SETFONT, (WPARAM)g_settingsLargeFont, TRUE);
			}

			// Right arrow button (only meaningful when VARIANTBC_ACTIVE)
			HWND hVariantRightButton = CreateWindow(L"BUTTON", L">",
				WS_CHILD | BS_PUSHBUTTON,
				rightStartX + 310, variantY, 80, 50,
				hDlg, (HMENU)IDC_VARIANT_RIGHT, g_hInst, NULL);
			SendMessage(hVariantRightButton, WM_SETFONT, (WPARAM)g_settingsLargeFont, TRUE);

			// Create Variant Save Button - initially hidden
			HWND hVariantSaveButton = CreateWindow(L"BUTTON", L"Save",
				WS_CHILD | BS_PUSHBUTTON,
				rightStartX, 600, 150, 50,
				hDlg, (HMENU)IDC_VARIANT_SAVE, g_hInst, NULL);
			SendMessage(hVariantSaveButton, WM_SETFONT, (WPARAM)g_settingsLargeFont, TRUE);

			// Page 2 (Password Change) - full-screen layout (initially hidden)
			const int pageMargin = 40;
			const int pageTop = 40;
			const int pageBottom = clientHeight - 110; // keep space for pagination + reset/close
			const int pageHeight = pageBottom - pageTop;
			const int pageWidth = clientWidth - pageMargin * 2;

			HWND hPwdChangeTitle = CreateWindow(L"BUTTON", L"Password Change",
				WS_CHILD | BS_GROUPBOX,
				pageMargin, pageTop, pageWidth, pageHeight,
				hDlg, (HMENU)IDC_PWD_CHANGE_TITLE, g_hInst, NULL);
			SendMessage(hPwdChangeTitle, WM_SETFONT, (WPARAM)g_settingsLargeFont, TRUE);

			const int panelGap = 40;
			const int panelPad = 30;
			const int panelW = (pageWidth - panelGap) / 2;
			const int panelH = pageHeight - 80;
			const int panelY = pageTop + 60;
			const int panel1X = pageMargin;
			const int panel2X = pageMargin + panelW + panelGap;

			const int displayH = 70;
			const int displayW = panelW - panelPad * 2;
			const int displayX1 = panel1X + panelPad;
			const int displayX2 = panel2X + panelPad;
			const int displayY = panelY + 70;

			// Keypad sizing (pixel-perfect-ish, scales with resolution)
			const int keypadGap = 14;
			int keypadBtn = (panelW - panelPad * 2 - keypadGap * 2) / 3;
			if (keypadBtn > 110) keypadBtn = 110;
			if (keypadBtn < 80) keypadBtn = 80;

			const int keypadW = keypadBtn * 3 + keypadGap * 2;
			const int keypadX1 = panel1X + (panelW - keypadW) / 2;
			const int keypadX2 = panel2X + (panelW - keypadW) / 2;
			const int keypadY = displayY + displayH + 40;
			const int keypadBottomY = keypadY + 5 * (keypadBtn + keypadGap) - keypadGap;

			// Setting Password (left panel)
			HWND hSettingPwdLabel = CreateWindow(L"STATIC", L"Setting Password (4 digits):",
				WS_CHILD | SS_LEFT,
				displayX1, panelY, displayW, 40,
				hDlg, (HMENU)IDC_SETTING_PWD_LABEL, g_hInst, NULL);
			SendMessage(hSettingPwdLabel, WM_SETFONT, (WPARAM)g_settingsLargeFont, TRUE);

			HWND hSettingPwdDisplay = CreateWindow(L"STATIC", L"",
				WS_CHILD | SS_CENTER | WS_BORDER,
				displayX1, displayY, displayW, displayH,
				hDlg, (HMENU)IDC_SETTING_PWD_DISPLAY, g_hInst, NULL);
			SendMessage(hSettingPwdDisplay, WM_SETFONT, (WPARAM)g_settingsLargeFont, TRUE);

			HWND hSettingPwdSaveButton = CreateWindow(L"BUTTON", L"Save",
				WS_CHILD | BS_PUSHBUTTON,
				displayX1, keypadBottomY + 10, displayW, 60,
				hDlg, (HMENU)IDC_SETTING_PWD_SAVE, g_hInst, NULL);
			SendMessage(hSettingPwdSaveButton, WM_SETFONT, (WPARAM)g_settingsLargeFont, TRUE);

			// Bookkeeping Password (right panel)
			HWND hBookkeepingPwdLabel = CreateWindow(L"STATIC", L"Bookkeeping Password (4 digits):",
				WS_CHILD | SS_LEFT,
				displayX2, panelY, displayW, 40,
				hDlg, (HMENU)IDC_BOOKKEEPING_PWD_LABEL, g_hInst, NULL);
			SendMessage(hBookkeepingPwdLabel, WM_SETFONT, (WPARAM)g_settingsLargeFont, TRUE);

			HWND hBookkeepingPwdDisplay = CreateWindow(L"STATIC", L"",
				WS_CHILD | SS_CENTER | WS_BORDER,
				displayX2, displayY, displayW, displayH,
				hDlg, (HMENU)IDC_BOOKKEEPING_PWD_DISPLAY, g_hInst, NULL);
			SendMessage(hBookkeepingPwdDisplay, WM_SETFONT, (WPARAM)g_settingsLargeFont, TRUE);

			HWND hBookkeepingPwdSaveButton = CreateWindow(L"BUTTON", L"Save",
				WS_CHILD | BS_PUSHBUTTON,
				displayX2, keypadBottomY + 10, displayW, 60,
				hDlg, (HMENU)IDC_BOOKKEEPING_PWD_SAVE, g_hInst, NULL);
			SendMessage(hBookkeepingPwdSaveButton, WM_SETFONT, (WPARAM)g_settingsLargeFont, TRUE);

			// Two independent keypads (left = setting, right = bookkeeping)
			const wchar_t* digits[10] = { L"0", L"1", L"2", L"3", L"4", L"5", L"6", L"7", L"8", L"9" };
			int pos[10][2] = { {1, 3}, {0, 0}, {1, 0}, {2, 0}, {0, 1}, {1, 1}, {2, 1}, {0, 2}, {1, 2}, {2, 2} };

			for (int i = 0; i < 10; i++) {
				int col = pos[i][0], row = pos[i][1];
				HWND hBtn1 = CreateWindow(L"BUTTON", digits[i],
					WS_CHILD | BS_PUSHBUTTON,
					keypadX1 + col * (keypadBtn + keypadGap), keypadY + row * (keypadBtn + keypadGap),
					keypadBtn, keypadBtn,
					hDlg, (HMENU)(IDC_SETTINGS_PWD_DIGIT_0 + i), g_hInst, NULL);
				SendMessage(hBtn1, WM_SETFONT, (WPARAM)g_settingsLargeFont, TRUE);

				HWND hBtn2 = CreateWindow(L"BUTTON", digits[i],
					WS_CHILD | BS_PUSHBUTTON,
					keypadX2 + col * (keypadBtn + keypadGap), keypadY + row * (keypadBtn + keypadGap),
					keypadBtn, keypadBtn,
					hDlg, (HMENU)(IDC_SETTINGS_BK_DIGIT_0 + i), g_hInst, NULL);
				SendMessage(hBtn2, WM_SETFONT, (WPARAM)g_settingsLargeFont, TRUE);
			}

			HWND hBack1 = CreateWindow(L"BUTTON", L"<-",
				WS_CHILD | BS_PUSHBUTTON,
				keypadX1, keypadY + 4 * (keypadBtn + keypadGap), keypadBtn * 2 + keypadGap, keypadBtn,
				hDlg, (HMENU)IDC_SETTINGS_PWD_BACKSPACE, g_hInst, NULL);
			SendMessage(hBack1, WM_SETFONT, (WPARAM)g_settingsLargeFont, TRUE);
			HWND hClear1 = CreateWindow(L"BUTTON", L"Clear",
				WS_CHILD | BS_PUSHBUTTON,
				keypadX1 + 2 * (keypadBtn + keypadGap), keypadY + 4 * (keypadBtn + keypadGap), keypadBtn, keypadBtn,
				hDlg, (HMENU)IDC_SETTINGS_PWD_CLEAR, g_hInst, NULL);
			SendMessage(hClear1, WM_SETFONT, (WPARAM)g_settingsLargeFont, TRUE);

			HWND hBack2 = CreateWindow(L"BUTTON", L"<-",
				WS_CHILD | BS_PUSHBUTTON,
				keypadX2, keypadY + 4 * (keypadBtn + keypadGap), keypadBtn * 2 + keypadGap, keypadBtn,
				hDlg, (HMENU)IDC_SETTINGS_BK_BACKSPACE, g_hInst, NULL);
			SendMessage(hBack2, WM_SETFONT, (WPARAM)g_settingsLargeFont, TRUE);
			HWND hClear2 = CreateWindow(L"BUTTON", L"Clear",
				WS_CHILD | BS_PUSHBUTTON,
				keypadX2 + 2 * (keypadBtn + keypadGap), keypadY + 4 * (keypadBtn + keypadGap), keypadBtn, keypadBtn,
				hDlg, (HMENU)IDC_SETTINGS_BK_CLEAR, g_hInst, NULL);
			SendMessage(hClear2, WM_SETFONT, (WPARAM)g_settingsLargeFont, TRUE);
			
			// Clear password entry buffers
			ClearSettingPwd(hDlg);
			ClearBookkeepingPwd(hDlg);

			// Pagination buttons (bottom-center)
			int navY = clientHeight - 70;
			int navCenterX = clientWidth / 2;
			HWND hPage1 = CreateWindow(L"BUTTON", L"1",
				WS_CHILD | BS_PUSHBUTTON,
				navCenterX - 80, navY, 60, 50,
				hDlg, (HMENU)IDC_SETTINGS_PAGE_1, g_hInst, NULL);
			SendMessage(hPage1, WM_SETFONT, (WPARAM)g_settingsLargeFont, TRUE);
			HWND hPage2 = CreateWindow(L"BUTTON", L"2",
				WS_CHILD | BS_PUSHBUTTON,
				navCenterX + 20, navY, 60, 50,
				hDlg, (HMENU)IDC_SETTINGS_PAGE_2, g_hInst, NULL);
			SendMessage(hPage2, WM_SETFONT, (WPARAM)g_settingsLargeFont, TRUE);
			
			// Create Reset and Close buttons at bottom-right - initially hidden
			int buttonY = clientHeight - 70;
			int buttonX = clientWidth - 240;
			
			HWND hResetButton = CreateWindow(L"BUTTON", L"Reset",
				WS_CHILD | BS_PUSHBUTTON,
				buttonX-80, buttonY, 150, 50,
				hDlg, (HMENU)IDC_RESET_BUTTON, g_hInst, NULL);
			SendMessage(hResetButton, WM_SETFONT, (WPARAM)g_settingsLargeFont, TRUE);
			
			HWND hCloseButton = CreateWindow(L"BUTTON", L"Close",
				WS_CHILD | BS_PUSHBUTTON,
				buttonX + 80, buttonY, 150, 50,
				hDlg, (HMENU)IDC_CLOSE_BUTTON, g_hInst, NULL);
			SendMessage(hCloseButton, WM_SETFONT, (WPARAM)g_settingsLargeFont, TRUE);

			// Populate games list
			if (hGamesList != NULL) {
				// Get game count from PlayDB
				PlayDB& playDB = PlayDB::GetInstance();
				g_gameCount = playDB.GetGameCount();
				
				for (int i = 0; i < g_gameCount; i++) {
					wstring gameName = GetGameNameFromPlayDB(i);
					SendMessage(hGamesList, LB_ADDSTRING, 0, (LPARAM)gameName.c_str());
				}
				// Select first game by default
				SendMessage(hGamesList, LB_SETCURSEL, 0, 0);
				
				// Load first game's bet info (this won't happen automatically with LB_SETCURSEL)
				g_selectedGame = 0;
				LoadGameBetInfo(0);
				UpdateBetSettingsDisplay(hDlg);
			}

			// Top-center save confirmation (hidden until a save succeeds; z-order last so it stays on top)
			HWND hSaveBanner = CreateWindow(L"STATIC", L"",
				WS_CHILD | SS_CENTER | SS_NOPREFIX,
				0, 8, clientWidth, 56,
				hDlg, (HMENU)IDC_SETTINGS_SAVED_BANNER, g_hInst, NULL);
			SendMessage(hSaveBanner, WM_SETFONT, (WPARAM)g_settingsLargeFont, TRUE);
		}

		AllowSetForegroundWindow(ASFW_ANY);
		// Bypass hook so gmainWindow is not replaced by the modal; use real API from Hook.h.
		BringWindowToTop(hDlg);
		SetActiveWindow(hDlg);
		if (HWND hOkPwd = GetDlgItem(hDlg, IDC_PASSWORD_OK)) {
			SetFocus(hOkPwd);
		}
		
		return TRUE;
		
	case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hDlg, &ps);
			PaintSettingsClientBackground(hDlg, hdc);
			EndPaint(hDlg, &ps);
		}
		return TRUE;
		
	case WM_ERASEBKGND:
		// Must actually draw the bitmap here; returning TRUE without painting left uncleared regions when
		// toggling many WS_CLIPCHILDREN children (settings pages 1/2).
		if (g_hBackgroundBitmap) {
			PaintSettingsClientBackground(hDlg, (HDC)wParam);
			return TRUE;
		}
		return FALSE;
		
	case WM_TIMER:
		// Handle timer events for password display
		if (wParam == TIMER_SETTING_PWD) {
			HideSettingPwd(hDlg);
			return TRUE;
		}
		else if (wParam == TIMER_BOOKKEEPING_PWD) {
			HideBookkeepingPwd(hDlg);
			return TRUE;
		}
		else if (wParam == TIMER_SAVE_BANNER) {
			g_saveBannerElapsedMs += 500;
			HWND hBanner = GetDlgItem(hDlg, IDC_SETTINGS_SAVED_BANNER);
			if (hBanner) {
				g_saveBannerBlinkVisible = !g_saveBannerBlinkVisible;
				ShowWindow(hBanner, g_saveBannerBlinkVisible ? SW_SHOW : SW_HIDE);
				if (g_saveBannerBlinkVisible) {
					SetWindowPos(hBanner, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
				}
			}
			if (g_saveBannerElapsedMs >= 3000) {
				KillTimer(hDlg, TIMER_SAVE_BANNER);
				if (hBanner) {
					ShowWindow(hBanner, SW_HIDE);
				}
			}
			return TRUE;
		}
		break;
		
	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
		{
			if (g_licenseDialogMode) {
				return TRUE;
			}
			// For modal dialogs, use EndDialog instead of DestroyWindow
			// Return the button ID as the result
			EndDialog(hDlg, LOWORD(wParam));
			return TRUE;
		}
		
		// Handle Password Dialog
		if (LOWORD(wParam) == IDC_PASSWORD_CLEAR) {
			if (g_passwordValidated)
				return TRUE;
			ClearPassword(hDlg);
			if (g_licenseDialogMode) {
				if (HWND hSt = GetDlgItem(hDlg, IDC_LICENSE_STATUS))
					SetWindowTextW(hSt, L"");
			}
			return TRUE;
		}
		if (LOWORD(wParam) == IDC_PASSWORD_OK) {
			if (g_licenseDialogMode) {
				HWND hSt = GetDlgItem(hDlg, IDC_LICENSE_STATUS);
				if (wcslen(g_enteredPassword) != 12) {
					if (hSt)
						SetWindowTextW(hSt, L"Enter exactly 12 digits.");
					return TRUE;
				}
				uint64_t code = _wcstoui64(g_enteredPassword, nullptr, 10);
				wchar_t licErr[256] = {};
				if (TimeLicense::ValidateAndApplyEnteredCode(code, licErr, sizeof(licErr) / sizeof(licErr[0]))) {
					EndDialog(hDlg, IDOK);
					return TRUE;
				}
				if (hSt)
					SetWindowTextW(hSt, licErr[0] ? licErr : L"License was rejected.");
				ClearPassword(hDlg);
				return TRUE;
			}
			if (ValidatePassword(g_enteredPassword, false)) {
				g_passwordValidated = true;
				// Hide password components and show main components
				ShowPasswordComponents(hDlg, false);
				SetSettingsPage(hDlg, 1);
				DebugPrintf("Password validated successfully\n");
			} else {
				// Close dialog when password is incorrect
				DebugPrintf("Invalid password entered - closing dialog\n");
				EndDialog(hDlg, IDCANCEL);
			}
			return TRUE;
		}

		// Pagination (only after password)
		if (g_passwordValidated) {
			if (LOWORD(wParam) == IDC_SETTINGS_PAGE_1) {
				SetSettingsPage(hDlg, 1);
				return TRUE;
			}
			if (LOWORD(wParam) == IDC_SETTINGS_PAGE_2) {
				SetSettingsPage(hDlg, 2);
				return TRUE;
			}
		}

		// Page 2: password entry via two independent keypads
		if (g_passwordValidated && g_settingsPage == 2) {
			if (LOWORD(wParam) >= IDC_SETTINGS_PWD_DIGIT_0 && LOWORD(wParam) <= IDC_SETTINGS_PWD_DIGIT_9) {
				int digit = LOWORD(wParam) - IDC_SETTINGS_PWD_DIGIT_0;
				AppendPwdDigit(hDlg, 1, digit);
				return TRUE;
			}
			if (LOWORD(wParam) == IDC_SETTINGS_PWD_BACKSPACE) {
				BackspacePwd(hDlg, 1);
				return TRUE;
			}
			if (LOWORD(wParam) == IDC_SETTINGS_PWD_CLEAR) {
				ClearPwd(hDlg, 1);
				return TRUE;
			}

			if (LOWORD(wParam) >= IDC_SETTINGS_BK_DIGIT_0 && LOWORD(wParam) <= IDC_SETTINGS_BK_DIGIT_9) {
				int digit = LOWORD(wParam) - IDC_SETTINGS_BK_DIGIT_0;
				AppendPwdDigit(hDlg, 2, digit);
				return TRUE;
			}
			if (LOWORD(wParam) == IDC_SETTINGS_BK_BACKSPACE) {
				BackspacePwd(hDlg, 2);
				return TRUE;
			}
			if (LOWORD(wParam) == IDC_SETTINGS_BK_CLEAR) {
				ClearPwd(hDlg, 2);
				return TRUE;
			}
		}
		
		// Handle digit button clicks (initial password / license entry only)
		if (!g_passwordValidated &&
			LOWORD(wParam) >= IDC_PASSWORD_BTN_0 && LOWORD(wParam) <= IDC_PASSWORD_BTN_9) {
			int buttonIndex = LOWORD(wParam) - IDC_PASSWORD_BTN_0;
			int digit = g_digitPositions[buttonIndex]; // Get the displayed number, not button index
			AddDigitToPassword(hDlg, digit);
			return TRUE;
		}
		
		// Only handle main dialog events if password is validated
		if (!g_passwordValidated) {
			return FALSE;
		}

		// Hide page components when not on that page
		if (g_settingsPage == 2) {
			// Page 2 still needs Close/Reset + Save handlers below
		}
		
		// Handle Close button
		if (LOWORD(wParam) == IDC_CLOSE_BUTTON) {
			// Save all settings to database before closing
			PlayDB& playDB = PlayDB::GetInstance();
			playDB.Save();
			DebugPrintf("All settings saved to database\n");
			
			EndDialog(hDlg, IDCANCEL);
			return TRUE;
		}
		
		// Handle Reset button
		if (LOWORD(wParam) == IDC_RESET_BUTTON) {
			DebugPrintf("Reset button clicked\n");
			
			// Show confirmation dialog
			int result = MessageBox(hDlg, 
				L"Are you sure you want to reset all settings to default values?\n\nThis will reset:\n- All game bet settings\n- Variant settings\n- Passwords\n\nThis action cannot be undone.", 
				L"Confirm Reset", 
				MB_YESNO | MB_ICONQUESTION | MB_DEFBUTTON2);
			
			DebugPrintf("MessageBox result: %d\n", result);
			
			if (result == IDYES) {
				DebugPrintf("User confirmed reset\n");
				
				// Reset PlayDB settings to defaults
				PlayDB& playDB = PlayDB::GetInstance();
				playDB.ResetGameSettings();
				playDB.SaveResettedAny();
				
				// User confirmed, reset to defaults
				ResetToDefaults(hDlg);
				
				// Clear password change components
				ClearSettingPwd(hDlg);
				ClearBookkeepingPwd(hDlg);

				ShowSavedNotification(hDlg);
			} else {
				DebugPrintf("User cancelled reset\n");
			}
			return TRUE;
		}
		
		// Handle Save buttons
		if (LOWORD(wParam) == IDC_BET_SAVE) {
			SaveGameBetInfo(g_selectedGame);
			wstring gameName = GetGameNameFromPlayDB(g_selectedGame);
			DebugPrintf("Bet settings saved for game: %S\n", gameName.c_str());
			ShowSavedNotification(hDlg);
			return TRUE;
		}

		if (LOWORD(wParam) == IDC_BET_SAVE_ALL) {
			if (ApplyBetSettingsToAllGames(hDlg)) {
				ShowSavedNotification(hDlg);
			}
			return TRUE;
		}

		if (LOWORD(wParam) == IDC_VARIANT_SAVE) {
			SaveVariantInfo();
			int idx = g_currentVariant;
			if (idx < 0 || idx >= g_variantCount) idx = 0;
			DebugPrintf("Variant settings saved: %S\n", g_variantNames[idx]);
			ShowSavedNotification(hDlg);
			return TRUE;
		}

		// Handle Up and Down arrow buttons for Games List
		if (LOWORD(wParam) == IDC_GAMES_UP) {
			int currentSelection = (int)SendDlgItemMessage(hDlg, IDC_GAMES_LIST, LB_GETCURSEL, 0, 0);
			if (currentSelection > 0) {
				SendDlgItemMessage(hDlg, IDC_GAMES_LIST, LB_SETCURSEL, currentSelection - 1, 0);
				g_selectedGame = currentSelection - 1;
				UpdateSelectedGameDisplay(hDlg);
			}
			return TRUE;
		}
		
		if (LOWORD(wParam) == IDC_GAMES_DOWN) {
			int currentSelection = (int)SendDlgItemMessage(hDlg, IDC_GAMES_LIST, LB_GETCURSEL, 0, 0);
			int itemCount = (int)SendDlgItemMessage(hDlg, IDC_GAMES_LIST, LB_GETCOUNT, 0, 0);
			if (currentSelection < itemCount - 1) {
				SendDlgItemMessage(hDlg, IDC_GAMES_LIST, LB_SETCURSEL, currentSelection + 1, 0);
				g_selectedGame = currentSelection + 1;
				UpdateSelectedGameDisplay(hDlg);
			}
			return TRUE;
		}
		
		// Handle game selection
		if (LOWORD(wParam) == IDC_GAMES_LIST && HIWORD(wParam) == LBN_SELCHANGE) {
			int selectedIndex = (int)SendDlgItemMessage(hDlg, IDC_GAMES_LIST, LB_GETCURSEL, 0, 0);
			if (selectedIndex != LB_ERR) {
				g_selectedGame = selectedIndex;
				UpdateSelectedGameDisplay(hDlg);
			}
			return TRUE;
		}
		
		// Handle bet value changes
		if (LOWORD(wParam) >= IDC_BET_ROW1_LEFT && LOWORD(wParam) <= IDC_BET_ROW3_RIGHT) {
			int row = (LOWORD(wParam) - IDC_BET_ROW1_LEFT) / 3;
			int button = (LOWORD(wParam) - IDC_BET_ROW1_LEFT) % 3;
			
			// Get current bet steps array
			int* currentSteps = (g_betMode == 0) ? g_currentBetSteps5 : g_currentBetSteps10;
			int currentCount = (g_betMode == 0) ? g_currentBetStepsCount5 : g_currentBetStepsCount10;
			
			if (row == 0) { // Bet Mode row - toggle between 5¢ and 10¢ if available
				if (button == 0 && g_hasBetSteps10) { // Left arrow - switch to 5¢
					g_betMode = 0;
					// Use the stored 5¢ indices (already set from database)
					// g_minBetIndex and g_maxBetIndex are already correct
				}
				else if (button == 2 && g_hasBetSteps10) { // Right arrow - switch to 10¢
					g_betMode = 1;
					// Use the stored 10¢ indices (already set from database)
					// g_minBetIndex10 and g_maxBetIndex10 are already correct
				}
			}
			else if (row == 1) { // Min bet row
				// Use correct indices based on bet mode
				int* minIndex = (g_betMode == 0) ? &g_minBetIndex : &g_minBetIndex10;
				int* maxIndex = (g_betMode == 0) ? &g_maxBetIndex : &g_maxBetIndex10;
				
				if (button == 0 && *minIndex > 0) { // Left arrow - decrease min
					(*minIndex)--;
					// Ensure min doesn't exceed max
					if (*minIndex >= *maxIndex) {
						*maxIndex = *minIndex + 1;
						if (*maxIndex >= currentCount) {
							*maxIndex = currentCount - 1;
						}
					}
				}
				else if (button == 2 && *minIndex < *maxIndex - 1
					&& *minIndex + 1 < currentCount
					&& currentSteps[*minIndex + 1] <= kUserMinBetCeilingCents) { // Right arrow - increase min
					(*minIndex)++;
				}
			}
			else if (row == 2) { // Max bet row
				// Use correct indices based on bet mode
				int* minIndex = (g_betMode == 0) ? &g_minBetIndex : &g_minBetIndex10;
				int* maxIndex = (g_betMode == 0) ? &g_maxBetIndex : &g_maxBetIndex10;
				
				if (button == 0 && *maxIndex > *minIndex + 1
					&& currentSteps[*maxIndex - 1] >= kUserMaxBetFloorCents) { // Left arrow - decrease max
					(*maxIndex)--;
				}
				else if (button == 2 && *maxIndex < currentCount - 1) { // Right arrow - increase max
					(*maxIndex)++;
				}
			}
			
			UpdateBetSettingsDisplay(hDlg);
			return TRUE;
		}
		
#ifdef VARIANTBC_ACTIVE
		// Handle variant changes (only when B/C are active; otherwise the arrow buttons are hidden).
		// Left/right are clamped to [A..C] (no wraparound); UpdateVariantDisplay() also greys out
		// the arrow that hits the boundary.
		if (LOWORD(wParam) == IDC_VARIANT_LEFT) {
			if (g_currentVariant > 0) {
				g_currentVariant--;
			}
			UpdateVariantDisplay(hDlg);
		}
		else if (LOWORD(wParam) == IDC_VARIANT_RIGHT) {
			if (g_currentVariant < g_variantCount - 1) {
				g_currentVariant++;
			}
			UpdateVariantDisplay(hDlg);
		}
#endif
		
		// Handle Setting Password Random Generate button
		if (LOWORD(wParam) == IDC_SETTING_PWD_RANDOM) {
			GenerateRandomSettingPwd(hDlg);
			return TRUE;
		}
		
		// Handle Setting Password Plus button
		if (LOWORD(wParam) == IDC_SETTING_PWD_PLUS) {
			IncrementSettingPwd(hDlg);
			return TRUE;
		}
		
		// Handle Setting Password Minus button
		if (LOWORD(wParam) == IDC_SETTING_PWD_MINUS) {
			DecrementSettingPwd(hDlg);
			return TRUE;
		}
		
		// Handle Bookkeeping Password Random Generate button
		if (LOWORD(wParam) == IDC_BOOKKEEPING_PWD_RANDOM) {
			GenerateRandomBookkeepingPwd(hDlg);
			return TRUE;
		}
		
		// Handle Bookkeeping Password Plus button
		if (LOWORD(wParam) == IDC_BOOKKEEPING_PWD_PLUS) {
			IncrementBookkeepingPwd(hDlg);
			return TRUE;
		}
		
		// Handle Bookkeeping Password Minus button
		if (LOWORD(wParam) == IDC_BOOKKEEPING_PWD_MINUS) {
			DecrementBookkeepingPwd(hDlg);
			return TRUE;
		}
		
		// Handle Setting Password Save button
		if (LOWORD(wParam) == IDC_SETTING_PWD_SAVE) {
			if (wcslen(g_settingPwdEntry) == 4) {
				// Convert wide string to string
				string password;
				for (int i = 0; i < 4; i++) {
					password += (char)(g_settingPwdEntry[i]);
				}
				
				PlayDB& playDB = PlayDB::GetInstance();
				playDB.SetSettingPassword(password);
				
				// Mask display after save (do not clear digits)
				HideSettingPwd(hDlg);
				
				DebugPrintf("Setting password saved successfully\n");
				ShowSavedNotification(hDlg);
			} else {
				MessageBox(hDlg, L"Password should be 4 digits", L"Invalid Password", MB_OK | MB_ICONWARNING);
			}
			return TRUE;
		}
		
		// Handle Bookkeeping Password Save button
		if (LOWORD(wParam) == IDC_BOOKKEEPING_PWD_SAVE) {
			if (wcslen(g_bookkeepingPwdEntry) == 4) {
				// Convert wide string to string
				string password;
				for (int i = 0; i < 4; i++) {
					password += (char)(g_bookkeepingPwdEntry[i]);
				}
				
				PlayDB& playDB = PlayDB::GetInstance();
				playDB.SetBookkeepingPassword(password);
				
				// Mask display after save (do not clear digits)
				HideBookkeepingPwd(hDlg);
				
				DebugPrintf("Bookkeeping password saved successfully\n");
				ShowSavedNotification(hDlg);
			} else {
				MessageBox(hDlg, L"Password should be 4 digits", L"Invalid Password", MB_OK | MB_ICONWARNING);
			}
			return TRUE;
		}
		
		break;
		
	case WM_CLOSE:
		if (g_licenseDialogMode) {
			return TRUE;
		}
		// For modal dialogs, use EndDialog instead of DestroyWindow
		// Return IDCANCEL as the result
		EndDialog(hDlg, IDCANCEL);
		return TRUE;
		
	case WM_DESTROY:
		if (g_licenseDialogMode) {
			SetWindowPos(hDlg, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
		}
		// Clean up timers
		KillTimer(hDlg, TIMER_SETTING_PWD);
		KillTimer(hDlg, TIMER_BOOKKEEPING_PWD);
		KillTimer(hDlg, TIMER_SAVE_BANNER);
		
		// Clean up the background bitmap
		if (g_hBackgroundBitmap != NULL) {
			DeleteObject(g_hBackgroundBitmap);
			g_hBackgroundBitmap = NULL;
		}
		// Clean up the large font
		if (g_settingsLargeFont != NULL) {
			DeleteObject(g_settingsLargeFont);
			g_settingsLargeFont = NULL;
		}
		return TRUE;
	}
	return FALSE;
}

INT_PTR CALLBACK BookkeepingDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_INITDIALOG:
		// Store the dialog handle when it's created
		g_bkDialog = hDlg;
		
		// Load background bitmap
		g_hBKBackgroundBitmap = (HBITMAP)LoadImage(NULL, L"dialog/signin/bg.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
		if (g_hBKBackgroundBitmap == NULL) {
			DebugPrintf("Failed to load background bitmap: %lu\n", static_cast<unsigned long>(GetLastError()));
		}
		
		// Set dialog to full screen with no title bar or padding
		{
			// Get screen dimensions
			int screenWidth = GetSystemMetrics(SM_CXSCREEN);
			int screenHeight = GetSystemMetrics(SM_CYSCREEN);
			
			// Remove window frame and title bar completely
			SetWindowLong(hDlg, GWL_STYLE, WS_POPUP);
			SetWindowLong(hDlg, GWL_EXSTYLE, 0);
			
			// Set window position and size to full screen with no padding
			SetWindowPos(hDlg, HWND_TOP, 0, 0, screenWidth, screenHeight, 
				SWP_FRAMECHANGED | SWP_SHOWWINDOW);
		}
		
		// Create large font for all components (except password)
		g_bkLargeFont = CreateFont(24, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
			DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
			DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, L"Arial");
		g_bkLargeFontBold = CreateFont(24, 0, 0, 0, FW_BLACK, FALSE, FALSE, FALSE,
			DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
			DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, L"Arial");
		
		// Create all components programmatically
		{
			// Clear password when dialog is shown
			ClearPasswordBK(hDlg);
			
			// Get client area for layout calculations
			RECT clientRect;
			GetClientRect(hDlg, &clientRect);
			int clientWidth = clientRect.right - clientRect.left;
			int clientHeight = clientRect.bottom - clientRect.top;
			
			// Calculate column widths (2:5 ratio)
			int leftWidth = (clientWidth * 2) / 7;
			int rightWidth = (clientWidth * 5) / 7;
			int rightStartX = leftWidth + 20; // 20px gap

			// Machine ID + license validity (bottom-left, above version)
			{
				wchar_t midLine[64];
				swprintf_s(midLine, L"Machine ID: %08u", TimeLicense::GetMachineId8());
				CreateWindow(L"STATIC", midLine,
					WS_CHILD | WS_VISIBLE | SS_LEFT | SS_NOPREFIX,
					10, clientHeight - 80, clientWidth - 20, 24,
					hDlg, (HMENU)IDC_BK_LICENSE_MACHINE_ID, g_hInst, NULL);
			}
			CreateWindow(L"STATIC", L"",
				WS_CHILD | SS_LEFT | SS_NOPREFIX,
				10, clientHeight - 54, clientWidth - 20, 22,
				hDlg, (HMENU)IDC_BK_LICENSE_VALID_UNTIL, g_hInst, NULL);
			ApplyMerkurLicenseValidUntilLine(hDlg, IDC_BK_LICENSE_VALID_UNTIL);
			
			// Digit generation uses myRandom(), which is self-seeded.
			GenerateRandomDigitNumbersBK();
			
			// Create Password Dialog Components (calculator style)
			CreateWindow(L"STATIC", L"Enter Password:",
				WS_CHILD | WS_VISIBLE | SS_CENTER,
				clientWidth/2 - 150, clientHeight/2 - 200, 300, 30,
				hDlg, (HMENU)IDC_BK_PASSWORD_TITLE, g_hInst, NULL);
			
			// Password display field
			CreateWindow(L"STATIC", L"",
				WS_CHILD | WS_VISIBLE | SS_CENTER | WS_BORDER,
				clientWidth/2 - 150, clientHeight/2 - 160, 300, 30,
				hDlg, (HMENU)IDC_BK_PASSWORD_DISPLAY, g_hInst, NULL);
			
			// Create digit buttons in fixed calculator positions (3x4 grid)
			// Calculate button size to fit within password box width (200px)
			int totalWidth = 300; // Same as password display
			int buttonSpacing = 5;
			int buttonSize = (totalWidth - 2 * buttonSpacing) / 3; // 3 buttons per row
			int startX = clientWidth/2 - 150; // Password display starts here
			int startY = clientHeight/2 - 120;
			
			// Fixed calculator layout positions
			int buttonPositions[10][2] = {
				{1, 3}, // Button 0: Bottom center
				{0, 0}, // Button 1: Top left
				{1, 0}, // Button 2: Top center
				{2, 0}, // Button 3: Top right
				{0, 1}, // Button 4: Middle left
				{1, 1}, // Button 5: Middle center
				{2, 1}, // Button 6: Middle right
				{0, 2}, // Button 7: Bottom left
				{1, 2}, // Button 8: Bottom center
				{2, 2}  // Button 9: Bottom right
			};
			
			for (int i = 0; i < 10; i++) {
				int col = buttonPositions[i][0];
				int row = buttonPositions[i][1];
				
				int x = startX + col * (buttonSize + buttonSpacing);
				int y = startY + row * (buttonSize + buttonSpacing);
				
				// Use random number for button text
				wchar_t buttonText[4];
				swprintf_s(buttonText, L"%d", g_bkDigitPositions[i]);
				CreateWindow(L"BUTTON", buttonText,
					WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
					x, y, buttonSize, buttonSize,
					hDlg, (HMENU)(IDC_BK_PASSWORD_BTN_0 + i), g_hInst, NULL);
			}
			
			// Clear + OK below keypad (same row, full width 300) — matches settings (Ctrl+O) dialog
			{
				const int rowY = startY + 4 * (buttonSize + buttonSpacing) + 30;
				const int btnH = 60;
				const int gap = 10;
				const int halfW = (300 - gap) / 2;
				CreateWindow(L"BUTTON", L"Clear",
					WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
					startX, rowY, halfW, btnH,
					hDlg, (HMENU)IDC_BK_PASSWORD_CLEAR, g_hInst, NULL);
				CreateWindow(L"BUTTON", L"OK",
					WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
					startX + halfW + gap, rowY, halfW, btnH,
					hDlg, (HMENU)IDC_BK_PASSWORD_OK, g_hInst, NULL);
			}

			// Version (bottom-left; shown only while password UI is visible)
			CreateWindow(L"STATIC", MERKUR_APP_VERSION_STRING,
				WS_CHILD | WS_VISIBLE | SS_LEFT | SS_NOPREFIX,
				10, clientHeight - 28, clientWidth - 20, 24,
				hDlg, (HMENU)IDC_BK_PASSWORD_VERSION, g_hInst, NULL);
			
			// Create Left Panel Components - initially hidden
			HWND hLeftTitle = CreateWindow(L"STATIC", L"Total",
				WS_CHILD | SS_LEFT,
				30, 30, leftWidth - 60, 50,
				hDlg, (HMENU)IDC_BK_LEFT_TITLE, g_hInst, NULL);
			SendMessage(hLeftTitle, WM_SETFONT, (WPARAM)g_bkLargeFont, TRUE);
			
			// Begin label and date
			HWND hBeginLabel = CreateWindow(L"STATIC", L"Begin:",
				WS_CHILD | SS_LEFT,
				30, 90, 80, 40,
				hDlg, (HMENU)IDC_BK_BEGIN_LABEL, g_hInst, NULL);
			SendMessage(hBeginLabel, WM_SETFONT, (WPARAM)g_bkLargeFont, TRUE);
			
			// Get current date and time
			SYSTEMTIME st;
			GetLocalTime(&st);
			wchar_t dateStr[64];
			swprintf_s(dateStr, L"%04d-%02d-%02d %02d:%02d", st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute);
			HWND hBeginDate = CreateWindow(L"STATIC", dateStr,
				WS_CHILD | SS_LEFT,
				120, 90, 200, 40,
				hDlg, (HMENU)IDC_BK_BEGIN_DATE, g_hInst, NULL);
			SendMessage(hBeginDate, WM_SETFONT, (WPARAM)g_bkLargeFont, TRUE);
			
			// Total In
			HWND hTotalInLabel = CreateWindow(L"STATIC", L"Total In:",
				WS_CHILD | SS_LEFT,
				30, 140, 120, 40,
				hDlg, (HMENU)IDC_BK_TOTAL_IN_LABEL, g_hInst, NULL);
			SendMessage(hTotalInLabel, WM_SETFONT, (WPARAM)g_bkLargeFont, TRUE);
			HWND hTotalInValue = CreateWindow(L"STATIC", L"0",
				WS_CHILD | SS_RIGHT,
				160, 140, leftWidth - 190, 40,
				hDlg, (HMENU)IDC_BK_TOTAL_IN_VALUE, g_hInst, NULL);
			SendMessage(hTotalInValue, WM_SETFONT, (WPARAM)g_bkLargeFont, TRUE);
			
			// Total Out
			HWND hTotalOutLabel = CreateWindow(L"STATIC", L"Total Out:",
				WS_CHILD | SS_LEFT,
				30, 190, 120, 40,
				hDlg, (HMENU)IDC_BK_TOTAL_OUT_LABEL, g_hInst, NULL);
			SendMessage(hTotalOutLabel, WM_SETFONT, (WPARAM)g_bkLargeFont, TRUE);
			HWND hTotalOutValue = CreateWindow(L"STATIC", L"0",
				WS_CHILD | SS_RIGHT,
				160, 190, leftWidth - 190, 40,
				hDlg, (HMENU)IDC_BK_TOTAL_OUT_VALUE, g_hInst, NULL);
			SendMessage(hTotalOutValue, WM_SETFONT, (WPARAM)g_bkLargeFont, TRUE);
			
			// Hold (with border line above) - will be calculated dynamically
			HWND hHoldLabel = CreateWindow(L"STATIC", L"Hold",
				WS_CHILD | SS_LEFT,
				30, 240, 120, 40,
				hDlg, (HMENU)IDC_BK_HOLD_LABEL, g_hInst, NULL);
			SendMessage(hHoldLabel, WM_SETFONT, (WPARAM)g_bkLargeFontBold, TRUE);
			HWND hRemainingValue = CreateWindow(L"STATIC", L"0",
				WS_CHILD | SS_RIGHT,
				160, 240, leftWidth - 190, 40,
				hDlg, (HMENU)IDC_BK_REMAINING_VALUE, g_hInst, NULL);
			SendMessage(hRemainingValue, WM_SETFONT, (WPARAM)g_bkLargeFontBold, TRUE);

			// Separator line between Hold and Played points
			CreateWindow(L"STATIC", NULL,
				WS_CHILD | SS_ETCHEDHORZ,
				30, 275, leftWidth - 60, 2,
				hDlg, (HMENU)IDC_BK_HOLD_SEPARATOR, g_hInst, NULL);
			
			// Played points
			HWND hPlayedPointsLabel = CreateWindow(L"STATIC", L"Played points:",
				WS_CHILD | SS_LEFT,
				30, 290, 140, 40,
				hDlg, (HMENU)IDC_BK_PLAYED_POINTS_LABEL, g_hInst, NULL);
			SendMessage(hPlayedPointsLabel, WM_SETFONT, (WPARAM)g_bkLargeFont, TRUE);
			HWND hPlayedPointsValue = CreateWindow(L"STATIC", L"0 -- %",
				WS_CHILD | SS_RIGHT,
				180, 290, leftWidth - 210, 40,
				hDlg, (HMENU)IDC_BK_PLAYED_POINTS_VALUE, g_hInst, NULL);
			SendMessage(hPlayedPointsValue, WM_SETFONT, (WPARAM)g_bkLargeFont, TRUE);
			
			// Won points
			HWND hWonPointsLabel = CreateWindow(L"STATIC", L"Won points:",
				WS_CHILD | SS_LEFT,
				30, 340, 140, 40,
				hDlg, (HMENU)IDC_BK_WON_POINTS_LABEL, g_hInst, NULL);
			SendMessage(hWonPointsLabel, WM_SETFONT, (WPARAM)g_bkLargeFont, TRUE);
			HWND hWonPointsValue = CreateWindow(L"STATIC", L"0 0,00%",
				WS_CHILD | SS_RIGHT,
				180, 340, leftWidth - 210, 40,
				hDlg, (HMENU)IDC_BK_WON_POINTS_VALUE, g_hInst, NULL);
			SendMessage(hWonPointsValue, WM_SETFONT, (WPARAM)g_bkLargeFont, TRUE);
			
			// Number of Games Spin
			HWND hGameSpinLabel = CreateWindow(L"STATIC", L"Number of Games Spin",
				WS_CHILD | SS_LEFT,
				30, 390, 220, 40,
				hDlg, (HMENU)IDC_BK_GAME_SPIN_LABEL, g_hInst, NULL);
			SendMessage(hGameSpinLabel, WM_SETFONT, (WPARAM)g_bkLargeFont, TRUE);
			HWND hGameSpinValue = CreateWindow(L"STATIC", L"0",
				WS_CHILD | SS_RIGHT,
				260, 390, leftWidth - 290, 40,
				hDlg, (HMENU)IDC_BK_GAME_SPIN_VALUE, g_hInst, NULL);
			SendMessage(hGameSpinValue, WM_SETFONT, (WPARAM)g_bkLargeFont, TRUE);
			
			// DELETE and CLOSE buttons - positioned at the right of left panel
			int buttonY = clientHeight - 100;
			int rightButtonX = leftWidth - 250; // Position buttons at the right side of left panel
			HWND hDeleteButton = CreateWindow(L"BUTTON", L"DELETE",
				WS_CHILD | BS_PUSHBUTTON,
				rightButtonX, buttonY, 120, 50,
				hDlg, (HMENU)IDC_BK_DELETE_BUTTON, g_hInst, NULL);
			SendMessage(hDeleteButton, WM_SETFONT, (WPARAM)g_bkLargeFont, TRUE);
			
			// DELETE button will be colored via WM_CTLCOLORBTN handler
			
			HWND hCloseButton = CreateWindow(L"BUTTON", L"CLOSE",
				WS_CHILD | BS_PUSHBUTTON,
				rightButtonX + 130, buttonY, 120, 50,
				hDlg, (HMENU)IDC_BK_CLOSE_BUTTON, g_hInst, NULL);
			SendMessage(hCloseButton, WM_SETFONT, (WPARAM)g_bkLargeFont, TRUE);
			
			// Create Right Panel Components - initially hidden
			HWND hRightTitle = CreateWindow(L"STATIC", L"Merkur",
				WS_CHILD | SS_LEFT,
				rightStartX + 20, 30, rightWidth - 60, 50,
				hDlg, (HMENU)IDC_BK_RIGHT_TITLE, g_hInst, NULL);
			SendMessage(hRightTitle, WM_SETFONT, (WPARAM)g_bkLargeFont, TRUE);
			
			// Calculate column widths based on 4:1:1:1 ratio
			int totalTableWidth = rightWidth - 60; // Account for margins
			int gameWidth = (totalTableWidth * 4) / 7;  // 4/7 of total width
			int otherWidth = (totalTableWidth * 1) / 7; // 1/7 of total width each
			int spacing = 10; // 10px spacing between columns
			
			// Create column labels
			HWND hGameLabel = CreateWindow(L"STATIC", L"Game",
				WS_CHILD | SS_CENTER,
				rightStartX + 20, 90, gameWidth, 30,
				hDlg, (HMENU)IDC_BK_GAME_LABEL, g_hInst, NULL);
			SendMessage(hGameLabel, WM_SETFONT, (WPARAM)g_bkLargeFont, TRUE);
			
			HWND hPlayedLabel = CreateWindow(L"STATIC", L"Played points",
				WS_CHILD | SS_CENTER,
				rightStartX + 20 + gameWidth + spacing, 90, otherWidth, 30,
				hDlg, (HMENU)IDC_BK_PLAYED_LABEL, g_hInst, NULL);
			SendMessage(hPlayedLabel, WM_SETFONT, (WPARAM)g_bkLargeFont, TRUE);
			
			HWND hWonLabel = CreateWindow(L"STATIC", L"Won points",
				WS_CHILD | SS_CENTER,
				rightStartX + 20 + gameWidth + otherWidth + 2*spacing, 90, otherWidth, 30,
				hDlg, (HMENU)IDC_BK_WON_LABEL, g_hInst, NULL);
			SendMessage(hWonLabel, WM_SETFONT, (WPARAM)g_bkLargeFont, TRUE);
			
			HWND hSpinsLabel = CreateWindow(L"STATIC", L"Spins",
				WS_CHILD | SS_CENTER,
				rightStartX + 20 + gameWidth + 2*otherWidth + 3*spacing, 90, otherWidth, 30,
				hDlg, (HMENU)IDC_BK_SPINS_LABEL, g_hInst, NULL);
			SendMessage(hSpinsLabel, WM_SETFONT, (WPARAM)g_bkLargeFont, TRUE);
			
			// Create 4 separate listboxes (synchronized selection)
			HWND hGameList = CreateWindow(L"LISTBOX", L"",
				WS_CHILD | WS_VSCROLL | WS_BORDER | LBS_NOINTEGRALHEIGHT | LBS_NOTIFY,
				rightStartX + 20, 130, gameWidth, clientHeight - 180,
				hDlg, (HMENU)IDC_BK_GAME_LIST, g_hInst, NULL);
			SendMessage(hGameList, WM_SETFONT, (WPARAM)g_bkLargeFont, TRUE);
			
			HWND hPlayedList = CreateWindow(L"LISTBOX", L"",
				WS_CHILD | WS_VSCROLL | WS_BORDER | LBS_NOINTEGRALHEIGHT | LBS_NOTIFY,
				rightStartX + 20 + gameWidth + spacing, 130, otherWidth, clientHeight - 180,
				hDlg, (HMENU)IDC_BK_PLAYED_LIST, g_hInst, NULL);
			SendMessage(hPlayedList, WM_SETFONT, (WPARAM)g_bkLargeFont, TRUE);
			
			HWND hWonList = CreateWindow(L"LISTBOX", L"",
				WS_CHILD | WS_VSCROLL | WS_BORDER | LBS_NOINTEGRALHEIGHT | LBS_NOTIFY,
				rightStartX + 20 + gameWidth + otherWidth + 2*spacing, 130, otherWidth, clientHeight - 180,
				hDlg, (HMENU)IDC_BK_WON_LIST, g_hInst, NULL);
			SendMessage(hWonList, WM_SETFONT, (WPARAM)g_bkLargeFont, TRUE);
			
			HWND hSpinsList = CreateWindow(L"LISTBOX", L"",
				WS_CHILD | WS_VSCROLL | WS_BORDER | LBS_NOINTEGRALHEIGHT | LBS_NOTIFY,
				rightStartX + 20 + gameWidth + 2*otherWidth + 3*spacing, 130, otherWidth, clientHeight - 180,
				hDlg, (HMENU)IDC_BK_SPINS_LIST, g_hInst, NULL);
			SendMessage(hSpinsList, WM_SETFONT, (WPARAM)g_bkLargeFont, TRUE);
			
			// Listboxes will be populated with real data after password validation
		}
		
		return TRUE;
		
	case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hDlg, &ps);
			
			if (g_hBKBackgroundBitmap != NULL) {
				// Get client area dimensions
				RECT clientRect;
				GetClientRect(hDlg, &clientRect);
				
				// Create memory DC for the bitmap
				HDC hdcMem = CreateCompatibleDC(hdc);
				HBITMAP hOldBitmap = (HBITMAP)SelectObject(hdcMem, g_hBKBackgroundBitmap);
				
				// Get bitmap dimensions
				BITMAP bmp;
				GetObject(g_hBKBackgroundBitmap, sizeof(BITMAP), &bmp);
				
				// Stretch the bitmap to fill the entire client area
				StretchBlt(hdc, 0, 0, clientRect.right, clientRect.bottom,
					hdcMem, 0, 0, bmp.bmWidth, bmp.bmHeight, SRCCOPY);
				
				// Clean up
				SelectObject(hdcMem, hOldBitmap);
				DeleteDC(hdcMem);
			}
			
			EndPaint(hDlg, &ps);
		}
		return TRUE;
		
	case WM_ERASEBKGND:
		// Prevent default background erasing to avoid flickering
		return TRUE;
		
	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
		{
			// For modal dialogs, use EndDialog instead of DestroyWindow
			// Return the button ID as the result
			EndDialog(hDlg, LOWORD(wParam));
			return TRUE;
		}
		
		// Handle Password Dialog
		if (LOWORD(wParam) == IDC_BK_PASSWORD_CLEAR) {
			if (g_bkPasswordValidated)
				return TRUE;
			ClearPasswordBK(hDlg);
			return TRUE;
		}
		if (LOWORD(wParam) == IDC_BK_PASSWORD_OK) {
			if (ValidatePassword(g_bkEnteredPassword, true)) {
				g_bkPasswordValidated = true;
				// Hide password components and show main components
				ShowPasswordComponentsBK(hDlg, false);
				ShowMainComponentsBK(hDlg, true);
				PopulateBookkeepingData(hDlg); // Populate with real data
				DebugPrintf("Bookkeeping password validated successfully\n");
			} else {
				// Close dialog when password is incorrect
				DebugPrintf("Invalid bookkeeping password entered - closing dialog\n");
				EndDialog(hDlg, IDCANCEL);
			}
			return TRUE;
		}
		
		// Handle digit button clicks
		if (LOWORD(wParam) >= IDC_BK_PASSWORD_BTN_0 && LOWORD(wParam) <= IDC_BK_PASSWORD_BTN_9) {
			int buttonIndex = LOWORD(wParam) - IDC_BK_PASSWORD_BTN_0;
			int digit = g_bkDigitPositions[buttonIndex]; // Get the displayed number, not button index
			AddDigitToPasswordBK(hDlg, digit);
			return TRUE;
		}
		
		// Only handle main dialog events if password is validated
		if (!g_bkPasswordValidated) {
			return FALSE;
		}
		
		// Handle Close button
		if (LOWORD(wParam) == IDC_BK_CLOSE_BUTTON) {
			// Save data before closing
			PlayDB& playDB = PlayDB::GetInstance();
			playDB.Save();
			DebugPrintf("Bookkeeping data saved\n");
			EndDialog(hDlg, IDCANCEL);
			return TRUE;
		}
		
		// Handle Delete button
		if (LOWORD(wParam) == IDC_BK_DELETE_BUTTON) {
			// Show confirmation dialog
			wstring confirmMessage = g_bkIsMainBookkeeping ? 
				L"Are you sure you want to delete all MAIN bookkeeping data?\n\nThis action cannot be undone." :
				L"Are you sure you want to delete all SUB bookkeeping data?\n\nThis action cannot be undone.";
			
			int result = MessageBox(hDlg, 
				confirmMessage.c_str(), 
				L"Confirm Delete", 
				MB_YESNO | MB_ICONQUESTION | MB_DEFBUTTON2);
			
			if (result == IDYES) {
				PlayDB& playDB = PlayDB::GetInstance();
				if (g_bkIsMainBookkeeping) {
					playDB.ResetMainBookData();
					playDB.SaveResettedAny();
					DebugPrintf("Main bookkeeping data deleted\n");
				} else {
					playDB.ResetSubBookData();
					playDB.SaveResettedAny();
					DebugPrintf("Sub bookkeeping data deleted\n");
				}
				// Refresh the dialog with updated data
				PopulateBookkeepingData(hDlg);
			}
			return TRUE;
		}
		
		// Handle synchronized listbox selection
		if (LOWORD(wParam) == IDC_BK_GAME_LIST && HIWORD(wParam) == LBN_SELCHANGE) {
			int selectedIndex = (int)SendDlgItemMessage(hDlg, IDC_BK_GAME_LIST, LB_GETCURSEL, 0, 0);
			if (selectedIndex != LB_ERR) {
				// Synchronize selection in all other listboxes
				SendDlgItemMessage(hDlg, IDC_BK_PLAYED_LIST, LB_SETCURSEL, selectedIndex, 0);
				SendDlgItemMessage(hDlg, IDC_BK_WON_LIST, LB_SETCURSEL, selectedIndex, 0);
				SendDlgItemMessage(hDlg, IDC_BK_SPINS_LIST, LB_SETCURSEL, selectedIndex, 0);
			}
			return TRUE;
		}
		
		if (LOWORD(wParam) == IDC_BK_PLAYED_LIST && HIWORD(wParam) == LBN_SELCHANGE) {
			int selectedIndex = (int)SendDlgItemMessage(hDlg, IDC_BK_PLAYED_LIST, LB_GETCURSEL, 0, 0);
			if (selectedIndex != LB_ERR) {
				// Synchronize selection in all other listboxes
				SendDlgItemMessage(hDlg, IDC_BK_GAME_LIST, LB_SETCURSEL, selectedIndex, 0);
				SendDlgItemMessage(hDlg, IDC_BK_WON_LIST, LB_SETCURSEL, selectedIndex, 0);
				SendDlgItemMessage(hDlg, IDC_BK_SPINS_LIST, LB_SETCURSEL, selectedIndex, 0);
			}
			return TRUE;
		}
		
		if (LOWORD(wParam) == IDC_BK_WON_LIST && HIWORD(wParam) == LBN_SELCHANGE) {
			int selectedIndex = (int)SendDlgItemMessage(hDlg, IDC_BK_WON_LIST, LB_GETCURSEL, 0, 0);
			if (selectedIndex != LB_ERR) {
				// Synchronize selection in all other listboxes
				SendDlgItemMessage(hDlg, IDC_BK_GAME_LIST, LB_SETCURSEL, selectedIndex, 0);
				SendDlgItemMessage(hDlg, IDC_BK_PLAYED_LIST, LB_SETCURSEL, selectedIndex, 0);
				SendDlgItemMessage(hDlg, IDC_BK_SPINS_LIST, LB_SETCURSEL, selectedIndex, 0);
			}
			return TRUE;
		}
		
		if (LOWORD(wParam) == IDC_BK_SPINS_LIST && HIWORD(wParam) == LBN_SELCHANGE) {
			int selectedIndex = (int)SendDlgItemMessage(hDlg, IDC_BK_SPINS_LIST, LB_GETCURSEL, 0, 0);
			if (selectedIndex != LB_ERR) {
				// Synchronize selection in all other listboxes
				SendDlgItemMessage(hDlg, IDC_BK_GAME_LIST, LB_SETCURSEL, selectedIndex, 0);
				SendDlgItemMessage(hDlg, IDC_BK_PLAYED_LIST, LB_SETCURSEL, selectedIndex, 0);
				SendDlgItemMessage(hDlg, IDC_BK_WON_LIST, LB_SETCURSEL, selectedIndex, 0);
			}
			return TRUE;
		}
		
		break;
		
	case WM_CLOSE:
		// For modal dialogs, use EndDialog instead of DestroyWindow
		// Return IDCANCEL as the result
		EndDialog(hDlg, IDCANCEL);
		return TRUE;
		
	case WM_DESTROY:
		// Clean up the background bitmap
		if (g_hBKBackgroundBitmap != NULL) {
			DeleteObject(g_hBKBackgroundBitmap);
			g_hBKBackgroundBitmap = NULL;
		}
		// Clean up the large font
		if (g_bkLargeFont != NULL) {
			DeleteObject(g_bkLargeFont);
			g_bkLargeFont = NULL;
		}
		if (g_bkLargeFontBold != NULL) {
			DeleteObject(g_bkLargeFontBold);
			g_bkLargeFontBold = NULL;
		}
		return TRUE;
		
	case WM_CTLCOLORBTN:
		{
			// Handle button coloring
			HWND hButton = (HWND)lParam;
			if (hButton == GetDlgItem(hDlg, IDC_BK_DELETE_BUTTON)) {
				// Return red brush for DELETE button
				static HBRUSH hRedBrush = CreateSolidBrush(RGB(220, 20, 20));
				SetBkColor((HDC)wParam, RGB(220, 20, 20));
				return (INT_PTR)hRedBrush;
			}
		}
		return FALSE;
	}
	return FALSE;
}

// Static variable for payout dialog background bitmap
static HBITMAP g_hPayoutBackgroundBitmap = NULL;

INT_PTR CALLBACK PayoutDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_INITDIALOG:
		// Store the dialog handle when it's created
		g_payoutDialog = hDlg;

#ifdef AIBOT_ACTIVE
		if (AIBot_TakeAutoPayoutRequest()) {
			PlayDB& playDB = PlayDB::GetInstance();
			playDB.CallPayoutCallback();
			playDB.Save();
			g_payoutDialog = NULL;
			EndDialog(hDlg, IDOK);
			return TRUE;
		}
#endif
		
		// Load background bitmap
		if (g_hPayoutBackgroundBitmap == NULL) {
			g_hPayoutBackgroundBitmap = (HBITMAP)LoadImage(NULL, L"dialog/signin/bg.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
			if (g_hPayoutBackgroundBitmap == NULL) {
				DebugPrintf("Failed to load background bitmap: %lu\n", static_cast<unsigned long>(GetLastError()));
			}
		}
		
		// Set dialog to full screen with no title bar or padding
		{
			// Get screen dimensions
			int screenWidth = GetSystemMetrics(SM_CXSCREEN);
			int screenHeight = GetSystemMetrics(SM_CYSCREEN);
			
			// Remove window frame and title bar completely
			SetWindowLong(hDlg, GWL_STYLE, WS_POPUP);
			SetWindowLong(hDlg, GWL_EXSTYLE, 0);
			
			// Set window position and size to full screen with no padding
			SetWindowPos(hDlg, HWND_TOP, 0, 0, screenWidth, screenHeight, 
				SWP_FRAMECHANGED | SWP_SHOWWINDOW);
		}
		
		// Create large font for all components
		g_payoutLargeFont = CreateFont(24, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
			DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
			DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, L"Arial");
		
		// Create all components programmatically
		{
			// Get client area for layout calculations
			RECT clientRect;
			GetClientRect(hDlg, &clientRect);
			int clientWidth = clientRect.right - clientRect.left;
			int clientHeight = clientRect.bottom - clientRect.top;
			
			DebugPrintf("Payout dialog client area: %dx%d\n", clientWidth, clientHeight);
			
			// Center the content
			int centerX = clientWidth / 2;
			int centerY = clientHeight / 2;
			
			DebugPrintf("Payout dialog center: %d, %d\n", centerX, centerY);
			
			// Get current date and time
			SYSTEMTIME st;
			GetLocalTime(&st);
			wchar_t dateStr[64];
			swprintf_s(dateStr, L"%04d-%02d-%02d %02d:%02d", st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute);
			
			// Date label
			HWND hDateLabel = CreateWindow(L"STATIC", L"Date:",
				WS_CHILD | SS_LEFT | WS_VISIBLE,
				30, 90, 80, 40,
				hDlg, (HMENU)IDC_PAYOUT_DATE_LABEL, g_hInst, NULL);
			SendMessage(hDateLabel, WM_SETFONT, (WPARAM)g_payoutLargeFont, TRUE);
			ShowWindow(hDateLabel, SW_SHOW);
			
			// Date value
			HWND hDateValue = CreateWindow(L"STATIC", dateStr,
				WS_CHILD | SS_LEFT | WS_VISIBLE,
				120, 90, 200, 40,
				hDlg, (HMENU)IDC_PAYOUT_DATE, g_hInst, NULL);
			SendMessage(hDateValue, WM_SETFONT, (WPARAM)g_payoutLargeFont, TRUE);
			ShowWindow(hDateValue, SW_SHOW);
			
			// Create Credits label and value on the same line
			PlayDB& playDB = PlayDB::GetInstance();
			double credits = playDB.GetGameCreditData();
			wstring creditsText = FormatCentAsEuro(credits);
			
			// Credits label
			HWND hCreditsLabel = CreateWindow(L"STATIC", L"Credits:",
				WS_CHILD | SS_LEFT | WS_VISIBLE,
				centerX - 150, centerY - 50, 100, 40,
				hDlg, (HMENU)IDC_PAYOUT_CREDITS_LABEL, g_hInst, NULL);
			SendMessage(hCreditsLabel, WM_SETFONT, (WPARAM)g_payoutLargeFont, TRUE);
			ShowWindow(hCreditsLabel, SW_SHOW);
			DebugPrintf("Created Credits label: %p\n", hCreditsLabel);
			
			// Credits value (next to the label)
			HWND hCreditsValue = CreateWindow(L"STATIC", creditsText.c_str(),
				WS_CHILD | SS_LEFT | WS_VISIBLE,
				centerX - 50, centerY - 50, 100, 40,
				hDlg, (HMENU)IDC_PAYOUT_CREDITS_VALUE, g_hInst, NULL);
			SendMessage(hCreditsValue, WM_SETFONT, (WPARAM)g_payoutLargeFont, TRUE);
			ShowWindow(hCreditsValue, SW_SHOW);
			DebugPrintf("Created Credits value: %p, credits: %f\n", hCreditsValue, credits);
			
			// Create Payout and Close buttons on the same line
			// Payout button (left side)
			HWND hPayoutButton = CreateWindow(L"BUTTON", L"Payout",
				WS_CHILD | BS_PUSHBUTTON | WS_VISIBLE,
				centerX - 120, centerY + 20, 100, 50,
				hDlg, (HMENU)IDC_PAYOUT_BUTTON, g_hInst, NULL);
			SendMessage(hPayoutButton, WM_SETFONT, (WPARAM)g_payoutLargeFont, TRUE);
			ShowWindow(hPayoutButton, SW_SHOW);
			DebugPrintf("Created Payout button: %p\n", hPayoutButton);
			
			// Close button (right side)
			HWND hCloseButton = CreateWindow(L"BUTTON", L"Close",
				WS_CHILD | BS_PUSHBUTTON | WS_VISIBLE,
				centerX + 20, centerY + 20, 100, 50,
				hDlg, (HMENU)IDC_PAYOUT_CLOSE_BUTTON, g_hInst, NULL);
			SendMessage(hCloseButton, WM_SETFONT, (WPARAM)g_payoutLargeFont, TRUE);
			ShowWindow(hCloseButton, SW_SHOW);
			DebugPrintf("Created Close button: %p\n", hCloseButton);
		}
		
		return TRUE;
		
	case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hDlg, &ps);
			
			// Draw background bitmap
			if (g_hPayoutBackgroundBitmap != NULL) {
				HDC hdcMem = CreateCompatibleDC(hdc);
				HBITMAP hbmOld = (HBITMAP)SelectObject(hdcMem, g_hPayoutBackgroundBitmap);
				
				BITMAP bm;
				GetObject(g_hPayoutBackgroundBitmap, sizeof(bm), &bm);
				
				StretchBlt(hdc, 0, 0, ps.rcPaint.right, ps.rcPaint.bottom,
					hdcMem, 0, 0, bm.bmWidth, bm.bmHeight, SRCCOPY);
				
				SelectObject(hdcMem, hbmOld);
				DeleteDC(hdcMem);
			}
			
			EndPaint(hDlg, &ps);
		}
		return TRUE;
		
	case WM_ERASEBKGND:
		// Prevent default background erasing
		return TRUE;
		
	case WM_COMMAND:
		if (LOWORD(wParam) == IDC_PAYOUT_BUTTON) {
			// Show confirmation alert
			int result = MessageBox(hDlg, 
				L"Are you sure you want to payout all credits?\n\nThis action cannot be undone.", 
				L"Confirm Payout", 
				MB_YESNO | MB_ICONQUESTION | MB_DEFBUTTON2);
			
			if (result == IDYES) {
				// Reset credits to 0
				PlayDB& playDB = PlayDB::GetInstance();
				//playDB.SetGameCreditData(0.0f);
				
				// Call payout callback. Callee resets value.
				playDB.CallPayoutCallback();
				
				// Update credits display
				SetDlgItemText(hDlg, IDC_PAYOUT_CREDITS_VALUE, L"0");
				
				DebugPrintf("Payout completed\n");
				
				playDB.Save();
				// Close the dialog after payout
				EndDialog(hDlg, IDOK);
			}
			return TRUE;
		}
		else if (LOWORD(wParam) == IDC_PAYOUT_CLOSE_BUTTON) {
			// Close the dialog
			DebugPrintf("Close button clicked\n");
			EndDialog(hDlg, IDCANCEL);
			return TRUE;
		}
		break;
		
	case WM_DESTROY:
		// Clean up resources
		if (g_hPayoutBackgroundBitmap != NULL) {
			DeleteObject(g_hPayoutBackgroundBitmap);
			g_hPayoutBackgroundBitmap = NULL;
		}
		if (g_payoutLargeFont != NULL) {
			DeleteObject(g_payoutLargeFont);
			g_payoutLargeFont = NULL;
		}
		return TRUE;
	}
	return FALSE;
}

void TimeLicense_ShowModalDialog()
{
	static bool s_inModal = false;
	if (s_inModal) {
		DebugPrintfT(LogTag::Fingerprint, "TimeLicense: ShowModalDialog skipped (already in modal)");
		return;
	}
	if (CryptoCard::gSettingsDialog != NULL && IsWindow(CryptoCard::gSettingsDialog)) {
		DebugPrintfT(LogTag::Fingerprint, "TimeLicense: ShowModalDialog skipped (settings dialog open)");
		return;
	}
	s_inModal = true;
	if (CryptoCard::gKeyboardHook) {
		DebugPrintfT(LogTag::Fingerprint, "TimeLicense: ShowModalDialog via InjectLicenseDialogHotkey (Ctrl+Q)");
		CryptoCard::InjectLicenseDialogHotkey();
	} else {
		DebugPrintfT(LogTag::Fingerprint, "TimeLicense: ShowModalDialog OpenLicenseDialog direct (no keyboard hook)");
		CryptoCard::GetInstance().OpenLicenseDialog();
	}
	s_inModal = false;
}
