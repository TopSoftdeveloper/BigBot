﻿#ifndef MYVECTOR_H
#define MYVECTOR_H
#include "Utils.h"
#include <vector>
#include <cstddef>   // for size_t
#include <initializer_list>

template <typename T>
class myVector {
private:
    std::vector<T> data;

public:
    // ========================
    // Constructors
    // ========================

    // Default constructor
    myVector() = default;

    // Initialize from initializer list
    myVector(std::initializer_list<T> init) : data(init) {}

    // Initialize from range [first, last)
    template <typename InputIt>
    myVector(InputIt first, InputIt last) : data(first, last) {}

    // Fill constructor: n copies of value
    myVector(size_t n, const T& value) : data(n, value) {}

    T& front() noexcept { return data.front(); }
    const T& front() const noexcept { return data.front(); }

    T& back() noexcept { return data.back(); }
    const T& back() const noexcept { return data.back(); }

    T* _data() noexcept { return data.data(); }
    const T* _data() const noexcept { return data.data(); }

    // ========================
    // Capacity
    // ========================

    size_t size() const noexcept { return data.size(); }
    bool empty() const noexcept { return data.empty(); }
    void clear() noexcept { data.clear(); }

    void reserve(size_t new_cap) { data.reserve(new_cap); }
    size_t capacity() const noexcept { return data.capacity(); }

    // ========================
    // Modifiers
    // ========================

    void push_back(const T& value) { data.push_back(value); }
    void pop_back() { data.pop_back(); }

    // Insert single element
    typename std::vector<T>::iterator insert(typename std::vector<T>::const_iterator pos, const T& value) {
        return data.insert(pos, value);
    }

    // Insert range
    template <typename InputIt>
    typename std::vector<T>::iterator insert(typename std::vector<T>::const_iterator pos, InputIt first, InputIt last) {
        return data.insert(pos, first, last);
    }

    // Erase single element
    typename std::vector<T>::iterator erase(typename std::vector<T>::const_iterator pos) {
        return data.erase(pos);
    }

    // Erase range
    typename std::vector<T>::iterator erase(typename std::vector<T>::const_iterator first,
        typename std::vector<T>::const_iterator last) {
        return data.erase(first, last);
    }

    // Assign from range
    template <typename InputIt>
    void assign(InputIt first, InputIt last) { data.assign(first, last); }

    // Assign n copies of a value
    void assign(size_t n, const T& value) { data.assign(n, value); }

    // ========================
    // Iterators
    // ========================

    auto begin() noexcept { return data.begin(); }
    auto end() noexcept { return data.end(); }
    auto begin() const noexcept { return data.begin(); }
    auto end() const noexcept { return data.end(); }
    auto cbegin() const noexcept { return data.cbegin(); }
    auto cend() const noexcept { return data.cend(); }

    // ========================
    // Access underlying std::vector
    // ========================


    // ========================
    // Element Access
    // ========================

    // T& operator[](size_t index) noexcept { return data[index]; }
    // const T& operator[](size_t index) const noexcept { return data[index]; }

    T& access(std::size_t index, const char* file, int line, const char* func) {
        if (index >= data.size()) {
            DebugPrintf("====================================================================\n");
            DebugPrintf("ERROR: Index out of range! Requested index: %zu, vector size: %zu\n",
                index, data.size());
            DebugPrintf("Location: %s() in %s:%d\n", func, file, line);
            DebugPrintf("====================================================================\n");
        }
        return data[index];
    }

    const T& access(std::size_t index, const char* file, int line, const char* func) const {
        if (index >= data.size()) {
            DebugPrintf("====================================================================\n");
            DebugPrintf("ERROR: Index out of range! Requested index: %zu, vector size: %zu\n",
                index, data.size());
            DebugPrintf("Location: %s() in %s:%d\n", func, file, line);
            DebugPrintf("====================================================================\n");
        }
        return data[index];
    }

    const std::vector<T>& get() const noexcept { return data; }
    std::vector<T>& get() noexcept { return data; }
};

#define AT(vec, index) (vec).access((index), __FILE__, __LINE__, __func__)

#endif // MYVECTOR_H
