#ifndef _STATE_MACHINE_H
#define _STATE_MACHINE_H
#include <Windows.h>
#include <atomic>
#include "myVector.h"
#include "./Game/ReelGame.h"

enum {
	STATUS_Init = 0,
	STATUS_Lobby,
	STATUS_InitGame,

	STATUS_LoadingContents,
	STATUS_LoadedContents,

	STATUS_PendingSpin,
	STATUS_PendingSpinAndGo,

	STATUS_Spin,
	STATUS_SpinRunning,
	STATUS_SpinFinished,

	STATUS_PendingMultiGo,
	STATUS_MultiGo,

	STATUS_PlayingBonusSound,
	STATUS_MagicGame,
	STATUS_Risiko,
	STATUS_TerminatingRisiko,
	STATUS_WaitActionBonusSound,
	STATUS_StartMoveBonus,
	STATUS_ReturnToMenu,
	STATUS_RisikoAss,

	STATUS_PenddingWaitMouseAction,
	STATUS_WaitMouseAction,
	STATUS_MovingSymbol,
	STATUS_MovedSymbol,
};

enum {
	CMD_None = 0,
	CMD_RunGame,
	CMD_Spin,
	CMD_SetSatus,
	CMD_SetSatusAndResetRsk,
	CMD_SetSatusAndResetCg,
	CMD_FinishCardGamble,
	CMD_FinishRisiko,
	CMD_UpdateBankBit,
	CMD_UpdateMagicBit,
	CMD_SaveCheckPointOfAG,

	CMD_ChargeCredit,
	CMD_BetUp,
	CMD_MaxBet,
	CMD_ReturnToMenu,
	CMD_EnterFreeMode,
	CMD_CardGambleSwapEnable,
	CMD_CalcRTP,

	CMD_SendPacket = 100
};

struct st_CMD_RunGame {
	UINT16 gameId;
};

struct st_CMD_CardGambleSwapEnable {
	BOOL enable;
};


struct st_CMD_ChargeCredit {
	UINT32 amount;
};

struct st_CMD_SendPacket {	
	UINT8 data[0x200];
	int len;
};

struct st_CMD_SetStatus {
	int status;
};

struct st_CMD_EnterFreeMode {
	BOOL f;
};

struct st_CMD_SaveCheckPointOfAG {
	int remain;
};

union CMD_obj {
	st_CMD_RunGame st_RunGame;
	st_CMD_ChargeCredit st_ChargeCredit;

	st_CMD_SendPacket st_SendPacket;
	st_CMD_SetStatus st_SetStatus;

	st_CMD_EnterFreeMode st_EnterFreeMode;	

	st_CMD_CardGambleSwapEnable st_CardGambleSwapEnable;

	st_CMD_SaveCheckPointOfAG st_SaveCheckPointOfAG;
};

struct StateMachineCmd {
	int cmd;
	UINT64 at;

	CMD_obj o;
};

struct CardGamble {
	BOOL bOpen;
	BOOL bRedActive;
	BOOL bFinished;
	BOOL bHighest;

	BOOL bSwapEnable;

	UINT32 nRisikoLevel;
	UINT32 nRisikoErfolg;
	UINT32 nRisikoSpitze;

	UINT32 nLedSwapInterval_ms;

	myVector<UINT8> vSelectedCards;
};	

struct Risiko {
	BOOL bOpen;
	BOOL bFinished;
	BOOL bOpening;
	int nOpeningWarmup;
	BOOL bUpgrading;
	BOOL bUpgraded;
	int nUpgradingWarmup;
	int go;
};

class StateMachine {
public:
	StateMachine();
	static std::atomic<int> g_rtpGeneration;
private:
	UINT16 m_nMagicCount;

	/** Step-based risiko threshold bumps (same tier ladder for card gamble and bonus coin). */
	static void AddRisikoStepThreshold(UINT32 level, int& threshold);

	std::atomic<int> m_nStatus;
	myVector<StateMachineCmd> m_vecCmd;
	CRITICAL_SECTION m_vecCmdMutex;

	myVector<StateMachineCmd> m_vecAction;
	CRITICAL_SECTION m_vecActionMutex;

	UINT64 m_nSpinWDT;
	myVector<UINT8> m_vecAnimsAfterTake;

	UINT64 m_nSpinStartTick;

	UINT64 m_nOpenGameTick;
public:
	// Spin parameters
	myVector<WinMeter> m_vSpinMeters;
	UINT64 m_nSpinNormalMeter;
	UINT64 m_nSpinMaxMeter;
	SoundItem m_SpinBonusSoundItem;
	UINT16 m_nSpinBetBit;

	BOOL m_bSpinFast;

public:
	UINT16 m_nGameID;
	UINT16 m_nGamePlan;

	BOOL m_bAutoSpin;
	BOOL m_bHalfAutoSpin;

	BOOL m_bFreeMode;
	BOOL m_bMultoGo;
	BOOL m_nMultiGoTotalLoop;

	UINT32 m_nBankBit;
	UINT32 m_nWinBit;

	UINT16 m_nBonusSoundID;
	BONUS m_nBonusBit;
	UINT64 m_atStopBonusSound;

	UINT64 m_atStopWaitAction_40s;
	UINT64 m_atAutoReturnToMenu;
	UINT64 m_atAutoNormalInMultigo;

	UINT64 m_atRisikoAssFinish;

	BOOL m_bNeedHideShowLines;

	// RgDragon
	UINT64 m_atCanMouseAction;
	UINT64 m_atMovingFinished;

public:
	//fast spin related function
	BOOL m_alreadySent;
	BOOL AlreadySentFastSpin();

	BOOL m_bLoopGuard;
	static void OnPayout();
	void ClearCredit();

	void SetBonusBit(UINT64 tick, UINT32 bonus);
	void SaveBonusBit(UINT32 bonus);

	UINT16 BonusMoveDelay_ms(int bonus);
	void SpinningTottalLines();

	BOOL KeyEventEnable();

	int GetStatus();
	void SetStatus(int status);
	void SetStatusAndDebug(const char* file, int line, const char* func, int new_status);

	int ReturnToMenu();
	void ReturnToMenu_pkt();

	void ChargeCredit(UINT32 Amount);
	void ChargeCredit_pkt(UINT32 Amount);

	int RunGame(UINT16 gameId);
	void RunGame_pkt(UINT16 gameId);
	void PostGameStartEvent();

	void BetUp();
	void BetUp_pkt();
	void MaxBet();
	void MaxBet_pkt();
	void Numpad0();
	void Numpad1();
	void Numpad2();

	int Spin();
	static double GaussDistribution(double mean, int currentbet, double totalspent, int totalspins);

	void SpinPost();
	void FastSpin();

	myVector<StateMachineCmd>& GetCmdVec();
	myVector<StateMachineCmd>& GetActionVec();

	void LOCK_CMD_VEC();
	void UNLOCK_CMD_VEC();

	void MousePressed(UINT8 reel, UINT8 x, UINT8 row, UINT8 y);

	void UpdateBankBitInGame(int delta);
public:
	BOOL PlaySound(UINT64 tick, UINT16 SoundId, BOOL RightNow = FALSE);
	void StopSound(UINT64 tick, UINT16 SoundId);
	void StopAllSound(UINT64 tick);
	void DisplayMoney(UINT64 tick, UINT16 gocID, UINT32 amount, UINT8 stepSizeTime);
	void SetVisibleByGOC(UINT64 tick, UINT16 gocID, BOOL visible);
	void ShowWinLines(UINT64 tick);
	void HideWinLines(UINT64 tick);
	void ToogleAutoSpin();
	void ToogleHalfAutoSpin();
	void ResetHalfAutoSpin();
	void ResetAutoSpin();
	void MoveBonus(UINT64& tick, UINT32 amount, BOOL fast);

	void ReadData(BYTE* data, int pReadSize);

	void EnterMagicGame();
	void TakeMagicBonus();
	void GoMagicGame();

	
	void StopPlayingBonusSound();
	void Loop();

public:
	CardGamble m_CardGamble;
	Risiko m_Risiko;

	void cg_open(BOOL force = FALSE);
	void cg_init();	
	void SelectRandomCard(BOOL pointing, BOOL redCard);
	void cg_go(BOOL red);
	void cg_takeBonusAndExit();
	void cg_moveRestErfolg(UINT64 tick);

	void rsk_init();
	void rsk_open(BOOL force = FALSE);
	void rsk_go();
	void rsk_takeBonusAndExit();
	BOOL rsk_downable();
	int rsk_down();

	void HideMultiGoAndStart();
	void HideMultiGoAndNormal(UINT64& tick);

public:
	void InitCache();
	myVector<UINT8> CalcRTP(BOOL fromCache, INT myGen);
};

extern StateMachine g_StateMachine;
extern std::atomic<double> gTotalWin;
extern std::atomic<double> gTotalBet;
extern double gTargetRTP;
#endif
