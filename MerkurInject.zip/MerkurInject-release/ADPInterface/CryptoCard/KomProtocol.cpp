#include "stdafx.h"
#include "Utils.h"
#include "KomProtocol.h"
#include "CryptoCard.h"
#include "DB.h"
#include "GrafficObjList.h"
#include "headerSoundIds.h"
#include "StateMachine.h"
#include "TimeLicense.h"

extern StateMachine g_StateMachine;

#define MAKE_PACKET(target, delay, ...)               \
    do {                                              \
        PACKET target;                                \
        target.sleeptime = delay;                     \
        target.data.insert(target.data.end(),         \
            { __VA_ARGS__ });                         \
		EnterCriticalSection(&m_InterruptAnsMutex);	  \
        mInterruptAns.push_back(target);              \
		LeaveCriticalSection(&m_InterruptAnsMutex);	  \
    } while (0)

#define MAKE_PACKET1(target, delay, l)                \
    do {                                              \
        PACKET target;                                \
        target.sleeptime = delay;                     \
        target.data.insert(target.data.end(),         \
            (l).begin(), (l).end());                  \
		EnterCriticalSection(&m_InterruptAnsMutex);	  \
        mInterruptAns.push_back(target);              \
		LeaveCriticalSection(&m_InterruptAnsMutex);	  \
    } while (0)

const BYTE gTouchData[] = "\x08\x07\x50\x00\x02\x00\x00\x00\x00";
const BYTE gTouchDataInGame[] = "\x08\x07\x50\x00\x01";


KomProtocol::KomProtocol() : myDB(DB::GetInstance())
{
	InitializeCriticalSection(&m_InterruptAnsMutex);

	mIsInitVideoCommand = true;
	DBindex = 0;

	EnterCriticalSection(&m_InterruptAnsMutex);
	mInterruptAns.clear();
	LeaveCriticalSection(&m_InterruptAnsMutex);

	mRunState = RUNSTATE_INIT;
	mJustNextFLAG = FALSE;
	mIsWaitingToStartGame = FALSE;
}

PROTOKOLLSTATES KomProtocol::DefineStateParam(int dummyCall)
{
	switch (mCommandID)
	{
		// Commands with variable-length parameters
	case '#':
	case '$':
	case '%':
	case '1':
	case '2':
	case '8':
	case ';':
	case '<':
	case 'G':
	case 'J':
	case 'O':
	case 'R':
	case 'Y':
	case 'Z':
	case '[':
	case '\\':
	case ']':
	case '`':
	case 'a':
	case 'b':
		mIsVariableParameterLaenge = true;
		return WAIT_PARAM_SIZE;

		// Special case: DB printout command
	case 'U':
		if (dummyCall)
			return NOTINIT;
		//PrepareDbPrintOut();
		return DB_PRINTOUT_TO_TEXT;

		// Special case: Wait for EOT/STX
	case 'W':
		if (dummyCall)
			return NOTINIT;
		//mSerial.mStopSending = 1;
		return WAIT_EOT_STX;

		// All other commands use fixed-length parameter handling
	default:
		CalculateFixedParamSize();
		mIsVariableParameterLaenge = false;
		return WAIT_PARAM;
	}
}


void KomProtocol::CalculateFixedParamSize()
{
	switch (this->mCommandID)
	{
	case '"':
		this->mNumParaBytesToWait = 36;
		this->mTotalParaBytes = 36;
		break;
	case '&':
	case ')':
	case '/':
	case 'I':
	case 'X':
		this->mNumParaBytesToWait = 3;
		this->mTotalParaBytes = 3;
		break;
	case '\'':
	case 'A':
		this->mNumParaBytesToWait = 4;
		this->mTotalParaBytes = 4;
		break;
	case '(':
	case '3':
	case '9':
	case 'M':
	case 'Q':
		this->mNumParaBytesToWait = 6;
		this->mTotalParaBytes = 6;
		break;
	case '*':
	case '+':
	case '.':
	case '4':
	case '5':
	case '6':
	case '7':
	case 'C':
	case 'T':
		this->mNumParaBytesToWait = 2;
		this->mTotalParaBytes = 2;
		break;
	case ',':
	case '0':
		this->mNumParaBytesToWait = 11;
		this->mTotalParaBytes = 11;
		break;
	case '-':
		this->mNumParaBytesToWait = 15;
		this->mTotalParaBytes = 15;
		break;
	case ':':
	case '>':
	case '?':
	case 'B':
	case 'D':
	case 'E':
	case 'F':
	case 'S':
		this->mNumParaBytesToWait = 0;
		this->mTotalParaBytes = 0;
		break;
	case '=':
	case 'K':
	case 'L':
	case 'N':
	case '_':
	case 'c':
		this->mNumParaBytesToWait = 1;
		this->mTotalParaBytes = 1;
		break;
	case '@':
		this->mNumParaBytesToWait = 7;
		this->mTotalParaBytes = 7;
		break;
	case 'H':
		this->mNumParaBytesToWait = 16;
		this->mTotalParaBytes = 16;
		break;
	case 'P':
	case '^':
		goto $LN47_25;
	case 'V':
		this->mNumParaBytesToWait = 31;
		this->mTotalParaBytes = 31;
		break;
	case 'd':
		this->mNumParaBytesToWait = 5;
		this->mTotalParaBytes = 5;
		break;
	default:
	$LN47_25:
		this->mTotalParaBytes = this->mNumParaBytesToWait;
		break;
	}
}

void KomProtocol::ManualSleep()
{
	if (DBindex + 1 < DB::NUM_ROWS)
	{
		Sleep(myDB.gDBWaitTime[DBindex + 1] * 1000);
	}
}

void KomProtocol::SendInputMoney(int Money)
{
	g_StateMachine.ChargeCredit(Money);
	//int currentMoney = myDB.CalcCredit(Money);
	//int creditID = myDB.gGameObjID["CREDIT"];

	//// --- Money Packet ---
	//MAKE_PACKET(pkt1, 0,
	//	0x01, 0x02, 0x2C, 0x00,
	//	static_cast<BYTE>(creditID & 0xFF),
	//	static_cast<BYTE>((creditID >> 8) & 0xFF),
	//	static_cast<BYTE>(currentMoney & 0xFF),
	//	static_cast<BYTE>((currentMoney >> 8) & 0xFF),
	//	0x00, 0x00, 0x64, 0x00,
	//	0x00, 0x00, 0x01,
	//	0x04
	//);

	////int uid = g_GrafficObjList.Str2GOCID("Championmeter");
	////uid = g_GrafficObjList.Str2GOCID("Geldspeicher"); // red
	////uid = g_GrafficObjList.Str2GOCID("WinAnzeige");	
	////
	////int cmoney = 9990;
	////if (iii == 0) {
	////	cmoney = 0;
	////	iii = 1;
	////}
	////else {
	////	cmoney = 100;
	////	iii = 0;
	////}
	////MAKE_PACKET(pkt1, 0,
	////	0x01, 0x02, 0x2C, 0x00,
	////	static_cast<BYTE>(uid & 0xFF),
	////	static_cast<BYTE>((uid >> 8) & 0xFF),
	////	static_cast<BYTE>(cmoney & 0xFF),
	////	static_cast<BYTE>((cmoney >> 8) & 0xFF),
	////	0x00, 0x00, 0x64, 0x00,
	////	0x00, 0x00, 0x01,
	////	0x04
	////);	

	//MAKE_PACKET(pkt2, 0,
	//	0x01, 0x02, 0x34, 0x00,
	//	SMP_Button1, 0x00, 0x04
	//);
}

#include "CryptoCard/Game/RgFruitinator.h"
void KomProtocol::Spin()
{
	g_StateMachine.ResetHalfAutoSpin();
	g_StateMachine.ResetAutoSpin();
	g_StateMachine.Spin();
}

void KomProtocol::FastSpin()
{
	g_StateMachine.FastSpin();
}

void KomProtocol::MaxBet() {
	g_StateMachine.MaxBet();
}

void KomProtocol::Numpad0() {
	g_StateMachine.Numpad0();
}

void KomProtocol::Numpad1() {
	g_StateMachine.Numpad1();
}

void KomProtocol::Numpad2() {
	g_StateMachine.Numpad2();
}

void KomProtocol::BetChange()
{
	g_StateMachine.BetUp();	
}

void KomProtocol::ReturnToMenu()
{
	if (g_StateMachine.ReturnToMenu() == 0) {
		DebugPrintf("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& Exited from game");
		mRunState = RUNSTATE_INIT;
	}
}

void KomProtocol::ToogleAutoSpin() {
	g_StateMachine.ToogleAutoSpin();
}


BOOL KomProtocol::IsInterrupt()
{
	EnterCriticalSection(&m_InterruptAnsMutex);
	if (!mInterruptAns.empty())
	{
		LeaveCriticalSection(&m_InterruptAnsMutex);
		return TRUE;
	}
	LeaveCriticalSection(&m_InterruptAnsMutex);
	return FALSE;
}

int KomProtocol::ComposeData(BYTE* data)
{
	int totalSize = 0;
	EnterCriticalSection(&m_InterruptAnsMutex);
	if (!mInterruptAns.empty())
	{
		const PACKET& pkt = mInterruptAns.front();
		int packetSize = static_cast<int>(pkt.data.size());
		if (packetSize > 0)
		{
			memcpy(data, pkt.data.data(), packetSize);
			totalSize = packetSize;
			Sleep(pkt.sleeptime * 1000);
		}

		// Remove the sent packet
		mInterruptAns.erase(mInterruptAns.begin());

		//And sends the next bytes;
		if (DBindex < myDB.gStateINDEX[mRunState])
		{
			DBindex++;
			memcpy(&data[totalSize], myDB.gDBData[DBindex], myDB.gDBDataSizes[DBindex]);
			totalSize += myDB.gDBDataSizes[DBindex];
			if (mRunState == RUNSTATE_INIT && DBindex >= myDB.gStateINDEX[RUNSTATE_INIT])
				TimeLicense::OnInitSerialDone();
		}
		LeaveCriticalSection(&m_InterruptAnsMutex);
		return totalSize;
	}
	LeaveCriticalSection(&m_InterruptAnsMutex);

	if (DBindex < myDB.gStateINDEX[mRunState])
	{
		DBindex++;
		memcpy(data, myDB.gDBData[DBindex], myDB.gDBDataSizes[DBindex]);
		if (mRunState == RUNSTATE_INIT && DBindex >= myDB.gStateINDEX[RUNSTATE_INIT])
			TimeLicense::OnInitSerialDone();
		return myDB.gDBDataSizes[DBindex];
	}

	return 0;
}

void KomProtocol::MousePressed(UINT8 reel, UINT8 x, UINT8 row, UINT8 y) {
	
	g_StateMachine.MousePressed(reel, x, row, y);
}

void KomProtocol::RunNewGame()
{
	DebugPrintf("***************** RunGame %d, %d", mGameID, mRunState);
	if (mRunState == RUNSTATE_INIT)
	{
		if (g_StateMachine.RunGame(mGameID) == 0) {
			mRunState = RUNSTATE_GAME;
			mIsWaitingToStartGame = TRUE;
		}
	}
}

void KomProtocol::MakePacket(const std::vector<UINT8>& data) {
	MAKE_PACKET1(pkt, 0, data);
}

void KomProtocol::MakePacket(const UINT8 *data, int len) {
	std::vector<UINT8> packet(data, data + len);
	MAKE_PACKET1(pkt, 0, packet);
}

BOOL IsReelGame(UINT16 goc);
void KomProtocol::ReadData(BYTE* data, int pReadSize)
{
	g_StateMachine.ReadData(data, pReadSize);
	/*if (mIsWaitingToStartGame) {
		BYTE expectedData[4] = { 0x02, 0x01, 0x00, 0x00 };

		expectedData[2] = static_cast<BYTE>(mGameID & 0xFF);
		expectedData[3] = static_cast<BYTE>((mGameID >> 8) & 0xFF);
		if (memcmp(expectedData, data, sizeof(expectedData)) == 0) {
			g_StateMachine.PostGameStartEvent();
			mIsWaitingToStartGame = FALSE;
		}
		else {
			expectedData[1] = 0x02;
			if (memcmp(expectedData, data, sizeof(expectedData)) == 0) {
				g_StateMachine.PostGameStartEvent();
				mIsWaitingToStartGame = FALSE;
			}
		}
	}*/

	if (DBindex < myDB.gStateINDEX[RUNSTATE_INIT]) return;
	
	if (memcmp(data, "\x06\x03\x00\x00", 4) == 0)
	{
		;
	}
	
	else if (memcmp(data, gTouchDataInGame, 5) == 0) {		
		MousePressed(data[6], data[5], data[8], data[7]);
	}
	else if (memcmp(data, gTouchData, 9) == 0)
	{
		if (mJustNextFLAG == TRUE )
		{
			//mRunState = RUNSTATE_FRUITINATOR;
			//RunNewGame();
		}
	}
	else
	{
		switch (data[0])
		{
		case 0x2:
		{
			int IDs = static_cast<int>(data[1]);
			int i = 0;
			for (i = 0; i < IDs; i++)
			{
				PACKET pkt;
				pkt.sleeptime = 0; // Or set appropriate value

				pkt.data.push_back(0x06);
				pkt.data.push_back(data[2 + i * 2]);
				pkt.data.push_back(data[3 + i * 2]);

				EnterCriticalSection(&m_InterruptAnsMutex);
				mInterruptAns.push_back(pkt);
				LeaveCriticalSection(&m_InterruptAnsMutex);
			}

			if (IDs == 1)
			{
				int temp = data[2] | (data[3] << 8);
				if (IsReelGame(temp)) {
					mGameID = temp;
					mJustNextFLAG = TRUE;
				}
			}

			if (mJustNextFLAG == TRUE && pReadSize > 2 + i * 2)
			{
				if (memcmp(&data[2 + i * 2], gTouchData, 9) == 0)
				{
					//mRunState = RUNSTATE_FRUITINATOR;
					RunNewGame();
				}
			}
			return;
		}
		default:
			break;
		}
	}

	mJustNextFLAG = FALSE;
}

