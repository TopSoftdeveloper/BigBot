#ifndef __CryptoCard_H__
#define __CryptoCard_H__
#include "Windows.h"
#include <deque>
#include <string>
#include <utility> // for std::pair
#include <chrono>
#pragma once

class KomProtocol;

class CryptoCard
{
private:
	CryptoCard();
	~CryptoCard();
	CryptoCard(const CryptoCard&) = delete;               // No copy
	CryptoCard& operator=(const CryptoCard&) = delete;    // No assign

public:
	static CryptoCard& GetInstance();                     // Singleton accessor

    KomProtocol *mpKomProtocol;
    int mStatus;
	BOOL mWaitForNext;
	/** Auto-reset; Read() sets, WriteDone() resets. Wait uses slice from hooked WaitForSingleObject dwMilliseconds (capped). */
	HANDLE m_hReadWakeEvent;
	BYTE mInterruptAns[2048];
	std::deque<std::pair<DWORD, bool>> mKeySequence;  // VK + isExtended
	std::chrono::steady_clock::time_point mLastSpinPress;
	bool mFastSpinTriggered = false;
	std::chrono::steady_clock::time_point mFastSpinExpire;
	std::chrono::steady_clock::time_point mLastNumpadAction;
	std::chrono::steady_clock::time_point mNumpad5PressStart;
	bool mNumpad5Pressed = false;
	bool mLongPressed = false;
	bool mNumpad6Pressed = false;

	bool IsPlusKey(DWORD vk);
	void ProcessKeySequence();      // Check for matching pattern
	bool DetectDoubleNumpad5();
	void HandleNumpadAction(DWORD vk);
	void HandleCtrlCombinations(DWORD vkCode);

	static HHOOK gKeyboardHook;
	static HWND gmainWindow;  // Track the settings dialog window
	static HWND gSettingsDialog;  // Track the settings dialog window
	static LRESULT CALLBACK KeyboardProc(int nCode, WPARAM wParam, LPARAM lParam);

    BOOL Read(BYTE* data, int pReadSize);
    BOOL Write(BYTE* data);
	void WriteDone();
	//void WriteReady();
	void WaitForSingleObject(HANDLE gSavedEvent, DWORD dwMilliseconds);
	void Initialize();
	void SetHook();
	void RemoveHook();                                    // Uninstall hook
	void OpenSettingsDialog();
	void OpenMainBookDialog();
	void OpenSubBookDialog();
	void OpenPayoutDialog(); // Opens payout dialog
	void HandleAsteriskSequence(); // Handles asterisk sequence detection
	/// Modal license entry (reuses IDD_SETTINGS layout with Machine ID + 12-digit code).
	void OpenLicenseDialog();
	/// Synthesizes Ctrl+Q so WH_KEYBOARD_LL runs the same path as a physical hotkey.
	static void InjectLicenseDialogHotkey();

	KomProtocol* GetKomProtocol();
};

#endif