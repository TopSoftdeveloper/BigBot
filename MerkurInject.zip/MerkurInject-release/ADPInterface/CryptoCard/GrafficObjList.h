#pragma once
#include "myVector.h"
#include <Windows.h>
#include <map>
#include <string>
#include <list>
#include <vector>
#include <iostream>

enum class grafficObjType {
    StartUpText,
    ErrorMeldung,
    ReelGame,
    Button,
    Sprite,
    Video,
    WinLine,
    ReelContainer,
    Meter,
    Meter2,
    MerkurFont,
    ReelStrip,
    FeatureGame,
    BinkVideo,
    CompositeMeter,
    SpriteFont,
    MultiGo,
    Event,
    VideoBink,
    Game,
    Disc,
    Layer,
    Service,
    Menue,
    Meter2Scroll,
    Meter2Scroll2,
    Sound,
    TextBox,
    PanelMeter,

    MAX_TYPE_NUM,
};

struct st_StartUpText {

};

struct st_ErrorMeldung {

};

struct st_ReelGame {

};

struct st_Button {

};

struct st_Video {

};

struct st_WinLine {

};

struct st_ReelContainer {

};

struct st_Meter {

};

struct st_Meter2 {

};

struct st_MerkurFont {

};

struct st_ReelStrip {

};

struct st_FeatureGame {

};

struct st_BinkVideo {

};

struct st_CompositeMeter {

};

struct st_SpriteFont {

};

struct st_MultiGo {

};

struct st_Event {

};

struct st_VideoBink {

};

struct st_Game {

};

struct st_Disc {

};

struct st_Layer {

};

struct st_Service {

};

struct st_Menue {

};

struct st_Meter2Scroll {

};

struct st_Meter2Scroll2 {

};

struct st_Sound {

};

struct st_TextBox {

};

struct st_PanelMeter {

};


union Obj {
    st_StartUpText _StartUpText;
    st_ErrorMeldung _ErrorMeldung;
    st_ReelGame _ReelGame;
    st_Button _Button;
    st_Video _Video;
    st_WinLine _WinLine;
    st_ReelContainer _ReelContainer;
    st_Meter _Meter;
    st_Meter2 _Meter2;
    st_MerkurFont _MerkurFont;
    st_ReelStrip _ReelStrip;
    st_FeatureGame _FeatureGame;
    st_BinkVideo _BinkVideo;
    st_CompositeMeter _CompositeMeter;
    st_SpriteFont _SpriteFont;
    st_MultiGo _MultiGo;
    st_Event _Event;
    st_VideoBink _VideoBink;
    st_Game _Game;
    st_Disc _Disc;
    st_Layer _Layer;
    st_Service _Service;
    st_Menue _Menue;
    st_Meter2Scroll _Meter2Scroll;
    st_Meter2Scroll2 _Meter2Scroll2;
    st_Sound _Sound;
    st_TextBox _TextBox;
    st_PanelMeter _PanelMeter;
};

struct grafficObj {
    char id[0x40];

    grafficObjType t;
    Obj o;
};

class GrafficObjList
{
public:
    GrafficObjList();
private:
    BOOL m_bInitialized;
    myVector<grafficObj> m_vecObj;
    std::map<std::string, std::string> m_mapGame2GOC;

public:
    int Load();
    grafficObjType Str2Type(char* str);
    char* Type2Str(grafficObjType type);
    std::string ReelGame2GOC(std::string reelGame);
    void PrintList();
    int Str2GOCID(std::string id);
};

extern GrafficObjList g_GrafficObjList;

std::string ConvertSymbolAutoPrefix(const std::string& symbol);

extern char* g_cfrtReelStrip[];