#pragma once
#include "GlobalVar.h"
class CEapiAPIEX_MSC
{
public:
	CEapiAPIEX_MSC(void);
	~CEapiAPIEX_MSC(void);
	
	
	DWORD m_dw04;
	DWORD m_dw08;
	infoStructure* m_pInfoStart;
	infoStructure* m_pInfoLast;
	HMODULE m_hMod14;
	DWORD m_dw18;

// 	sub_100095E0
	virtual	void sub_100087A0();
// 	sub_10007F00
// 	sub_10008830
// 	sub_10007EF0
// 	sub_10007FF0
// 	sub_10008050
	virtual BOOL sub_10008150(DWORD dwVal, DWORD dwArg_4, DWORD dwArg_8);
// 	sub_100080D0
// 	sub_10007F80
// 	sub_100081C0
// 	sub_100083A0
// 	sub_10008470
// 	sub_10003550
// 	sub_100084B0
// 	sub_10003550
// 	sub_100082D0
// 	sub_10008350
// 	sub_10006610
// 	sub_10006620
// 	sub_100084F0
// 	sub_10003660
// 	sub_10004550
// 	sub_10009340
	virtual BOOL GetVCPFeatureAndVCPFeatureReply_10006970(DWORD* arg_0, DWORD arg_4);
	virtual BOOL SetVCPFeature_10006A80(DWORD* pdwNewVal, DWORD nNum);
	virtual BOOL GetVCPFeatureAndVCPFeatureReply_10006B70(DWORD* pdwCurVal, int nNum);
	virtual BOOL SetVCPFeature_10005070(DWORD* pdwNewVal, DWORD nNum);
	virtual BOOL sub_10003720(BYTE byVal, BYTE* bySrc, BYTE byLen);
// 	sub_10008610
// 	sub_100051F0
// 	sub_100051F0
	virtual BOOL SetVCPFeature_10005200(int nNum, BYTE bVCPCode, DWORD* pdwNewVal);
	virtual	BOOL GetVCPFeatureAndVCPFeatureReply_10003850(int nArgNum, BYTE bVCPCode, DWORD* pdwCurrentVal, DWORD* dwMaxVal);
	virtual BOOL SaveCurrentSettings_10006D60(int nNum);
	virtual	DWORD sub_10007E60();
};
