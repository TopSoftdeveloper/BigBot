#pragma once

class CInterfaceAPIEX
{
public:
	CInterfaceAPIEX(void);
	~CInterfaceAPIEX(void);
	HANDLE ApiEXInit_1000A7E0();
	DWORD sub_1000A5D0(DWORD dwVar);
	DWORD sub_10009850(DWORD dwArg);
	DWORD sub_10009BB0(DWORD dwArg);
	DWORD sub_10009F10(DWORD dwArg);
	DWORD sub_1000A270(DWORD dwArg);

	DWORD m_dw0C;
	DWORD m_dw10;
	HANDLE m_hClass14;

// 	sub_10009820	???
// 	nullsub_2
// 	sub_10009650
// 	sub_1000B450
// 	sub_10009650
// 	sub_1000B440
// 	sub_1000B440
// 	sub_100051F0
// 	sub_100051F0
// 	sub_1000B440
// 	sub_1000B440
// 	sub_1000B450
// 	sub_10009650
// 	sub_10009650
// 	sub_10009650
// 	sub_10009650
// 	sub_1000B450
// 	sub_1000B450
// 	sub_1000B450
// 	sub_1000B450
// 	sub_1000B450
// 	sub_1000B440
// 	sub_1000B450
// 	sub_1000B450
// 	sub_1000B440
// 	sub_1000B440
// 	sub_1000B440
// 	sub_1000B440
// 	sub_100051F0
// 	sub_1000B450
// 	sub_100051F0
// 	sub_100051F0
// 	sub_100051F0
// 	sub_1000B470
// 	sub_1000B450
// 	sub_1000B440

};
