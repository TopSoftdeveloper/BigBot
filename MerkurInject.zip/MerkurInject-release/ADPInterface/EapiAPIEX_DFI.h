#pragma once
#include "GlobalVar.h"

class CEapiAPIEX_DFI
{
public:
	CEapiAPIEX_DFI(void);
	~CEapiAPIEX_DFI(void);
	DWORD m_dw04;
	DWORD m_dw08;
	infoStructure* m_pInfoStart;
	infoStructure* m_pInfoLast;
	HMODULE m_hMod14;
	DWORD m_dw18;

// 	sub_100061B0	
 	virtual void sub_10006F60();
// 	sub_10004960
// 	sub_10005400
// 	sub_10007EF0
// 	sub_10004A50
// 	sub_10004AB0
 	virtual BOOL EApiI2CWrite_10004BB0(BYTE byVal, DWORD dwArg_4, DWORD dwArg_8);
// 	sub_10004B30
// 	sub_100049E0
// 	sub_10004C20
// 	sub_10004E00
// 	sub_10004ED0
// 	sub_10003550
// 	sub_10004F10
// 	sub_10003550
// 	sub_10004D30
// 	sub_10004DB0
// 	sub_10006610
// 	sub_10006620
// 	sub_10004F50
// 	sub_10003660
// 	sub_10004550
// 	sub_10005F10 
	virtual BOOL GetVCPFeatureAndVCPFeatureReply_10006970(DWORD* arg_0, DWORD arg_4);
	virtual BOOL SetVCPFeature_10006A80(DWORD* pdwNewVal, DWORD nNum);
	virtual BOOL GetVCPFeatureAndVCPFeatureReply_10006B70(DWORD* pdwCurVal, int nNum);
	virtual BOOL SetVCPFeature_10005070(DWORD* pdwNewVal, DWORD nNum);
	virtual BOOL sub_10003720(BYTE byVal, BYTE* bySrc, BYTE byLen);
// 	sub_10005160
// 	sub_100051F0 retn 0
// 	sub_100051F0 retn 0
	virtual BOOL SetVCPFeature_10005200(int nNum, BYTE bVCPCode, DWORD* pdwNewVal);
	virtual	BOOL GetVCPFeatureAndVCPFeatureReply_10003850(int nArgNum, BYTE bVCPCode, DWORD* pdwCurrentVal, DWORD* dwMaxVal);
	virtual BOOL SaveCurrentSettings_10006D60(int nNum);
	virtual DWORD sub_100048F0();

};
