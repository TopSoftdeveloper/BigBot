#pragma once

class CUniAPIEX
{
public:
	CUniAPIEX(void);
	~CUniAPIEX(void);

	// 	sub_10001950
	// 	 nullsub_2
	// 	 sub_10009650
	// 	 sub_1000B450
	// 	 sub_10009650
	// 	 sub_1000B440
	// 	 sub_1000B440
	// 	 sub_100051F0
	// 	 sub_100051F0
	// 	 sub_1000B440
	// 	 sub_1000B440
	// 	 sub_1000B450
	// 	 sub_10009650
	// 	 sub_10009650
	// 	 sub_10009650
	// 	 sub_10009650
	// 	 sub_1000B450
	// 	 sub_1000B450
	// 	 sub_1000B450
	// 	 sub_1000B420
	// 	 sub_1000B450
	// 	 sub_1000B440
	// 	 sub_1000B450
	// 	 sub_1000B450
	// 	 sub_1000B440
	// 	 sub_1000B440
	// 	 sub_1000B440
	// 	 sub_1000B440
	// 	 sub_100051F0
	// 	 sub_1000B450
	// 	 sub_100051F0
	// 	 sub_100051F0
	// 	 sub_100051F0
	// 	 sub_1000B470
	// 	 sub_1000B450
};
