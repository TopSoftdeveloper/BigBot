#include "stdafx.h"
#include "Hook.h"
#include "Utils.h"

#ifdef BIGBET_ACTIVE
#include <mutex>
#include <string>
#include <unordered_set>
#endif
#include "Game.h"
#include "CryptoCard/CryptoCard.h"
#include "CryptoCard/StateMachine.h"
#include "SharedMutex.h"
#include "OneMinitorManipulation.h"

HANDLE comfile;
OriginalCreateFileW originalCreateFileW = NULL;
OriginalSetCommState originalSetCommState = NULL;
OriginalGetCommState originalGetCommState = NULL;
OriginalSetCommTimeouts originalSetCommTimeouts = NULL;
OriginalWriteFile originalWriteFile = NULL;
OriginalReadFile originalReadFile = NULL;
OriginalGetDefaultCommConfigW originalGetDefaultCommConfigW = NULL;
OriginalGetCommProperties originalGetCommProperties = NULL;
OriginalSetupComm originalSetupComm = NULL;
OriginalWaitCommEvent originalWaitCommEvent = NULL;
OriginalGetOverlappedResult originalGetOverlappedResult = NULL;
OriginalClearCommError originalClearCommError = NULL;
OriginalShowCursor originalShowCursor = NULL;
OriginalSetForegroundWindow originalSetForegroundWindow = NULL;
OriginalDeviceIoControl originalDeviceIoControl = NULL;
RegQueryValueExW_t originalRegQueryValueExW = NULL;
WaitForSingleObject_t originalWaitForSingleObject = NULL;
EnterCriticalSection_t originalEnterCriticalSection = NULL;

CryptoCard& gCryptoCard = CryptoCard::GetInstance();

HANDLE gOverlappedEvent = nullptr;

#ifdef BIGBET_ACTIVE
namespace
{

/** Nested HookedCreateFileW depth: redirect only on outermost call (avoids re-entry if a lower layer opens files).
 *  Scan uses FindFirstFileW/GetFileAttributesW/GetModuleFileNameW — those are not detoured in dllmain.cpp. */

thread_local unsigned g_createFileHookDepth = 0;

constexpr wchar_t kGfxHd[] = L"gamegraficsHD";
constexpr wchar_t kGfxUpdate[] = L"gamegraficsHDUpdate";
constexpr size_t kGfxHdLen = (sizeof(kGfxHd) / sizeof(kGfxHd[0])) - 1;

std::mutex g_gfxUpdateMutex;
std::unordered_set<std::wstring> g_gfxUpdateRelPathsLower;
bool g_gfxUpdateScanned = false;

static bool IsPathSep(wchar_t c)
{
	return c == L'\\' || c == L'/';
}

/** Finds a path component equal to gamegraficsHD (case-insensitive), not a substring of gamegraficsHDUpdate. */
static LPCWSTR FindGfxHdFolder(LPCWSTR path)
{
	if (!path)
		return nullptr;
	for (const wchar_t* p = path; *p; ++p)
	{
		if ((p == path || IsPathSep(p[-1])) && _wcsnicmp(p, kGfxHd, kGfxHdLen) == 0)
		{
			const wchar_t next = p[kGfxHdLen];
			if (next == L'\0' || IsPathSep(next))
				return p;
		}
	}
	return nullptr;
}

static std::wstring NormalizeSeparatorsLower(std::wstring s)
{
	for (wchar_t& c : s)
	{
		if (c == L'/')
			c = L'\\';
	}
	if (!s.empty())
		CharLowerBuffW(&s[0], static_cast<DWORD>(s.size()));
	return s;
}

static void ScanDirRecursive(const std::wstring& dirAbs, const std::wstring& relPrefix, std::unordered_set<std::wstring>& out)
{
	const std::wstring pattern = dirAbs + L"\\*";
	WIN32_FIND_DATAW fd;
	const HANDLE hFind = FindFirstFileW(pattern.c_str(), &fd);
	if (hFind == INVALID_HANDLE_VALUE)
		return;

	do
	{
		if (fd.cFileName[0] == L'.' && (fd.cFileName[1] == L'\0' || (fd.cFileName[1] == L'.' && fd.cFileName[2] == L'\0')))
			continue;

		const std::wstring fullPath = dirAbs + L"\\" + fd.cFileName;
		const std::wstring relPath = relPrefix.empty()
			? std::wstring(fd.cFileName)
			: relPrefix + L"\\" + std::wstring(fd.cFileName);

		if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
			ScanDirRecursive(fullPath, relPath, out);
		else
			out.insert(NormalizeSeparatorsLower(relPath));
	} while (FindNextFileW(hFind, &fd));

	FindClose(hFind);
}

/** Populates g_gfxUpdateRelPathsLower with lowercased relative paths under exeDir\gamegraficsHDUpdate. Caller must hold g_gfxUpdateMutex. */
static void ScanGameGraphicsUpdateFolder()
{
	wchar_t exePath[MAX_PATH];
	if (GetModuleFileNameW(nullptr, exePath, MAX_PATH) == 0)
		return;

	wchar_t* lastSlash = wcsrchr(exePath, L'\\');
	if (!lastSlash)
		return;
	*lastSlash = L'\0';

	std::wstring root = exePath;
	root += L"\\";
	root += kGfxUpdate;

	const DWORD attr = GetFileAttributesW(root.c_str());
	if (attr == INVALID_FILE_ATTRIBUTES || (attr & FILE_ATTRIBUTE_DIRECTORY) == 0)
		return;

	g_gfxUpdateRelPathsLower.clear();
	ScanDirRecursive(root, std::wstring(), g_gfxUpdateRelPathsLower);
}

static void PreloadGameGraphicsUpdateFileList()
{
	std::lock_guard<std::mutex> lock(g_gfxUpdateMutex);
	if (!g_gfxUpdateScanned)
	{
		ScanGameGraphicsUpdateFolder();
		g_gfxUpdateScanned = true;
	}
}

static bool TryRedirectToGameGraphicsUpdate(LPCWSTR lpFileName, std::wstring* outNewPath)
{
	if (!lpFileName)
		return false;

	const wchar_t* hit = FindGfxHdFolder(lpFileName);
	if (!hit)
		return false;
	if (!IsPathSep(hit[kGfxHdLen]))
		return false;

	const wchar_t* tail = hit + kGfxHdLen + 1;
	if (*tail == L'\0')
		return false;

	const std::wstring tailKey = NormalizeSeparatorsLower(std::wstring(tail));

	{
		std::lock_guard<std::mutex> lock(g_gfxUpdateMutex);
		if (!g_gfxUpdateScanned)
		{
			ScanGameGraphicsUpdateFolder();
			g_gfxUpdateScanned = true;
		}
		if (g_gfxUpdateRelPathsLower.find(tailKey) == g_gfxUpdateRelPathsLower.end())
			return false;
	}

	std::wstring result;
	result.assign(lpFileName, static_cast<size_t>(hit - lpFileName));
	result += kGfxUpdate;
	result += L'\\';
	result += tail;
	*outNewPath = std::move(result);
	return true;
}

} // namespace
#endif // BIGBET_ACTIVE

HANDLE WINAPI HookedCreateFileW(
	LPCWSTR lpFileName,
	DWORD dwDesiredAccess,
	DWORD dwShareMode,
	LPSECURITY_ATTRIBUTES lpSecurityAttributes,
	DWORD dwCreationDisposition,
	DWORD dwFlagsAndAttributes,
	HANDLE hTemplateFile
)
{
	static int onerun = false;
	if (!onerun)
	{
		onerun = true;

		std::thread([]() {
			SetCurrentThreadPriorityNormal();
			//SetWindowsPowerSaveMode();
#ifdef BIGBET_ACTIVE
			PreloadGameGraphicsUpdateFileList();
#endif
			RunStateMachine();
			LoadGrafficObjList();
			}).detach(); // Run in background, don't wait
	}

	if ((DWORD)lpFileName == 0x04)
	{
		return VIRTUALSRAMHANDLE;
	}

	//DebugPrintfW(L"Creating File : %s", lpFileName);

	if (wcscmp(lpFileName, L"com6") == 0)
	{
		return VIRTUALHANDLE6;
	}

	if (wcsicmp(lpFileName, L"com7") == 0)
	{
		gCryptoCard.Initialize();

		//To read from acceptor shared memory
		initSharedMemory();
		openSharedMemory();

		//To write commands to ScreenMirror
		OneMonitorManipulation::GetInstance().InitOneMonitorActivation();

		//Detect Virtual Driver and Init 

		return VIRTUALHANDLE7;
	}

	if (originalCreateFileW)
	{
#ifdef BIGBET_ACTIVE
		++g_createFileHookDepth;
		struct CreateFileHookDepthGuard
		{
			~CreateFileHookDepthGuard()
			{
				--g_createFileHookDepth;
			}
		} depthGuard;

		LPCWSTR pathToOpen = lpFileName;
		std::wstring redirected;
		if (g_createFileHookDepth == 1 && TryRedirectToGameGraphicsUpdate(lpFileName, &redirected))
		{
			DebugPrintfWT(LogTag::Hook, L"CreateFileW redirect: %s -> %s", lpFileName, redirected.c_str());
			pathToOpen = redirected.c_str();
		}
		return originalCreateFileW(pathToOpen, dwDesiredAccess, dwShareMode, lpSecurityAttributes, dwCreationDisposition, dwFlagsAndAttributes, hTemplateFile);
#else
		return originalCreateFileW(lpFileName, dwDesiredAccess, dwShareMode, lpSecurityAttributes, dwCreationDisposition, dwFlagsAndAttributes, hTemplateFile);
#endif
	}

	return INVALID_HANDLE_VALUE; // Return appropriate value if the original function was not found
}

BOOL WINAPI HookedSetCommState(
	HANDLE hFile,
	LPDCB lpDCB
)
{
	if (hFile == VIRTUALHANDLE6 || hFile == VIRTUALHANDLE7)
	{
		return true;
	}

	if (originalSetCommState)
		return originalSetCommState(hFile, lpDCB);

	return FALSE; // Return appropriate value if the original function was not found
}

BOOL WINAPI HookedGetCommState(
	HANDLE hFile,
	LPDCB lpDCB
)
{
	if (hFile == VIRTUALHANDLE6 || hFile == VIRTUALHANDLE7)
	{
		return true;
	}

	if (originalGetCommState)
		return originalGetCommState(hFile, lpDCB);

	return FALSE; // Return appropriate value if the original function was not found
}

BOOL WINAPI HookedSetCommTimeouts(
	HANDLE hFile,
	LPCOMMTIMEOUTS lpCommTimeouts
)
{
	if (hFile == VIRTUALHANDLE6 || hFile == VIRTUALHANDLE7)
	{
		return true;
	}

	if (originalSetCommTimeouts)
		return originalSetCommTimeouts(hFile, lpCommTimeouts);

	return FALSE; // Return appropriate value if the original function was not found
}

int g_writecount = 0;
int g_writtenbytes = 0;

int g_readcount = 0;

int g_writecount7 = 0;
int g_writtenbytes7 = 0;

BOOL WINAPI HookedWriteFile(
	HANDLE hFile,
	LPCVOID lpBuffer,
	DWORD nNumberOfBytesToWrite,
	LPDWORD lpNumberOfBytesWritten,
	LPOVERLAPPED lpOverlapped
)
{

	if (hFile == VIRTUALHANDLE6)
	{
		// DebugPrintf("---COM6 Writing %lu bytes\r\n", nNumberOfBytesToWrite);
		DebugHexDump(lpBuffer, nNumberOfBytesToWrite);

		g_writecount++;
		g_writtenbytes = nNumberOfBytesToWrite;
		if (lpNumberOfBytesWritten != NULL)
		{
			*lpNumberOfBytesWritten = nNumberOfBytesToWrite;
		}

		SetLastError(ERROR_IO_PENDING);
		if (lpOverlapped && lpOverlapped->hEvent) {
			SetEvent(lpOverlapped->hEvent); // <--- Critical to avoid timeout
		}

		return false;
	}

	if (hFile == VIRTUALHANDLE7)
	{
		// DebugPrintf("---COM7 Writing %lu bytes\r\n", nNumberOfBytesToWrite);
		DebugHexDump(lpBuffer, nNumberOfBytesToWrite);

		g_writecount7++;
		g_writtenbytes7 = nNumberOfBytesToWrite;
		if (lpNumberOfBytesWritten != NULL)
		{
			*lpNumberOfBytesWritten = nNumberOfBytesToWrite;
		}

		SetLastError(ERROR_IO_PENDING);
		if (lpOverlapped && lpOverlapped->hEvent) {
			SetEvent(lpOverlapped->hEvent); // <--- Critical to avoid timeout
		}

		gCryptoCard.Read((BYTE*)lpBuffer, nNumberOfBytesToWrite);

		return false;
	}
	// Call the original function

	return originalWriteFile(hFile, lpBuffer, nNumberOfBytesToWrite, lpNumberOfBytesWritten, lpOverlapped);
}


BOOL WINAPI HookedWaitCommEvent(
	HANDLE hFile,
	LPDWORD lpEvtMask,
	LPOVERLAPPED lpOverlapped
) {
	//DebugPrintfW(L"Hooked WaitCommEvent called: handle=0x%p\n", hFile);

	if (hFile == VIRTUALHANDLE6) {
		if (!lpEvtMask) {
			SetLastError(ERROR_INVALID_PARAMETER);
			return FALSE;
		}

		Sleep(INFINITE); // park thread; no timer wake-ups, CPU stays idle

		// Simulate a default event � for example, data received
		*lpEvtMask = EV_RXCHAR;  // Simulate incoming character event

		if (lpOverlapped) {
			// Simulate async completion
			if (lpOverlapped->hEvent) {
				SetEvent(lpOverlapped->hEvent);
			}
			// Optionally use QueueUserAPC or similar for IOCP
			return TRUE;
		}
		else {
			// Blocking mode � simulate immediate event
			Sleep(10); // simulate wait time
			return TRUE;
		}
	}

	if (hFile == VIRTUALHANDLE7) {

		if (!lpEvtMask) {
			SetLastError(ERROR_INVALID_PARAMETER);
			return FALSE;
		}

		if (lpOverlapped && lpOverlapped->hEvent) {
			gOverlappedEvent = lpOverlapped->hEvent;
			//DebugPrintfW(L"gOverlappedEvent handle=0x%p\n", gOverlappedEvent);

		}

		SetLastError(ERROR_IO_PENDING);
		//DebugPrintfW(L"Hooked WaitCommEvent called: return FALSE");
		return FALSE;
	}

	// Fallback to original
	if (originalWaitCommEvent) {
		return originalWaitCommEvent(hFile, lpEvtMask, lpOverlapped);
	}

	SetLastError(ERROR_PROC_NOT_FOUND);
	return FALSE;
}

DWORD WINAPI HookedWaitForSingleObject(HANDLE hHandle, DWORD dwMilliseconds)
{
	if (hHandle == gOverlappedEvent) {
		gCryptoCard.WaitForSingleObject(hHandle, dwMilliseconds);
		SetEvent(hHandle); // Trigger the event manually
		return WAIT_OBJECT_0;
	}

	return originalWaitForSingleObject(hHandle, dwMilliseconds);
}


BOOL WINAPI HookedReadFile(
	HANDLE hFile,
	LPVOID lpBuffer,
	DWORD nNumberOfBytesToRead,
	LPDWORD lpNumberOfBytesRead,
	LPOVERLAPPED lpOverlapped
)
{
	static BOOL isContinue = FALSE;
	static BOOL mToRead = 0;
	static BOOL mPosition = 0;
	static BYTE mBuffer[1024] = { 0 };

	if (hFile == VIRTUALHANDLE6)
	{
		// DebugPrintf("+++COM Reading %d bytes", nNumberOfBytesToRead);

		if (lpOverlapped && lpOverlapped->hEvent) {
			SetEvent(lpOverlapped->hEvent); // <--- Critical to avoid timeout
		}

		return true;
	}

	if (hFile == VIRTUALHANDLE7)
	{
		// DebugPrintf("+++COM7 Reading %d bytes", nNumberOfBytesToRead);
		if (isContinue == FALSE)
		{
			mToRead = gCryptoCard.Write((BYTE*)mBuffer);
		}

		
		int copysize = min(mToRead, nNumberOfBytesToRead);
		memcpy(lpBuffer, &mBuffer[mPosition], copysize);
		*lpNumberOfBytesRead = copysize;

		if (mToRead > nNumberOfBytesToRead) {
			isContinue = TRUE;
			mToRead -= copysize;
			mPosition += copysize;
		}
		else {
			isContinue = FALSE;
			mPosition = 0;
			mToRead = 0;
			gCryptoCard.WriteDone();
		}
		DebugHexDump(lpBuffer, *lpNumberOfBytesRead);
		return TRUE;
	}
	
	// Call the original function
	if (originalReadFile)
		return originalReadFile(hFile, lpBuffer, nNumberOfBytesToRead, lpNumberOfBytesRead, lpOverlapped);

	return FALSE; // Return appropriate value if the original function was not found
}

BOOL WINAPI HookedGetDefaultCommConfigW(
	LPCWSTR lpszName,
	LPCOMMCONFIG lpCC,
	LPDWORD lpdwSize
) {
	DebugPrintfW(L"Hooked GetDefaultCommConfigW called with port: %s\n", lpszName);

	// Optional: Intercept specific port
	if (lpszName && (wcscmp(lpszName, L"com6") == 0) || lpszName && (wcsicmp(lpszName, L"com7") == 0)) {
		// You could modify lpCC contents here or log usage
		DebugPrintfW(L"Intercepted default config request for COM6\n");
		// Optionally return FALSE to simulate failure, or manually populate lpCC
		DWORD requiredSize = sizeof(COMMCONFIG);
		if (*lpdwSize < requiredSize) {
			*lpdwSize = requiredSize;
			SetLastError(ERROR_INSUFFICIENT_BUFFER);
			return FALSE;
		}

		ZeroMemory(lpCC, requiredSize);
		lpCC->dwSize = requiredSize;
		lpCC->wVersion = 1;

		// Fill in DCB with typical defaults
		DCB& dcb = lpCC->dcb;
		dcb.DCBlength = sizeof(DCB);
		dcb.BaudRate = CBR_9600;
		dcb.fBinary = TRUE;
		dcb.fParity = FALSE;
		dcb.fOutxCtsFlow = FALSE;
		dcb.fOutxDsrFlow = FALSE;
		dcb.fDtrControl = DTR_CONTROL_ENABLE;
		dcb.fDsrSensitivity = FALSE;
		dcb.fTXContinueOnXoff = TRUE;
		dcb.fOutX = FALSE;
		dcb.fInX = FALSE;
		dcb.fErrorChar = FALSE;
		dcb.fNull = FALSE;
		dcb.fRtsControl = RTS_CONTROL_ENABLE;
		dcb.fAbortOnError = FALSE;
		dcb.ByteSize = 8;
		dcb.Parity = NOPARITY;
		dcb.StopBits = ONESTOPBIT;

		*lpdwSize = requiredSize;
		return true;
	}

	if (originalGetDefaultCommConfigW) {
		return originalGetDefaultCommConfigW(lpszName, lpCC, lpdwSize);
	}

	SetLastError(ERROR_PROC_NOT_FOUND);
	return FALSE;
}

BOOL WINAPI HookedGetCommProperties(
	HANDLE hFile,
	LPCOMMPROP lpCommProp
) {
	DebugPrintfW(L"Hooked GetCommProperties called for handle: 0x%p\n", hFile);

	if (hFile == VIRTUALHANDLE6 || hFile == VIRTUALHANDLE7) {
		if (!lpCommProp) {
			SetLastError(ERROR_INVALID_PARAMETER);
			return FALSE;
		}

		ZeroMemory(lpCommProp, sizeof(COMMPROP));
		lpCommProp->wPacketLength = sizeof(COMMPROP);
		lpCommProp->wPacketVersion = 1;
		lpCommProp->dwServiceMask = SP_SERIALCOMM;
		lpCommProp->dwMaxTxQueue = 0;
		lpCommProp->dwMaxRxQueue = 0;
		lpCommProp->dwMaxBaud = BAUD_9600;
		lpCommProp->dwProvSubType = PST_RS232;
		lpCommProp->dwProvCapabilities = PCF_TOTALTIMEOUTS | PCF_PARITY_CHECK | PCF_RTSCTS;
		lpCommProp->dwSettableParams = SP_BAUD | SP_DATABITS | SP_PARITY | SP_STOPBITS | SP_HANDSHAKING;
		lpCommProp->dwSettableBaud = BAUD_9600 | BAUD_19200 | BAUD_38400 | BAUD_57600 | BAUD_115200;
		lpCommProp->wSettableData = DATABITS_7 | DATABITS_8;
		lpCommProp->wSettableStopParity = STOPBITS_10 | PARITY_NONE;

		return TRUE;
	}

	// Fallback to original function
	if (originalGetCommProperties) {
		return originalGetCommProperties(hFile, lpCommProp);
	}

	SetLastError(ERROR_PROC_NOT_FOUND);
	return FALSE;
}

BOOL WINAPI HookedSetupComm(
	HANDLE hFile,
	DWORD dwInQueue,
	DWORD dwOutQueue
) {
	DebugPrintfW(L"Hooked SetupComm called: handle=0x%p, InQueue=%lu, OutQueue=%lu\n", hFile, dwInQueue, dwOutQueue);

	if (hFile == VIRTUALHANDLE6 || hFile == VIRTUALHANDLE7) {
		// Simulate success without doing anything
		DebugPrintfW(L"Simulating SetupComm success for virtual COM6/COM7\n");
		return TRUE;
	}

	if (originalSetupComm) {
		return originalSetupComm(hFile, dwInQueue, dwOutQueue);
	}

	SetLastError(ERROR_PROC_NOT_FOUND);
	return FALSE;
}

BOOL WINAPI HookedGetOverlappedResult(
	HANDLE hFile,
	LPOVERLAPPED lpOverlapped,
	LPDWORD lpNumberOfBytesTransferred,
	BOOL bWait
) {
	//DebugPrintfW(L"Hooked GetOverlappedResult: handle=0x%p, bWait=%d\n", hFile, bWait);

	if (hFile == VIRTUALHANDLE6) {
		if (!lpOverlapped || !lpNumberOfBytesTransferred) {
			SetLastError(ERROR_INVALID_PARAMETER);
			return FALSE;
		}

		// Simulate that 1 byte was transferred successfully
		*lpNumberOfBytesTransferred = g_writtenbytes;

		// If the operation "has not completed" yet, simulate delay if bWait == TRUE
		if (bWait) {
			Sleep(5); // Simulate wait time
		}

		// Simulate success
		return TRUE;
	}

	if (hFile == VIRTUALHANDLE7) {
		if (!lpOverlapped || !lpNumberOfBytesTransferred) {
			SetLastError(ERROR_INVALID_PARAMETER);
			return FALSE;
		}

		// Simulate that 1 byte was transferred successfully
		*lpNumberOfBytesTransferred = g_writtenbytes7;

		// If the operation "has not completed" yet, simulate delay if bWait == TRUE
		if (bWait) {
			Sleep(5); // Simulate wait time
		}

		// Simulate success
		return TRUE;
	}

	// Call original if not our handle
	if (originalGetOverlappedResult) {
		return originalGetOverlappedResult(hFile, lpOverlapped, lpNumberOfBytesTransferred, bWait);
	}

	SetLastError(ERROR_PROC_NOT_FOUND);
	return FALSE;
}

BOOL WINAPI HookedClearCommError(
	HANDLE hFile,
	LPDWORD lpErrors,
	LPCOMSTAT lpStat
) {
	//DebugPrintfW(L"Hooked ClearCommError: handle=0x%p\n", hFile);

	if (hFile == VIRTUALHANDLE6 || hFile == VIRTUALHANDLE7) {
		if (lpErrors) {
			*lpErrors = 0; // No error
		}

		if (lpStat) {
			ZeroMemory(lpStat, sizeof(COMSTAT));
			lpStat->fCtsHold = FALSE;
			lpStat->fDsrHold = FALSE;
			lpStat->fRlsdHold = FALSE;
			lpStat->fXoffHold = FALSE;
			lpStat->fXoffSent = FALSE;
			lpStat->fEof = FALSE;
			lpStat->fTxim = FALSE;

			lpStat->cbInQue = 1;  // Simulate 1 byte waiting
			lpStat->cbOutQue = 0; // No pending output
		}

		return TRUE;
	}

	// Fallback to original
	if (originalClearCommError) {
		return originalClearCommError(hFile, lpErrors, lpStat);
	}

	SetLastError(ERROR_PROC_NOT_FOUND);
	return FALSE;
}


int WINAPI HookedShowCursor(BOOL bShow) {
	static bool onerun = false;
	DebugPrintfW(L"Hooked ShowCursor: bShow=%d\n", bShow);
#ifdef SHOW_GAME_CURSOR
	return originalShowCursor(TRUE);
#else
	return originalShowCursor(FALSE);
#endif
}

BOOL WINAPI HookedSetForegroundWindow(HWND hWnd) {
	DebugPrintfW(L"Hooked SetForegroundWindow: hWnd=0x%p\n", hWnd);

	if (IsWindow(hWnd)) {
		CryptoCard::gmainWindow = hWnd;
		// For other windows, simulate setting it as foreground (but do nothing)
#ifdef TOPMOSTWINDOW_ACTIVE
	if (!OneMonitorManipulation::GetInstance().IsMirrorWindowVisible()) {
		DebugPrintfW(L"[TOPWINDOW] call originalSetForegroundWindow.\n");
		originalSetForegroundWindow(hWnd);
	}
#endif
		DebugPrintfW(L"Simulating SetForegroundWindow success.\n");
		return TRUE;
	}

	// Simulate failure like the real API
	SetLastError(ERROR_INVALID_WINDOW_HANDLE);
	return TRUE;
}

#define SRAM_SIZE 1024 * 4  // Or whatever max size you need
uint8_t fakeSram[SRAM_SIZE] = { 0 };

BOOL WINAPI HookedDeviceIoControl(
	HANDLE hDevice,
	DWORD dwIoControlCode,
	LPVOID lpInBuffer,
	DWORD nInBufferSize,
	LPVOID lpOutBuffer,
	DWORD nOutBufferSize,
	LPDWORD lpBytesReturned,
	LPOVERLAPPED lpOverlapped
) {

	if (hDevice == VIRTUALSRAMHANDLE) {
		//DebugPrintfW(L"Hooked DeviceIoControl: code=0x%08X\n", dwIoControlCode);
		if (dwIoControlCode == 0x9C402004 && nInBufferSize == 6 && nOutBufferSize >= 8 && lpOutBuffer) {
			GFORCE_VERSION* out = (GFORCE_VERSION*)lpOutBuffer;
			const GFORCE_VERSION* in = (GFORCE_VERSION*)lpInBuffer;

			// Simulate the same version back, but with correct checksum
			out->version = in->version;
			out->chksum = CalcChecksum(in->version);

			if (lpBytesReturned)* lpBytesReturned = sizeof(GFORCE_VERSION);
			return TRUE;
		}

		else if (dwIoControlCode == 0x9C402000) {
			return TRUE;
		}
		else if (dwIoControlCode == 0x9C402004) {
			if (lpInBuffer && nInBufferSize >= 6 && lpOutBuffer && nOutBufferSize >= 4) {
				const uint8_t* in = (const uint8_t*)lpInBuffer;

				// Extract the SRAM read position (3 bytes little-endian)
				uint32_t pos = in[0] | (in[1] << 8) | (in[2] << 16);

				uint32_t length = in[4];  // in[3] = LSB of v10, in[4] = MSB of v10, together they are 4

				if (pos + length <= SRAM_SIZE) {
					uint32_t chksum = 0;

					// Simulate checksum over 4 bytes at that position
					for (uint32_t i = 0; i < length; ++i) {
						chksum += fakeSram[pos + i];
					}

					*(uint32_t*)lpOutBuffer = chksum;
					if (lpBytesReturned)* lpBytesReturned = sizeof(uint32_t);
					return TRUE;
				}
				else {
					DebugPrintfW(L"SRAM read out of bounds at pos=%u len=%u\n", pos, length);
					SetLastError(ERROR_INVALID_PARAMETER);
					return FALSE;
				}
			}
			SetLastError(ERROR_INVALID_PARAMETER);
			return FALSE;
		}

		SetLastError(ERROR_INVALID_FUNCTION);
		return FALSE;
	}

	if (originalDeviceIoControl)
		return originalDeviceIoControl(hDevice, dwIoControlCode, lpInBuffer, nInBufferSize, lpOutBuffer, nOutBufferSize, lpBytesReturned, lpOverlapped);
}


LSTATUS WINAPI HookedRegQueryValueExW(
	HKEY hKey,
	LPCWSTR lpValueName,
	LPDWORD lpReserved,
	LPDWORD lpType,
	LPBYTE lpData,
	LPDWORD lpcbData
) {
	if (lpValueName && wcscmp(lpValueName, L"ProcessorNameString") == 0) {
#ifdef ISMAIL_RELEASE
		const wchar_t* fakeCpuName = L"Intel(R) Core(TM) V1756-3120 CPU @ 5.80GHz";
#else
		const wchar_t* fakeCpuName = L"Intel(R) Core(TM) i3-3120 CPU @ 5.80GHz";
#endif
		DWORD requiredSize = (wcslen(fakeCpuName) + 1) * sizeof(wchar_t);

		if (lpcbData) {
			if (lpData && *lpcbData >= requiredSize) {
				memcpy(lpData, fakeCpuName, requiredSize);
				if (lpType)* lpType = REG_SZ;
				*lpcbData = requiredSize;
				return ERROR_SUCCESS;
			}
			else {
				*lpcbData = requiredSize;
				return ERROR_MORE_DATA;  // Buffer too small
			}
		}

		return ERROR_INVALID_PARAMETER;
	}

	// Call original for all other cases
	return originalRegQueryValueExW(hKey, lpValueName, lpReserved, lpType, lpData, lpcbData);
}

VOID WINAPI HookedEnterCriticalSection(LPCRITICAL_SECTION lpCriticalSection)
{
    DebugPrintfW(L"[Hook] EnterCriticalSection called: section=0x%p", lpCriticalSection);

    // Optional: simulate deadlock or force skip
    // return; // if you want to suppress it (not recommended)

    // Call the original
    originalEnterCriticalSection(lpCriticalSection);
}