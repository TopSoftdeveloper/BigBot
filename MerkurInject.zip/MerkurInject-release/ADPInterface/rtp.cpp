#include "stdafx.h"
#include "./CryptoCard/StateMachine.h"
#include <chrono>
#include <cmath>
#include <iostream>

static inline int clamp_int(int v, int lo, int hi)
{
	return (v < lo) ? lo : (v > hi) ? hi : v;
}

static inline double clamp_double(double v, double lo, double hi)
{
	return (v < lo) ? lo : (v > hi) ? hi : v;
}

// High-win gate in pickClosestBelow: accept if (myRandom() % 10000) < value (basis points of 10000).
// Tier anchors at multi 4, 8, 16, 32, 64, 100, 128; between anchors we linearly interpolate the two adjacent tiers.
//										   ~8x,   16x, 32x, 64x, 100x, 128x, more    
static const int kHighWinAcceptBpsA[7] = { 6000, 3000, 2000, 1000, 500, 250, 125 }; // ~A: 

static int high_win_accept_bps_for_multi(double multi, const int tierBps[7])
{
	if (multi < 4.0) {
		return 10000;
	}
	if (multi >= 200.0) {
		return 0;
	}
	if (multi >= 128.0) {
		return tierBps[6];
	}

	auto lerp_bps = [](double t, int a, int b) {
		t = clamp_double(t, 0.0, 1.0);
		return static_cast<int>(
			std::lround(static_cast<double>(a) + t * static_cast<double>(b - a)));
	};

	if (multi >= 100.0) {
		return lerp_bps((multi - 100.0) / (128.0 - 100.0), tierBps[5], tierBps[6]);
	}
	if (multi >= 64.0) {
		return lerp_bps((multi - 64.0) / (100.0 - 64.0), tierBps[4], tierBps[5]);
	}
	if (multi >= 32.0) {
		return lerp_bps((multi - 32.0) / (64.0 - 32.0), tierBps[3], tierBps[4]);
	}
	if (multi >= 16.0) {
		return lerp_bps((multi - 16.0) / (32.0 - 16.0), tierBps[2], tierBps[3]);
	}
	if (multi >= 8.0) {
		return lerp_bps((multi - 8.0) / (16.0 - 8.0), tierBps[1], tierBps[2]);
	}
	return lerp_bps((multi - 4.0) / (8.0 - 4.0), tierBps[0], tierBps[1]);
}

double StateMachine::GaussDistribution(double mean, int currentbet, double totalspent, int totalspins)
{
	// 50% shortcut
	if (myRandom() < 5000) {
		return mean / 100.0;
	}

	// Clamp bet
	currentbet = clamp_int(currentbet, 5, 400);

	// baseStdDev mapping
	// Standard deviation derived from currentbet (tweak factor as needed)
	//currentbet	baseStdDev
	//5				~1.52
	//25			~3.47
	//50			~4.58
	//100			~6.59
	//200			~11.25
	//300			~13.73
	//400			15.00 ✅
	const double x = static_cast<double>(currentbet) / 400.0;
	double baseStdDev = 15.0 * std::pow(x, 0.415);

	// Smooth decay by both total spent and total spins (mainbook).
	// This avoids short-term spikes and distributes wins across longer sessions.
	const double maxSpent = 1000000.0;
	const double maxSpins = 5000.0;
	double tSpent = clamp_double(totalspent / maxSpent, 0.0, 1.0);
	double tSpins = clamp_double(static_cast<double>(totalspins) / maxSpins, 0.0, 1.0);
	double spentDecay = 1.0 - std::pow(tSpent, 1.25);
	double spinDecay = 1.0 - std::pow(tSpins, 1.10);
	double decay = 0.55 * spentDecay + 0.45 * spinDecay;
	decay = clamp_double(decay, 0.05, 1.0);
	double stddev = baseStdDev * decay;
	if (stddev <= 0.0) stddev = 1e-4;

	// One RNG per thread, seeded once
	thread_local std::mt19937 rng{ std::random_device{}() };

	std::normal_distribution<double> dist(mean, stddev);
	double value = dist(rng);

	// hard 1σ boundaries
	const double minV = mean - stddev;
	const double maxV = mean + stddev;
	value = clamp_double(value, minV, maxV);

	return std::fabs(value) / 100.0;
}

int gCachedReelSetIdx = -1;
myVector<UINT8> gSpinCache;

void StateMachine::InitCache() {
	gCachedReelSetIdx = -1;
	gSpinCache.clear();
}

ReelGame* CreateReelGameObject(UINT16 GameID);
myVector<UINT8> StateMachine::CalcRTP(BOOL fromCache, int myGen) {
	auto start = std::chrono::high_resolution_clock::now();
	if (g_ReelGame->GetMultiGoEnable()) {
		int reelIdx0 = 0;
		int reelIdx1 = 0;
		int reelIdx2 = 0;
		int reelIdx3 = 0;
		g_ReelGame->GetMultiGoReelPlanIdx(reelIdx0, reelIdx1, reelIdx2, reelIdx3);
		if (g_ReelGame->GetMultiGoEnable() == g_ReelGameTmp->GetMultiGoEnable()) {
			if (g_ReelGame->MultiGoBetStep() == g_ReelGameTmp->MultiGoBetStep()) {
				int cpReelIdx0 = 0;
				int cpReelIdx1 = 0;
				int cpReelIdx2 = 0;
				int cpReelIdx3 = 0;
				g_ReelGameTmp->GetMultiGoReelPlanIdx(cpReelIdx0, cpReelIdx1, cpReelIdx2, cpReelIdx3);

				if (reelIdx0 == cpReelIdx0 && reelIdx1 == cpReelIdx1 && reelIdx2 == cpReelIdx2 && reelIdx3 == cpReelIdx3) {
					if (gSpinCache.size() > 0 && fromCache) {
						DebugPrintf("ERROR: bbb From Cache");
						return gSpinCache;
					}
				}
			}
		}
		g_ReelGameTmp->SetMultiGoEnable(TRUE);
		g_ReelGameTmp->SetMultiGoBetStep(g_ReelGame->MultiGoBetStep());
		g_ReelGameTmp->SetMultiGoReelPlanIdx(reelIdx0, reelIdx1, reelIdx2, reelIdx3);
	}
	else {
		int curReelSetIdx = g_ReelGame->CurrentReelSetIdx();
		if (fromCache && gSpinCache.size() > 0 && gCachedReelSetIdx == curReelSetIdx && m_bFreeMode == FALSE && m_nGameID != GOC_RgKeyOfTheNile) {
			//DebugPrintf("ERROR: strange From Cache");
			return gSpinCache;
		}
		gCachedReelSetIdx = curReelSetIdx;
		g_ReelGameTmp->ChangeReelStrip(gCachedReelSetIdx);
		g_ReelGameTmp->SetBets(g_ReelGame->Bets());
		g_ReelGameTmp->SetBetStep(g_ReelGame->BetStep());
		g_ReelGameTmp->SetWinLine(g_ReelGame->GetWinLine());
		g_ReelGameTmp->SetBonus(g_ReelGame->GetBonus());
		g_ReelGameTmp->SetMultiGoEnable(FALSE);
	}

	ReelGame* rg = NULL;
	if (m_bFreeMode == TRUE) {
		rg = g_ReelGame;
	}
	else {
		rg = g_ReelGameTmp;
	}
	if (m_nGameID == GOC_RgKeyOfTheNile) {
		rg = g_ReelGame;
	}
	{
		// critical fix: validBet is the bet bit of the current spin
		UINT16 validBet = g_ReelGame->BetBit();
		if (m_bMultoGo) {
			validBet = 0;
		}

		if (rg->GetMultiGoEnable()) {
			validBet = 4 * AT(rg->Bets(), rg->MultiGoBetStep());
		}
		// Use atomic loads to safely read gTotalBet and gTotalWin
		double currentTotalBet = gTotalBet.load();
		double currentTotalWin = gTotalWin.load();
		int betbit = (m_bFreeMode ? 0 : validBet);
		auto& playDB = PlayDB::GetInstance();
		const int mainTotalSpins = playDB.GetMainBookTotalSpins();
		double gauseRTP = StateMachine::GaussDistribution(gTargetRTP * 100.0, validBet, currentTotalBet, mainTotalSpins);

		// Use GauseRTP for first small number of spins.  
		double totalBetDouble = currentTotalBet + static_cast<double>(betbit);
		double targetTotalWin = totalBetDouble * gauseRTP;
		int maxAllowedWin = static_cast<int>(targetTotalWin - (currentTotalWin + m_nBonusBit.coin * rg->GetMultiGoEnable()));

		if (maxAllowedWin < 0) {
			maxAllowedWin = 0;
		}

		struct SpinCandidate {
			myVector<WinMeter> meters;
			UINT64 normalMeter;
			UINT64 maxMeter;
			SoundItem bonusSoundItem;
			myVector<UINT8> result;
			UINT32 totalBonus;
			UINT32 totalAG;
			BOOL canFree;
		};

		int loopCnt = 0;
		const int MAX_LOOP_ITERATIONS = 10000;  // CRITICAL FIX: Prevent infinite loop
		myVector<SpinCandidate> candidates;
		while (candidates.size() < 0x80 && loopCnt < MAX_LOOP_ITERATIONS) {
			if (myGen != StateMachine::g_rtpGeneration.load())
			{
				gSpinCache.clear();
				DebugPrintf("ERROR: aaa FAST closing loop %zu", candidates.size());

				return myVector<UINT8>();
			}

			loopCnt++;
			if ((loopCnt % 200) == 0) {
				DebugPrintf("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& choosing reelStrip... %d", loopCnt);
			}

			SpinCandidate c;
			c.normalMeter = 0;
			c.maxMeter = 0;
			c.bonusSoundItem = { 0, "", 0 };
			c.meters.clear();
			c.canFree = FALSE;

			c.result = rg->Win(c.meters, c.normalMeter, c.maxMeter, c.bonusSoundItem, TRUE, myVector<UINT8> {}, c.canFree);
			c.totalBonus = 0;
			c.totalAG = 0;

			for (const auto& meter : c.meters) {
				c.totalBonus += meter.bonus.coin + meter.bonus.ag * 1000;
				c.totalAG += meter.bonus.ag;
			}
			
			if (m_bFreeMode == TRUE || m_bMultoGo == TRUE || m_nGameID == GOC_RgPharosGoldBase) { // prevent match ag in freemode and multigo
				if (c.totalAG > 0) {
					continue;
				}
			}
			if (rg->SelectedableReelsInFreeGame(c.result) == FALSE) {
				continue;
			}
			// when enter freemode, have to avoid ag game
			if (c.canFree == TRUE && c.totalAG > 0) {
				continue;
			}

			//special for games
			//1. IndianRuby: avoid too much 2 elephants bonus
			if (m_nGameID == GOC_RgIndianRuby && c.canFree == TRUE) {
				c.totalBonus = validBet * 12;
				c.canFree = FALSE;
			}
			candidates.push_back(c);
		}

		UINT forceMultiplier = 32; // default forceMultiplier
		int randPercent = myRandom() % 100; // random number between 0–999

		auto variant = PlayDB::GAME_VARIANT_A;
		if (randPercent < 10)          // 10% chance
			forceMultiplier = 100;
		else if (randPercent < 20)     // next 10%
			forceMultiplier = 64;

		//Reduce forceMultiplier according to the current bet step
		int currentbet = clamp_int(validBet, 5, 400);
		const double xxxx = static_cast<double>(currentbet) / 400.0;
		forceMultiplier = static_cast<UINT>(forceMultiplier * std::pow(xxxx, 0.415));

		const UINT bigWinThreshold = validBet * forceMultiplier;
		const bool forceBigWinThisSpin = rg->RTP_force_bigWin();// 1.3%
		DebugPrintf("[Gause]RTP... %.6f, AllowedWin... %d, BigWin... %d Multipler... %u",
			gauseRTP, maxAllowedWin, static_cast<int>(forceBigWinThisSpin), forceMultiplier);
		DebugPrintf("[Gause]totalBet... %.0f, totalWin... %.0f, currentBet... %u",
			currentTotalBet, currentTotalWin, static_cast<unsigned>(validBet));
		// helpers
		auto pickClosestBelow = [&](UINT cap, bool requireWeight5, int& outIdx) {
			// pick the candidate with bonus <= cap, closest to cap (largest bonus)
			UINT best = 0;
			int idx = -1;
			const int* tierBps = kHighWinAcceptBpsA;
			// Variant B/C are disabled for now.
			tierBps = kHighWinAcceptBpsA;
			// One roll per pickClosestBelow call; basis points so sub-1% tiers work.
			const int highWinGateRoll = myRandom() % 10000;
			for (int i = 0; i < (int)candidates.size(); ++i) {

				if (AT(candidates, i).canFree) {
					continue;
				}
				UINT b = AT(candidates, i).totalBonus;
				if (validBet > 0) {
					const double multi = static_cast<double>(b) / static_cast<double>(validBet);
					const int acceptBps = high_win_accept_bps_for_multi(multi, tierBps);
					if (highWinGateRoll >= acceptBps) {
						continue;
					}
				}
				if (b <= cap && b >= best) {
					best = b;
					idx = i;
				}
			}
			outIdx = idx;
		};

		auto pickFree = [&](int& outIdx) {
			UINT lowest = 0x7fffffff;
			int idx = -1;
			for (int i = 0; i < (int)candidates.size(); ++i) {
				if (AT(candidates, i).canFree) {
					// if (!respectsHardRtpCap(AT(candidates, i))) {
					// 	continue;
					// }
					if (AT(candidates, i).totalBonus < lowest) {
						lowest = AT(candidates, i).totalBonus;
						idx = i;
					}
				}
			}

			outIdx = idx;
		};

		auto pickNoWin = [&](int& outIdx, unsigned int currentBet, int probabilityDivisor) {
			// Unmatch (!pickSame): all strict no-win candidates (totalBonus==0), then random.
			// No early return with "match" small-win (pickSame) — fallback to lowest bonus below.
			int idx = -1;
			UINT lowestNZ = currentBet * 2;
			//C:2.5%, B:5%, A:10%
			bool pickSame = (probabilityDivisor == -1) ? 0 : ((myRandom() % probabilityDivisor) == 0);

			if (!pickSame) {
				myVector<int> unmatchIdx;
				for (int i = 0; i < (int)candidates.size(); ++i) {
					if (AT(candidates, i).canFree) {
						continue;
					}
					if (AT(candidates, i).totalBonus == 0) {
						unmatchIdx.push_back(i);
					}
				}
				if (unmatchIdx.size() > 0) {
					outIdx = AT(unmatchIdx, myRandom() % (int)unmatchIdx.size());
					return;
				}
			}
			DebugPrintf("[Gause] Pick Same or 2x... win = %d", lowestNZ);
			for (int i = 0; i < (int)candidates.size(); ++i) {
				if (AT(candidates, i).canFree) {
					continue;
				}

				UINT b = AT(candidates, i).totalBonus;
				if (b <= lowestNZ && b != 0) {
					outIdx = i;
					return;
				}
			}
			outIdx = idx;
		};

		int bestIndex = -1;

		//get candidate from maxAllowedWin. if not check force big win rate
		if (bestIndex == -1) {
			if (maxAllowedWin > 0) {
				int maxWinBranchPct = 10;	//10% max allowed win
				if ((myRandom() % 100) < maxWinBranchPct) {
					DebugPrintf("[Gause] pick from maxAllowedWin");
					pickClosestBelow((UINT)maxAllowedWin, /*requireWeight5=*/false, bestIndex);
				}
				else {
					//in this case, let's give free spin chance
					if(forceBigWinThisSpin){
						DebugPrintf("[Gause] giving freespin: bestIndex = %d", bestIndex);
						if ((myRandom() % 6) == 0) { // 16.6% freemode
							DebugPrintf("[Gause] freespin is made");
							pickFree(bestIndex);
						}
					}
					else {
						pickNoWin(bestIndex, validBet, 11);	// 9.9% chance same or 2x bet
					}
				}
			}
			// 5% forced big win up to betbit*10, preferring weight==5
			else if (forceBigWinThisSpin) {
				if ((myRandom() % 4) == 0) { // 25% freemode
					pickFree(bestIndex);
				}

				if (bestIndex == -1) {
					pickClosestBelow(bigWinThreshold, /*requireWeight5=*/false, bestIndex);
				}
			}
			else {
				//It's being used in Free spin mode
				if (rg->NoFunInFreeMode()) {
					if (m_bFreeMode && (myRandom() % 4) == 0) {
						int mul = 4 + (myRandom() % 5);
						pickClosestBelow(mul * (UINT)validBet, /*requireWeight5=*/false, bestIndex);
					}
				}
			}
		}

		// To stop too much dead spin
		if (bestIndex == -1) {
			int probabilityDivisor = 5; // Default (5 → 20%)
			probabilityDivisor = 30; // Variant A only

			if ((myRandom() % probabilityDivisor) == 0) {
				// up to 8 * betbit
				DebugPrintf("[Gause] pick from 16x win");
				pickClosestBelow((UINT)(16u * (UINT)validBet), /*requireWeight5=*/false, bestIndex);
				if (bestIndex == -1) {
					pickNoWin(bestIndex, validBet, -1);
				}
			}
			else {
				pickNoWin(bestIndex, validBet, 9); //11.1%
			}
		}

#ifdef TEST_RTP_RANDOM_FALLBACK
		// Test hook: force invalid index to verify random fallback path.
		if (candidates.size() > 0) {
			DebugPrintf("TEST_RTP_RANDOM_FALLBACK: forcing bestIndex=-1 with non-empty candidates");
			bestIndex = -1;
		}
#endif


		// CRITICAL FIX: Ensure bestIndex is valid before accessing array
		if (bestIndex < 0 || bestIndex >= (int)candidates.size()) {
			DebugPrintf("[Gause] ERROR:  Invalid bestIndex=%d, candidates.size()=%zu, using random fallback", bestIndex, candidates.size());

			//if (candidates.size() == 0) {
			//	gSpinCache.clear();
			//	return gSpinCache;
			//}

			// Try to recover by generating a fresh strict no-win candidate (bounded: unbounded loop pegs one core).
			const int MAX_REGEN_NO_WIN = 20000;
			int regen = 0;
			for (; regen < MAX_REGEN_NO_WIN; ++regen) {
				//if (myGen != StateMachine::g_rtpGeneration.load()) {
				//	gSpinCache.clear();
				//	return gSpinCache;
				//}
				SpinCandidate rc;
				rc.normalMeter = 0;
				rc.maxMeter = 0;
				rc.bonusSoundItem = { 0, "", 0 };
				rc.meters.clear();
				rc.canFree = FALSE;
				rc.result = rg->Win(rc.meters, rc.normalMeter, rc.maxMeter, rc.bonusSoundItem, TRUE, myVector<UINT8>{}, rc.canFree);
				rc.totalBonus = 0;
				rc.totalAG = 0;
				
				if (m_bFreeMode == TRUE || m_bMultoGo == TRUE || m_nGameID == GOC_RgPharosGoldBase) { // prevent match ag in freemode and multigo
					if (rc.totalAG > 0) {
						continue;
					}
				}
				
				if (rg->SelectedableReelsInFreeGame(rc.result) == FALSE) {
					continue;
				}
				if (rc.canFree == TRUE && rc.totalAG > 0) {
					continue;
				}
				
				for (const auto& meter : rc.meters) {
					rc.totalBonus += meter.bonus.coin + meter.bonus.ag * 1000;
					rc.totalAG += meter.bonus.ag;
				}

				UINT32 bonusMult = 0;
				//special for games
				//1. IndianRuby: avoid too much 2 elephants bonus
				if (m_nGameID == GOC_RgIndianRuby && rc.canFree == TRUE) {
					rc.canFree = FALSE;
				}
				// strict no-win or under 16x bet
				if (regen < 1000)
					bonusMult += 2;
				else if (regen < 2000)
					bonusMult += 4;
				else if (regen < 3000)
					bonusMult += 8;
				else if (regen < 4000)
					bonusMult += 16;
				else if (regen < 5000)
					bonusMult += 32;
				else if (regen < 6000)
					bonusMult += 64;
				else
					bonusMult += 128;

				if (rc.canFree == FALSE && rc.totalBonus <= (UINT32)validBet * bonusMult) {
					DebugPrintf("[Gause] ERROR: Found recover mode = %d, bonus = %d", regen + 1, rc.totalBonus);
					gSpinCache = rc.result;
					return gSpinCache;
				}

				if ((regen % 1000) == 999) {
					DebugPrintf("[Gause] ERROR: Regenerating no-win candidate... attempts=%d", regen + 1);
				}
			}

			DebugPrintf("[Gause] CRITICAL ERROR: no Candidate", MAX_REGEN_NO_WIN);
			gSpinCache = AT(candidates, myRandom() % (int)candidates.size()).result;
			return gSpinCache;

		}

#ifdef TEST_WILD
		gSpinCache = AT(candidates, myRandom() % candidates.size()).result;
#else
		gSpinCache = AT(candidates, bestIndex).result;
#endif
	}

	auto end = std::chrono::high_resolution_clock::now();
	auto ms =
		std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
	DebugPrintf("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& CalcRTP exec time: %lldms", static_cast<long long>(ms.count()));
	return gSpinCache;
}