#include "StdAfx.h"
#include "EapiAPIEX_IES.h"
#include "GlobalVar.h"
#include "stdlib.h"
#include "PhysicalMonitorEnumerationAPI.h"
#include "LowLevelMonitorConfigurationAPI.h"
#pragma comment (lib, "dxva2.lib")

DWORD g_dword_1001F6BC;
HMODULE hEAPI_IES; 
LPVOID g_dword_1001F6B8 = NULL;
BYTE g_dword_1001F678[64];
wchar_t g_wsz1001F5F8[32];

// LPEApiLibUnInitialize g_lpfnEApiLibUnInitializeIES = 0;
// LPEApiLibInitialize g_lpfnEApiLibInitializeIES ;
// LPEApiI2CReadTransfer EApiI2CReadTransfer = 0;
// LPEApiI2CWriteTransfer EApiI2CWriteTransfer = 0;
// LPEApiWDogGetCap EApiWDogGetCap  = 0;
// LPEApiWDogTrigger EApiWDogTrigger = 0;
// LPEApiVgaGetBacklightBrightness EApiVgaGetBacklightBrightness = 0;
// LPEApiVgaSetBacklightBrightness EApiVgaSetBacklightBrightness = 0;
// LPEApiBoardGetValue EApiBoardGetValue = 0;

LPOut32  Out32 = 0;
LPInp32  Inp32 = 0;
BOOL CALLBACK fnEnumProc_10007CA0( HMONITOR hMonitor,  // handle to display monitor
					 HDC hDC,     // handle to monitor DC
					 LPRECT rect, // monitor intersection rectangle
					 LPARAM dwData )      // data????????
{
	myMonitorInfo myMonInfo; 
	myMonInfo.hdc = hDC;
	myMonInfo.hMonitor = hMonitor;
	myMonInfo.rect.left = rect->left;
	myMonInfo.rect.top = rect->top;
	myMonInfo.rect.right = rect->right;
	myMonInfo.rect.bottom = rect->bottom;
	myMonInfo.nInfo = 0;
	myMonInfo.nInfoFlag = 0;
	addNewDisplayInfoToList(dwData, &myMonInfo);
	g_dword_1001F6BC = dwData;	

	return 1;
}

LPinfoStructure sub_10006E50(LPinfoStructure lParam)
{
	LPinfoStructure curr_info; // eax@1
	LPinfoStructure next_info; // ecx@1
	LPinfoStructure prev_info; // esi@1
	LPinfoStructure result; // eax@4

	curr_info = lParam;
	next_info = lParam->next;
	for ( prev_info = lParam; next_info; next_info = (next_info->next) )
	{
		prev_info = curr_info;
		curr_info = next_info;
	}
	if ( curr_info )
	{
		free(curr_info);
		prev_info->next = NULL;
		result = prev_info;
	}
	else
	{
		result = NULL;
	}
	return result;
}

CEapiAPIEX_IES::CEapiAPIEX_IES(void)/// sub_10007D30 sub_10007CA0
{
	m_dw18 = 0;
	infoStructure* pInfoStr;
	pInfoStr = new infoStructure;
	pInfoStr->nMonIdx = -1;
	pInfoStr->next = 0;
	myMonitorInfo* pMyMonInfo;
	pMyMonInfo = new myMonitorInfo;// malloc(544); 0x220
	pInfoStr->myMoninfo = pMyMonInfo;
	memset(pMyMonInfo, 0, sizeof(myMonitorInfo));
	m_pInfoStart = pInfoStr;
	m_pInfoLast = pInfoStr;
	int nNumMonitor = GetSystemMetrics(SM_CMONITORS);
	MONITORINFOEXW moninfo;
	moninfo.cbSize = 104;
	m_pInfoLast->nMonIdx = 0;	
	m_pInfoLast->myMoninfo->nInfo = 0;

	EnumDisplayMonitors(0,0,fnEnumProc_10007CA0, (LPARAM)m_pInfoLast);

	m_pInfoLast = m_pInfoLast->next;
	if(m_pInfoLast->nMonIdx <= nNumMonitor)
	{
		HMONITOR hMonitor;
		while(1)
		{
			hMonitor = m_pInfoLast->myMoninfo->hMonitor;
			GetMonitorInfoW(hMonitor, &moninfo);
			wcscpy_s(m_pInfoLast->myMoninfo->wszDevice, 0xFF, moninfo.szDevice);
			m_pInfoLast->myMoninfo->nInfoFlag = moninfo.dwFlags;
			m_pInfoLast = m_pInfoLast->next;
			if (!m_pInfoLast) break;	
			if (m_pInfoLast->nMonIdx > nNumMonitor) break;
		}
	}
	m_hModEAPI_IES = 0;
}

CEapiAPIEX_IES::~CEapiAPIEX_IES(void)
{

}



void CEapiAPIEX_IES::sub_10006F60()
{
	m_pInfoLast = m_pInfoStart;
	if (m_pInfoStart->nMonIdx == 0)
	{
		infoStructure* pVarInfo_c;
		infoStructure* pVarInfo_a;
		infoStructure* pVarInfo_i;
		pVarInfo_a = m_pInfoStart;
		while(1)
		{		
			pVarInfo_c = pVarInfo_a->next;
			pVarInfo_i = pVarInfo_a;
			if (pVarInfo_c)
			{
				while(1)
				{
					pVarInfo_i = pVarInfo_a;
					pVarInfo_a = pVarInfo_c;
					pVarInfo_c = pVarInfo_a->next;					
					if(pVarInfo_c == 0) break;
				}
			}
			if(pVarInfo_a->nMonIdx == 0) break;//*(DWORD*)dwtmpa
			delete pVarInfo_a;
			pVarInfo_i->next = 0;
			pVarInfo_a = m_pInfoStart;
			pVarInfo_c = pVarInfo_a;
			m_pInfoLast = pVarInfo_a;
			if (pVarInfo_c->nMonIdx != 0) break; //*(DWORD*)dwtmpc
		}
	}
	delete m_pInfoStart;
	m_dw18 = -1;

	if (m_hModEAPI_IES)
	{
// 		g_lpfnEApiLibUnInitializeIES = (LPEApiLibUnInitialize)GetProcAddress(m_hModEAPI_IES, "EApiLibUnInitialize");
// 		if ((DWORD)g_lpfnEApiLibUnInitializeIES)
// 		{
// 			g_lpfnEApiLibUnInitializeIES();
// 		}
		EApiLibUnInitialize();
	}
	if (m_hModEAPI_IES)
	{
		FreeLibrary(m_hModEAPI_IES);
	}
	m_hModEAPI_IES = NULL;
}

VOID CEapiAPIEX_IES::sub_10006E90()// constructor 
{
	m_pInfoLast = m_pInfoStart;
	DWORD dwEnd = m_dw04;
	infoStructure* curr_info = m_pInfoStart;// eax
	infoStructure* next_info = 0;//ecx
	infoStructure* prev_info = 0;//edi = 0;// prev
	if(next_info = m_pInfoStart->next)
	{
		do 
		{
			prev_info = curr_info;
			curr_info = next_info;
			next_info = curr_info->next;
		} while (next_info!=0);
	}
	//loc_10006EE1:
	if(curr_info == NULL) prev_info = NULL;
	else {
		delete curr_info;
		prev_info->next = NULL;
	}

	if(prev_info->nMonIdx != -1)
		sub_10006E50(prev_info);
	if(m_hModEAPI_IES){
// 		g_lpfnEApiLibUnInitializeIES = (LPEApiLibUnInitialize)GetProcAddress(m_hModEAPI_IES, "EApiLibUnInitialize");
// 		if(g_lpfnEApiLibUnInitializeIES) g_lpfnEApiLibUnInitializeIES();
		EApiLibUnInitialize();
	}
	if(m_hModEAPI_IES)
		FreeLibrary(m_hModEAPI_IES);
	m_hModEAPI_IES = NULL;
	//sub_1000B430();//CUniAPI_constructor

	
}

HANDLE CEapiAPIEX_IES::sub_10007E40(BOOL flag)// constructor(BOOL flag)
{
	sub_10006E90();//constructor()
	if(!flag) delete this;
	return  this;
}
DWORD 	CEapiAPIEX_IES::sub_10006240()
{
	//LPEApiBoardGetValue EApiBoardGetValue = NULL;
	DWORD ret = 0;
	if ( m_hModEAPI_IES )
	{
		//EApiBoardGetValue = (LPEApiBoardGetValue)GetProcAddress(m_hModEAPI_IES, "EApiBoardGetValue");
// 		if ( EApiBoardGetValue )
// 		{
			if(EApiBoardGetValue(0, &ret)) return 0;
			return ret;
			//return v4 == 0 ? v9 : 0;
//		}
	}
	else
	{
		m_hModEAPI_IES = LoadLibraryW(L"EAPI.dll");
		//*(DWORD *)(v1 + 20) = v6;
// 		EApiBoardGetValue = (LPEApiBoardGetValue)GetProcAddress(m_hModEAPI_IES, "EApiBoardGetValue");
// 		if ( EApiBoardGetValue )
// 		{
			if(EApiBoardGetValue(0, &ret)) return 0;
			return ret;
//		}
	}
	return 0;

}
int  CEapiAPIEX_IES::sub_10006FF0(ArrayStr* pArrayStr)
{
	int var_4 = 32;
	g_dword_1001F6B8 = malloc(32);
	LPEApiBoardGetStringA  EApiBoardGetStringA = NULL;
	
	if(m_hModEAPI_IES)
	{
		EApiBoardGetStringA = (LPEApiBoardGetStringA)GetProcAddress(m_hModEAPI_IES, "EApiBoardGetStringA");
		pArrayStr->nSize = (int)EApiBoardGetStringA;
		
	}
	else{
		m_hModEAPI_IES = LoadLibraryW(L"EAPI.dll");
		if(m_hModEAPI_IES)
		{
			EApiBoardGetStringA = (LPEApiBoardGetStringA)GetProcAddress(m_hModEAPI_IES, "EApiBoardGetStringA");
			pArrayStr->nSize = (int)EApiBoardGetStringA;

		}
	}
	if(m_hModEAPI_IES && EApiBoardGetStringA)
	{//loc_10007059: 
		int ret = EApiBoardGetStringA(0, g_dword_1001F6B8, (LPDWORD)&var_4);
		if( ret==0)
		{
			memset(g_dword_1001F678, 0, 64);
			memset(g_wsz1001F5F8, 0, 64);
			FormatStrA_100086A0(g_dword_1001F678, 64, "%s", g_dword_1001F6B8);
			int nLen = strlen((const char*)g_dword_1001F678);
			int i = 0, j=0;
			for(i = 0, j = 0; i < nLen; i++, j++)
			{
				if(i >= 32) break;
				g_wsz1001F5F8[i] = g_dword_1001F678[i];
				if(g_dword_1001F678[i]==0x20 &&((g_dword_1001F678[i+1]==0x20) || (g_dword_1001F678[i+1]==0x00)))
					break;
			}
			g_wsz1001F5F8[i] = 0;
			FormatStrW_100052F0(pArrayStr->wszStr_C4, 32, L"%s", g_wsz1001F5F8);

		}//loc_10007130
		else if(ret ==0xFFFFF9FF)
		{
			free(g_dword_1001F6B8);
			g_dword_1001F6B8 = malloc(32);
			memset(g_dword_1001F6B8, 0, 32);
			if(!EApiBoardGetStringA(0, g_dword_1001F6B8, (LPDWORD)&var_4))
			{
				memset(g_dword_1001F678, 0, 64);
				memset(g_wsz1001F5F8, 0, 64);
				FormatStrA_100086A0(g_dword_1001F678, 64, "%s", g_dword_1001F6B8);
				int nLen = strlen((const char*)g_dword_1001F678);
				int i = 0, j=0;
				for(i = 0, j = 0; i < nLen; i++, j++)
				{
					if(i >= 32) break;
					g_wsz1001F5F8[i] = g_dword_1001F678[i];
					if(g_dword_1001F678[i]==0x20 &&((g_dword_1001F678[i+1]==0x20) || (g_dword_1001F678[i+1]==0x00)))
						break;
				}
				g_wsz1001F5F8[i] = 0;
				FormatStrW_100052F0(pArrayStr->wszStr_C4, 32, L"%s", g_wsz1001F5F8);
			}


		}
		else if(ret == 0xFFFFFCFF)
		{
			wcscpy_s((wchar_t *)pArrayStr->wszStr_C4, 32, L"UNSUPPORTED");
		}
		else{
			FormatStrW_100052F0(pArrayStr->wszStr_C4, 32, L"EC %u", 0);
		}

	}
	//// 1000722F
	if(g_dword_1001F6B8) free(g_dword_1001F6B8);
	g_dword_1001F6B8 = malloc(32);
	memset(g_dword_1001F6B8, 0, 32);
	wchar_t* pFormat = NULL;
	wchar_t* pDest = NULL;
	wchar_t* pSrc = NULL;
	if(EApiBoardGetStringA)
	{
		int ret = EApiBoardGetStringA(1, g_dword_1001F6B8, (LPDWORD)&var_4);
		if(ret == 0)
		{
			memset(g_dword_1001F678, 0, 64);
			memset(g_wsz1001F5F8, 0, 64);
			FormatStrA_100086A0(g_dword_1001F678, 64, "%s", g_dword_1001F6B8);
			int nLen = strlen((const char*)g_dword_1001F678);
			int i = 0, j=0;
			for(i = 0, j = 0; i < nLen; i++, j++)
			{
				if(i >= 32) break;
				g_wsz1001F5F8[i] = g_dword_1001F678[i];
				if(g_dword_1001F678[i]==0x20 &&((g_dword_1001F678[i+1]==0x20) || (g_dword_1001F678[i+1]==0x00)))
					break;
			}
			g_wsz1001F5F8[i] = 0;
			pSrc = g_wsz1001F5F8;
			pFormat = L"%s";
			pDest = (wchar_t*)pArrayStr->wszStr_04;
			
		}
		else if(ret == 0xFFFFF9FF)
		{
			free(g_dword_1001F6B8);
			g_dword_1001F6B8 = malloc(32);
			memset(g_dword_1001F6B8, 0, 32);
			if(!EApiBoardGetStringA(1, g_dword_1001F6B8, (LPDWORD)&var_4))
			{
				memset(g_dword_1001F678, 0, 64);
				memset(g_wsz1001F5F8, 0, 64);
				FormatStrA_100086A0(g_dword_1001F678, 64, "%s", g_dword_1001F6B8);
				int nLen = strlen((const char*)g_dword_1001F678);
				int i = 0, j=0;
				for(i = 0, j = 0; i < nLen; i++, j++)
				{
					if(i >= 32) break;
					g_wsz1001F5F8[i] = g_dword_1001F678[i];
					if(g_dword_1001F678[i]==0x20 &&((g_dword_1001F678[i+1]==0x20) || (g_dword_1001F678[i+1]==0x00)))
						break;
				}
				g_wsz1001F5F8[i] = 0;
				pSrc = g_wsz1001F5F8;
				pFormat = L"%s";
				pDest = (wchar_t*)pArrayStr->wszStr_04;
				
			}

		}
		else if(ret == 0xFFFFFCFF)
		{
			wcscpy_s((wchar_t *)pArrayStr->wszStr_04, 32, L"UNSUPPORTED");
		}
		else{
			pFormat = L"EC %u";
			pDest = (wchar_t*)pArrayStr->wszStr_04;
			pSrc = NULL;
			//FormatStrW_100052F0(arrayStr.wszStr1, 32, L"EC %u", 0);
		}
		
		FormatStrW_100052F0(pDest, 32, pFormat, pSrc);
	}

///////////////////////////// 3 /////////////////////////////////////////////
	if(g_dword_1001F6B8) free(g_dword_1001F6B8);
	g_dword_1001F6B8 = malloc(32);
	memset(g_dword_1001F6B8, 0, 32);
	if(EApiBoardGetStringA)
	{//loc_10007059: 
		int ret = EApiBoardGetStringA(3, g_dword_1001F6B8, (LPDWORD)&var_4);
		if( ret==0)
		{
			memset(g_dword_1001F678, 0, 64);
			memset(g_wsz1001F5F8, 0, 64);
			FormatStrA_100086A0(g_dword_1001F678, 64, "%s", g_dword_1001F6B8);
			int nLen = strlen((const char*)g_dword_1001F678);
			int i = 0, j=0;
			for(i = 0, j = 0; i < nLen; i++, j++)
			{
				if(i >= 32) break;
				g_wsz1001F5F8[i] = g_dword_1001F678[i];
				if(g_dword_1001F678[i]==0x20 &&((g_dword_1001F678[i+1]==0x20) || (g_dword_1001F678[i+1]==0x00)))
					break;
			}
			g_wsz1001F5F8[i] = 0;
			FormatStrW_100052F0(pArrayStr->wszStr_110, 32, L"%s", g_wsz1001F5F8);

		}//loc_10007130
		else if(ret ==0xFFFFF9FF)
		{
			free(g_dword_1001F6B8);
			g_dword_1001F6B8 = malloc(32);
			memset(g_dword_1001F6B8, 0, 32);
			if(!EApiBoardGetStringA(3, g_dword_1001F6B8, (LPDWORD)&var_4))
			{
				memset(g_dword_1001F678, 0, 64);
				memset(g_wsz1001F5F8, 0, 64);
				FormatStrA_100086A0(g_dword_1001F678, 64, "%s", g_dword_1001F6B8);
				int nLen = strlen((const char*)g_dword_1001F678);
				int i = 0, j=0;
				for(i = 0, j = 0; i < nLen; i++, j++)
				{
					if(i >= 32) break;
					g_wsz1001F5F8[i] = g_dword_1001F678[i];
					if(g_dword_1001F678[i]==0x20 &&((g_dword_1001F678[i+1]==0x20) || (g_dword_1001F678[i+1]==0x00)))
						break;
				}
				g_wsz1001F5F8[i] = 0;
				FormatStrW_100052F0(pArrayStr->wszStr_110, 32, L"%s", g_wsz1001F5F8);
			}


		}
		else if(ret == 0xFFFFFCFF)
		{
			wcscpy_s((wchar_t *)pArrayStr->wszStr_110, 32, L"UNSUPPORTED");
		}
		else{
			FormatStrW_100052F0(pArrayStr->wszStr_110, 32, L"EC %u", 0);
		}

	}
	///////////////////////////////// 5 /////////////////////////////////////////
	if(g_dword_1001F6B8) free(g_dword_1001F6B8);
	g_dword_1001F6B8 = malloc(32);
	memset(g_dword_1001F6B8, 0, 32);
	if(EApiBoardGetStringA)
	{//loc_10007059: 
		int ret = EApiBoardGetStringA(5, g_dword_1001F6B8, (LPDWORD)&var_4);
		if( ret==0)
		{
			memset(g_dword_1001F678, 0, 64);
			memset(g_wsz1001F5F8, 0, 64);
			FormatStrA_100086A0(g_dword_1001F678, 64, "%s", g_dword_1001F6B8);
			int nLen = strlen((const char*)g_dword_1001F678);
			int i = 0, j=0;
			for(i = 0, j = 0; i < nLen; i++, j++)
			{
				if(i >= 32) break;
				g_wsz1001F5F8[i] = g_dword_1001F678[i];
				if(g_dword_1001F678[i]==0x20 &&((g_dword_1001F678[i+1]==0x20) || (g_dword_1001F678[i+1]==0x00)))
					break;
			}
			g_wsz1001F5F8[i] = 0;
			FormatStrW_100052F0(pArrayStr->wszStr_44, 32, L"%s", g_wsz1001F5F8);

		}//loc_10007130
		else if(ret ==0xFFFFF9FF)
		{
			free(g_dword_1001F6B8);
			g_dword_1001F6B8 = malloc(32);
			memset(g_dword_1001F6B8, 0, 32);
			if(!EApiBoardGetStringA(5, g_dword_1001F6B8, (LPDWORD)&var_4))
			{
				memset(g_dword_1001F678, 0, 64);
				memset(g_wsz1001F5F8, 0, 64);
				FormatStrA_100086A0(g_dword_1001F678, 64, "%s", g_dword_1001F6B8);
				int nLen = strlen((const char*)g_dword_1001F678);
				int i = 0, j=0;
				for(i = 0, j = 0; i < nLen; i++, j++)
				{
					if(i >= 32) break;
					g_wsz1001F5F8[i] = g_dword_1001F678[i];
					if(g_dword_1001F678[i]==0x20 &&((g_dword_1001F678[i+1]==0x20) || (g_dword_1001F678[i+1]==0x00)))
						break;
				}
				g_wsz1001F5F8[i] = 0;
				FormatStrW_100052F0(pArrayStr->wszStr_44, 32, L"%s", g_wsz1001F5F8);
			}


		}
		else if(ret == 0xFFFFFCFF)
		{
			wcscpy_s((wchar_t *)pArrayStr->wszStr_44, 32, L"UNSUPPORTED");
		}
		else{
			FormatStrW_100052F0(pArrayStr->wszStr_44, 32, L"EC %u", 0);
		}

	}
	//////////////////////////////////////////////////////////////////////////
	///////////////////////////////// 4 /////////////////////////////////////////
	if(g_dword_1001F6B8) free(g_dword_1001F6B8);
	g_dword_1001F6B8 = malloc(32);
	memset(g_dword_1001F6B8, 0, 32);
	if(EApiBoardGetStringA)
	{//loc_10007059: 
		int ret = EApiBoardGetStringA(4, g_dword_1001F6B8, (LPDWORD)&var_4);
		if( ret==0)
		{
			memset(g_dword_1001F678, 0, 64);
			memset(g_wsz1001F5F8, 0, 64);
			FormatStrA_100086A0(g_dword_1001F678, 64, "%s", g_dword_1001F6B8);
			int nLen = strlen((const char*)g_dword_1001F678);
			int i = 0, j=0;
			for(i = 0, j = 0; i < nLen; i++, j++)
			{
				if(i >= 32) break;
				g_wsz1001F5F8[i] = g_dword_1001F678[i];
				if(g_dword_1001F678[i]==0x20 &&((g_dword_1001F678[i+1]==0x20) || (g_dword_1001F678[i+1]==0x00)))
					break;
			}
			g_wsz1001F5F8[i] = 0;
			FormatStrW_100052F0(pArrayStr->wszStr_84, 32, L"%s", g_wsz1001F5F8);

		}//loc_10007130
		else if(ret ==0xFFFFF9FF)
		{
			free(g_dword_1001F6B8);
			g_dword_1001F6B8 = malloc(32);
			memset(g_dword_1001F6B8, 0, 32);
			if(!EApiBoardGetStringA(4, g_dword_1001F6B8, (LPDWORD)&var_4))
			{
				memset(g_dword_1001F678, 0, 64);
				memset(g_wsz1001F5F8, 0, 64);
				FormatStrA_100086A0(g_dword_1001F678, 64, "%s", g_dword_1001F6B8);
				int nLen = strlen((const char*)g_dword_1001F678);
				int i = 0, j=0;
				for(i = 0, j = 0; i < nLen; i++, j++)
				{
					if(i >= 32) break;
					g_wsz1001F5F8[i] = g_dword_1001F678[i];
					if(g_dword_1001F678[i]==0x20 &&((g_dword_1001F678[i+1]==0x20) || (g_dword_1001F678[i+1]==0x00)))
						break;
				}
				g_wsz1001F5F8[i] = 0;
				FormatStrW_100052F0(pArrayStr->wszStr_84, 32, L"%s", g_wsz1001F5F8);
			}


		}
		else if(ret == 0xFFFFFCFF)
		{
			wcscpy_s((wchar_t *)pArrayStr->wszStr_84, 32, L"UNSUPPORTED");
		}
		else{
			FormatStrW_100052F0(pArrayStr->wszStr_84, 32, L"EC %u", 0);
		}

	}
	if(g_dword_1001F6B8)
		free(g_dword_1001F6B8);
	return 1;
}

DWORD 	CEapiAPIEX_IES::sub_10007EF0()
{
	LP_EApiBoardGetValue _EApiBoardGetValue = NULL;
	DWORD ret = 0;
	if ( m_hModEAPI_IES )
	{
		//_EApiBoardGetValue = (LP_EApiBoardGetValue)GetProcAddress(m_hModEAPI_IES, "_EApiBoardGetValue@8");
// 		if ( _EApiBoardGetValue )
// 		{
			if(EApiBoardGetValue(0, &ret)) return 0;
			return ret;
			//return v4 == 0 ? v9 : 0;
//		}
	}
	else
	{
		m_hModEAPI_IES = LoadLibraryW(L"EApi_MSC.dll");
		//*(DWORD *)(v1 + 20) = v6;
		_EApiBoardGetValue = (LPEApiBoardGetValue)GetProcAddress(m_hModEAPI_IES, "EApiBoardGetValue");
		if ( _EApiBoardGetValue )
		{
			if(_EApiBoardGetValue(0, &ret)) return 0;
			return ret;
		}
	}
	return 0;
}

BOOL  	CEapiAPIEX_IES::sub_10006330(BYTE bFlag, DWORD dwVal)
{
	if(!m_hModEAPI_IES){
		m_hModEAPI_IES = LoadLibraryW(L"EAPI.dll");
	}
// 	EApiI2CReadTransfer = (LPEApiI2CReadTransfer)GetProcAddress(m_hModEAPI_IES, "EApiI2CReadTransfer");
// 	if(EApiI2CReadTransfer)
// 		return (EApiI2CReadTransfer(0, (bFlag|1), 0x40000000, nCmd, 1, 1)==0);
	return (EApiI2CReadTransfer(0, (bFlag|1), 0x40000000, (void*)dwVal, 1, 1)==0);
	return FALSE;
}

BOOL 	CEapiAPIEX_IES::sub_10006390(BYTE bFlag, BYTE bRet)
{
	if(bFlag != 54) return 0;
	if(!m_hModEAPI_IES){
		m_hModEAPI_IES = LoadLibraryW(L"EAPI.dll");
	}
// 	EApiI2CWriteTransfer = (LPEApiI2CWriteTransfer)GetProcAddress(m_hModEAPI_IES, "EApiI2CWriteTransfer");
// 	if(EApiI2CWriteTransfer)
// 		return (EApiI2CWriteTransfer(0, 54, 0x40000000, (PCHAR)&bRet, 1)==0);
	return (EApiI2CWriteTransfer(0, 54, 0x40000000, (PCHAR)&bRet, 1)==0);
	return FALSE;
}

BOOL 	CEapiAPIEX_IES::sub_10006490(BYTE bFlag, int nCmd, PBYTE pbRet)
{
	if(bFlag != 54) return 0;
	if(!m_hModEAPI_IES){
		m_hModEAPI_IES = LoadLibraryW(L"EAPI.dll");
	}

// 	EApiI2CWriteTransfer = (LPEApiI2CWriteTransfer)GetProcAddress(m_hModEAPI_IES, "EApiI2CWriteTransfer");
// 	if(EApiI2CWriteTransfer)
// 		return (EApiI2CWriteTransfer(0, 54, 0x40000000, (PCHAR)pbRet, nCmd)==0);
	return (EApiI2CWriteTransfer(0, 54, 0x40000000, (PCHAR)pbRet, nCmd)==0);
	return FALSE;
}

BOOL 	CEapiAPIEX_IES::sub_10006410(BYTE bFlag, DWORD dwCmd1, DWORD nCmd2)
{
	if(dwCmd1 >= 126) return FALSE;

	if(!m_hModEAPI_IES){
		m_hModEAPI_IES = LoadLibraryW(L"EAPI.dll");
	}
// 	EApiI2CReadTransfer = (LPEApiI2CReadTransfer)GetProcAddress(m_hModEAPI_IES, "EApiI2CReadTransfer");
// 	if(EApiI2CReadTransfer)
// 		return (EApiI2CReadTransfer(0, (bFlag|1), 0x40000000, nCmd2, dwCmd1, dwCmd1)==0);
	return (EApiI2CReadTransfer(0, (bFlag|1), 0x40000000, (void*)nCmd2, dwCmd1, dwCmd1)==0);
	return FALSE;
}

BOOL 	CEapiAPIEX_IES::sub_100062C0(char bFlag, char bRet)
{
	if(bRet == 2) return 0;
	if(!m_hModEAPI_IES){
		m_hModEAPI_IES = LoadLibraryW(L"EAPI.dll");
	}

// 	EApiI2CWriteTransfer = (LPEApiI2CWriteTransfer)GetProcAddress(m_hModEAPI_IES, "EApiI2CWriteTransfer");
// 	if(EApiI2CWriteTransfer)
// 		return (EApiI2CWriteTransfer(0, bFlag&0xFE, 0x40000000, (PCHAR)&bRet, 1)==0);
	return (EApiI2CWriteTransfer(0, bFlag&0xFE, 0x40000000, (PCHAR)&bRet, 1)==0);
	return FALSE;
}

BOOL 	CEapiAPIEX_IES::sub_10006500(int nCode, StructSize13 stCmd)
{
	
	if(!m_hModEAPI_IES){
		m_hModEAPI_IES = LoadLibraryW(L"EAPI.dll");
	}
	BYTE bCode = stCmd.bCode;
// 	EApiI2CWriteTransfer = (LPEApiI2CWriteTransfer)GetProcAddress(m_hModEAPI_IES, "EApiI2CWriteTransfer");
// 	if(EApiI2CWriteTransfer)
// 		return (EApiI2CWriteTransfer(0, 32, 0x40000000, (PCHAR)&bCode, nCode)==0);
	return (EApiI2CWriteTransfer(0, 32, 0x40000000, (PCHAR)&bCode, nCode)==0);
	return FALSE;
}
BOOL 	CEapiAPIEX_IES::sub_10006700(DWORD64* pdwRet)
{
	DWORD dwParam1 = 0, dwParam2 = 0, dwParam3 = 0;
	if(m_hModEAPI_IES)
	{
		//EApiWDogGetCap = (LPEApiWDogGetCap)GetProcAddress(m_hModEAPI_IES, "EApiWDogGetCap");
		//if(EApiWDogGetCap){
			if(!EApiWDogGetCap(&dwParam1,&dwParam2,&dwParam3)){
				*((DWORD*)pdwRet +4) = dwParam1;
				*(DWORD*)pdwRet = dwParam2;
				return TRUE;
			}
		//	return FALSE;
		//}
		return FALSE;
	}
	m_hModEAPI_IES = LoadLibraryW(L"EAPI.dll");
	//EApiWDogGetCap = (LPEApiWDogGetCap)GetProcAddress(m_hModEAPI_IES, "EApiWDogGetCap");
	//if(!EApiWDogGetCap) return FALSE;
	if(EApiWDogGetCap(&dwParam1,&dwParam2,&dwParam3)) return FALSE;

	*((DWORD*)pdwRet +4) = dwParam1;
	*(DWORD*)pdwRet = dwParam2;
	return TRUE;
}

int 	CEapiAPIEX_IES::sub_10003550()
{
	return  0xFFFFFCFF;
}

BOOL 	CEapiAPIEX_IES::sub_10006810()
{
	if(!m_hModEAPI_IES)
		m_hModEAPI_IES = LoadLibraryW(L"EAPI.dll");
	//EApiWDogTrigger = (LPEApiWDogTrigger)GetProcAddress(m_hModEAPI_IES, "EApiWDogTrigger");
	//if(EApiWDogTrigger)
		return (EApiWDogTrigger()==0);
	return FALSE;
}

BOOL	CEapiAPIEX_IES::sub_10006630(BYTE* pbRet)
{
	BYTE ret = 0;
	if(m_hModEAPI_IES){
		//EApiVgaGetBacklightBrightness = (LPEApiVgaGetBacklightBrightness)GetProcAddress(m_hModEAPI_IES, "EApiVgaGetBacklightBrightness");
		//if(EApiVgaGetBacklightBrightness){
			if(EApiVgaGetBacklightBrightness(0, (PDWORD)&ret))
				return FALSE;
			*(BYTE*)pbRet = ret;
			return TRUE;
		//}
	}
	else{
		m_hModEAPI_IES = LoadLibraryW(L"EAPI.dll");
		//EApiVgaGetBacklightBrightness = (LPEApiVgaGetBacklightBrightness)GetProcAddress(m_hModEAPI_IES, "EApiVgaGetBacklightBrightness");
		if(EApiVgaGetBacklightBrightness(0, (PDWORD)&ret))
			return FALSE;
		*(BYTE*)pbRet = ret;
		return TRUE;
	}
	return FALSE;
}

BOOL	CEapiAPIEX_IES::sub_100066B0(BYTE nCode)
{
	if(!m_hModEAPI_IES)
		m_hModEAPI_IES = LoadLibraryW(L"EAPI.dll");
	//EApiVgaSetBacklightBrightness = (LPEApiVgaSetBacklightBrightness)GetProcAddress(m_hModEAPI_IES, "EApiVgaSetBacklightBrightness");
	//if(EApiVgaSetBacklightBrightness)
		return (EApiVgaSetBacklightBrightness(0, nCode) == 0);
	return FALSE;
}
int		CEapiAPIEX_IES::sub_10006610(BYTE* bCode)
{
	*bCode = 0;
	return 0xFFFFFCFF;
}

int		CEapiAPIEX_IES::sub_10006620()
{
	return 0xFFFFFCFF;
}

BOOL 	CEapiAPIEX_IES::sub_10006850(DWORD* pdwCode)
{
	DWORD nRet = 0;
	if(m_hModEAPI_IES)
	{
		//EApiBoardGetValue = (LPEApiBoardGetValue)GetProcAddress(m_hModEAPI_IES, "EApiBoardGetValue");
		//if(!EApiBoardGetValue) return TRUE;

		if(EApiBoardGetValue(0x2000, &nRet))
			*pdwCode = 0xFFFFFFFF;
		else{
			*pdwCode =(nRet - 2731)/10;
		}
	}
	else
	{
		m_hModEAPI_IES = LoadLibraryW(L"EAPI.dll");
		//EApiBoardGetValue = (LPEApiBoardGetValue)GetProcAddress(m_hModEAPI_IES, "EApiBoardGetValue");

		//if (!EApiBoardGetValue) return TRUE;

		if( EApiBoardGetValue(0x2000, &nRet)) *pdwCode = 0xFFFFFFFF;
		else{
			*pdwCode =(nRet - 2731)/10;
		}
	}
	if(EApiBoardGetValue(0x20001, &nRet)) *pdwCode = 0xFFFFFFFF;
	else
		*pdwCode = (nRet - 2731)/10;

	if(EApiBoardGetValue(0x20002, &nRet)) *pdwCode = 0xFFFFFFFF;
	else
		*pdwCode = (nRet - 2731)/10;
	return TRUE;

}

BOOL	CEapiAPIEX_IES::sub_10003660(double* arg_0, int* arg_4)
{
	BYTE by_c[5] = {0,};
	if (sub_100062C0(0x20, 0x08))
	{
		Sleep(100);

		if (sub_10006410(0x20, 0x05, (DWORD)by_c))
		{
			*arg_0 = by_c[0] * 13.5;
			DWORD v7 = (by_c[2] | (by_c[1] << 8)) << 8;
			*arg_4 = by_c[4] | ((by_c[3] | v7) << 8);
			return 1;
		}
	}
	return 0;
}

BOOL CEapiAPIEX_IES::sub_10004550(BYTE* arg_0)
{
	BYTE lpBy_v8[7] = {0,};
	if ( *(DWORD *)arg_0 != 0 )
	{
		if ( sub_100062C0(0x20, 0x04))
		{
			Sleep(0x64);
			if (sub_10006410(0x20, 0x07, (DWORD)lpBy_v8))
			{
				if (FormatStrW_100052F0((WCHAR*)(arg_0 + 0x4), 0x20, L"%02X.%02X", lpBy_v8[0], lpBy_v8[1])==1)
				{
					*(BYTE *)(arg_0 + 69) = lpBy_v8[3];
					*(WORD *)(arg_0 + 70) = lpBy_v8[2];
					*(BYTE *)(arg_0 + 72) = lpBy_v8[5];
					*(BYTE *)(arg_0 + 68) = lpBy_v8[4];
					*(BYTE *)(arg_0 + 73) = lpBy_v8[6];
					return 1;
				}
			}
		}
	}
	return 0;
}

int	CEapiAPIEX_IES::sub_10007B00(BYTE* arg_0)
{
	DWORD nCode = 0;
	int nRet = 0;
	HMODULE hMode = NULL;
	if(!m_hModEAPI_IES) m_hModEAPI_IES = LoadLibraryW(L"EAPI.dll");
	//EApiBoardGetValue =  (LPEApiBoardGetValue)GetProcAddress(m_hModEAPI_IES, "EApiBoardGetValue");
	//if(EApiBoardGetValue){
		if(EApiBoardGetValue(1, &nCode)) nRet = 1;
		else{
			*(DWORD*)(arg_0 + 4) = nCode;
			FormatStrW_100052F0((WCHAR*)(arg_0 + 0x0C), 0x20, L"%d", nCode);
			nRet = 2;
		}
	//}

	HMODULE hMod = NULL;
	hMod = LoadLibraryW(L"inpout32.dll");
	LPIsInpOutDriverOpen IsInpOutDriverOpen = (LPIsInpOutDriverOpen)GetProcAddress(hMod, "IsInpOutDriverOpen");
	if(IsInpOutDriverOpen){
		Out32 = (LPOut32)GetProcAddress(hMod, "Out32");
		if(Inp32) (LPInp32)GetProcAddress(hMod, "Inp32");
	}
	if(IsInpOutDriverOpen())
	{
		Out32(0xA80, 80);
		int temp1 = Inp32(0xA81);
		Out32(0xA80, 81);
		int temp2 = Inp32(0xA81);
		Out32(0xA80, 82);
		int temp3 = Inp32(0xA81);
		Out32(0xA80, 83);
		int temp4 = Inp32(0xA81);
		Out32(0xA80, 84);
		Inp32(0xA81);
		Out32(0xA80, 85);
		Inp32(0xA81);
		temp1 = temp1 + ((temp2 + ((temp3 + (temp4 << 8)) << 8)) << 8);
		*(DWORD*)(arg_0+8) = temp1;
		nCode = temp1;
		FormatStrW_100052F0((WCHAR*)(arg_0 + 0x4C), 0x20, L"%d", temp1);
	}
	if(m_hModEAPI_IES)
		FreeLibrary(m_hModEAPI_IES);
	return nRet;

}

BOOL CEapiAPIEX_IES::GetVCPFeatureAndVCPFeatureReply_10006970(DWORD* dwCurVal, int nNum)
{
	BOOL bRet = FALSE;

	DWORD pdwNumberOfPhysicalMonitors; 
	DWORD pdwCurrentValue; 
	DWORD pdwMaximumValue; 

	pdwCurrentValue = 0;
	pdwMaximumValue = 0;
	pdwNumberOfPhysicalMonitors = 0;
	int SystemMetrics = GetSystemMetrics(SM_CMONITORS);

	if (nNum > 0 && nNum <= SystemMetrics )
	{
		m_pInfoLast = m_pInfoStart;
		m_pInfoLast = m_pInfoStart->next;
		if ( m_pInfoLast->nMonIdx <= SystemMetrics )
		{
			while (1)
			{
				if (nNum == m_pInfoLast->nMonIdx)
				{
					if (GetNumberOfPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, &pdwNumberOfPhysicalMonitors))
					{
						LPPHYSICAL_MONITOR phymonitor =  new PHYSICAL_MONITOR[pdwNumberOfPhysicalMonitors];
						if (phymonitor)
						{
							if (GetPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, pdwNumberOfPhysicalMonitors, phymonitor))
							{
								if (GetVCPFeatureAndVCPFeatureReply(phymonitor[0].hPhysicalMonitor, 0x12, NULL, &pdwCurrentValue,&pdwMaximumValue))
								{
									*dwCurVal = pdwCurrentValue;
									bRet = TRUE;
								}
								else
									GetLastError();

								DestroyPhysicalMonitors(pdwNumberOfPhysicalMonitors, phymonitor);
								delete[] phymonitor;
							}

						}
					}
					return bRet;

				}
				m_pInfoLast = m_pInfoLast->next;
				if (m_pInfoLast == 0 || m_pInfoLast->nMonIdx > SystemMetrics)
				{
					return 0;
				}
			}
		}
	}
	return 0;
}
BOOL CEapiAPIEX_IES::SetVCPFeature_10006A80(DWORD* pdwNewVal, int nNum)
{
	BOOL bRet = FALSE;

	DWORD pdwNumberOfPhysicalMonitors;
	DWORD dwCurrentValue; 
	DWORD dwMaximumValue; 

	dwCurrentValue = 0;
	dwMaximumValue = 0;
	pdwNumberOfPhysicalMonitors = 0;
	int SystemMetrics = GetSystemMetrics(SM_CMONITORS);

	if (nNum > 0 && nNum <= SystemMetrics )
	{
		m_pInfoLast = m_pInfoStart;
		m_pInfoLast = m_pInfoStart->next;
		if ( m_pInfoLast->nMonIdx <= SystemMetrics )
		{
			while (1)
			{
				if (nNum == m_pInfoLast->nMonIdx)
				{
					if (GetNumberOfPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, &pdwNumberOfPhysicalMonitors))
					{
						LPPHYSICAL_MONITOR phymonitor =  new PHYSICAL_MONITOR[pdwNumberOfPhysicalMonitors];
						if (phymonitor)
						{
							if (GetPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, pdwNumberOfPhysicalMonitors, phymonitor))
							{
								if (SetVCPFeature(phymonitor[0].hPhysicalMonitor, 0x12, *pdwNewVal))
								{
									bRet = TRUE;
								}
								else
									GetLastError();

								DestroyPhysicalMonitors(pdwNumberOfPhysicalMonitors, phymonitor);
								delete[] phymonitor;
							}

						}
					}
					return bRet;

				}
				m_pInfoLast = m_pInfoLast->next;
				if (m_pInfoLast == 0 || m_pInfoLast->nMonIdx > SystemMetrics)
				{
					return 0;
				}
			}
		}
	}
	return 0;
}

BOOL CEapiAPIEX_IES::GetVCPFeatureAndVCPFeatureReply_10006B70(DWORD* pdwCurVal, int nNum)
{
	BOOL bRet = FALSE;

	DWORD pdwNumberOfPhysicalMonitors; 
	DWORD pdwCurrentValue; 
	DWORD pdwMaximumValue; 

	pdwCurrentValue = 0;
	pdwMaximumValue = 0;
	pdwNumberOfPhysicalMonitors = 0;
	int SystemMetrics = GetSystemMetrics(SM_CMONITORS);

	if (nNum > 0 && nNum <= SystemMetrics )
	{
		m_pInfoLast = m_pInfoStart;
		m_pInfoLast = m_pInfoStart->next;
		if ( m_pInfoLast->nMonIdx <= SystemMetrics )
		{
			while (1)
			{
				if (nNum == m_pInfoLast->nMonIdx)
				{
					if (GetNumberOfPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, &pdwNumberOfPhysicalMonitors))
					{
						LPPHYSICAL_MONITOR phymonitor =  new PHYSICAL_MONITOR[pdwNumberOfPhysicalMonitors];
						if (phymonitor)
						{
							if (GetPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, pdwNumberOfPhysicalMonitors, phymonitor))
							{
								if (GetVCPFeatureAndVCPFeatureReply(phymonitor[0].hPhysicalMonitor, 0x10, NULL, &pdwCurrentValue,&pdwMaximumValue))
								{
									*pdwCurVal = pdwCurrentValue;
									bRet = TRUE;
								}
								else
									GetLastError();

								DestroyPhysicalMonitors(pdwNumberOfPhysicalMonitors, phymonitor);
								delete[] phymonitor;
							}

						}
					}
					return bRet;

				}
				m_pInfoLast = m_pInfoLast->next;
				if (m_pInfoLast == 0 || m_pInfoLast->nMonIdx > SystemMetrics)
				{
					return 0;
				}
			}
		}
	}
	return 0;
}
BOOL CEapiAPIEX_IES::SetVCPFeature_10005070(DWORD* pdwNewVal, int nNum)
{
	BOOL bRet = FALSE;
	DWORD pdwNumberOfPhysicalMonitors; 
	DWORD pdwCurrentValue; 
	DWORD pdwMaximumValue; 

	pdwCurrentValue = 0;
	pdwMaximumValue = 0;
	pdwNumberOfPhysicalMonitors = 0;
	int SystemMetrics = GetSystemMetrics(SM_CMONITORS);

	if (nNum > 0 && nNum <= SystemMetrics )
	{
		m_pInfoLast = m_pInfoStart;
		m_pInfoLast = m_pInfoStart->next;
		if ( m_pInfoLast->nMonIdx <= SystemMetrics )
		{
			while (1)
			{
				if (nNum == m_pInfoLast->nMonIdx)
				{
					if (GetNumberOfPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, &pdwNumberOfPhysicalMonitors))
					{
						LPPHYSICAL_MONITOR phymonitor =  new PHYSICAL_MONITOR[pdwNumberOfPhysicalMonitors];
						if (phymonitor)
						{
							if (GetPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, pdwNumberOfPhysicalMonitors, phymonitor))
							{
								if (SetVCPFeature(phymonitor[0].hPhysicalMonitor, 0x10, *pdwNewVal))
								{
									bRet = TRUE;
								}
								else
									GetLastError();

								DestroyPhysicalMonitors(pdwNumberOfPhysicalMonitors, phymonitor);
								delete[] phymonitor;
							}

						}
					}
					return bRet;

				}
				m_pInfoLast = m_pInfoLast->next;
				if (m_pInfoLast == 0 || m_pInfoLast->nMonIdx > SystemMetrics)
				{
					return 0;
				}
			}
		}
	}
	return 0;
}
BOOL CEapiAPIEX_IES::sub_10003720(BYTE byVal, BYTE* bySrc, BYTE byLen)
{
	BYTE byBuf[32]; 	
	memset(byBuf, 0, sizeof(byBuf));
	byBuf[0] = byVal;
	memcpy(byBuf, bySrc, byLen);
	if (sub_10006490(0x36, byLen + 1, byBuf) == 1) return TRUE;
	return FALSE;
}
BOOL CEapiAPIEX_IES::sub_10006C80(DWORD* pdwParam)
{
	HMODULE hMod; 
	BOOL bRet = 0; 
	DWORD dwVal = 0; 
	hMod = m_hModEAPI_IES;
	if ( !hMod )
	{
		hMod = LoadLibraryW(L"EApi.dll");
		m_hModEAPI_IES = hMod;
	}
// 	LPFnU_DP EApiBoardGetValue = (LPFnU_DP)GetProcAddress(hMod, "EApiBoardGetValue");
// 	if ( EApiBoardGetValue )
// 	{
		if ( EApiBoardGetValue(0x22000, &dwVal) ) bRet = 0;
		else{			
			bRet = 1;
			*pdwParam = 0x10000;
			pdwParam[1] = dwVal;
		}
//	}
	if ( m_hModEAPI_IES )
	{
// 		LPFnU_DP ProcAddress = (LPFnU_DP)GetProcAddress(m_hModEAPI_IES, "EApiBoardGetValue");
// 		if ( ProcAddress )
// 		{
			if ( EApiBoardGetValue(0x22000, &dwVal) ) return 0;
//		}
	}
	else
	{
		m_hModEAPI_IES = LoadLibraryW(L"EApi.dll");		
// 		EApiBoardGetValue = (LPFnU_DP)GetProcAddress(m_hModEAPI_IES, "EApiBoardGetValue");
// 		if ( EApiBoardGetValue )
// 		{
			if ( EApiBoardGetValue(0x22001, &dwVal) )	return 0;
//		}
	}
	pdwParam[1] = dwVal;
	*pdwParam = 0x20000;
	bRet = 1;
	return bRet;
}
DWORD CEapiAPIEX_IES::retn0_100051F0()
{
	return 0;
}
BOOL CEapiAPIEX_IES::SetVCPFeature_10005200(int nNum, BYTE bVCPCode, DWORD* pdwNewVal)
{
	BOOL bRet = FALSE;
	DWORD pdwNumberOfPhysicalMonitors;
	DWORD pdwCurrentValue; 
	DWORD pdwMaximumValue; 

	pdwCurrentValue = 0;
	pdwMaximumValue = 0;
	pdwNumberOfPhysicalMonitors = 0;
	int SystemMetrics = GetSystemMetrics(SM_CMONITORS);

	if (nNum > 0 && nNum <= SystemMetrics )
	{
		m_pInfoLast = m_pInfoStart;
		m_pInfoLast = m_pInfoStart->next;
		if ( m_pInfoLast->nMonIdx <= SystemMetrics )
		{
			while (1)
			{
				if (nNum == m_pInfoLast->nMonIdx)
				{
					if (GetNumberOfPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, &pdwNumberOfPhysicalMonitors))
					{
						LPPHYSICAL_MONITOR phymonitor =  new PHYSICAL_MONITOR[pdwNumberOfPhysicalMonitors];
						if (phymonitor)
						{
							if (GetPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, pdwNumberOfPhysicalMonitors, phymonitor))
							{
								if (SetVCPFeature(phymonitor[0].hPhysicalMonitor, bVCPCode, *pdwNewVal))
								{
									bRet = TRUE;
								}
								else
									GetLastError();
								DestroyPhysicalMonitors(pdwNumberOfPhysicalMonitors, phymonitor);
								delete[] phymonitor;
							}

						}
					}
					return bRet;
				}
				m_pInfoLast = m_pInfoLast->next;
				if (m_pInfoLast == 0 || m_pInfoLast->nMonIdx > SystemMetrics)
				{
					return 0;
				}
			}
		}
	}
	return 0;
}
BOOL CEapiAPIEX_IES::GetVCPFeatureAndVCPFeatureReply_10003850(int nArgNum, BYTE bVCPCode, DWORD* pdwCurrentVal, DWORD* dwMaxVal)
{
	BOOL bRet = FALSE;
	DWORD dwCurrentValue;
	DWORD dwMaximumValue;	
	DWORD dwNumOfPhyMonitors = 0; 
	int nSystemMetrics = GetSystemMetrics(SM_CMONITORS);

	if (nArgNum > 0 && nArgNum <= nSystemMetrics )
	{
		m_pInfoLast = m_pInfoStart;
		m_pInfoLast = m_pInfoStart->next;
		if ( m_pInfoLast->nMonIdx <= nSystemMetrics )
		{
			while (1)
			{
				if (nArgNum == m_pInfoLast->nMonIdx)
				{
					if (GetNumberOfPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, &dwNumOfPhyMonitors))
					{
						LPPHYSICAL_MONITOR phymonitor =  new PHYSICAL_MONITOR[dwNumOfPhyMonitors];//(LPPHYSICAL_MONITOR)malloc(dwNumOfPhyMonitors*sizeof(PHYSICAL_MONITOR));
						if (phymonitor)
						{
							if (GetPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, dwNumOfPhyMonitors, phymonitor))
							{
								if (GetVCPFeatureAndVCPFeatureReply(phymonitor[0].hPhysicalMonitor, bVCPCode, NULL, &dwCurrentValue,&dwMaximumValue))
								{
									*pdwCurrentVal = dwCurrentValue;
									*dwMaxVal = dwMaximumValue;
									bRet = TRUE;
								}
								else
									GetLastError();

								DestroyPhysicalMonitors(dwNumOfPhyMonitors, phymonitor);
								delete[] phymonitor;
							}
						}
					}
					return bRet;
				}
				m_pInfoLast = m_pInfoLast->next;
				if (m_pInfoLast == 0 || m_pInfoLast->nMonIdx > nSystemMetrics)
				{
					return 0;
				}
			}
		}
	}
	return 0;
}

BOOL CEapiAPIEX_IES::SaveCurrentSettings_10006D60(int nNum)
{
	BOOL bRet = FALSE; 	
	PHYSICAL_MONITOR* pPhyMonitor; 
	DWORD dwNumPhyMonitors = 0; 
	int nSystemMetrics = GetSystemMetrics(SM_CMONITORS);
	if (!nNum) return FALSE;
	if ( nNum <= nSystemMetrics )
	{		
		m_pInfoLast = m_pInfoStart->next;
		if ( m_pInfoLast->nMonIdx <= nSystemMetrics )
		{
			while ( 1 )
			{				
				if ( nNum == m_pInfoLast->nMonIdx ) break;
				m_pInfoLast = m_pInfoLast->next;
				if ( !m_pInfoLast || m_pInfoLast->nMonIdx > nSystemMetrics) return FALSE;
			}
			if ( GetNumberOfPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, &dwNumPhyMonitors) )
			{
				pPhyMonitor = new PHYSICAL_MONITOR[dwNumPhyMonitors] ;
				if ( pPhyMonitor )
				{
					if ( GetPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, dwNumPhyMonitors,	pPhyMonitor) )
					{
						if ( SaveCurrentSettings(pPhyMonitor->hPhysicalMonitor) )
							bRet = TRUE;
						else
							GetLastError();
					}
					DestroyPhysicalMonitors(dwNumPhyMonitors, pPhyMonitor);
					delete[] pPhyMonitor;
				}
			}
		}
	}
	return bRet;
}


DWORD CEapiAPIEX_IES::sub_100061D0()
{	
	m_dw18 = 0;
	if (!m_hModEAPI_IES)
	{
#if 1
		hEAPI_IES = LoadLibraryW(L"EAPI.dll");
		m_hModEAPI_IES = hEAPI_IES;
#endif
	}
	if (!hEAPI_IES) return 0;
// 	g_lpfnEApiLibInitializeIES = (LPEApiLibInitialize)GetProcAddress(hEAPI_IES, "EApiLibInitialize");	
// 
// 	DWORD dwRet;
// 	if ((DWORD)g_lpfnEApiLibInitializeIES == 0)
// 	{
// 		sub_10006F60();
// 		return 0;	
// 	}
// 	dwRet = g_lpfnEApiLibInitializeIES();
	
	
	DWORD dwRet;
	if (EApiLibInitialize == 0)
	{
		sub_10006F60();
		return 0;	
	}
	dwRet = EApiLibInitialize();

	if (!dwRet) return 2000;
	sub_10006F60();
	return 0;	
}