#pragma once
#ifndef __GAME__H_
#define __GAME__H_

typedef unsigned short uint16_t;
typedef unsigned int   uint32_t;

struct GFORCE_VERSION
{
	int version;
	unsigned int chksum;
};

#endif
