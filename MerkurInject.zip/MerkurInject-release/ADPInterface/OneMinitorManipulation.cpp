#include "stdafx.h"
#include "Utils.h"
#include "SharedMutex.h"
#include "OneMinitorManipulation.h"
#include <setupapi.h>
#include <devguid.h>
#include <tlhelp32.h>

#pragma comment(lib, "setupapi.lib")

OneMonitorManipulation& OneMonitorManipulation::GetInstance()
{
	static OneMonitorManipulation instance;
	return instance;
}

void OneMonitorManipulation::CheckForVirtualMonitor()
{
	m_bHasVirtualMonitor = false;

	// Get display adapter device class
	GUID displayGUID = GUID_DEVCLASS_DISPLAY;
	HDEVINFO hDevInfo = SetupDiGetClassDevs(&displayGUID, NULL, NULL, DIGCF_PRESENT);
	
	if (hDevInfo == INVALID_HANDLE_VALUE)
	{
		DebugPrintf("CheckForVirtualMonitor: SetupDiGetClassDevs failed, error: %lu\n", GetLastError());
		return;
	}

	SP_DEVINFO_DATA deviceInfoData;
	deviceInfoData.cbSize = sizeof(SP_DEVINFO_DATA);

	// Enumerate through all display adapters
	for (DWORD i = 0; SetupDiEnumDeviceInfo(hDevInfo, i, &deviceInfoData); i++)
	{
		// Get the driver name
		DWORD dataType;
		WCHAR driverName[256] = { 0 };
		DWORD requiredSize = 0;

		// Get the driver name property
		if (SetupDiGetDeviceRegistryProperty(
			hDevInfo,
			&deviceInfoData,
			SPDRP_DRIVER,
			&dataType,
			(PBYTE)driverName,
			sizeof(driverName),
			&requiredSize))
		{
			if (driverName[0] != 0)
			{
				// Check for common virtual monitor driver names
				_wcslwr_s(driverName, _countof(driverName));
				
				if (wcsstr(driverName, L"rdpdd") != NULL ||           // Remote Desktop Display Driver
					wcsstr(driverName, L"indirect") != NULL ||        // Indirect Display Driver
					wcsstr(driverName, L"virtual") != NULL ||         // Virtual Display Driver
					wcsstr(driverName, L"iddcx") != NULL ||           // Indirect Display Driver Class Extension
					wcsstr(driverName, L"microsoft remote") != NULL)  // Microsoft Remote Display Adapter
				{
					DebugPrintfW(L"CheckForVirtualMonitor: Found virtual monitor driver: %s\n", driverName);
					m_bHasVirtualMonitor = true;
					break;
				}
			}
		}

		// Also check the device description
		WCHAR deviceDesc[256] = { 0 };
		if (SetupDiGetDeviceRegistryProperty(
			hDevInfo,
			&deviceInfoData,
			SPDRP_DEVICEDESC,
			&dataType,
			(PBYTE)deviceDesc,
			sizeof(deviceDesc),
			&requiredSize))
		{
			_wcslwr_s(deviceDesc, _countof(deviceDesc));
			
			if (wcsstr(deviceDesc, L"virtual") != NULL ||
				wcsstr(deviceDesc, L"remote") != NULL ||
				wcsstr(deviceDesc, L"indirect") != NULL)
			{
				DebugPrintfW(L"CheckForVirtualMonitor: Found virtual monitor device: %s\n", deviceDesc);
				m_bHasVirtualMonitor = true;
				break;
			}
		}
	}

	SetupDiDestroyDeviceInfoList(hDevInfo);

	if (!m_bHasVirtualMonitor)
	{
		DebugPrintf("CheckForVirtualMonitor: No virtual monitor found\n");
	}
}

void OneMonitorManipulation::InitOneMonitorActivation()
{
	// Check if display monitor's driver name and see if there is virtual monitor
	CheckForVirtualMonitor();

	// If virtual monitor exists then Init Shared Memory
	if (m_bHasVirtualMonitor)
	{
		MonitorInitSharedMemory();

		//run ScreenMirror.exe
		WCHAR szExePath[MAX_PATH] = { 0 };
		WCHAR szScreenMirrorPath[MAX_PATH] = { 0 };
		
		// Get current executable path (game.exe)
		if (GetModuleFileNameW(NULL, szExePath, MAX_PATH) == 0)
		{
			DebugPrintf("InitOneMonitorActivation: Failed to get executable path, error: %lu\n", GetLastError());
		}
		else
		{
			// Extract directory path
			WCHAR* pLastSlash = wcsrchr(szExePath, L'\\');
			if (pLastSlash != NULL)
			{
				// Null-terminate at the last backslash to get directory
				*pLastSlash = L'\0';
				
				// Build ScreenMirror.exe path: <game_dir>\general\DLL\ScreenMirror.exe
				swprintf_s(szScreenMirrorPath, MAX_PATH, L"%s\\general\\DLL\\ScreenMirror.exe", szExePath);
				
				// Check if file exists
				if (GetFileAttributesW(szScreenMirrorPath) == INVALID_FILE_ATTRIBUTES)
				{
					DebugPrintfW(L"InitOneMonitorActivation: ScreenMirror.exe not found at: %s\n", szScreenMirrorPath);
				}
				else
				{
					// Close all existing ScreenMirror.exe processes
					HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
					if (hSnapshot != INVALID_HANDLE_VALUE)
					{
						PROCESSENTRY32W pe32;
						pe32.dwSize = sizeof(PROCESSENTRY32W);
						
						if (Process32FirstW(hSnapshot, &pe32))
						{
							do
							{
								// Check if process name matches ScreenMirror.exe
								if (_wcsicmp(pe32.szExeFile, L"ScreenMirror.exe") == 0)
								{
									// Open the process
									HANDLE hProcess = OpenProcess(PROCESS_TERMINATE, FALSE, pe32.th32ProcessID);
									if (hProcess != NULL)
									{
										DebugPrintfW(L"InitOneMonitorActivation: Terminating existing ScreenMirror.exe process (PID: %lu)\n", pe32.th32ProcessID);
										TerminateProcess(hProcess, 0);
										CloseHandle(hProcess);
									}
								}
							} while (Process32NextW(hSnapshot, &pe32));
						}
						
						CloseHandle(hSnapshot);
						
						// Wait a bit for processes to terminate
						Sleep(500);
					}
					
					// Run ScreenMirror.exe
					STARTUPINFOW si = { 0 };
					PROCESS_INFORMATION pi = { 0 };
					si.cb = sizeof(si);
					
					if (CreateProcessW(
						szScreenMirrorPath,  // Application name
						NULL,                // Command line (use application name)
						NULL,                // Process security attributes
						NULL,                // Thread security attributes
						FALSE,               // Inherit handles
						0,                   // Creation flags
						NULL,                // Environment
						NULL,                // Current directory
						&si,                 // Startup info
						&pi))                // Process information
					{
						DebugPrintfW(L"InitOneMonitorActivation: Successfully launched ScreenMirror.exe\n");
						// Close handles to avoid handle leaks
						CloseHandle(pi.hProcess);
						CloseHandle(pi.hThread);
					}
					else
					{
						DebugPrintfW(L"InitOneMonitorActivation: Failed to launch ScreenMirror.exe, error: %lu\n", GetLastError());
					}
				}
			}
			else
			{
				DebugPrintf("InitOneMonitorActivation: Invalid executable path format\n");
			}
		}
	}
	else
	{
		DebugPrintf("InitOneMonitorActivation: Virtual monitor not found, skipping shared memory initialization\n");
	}
}

void OneMonitorManipulation::ShowMirrorWindow()
{
	if (m_bHasVirtualMonitor)	{
		SendMessageToMirror("SHOW2ND");
		m_bIsMirrorWindowVisible = TRUE;
	}
	else
	{
		DebugPrintf("ShowMirrorWindow: Virtual monitor not found, skipping\n");
	}
}

void OneMonitorManipulation::HideMirrorWindow()
{
	if(m_bHasVirtualMonitor)	{
		SendMessageToMirror("HIDE2ND");
		m_bIsMirrorWindowVisible = FALSE;
	}
	else
	{
		DebugPrintf("HideMirrorWindow: Virtual monitor not found, skipping\n");
	}
}

void OneMonitorManipulation::ToggleMirrorWindow()
{
	if(m_bHasVirtualMonitor)	{
		if(m_bIsMirrorWindowVisible){
			HideMirrorWindow();
			m_bIsMirrorWindowVisible = FALSE;
		}
		else
		{
			ShowMirrorWindow();
			m_bIsMirrorWindowVisible = TRUE;
		}
	}
	else
	{
		DebugPrintf("ToggleMirrorWindow: Virtual monitor not found, skipping\n");
	}
}

void OneMonitorManipulation::AutoSwitchMirrorWindow(int coin, bool upgraded)
{
	if(m_bHasVirtualMonitor)	{
		if(upgraded == false)	{
			if((coin >= 0 && coin <= 400) )	{
				HideMirrorWindow();
			}
			else {
				ShowMirrorWindow();
			}
		}
		else {
			if((coin >= 10000 && coin <= 18000) )	{
				HideMirrorWindow();
			}
			else {
				ShowMirrorWindow();
			}
		}
	}
}