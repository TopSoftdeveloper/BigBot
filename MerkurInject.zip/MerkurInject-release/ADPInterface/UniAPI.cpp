#include "StdAfx.h"
#include "UniAPI.h"

CUniAPI::CUniAPI(void)
{
}

CUniAPI::~CUniAPI(void)
{
}
