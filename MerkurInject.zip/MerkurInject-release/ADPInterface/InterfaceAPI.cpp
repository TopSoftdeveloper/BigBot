#include "StdAfx.h"
#include "InterfaceAPI.h"
#include "CongaAPI.h"
#include "KontronAPI.h"
#include "EapiAPI.h"
#include "UniAPI.h"

CInterfaceAPI::CInterfaceAPI(void) // sub_10009660
{
	m_dw0C= 0;
	m_dw10 = 0;
	m_hClassInst14 = 0;
}

CInterfaceAPI::~CInterfaceAPI(void)
{
}

HANDLE CInterfaceAPI::ApiInit_100096B0()
{
	CongaAPI *pCongaAPI = new CongaAPI;
	if (pCongaAPI)
	{
		if (pCongaAPI->CgosInit_10001100())
		{
			CongaAPI *pCongaAPI2 = new CongaAPI;
			if (pCongaAPI2)
			{
				m_hClassInst14 = pCongaAPI2;
				pCongaAPI2->m_dw04 = pCongaAPI->m_dw0C;
				pCongaAPI2->m_dw08 = pCongaAPI->m_dw10;
				delete pCongaAPI;
				return pCongaAPI2;
			}
			return 0;
		}
	}
	else
	{
		//delete pCongaAPI;
		CKontronAPI* pKontron = new CKontronAPI;
		if (pKontron)
		{
			if (pKontron->JidaInit_1000AB30())
			{
				CKontronAPI* pKontron2 = new CKontronAPI;
				if (pKontron2)
				{
					m_hClassInst14 = pKontron2;
					pKontron2->m_dw04 = pKontron->m_dw10;
					pKontron2->m_dw08 = pKontron->m_dw0C;
					delete pKontron;
					return pKontron2;
				}
				return 0;
			}
		}	
		else
		{
			CEapiAPI* pEapi = new CEapiAPI;
			if (!pEapi) return 0;
			if(pEapi->EapiInit_100026A0())
			{
				CEapiAPI* pEapi2 = new CEapiAPI;
				if (!pEapi2) return 0;
				m_hClassInst14 = pEapi2;
				pEapi2->m_dw04 = 0;
				pEapi2->m_dw08 = 0;
				delete pEapi;
				return pEapi2;
			}
		}

	}	
	return 0;
}
HANDLE CInterfaceAPI::SameConstruct_10009680(BOOL bFlag)
{
	CUniAPI* pCUniApi = new CUniAPI;

	if (!bFlag)
	{
		delete pCUniApi;

	}
	return pCUniApi;
}