#include "StdAfx.h"
#include "EapiAPIEX_MSC.h"
#include "stdlib.h"
#include "GlobalVar.h"
#include "PhysicalMonitorEnumerationAPI.h"
#include "LowLevelMonitorConfigurationAPI.h"
#pragma comment (lib, "dxva2.lib")

DWORD g_dword_1001F784;
BOOL CALLBACK fnEnumProc_10009440( HMONITOR hMonitor,  // handle to display monitor
						   HDC hDC,     // handle to monitor DC
						   LPRECT rect, // monitor intersection rectangle
						   LPARAM dwData )      // data????????
{
	myMonitorInfo myMonInfo; 
	myMonInfo.hdc = hDC;
	myMonInfo.hMonitor = hMonitor;
	myMonInfo.rect.left = rect->left;
	myMonInfo.rect.top = rect->top;
	myMonInfo.rect.right = rect->right;
	myMonInfo.rect.bottom = rect->bottom;
	myMonInfo.nInfo = 0;
	// myMonInfo.nInfoFlag = 0;
	addNewDisplayInfoToList(dwData, &myMonInfo);
	g_dword_1001F784 = dwData;	
	return 1;
}
CEapiAPIEX_MSC::CEapiAPIEX_MSC(void)//sub_100094D0
{
	infoStructure* pInfoStr;
	pInfoStr = new infoStructure;
	pInfoStr->nMonIdx = -1;
	pInfoStr->next = 0;
	myMonitorInfo* pMyMonInfo;
	pMyMonInfo = new myMonitorInfo;// malloc(544); 0x220
	pInfoStr->myMoninfo = pMyMonInfo;
	memset(pMyMonInfo, 0, sizeof(myMonitorInfo));
	m_pInfoStart = pInfoStr;
	m_pInfoLast = pInfoStr;
	int nNumMonitor = GetSystemMetrics(SM_CMONITORS);
	MONITORINFOEXW moninfo;
	moninfo.cbSize = 104;
	m_pInfoLast->nMonIdx = 0;	
	m_pInfoLast->myMoninfo->nInfo = 0;

	EnumDisplayMonitors(0,0,fnEnumProc_10009440, (LPARAM)m_pInfoLast);
	
	m_pInfoLast = m_pInfoLast->next;
	if(m_pInfoLast->nMonIdx <= nNumMonitor)
	{
		HMONITOR hMonitor;
		while(1)
		{
			hMonitor = m_pInfoLast->myMoninfo->hMonitor;
			GetMonitorInfoW(hMonitor, &moninfo);
			wcscpy_s(m_pInfoLast->myMoninfo->wszDevice, 0xFF, moninfo.szDevice);
			m_pInfoLast->myMoninfo->nInfoFlag = moninfo.dwFlags;
			m_pInfoLast = m_pInfoLast->next;
			if (!m_pInfoLast) break;	
			if (m_pInfoLast->nMonIdx > nNumMonitor) break;
		}
	}
	m_hMod14 = 0;
}

CEapiAPIEX_MSC::~CEapiAPIEX_MSC(void)
{
}
//typedef UINT (__thiscall* LPEApiLibInitialize)( VOID );
//typedef VOID (__thiscall* LPEApiLibUnInitialize)( VOID );
LPEApiLibInitialize g_lpfnEApiLibInitialMSC = 0;
LPEApiLibUnInitialize g_lpfnEApiLibUnInitializeMSC = 0;
void CEapiAPIEX_MSC::sub_100087A0()
{
	//DWORD dweax = m_pInfoStr0C;
	m_pInfoLast = m_pInfoStart;
	if (m_pInfoStart->nMonIdx == 0)
	{
		infoStructure* pNextInfo;
		infoStructure* pCurrInfo;
		infoStructure* pPrevInfo;
		pCurrInfo = m_pInfoStart;
		while(1)
		{		
			pNextInfo = pCurrInfo->next;
			pPrevInfo = pCurrInfo;
			if (pNextInfo)
			{
				while(1)
				{
					pPrevInfo = pCurrInfo;
					pCurrInfo = pNextInfo;
					pNextInfo = pCurrInfo->next;					
					if(pNextInfo == 0) break;
				}
			}
			if(pCurrInfo->nMonIdx == 0) break;
			delete pCurrInfo;
			pPrevInfo->next = 0;
			pCurrInfo = m_pInfoStart;
			pNextInfo = pCurrInfo;
			m_pInfoLast = pCurrInfo;
			if (pNextInfo->nMonIdx != 0) break; 
		}
	}
	delete m_pInfoStart;
	m_dw18 = -1;
	if (m_hMod14)
	{
		g_lpfnEApiLibUnInitializeMSC = (LPEApiLibUnInitialize)GetProcAddress(m_hMod14, "_EApiLibUnInitialize@0");
		if ((DWORD)g_lpfnEApiLibUnInitializeMSC)
		{
			g_lpfnEApiLibUnInitializeMSC();
		}
	}
	if (m_hMod14)
	{
		FreeLibrary(m_hMod14);
	}
	m_hMod14 = NULL;
}

BOOL CEapiAPIEX_MSC::sub_10008150(DWORD dwVal, DWORD dwArg_4, DWORD dwArg_8)
{
	HMODULE hMod; 
	if ( dwVal != 0x36 ) return FALSE;
	hMod = m_hMod14;
	if ( !hMod )
	{
		hMod = LoadLibraryW(L"EApi_MSC.dll");
		m_hMod14 = hMod;
	}
	LPFnU_DDDDD EApiI2CWriteTransfer = (LPFnU_DDDDD)GetProcAddress(hMod, "_EApiI2CWriteTransfer@20");
	return EApiI2CWriteTransfer	&& EApiI2CWriteTransfer(0, 54, 0x40000000, dwArg_8, dwArg_8) == 0;
}

BOOL CEapiAPIEX_MSC::GetVCPFeatureAndVCPFeatureReply_10006970(DWORD* dwCurVal, DWORD nNum)
{
	BOOL bRet = FALSE;

	DWORD pdwNumberOfPhysicalMonitors; 
	DWORD pdwCurrentValue; 
	DWORD pdwMaximumValue; 

	pdwCurrentValue = 0;
	pdwMaximumValue = 0;
	pdwNumberOfPhysicalMonitors = 0;
	int SystemMetrics = GetSystemMetrics(SM_CMONITORS);

	if (nNum > 0 && nNum <= SystemMetrics )
	{
		m_pInfoLast = m_pInfoStart;
		m_pInfoLast = m_pInfoStart->next;
		if ( m_pInfoLast->nMonIdx <= SystemMetrics )
		{
			while (1)
			{
				if (nNum == m_pInfoLast->nMonIdx)
				{
					if (GetNumberOfPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, &pdwNumberOfPhysicalMonitors))
					{
						LPPHYSICAL_MONITOR phymonitor =  new PHYSICAL_MONITOR[pdwNumberOfPhysicalMonitors];
						if (phymonitor)
						{
							if (GetPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, pdwNumberOfPhysicalMonitors, phymonitor))
							{
								if (GetVCPFeatureAndVCPFeatureReply(phymonitor[0].hPhysicalMonitor, 0x12, NULL, &pdwCurrentValue,&pdwMaximumValue))
								{
									*dwCurVal = pdwCurrentValue;
									bRet = TRUE;
								}
								else
									GetLastError();

								DestroyPhysicalMonitors(pdwNumberOfPhysicalMonitors, phymonitor);
								delete[] phymonitor;
							}

						}
					}
					return bRet;

				}
				m_pInfoLast = m_pInfoLast->next;
				if (m_pInfoLast == 0 || m_pInfoLast->nMonIdx > SystemMetrics)
				{
					return 0;
				}
			}
		}
	}
	return 0;
}
BOOL CEapiAPIEX_MSC::SetVCPFeature_10006A80(DWORD* pdwNewVal, DWORD nNum)
{
	BOOL bRet = FALSE;

	DWORD pdwNumberOfPhysicalMonitors;
	DWORD dwCurrentValue; 
	DWORD dwMaximumValue; 

	dwCurrentValue = 0;
	dwMaximumValue = 0;
	pdwNumberOfPhysicalMonitors = 0;
	int SystemMetrics = GetSystemMetrics(SM_CMONITORS);

	if (nNum > 0 && nNum <= SystemMetrics )
	{
		m_pInfoLast = m_pInfoStart;
		m_pInfoLast = m_pInfoStart->next;
		if ( m_pInfoLast->nMonIdx <= SystemMetrics )
		{
			while (1)
			{
				if (nNum == m_pInfoLast->nMonIdx)
				{
					if (GetNumberOfPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, &pdwNumberOfPhysicalMonitors))
					{
						LPPHYSICAL_MONITOR phymonitor =  new PHYSICAL_MONITOR[pdwNumberOfPhysicalMonitors];
						if (phymonitor)
						{
							if (GetPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, pdwNumberOfPhysicalMonitors, phymonitor))
							{
								if (SetVCPFeature(phymonitor[0].hPhysicalMonitor, 0x12, *pdwNewVal))
								{
									bRet = TRUE;
								}
								else
									GetLastError();

								DestroyPhysicalMonitors(pdwNumberOfPhysicalMonitors, phymonitor);
								delete[] phymonitor;
							}

						}
					}
					return bRet;

				}
				m_pInfoLast = m_pInfoLast->next;
				if (m_pInfoLast == 0 || m_pInfoLast->nMonIdx > SystemMetrics)
				{
					return 0;
				}
			}
		}
	}
	return 0;
}

BOOL CEapiAPIEX_MSC::GetVCPFeatureAndVCPFeatureReply_10006B70(DWORD* pdwCurVal, int nNum)
{
	BOOL bRet = FALSE;

	DWORD pdwNumberOfPhysicalMonitors; 
	DWORD pdwCurrentValue; 
	DWORD pdwMaximumValue; 

	pdwCurrentValue = 0;
	pdwMaximumValue = 0;
	pdwNumberOfPhysicalMonitors = 0;
	int SystemMetrics = GetSystemMetrics(SM_CMONITORS);

	if (nNum > 0 && nNum <= SystemMetrics )
	{
		m_pInfoLast = m_pInfoStart;
		m_pInfoLast = m_pInfoStart->next;
		if ( m_pInfoLast->nMonIdx <= SystemMetrics )
		{
			while (1)
			{
				if (nNum == m_pInfoLast->nMonIdx)
				{
					if (GetNumberOfPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, &pdwNumberOfPhysicalMonitors))
					{
						LPPHYSICAL_MONITOR phymonitor =  new PHYSICAL_MONITOR[pdwNumberOfPhysicalMonitors];
						if (phymonitor)
						{
							if (GetPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, pdwNumberOfPhysicalMonitors, phymonitor))
							{
								if (GetVCPFeatureAndVCPFeatureReply(phymonitor[0].hPhysicalMonitor, 0x10, NULL, &pdwCurrentValue,&pdwMaximumValue))
								{
									*pdwCurVal = pdwCurrentValue;
									bRet = TRUE;
								}
								else
									GetLastError();

								DestroyPhysicalMonitors(pdwNumberOfPhysicalMonitors, phymonitor);
								delete[] phymonitor;
							}

						}
					}
					return bRet;

				}
				m_pInfoLast = m_pInfoLast->next;
				if (m_pInfoLast == 0 || m_pInfoLast->nMonIdx > SystemMetrics)
				{
					return 0;
				}
			}
		}
	}
	return 0;
}
BOOL CEapiAPIEX_MSC::SetVCPFeature_10005070(DWORD* pdwNewVal, DWORD nNum)
{
	BOOL bRet = FALSE;
	DWORD pdwNumberOfPhysicalMonitors; 
	DWORD pdwCurrentValue; 
	DWORD pdwMaximumValue; 

	pdwCurrentValue = 0;
	pdwMaximumValue = 0;
	pdwNumberOfPhysicalMonitors = 0;
	int SystemMetrics = GetSystemMetrics(SM_CMONITORS);

	if (nNum > 0 && nNum <= SystemMetrics )
	{
		m_pInfoLast = m_pInfoStart;
		m_pInfoLast = m_pInfoStart->next;
		if ( m_pInfoLast->nMonIdx <= SystemMetrics )
		{
			while (1)
			{
				if (nNum == m_pInfoLast->nMonIdx)
				{
					if (GetNumberOfPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, &pdwNumberOfPhysicalMonitors))
					{
						LPPHYSICAL_MONITOR phymonitor =  new PHYSICAL_MONITOR[pdwNumberOfPhysicalMonitors];
						if (phymonitor)
						{
							if (GetPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, pdwNumberOfPhysicalMonitors, phymonitor))
							{
								if (SetVCPFeature(phymonitor[0].hPhysicalMonitor, 0x10, *pdwNewVal))
								{
									bRet = TRUE;
								}
								else
									GetLastError();

								DestroyPhysicalMonitors(pdwNumberOfPhysicalMonitors, phymonitor);
								delete[] phymonitor;
							}

						}
					}
					return bRet;

				}
				m_pInfoLast = m_pInfoLast->next;
				if (m_pInfoLast == 0 || m_pInfoLast->nMonIdx > SystemMetrics)
				{
					return 0;
				}
			}
		}
	}
	return 0;
}
BOOL CEapiAPIEX_MSC::sub_10003720(BYTE byVal, BYTE* bySrc, BYTE byLen)
{
	BYTE byBuf[32]; 	
	memset(byBuf, 0, sizeof(byBuf));
	byBuf[0] = byVal;
	memcpy(byBuf, bySrc, byLen);
	if (sub_10008150(0x36, byLen + 1, (DWORD)byBuf) == 1) return TRUE;
	else return FALSE;
}
BOOL CEapiAPIEX_MSC::SetVCPFeature_10005200(int nNum, BYTE bVCPCode, DWORD* pdwNewVal)
{
	BOOL bRet = FALSE;
	DWORD pdwNumberOfPhysicalMonitors;
	DWORD pdwCurrentValue; 
	DWORD pdwMaximumValue; 

	pdwCurrentValue = 0;
	pdwMaximumValue = 0;
	pdwNumberOfPhysicalMonitors = 0;
	int SystemMetrics = GetSystemMetrics(SM_CMONITORS);

	if (nNum > 0 && nNum <= SystemMetrics )
	{
		m_pInfoLast = m_pInfoStart;
		m_pInfoLast = m_pInfoStart->next;
		if ( m_pInfoLast->nMonIdx <= SystemMetrics )
		{
			while (1)
			{
				if (nNum == m_pInfoLast->nMonIdx)
				{
					if (GetNumberOfPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, &pdwNumberOfPhysicalMonitors))
					{
						LPPHYSICAL_MONITOR phymonitor =  new PHYSICAL_MONITOR[pdwNumberOfPhysicalMonitors];
						if (phymonitor)
						{
							if (GetPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, pdwNumberOfPhysicalMonitors, phymonitor))
							{
								if (SetVCPFeature(phymonitor[0].hPhysicalMonitor, bVCPCode, *pdwNewVal))
								{
									bRet = TRUE;
								}
								else
									GetLastError();
								DestroyPhysicalMonitors(pdwNumberOfPhysicalMonitors, phymonitor);
								delete[] phymonitor;
							}

						}
					}
					return bRet;
				}
				m_pInfoLast = m_pInfoLast->next;
				if (m_pInfoLast == 0 || m_pInfoLast->nMonIdx > SystemMetrics)
				{
					return 0;
				}
			}
		}
	}
	return 0;
}

BOOL CEapiAPIEX_MSC::GetVCPFeatureAndVCPFeatureReply_10003850(int nArgNum, BYTE bVCPCode, DWORD* pdwCurrentVal, DWORD* dwMaxVal)
{
	BOOL bRet = FALSE;
	DWORD dwCurrentValue;
	DWORD dwMaximumValue;	
	DWORD dwNumOfPhyMonitors = 0; 
	int nSystemMetrics = GetSystemMetrics(SM_CMONITORS);

	if (nArgNum > 0 && nArgNum <= nSystemMetrics )
	{
		m_pInfoLast = m_pInfoStart;
		m_pInfoLast = m_pInfoStart->next;
		if ( m_pInfoLast->nMonIdx <= nSystemMetrics )
		{
			while (1)
			{
				if (nArgNum == m_pInfoLast->nMonIdx)
				{
					if (GetNumberOfPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, &dwNumOfPhyMonitors))
					{
						LPPHYSICAL_MONITOR phymonitor =  new PHYSICAL_MONITOR[dwNumOfPhyMonitors];//(LPPHYSICAL_MONITOR)malloc(dwNumOfPhyMonitors*sizeof(PHYSICAL_MONITOR));
						if (phymonitor)
						{
							if (GetPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, dwNumOfPhyMonitors, phymonitor))
							{
								if (GetVCPFeatureAndVCPFeatureReply(phymonitor[0].hPhysicalMonitor, bVCPCode, NULL, &dwCurrentValue,&dwMaximumValue))
								{
									*pdwCurrentVal = dwCurrentValue;
									*dwMaxVal = dwMaximumValue;
									bRet = TRUE;
								}
								else
									GetLastError();

								DestroyPhysicalMonitors(dwNumOfPhyMonitors, phymonitor);
								delete[] phymonitor;
							}
						}
					}
					return bRet;
				}
				m_pInfoLast = m_pInfoLast->next;
				if (m_pInfoLast == 0 || m_pInfoLast->nMonIdx > nSystemMetrics)
				{
					return 0;
				}
			}
		}
	}
	return 0;
}

BOOL CEapiAPIEX_MSC::SaveCurrentSettings_10006D60(int nNum)
{
	BOOL bRet = FALSE; 	
	PHYSICAL_MONITOR* pPhyMonitor; 
	DWORD dwNumPhyMonitors = 0; 
	int nSystemMetrics = GetSystemMetrics(SM_CMONITORS);
	if (!nNum) return FALSE;
	if ( nNum <= nSystemMetrics )
	{		
		m_pInfoLast = m_pInfoStart->next;
		if ( m_pInfoLast->nMonIdx <= nSystemMetrics )
		{
			while ( 1 )
			{				
				if ( nNum == m_pInfoLast->nMonIdx ) break;
				m_pInfoLast = m_pInfoLast->next;
				if ( !m_pInfoLast || m_pInfoLast->nMonIdx > nSystemMetrics) return FALSE;
			}
			if ( GetNumberOfPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, &dwNumPhyMonitors) )
			{
				pPhyMonitor = new PHYSICAL_MONITOR[dwNumPhyMonitors] ;
				if ( pPhyMonitor )
				{
					if ( GetPhysicalMonitorsFromHMONITOR(m_pInfoLast->myMoninfo->hMonitor, dwNumPhyMonitors,	pPhyMonitor) )
					{
						if ( SaveCurrentSettings(pPhyMonitor->hPhysicalMonitor) )
							bRet = TRUE;
						else
							GetLastError();
					}
					DestroyPhysicalMonitors(dwNumPhyMonitors, pPhyMonitor);
					delete[] pPhyMonitor;
				}
			}
		}
	}
	return bRet;
}

DWORD CEapiAPIEX_MSC::sub_10007E60()
{
	HMODULE hMod; 
	m_dw18 = 0;
	if (!m_hMod14)
	{
		hMod = LoadLibraryW(L"EApi_MSC.dll");
		m_hMod14 = hMod;
	}
	if (!hMod) return 0;
	g_lpfnEApiLibInitialMSC = (LPEApiLibInitialize)GetProcAddress(hMod, "_EApiLibInitialize@0");
	DWORD dwRet;
	if ((DWORD)g_lpfnEApiLibInitialMSC == 0)
	{
		sub_100087A0();
		return 0;	
	}
	dwRet = (DWORD)g_lpfnEApiLibInitialMSC();
	if (!dwRet) return 2000;
	sub_100087A0();
	return 0;
}
