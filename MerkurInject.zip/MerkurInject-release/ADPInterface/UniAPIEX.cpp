#include "StdAfx.h"
#include "UniAPIEX.h"

CUniAPIEX::CUniAPIEX(void)
{
}

CUniAPIEX::~CUniAPIEX(void)
{
}
