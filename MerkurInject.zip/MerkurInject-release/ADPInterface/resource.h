//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ADPInterface.rc
//
#define IDD_DIALOG1                     101
#define IDD_SETTINGS                    101
#define IDD_BOOKKEEPING                 102
#define IDD_PAYOUT                      103
#define IDC_GAMES_UP                    2040
#define IDC_GAMES_DOWN                  2041

// Control IDs for Payout Dialog
#define IDC_PAYOUT_CREDITS_LABEL        2042
#define IDC_PAYOUT_CREDITS_VALUE        2043
#define IDC_PAYOUT_BUTTON               2044
#define IDC_PAYOUT_CLOSE_BUTTON         2045
#define IDC_PAYOUT_DATE_LABEL           2046
#define IDC_PAYOUT_DATE                 2047

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         2048
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
