#pragma once
#include <Windows.h>

typedef struct {
	INT addedCredit;
	HANDLE mutex;
} SharedMemoryData;

void initSharedMemory();

//void releaseSharedMemory();

void writeCreditData(int credit);

void openSharedMemory();


/* One Monitor Manipulation logic*/
#define MAX_MESSAGE_LENGTH 32

typedef struct {
	char message[MAX_MESSAGE_LENGTH];  // Message buffer for "SHOW2ND" or "HIDE2ND"
	// Note: Mutex handles cannot be shared directly, use named mutex instead
} MonitorSharedMemoryData;

BOOL MonitorInitSharedMemory();
void MonitorReleaseSharedMemory();
BOOL SendMessageToMirror(const char* message);


