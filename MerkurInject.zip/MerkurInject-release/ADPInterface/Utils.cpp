#include "stdafx.h"
#include "Utils.h"
#include "CryptoCard/GrafficObjList.h"
#include "CryptoCard/StateMachine.h"
#include "CryptoCard/Cryptocard.h"
#include "CryptoCard/KomProtocol.h"
#include "OneMinitorManipulation.h"

void SetCurrentThreadPriorityNormal() {
	SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_NORMAL);
}

void SetCurrentThreadPriorityHigh() {
	SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_ABOVE_NORMAL);
}

namespace {

#if ENABLE_LOGS == 1
static void LogPowerSettingFailure(const char* step, DWORD err)
{
	if (err != ERROR_SUCCESS)
		DebugPrintfT(LogTag::General, "SetWindowsPowerSaveMode: %s failed (%lu)", step, err);
}
#else
static void LogPowerSettingFailure(const char*, DWORD) {}
#endif

/** Runs %SystemRoot%\System32\powercfg.exe with no visible console (CREATE_NO_WINDOW). */
static DWORD RunPowerCfgHidden(const wchar_t* argumentsAfterExe)
{
	wchar_t systemDir[MAX_PATH];
	if (GetSystemDirectoryW(systemDir, MAX_PATH) == 0)
		return GetLastError();

	wchar_t exePath[MAX_PATH];
	swprintf_s(exePath, L"%s\\powercfg.exe", systemDir);

	wchar_t cmdLine[1024];
	swprintf_s(cmdLine, L"\"%s\" %s", exePath, argumentsAfterExe);

	wchar_t cmdLineMutable[1024];
	wcscpy_s(cmdLineMutable, cmdLine);

	STARTUPINFOW si = {};
	si.cb = sizeof(si);
	si.dwFlags = STARTF_USESHOWWINDOW;
	si.wShowWindow = SW_HIDE;

	PROCESS_INFORMATION pi = {};
	if (!CreateProcessW(
		exePath,
		cmdLineMutable,
		nullptr,
		nullptr,
		FALSE,
		CREATE_NO_WINDOW,
		nullptr,
		nullptr,
		&si,
		&pi))
	{
		return GetLastError();
	}

	WaitForSingleObject(pi.hProcess, INFINITE);
	DWORD exitCode = 0;
	GetExitCodeProcess(pi.hProcess, &exitCode);
	CloseHandle(pi.hProcess);
	CloseHandle(pi.hThread);

	return exitCode == 0 ? ERROR_SUCCESS : exitCode;
}

static void PowerCfgStep(const char* step, const wchar_t* argumentsAfterExe)
{
	LogPowerSettingFailure(step, RunPowerCfgHidden(argumentsAfterExe));
}

} // namespace

void SetWindowsPowerSaveMode()
{
	// Built-in Power saver scheme GUID; /change applies to the active scheme — set it first.
	PowerCfgStep("powercfg /setactive", L"/setactive a1841308-3541-4fab-bc81-f71556f20b4a");
	// 0 minutes = never (display, disk, standby, hibernate); AC and DC.
	PowerCfgStep("powercfg /change monitor-timeout-ac", L"/change monitor-timeout-ac 0");
	PowerCfgStep("powercfg /change monitor-timeout-dc", L"/change monitor-timeout-dc 0");
	PowerCfgStep("powercfg /change disk-timeout-ac", L"/change disk-timeout-ac 0");
	PowerCfgStep("powercfg /change disk-timeout-dc", L"/change disk-timeout-dc 0");
	PowerCfgStep("powercfg /change standby-timeout-ac", L"/change standby-timeout-ac 0");
	PowerCfgStep("powercfg /change standby-timeout-dc", L"/change standby-timeout-dc 0");
	PowerCfgStep("powercfg /change hibernate-timeout-ac", L"/change hibernate-timeout-ac 0");
	PowerCfgStep("powercfg /change hibernate-timeout-dc", L"/change hibernate-timeout-dc 0");
}

void LoadGrafficObjList() {
	g_GrafficObjList.Load();
}

void KeepGameWindowTopmostTick()
{
#ifdef TOPMOSTWINDOW_ACTIVE
	if (OneMonitorManipulation::GetInstance().IsMirrorWindowVisible()) {
		DebugPrintfW(L"[TOPWINDOW] KeepGameWindowTopmostTick skip.\n");
		return;
	}

	// Throttle to avoid hammering Win32 APIs in a tight loop.
	static UINT64 s_lastTickMs = 0;
	const UINT64 now = current_time_ms();
	if (now - s_lastTickMs < 250)
		return;
	s_lastTickMs = now;

	const HWND hWnd = CryptoCard::gmainWindow;
	if (!hWnd || !IsWindow(hWnd))
		return;

	if (IsIconic(hWnd))
		return;

	const LONG_PTR exStyle = GetWindowLongPtrW(hWnd, GWL_EXSTYLE);
	//const bool isTopmost = (exStyle & WS_EX_TOPMOST) != 0;
	//if (isTopmost)
	//	return;

	// Keep it on top without stealing focus.
	SetWindowPos(
		hWnd,
		HWND_TOPMOST,
		0, 0, 0, 0,
		SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_NOSENDCHANGING
	);
#endif
}

void Loop_Machine() {
	SetCurrentThreadPriorityNormal();
	while (1) {
		g_StateMachine.Loop();
	}
}

void RunStateMachine() {
	if (g_StateMachine.GetStatus() == STATUS_Init) {
		g_StateMachine.SetStatus(STATUS_Lobby);
		std::thread(Loop_Machine).detach();
	}
}

UINT64 current_time_ms() {
	using namespace std::chrono;
	return duration_cast<milliseconds>(
		steady_clock::now().time_since_epoch()
	).count();
}

const char* LogTagToString(LogTag tag)
{
	switch (tag) {
	case LogTag::Status:    	return "Status";
	case LogTag::RTP:       	return "RTP";
	case LogTag::Risiko:    	return "Risiko";
	case LogTag::CardGamble:	return "CardGamble";
	case LogTag::DB:        	return "DB";
	case LogTag::Hook:      	return "Hook";
	case LogTag::Fingerprint: 	return "Fingerprint";
	case LogTag::General:
	default:                	return "General";
	}
}

void DebugPrintf(const char* fmt, ...) {
#if ENABLE_LOGS == 1
	va_list args;
	va_start(args, fmt);
	char buffer[512];
	if (fmt && fmt[0] == '[') {
		vsnprintf(buffer, sizeof(buffer), fmt, args);
	}
	else {
		const int prefixLen = snprintf(buffer, sizeof(buffer), "[%s] ", LogTagToString(LogTag::General));
		if (prefixLen > 0 && prefixLen < (int)sizeof(buffer)) {
			vsnprintf(buffer + prefixLen, sizeof(buffer) - prefixLen, fmt ? fmt : "", args);
		}
	}
	va_end(args);
	OutputDebugStringA(buffer);
#endif
}

void DebugPrintfW(const wchar_t* fmt, ...) {
#if ENABLE_LOGS == 1
	va_list args;
	va_start(args, fmt);
	wchar_t buffer[512];
	if (fmt && fmt[0] == L'[') {
		vswprintf(buffer, sizeof(buffer) / sizeof(wchar_t), fmt, args);
	}
	else {
		const wchar_t* tag = L"General";
		int prefixLen = swprintf(buffer, sizeof(buffer) / sizeof(wchar_t), L"[%s] ", tag);
		if (prefixLen > 0 && prefixLen < (int)(sizeof(buffer) / sizeof(wchar_t))) {
			vswprintf(buffer + prefixLen, (sizeof(buffer) / sizeof(wchar_t)) - prefixLen, fmt ? fmt : L"", args);
		}
	}
	va_end(args);
	OutputDebugStringW(buffer);
#endif
}

void DebugPrintfT(LogTag tag, const char* fmt, ...)
{
#if ENABLE_LOGS == 1
	va_list args;
	va_start(args, fmt);
	char buffer[512];
	const int prefixLen = snprintf(buffer, sizeof(buffer), "[%s] ", LogTagToString(tag));
	if (prefixLen > 0 && prefixLen < (int)sizeof(buffer)) {
		vsnprintf(buffer + prefixLen, sizeof(buffer) - prefixLen, fmt ? fmt : "", args);
	}
	va_end(args);
	OutputDebugStringA(buffer);
#else
	(void)tag; (void)fmt;
#endif
}

void DebugPrintfWT(LogTag tag, const wchar_t* fmt, ...)
{
#if ENABLE_LOGS == 1
	va_list args;
	va_start(args, fmt);
	wchar_t buffer[512];
	const wchar_t* wtag = L"General";
	switch (tag) {
	case LogTag::Status:     wtag = L"Status"; break;
	case LogTag::RTP:        wtag = L"RTP"; break;
	case LogTag::Risiko:     wtag = L"Risiko"; break;
	case LogTag::CardGamble: wtag = L"CardGamble"; break;
	case LogTag::DB:         wtag = L"DB"; break;
	case LogTag::Hook:       wtag = L"Hook"; break;
	case LogTag::Fingerprint: wtag = L"Fingerprint"; break;
	case LogTag::General:
	default:                wtag = L"General"; break;
	}
	int prefixLen = swprintf(buffer, sizeof(buffer) / sizeof(wchar_t), L"[%s] ", wtag);
	if (prefixLen > 0 && prefixLen < (int)(sizeof(buffer) / sizeof(wchar_t))) {
		vswprintf(buffer + prefixLen, (sizeof(buffer) / sizeof(wchar_t)) - prefixLen, fmt ? fmt : L"", args);
	}
	va_end(args);
	OutputDebugStringW(buffer);
#else
	(void)tag; (void)fmt;
#endif
}

void DebugHexDump(const void* data, size_t size)
{
#if ENABLE_LOGS == 1
	const unsigned char* p = static_cast<const unsigned char*>(data);

	char line[128];              // plenty for one 16-byte line
	size_t offset = 0;

	while (offset < size)
	{
		int len = 0;

		// offset
		len += sprintf_s(line + len, sizeof(line) - len, "%08zx  ", offset);

		// hex bytes
		for (size_t i = 0; i < 16; ++i)
		{
			if (offset + i < size)
				len += sprintf_s(line + len, sizeof(line) - len,
					"%02X ", p[offset + i]);
			else
				len += sprintf_s(line + len, sizeof(line) - len, "   ");
		}

		// ASCII
		len += sprintf_s(line + len, sizeof(line) - len, " ");
		for (size_t i = 0; i < 16 && offset + i < size; ++i)
		{
			unsigned char c = p[offset + i];
			line[len++] = (c >= 32 && c < 127) ? c : '.';
		}
		line[len] = '\0';

		OutputDebugStringA(line);
		OutputDebugStringA("\r\n");

		offset += 16;
	}
#endif
}

uint16_t CalcChecksum(uint32_t version) {
	return (BYTE(version) + BYTE(version >> 8) + BYTE(version >> 16) + BYTE(version >> 24)) & 0xFFFF;
}

void Patch(DWORD dwBaseAddress, char* szData, int iSize)
{
	DWORD dwOldProtection = NULL;

	VirtualProtect((LPVOID)dwBaseAddress, iSize, PAGE_EXECUTE_READWRITE, &dwOldProtection);
	CopyMemory((LPVOID)dwBaseAddress, szData, iSize);
	VirtualProtect((LPVOID)dwBaseAddress, iSize, dwOldProtection, NULL);
}


BYTE GetRandomByte(BYTE modules)
{
	static std::random_device rd;
	static std::mt19937 gen(rd());
	static std::uniform_int_distribution<int> dist(0, 255);

	return static_cast<BYTE>(dist(gen)) % modules;
}

static void LeftClickNow()
{
	INPUT inputs[2] = {};

	inputs[0].type = INPUT_MOUSE;
	inputs[0].mi.dwFlags = MOUSEEVENTF_LEFTDOWN;

	inputs[1].type = INPUT_MOUSE;
	inputs[1].mi.dwFlags = MOUSEEVENTF_LEFTUP;

	SendInput(2, inputs, sizeof(INPUT));
	DebugPrintf("Left Clicked");
}

// Non-blocking: schedules a click after delayMs, returns immediately
void LeftClickAt(int x, int y, int delayMs)
{
	std::thread([x, y, delayMs]() {
		SetCurrentThreadPriorityNormal();
		if (delayMs > 0)
			std::this_thread::sleep_for(std::chrono::milliseconds(delayMs));

		SetCursorPos(x, y);
		LeftClickNow();
		}).detach();
}