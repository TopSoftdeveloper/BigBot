#pragma once
#include "GlobalVar.h"
#include "..\\import_header\\Cgos.h"
struct CTIMEINFO
{
	unsigned __int8 Day;
	unsigned __int8 Month;
	unsigned __int16 Year;
	unsigned __int8 Hour;
	unsigned __int8 Minute;
};

struct CUNIWDCONFIG
{
	unsigned int dwTimeout;
	unsigned int dwDelay;
	unsigned int dwMode;
};

struct CUNIBOARDINFO
{
	unsigned int dwSize;
	wchar_t szHWPlatform[32];
	wchar_t szHWRevision[32];
	wchar_t szBIOSVersion[32];
	wchar_t szManufacturer[32];
	CTIMEINFO stManufacturDate;
	CTIMEINFO stMaintenanceTime;
	wchar_t szSerialNumber[32];
};

struct CBOOTCTRLINFO
{
	unsigned int dwSize;
	wchar_t szBootCtrlVerHWPlatform[32];
	CTIMEINFO stProductionDate;
};

struct CUNIEXTENDBOARDINFO
{
	unsigned int dwSize;
	unsigned int dwBootCounter;
	unsigned int dwRunningCounter;
	wchar_t tcBootCounter[32];
	wchar_t tcRunningCounter[32];
};

struct CUNIEXTENDFANINFO
{
	unsigned int dwType;
	unsigned int dwCurSpeed;
};

class CUniAPIEx
{
public:
	CUniAPIEx(void);
	
	DWORD m_dw04;
	DWORD m_dw08;
	infoStructure* m_pInfoStart;
	infoStructure* m_pInfoLast;
	DWORD m_dw14; //infoStructure* 
	DWORD m_dw18; //infoStructure* 

	virtual ~CUniAPIEx();
	virtual void Close();
	virtual unsigned int GetVersionNumber();
	virtual unsigned int GetBoardInfo(CUNIBOARDINFO*);
	virtual int I2CConfig();
	virtual int I2CReadByte(unsigned __int8, unsigned __int8*);
	virtual int I2CWriteByte(unsigned __int8, unsigned __int8);
	virtual int I2CWriteStr(unsigned __int8, unsigned int, unsigned __int8*);
	virtual int I2CReadStr(unsigned __int8, unsigned int, unsigned __int8*);
	virtual int I2CWriteCommand(unsigned __int8, unsigned __int8);
	virtual int I2CWriteTime(unsigned int, _SYSTEMTIME*);
	virtual int WatchDogConfig(CUNIWDCONFIG*);
	virtual int WatchDogStop();
	virtual int WatchDogGetStatus();
	virtual int WatchDogTrigger();
	virtual int VgaConfig();
	virtual int VgaGetBacklight(unsigned __int8*);
	virtual int VgaSetBacklight(unsigned __int8);
	virtual int VgaGetContrast(unsigned __int8*);
	virtual int VgaSetContrast(unsigned __int8);
	virtual int GetTemperatur(unsigned int*);
	virtual int GetBatteryVol(long double*, unsigned int*);
	virtual int GetBootCtrlVer(CBOOTCTRLINFO*);
	virtual int GetExtendBoardInfo(CUNIEXTENDBOARDINFO*);
	virtual int GetContrast(unsigned int*, unsigned int);
	virtual int SetContrast(unsigned int*, unsigned int);
	virtual int GetBrightness(unsigned int*, unsigned int);
	virtual int SetBrightness(unsigned int*, unsigned int);
	virtual int SendAudioCfgData(unsigned __int8, unsigned __int8*, unsigned __int8);
	virtual int GetFanInfo(CUNIEXTENDFANINFO*);
	virtual int WriteEEPROM(unsigned __int8*, unsigned int, unsigned int);
	virtual int ReadEEPROM(unsigned __int8*, unsigned int, unsigned int);
	virtual int SendVCPSets(unsigned int, unsigned __int8, unsigned int*);
	virtual int GetVCPSets(unsigned int, unsigned __int8, unsigned int*, unsigned int*);
	virtual int SaveTFTSettings(unsigned int);							
};
