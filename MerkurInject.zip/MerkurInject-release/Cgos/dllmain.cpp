// dllmain.cpp : Defines the entry point for the DLL application.
#include "stdafx.h"
#include "Global.h"
#include <malloc.h>
#include <tchar.h>
#include "Cgos.h"

HMODULE g_hModule;
BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
					 )
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		{
			TCHAR tszModuleName[MAX_PATH] = _T("");
			TCHAR tszDllName[MAX_PATH] = _T("");
			GetModuleFileName(NULL, tszModuleName, MAX_PATH);
			TCHAR* p = _tcsrchr(tszModuleName, '\\');

			*(p) = NULL;
			SetCurrentDirectory(tszModuleName);
		}
		g_hModule = hModule;
		break;
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
	case DLL_PROCESS_DETACH:
		break;
	}
	return TRUE;
}


// Function declarations

int  MainProc_10001000(int nFlag, int nCmd, int nSize, int nParam1, int nParam2, int nParam3, int nParam4, int nParam5, DWORD *pdwRes, DWORD *pdwAdd);
int  GetInfo_100010E0(char nFlag, int nCmd, int nSize, int nParam1, int nParam2, int nParam3, int nParam4, 
					  int nParam5, DWORD *pdwRes, DWORD *pdwAdd, void* pInBuf, int nInputLen, void* pOutBuf, int nOutLen);
void MultiByte2WCHAR_10001340(char *pszSrc, WCHAR *pwszDest, int nLen);
BOOL Service_100042B0(DWORD dwType, char *szSub, LPCSTR lpServiceName, HMODULE hModule);
void * Memset_10004570(void *lpMem, char Val, int nSize);
HANDLE CreateFileA_CGOS_10004580();
BOOL LibInstall_100045A0(int nType);
BOOL DeviceIoControl_10004720(HANDLE hDevice, DWORD dwIoControlCode, LPVOID lpInBuffer, DWORD nInBufferSize, LPVOID lpOutBuffer, DWORD nOutBufferSize, LPDWORD lpBytesReturned);
void CloseHandle_10004750(HANDLE hObject);
HKEY GetHKEYbyNameA_10004760(char* szName);
void MakeRegPath_100047F0(char* szIn1, char* szIn2,char* szout);
BOOL SetRegKey_10004890(char *lpAppName, char *lpKeyName, char* lpString, char* lpFileName);
BOOL  SetRegKey_100049A0(char* lpAppName, char* lpValName, int Data, char* lpFileName);


char AppName[16] = { 0 }; 

HANDLE g_hDevice = INVALID_HANDLE_VALUE; 
DWORD g_dwError_1000FCA8; 
DWORD* g_offErr_1000F004 = &g_dwError_1000FCA8; 
int g_dwLibSuccess_1000FCA0 = 0;
int g_nDRVVer_1000FCA4 = 0; 

CHAR g_String[16] = {0};


//----- (10001000) --------------------------------------------------------
int  MainProc_10001000(int nFlag, int nCmd, int nSize, int nParam1, int nParam2, int nParam3, int nParam4, int nParam5, DWORD *pdwRes, DWORD *pdwAdd)
{
	int result; 
	DWORD BytesReturned; 
	DEVOUT_0C OutBuffer;	
	DEVINPUT_1C InBuffer;
	InBuffer.nCmd_0 = nCmd;
	InBuffer.nSize_4 = nSize;
	InBuffer.nParam_8 = nParam1;
	InBuffer.nParam_c = nParam2;
	InBuffer.nParam_10 = nParam3;
	InBuffer.nParam_14 = nParam4;
	InBuffer.nParam_18 = nParam5;
	if ( g_dwLibSuccess_1000FCA0	&& (DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, sizeof(InBuffer), &OutBuffer, sizeof(OutBuffer), &BytesReturned)) )
	{
		if ( BytesReturned >= 0xC )
		{
			if ( OutBuffer.nErrCode_0)
			{
				*g_offErr_1000F004 = OutBuffer.nErrCode_0;
				return 0;
			}
			else
			{
				result = OutBuffer.nResult_4;
				if ( pdwRes ) *pdwRes = OutBuffer.nResult_4;
				if ( pdwAdd ) *pdwAdd = OutBuffer.nAddInfo_8;
				if ( nFlag == 1 )	return 1;
			}
		}
		else
		{
			*g_offErr_1000F004 = -1;
			return 0;
		}
	}
	else
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
	return result;
}
int  GetInfo_100010E0(char nFlag, int nCmd, int nSize, int nParam1, int nParam2, int nParam3, int nParam4, 
						 int nParam5, DWORD *pdwRes, DWORD *pdwAdd, void* pInBuf, int nInputLen, void* pOutBuf, int nOutLen)
{
	DWORD BytesReturned; 	
	DWORD dwBuf[128];
	DWORD *pBuf; 
	//Src = pInBuf;
	int nRet = 0;
	pBuf = dwBuf;
	
	if ( !g_dwLibSuccess_1000FCA0 )
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
	if ( nFlag != 8 )
	{
		if ( pInBuf ) nInputLen = *(DWORD*)pInBuf;
		if ( pOutBuf ) nOutLen = *(DWORD*)pOutBuf;
	}
	if ( nInputLen && !pInBuf )
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
	if ( nOutLen && !pOutBuf )
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
	int nBufSize;
	nBufSize = nInputLen + sizeof(DEVINPUT_1C) + nOutLen + sizeof(DEVOUT_0C);
	BOOL bflag = FALSE;
	if ( nBufSize > 0x200 )
	{
		bflag = TRUE;
		pBuf = (DWORD*)malloc(nBufSize);
		if (pBuf == 0) return 0;
	}
	DEVINPUT_1C *pInput = (DEVINPUT_1C*)pBuf;
	pInput->nCmd_0 = nCmd;
	pInput->nSize_4 = nSize;
	pInput->nParam_8 = nParam1;
	pInput->nParam_c = nParam2;
	pInput->nParam_10 = nParam3;
	pInput->nParam_14 = nParam4;
	pInput->nParam_18 = nParam5;
	if (pInBuf) memcpy(&pBuf[7], pInBuf, nInputLen);
	DEVOUT_0C* pDevOut = (DEVOUT_0C*) pBuf+nInputLen+sizeof(DEVINPUT_1C);
	if ( DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, pInput, nInputLen+28, pDevOut, nOutLen + 12, &BytesReturned) && BytesReturned >= 12
		&& ((nFlag == 4) || BytesReturned >= (DWORD)(nOutLen+12)) )
	{
		if ( pDevOut->nErrCode_0)
		{
			*g_offErr_1000F004 = pDevOut->nErrCode_0;
		}
		else
		{
			if ( pOutBuf )	memcpy(pOutBuf, &pDevOut[3], nOutLen);
			if ( pdwRes )		*pdwRes = pDevOut->nResult_4;
			if ( pdwAdd )		*pdwAdd = pDevOut->nAddInfo_8;
			if ( nFlag != 1 )	return pDevOut->nResult_4;;
			nRet = 1;
		}
	}
	else *g_offErr_1000F004 = -1;
	if ( bflag ) free(pBuf);
	return nRet;
}
void MultiByte2WCHAR_10001340(char *pszSrc, WCHAR *pwszDest, int nLen)
{
	WCHAR *pwDest; // edx
	char *pbySrc; // edi	
	int nCnt; // esi

	pwDest = pwszDest;
	pbySrc = pszSrc;
	nCnt = nLen;
	if ( !pszSrc || !pwszDest || !nLen)	return;
	while ( 1 )
	{
		nCnt = nCnt - 1;
		if ( !*pbySrc )	break;
		*pwDest = (WORD)*pbySrc;
		pwDest = pwDest++;
		pbySrc = pbySrc++;
		if ( !nCnt )
		{
			*pwDest = 0;
			return;
		}
	}
	if ( nCnt )	*pwDest = 0;
}

BOOL CgosLibUninitialize()
{
	if ( !g_dwLibSuccess_1000FCA0 ) return FALSE;
	g_dwLibSuccess_1000FCA0 = g_dwLibSuccess_1000FCA0 - 1;
	if ( !g_dwLibSuccess_1000FCA0 )
	{
		if ( g_hDevice != INVALID_HANDLE_VALUE)
			CloseHandle_10004750(g_hDevice);
		g_hDevice = INVALID_HANDLE_VALUE;
	}
	return TRUE;
}

BOOL CgosLibInitialize()
{
	HANDLE hDev; 
	int nflag; 
	DWORD BytesReturned; 
	DEVOUT_0C OutBuffer;
	DEVINPUT_1C InBuffer; 

	if (g_dwLibSuccess_1000FCA0 ) return TRUE;

	hDev = CreateFileA_CGOS_10004580();
	g_hDevice = hDev;
	if ( !hDev )
	{
		g_hDevice = INVALID_HANDLE_VALUE;
		return FALSE;
	}
	if ( hDev == INVALID_HANDLE_VALUE )
		return FALSE;
	g_dwLibSuccess_1000FCA0++;
	if ( g_dwLibSuccess_1000FCA0 )
	{
		memset(&InBuffer, 0, sizeof(InBuffer));
		nflag = DeviceIoControl_10004720(hDev, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned);
		if ( nflag )
		{
			if ( BytesReturned >= 0xC )
			{
				if ( OutBuffer.nErrCode_0 )
				{
					*g_offErr_1000F004 = OutBuffer.nErrCode_0;
					nflag = 0;
				}
				else
				{
					nflag = OutBuffer.nResult_4;
				}
			}
			else
			{
				*g_offErr_1000F004 = -1;
				nflag = 0;
			}
		}
		else
		{
			*g_offErr_1000F004 = -1;
		}
	}
	else
	{
		*g_offErr_1000F004 = -1;
		nflag = 0;
	}
	g_nDRVVer_1000FCA4 = nflag;
	if ( (nflag & 0xFF000000) != 0x1000000 )
	{
		CgosLibUninitialize();
		return FALSE;
	}
	return TRUE;
}

int CgosLibGetVersion()
{
	return 0x103000F;
}

//----- (100014F0) --------------------------------------------------------
int CgosLibGetDrvVersion()
{
	return g_nDRVVer_1000FCA4;
}

BOOL CgosLibIsAvailable()
{
	return g_dwLibSuccess_1000FCA0 != 0;
}

BOOL CgosLibInstall(int nType)
{
	return LibInstall_100045A0(nType);
}
int CgosLibGetLastError()
{
	return *g_offErr_1000F004;
}
BOOL CgosLibSetLastErrorAddress(DWORD* pdwAddr)
{
	if ( !pdwAddr )	pdwAddr = &g_dwError_1000FCA8;
	g_offErr_1000F004 = pdwAddr;
	*pdwAddr = 0;
	return 1;
}

BOOL CgosBoardClose(DWORD BytesReturned)
{
	DEVOUT_0C OutBuffer;
	DEVINPUT_1C InBuffer; 

	if (!g_dwLibSuccess_1000FCA0)
	{
		*g_offErr_1000F004 = -1;
		return FALSE;
	}
	InBuffer.nCmd_0 = 1;
	InBuffer.nSize_4 = BytesReturned;
	memset(&InBuffer.nParam_8, 0, 20);

	if ( g_dwLibSuccess_1000FCA0 && (DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned)) )
	{
		if ( BytesReturned >= 0xC )
		{
			if ( OutBuffer.nErrCode_0 )
			{
				*g_offErr_1000F004 = OutBuffer.nErrCode_0;
				return 0;
			}
			else
			{
				return 1;
			}
		}
		else
		{
			*g_offErr_1000F004 = -1;
			return 0;
		}
	}	
	*g_offErr_1000F004 = -1;
	return FALSE;
}

int  CgosBoardCount(DWORD BytesReturned, int nParam)
{
	int result; 
	DEVOUT_0C OutBuffer;
	DEVINPUT_1C InBuffer; 
	if (!g_dwLibSuccess_1000FCA0)
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
	InBuffer.nCmd_0 = 2;
	InBuffer.nSize_4 = 0;
	InBuffer.nParam_8 = 0;
	InBuffer.nParam_c = BytesReturned;
	InBuffer.nParam_10 = nParam;
	InBuffer.nParam_14 = 0;
	InBuffer.nParam_18 = 0;
	result = DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned);
	if ( result )
	{
		if ( BytesReturned >= 0xC )
		{
			if ( OutBuffer.nErrCode_0 )
			{
				*g_offErr_1000F004 = OutBuffer.nErrCode_0;
				return 0;
			}
			else
			{
				return OutBuffer.nResult_4;
			}
		}
		else
		{
			*g_offErr_1000F004 = -1;
			return 0;
		}
	}
	else
	{
		*g_offErr_1000F004 = -1;
	}
	return result;
}

int  CgosBoardOpen(int param1, int param2, int param3, DWORD *pdwRes)
{
	return MainProc_10001000(0, 3, 0, param2, param1, param3, 0, 0, pdwRes, 0);
}

int CgosBoardOpenByNameA(char *pszName, DWORD *pdwRes)
{
	int nNameLen; 
	if ( pszName ) nNameLen = strlen(pszName);
	return GetInfo_100010E0(0, 4, 0, 0, 0, 0, 0, 0, pdwRes, 0, pszName, nNameLen, 0, 0);
}

int  CgosBoardGetNameA(int nSize, char *szStr, int nlen)
{
	return GetInfo_100010E0(4, 5, nSize, 0, 0, 0, 0, 0, 0, 0, 0, 0, szStr, nlen);
}
int  CgosBoardGetInfoA(int nSize, int *pOut)
{
	return GetInfo_100010E0(8, 6, nSize, 0, 0, 0, 0, 0, 0, 0, 0, 0, pOut, 0);
}
int  CgosBoardGetBootCounter(int nSize, DWORD *pRes)
{
	return MainProc_10001000(0, 7, nSize, 0, 0, 0, 0, 0, pRes, 0);
}
int  CgosBoardGetRunningTimeMeter(int a1, DWORD *pRes)
{
	return MainProc_10001000(0, 8, a1, 0, 0, 0, 0, 0, pRes, 0);
}
int  CgosBoardGetOption(int a1, int a2, DWORD *pRes)
{
	return MainProc_10001000(0, 9, a1, a2, 0, 0, 0, 0, pRes, 0);
}
BOOL  CgosBoardSetOption(DWORD BytesReturned, int param1, int param2)
{
	BOOL result; 
	DEVOUT_0C OutBuffer; 
	DEVINPUT_1C InBuffer; 

	if ( !g_dwLibSuccess_1000FCA0 )
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
	InBuffer.nCmd_0 = 10;
	InBuffer.nSize_4 = BytesReturned;
	InBuffer.nParam_8 = param1;
	InBuffer.nParam_c = param2;
	memset(&InBuffer.nParam_10, 0, 12);
	result = DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned);
	if ( result )
	{
		if ( BytesReturned < 0xC )
		{
			*g_offErr_1000F004 = -1;
			return 0;
		}
		if ( OutBuffer.nErrCode_0 )
		{
			*g_offErr_1000F004 = OutBuffer.nErrCode_0;
			return 0;
		}
		else
		{
			return 1;
		}
	}
	else
	{
		*g_offErr_1000F004 = -1;
	}
	return result;
}
int  CgosVgaCount(DWORD BytesReturned)
{
	DEVOUT_0C OutBuffer; 
	DEVINPUT_1C InBuffer; 
	if (!g_dwLibSuccess_1000FCA0)
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
	InBuffer.nCmd_0 = 12,
	InBuffer.nSize_4 = BytesReturned;		
	memset(&InBuffer.nParam_8, 0, 20);

	if ( DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned) )
	{
		if ( BytesReturned >= 0xC )
		{
			if ( OutBuffer.nErrCode_0 )
			{
				*g_offErr_1000F004 = OutBuffer.nErrCode_0;
				return 0;
			}
			else
			{
				return OutBuffer.nResult_4;
			}
		}
		else
		{
			*g_offErr_1000F004 = -1;
			return 0;
		}
	}
	*g_offErr_1000F004 = -1;
	return 0;
}
int  CgosVgaGetContrast(int nSize, int param, DWORD *pRes)
{
	return MainProc_10001000(0, 13, nSize, param, 0, 0, 0, 0, pRes, 0);
}

BOOL  CgosVgaSetContrast(DWORD BytesReturned, int a2, int a3)
{
	BOOL result; // eax
	DEVOUT_0C OutBuffer; // [esp+0h] [ebp-28h] BYREF
	DEVINPUT_1C InBuffer; // [esp+Ch] [ebp-1Ch] BYREF

	if ( !g_dwLibSuccess_1000FCA0 )
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
	InBuffer.nCmd_0 = 14;
	InBuffer.nSize_4 = BytesReturned;
	InBuffer.nParam_8 = a2;
	InBuffer.nParam_c = a3;
	memset(&InBuffer.nParam_10, 0, 12);
	result = DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned);
	if ( result )
	{
		if ( BytesReturned < 0xC )
		{
			*g_offErr_1000F004 = -1;
			return 0;
		}
		if ( OutBuffer.nErrCode_0 )
		{
			*g_offErr_1000F004 = OutBuffer.nErrCode_0;
			return 0;
		}
		else
		{
			return 1;
		}
	}
	*g_offErr_1000F004 = -1;
	return FALSE;
}

int  CgosVgaGetContrastEnable(int a1, int a2, DWORD *a3)
{
	return MainProc_10001000(0, 15, a1, a2, 0, 0, 0, 0, a3, 0);
}

BOOL  CgosVgaSetContrastEnable(DWORD BytesReturned, int a2, int a3)
{
	BOOL result; 
	DEVOUT_0C OutBuffer; 
	DEVINPUT_1C InBuffer; 

	if ( !g_dwLibSuccess_1000FCA0 )
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
	InBuffer.nSize_4 = BytesReturned;
	InBuffer.nParam_8 = a2;
	InBuffer.nParam_c = a3;
	InBuffer.nCmd_0 = 16;
	memset(&InBuffer.nParam_10, 0, 12);
	result = DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned);
	if ( result )
	{
		if ( BytesReturned < 0xC )
		{
			*g_offErr_1000F004 = -1;
			return 0;
		}
		if ( OutBuffer.nErrCode_0 )
		{
			*g_offErr_1000F004 = OutBuffer.nErrCode_0;
			return 0;
		}
		else
		{
			return 1;
		}
	}
	*g_offErr_1000F004 = -1;
	return FALSE;
}
int  CgosVgaGetBacklight(int a1, int a2, DWORD *a3)
{
	return MainProc_10001000(0, 17, a1, a2, 0, 0, 0, 0, a3, 0);
}
BOOL  CgosVgaSetBacklight(DWORD BytesReturned, int a2, int a3)
{
	BOOL result;
	DEVOUT_0C OutBuffer;
	DEVINPUT_1C InBuffer; 

	if ( !g_dwLibSuccess_1000FCA0 )
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
	InBuffer.nCmd_0 = 18;
	InBuffer.nSize_4 = BytesReturned;
	InBuffer.nParam_8 = a2;
	InBuffer.nParam_c = a3;
	memset(&InBuffer.nParam_10, 0, 12);
	result = DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned);
	if ( result )
	{
		if ( BytesReturned < 0xC )
		{
			*g_offErr_1000F004 = -1;
			return 0;
		}
		if ( OutBuffer.nErrCode_0 )
		{
			*g_offErr_1000F004 = OutBuffer.nErrCode_0;
			return 0;
		}
		else
		{
			return 1;
		}
	}
	*g_offErr_1000F004 = -1;
	return FALSE;
}
int  CgosVgaGetBacklightEnable(int a1, int a2, DWORD *a3)
{
	return MainProc_10001000(0, 19, a1, a2, 0, 0, 0, 0, a3, 0);
}

BOOL  CgosVgaSetBacklightEnable(DWORD BytesReturned, int a2, int a3)
{
	BOOL result; 
	DEVOUT_0C OutBuffer; 
	DEVINPUT_1C InBuffer; 

	if ( !g_dwLibSuccess_1000FCA0 )
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
	InBuffer.nCmd_0 = 20;
	InBuffer.nSize_4 = BytesReturned;
	InBuffer.nParam_8 = a2;
	InBuffer.nParam_c = a3;
	memset(&InBuffer.nParam_10, 0, 12);
	result = DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned);
	if ( result )
	{
		if ( BytesReturned < 0xC )
		{
			*g_offErr_1000F004 = -1;
			return 0;
		}
		if ( OutBuffer.nErrCode_0 )
		{
			*g_offErr_1000F004 = OutBuffer.nErrCode_0;
			return 0;
		}
		else
		{
			return 1;
		}
	}
	*g_offErr_1000F004 = -1;
	return FALSE;
}
BOOL  CgosVgaEndDarkBoot(DWORD BytesReturned, int a2)
{
	BOOL result; 
	DEVOUT_0C OutBuffer;
	DEVINPUT_1C InBuffer; 
	if ( !g_dwLibSuccess_1000FCA0 )
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}			
	InBuffer.nCmd_0 = 21;
	InBuffer.nSize_4 = BytesReturned;
	InBuffer.nParam_8 = 0;
	InBuffer.nParam_c = a2;
	memset(&InBuffer.nParam_10, 0, 12);
	result = DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned);
	if ( result )
	{
		if ( BytesReturned >= 0xC )
		{
			if ( OutBuffer.nErrCode_0 )
			{
				*g_offErr_1000F004 = OutBuffer.nErrCode_0;
				return 0;
			}
			else
			{
				return 1;
			}
		}
		else
		{
			*g_offErr_1000F004 = -1;
			return 0;
		}
	}
	*g_offErr_1000F004 = -1;
	return FALSE;
}
int  CgosVgaGetInfo(int a1, int a2, int *a3)
{
	return GetInfo_100010E0(8, 22, a1, a2, 0, 0, 0, 0, 0, 0, 0, 0, a3, 0);
}
int  CgosStorageAreaCount(DWORD BytesReturned, int a2)
{
	int result;
	DEVOUT_0C OutBuffer;
	DEVINPUT_1C InBuffer; 
	if (!g_dwLibSuccess_1000FCA0)
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
	InBuffer.nSize_4 = BytesReturned;
	InBuffer.nParam_8 = a2;
	InBuffer.nCmd_0 = 23;
	memset(&InBuffer.nParam_c, 0, 16);
	result = DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned);
	if ( result )
	{
		if ( BytesReturned >= 0xC )
		{
			if ( OutBuffer.nErrCode_0 )
			{
				*g_offErr_1000F004 = OutBuffer.nErrCode_0;
				return 0;
			}
			else
			{
				return OutBuffer.nResult_4;
			}
		}
		else
		{
			*g_offErr_1000F004 = -1;
			return 0;
		}
	}
	*g_offErr_1000F004 = -1;
	return FALSE;
}
int  CgosStorageAreaType(DWORD BytesReturned, int a2)
{
	int result; 
	DEVOUT_0C OutBuffer;
	DEVINPUT_1C InBuffer; 
	if (!g_dwLibSuccess_1000FCA0)
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
	InBuffer.nCmd_0 = 24;
	InBuffer.nSize_4 = BytesReturned;
	InBuffer.nParam_8 = a2;
	memset(&InBuffer.nParam_c, 0, 16);
	result = DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned);
	if ( result )
	{
		if ( BytesReturned >= 0xC )
		{
			if ( OutBuffer.nErrCode_0 )
			{
				*g_offErr_1000F004 = OutBuffer.nErrCode_0;
				return 0;
			}
			else return OutBuffer.nResult_4;
		}
		else
		{
			*g_offErr_1000F004 = -1;
			return 0;
		}
	}
	*g_offErr_1000F004 = -1;
	return FALSE;
}

int  CgosStorageAreaSize(DWORD BytesReturned, int a2)
{
	int result; 
	DEVOUT_0C OutBuffer;
	DEVINPUT_1C InBuffer; 
	if (!g_dwLibSuccess_1000FCA0)
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
	InBuffer.nCmd_0 = 25;
	InBuffer.nSize_4 = BytesReturned;
	InBuffer.nParam_8 = a2;
	memset(&InBuffer.nParam_c, 0, 16);
	result = DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned);
	if ( result )
	{
		if ( BytesReturned >= 0xC )
		{
			if ( OutBuffer.nErrCode_0 )
			{
				*g_offErr_1000F004 = OutBuffer.nErrCode_0;
				return 0;
			}
			else
			{
				return OutBuffer.nResult_4;
			}
		}
		else
		{
			*g_offErr_1000F004 = -1;
			return 0;
		}
	}
	*g_offErr_1000F004 = -1;
	return FALSE;
}
int  CgosStorageAreaBlockSize(DWORD BytesReturned, int a2)
{
	int result; 
	DEVOUT_0C OutBuffer;
	DEVINPUT_1C InBuffer; 
	if (!g_dwLibSuccess_1000FCA0)
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
	InBuffer.nCmd_0 = 25;
	InBuffer.nSize_4 = BytesReturned;
	InBuffer.nParam_8 = a2;
	memset(&InBuffer.nParam_c, 0, 16);
	result = DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned);
	if ( result )
	{
		if ( BytesReturned >= 0xC )
		{
			if ( OutBuffer.nErrCode_0 )
			{
				*g_offErr_1000F004 = OutBuffer.nErrCode_0;
				return 0;
			}
			else
			{
				return OutBuffer.nResult_4;
			}
		}
		else
		{
			*g_offErr_1000F004 = -1;
			return 0;
		}
	}
	*g_offErr_1000F004 = -1;
	return FALSE;
}
int  CgosStorageAreaRead(int a1, int a2, int a3, int *a4, int a5)
{
	return GetInfo_100010E0(0, 27, a1, a2, a3, a5, 0, 0, 0, 0, 0, 0, a4, a5);
}
int  CgosStorageAreaWrite(int a1, int a2, int a3, int *a4, int Size)
{
	return GetInfo_100010E0(0, 28, a1, a2, a3, Size, 0, 0, 0, 0, a4, Size, 0, 0);
}

int  CgosStorageAreaErase(DWORD BytesReturned, int a2, int a3, int a4)
{
	DEVOUT_0C OutBuffer;
	DEVINPUT_1C InBuffer; 

	if ( g_dwLibSuccess_1000FCA0
		&& (InBuffer.nParam_8 = a2,
		InBuffer.nSize_4 = BytesReturned,
		InBuffer.nParam_c = a3,
		InBuffer.nParam_10 = a4,
		InBuffer.nCmd_0 = 29,
		InBuffer.nParam_14 = 0,
		InBuffer.nParam_18 = 0,
		DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned)) )
	{
		if ( BytesReturned >= 0xC )
		{
			if ( OutBuffer.nErrCode_0 )
			{
				*g_offErr_1000F004 = OutBuffer.nErrCode_0;
				return 0;
			}
			else
			{
				return 1;
			}
		}
		else
		{
			*g_offErr_1000F004 = -1;
			return 0;
		}
	}
	else
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
}
int  CgosStorageAreaEraseStatus(int a1, int a2, int a3, int a4, DWORD *a5)
{
	return MainProc_10001000(0, 30, a1, a2, a3, a4, 0, 0, a5, 0);
}

int  CgosStorageAreaLock(int a1, int a2, int a3, int *a4, int Size)
{
	return GetInfo_100010E0(0, 82, a1, a2, a3, Size, 0, 0, 0, 0, a4, Size, 0, 0);
}
int  CgosStorageAreaUnlock(int a1, int a2, int a3, int *a4, int Size)
{
	return GetInfo_100010E0(0, 83, a1, a2, a3, Size, 0, 0, 0, 0, a4, Size, 0, 0);
}
int  CgosStorageAreaIsLocked(DWORD BytesReturned, int a2, int a3)
{
	int result; // eax
	DEVOUT_0C OutBuffer; // [esp+0h] [ebp-28h] BYREF
	DEVINPUT_1C InBuffer; // [esp+Ch] [ebp-1Ch] BYREF
	if ( !g_dwLibSuccess_1000FCA0 )
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
	InBuffer.nSize_4 = BytesReturned;
	InBuffer.nParam_8 = a2;
	InBuffer.nParam_c = a3;
	InBuffer.nCmd_0 = 84;
	memset(&InBuffer.nParam_10, 0, 12);
	result = DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned);
	if ( result )
	{
		if ( BytesReturned < 0xC )
		{
			*g_offErr_1000F004 = -1;
			return 0;
		}
		if ( OutBuffer.nErrCode_0 )
		{
			*g_offErr_1000F004 = OutBuffer.nErrCode_0;
			return 0;
		}
		else
		{
			return OutBuffer.nResult_4;
		}
	}
	*g_offErr_1000F004 = -1;
	return result;
}
int  CgosI2CCount(DWORD BytesReturned)
{
	DEVOUT_0C OutBuffer; // [esp+4h] [ebp-28h] BYREF
	DEVINPUT_1C InBuffer; // [esp+10h] [ebp-1Ch] BYREF

	InBuffer.nCmd_0 = 31;
	InBuffer.nSize_4 = BytesReturned;
	memset(&InBuffer.nParam_8, 0, 20);
	if ( g_dwLibSuccess_1000FCA0 && (DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned)) )
	{
		if ( BytesReturned >= 0xC )
		{
			if ( OutBuffer.nErrCode_0 )
			{
				*g_offErr_1000F004 = OutBuffer.nErrCode_0;
				return 0;
			}
			else
			{
				return OutBuffer.nResult_4;
			}
		}
		else
		{
			*g_offErr_1000F004 = -1;
			return 0;
		}
	}
	else
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
}
BOOL  CgosI2CIsAvailable(DWORD BytesReturned, int a2)
{
	BOOL result; // eax
	DEVOUT_0C OutBuffer; // [esp+4h] [ebp-28h] BYREF
	DEVINPUT_1C InBuffer; // [esp+10h] [ebp-1Ch] BYREF

	if ( g_dwLibSuccess_1000FCA0 )
	{
		InBuffer.nCmd_0 = 33;
		InBuffer.nSize_4 = BytesReturned;
		InBuffer.nParam_8 = a2;		
		memset(&InBuffer.nParam_c, 0, 16);
		result = DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned);
		if ( result )
		{
			if ( BytesReturned >= 0xC )
			{
				if ( OutBuffer.nErrCode_0 )
				{
					*g_offErr_1000F004 = OutBuffer.nErrCode_0;
					return 0;
				}
				else
				{
					return 1;
				}
			}
			else
			{
				*g_offErr_1000F004 = -1;
				return 0;
			}
		}
		else
		{
			*g_offErr_1000F004 = -1;
		}
	}
	else
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
	return result;
}

int  CgosI2CType(DWORD BytesReturned, int a2)
{
	int result; // eax
	DEVOUT_0C OutBuffer; // [esp+4h] [ebp-28h] BYREF
	DEVINPUT_1C InBuffer; // [esp+10h] [ebp-1Ch] BYREF

	if ( g_dwLibSuccess_1000FCA0 )
	{
		InBuffer.nSize_4 = BytesReturned;
		InBuffer.nParam_8 = a2;
		InBuffer.nCmd_0 = 32;
		memset(&InBuffer.nParam_c, 0, 16);
		result = DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned);
		if ( result )
		{
			if ( BytesReturned >= 0xC )
			{
				if ( OutBuffer.nErrCode_0 )
				{
					*g_offErr_1000F004 = OutBuffer.nErrCode_0;
					return 0;
				}
				else
				{
					return OutBuffer.nResult_4;
				}
			}
			else
			{
				*g_offErr_1000F004 = -1;
				return 0;
			}
		}
		else
		{
			*g_offErr_1000F004 = -1;
		}
	}
	else
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
	return result;
}

int  CgosI2CRead(int a1, int a2, BYTE a3, int *a4, int a5)
{
	return GetInfo_100010E0(0, 34, a1, a2, a3, 0, 0, 0, 0, 0, 0, 0, a4, a5);
}


int  CgosI2CWrite(int a1, int a2, BYTE a3, int *a4, int Size)
{
	return GetInfo_100010E0(0, 35, a1, a2, a3, 0, 0, 0, 0, 0, a4, Size, 0, 0);
}


BOOL  CgosI2CReadRegister(int a1, int a2, BYTE a3, int a4, BYTE *a5)
{
	if ( !a5 ) return FALSE;
	if ( !MainProc_10001000(0, 36, a1, a2, (int)a3, a4, 0, 0, (DWORD*)&a3, 0) )	return FALSE;
	*a5 = a3;
	return 1;
}

BOOL  CgosI2CWriteRegister(int a1, int a2, DWORD BytesReturned, int a4, int a5)
{
	BOOL result; 
	DEVOUT_0C OutBuffer;
	DEVINPUT_1C InBuffer;

	if ( g_dwLibSuccess_1000FCA0 )
	{
		InBuffer.nSize_4 = a1;
		InBuffer.nParam_c = BytesReturned;
		InBuffer.nParam_8 = a2;
		InBuffer.nParam_10 = a4;
		InBuffer.nParam_14 = a5;
		InBuffer.nCmd_0 = 37;
		InBuffer.nParam_18 = 0;
		result = DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned);
		if ( result )
		{
			if ( BytesReturned >= 0xC )
			{
				if ( OutBuffer.nErrCode_0 )
				{
					*g_offErr_1000F004 = OutBuffer.nErrCode_0;
					return 0;
				}
				else
				{
					return 1;
				}
			}
			else
			{
				*g_offErr_1000F004 = -1;
				return 0;
			}
		}
		else
		{
			*g_offErr_1000F004 = -1;
		}
	}
	else
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
	return result;
}
int  CgosI2CWriteReadCombined(int a1, int a2, int a3, int *a4, int Size, int *a6, int a7)
{
	return GetInfo_100010E0(0, 38, a1, a2, a3, 0, 0, 0, 0, 0, a4, Size, a6, a7);
}
int  CgosI2CGetMaxFrequency(int a1, int a2, DWORD *a3)
{
	return MainProc_10001000(0, 85, a1, a2, 0, 0, 0, 0, a3, 0);
}
int  CgosI2CGetFrequency(int a1, int a2, DWORD *a3)
{
	return MainProc_10001000(0, 86, a1, a2, 0, 0, 0, 0, a3, 0);
}
BOOL  CgosI2CSetFrequency(DWORD BytesReturned, int a2, int a3)
{
	BOOL bRet; 
	DEVOUT_0C OutBuffer; 
	DEVINPUT_1C InBuffer;

	if ( !g_dwLibSuccess_1000FCA0 )
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}

	InBuffer.nSize_4 = BytesReturned;
	InBuffer.nParam_8 = a2;
	InBuffer.nParam_c = a3;
	InBuffer.nCmd_0 = 87;
	memset(&InBuffer.nParam_10, 0, 12);
	bRet = DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned);
	if ( bRet )
	{
		if ( BytesReturned < 0xC )
		{
			*g_offErr_1000F004 = -1;
			return 0;
		}
		if ( OutBuffer.nErrCode_0 )
		{
			*g_offErr_1000F004 = OutBuffer.nErrCode_0;
			return 0;
		}
		else
		{
			return 1;
		}
	}
	*g_offErr_1000F004 = -1;
	return bRet;
}
int  CgosIOCount(DWORD BytesReturned)
{
	DEVOUT_0C OutBuffer; 
	DEVINPUT_1C InBuffer;

	InBuffer.nSize_4 = BytesReturned;
	InBuffer.nCmd_0 = 39;
	memset(&InBuffer.nParam_8, 0, 20);

	if ( g_dwLibSuccess_1000FCA0 && DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned)) 
	{
		if ( BytesReturned >= 0xC )
		{
			if ( OutBuffer.nErrCode_0 )
			{
				*g_offErr_1000F004 = OutBuffer.nErrCode_0;
				return 0;
			}
			else
			{
				return OutBuffer.nResult_4;
			}
		}
		else
		{
			*g_offErr_1000F004 = -1;
			return 0;
		}
	}
	*g_offErr_1000F004 = -1;
	return 0;

}

BOOL  CgosIOIsAvailable(DWORD BytesReturned, int a2)
{
	BOOL result; 
	DEVOUT_0C OutBuffer; 
	DEVINPUT_1C InBuffer;

	if ( g_dwLibSuccess_1000FCA0 )
	{
		InBuffer.nSize_4 = BytesReturned;
		InBuffer.nParam_8 = a2;
		InBuffer.nCmd_0 = 40;
		memset(&InBuffer.nParam_c, 0, 16);
		result = DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned);
		if ( result )
		{
			if ( BytesReturned >= 0xC )
			{
				if ( OutBuffer.nErrCode_0 )
				{
					*g_offErr_1000F004 = OutBuffer.nErrCode_0;
					return 0;
				}
				else
				{
					return 1;
				}
			}
			else
			{
				*g_offErr_1000F004 = -1;
				return 0;
			}
		}
		else
		{
			*g_offErr_1000F004 = -1;
		}
	}
	else
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
	return result;
}

int  CgosIORead(int a1, int a2, DWORD *a3)
{
	return MainProc_10001000(0, 41, a1, a2, 0, 0, 0, 0, a3, 0);
}

BOOL  CgosIOWrite(DWORD BytesReturned, int a2, int a3)
{
	BOOL result; 
	DEVOUT_0C OutBuffer; 
	DEVINPUT_1C InBuffer;

	if ( !g_dwLibSuccess_1000FCA0 )
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}

	InBuffer.nSize_4 = BytesReturned;
	InBuffer.nParam_8 = a2;
	InBuffer.nParam_c = a3;
	InBuffer.nCmd_0 = 42;
	memset(&InBuffer.nParam_10, 0, 12);
	result = DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned);
	if ( result )
	{
		if ( BytesReturned < 0xC )
		{
			*g_offErr_1000F004 = -1;
			return 0;
		}
		if ( OutBuffer.nErrCode_0 )
		{
			*g_offErr_1000F004 = OutBuffer.nErrCode_0;
			return 0;
		}
		else
		{
			return 1;
		}
	}
	*g_offErr_1000F004 = -1;
	return result;
}
BOOL  CgosIOXorAndXor(DWORD BytesReturned, int a2, int a3, int a4, int a5)
{
	BOOL result; // eax
	DEVOUT_0C OutBuffer; // [esp+0h] [ebp-28h] BYREF
	DEVINPUT_1C InBuffer; // [esp+Ch] [ebp-1Ch] BYREF

	if ( g_dwLibSuccess_1000FCA0 )
	{
		InBuffer.nParam_c = a3;
		InBuffer.nSize_4 = BytesReturned;
		InBuffer.nParam_8 = a2;
		InBuffer.nParam_10 = a4;
		InBuffer.nParam_14 = a5;
		InBuffer.nCmd_0 = 43;
		InBuffer.nParam_18 = 0;
		result = DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned);
		if ( result )
		{
			if ( BytesReturned >= 0xC )
			{
				if ( OutBuffer.nErrCode_0 )
				{
					*g_offErr_1000F004 = OutBuffer.nErrCode_0;
					return 0;
				}
				else
				{
					return 1;
				}
			}
			else
			{
				*g_offErr_1000F004 = -1;
				return 0;
			}
		}
		else
		{
			*g_offErr_1000F004 = -1;
		}
	}
	else
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
	return result;
}
int  CgosIOGetDirection(int a1, int a2, DWORD *a3)
{
	return MainProc_10001000(0, 44, a1, a2, 0, 0, 0, 0, a3, 0);
}

BOOL  CgosIOSetDirection(DWORD BytesReturned, int a2, int a3)
{
	BOOL result; // eax
	DEVOUT_0C OutBuffer; // [esp+0h] [ebp-28h] BYREF
	DEVINPUT_1C InBuffer; // [esp+Ch] [ebp-1Ch] BYREF

	if ( !g_dwLibSuccess_1000FCA0 )
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}	
	InBuffer.nSize_4 = BytesReturned;
	InBuffer.nParam_8 = a2;
	InBuffer.nParam_c = a3;
	InBuffer.nCmd_0 = 45;
	memset(&InBuffer.nParam_10, 0, 12);
	result = DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned);
	if ( result )
	{
		if ( BytesReturned < 0xC )
		{
			*g_offErr_1000F004 = -1;
			return 0;
		}
		if ( OutBuffer.nErrCode_0 )
		{
			*g_offErr_1000F004 = OutBuffer.nErrCode_0;
			return 0;
		}
		else
		{
			return 1;
		}
	}
	else
	{
		*g_offErr_1000F004 = -1;
	}
	return result;
}

int  CgosIOGetDirectionCaps(int a1, int a2, DWORD *a3, DWORD *a4)
{
	return MainProc_10001000(0, 46, a1, a2, 0, 0, 0, 0, a3, a4);
}

int  CgosIOGetNameA(int a1, int a2, int *a3, int a4)
{
	return GetInfo_100010E0(4, 47, a1, a2, 0, 0, 0, 0, 0, 0, 0, 0, a3, a4);
}

//----- (10002E50) --------------------------------------------------------
int  CgosWDogCount(DWORD BytesReturned)
{
	DEVOUT_0C OutBuffer; 
	DEVINPUT_1C InBuffer;
	if (!g_dwLibSuccess_1000FCA0)
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
	
	InBuffer.nSize_4 = BytesReturned;
	InBuffer.nCmd_0 = 48;
	memset(&InBuffer.nParam_8, 0, 20);
	if (DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned)) 
	{
		if ( BytesReturned >= 0xC )
		{
			if ( OutBuffer.nErrCode_0 )
			{
				*g_offErr_1000F004 = OutBuffer.nErrCode_0;
				return 0;
			}
			else
			{
				return OutBuffer.nResult_4;
			}
		}
		else
		{
			*g_offErr_1000F004 = -1;
			return 0;
		}
	}
	*g_offErr_1000F004 = -1;
	return 0;
}
BOOL  CgosWDogIsAvailable(DWORD BytesReturned, int a2)
{
	BOOL result; // eax
	DEVOUT_0C OutBuffer; 
	DEVINPUT_1C InBuffer;

	if ( g_dwLibSuccess_1000FCA0 )
	{
		InBuffer.nSize_4 = BytesReturned;
		InBuffer.nParam_8 = a2;
		InBuffer.nCmd_0 = 49;
		memset(&InBuffer.nParam_c, 0, 16);
		result = DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned);
		if ( result )
		{
			if ( BytesReturned >= 0xC )
			{
				if ( OutBuffer.nErrCode_0 )
				{
					*g_offErr_1000F004 = OutBuffer.nErrCode_0;
					return 0;
				}
				else
				{
					return 1;
				}
			}
			else
			{
				*g_offErr_1000F004 = -1;
				return 0;
			}
		}
		else
		{
			*g_offErr_1000F004 = -1;
		}
	}
	else
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
	return result;
}
BOOL  CgosWDogTrigger(DWORD BytesReturned, int a2)
{
	BOOL result; 
	DEVOUT_0C OutBuffer; 
	DEVINPUT_1C InBuffer;

	if ( g_dwLibSuccess_1000FCA0 )
	{
		InBuffer.nSize_4 = BytesReturned;
		InBuffer.nParam_8 = a2;
		InBuffer.nCmd_0 = 50;
		memset(&InBuffer.nParam_c, 0, 16);
		result = DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned);
		if ( result )
		{
			if ( BytesReturned >= 0xC )
			{
				if ( OutBuffer.nErrCode_0 )
				{
					*g_offErr_1000F004 = OutBuffer.nErrCode_0;
					return 0;
				}
				else
				{
					return 1;
				}
			}
			else
			{
				*g_offErr_1000F004 = -1;
				return 0;
			}
		}
		else
		{
			*g_offErr_1000F004 = -1;
		}
	}
	else
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
	return result;
}

int  CgosWDogGetTriggerCount(DWORD BytesReturned, int a2)
{
	int result; // eax
	DEVOUT_0C OutBuffer; 
	DEVINPUT_1C InBuffer;

	if ( g_dwLibSuccess_1000FCA0 )
	{
		InBuffer.nSize_4 = BytesReturned;
		InBuffer.nParam_8 = a2;
		InBuffer.nCmd_0 = 51;
		memset(&InBuffer.nParam_c, 0, 16);
		result = DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned);
		if ( result )
		{
			if ( BytesReturned >= 0xC )
			{
				if ( OutBuffer.nErrCode_0 )
				{
					*g_offErr_1000F004 = OutBuffer.nErrCode_0;
					return 0;
				}
				else
				{
					return OutBuffer.nResult_4;
				}
			}
			else
			{
				*g_offErr_1000F004 = -1;
				return 0;
			}
		}
		else
		{
			*g_offErr_1000F004 = -1;
		}
	}
	else
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
	return result;
}

BOOL  CgosWDogSetTriggerCount(DWORD BytesReturned, int a2, int a3)
{
	BOOL result; // eax
	DEVOUT_0C OutBuffer; 
	DEVINPUT_1C InBuffer;

	if ( !g_dwLibSuccess_1000FCA0 )
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
	InBuffer.nSize_4 = BytesReturned;
	InBuffer.nParam_8 = a2;
	InBuffer.nParam_c = a3;
	InBuffer.nCmd_0 = 52;
	memset(&InBuffer.nParam_10, 0, 12);
	result = DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned);
	if ( result )
	{
		if ( BytesReturned < 0xC )
		{
			*g_offErr_1000F004 = -1;
			return 0;
		}
		if ( OutBuffer.nErrCode_0 )
		{
			*g_offErr_1000F004 = OutBuffer.nErrCode_0;
			return 0;
		}
		else
		{
			return 1;
		}
	}
	else
	{
		*g_offErr_1000F004 = -1;
	}
	return result;
}
int  CgosWDogGetConfigStruct(int a1, int a2, int *a3)
{
	return GetInfo_100010E0(8, 53, a1, a2, 0, 0, 0, 0, 0, 0, 0, 0, a3, 0);
}

//----- (10003280) --------------------------------------------------------
int  CgosWDogSetConfigStruct(int a1, int a2, int *a3)
{
	return GetInfo_100010E0(8, 54, a1, a2, 0, 0, 0, 0, 0, 0, a3, 0, 0, 0);
}

//----- (100032B0) --------------------------------------------------------
BOOL  CgosWDogSetConfig(DWORD BytesReturned, int a2, int a3, int a4, int a5)
{
	BOOL result; // eax
	DEVOUT_0C OutBuffer; 
	DEVINPUT_1C InBuffer;

	if ( g_dwLibSuccess_1000FCA0 )
	{
		InBuffer.nCmd_0 = 55;
		InBuffer.nSize_4 = BytesReturned;
		InBuffer.nParam_8 = a2;
		InBuffer.nParam_c = a3;
		InBuffer.nParam_10 = a4;
		InBuffer.nParam_14 = a5;		
		InBuffer.nParam_18 = 0;
		result = DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned);
		if ( result )
		{
			if ( BytesReturned >= 0xC )
			{
				if ( OutBuffer.nErrCode_0 )
				{
					*g_offErr_1000F004 = OutBuffer.nErrCode_0;
					return 0;
				}
				else
				{
					return 1;
				}
			}
			else
			{
				*g_offErr_1000F004 = -1;
				return 0;
			}
		}
		else
		{
			*g_offErr_1000F004 = -1;
		}
	}
	else
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
	return result;
}

BOOL  CgosWDogDisable(DWORD BytesReturned, int a2)
{
	BOOL result; 
	DEVOUT_0C OutBuffer; 
	DEVINPUT_1C InBuffer;

	if ( g_dwLibSuccess_1000FCA0 )
	{
		InBuffer.nSize_4 = BytesReturned;
		InBuffer.nParam_8 = a2;
		InBuffer.nCmd_0 = 56;
		memset(&InBuffer.nParam_c, 0, 16);
		result = DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned);
		if ( result )
		{
			if ( BytesReturned >= 0xC )
			{
				if ( OutBuffer.nErrCode_0 )
				{
					*g_offErr_1000F004 = OutBuffer.nErrCode_0;
					return 0;
				}
				else
				{
					return 1;
				}
			}
			else
			{
				*g_offErr_1000F004 = -1;
				return 0;
			}
		}
		else
		{
			*g_offErr_1000F004 = -1;
		}
	}
	else
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
	return result;
}

int  CgosWDogGetInfo(int a1, int a2, int *a3)
{
	return GetInfo_100010E0(8, 57, a1, a2, 0, 0, 0, 0, 0, 0, 0, 0, a3, 0);
}

int  CgosPerformanceGetCurrent(int a1, int a2, DWORD *a3)
{
	return MainProc_10001000(1, 58, a1, a2, 0, 0, 0, 0, a3, 0);
}
BOOL  CgosPerformanceSetCurrent(DWORD BytesReturned, int a2, int a3)
{
	BOOL result; // eax
	DEVOUT_0C OutBuffer; 
	DEVINPUT_1C InBuffer;

	if ( !g_dwLibSuccess_1000FCA0 )
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}

	InBuffer.nSize_4 = BytesReturned;
	InBuffer.nParam_8 = a2;
	InBuffer.nParam_c = a3;
	InBuffer.nCmd_0 = 59;
	memset(&InBuffer.nParam_10, 0, 12);
	result = DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned);
	if ( result )
	{
		if ( BytesReturned < 0xC )
		{
			*g_offErr_1000F004 = -1;
			return 0;
		}
		if ( OutBuffer.nErrCode_0 )
		{
			*g_offErr_1000F004 = OutBuffer.nErrCode_0;
			return 0;
		}
		else
		{
			return 1;
		}
	}
	else
	{
		*g_offErr_1000F004 = -1;
	}
	return result;
}

int  CgosPerformanceGetPolicyCaps(int a1, int a2, DWORD *a3)
{
	return MainProc_10001000(0, 60, a1, a2, 0, 0, 0, 0, a3, 0);
}

int  CgosPerformanceGetPolicy(int a1, int a2, DWORD *a3)
{
	return MainProc_10001000(0, 61, a1, a2, 0, 0, 0, 0, a3, 0);
}

//----- (100035E0) --------------------------------------------------------
BOOL  CgosPerformanceSetPolicy(DWORD BytesReturned, int a2, int a3)
{
	BOOL bRet; // eax
	DEVOUT_0C OutBuffer; 
	DEVINPUT_1C InBuffer;

	if ( !g_dwLibSuccess_1000FCA0 )
	{		
		*g_offErr_1000F004 = -1;
		return 0;
	}
	InBuffer.nSize_4 = BytesReturned;
	InBuffer.nParam_8 = a2;
	InBuffer.nParam_c = a3;
	InBuffer.nCmd_0 = 62;
	memset(&InBuffer.nParam_10, 0, 12);
	bRet = DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned);
	if ( bRet )
	{
		if ( BytesReturned < 0xC )
		{
			*g_offErr_1000F004 = -1;
			return 0;
		}
		if ( OutBuffer.nErrCode_0 )
		{
			*g_offErr_1000F004 = OutBuffer.nErrCode_0;
			return 0;
		}
		else
		{
			return 1;
		}
	}
	else
	{
		*g_offErr_1000F004 = -1;
	}
	return bRet;
}

int  CgosTemperatureCount(DWORD BytesReturned)
{
	DEVOUT_0C OutBuffer; 
	DEVINPUT_1C InBuffer;

	if ( g_dwLibSuccess_1000FCA0
		&& (InBuffer.nSize_4 = BytesReturned,
		InBuffer.nCmd_0 = 63,
		memset(&InBuffer.nParam_8, 0, 20),
		DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned)) )
	{
		if ( BytesReturned >= 0xC )
		{
			if ( OutBuffer.nErrCode_0 )
			{
				*g_offErr_1000F004 = OutBuffer.nErrCode_0;
				return 0;
			}
			else
			{
				return OutBuffer.nResult_4;
			}
		}
		else
		{
			*g_offErr_1000F004 = -1;
			return 0;
		}
	}
	else
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
}
int  CgosTemperatureGetInfo(int a1, int a2, int *a3)
{
	return GetInfo_100010E0(8, 64, a1, a2, 0, 0, 0, 0, 0, 0, 0, 0, a3, 0);
}

int  CgosTemperatureGetCurrent(int a1, int a2, DWORD *a3, DWORD *a4)
{
	return MainProc_10001000(0, 65, a1, a2, 0, 0, 0, 0, a3, a4);
}

BOOL  CgosTemperatureSetLimits(DWORD BytesReturned, int a2, int a3)
{
	BOOL result; // eax
	DEVOUT_0C OutBuffer; 
	DEVINPUT_1C InBuffer;
	if ( g_dwLibSuccess_1000FCA0 )
	{
		InBuffer.nSize_4 = BytesReturned;
		InBuffer.nParam_8 = a2;
		InBuffer.nCmd_0 = 66;
		memset(&InBuffer.nParam_c, 0, 16);
		result = DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned);
		if ( result )
		{
			if ( BytesReturned >= 0xC )
			{
				if ( OutBuffer.nErrCode_0 )
				{
					*g_offErr_1000F004 = OutBuffer.nErrCode_0;
					return 0;
				}
				else
				{
					return 1;
				}
			}
			else
			{
				*g_offErr_1000F004 = -1;
				return 0;
			}
		}
		else
		{
			*g_offErr_1000F004 = -1;
		}
	}
	else
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
	return result;
}
int  CgosFanCount(DWORD BytesReturned)
{
	DEVOUT_0C OutBuffer; 
	DEVINPUT_1C InBuffer;
	if (!g_dwLibSuccess_1000FCA0)
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
	InBuffer.nSize_4 = BytesReturned;
	InBuffer.nCmd_0 = 67;
	memset(&InBuffer.nParam_8, 0, 20);
	if (DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned))
	{
		if ( BytesReturned >= 0xC )
		{
			if ( OutBuffer.nErrCode_0 )
			{
				*g_offErr_1000F004 = OutBuffer.nErrCode_0;
				return 0;
			}
			else
			{
				return OutBuffer.nResult_4;
			}
		}
		else
		{
			*g_offErr_1000F004 = -1;
			return 0;
		}
	}
	else
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
}
int  CgosFanGetInfo(int a1, int a2, int *a3)
{
	return GetInfo_100010E0(8, 68, a1, a2, 0, 0, 0, 0, 0, 0, 0, 0, a3, 0);
}

//----- (10003990) --------------------------------------------------------
int  CgosFanGetCurrent(int a1, int a2, DWORD *a3, DWORD *a4)
{
	return MainProc_10001000(0, 69, a1, a2, 0, 0, 0, 0, a3, a4);
}

//----- (100039C0) --------------------------------------------------------
int  CgosFanSetLimits(int a1, int a2, int *a3)
{
	return GetInfo_100010E0(8, 70, a1, a2, 0, 0, 0, 0, 0, 0, a3, 0, 0, 0);
}

//----- (100039F0) --------------------------------------------------------
int  CgosVoltageCount(DWORD BytesReturned)
{
	DEVOUT_0C OutBuffer; 
	DEVINPUT_1C InBuffer;

	if (!g_dwLibSuccess_1000FCA0)
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
	InBuffer.nSize_4 = BytesReturned;
	InBuffer.nCmd_0 = 71;
	memset(&InBuffer.nParam_8, 0, 20);
	if ( DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned))
	{
		if ( BytesReturned >= 0xC )
		{
			if ( OutBuffer.nErrCode_0 )
			{
				*g_offErr_1000F004 = OutBuffer.nErrCode_0;
				return 0;
			}
			else
			{
				return OutBuffer.nResult_4;
			}
		}
		else
		{
			*g_offErr_1000F004 = -1;
			return 0;
		}
	}
	else
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
}
int  CgosVoltageGetInfo(int a1, int a2, int *a3)
{
	return GetInfo_100010E0(8, 72, a1, a2, 0, 0, 0, 0, 0, 0, 0, 0, a3, 0);
}

//----- (10003AE0) --------------------------------------------------------
int  CgosVoltageGetCurrent(int a1, int a2, DWORD *a3, DWORD *a4)
{
	return MainProc_10001000(0, 73, a1, a2, 0, 0, 0, 0, a3, a4);
}

//----- (10003B10) --------------------------------------------------------
int  CgosVoltageSetLimits(int a1, int a2, int *a3)
{
	return GetInfo_100010E0(8, 74, a1, a2, 0, 0, 0, 0, 0, 0, a3, 0, 0, 0);
}

//----- (10003B40) --------------------------------------------------------
int  CgosBoardGetBootErrorLog(int a1, int a2, DWORD *a3, int *a4, int *a5)
{
	int v5 = 0; 
	if ( a5 ) v5 = *a5;
	return GetInfo_100010E0(0, 11, a1, a2, 0, 0, 0, 0, (DWORD*)a5, a3, 0, 0, a4, v5);
}

//----- (10003B80) --------------------------------------------------------
int  CgosCgbcGetInfo(int a1, int a2, int *a3)
{
	return GetInfo_100010E0(8, 79, a1, a2, 0, 0, 0, 0, 0, 0, 0, 0, a3, 0);
}

//----- (10003BB0) --------------------------------------------------------
BOOL  CgosCgbcSetControl(DWORD BytesReturned, int a2, int a3)
{
	BOOL result; // eax
	DEVOUT_0C OutBuffer; 
	DEVINPUT_1C InBuffer;

	if ( !g_dwLibSuccess_1000FCA0 )
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
	InBuffer.nSize_4 = BytesReturned;
	InBuffer.nParam_c = a2;
	InBuffer.nParam_10 = a3;
	InBuffer.nCmd_0 = 79;
	InBuffer.nParam_8 = 0;
	InBuffer.nParam_14 = 0;
	InBuffer.nParam_18 = 0;
	result = DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned);
	if ( result )
	{
		if ( BytesReturned < 0xC )
		{
			*g_offErr_1000F004 = -1;
			return 0;
		}
		if ( OutBuffer.nErrCode_0 )
		{
			*g_offErr_1000F004 = OutBuffer.nErrCode_0;
			return 0;
		}
		else
		{
			return 1;
		}
	}
	else
	{
		*g_offErr_1000F004 = -1;
	}
	return result;
}


//----- (10003C80) --------------------------------------------------------
BOOL  CgosCgbcReadWrite(int a1, BYTE a2, BYTE *a3, int a4, int a5)
{
	if (!a3) return 0;
	if ( !MainProc_10001000(0, 80, a1, 0, (int)a2, (int)(a4 | (a5 << 8)), a5, 0, (DWORD*)&a2, 0) ) return 0;
	*a3 = a2;
	return 1;
}

//----- (10003CE0) --------------------------------------------------------
int  CgosCgbcHandleCommand(int a1, int *a2, int Size, int *a4, int a5, DWORD *a6)
{
	return GetInfo_100010E0(0, 81, a1, 0, Size, a5, 0, 0, a6, 0, a2, Size, a4, a5);
}

//----- (10003D20) --------------------------------------------------------
int  CgosCgeb(int a1, int *a2, int Size)
{
	return GetInfo_100010E0(4, 75, a1, 0, 0, 0, 0, 0, 0, 0, a2, Size, a2, Size);
}

//----- (10003D50) --------------------------------------------------------
int  CgosCgebTransAddr(DWORD BytesReturned, int a2)
{
	int result; // eax
	DEVOUT_0C OutBuffer; 
	DEVINPUT_1C InBuffer;

	if ( g_dwLibSuccess_1000FCA0 )
	{
		InBuffer.nSize_4 = BytesReturned;
		InBuffer.nParam_c = a2;
		InBuffer.nCmd_0 = 76;
		InBuffer.nParam_8 = 0;
		memset(&InBuffer.nParam_10, 0, 12);
		result = DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned);
		if ( result )
		{
			if ( BytesReturned >= 0xC )
			{
				if ( OutBuffer.nErrCode_0 )
				{
					*g_offErr_1000F004 = OutBuffer.nErrCode_0;
					return 0;
				}
				else
				{
					return OutBuffer.nResult_4;
				}
			}
			else
			{
				*g_offErr_1000F004 = -1;
				return 0;
			}
		}
		else
		{
			*g_offErr_1000F004 = -1;
		}
	}
	else
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
	return result;
}

//----- (10003E20) --------------------------------------------------------
int  CgosCgebDbgLevel(DWORD BytesReturned, int a2)
{
	int result; // eax
	DEVOUT_0C OutBuffer; 
	DEVINPUT_1C InBuffer;

	if ( g_dwLibSuccess_1000FCA0 )
	{
		InBuffer.nSize_4 = BytesReturned;
		InBuffer.nParam_c = a2;
		InBuffer.nCmd_0 = 77;
		InBuffer.nParam_8 = 0;
		memset(&InBuffer.nParam_10, 0, 12);
		result = DeviceIoControl_10004720(g_hDevice, 0xAD9C2000, &InBuffer, 0x1C, &OutBuffer, 0xC, &BytesReturned);
		if ( result )
		{
			if ( BytesReturned >= 0xC )
			{
				if ( OutBuffer.nErrCode_0 )
				{
					*g_offErr_1000F004 = OutBuffer.nErrCode_0;
					return 0;
				}
				else
				{
					return OutBuffer.nResult_4;
				}
			}
			else
			{
				*g_offErr_1000F004 = -1;
				return 0;
			}
		}
		else
		{
			*g_offErr_1000F004 = -1;
		}
	}
	else
	{
		*g_offErr_1000F004 = -1;
		return 0;
	}
	return result;
}

//----- (10003EF0) --------------------------------------------------------
int  CgosBoardOpenByNameW(WORD *wszName, DWORD *a2)
{
	char *pszName; 
	int nLen; 
	char szName[16] = {0}; 
	int i = 0;
	if ( wszName )
	{
		for ( i = 0; i < 16; i++)
		{
			if ( !wszName[i] ) break;
			szName[i] = (char)wszName[i];
		}
		pszName = szName;
	}
	else
	{
		pszName = 0;		
	}
	if ( pszName )
		nLen = strlen(szName);
	return GetInfo_100010E0(0, 4, 0, 0, 0, 0, 0, 0, a2, 0, (void*)pszName, nLen, 0, 0);
}

//----- (10003FA0) --------------------------------------------------------
int  CgosBoardGetNameW(int a1, WCHAR *a2, int a3)
{
	int result; // eax
	char szName[16]; 
	result = GetInfo_100010E0(4, 5, a1, 0, 0, 0, 0, 0, 0, 0, 0, 0, szName, 0x10);
	if ( result )
	{
		MultiByte2WCHAR_10001340(szName, a2, a3);
		return 1;
	}
	return result;
}

//----- (10004020) --------------------------------------------------------
BOOL  CgosBoardGetInfoW(int a1, CGOSINFO130* pInfoCgos)
{
	BOARDINFO_B8 boardinfo;
	if ( pInfoCgos->nLen_0 < 0x130 ) return FALSE;
	Memset_10004570((void*)&boardinfo, 0, sizeof(BOARDINFO_B8));
	boardinfo.nLen_0 = 0xB8;
	if ( !GetInfo_100010E0(8, 6, a1, 0, 0, 0, 0, 0, 0, 0, 0, 0, &boardinfo, 0) )	return 0;
	pInfoCgos->n_4 = boardinfo.n_4;
	MultiByte2WCHAR_10001340(boardinfo.szStr_18, pInfoCgos->wsz_28, 16);
	MultiByte2WCHAR_10001340(boardinfo.szStr_28, pInfoCgos->wsz_48 , 16);
	MultiByte2WCHAR_10001340(boardinfo.szStr_38, pInfoCgos->wsz_68, 16);
	memcpy(pInfoCgos->byBuf88, boardinfo.byBuf_48, 32);
	MultiByte2WCHAR_10001340(boardinfo.szStr_68, pInfoCgos->wsz_A8, 16);
	pInfoCgos->w_C8 = boardinfo.w_78;
	pInfoCgos->w_CA = boardinfo.w_7A;
	pInfoCgos->w_CC = boardinfo.w_7C;
	pInfoCgos->w_CE = boardinfo.w_7E;
	pInfoCgos->dw_D0 = boardinfo.dw_80;
	pInfoCgos->dw_D4 = boardinfo.dw_84;
	pInfoCgos->dw_D8 = boardinfo.dw_88;
	MultiByte2WCHAR_10001340(boardinfo.szStr_8C, pInfoCgos->wsz_DC, 20);
	MultiByte2WCHAR_10001340(boardinfo.szStr_A0, pInfoCgos->wsz_104, 20);
	pInfoCgos->dw_12C = boardinfo.dw_B4;
	return 1;
}

//----- (10004210) --------------------------------------------------------
BOOL  CgosIOGetNameW(int a1, int a2, WCHAR *wszName, int nLen)
{
	int result;
	char szName[16]; 
	result = GetInfo_100010E0(4, 47, a1, a2, 0, 0, 0, 0, 0, 0, 0, 0, szName, 0x10);
	if ( result )
	{
		MultiByte2WCHAR_10001340(szName, wszName, nLen);
		return 1;
	}
	return result;
}

//----- (100042B0) --------------------------------------------------------
BOOL Service_100042B0(DWORD dwType, char *szSub, LPCSTR lpServiceName, HMODULE hModule)
{
	char *pszSub;
	char* pszW; 
	SC_HANDLE schService; 
	BOOL started; 
	SC_HANDLE hSCManager; 
	char* Str; 
	SERVICE_STATUS ServiceStatus; 
	char szServiceName[63];
	CHAR szBinPath[0x104];

	pszSub = szSub;
	Str = szSub;
	started = 0;
	hSCManager = OpenSCManagerA(0, 0, SC_MANAGER_ALL_ACCESS); //0xF003F
	if (hSCManager == NULL) return 0;
	int n = 0;
	if ( !szSub )
	{
		strcpy_s(szServiceName, sizeof(szServiceName), lpServiceName);
		while(1)
		{
			if (!szServiceName[n]) break;
			n++;
		}
		strcpy_s(&szServiceName[n], 63 - n, ".sys");
		Str = szServiceName;
		pszSub = szServiceName;
	}
	szBinPath[0] = 0;
	if ( hModule )
	{
		GetModuleFileNameA(hModule, szBinPath, 0x104);
		pszW = strrchr(szBinPath, 0x5C);// "\"
		if ( pszW ) *(pszW+1) = 0;
		else	szBinPath[0] = 0;
	}
	else
	{
		GetSystemDirectoryA(szBinPath, 0x104);
		if ( szBinPath )
		{
			if (szBinPath[strlen(szBinPath)-1] == 0x5C)
			{
				szBinPath[strlen(szBinPath)-1] = 0;
			}
		}
		int n = strlen(szBinPath)-1;
		strcpy_s(&szBinPath[n], MAX_PATH -n,  "\\drivers\\");
	}
	memcpy(&szBinPath[strlen(szBinPath)-1], pszSub, strlen(pszSub)+1);
	if ( (dwType & 1) != 0 )
	{
		if ( (dwType & 2) == 0 )
		{
			char* pExistExe = strstr(Str, ".exe");
			DWORD dwServiceType = 0;
			if (pExistExe) dwServiceType = SERVICE_WIN32_OWN_PROCESS;
			else dwServiceType = SERVICE_KERNEL_DRIVER;
			DWORD dwStartType = (dwType & 4 | 8) >> 2;
			schService = CreateServiceA(hSCManager,lpServiceName,lpServiceName,SERVICE_ALL_ACCESS, dwServiceType,dwStartType,SERVICE_ERROR_NORMAL,
				szBinPath,	0,	0,	0, 0, 0);
			if ( schService )
				CloseServiceHandle(schService);
		}
		schService = OpenServiceA(hSCManager, lpServiceName, SERVICE_ALL_ACCESS);		
		if ( !schService )//10004496
		{
			CloseServiceHandle(hSCManager);
			return started;
		}
		started = StartServiceA(schService, 0, 0);
		if ( !started && GetLastError() == ERROR_SERVICE_ALREADY_RUNNING )
		{
			CloseServiceHandle(schService);
			CloseServiceHandle(hSCManager);
			return 1;
		}
	}
	else
	{
		schService = OpenServiceA(hSCManager, lpServiceName, SERVICE_ALL_ACCESS);
		if ( !schService )
		{
			CloseServiceHandle(hSCManager);
			return started;
		}
		started = ControlService(schService, SERVICE_CONTROL_STOP, &ServiceStatus);
		if ( (dwType & 2) == 0 )
			started = DeleteService(schService);
	}
	CloseServiceHandle(schService);
	CloseServiceHandle(hSCManager);
	return started;
}

//----- (10004570) --------------------------------------------------------
void * Memset_10004570(void *lpMem, char Val, int nSize)
{
	return memset(lpMem, Val, nSize);
}

//----- (10004580) --------------------------------------------------------
HANDLE CreateFileA_CGOS_10004580()
{
	return CreateFileA("\\\\.\\cgos", GENERIC_WRITE, FILE_SHARE_WRITE, 0, OPEN_EXISTING, 0, 0);
}

//----- (100045A0) --------------------------------------------------------
BOOL LibInstall_100045A0(int nType)
{
	OSVERSIONINFOA VersionInformation; 
	CHAR FileName[44]; 
	VersionInformation.dwOSVersionInfoSize = 0x94;
	if ( !GetVersionExA(&VersionInformation) )
		return 0;
	if ( VersionInformation.dwPlatformId == 2 )
		return Service_100042B0(nType, "cgos.sys", "Cgos", g_hModule);
	if ( VersionInformation.dwPlatformId != 1 )
		return 0;
	strcpy_s(FileName, 44, "HKLM\\System\\CurrentControlSet\\Services\\Cgos");
	if ( VersionInformation.dwMajorVersion == 4 && !VersionInformation.dwMinorVersion )
		return 0;
	if ( nType )
	{
		SetRegKey_100049A0(AppName, "Type", 1, FileName);
		SetRegKey_100049A0(AppName, "Start", 2, FileName);
		SetRegKey_100049A0(AppName, "ErrorControl", 1, FileName);
		SetRegKey_10004890(AppName, "DisplayName", "Cgos", FileName);
	}
	else 
	{
		RegDeleteKeyA(HKEY_LOCAL_MACHINE, &FileName[5]);
	}
	return 1;
}

//----- (10004720) --------------------------------------------------------
BOOL DeviceIoControl_10004720(
						  HANDLE hDevice,
						  DWORD dwIoControlCode,
						  LPVOID lpInBuffer,
						  DWORD nInBufferSize,
						  LPVOID lpOutBuffer,
						  DWORD nOutBufferSize,
						  LPDWORD lpBytesReturned)
{
	return DeviceIoControl(
		hDevice,
		dwIoControlCode,
		lpInBuffer,
		nInBufferSize,
		lpOutBuffer,
		nOutBufferSize,
		lpBytesReturned,
		0);
}

//----- (10004750) --------------------------------------------------------
void CloseHandle_10004750(HANDLE hObject)
{
	CloseHandle(hObject);
}

//----- (10004760) --------------------------------------------------------
HKEY GetHKEYbyNameA_10004760(char* szName)
{
	int nSubStr; // ecx
	HKEY hkey; // eax

	if ( !szName || szName[0] != 'H' || szName[1] != 'K' || szName[4] != '\\' || strlen(szName) < 5  )
	{
		return 0;
	}
	nSubStr = szName[3] + (szName[2] << 8);
	hkey = HKEY_CLASSES_ROOT;
	if(nSubStr == 0x4355) hkey = HKEY_CURRENT_USER;
	else if(nSubStr == 0x4C4D) hkey = HKEY_LOCAL_MACHINE;
	else if(nSubStr == 0x5553) hkey = HKEY_USERS;
	else if(nSubStr == 0x4343) hkey = HKEY_CURRENT_CONFIG;
	return hkey;
}

//----- (100047F0) --------------------------------------------------------
void MakeRegPath_100047F0(char* szIn1, char* szIn2,char* szout)
{
	int nlen; // eax

	strcpy(szout, &szIn2[5]);// strcpy_s(a3, &a2[5], strlen(a2)-5)));
	if ( szIn1 && szIn1[0] )
	{
		if ( szout[0] )
		{
			if ( szout[strlen(szout) - 1] != 0x5C )
			{
				szout[strlen(szout) - 1] = 0x5C;
				szout[strlen(szout) - 1] = 0x0;
			}				
		}
		nlen = strlen(szIn1) + 1;
		memcpy(&szout[strlen(szout)], szIn1, nlen);
	}	
}

//----- (10004890) --------------------------------------------------------
BOOL SetRegKey_10004890(char *lpAppName, char *lpKeyName, char* lpString, char* lpFileName)
{
	BOOL bRet; 
	HKEY hkey; 
	LSTATUS status; 
	DWORD dwDisposition; 
	CHAR SubKey[512]; 


	bRet = 0;
	hkey = GetHKEYbyNameA_10004760(lpFileName);
	if ( !hkey )
		return WritePrivateProfileStringA(lpAppName, lpKeyName, lpString, lpFileName);
	MakeRegPath_100047F0(lpAppName, lpFileName, SubKey);
	if ( !RegCreateKeyExA(hkey, SubKey, 0, 0, 0, KEY_ALL_ACCESS, 0, (PHKEY)&lpAppName, &dwDisposition) )
	{
		if ( lpString )
			status = RegSetValueExA((HKEY)lpAppName, lpKeyName, 0, 1, (const BYTE*)lpString, strlen(lpString) + 1);
		else
			status = RegDeleteValueA((HKEY)lpAppName, lpKeyName);
		if (!status) bRet = TRUE;
		RegCloseKey((HKEY)lpAppName);
	}
	return bRet;
}

//----- (100049A0) --------------------------------------------------------
BOOL  SetRegKey_100049A0(char* lpAppName, char* lpValName, int Data, char* lpFileName)
{
	char *pfilename; 
	BOOL bRet; 
	HKEY hkey; 
	HKEY phkResult; 
	char* lpKeyName; 
	DWORD dwDisposition; 
	CHAR SubKey[512]; 

	pfilename = lpFileName;
	lpKeyName = lpValName;
	bRet = 0;
	hkey = GetHKEYbyNameA_10004760(lpFileName);
	if ( hkey )
	{
		MakeRegPath_100047F0(lpAppName, pfilename, SubKey);
		if ( !RegCreateKeyExA(hkey, SubKey, 0, 0, 0, 0xF003F, 0, &phkResult, &dwDisposition) )
		{			
			bRet = RegSetValueExA(phkResult, lpKeyName, 0, 4, (BYTE*)&Data, 4) == 0;
			RegCloseKey(phkResult);
		}
		return bRet;
	}
	else
	{
		wsprintfA(g_String, "%i", Data);
		return WritePrivateProfileStringA(lpAppName, lpKeyName, g_String, pfilename);
	}
}
