#pragma  once

extern HMODULE g_hModule;

typedef struct tagDEVINPUT_1C 
{
	int nCmd_0;
	int nSize_4;
	int nParam_8;
	int nParam_c;
	int nParam_10;
	int nParam_14;
	int nParam_18;
} DEVINPUT_1C, *LPDEVINPUT_1C;
typedef struct tagDEVOUT_0C 
{
	int nErrCode_0;
	int nResult_4;
	int nAddInfo_8;

} DEVOUT_0C, *LPDEVOUT_0C;

typedef struct tagCGOSINFO130{
	int nLen_0;
	int n_4;
	BYTE lpBy_8[0x20];
	WCHAR wsz_28[0x10];
	WCHAR wsz_48[0x10];
	WCHAR wsz_68[0x10];
	BYTE byBuf88[32];//0x88
	WCHAR wsz_A8[0x10];
	WORD w_C8;
	WORD w_CA;
	WORD w_CC;
	WORD w_CE;
	DWORD dw_D0;
	DWORD dw_D4;
	DWORD dw_D8;
	WCHAR wsz_DC[0x14];
	WCHAR wsz_104[0x14];
	DWORD dw_12C;
}CGOSINFO130, *LPCGOSINFO130;

typedef struct tagBOARDINFO_B8
{
	int nLen_0;
	int n_4;
	char szStr_18[0x10];
	char szStr_28[0x10];
	char szStr_38[0x10];
	BYTE byBuf_48[32];
	char szStr_68[0x10];
	WORD w_78;
	WORD w_7A;
	WORD w_7C;
	WORD w_7E;
	DWORD dw_80;
	DWORD dw_84;
	DWORD dw_88;
	char szStr_8C[0x14];
	char szStr_A0[0x14];
	DWORD dw_B4;
}BOARDINFO_B8, *LPBOARDINFO_B8;