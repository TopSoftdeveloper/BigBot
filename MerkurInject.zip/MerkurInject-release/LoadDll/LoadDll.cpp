// LoadDll.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "LoadDll.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// The one and only application object
typedef UINT (__stdcall* LPEApiLibInitialize)( VOID );
typedef UINT (__stdcall* LPSub_105730)( VOID );
typedef HANDLE (__stdcall* LPH_V)(VOID);
CWinApp theApp;

using namespace std;
int retun_func()
{
	return 4;
}
int asm_test()
{
	__asm{
		pushad
		call retun_func
		neg eax
		sbb eax, eax
		not eax
		popad
	}
	__asm{
		pushad
		call retun_func
		cmp eax, 5
		sbb eax, eax
		sbb eax, 0FFFFFFFFh
		mov edx, eax
		popad
	}// if (eax >=5) eax = 1 else eax = 0;
	return 1;
}
int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;

	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		// TODO: change error code to suit your needs
		_tprintf(_T("Fatal Error: MFC initialization failed\n"));
		nRetCode = 1;
	}
	else
	{
		// TODO: code your application's behavior here.
		asm_test();
		TCHAR tszModuleName[MAX_PATH] = _T("");
		GetModuleFileName(NULL, tszModuleName, MAX_PATH);
		TCHAR* p = _tcsrchr(tszModuleName, '\\');
		*p = NULL;
		SetCurrentDirectory(tszModuleName);
#if 0
		_tcscat_s(tszModuleName, _T("\\eapi.dll"));
		
		HMODULE hEapiDll = LoadLibrary(tszModuleName);
#endif
		HMODULE hAdpDll = LoadLibrary(_T("ADPInterface.dll"));
		//LPSub_105730 sub_105730 = (LPSub_105730)((DWORD)hEapiDll + 0x5730);
		//sub_105730();
		LPH_V pFnGetADPInterfaceEX = (LPH_V)GetProcAddress(hAdpDll, "GetADPInterfaceEX");
		pFnGetADPInterfaceEX();
	}

	return nRetCode;
}
