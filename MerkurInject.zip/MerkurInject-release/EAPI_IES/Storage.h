﻿#pragma once
class CStorage
{
public:
	CStorage();
	~CStorage();

public:

	//virtual void sub_100052B0();파괴자

};

