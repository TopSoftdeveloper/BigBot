#include "stdafx.h"
#include "SmbusInrerface.h"


CSmbusInrerface::CSmbusInrerface()
{
}


CSmbusInrerface::~CSmbusInrerface()
{
}


void CSmbusInrerface::sub_10006950()
{
}
