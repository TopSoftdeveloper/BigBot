#pragma once
#include "MultiSensor.h"

class CAmdBrazos : public CMultiSensor
{
public:
	CAmdBrazos();
	~CAmdBrazos();

public:

	virtual void sub_1000A480();
	virtual void sub_100052A0();
	virtual DWORD sub_10009DD0();
	virtual DWORD sub_10006E70(DWORD i);
	virtual void sub_10006EB0();
	virtual void sub_10006F00();
	virtual void sub_10006F60();
	virtual void sub_10006FB0();
	virtual void sub_10007000();
	virtual void sub_10007050();
	virtual void sub_100086C0();
	virtual void sub_10009E40();
	virtual DWORD sub_10009DE0();
	virtual void sub_10009EC0();
	virtual void sub_100086D0();
	virtual void sub_10009EF0();
	virtual void sub_10009E80();
	virtual void sub_10009F10();
	virtual DWORD sub_10009DF0();
};

