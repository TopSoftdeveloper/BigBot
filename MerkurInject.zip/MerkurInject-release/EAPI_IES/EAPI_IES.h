
#ifdef EAPI_IES_EXPORTS
#define EAPI_IES_API __declspec(dllexport)
#else
#define EAPI_IES_API __declspec(dllimport)
#endif

EAPI_IES_API int	EApiBoardGetStringA(int nCode, LPVOID lpOutBuffer, DWORD nParam1);				
EAPI_IES_API int	EApiBoardGetValue(DWORD dwVal, DWORD *pdwBuff);				
EAPI_IES_API int	EApiGPIOGetDirection(DWORD dwVal1, DWORD dwVal2, DWORD dwVal3);			
EAPI_IES_API int	EApiGPIOGetDirectionCaps(DWORD dwArg1, DWORD *pdwBuff1, DWORD *pdwBuff2);	
EAPI_IES_API int	EApiGPIOGetLevel(DWORD dwVal1, DWORD dwVal2, DWORD dwVal3);				
EAPI_IES_API int	EApiGPIOSetDirection(DWORD dwVal1, DWORD dwVal2, PDWORD pdwVal3);			
EAPI_IES_API int	EApiGPIOSetLevel(DWORD dwVal1, DWORD dwVal2, PDWORD pdwVal3);				
EAPI_IES_API int	EApiI2CGetBusCap(DWORD dwVal, DWORD *dwBuff);				
EAPI_IES_API int	EApiI2CProbeDevice(DWORD dwVal1, WORD dwVal2);				
EAPI_IES_API int	EApiI2CReadTransfer(DWORD dwFlag, SHORT wVal2, int nVal3, void *lpBuff, DWORD dwVal5, DWORD dwVal6);				
EAPI_IES_API int	EApiI2CWriteReadRaw(DWORD dwVal1,BYTE bVal2, void *lpVal3, DWORD dwVal4, void *lpVal5, DWORD dwVal6, DWORD dwVal7);				
EAPI_IES_API int	EApiI2CWriteTransfer(int nVal1, int nVal2, int nVal3, void *Source, int nVal4);			
EAPI_IES_API int	EApiLibInitialize(void);				
EAPI_IES_API DWORD	EApiLibUnInitialize(void);				
EAPI_IES_API int	EApiStorageAreaRead(DWORD fFlag, DWORD dwVal2, void *lpBuff3, DWORD dwVal4, DWORD dwVal5);				
EAPI_IES_API int	EApiStorageAreaWrite(DWORD dwVal1, DWORD dwVal2, BYTE *pbBuff3, SIZE_T nSize);			
EAPI_IES_API int	EApiStorageCap(DWORD dwArg1, DWORD *pdwBuff1, DWORD *pdwBuff2);					
EAPI_IES_API int	EApiVgaGetBacklightBrightness(DWORD dwFlag, DWORD *pdwBuff);	
EAPI_IES_API int	EApiVgaGetBacklightEnable(DWORD dwArg1, DWORD *pdwBuff);		
EAPI_IES_API int	EApiVgaSetBacklightBrightness(DWORD dwVal1, DWORD dwVal2);	
EAPI_IES_API int	EApiVgaSetBacklightEnable(DWORD dwArg1, DWORD dwArg2);	
EAPI_IES_API int	EApiWDogGetCap(DWORD *pdwBuff1, DWORD *pdwBuff2, DWORD *pdwBuff3);					
EAPI_IES_API int	EApiWDogStart(DWORD dwArg1, DWORD dwArg2, DWORD dwArg3);					
EAPI_IES_API int	EApiWDogStop(void);					
EAPI_IES_API DWORD	EApiWDogTrigger(void);					
EAPI_IES_API int	KemEApiBeep(DWORD InBuffer, DWORD dwMilliseconds);						
EAPI_IES_API int	KemEApiGPIOCancelEvent(void);			
EAPI_IES_API int	KemEApiGPIOGetCaps(DWORD dwArg1, DWORD *pdwBuff);				
EAPI_IES_API int	KemEApiGPIOGetEvent(DWORD dwArg1, DWORD dwArg2, BYTE *pbDest);				
EAPI_IES_API int	KemEApiGPIOSetEvent(DWORD dwArg1, int dwArg2, DWORD *pdwBuff);				
EAPI_IES_API int	KemEApiGPIOWaitOnEvent(DWORD dwArg1, DWORD dwArg2, DWORD dwArg3);			
EAPI_IES_API int	KemEApiMuxCaps(PDWORD  pdwOutBuffer);					
EAPI_IES_API int	KemEApiMuxEnable(DWORD InBuffer, DWORD dwFlag);				
EAPI_IES_API int	KemEApiMuxGetState(LPVOID lpOutBuffer);				
EAPI_IES_API int	KemEApiPwmGetCaps(DWORD dwArg1, DWORD* pdwBuff);				
EAPI_IES_API int	KemEApiPwmSetDuty(int dwArg1, DWORD dwInBuffer);				
EAPI_IES_API int	KemEApiPwmSetFrequency(DWORD dwFlag, DWORD dwInBuffer);			
EAPI_IES_API int	KemEApiPwmSetPolarity(DWORD dwArg1, DWORD dwArg2);			
EAPI_IES_API int	KemEApiSmbusQuickRead(DWORD dwOpt);			
EAPI_IES_API int	KemEApiSmbusQuickWrite(DWORD dwArg1);			
EAPI_IES_API int	KemEApiSmbusReadByte(DWORD dwArg1, DWORD dwArg2, DWORD dwArg3);			
EAPI_IES_API int	KemEApiSmbusReadWord(DWORD dwArg1, DWORD dwArg2, DWORD dwArg3);			
EAPI_IES_API int	KemEApiSmbusReceiveByte(DWORD dwArg1, DWORD dwArg2);			
EAPI_IES_API int	KemEApiSmbusSendByte(int dwArg2, char dwArg3);			
EAPI_IES_API int	KemEApiSmbusWriteByte(DWORD dwArg1, DWORD dwArg2, BYTE bArg3);			
EAPI_IES_API int	KemEApiSmbusWriteWord(int dwArg1, int dwArg2, int dwArg3, int dwArg4, WORD wArg5);			

