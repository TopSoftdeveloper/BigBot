#include "stdafx.h"
#include "AmdBrazos.h"


CAmdBrazos::CAmdBrazos()
{
}


CAmdBrazos::~CAmdBrazos()
{
}


void CAmdBrazos::sub_1000A480()
{
}


void CAmdBrazos::sub_100052A0()
{
}
DWORD CAmdBrazos::sub_10009DD0()
{
	return 4;
}

DWORD CAmdBrazos::sub_10006E70(DWORD i)
{
	return 1;
}


void CAmdBrazos::sub_10006EB0()
{
}


void CAmdBrazos::sub_10006F00()
{
}


void CAmdBrazos::sub_10006F60()
{
}


void CAmdBrazos::sub_10006FB0()
{
}


void CAmdBrazos::sub_10007000()
{
}


void CAmdBrazos::sub_10007050()
{
}


void CAmdBrazos::sub_100086C0()
{
}


void CAmdBrazos::sub_10009E40()
{
}


DWORD CAmdBrazos::sub_10009DE0()
{
	return 1;
}


void CAmdBrazos::sub_10009EC0()
{
}


void CAmdBrazos::sub_100086D0()
{
}


void CAmdBrazos::sub_10009EF0()
{
}


void CAmdBrazos::sub_10009E80()
{
}


void CAmdBrazos::sub_10009F10()
{
}


DWORD CAmdBrazos::sub_10009DF0()
{
	return 1;
}
