#include "stdafx.h"
#include "Adt74x.h"


CAdt74x::CAdt74x()
{
}


CAdt74x::~CAdt74x()
{
}
