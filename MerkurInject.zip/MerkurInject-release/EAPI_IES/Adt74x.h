#pragma once
#include "MultiSensor.h"

class CAdt74x :  public CMultiSensor
{
public:
	CAdt74x();
	~CAdt74x();
};

