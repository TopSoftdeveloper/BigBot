#pragma once
class CSmbusInrerface
{
public:
	CSmbusInrerface();
	~CSmbusInrerface();

public:


	virtual void sub_10006950();
};

