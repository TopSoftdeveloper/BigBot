#pragma once
#include "Storage.h"

class CCmos : public CStorage
{
public:
	CCmos();
	virtual ~CCmos();//sub_100052B0


public:
	virtual BOOL sub_100052A0();
	virtual BOOL sub_10005F90(BYTE byVal, BYTE* pbyBuf, int nCnt);
	virtual BOOL sub_10005FF0(BYTE byVal, BYTE* pbyBuf, int nCnt);
	virtual DWORD sub_10009DE0();
	virtual BOOL sub_10006050(DWORD* pdwVal1, DWORD* pdwVal2);
};


