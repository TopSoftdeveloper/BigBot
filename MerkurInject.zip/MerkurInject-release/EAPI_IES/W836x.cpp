#include "stdafx.h"
#include "W836x.h"
#include "EAPI_IES_global.h"

CW836x::CW836x()
{
}


CW836x::~CW836x()
{
}


BOOL CW836x::sub_1000B2B0(DWORD bySrc, BYTE byVal, BYTE *pDest)
{	
	BOOL bRet; 	
	DWORD dwOut; 

	bRet = 0;
	bySrc = (BYTE)bySrc;
	dwOut = 0;
	EnterCriticalSection(&m_cs40);	
	if ( m_pWPARAM64 )
	{
		m_pWPARAM64->pAddHeaderInfo_8 = (DWORD)m_pWPARAM64 + 0x20;
		m_pWPARAM64->dwCode_10 = 0x43696541;
		m_pWPARAM64->dwUnk_18 = 0;
		m_pWPARAM64->dwUnk_1C = 0;

	}
	sub_100072A0(4, (BYTE *)&bySrc, (SMBUSPARAM*)m_pWPARAM64, 0);
	bySrc = byVal;
	sub_100072A0(4, (BYTE *)&bySrc, (SMBUSPARAM*)m_pWPARAM64, 0);
	if ( !sub_10007460((SMBUSPARAM*)m_pWPARAM64, (DWORD)m_pdw60, m_dw58, &dwOut)
		&& dwOut == 1 )
	{
		sub_100073E0(&bySrc, (SMBUSPARAM*)m_pWPARAM64);
		*pDest = (BYTE)bySrc;
		bRet = 1;
	}
	LeaveCriticalSection(&m_cs40);
	return bRet;
}
BOOL CW836x::sub_1000B370(DWORD bySrc, BYTE byVal,BYTE byParam)
{	
	BOOL bRet; 	
	DWORD dwOut; 

	bRet = 0;
	bySrc = (BYTE)bySrc;
	dwOut = 0;
	EnterCriticalSection(&m_cs40);	
	if ( m_pWPARAM64 )
	{
		m_pWPARAM64->pAddHeaderInfo_8 = (DWORD)m_pWPARAM64 + 0x20;
		m_pWPARAM64->dwCode_10 = 0x43696541;
		m_pWPARAM64->dwUnk_18 = 0;
		m_pWPARAM64->dwUnk_1C = 0;

	}
	sub_100072A0(4, (BYTE *)&bySrc, (SMBUSPARAM*)m_pWPARAM64, 0);
	bySrc = byVal;
	sub_100072A0(4, (BYTE *)&bySrc, (SMBUSPARAM*)m_pWPARAM64, 0);
	bySrc = byParam;
	sub_100072A0(4, (BYTE *)&bySrc, (SMBUSPARAM*)m_pWPARAM64, 0);
	if ( !sub_10007460((SMBUSPARAM*)m_pWPARAM64, (DWORD)m_pdw60, m_dw58, 0) )
	{		
		bRet = 1;
	}
	LeaveCriticalSection(&m_cs40);
	return bRet;
}

BOOL CW836x::sub_1000B150()
{
	WORD wAllocSize; 
	DWORD *pAlloc; 
	
	BOOL bRet; 
	BYTE byVar; 
	DWORD dwBYTEsReturn; 

	dwBYTEsReturn = 0;
	if ( sub_10003430(0, 1, 0, (PWORD)&dwBYTEsReturn) != 0x7A )
		return 0;
	wAllocSize = (WORD)dwBYTEsReturn;
	pAlloc = (DWORD *)HeapAlloc(g_hHeap_1001ADE8, 8, (WORD)dwBYTEsReturn);
	if ( !pAlloc )
		return 0;
	sub_10003430(pAlloc, 1, wAllocSize, 0);

	m_pdw60 = (DWORD*)sub_100070F0((WCHAR *)*pAlloc);
	if ( !m_pdw60 )
	{
		HeapFree(g_hHeap_1001ADE8, 0, pAlloc);
		return 0;
	}
	m_pWPARAM64 = (W836XPARAM_6C*)HeapAlloc(g_hHeap_1001ADE8, 8, 0x6C);
	if ( !m_pWPARAM64 )
	{
		HeapFree(g_hHeap_1001ADE8, 0, pAlloc);
		return 0;
	}
	if ( m_pWPARAM64 )
	{
		m_pWPARAM64->wHeaderlen_0 = 0x4C;
		m_pWPARAM64->wBodyLen_2 = 0x20;
		m_pWPARAM64->pAddrBody_4 = (DWORD)m_pWPARAM64 + 0x4C;
		m_pWPARAM64->pAddHeaderInfo_8 = (DWORD)m_pWPARAM64 + 0x20;
		m_pWPARAM64->dwCode_10 = 0x43696541;
		m_pWPARAM64->dwUnk_18 = 0;
		m_pWPARAM64->dwUnk_1C = 0;
		m_pWPARAM64->dwPrefixBody_4C = 0x426F6541;
	}
	m_dw58 = pAlloc[1];
	m_dw5C = pAlloc[2];
	byVar = 0;
	sub_1000B2B0(0, 0x4F, &byVar);
	m_w20 = byVar;
	sub_1000B2B0(0x80, 0x4F, &byVar);
	m_w20  += byVar << 8;

	if ( (WORD)m_w20 == 0x5CA3 )
	{		
		m_lpFn10 = (CW386_LPFnB_DBP)(&CW836x::sub_1000B2B0);
		m_dw14 = 0;
		m_lpFn18 = (CW386_LPFnB_DBB)&CW836x::sub_1000B370;
		m_dw1C = 0;
		bRet = 1;
	}
	else
	{
		bRet = 0;
	}
	HeapFree(g_hHeap_1001ADE8, 0, pAlloc);
	return bRet;
}
void CW836x::sub_1000B070(DWORD OutBuffer, BYTE byParam, BYTE *pDest)
{
	EnterCriticalSection(&m_cs40);
	sub_10003040((BYTE)m_w3A, 78);
	sub_10003040((BYTE)m_w3A + 1, (BYTE)OutBuffer);
	sub_10003040((BYTE)m_w3A, byParam);
	OutBuffer = -1;
	sub_100030C0((WORD)m_w3A + 1, (PBYTE)&OutBuffer);
	*pDest = (BYTE)OutBuffer;
	LeaveCriticalSection(&m_cs40);	
}
void CW836x::sub_1000B0F0(BYTE byArg1, BYTE byArg2, BYTE byArg3)
{
	EnterCriticalSection(&m_cs40);
	sub_10003040((BYTE)m_w3A, 78);
	sub_10003040((BYTE)m_w3A + 1, byArg1);
	sub_10003040((BYTE)m_w3A, byArg2);
	sub_100030C0((BYTE)m_w3A + 1, &byArg3);
	LeaveCriticalSection(&m_cs40);	
}
WORD CW836x::sub_10008630()
{
	DWORD OutBuffer; 
	WORD wRet;
	BYTE byRet;

	sub_10003040((BYTE)m_w08, 0x60);	
	OutBuffer = -1;
	sub_100030C0((BYTE)m_w08 + 1, (PBYTE)&OutBuffer);
	byRet = (BYTE)OutBuffer;
	sub_10003040((BYTE)m_w08, 0x61);
	OutBuffer = -1;
	sub_100030C0(m_w08 + 1, (PBYTE)&OutBuffer);
	wRet = (byRet << 8) + (BYTE)OutBuffer;
	return wRet;
}

BOOL CW836x::sub_1000AF70()
{	
	WORD wFirst; 
	WORD wNext; 
	BYTE byVal; 	
	sub_10003040((BYTE)m_w08, 0x87);
	sub_10003040((BYTE)m_w08, 0x87);
	sub_10003040((BYTE)m_w08, 7);
	sub_10003040((BYTE)m_w08 + 1, 11);
	wFirst = sub_10008630();
	Sleep(0x64);
	wNext = sub_10008630();
	sub_10003040((BYTE)m_w08, 0xAA);
	if ( wFirst != wNext )
		return 0;
	if ( !wFirst )
		return 0;
	byVal = 0;
	m_w3A = wFirst + 5;
	sub_1000B070( 0, 0x4F, &byVal);
	m_w20 = byVal;
	Sleep(0xA);
	sub_1000B070(0x80, 0x4F, &byVal);
	m_w20 += byVal << 8;
	if ( m_w20 != 0x5CA3 )
		return 0;
	m_lpFn10 = (CW386_LPFnB_DBP)(&CW836x::sub_1000B070);
	m_dw14 = 0;
	m_lpFn18 = (CW386_LPFnB_DBB)&CW836x::sub_1000B0F0;
	m_dw1C = 0;
	return 1;
}
BYTE CW836x::sub_1000AE80()
{
	PBYTE pbyBuf; // edi
	BYTE byRet; // al
	//PBYTE *pbyBuf2; // ebp
	PBYTE pbyBuf2;
	BYTE byParam1; // cl
	BYTE byCnt; // bl
	BYTE bytmp;
	BYTE byParam; 

	pbyBuf = m_pby2C;
	pbyBuf2 = pbyBuf + 12 * m_by30;
	byParam1 = -1;
	bytmp = 0;
	byCnt = 1;
	for ( m_w2A = 0; pbyBuf < pbyBuf2; byCnt *= 2 )
	{
		byRet = pbyBuf[2];
		if ( byRet )
		{
			if ( byRet != byParam1 )
			{				
				byParam = pbyBuf[2];
				//LPFnU_DDP pFnProc = (LPFnU_DDP)m_lpFn10;
				//byRet = *(CW386_LPFnB_DBP)m_lpFn10((DWORD)pbyBuf[3], byParam, &bytmp);
				byRet = (this->*m_lpFn10)((DWORD)pbyBuf[3], byParam, &bytmp);
				//byRet = pFnProc((DWORD)pbyBuf[3],	byParam, &bytmp);
				byParam1 = byParam;
			}
			if ( (bytmp & pbyBuf[4]) != 0 )
			{
				byRet = byCnt;
				m_w2A |= byCnt;
			}
		}
		else
		{
			m_w2A |= byCnt;
		}
		pbyBuf += 12;
	}
	return byRet;
}
BYTE CW836x::sub_1000ADF0()
{
	BYTE bRet; 
	BYTE bytmp; 
	BYTE bycn; 
	BYTE byVal;

	bRet = 0;
	bytmp = 0xFF;
	byVal = 0;
	bycn = 1;
	m_w32 = 0;
	int n = 0;
	for (n = 0; n < 14*m_by38; n+=14)
	{
		if (m_pby34[n+2])
		{
			if (m_pby34[n+2] != bytmp)
			{
				(this->*m_lpFn10)((DWORD)m_pby34[n+3],m_pby34[n+2],&byVal);
				bytmp = m_pby34[n+2];
			}
			bRet = byVal;
			if ( (byVal & m_pby34[n+4]) != 0 )
				m_w32 |= bycn;
		}
		else
		{
			bRet = bycn;
			m_w32 |= bycn;
		}
		bycn *= 2;
	}	
	return bRet;
}
BYTE CW836x::sub_1000AF00()
{
	BYTE byRet; 
	BYTE bytmp; 
	BYTE byVal; 
	int i; 

	bytmp = 0xFF;
	byVal = 0;
	BYTE bycn = 1;
	for (i = 0; i < 10*m_by28; i += 10)
	{
		byRet = m_pby24[i+2];
		if (byRet != bytmp)
		{
			bytmp = m_pby24[i+2];
			byRet = (this->*m_lpFn10)(0, bytmp, &byVal);
		}
		if ((byVal & m_pby24[i+3]) != 0)
		{
			m_w22 |= bycn;
		}
		bycn *= 2;
	}
	return byRet;
}
DWORD CW836x::sub_1000A6B0()
{
	DWORD dwRet;
	dwRet = 0;
	if ( !m_dw3C ) return 0;

	dwRet = sub_1000B150();
	if ( !dwRet )
		dwRet = sub_1000AF70(/*(int)this*/);
	if ( dwRet == 1 )
	{
		sub_1000AE80();
		sub_1000ADF0();
		sub_1000AF00();
	}
	return dwRet;
}



DWORD CW836x::sub_10006E70(DWORD dwArg)
{
	DWORD result; 
	result = 0;
	switch ( dwArg )
	{
	case 0:
		return sub_1000A490();
	case 1:
		return sub_1000A4B0();
	case 2:
		return sub_1000A4A0();
	}
	return result;
}


DWORD CW836x::sub_10006EB0(DWORD dwArg1, DWORD dwArg2, PDWORD pdwArg3)
{
	int result; 
	result = 0;
	switch ( dwArg1 )
	{
	case 0:
		return sub_1000A730((WORD)dwArg2, pdwArg3);//38
	case 1:
		return sub_1000AB50((WORD)dwArg2, pdwArg3);//3c
	case 2:
		return sub_1000A7E0((WORD)dwArg2, pdwArg3);//40
	}
	return result;
}


DWORD CW836x::sub_10006F00(DWORD dwArg1, DWORD dwArg2, PDWORD pdwArg3, PDWORD pdwArg4)
{
	int result; 

	result = 0;
	switch ( dwArg1 )
	{
	case 0:
		return sub_1000A860((BYTE)dwArg2, pdwArg3, pdwArg4);
	case 1:
		return sub_1000ABC0((WORD)dwArg2, pdwArg3, pdwArg4);
	case 2:
		return sub_1000A8A0((WORD)dwArg2, pdwArg3, pdwArg4);
	}
	return result;
}


DWORD CW836x::sub_10006F60(DWORD dwArg1, DWORD dwArg2, PDWORD pdwArg3)
{
	int result; 
	result = 0;
	switch ( dwArg1 )
	{
	case 0:
		return sub_1000A900((WORD)dwArg2, pdwArg3);
	case 1:
		return sub_1000AC20((WORD)dwArg2, pdwArg3);
	case 2:
		return sub_10009DE0(dwArg2, pdwArg3);
	}
	return result;
}


DWORD CW836x::sub_10006FB0(DWORD dwFlag, DWORD dwArg2, PDWORD pdwArg3)
{
	switch ( dwFlag )
	{
	case 0:
		
		return sub_1000A940((WORD)dwArg2, pdwArg3);
	case 1:
		
		return sub_1000AC60((WORD)dwArg2, pdwArg3);
	case 2:
		
		return sub_10009DE0(dwArg2, pdwArg3);
	}
	return 0;
}


DWORD CW836x::sub_10007000(DWORD dwFlag, DWORD dwArg2, PDWORD pdwArg3)
{
	switch ( dwFlag )
	{
	case 0:
		return sub_1000A9A0((WORD)dwArg2, pdwArg3);//68
	case 1:
		return sub_1000ACE0((WORD)dwArg2, pdwArg3);//6c
	case 2:
		return sub_10009DE0(dwArg2, pdwArg3);//70
	}
	return 0;
}


DWORD CW836x::sub_10007050(DWORD dwArg1, DWORD dwArg2, PDWORD pdwArg3)
{
	switch ( dwArg1 )
	{
	case 0:
		return sub_1000AA00((WORD)dwArg2, (PWORD)pdwArg3); //74
	case 1:
		return sub_1000AD60((WORD)dwArg2, (PDWORD)pdwArg3);//78
	case 2:
		return sub_1000AA90((WORD)dwArg2, pdwArg3);//78
	}
	return 0;
}


BYTE CW836x::sub_1000A490()
{
	return m_by30;
}


BYTE CW836x::sub_1000A4B0()
{
	return m_by38;
}


BYTE CW836x::sub_1000A4A0()
{
	return m_by28;
}


DWORD CW836x::sub_1000A730(WORD wArg1, DWORD *pdwArg2)
{
	int result; 
	int dwTmp1; 
	BYTE byTmp2; 
	
	result = 0;
	byTmp2 = 0;
	if ( wArg1 < m_by30 )
	{
		(this->*m_lpFn10)(m_pby2C[0xC*wArg1+1], m_pby2C[0xC*wArg1], &byTmp2);
		dwTmp1 = 1000 * byTmp2;
		if (m_pby2C[0xC*wArg1 + 1])
		{
			(this->*m_lpFn10)(m_pby2C[0xC*wArg1 + 1], m_pby2C[0xC*wArg1]+1, &byTmp2);
			dwTmp1 += (byTmp2 & 0x80) != 0 ? 0x1F4 : 0;
		}
		*pdwArg2 = dwTmp1;
		return 1;
	}
	return result;
}


DWORD CW836x::sub_1000AB50(WORD dwArg1, DWORD *pdwArg2)
{
	DWORD result; 
	BYTE *pbyTmp1; 
	BYTE byTmp2; 
	
	result = 0;
	byTmp2 = 0;
	if ( dwArg1 < m_by38 )
	{
		pbyTmp1 = &m_pby34[14 * dwArg1];
		(this->*m_lpFn10)(pbyTmp1[1],pbyTmp1[0],&byTmp2);
		*pdwArg2 = byTmp2*pbyTmp1[12]*(DWORD)pbyTmp1[13]/0x64;
		return 1;
	}
	return 0;
}


DWORD CW836x::sub_1000A7E0(WORD dwArg1, DWORD *pdwArg2)
{
	BYTE *pbyTmp1; // eax
	BYTE byTmp2; 
	BYTE byRet; 

	byRet = 1;
	if ( dwArg1 >= m_by28 )
		return 0;
	pbyTmp1 = &m_pby24[10*dwArg1];
	(this->*m_lpFn10)(pbyTmp1[1], pbyTmp1[0], &byRet);
	if ( !byRet )
		return 0;
	byTmp2 = sub_1000AAE0(dwArg1);
	*pdwArg2 = 0x149970 / (byRet * (unsigned int)byTmp2);
	return 1;
}


DWORD CW836x::sub_1000A860(BYTE byArg1, DWORD *a3, DWORD *a4)
{
	int result; 
	result = 0;
	if ( ((1 << byArg1) & m_w2A) != 0 )
	{
		*a3 = 0xFFFF2928;
		*a4 = 125000;
		return 1;
	}
	return result;
}


DWORD CW836x::sub_1000ABC0(WORD wArg1, DWORD *pdwArg2, DWORD *pdwArg3)
{
	int result;

	result = 0;
	if ( wArg1 < m_by38 )
	{
		*pdwArg2 = 0;
		*pdwArg3 = (m_pby34[14*wArg1+12] * (DWORD)m_pby34[14*wArg1+13]<<8)/100;
		return 1;
	}
	return 0;
}


DWORD CW836x::sub_1000A8A0(WORD wArg1, DWORD *pdwArg2, DWORD *pdwArg3)
{
	DWORD result;
	result = 0;
	if ( wArg1 < (WORD)m_by28 )
	{
		sub_1000AAE0(wArg1);
		*pdwArg2 = 0x149970 / (255 * (BYTE)sub_1000AAE0(wArg1));
		*pdwArg3 = 0x149970 / (BYTE)sub_1000AAE0(wArg1);
		return 1;
	}
	return result;
}


DWORD CW836x::sub_1000A900(WORD wArg1, PDWORD pdwArg2)
{
	if ( wArg1 < m_by30 )
	{
		*pdwArg2 = (m_pby2C[12*wArg1+1] != 0) ? 500 : 1000;
		return 1;
	}
	return 0;
}


DWORD CW836x::sub_1000AC20(WORD wArg1, PDWORD pdwArg2)
{
	if ( wArg1 < m_by38 )
	{
		*pdwArg2 = m_pby34[14*wArg1+12];
		return 1;
	}
	return 0;
}


DWORD CW836x::sub_10009DE0(DWORD, PDWORD)
{
	return 0;
}


DWORD CW836x::sub_1000AC60(WORD wArg1, DWORD *pdwArg4)
{
	int result; 
	BYTE *pbyTmp1; 
	BYTE byTmp2; 
		
	result = 0;
	byTmp2 = 0;
	if ( wArg1 < m_by38 )
	{
		pbyTmp1 = &m_pby34[14*wArg1];
		(this->*m_lpFn10)(pbyTmp1[1],pbyTmp1[5],&byTmp2);
		*pdwArg4 = byTmp2 * pbyTmp1[12] * (DWORD)pbyTmp1[13] / 100;
		return 1;
	}
	return 0;
}


DWORD CW836x::sub_1000A940(WORD wArg1, DWORD *pdwArg2)
{
	int result; 
	PBYTE pbyTmp1; 
	BYTE byRet; 

	result = 0;
	byRet = 0;
	if ( wArg1 < m_by30 )
	{
		pbyTmp1 = &m_pby2C[12 * wArg1];
		(this->*m_lpFn10)(pbyTmp1[6], pbyTmp1[5],&byRet);
		*pdwArg2 = 1000 * byRet;
		return 1;
	}
	return 0;
}


DWORD CW836x::sub_1000A9A0(WORD wArg1, DWORD *pdwArg2)
{
	PBYTE pbyTmp1; 
	BYTE byRet; 
	byRet = 0;
	if ( wArg1 < m_by30 )
	{
		pbyTmp1 = &m_pby2C[ 12 * wArg1];
		(this->*m_lpFn10)(pbyTmp1[8],pbyTmp1[7],&byRet);
		*pdwArg2 = 1000 * byRet;
		return 1;
	}
	return 0;
}


DWORD CW836x::sub_1000ACE0(WORD wArg1, DWORD *pdwArg2)
{
	PBYTE pbyTmp1; 
	BYTE byTmp2; 
	byTmp2 = 0;
	if ( wArg1 < m_by38 )
	{
		pbyTmp1 = &m_pby34[14 * wArg1];
		(this->*m_lpFn10)(pbyTmp1[1], pbyTmp1[7], &byTmp2);
		*pdwArg2 = byTmp2 * pbyTmp1[12] * (DWORD)pbyTmp1[13] / 0x64;
		return 1;
	}
	return 0;
}


DWORD CW836x::sub_1000AA00(WORD wArg1, PWORD pdwArg2)
{
	int result; 
	BYTE bRet; 
	result = 0;
	bRet = 0;
	if ( wArg1 < m_by30 )
	{
		if ( (m_w2A & (1 << wArg1)) != 0 )
		{
			(this->*m_lpFn10)(m_pby2C[12*wArg1 + 10], m_pby2C[12*wArg1 + 9], &bRet);
			*pdwArg2 = ((bRet & (m_pby2C[12*wArg1+1])) != 0) + 1;
		}
		else
		{
			*pdwArg2 = 16;
		}
		return 1;
	}
	return 0;
}


LPVOID CW836x::sub_1000A4D0(LPVOID lpMem, BYTE bFlag)
{
	sub_1000A620();
	if ( (bFlag & 1) != 0 && lpMem )
		HeapFree(g_hHeap_1001ADE8, 0, lpMem);
	return lpMem;
}

void CW836x::sub_1000B4E0()
{
	sub_1000A620();
	//~CW836x();

}
BYTE CW836x::sub_1000AAE0(WORD wArg1)
{

	BYTE *pbyTmp1; 
	BYTE byRet; 
	BYTE byTmp2; 

	pbyTmp1 = &m_pby24[10 * wArg1];
	byTmp2 = 0;
	(this->*m_lpFn10)(0, pbyTmp1[4], &byTmp2);
	byRet = (BYTE)(byTmp2 & pbyTmp1[5]) >> pbyTmp1[6];
	(this->*m_lpFn10)(0, pbyTmp1[7], &byTmp2);
	return g_byte_10015BA8[byRet | ((byTmp2 & pbyTmp1[8])>> pbyTmp1[9])];
}

DWORD CW836x::sub_1000A620()
{
	FUNCSTRUC10* pdwTmp1; 
	DWORD *pdwTmp2; 
	LPFnV_P pFnProc;
	int result; 

	DeleteCriticalSection(&m_cs40);
	pdwTmp1 = (FUNCSTRUC10*)m_pdw60;
	pdwTmp2 = 0;
	if ( pdwTmp1 && (pdwTmp1->dwSelfAddr00 == (DWORD)pdwTmp1) )
	{
		pFnProc = (LPFnV_P)(pdwTmp1->pFunc04);
		if ( pFnProc )
		{
			if ( pdwTmp1->dwFlag08 )
				pdwTmp2 = (DWORD*)pdwTmp1->dwParam10;
			pFnProc(pdwTmp2);
		}
		HeapFree(g_hHeap_1001ADE8, 0, pdwTmp1);
	}
	
	if ( m_pWPARAM64 )
		result = HeapFree(g_hHeap_1001ADE8, 0, m_pWPARAM64);
	m_pdw60 = NULL;
	m_pWPARAM64 = NULL;

	return result;
}

DWORD CW836x::sub_1000AD60(WORD wArg1, PDWORD pdwArg2)
{
	
	int result; 
	BYTE *pbyTmp1; 
	BYTE byRet;
	
	result = 0;
	byRet = 0;
	if ( wArg1 < m_by38 )
	{
		
		if( m_w32 & (1<<wArg1))
		{
			pbyTmp1 = &m_pby34[14*wArg1];
			
			(this->*m_lpFn10)(pbyTmp1[10], pbyTmp1[9], &byRet);
			result = 1;
			*pdwArg2 = ((byRet & pbyTmp1[11]) != 0) + 1;
		}
		else
		{
			*pdwArg2 = 16;
			return 1;
		}
	}
	return result;
}

DWORD CW836x::sub_1000AA90(WORD wArg1, PDWORD pdwArg2)
{
	if ( wArg1 < m_by28 )
	{
		if ( (1 << wArg1) & m_w22 )
			*pdwArg2 = 1;
		else
			*pdwArg2 = 16;
		return 1;
	}
	return 0;
}

void CW836x::sub_1000A480()
{
	delete this;
}