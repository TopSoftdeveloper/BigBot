#pragma once
//#include <winddi.h>
#include <setupapi.h>
#include "Cmos.h"
#include "EmbeddedEeprom.h"
#include "GpioDefaultProxy.h"
//#include "Smbus_Def.h"
#include "W83627DHGP.h"
#pragma comment(lib,"../Lib/SetupAPI.Lib")
//W83627DHGP
typedef struct tagDEVINFO {
	FLONG   flGraphicsCaps;
	LOGFONTW  lfDefaultFont;
	LOGFONTW  lfAnsiVarFont;
	LOGFONTW  lfAnsiFixFont;
	ULONG  cFonts;
	ULONG  iDitherFormat;
	USHORT  cxDither;
	USHORT  cyDither;
	HPALETTE  hpalDefault;
	FLONG  flGraphicsCaps2;
} DEVINFO, *PDEVINFO;

typedef struct tagFuncTable16{
	DWORD unk00;
	DWORD unk04;
	DWORD unk08;
	LPVOID pFunc;
} FUNCTBL16, *PFUNCTBL16;

typedef struct tagFUNCSTRUC10{
	DWORD dwSelfAddr00;
	LPVOID pFunc04;
	DWORD dwFlag08;
	char* szStr0C;
	DWORD dwParam10;
} FUNCSTRUC10, *PFUNCSTRUC10;

typedef struct tagFuncTable20{
	DWORD unk00;
	DWORD unk04;
	DWORD unk08;
	DWORD unk0C;
	LPVOID pFunc;
} FUNCTBL20, *PFUNCTBL20;
typedef struct tagDEVINPUT_1C 
{
	int nCmd_0;
	int nParam_4;
	int nParam_8;
	int nParam_c;
	int nParam_10;
	int nParam_14;
	int nParam_18;
} DEVINPUT_1C, *LPDEVINPUT_1C;
typedef struct tagDEVOUT_0C 
{
	int nErrCode_0;
	int nResult_4;
	int nAddInfo_8;

} DEVOUT_0C, *LPDEVOUT_0C;

//////////////////////////////////////////////////////////////////////////
typedef struct tagControlDevice30{
	DWORD dwOutBuffer[5];
	LPVOID lpClass;
	DWORD dwUnk18;
	DWORD dwUnk1C;
	DWORD dwUnk20;
	DWORD dwUnk24;
	DWORD dwFlag;
	DWORD dwUnk2C;

}ControlDevice30,*PControlDevice30;
//////////////////////////////////////////////////////////////////////////





/*W836XPARAM_6C*/

DWORD sub_10007460(SMBUSPARAM* lpBuf, DWORD dwParam, DWORD dwCmd, DWORD *pdwOut);
void sub_100072A0(WORD wCnt, BYTE *pSrc, SMBUSPARAM* pDest, WORD wMod);
DWORD sub_100073E0(DWORD *pDest, SMBUSPARAM* plpParam);
//////////////////////////////////////////////////////////////////////////

typedef UINT (__thiscall* LPFnU_V)(VOID);
typedef VOID (__thiscall* LPFnV_V)(VOID);
typedef UINT (__thiscall* LPFnU_D)(DWORD);
typedef VOID (__thiscall* LPFnV_D)(DWORD);
typedef UINT (__thiscall* LPFnU_DDDD)(DWORD, DWORD, DWORD, DWORD);
typedef UINT (__thiscall* LPFnU_DDD)(DWORD, DWORD, DWORD);
typedef VOID (__thiscall* LPFnV_P)(PDWORD );

typedef UINT (__thiscall* LPFnU_DDDDD)(DWORD, DWORD, DWORD, DWORD, DWORD);
typedef UINT (__thiscall* LPFnU_DDDPD)(DWORD, DWORD, DWORD, LPVOID, DWORD);
typedef DWORD (__thiscall* LPFnD_DDD)(DWORD, DWORD, DWORD);
typedef DWORD (__thiscall* LPFnD_DDDP)(DWORD, DWORD, DWORD, LPVOID);
typedef UINT (__thiscall* LPFnU_DD)(DWORD, DWORD);
typedef UINT (__thiscall* LPFnU_DDPP)(DWORD, DWORD, LPVOID, LPVOID);
typedef UINT (__thiscall* LPFnU_DDP)(DWORD, DWORD, LPVOID);
typedef UINT (__thiscall* LPFnU_DP)(DWORD, LPVOID);
typedef UINT (__thiscall* LPFnU_PP)(LPVOID, LPVOID);
typedef DWORD (__thiscall* LPFnD_BDD)(BYTE, DWORD, DWORD);
typedef DWORD (__cdecl* LPFnD_HPDPDP)( HDEVINFO, PSP_DEVINFO_DATA, DWORD, PBYTE, DWORD, PDWORD );
typedef DWORD* (__thiscall* LPFnP_V)(VOID);
typedef DWORD* (__cdecl* LPFnP_D)(DWORD);
typedef DWORD (__cdecl* LPFnD_V)(VOID);

//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////
extern HMODULE g_hmod_1001ADB4;
extern HMODULE g_hmod_1001ADE4;

extern DWORD   g_dwTlsIndex_10019FFC;
extern HANDLE g_hHeap_1001ADE8;
extern HANDLE g_hObject_1001ADE0;
extern DWORD g_dword_1001ADD8;
extern CRITICAL_SECTION g_CriticalSection_1001AD9C;
extern DWORD g_off_10002F40;
extern CGpioDefaultProxy* g_pGpioDefaultProxy_1001AD98;
extern LPVOID g_pCSmbus_Def_1001ADEC;
extern HANDLE g_hFile_10019FF8;
extern PDWORD  g_pClassList_1001ADB8[8];


extern DWORD g_dword_1001AE00[8];
/*
extern LPVOID g_dword_1001AE04;
extern DWORD g_dword_1001AE08;
extern DWORD g_dword_1001AE0C;
extern DWORD g_dword_1001AE00[4];
extern DWORD g_dword_1001AE14;
extern DWORD g_dword_1001AE18;
extern DWORD g_dword_1001AE1C;
*/


extern DWORD  g_dword_1001AE30;
extern PDWORD  g_dword_1001AE20;
extern LPVOID g_lpMem_1001AE24;
extern DWORD  g_dword_1001ADDC;
extern DWORD  g_ClassGuid_10015A3C[4];
extern DWORD	g_ClassGuid_10015A4C[4];
extern HANDLE g_hMutex_1001ADFC;
extern DWORD g_DS_0[2];
extern CStorage* g_pCEmbeddedEeprom_1001AE28[2];
extern DWORD g_dword_1001ADF0;
extern PDWORD  g_dword_10015BF0;
//extern PDWORD  g_dword_10015BEC;
extern FUNCTBL16 g_dword_10015BE8[9];
extern FUNCTBL20 g_dword_1001A01C[3];
extern BYTE g_byte_10015BA8[8];

extern char szHACPI[8]; 
extern DWORD g_dword_1001ADF4[2];
extern DWORD g_dword_10015A84[9];
extern DWORD g_dword_10015B28[32];
extern DWORD g_dword_10015BB0[14];
extern DWORD g_dword_10015A60[9];
extern DWORD g_dword_10015AA8[32];
extern DWORD g_dword_10015D48[6];
extern DWORD g_dword_10015D60[21];
extern BYTE g_byte_10015D20[16];
extern BYTE g_byte_10015D30[24];
BOOL		InitDll_10004BE0(HMODULE hInstDll);
BOOL		sub_10004B60(void);
OVERLAPPED*		getTlsValue_10004D00(void);
BOOL		releaseTlsValue_10004CB0();
BOOL		ReleaseDll_10004C10();
BOOL		sub_10002F40();
void		sub_10006E10();
void		sub_10005A30();
DWORD		sub_10005070();
DWORD		sub_10002E30();
DWORD		sub_10005000(DWORD* pdwIn, LPCWSTR lpServiceName);
DWORD		sub_10004EC0(HANDLE* pFileHandle, GUID* bGUID);
DWORD		sub_100031D0(PBYTE pParam);
DWORD		sub_10004FE0();
DWORD		sub_10005270();
void		sub_10005730();
BOOL		sub_10007260();
BOOL		sub_100069E0();
LPVOID		sub_10007550();
LPVOID		sub_10005A10(LPVOID lpMem);
LPVOID		sub_100052E0(PBYTE result, DWORD dwVal1, PDWORD  pdwVal, DWORD dwVal2);
DWORD		sub_1000A180(HDEVINFO hDevInfo);
DWORD		sub_1000A2B0(LPVOID lpParam, HDEVINFO hDevInfo, SP_DEVINFO_DATA* pDevData, DWORD* dwBytes);

DWORD		MySetupDiGetDeviceRegistryProperty_1000A420(
				   HDEVINFO DeviceInfoSet,
				   PSP_DEVINFO_DATA DeviceInfoData,
				   DWORD Property,
				   PBYTE PropertyBuffer);
DWORD MySetupDiGetDeviceRegistryProperty_1000A3D0(
				   HDEVINFO DeviceInfoSet,
				   PSP_DEVINFO_DATA DeviceInfoData,
				   DWORD Property,
				   PBYTE PropertyBuffer,
				   DWORD PropertyBufferSize,
				   PDWORD  RequiredSize);
DWORD		CSmbusCreate_10006980();
LPVOID		CGpioDefalutCreate_100075D0();
LPVOID		CGpioDefalutCreate2_10007E70();
DWORD		sub_10009F30(wchar_t *Source, void *a2);
DWORD		sub_10004E50(	void *a1, DWORD dwIoControlCode,	
				   void *lpInBuffer,	
				   DWORD nInBufferSize,								
				   void *lpOutBuffer,
				   DWORD nOutBufferSize, 
				   DWORD *lpNumberOfBytesTransferred);
int			sub_100068E0(DWORD *a1, DWORD *a2);
BOOL		sub_10005320(PControlDevice30 lpParam);
DWORD		sub_10003430(DWORD *pdwIn, DWORD dwFlag, WORD wSize, PWORD dwVal4);
//////////////////////////////// UnInitialize//////////////////////////////////////////
int			sub_10002F70();
int			sub_10001EE0(BYTE *lpOutBuffer, DWORD* a2);
int			sub_100024D0(BYTE *lpOutBuffer, DWORD *a2);
int			sub_10001F90(BYTE *lpOutBuffer, DWORD *a2);
int			sub_10002040(BYTE *lpOutBuffer, DWORD *a2);
int			sub_10001E30(BYTE *lpOutBuffer, DWORD *a2);
BOOL		sub_10004DB0(BYTE *lpOutBuffer, DWORD dwVal, PBYTE pbBuff2);
int			sub_10004B10(BYTE *a1, int a2, BYTE *a3);
int			sub_10003310(char InBuffer, DWORD* lpOutBuffer, DWORD DestinationSize, DWORD *a4);

int			 sub_10006240(DWORD *a1, BYTE bVal);
int			sub_100020F0(DWORD dwVal1);
int			sub_100050E0(char a1, PDWORD  a2, WORD a3, WORD *a4);
int			sub_100061C0(  int a1,	 DWORD *a2,	 PBYTE pbMem, WORD a4, WORD *a5);
int			sub_100068A0(PBYTE pbBuff1, PBYTE pbBuff2);
int			sub_10006070(BYTE * a1, BYTE *a2);
int			sub_10006330(PBYTE a1, PBYTE a2);
int			sub_100063F0(PBYTE a1, PBYTE	 a2);
int			sub_10006530(PBYTE a1, PBYTE a2);
int			sub_10006650(PBYTE a1, PBYTE a2);
int			sub_10006710(PBYTE a1, PBYTE a2);
DWORD64		sub_10004DE0(DWORD64 a1);
int			sub_10006760(PBYTE a1, PBYTE a2);
int			sub_100067B0(int a1, int a2);
BYTE *		sub_10006820(BYTE a1, PBYTE a2, BYTE *a3, BYTE *a4);
int			sub_100064B0(PBYTE pbBuff1, PBYTE pbBuff2);
int			sub_10002440(DWORD *a1, DWORD a2);
int			sub_100023B0(DWORD *a1, int a2);
int			sub_100022F0(int a1, DWORD *a2);
int			sub_10003250(DWORD *a1);
int			sub_100032B0(DWORD *a1);
//EApi2WriteTransfer//
int			sub_10002240(DWORD dwFlag);
int			sub_100035B0(int nSize, DWORD dwVal2, SHORT wVal3, void *lpDest);
DWORD		sub_10004170(DWORD *pdwBuff);
DWORD		sub_10004100();
DWORD		sub_10004830(DWORD *pdwRetCode, ...);
DWORD		sub_100047B0(BYTE bFlag, DWORD dwVal);
int			sub_10003CA0(DWORD dwVal, LPVOID lpOutBuffer);
DWORD		*sub_10005AE0(WORD *pwBuff1, int nSize);
int			sub_100056E0(PControlDevice30 pCtrlDevice, void *lpBuff2, size_t nSize, DWORD dwVal4);
DWORD		sub_10001000(PControlDevice30 pControlDevice);
int			sub_100054A0(PControlDevice30 pCtrlDevice, SIZE_T nSize, DWORD dwArg2, BYTE *Src);
//////////////////////////////////////////////////////////////////////////
DWORD sub_10003B30(int nSizeDest, int a2, WORD a3, WORD a4, int a5, void *pDest);
DWORD sub_10003D70(DWORD* pdwArg, BYTE* pbyArg);
DWORD sub_100036F0(DWORD a1, WORD a2, void *Source, DWORD dwSizeSrc, DWORD *a5, DWORD a6);
DWORD sub_10005200(DWORD dwParam);
DWORD sub_10003820(DWORD a1, DWORD a2, WORD a3, void *Source, DWORD SrcSize, DWORD* a6, void* Dest,DWORD *a8,  int a9);
DWORD sub_100039D0(DWORD dwlen, DWORD a2, DWORD a3, WORD a4, WORD a5, void *Source);
DWORD sub_100070F0(WCHAR* wszStr);
//////////////////////////////// //////////////////////////////////////////
int		sub_10005610(PControlDevice30 pCtrlDev);
DWORD	sub_10004520(DWORD *pdwBuff);
DWORD	sub_100044B0(DWORD dwFlag);
DWORD	sub_10004280(DWORD *pdwBuff);
DWORD	sub_10004090(PDWORD  pdwBuff);
DWORD	sub_10004210();
DWORD	sub_10004310();
DWORD  sub_10004A30(DWORD InBuffer, DWORD dwMilliseconds);
DWORD  sub_100049C0(PDWORD  pdwOutBuffer);
DWORD  sub_100048D0(DWORD InBuffer, DWORD dwFlag);
DWORD  sub_10004950(LPVOID lpOutBuffer);
//////////////////////////////////////////////////////////////////////////
DWORD  sub_10004700(DWORD *pdwBuff);
DWORD  sub_100045B0(DWORD dwInBuffer);
DWORD  sub_10004620(DWORD InBuffer);
DWORD  sub_10004690(DWORD dwInBuffer);
BOOL sub_10006DD0(DWORD dwArg1,int iClassType);
SHORT *sub_10006AD0();
DWORD sub_100083C0(WORD wArg1);
DWORD sub_10009340(DWORD dwArg1);
DWORD sub_10009440(DWORD dwArg1);
DWORD sub_10006A80(DWORD dwArg1);
DWORD sub_10009E20(DWORD dwArg1);
DWORD sub_10009650(DWORD dwArg1);
DWORD sub_100086E0(DWORD dwArg1);

//SHORT* sub_10006C80(PDWORD  pdwArg1);

DWORD		sub_10003040(BYTE bArg1, DWORD dwArg2);
LPVOID		sub_1000A510(SHORT wArg1, BYTE bArg2, BYTE bArg3, DWORD dwArg4);
OVERLAPPED *sub_10004D00();
SHORT*		sub_10006C80(PDWORD  pdwArg1, int iClassType);
DWORD		sub_100030C0(char InBuffer, LPVOID lpOutBuffer);// uncompleted