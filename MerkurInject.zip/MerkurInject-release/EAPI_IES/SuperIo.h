#pragma once
class CSuperIo
{
public:
	CSuperIo();
	~CSuperIo();

public:
	virtual void sub_1000A450();
	virtual void purecall();
	
};

