#include "stdafx.h"
#include "W83627DHGP.h"
#include "EApi_IES_global.h"
CW83627DHGP::CW83627DHGP()
{
}


CW83627DHGP::~CW83627DHGP()
{
}


void CW83627DHGP::sub_1000A480()
{
	// call destructor
	CW83627DHGP::~CW83627DHGP();
}

#if 0
DWORD CW83627DHGP::sub_1000A6B0()
{
	CW836x::sub_1000A6B0();
	return TRUE;
}


DWORD CW83627DHGP::sub_10006E70()
{
	return 1;
}


void CW83627DHGP::sub_10006EB0()
{
}


void CW83627DHGP::sub_10006F00()
{
}


void CW83627DHGP::sub_10006F60()
{
}


void CW83627DHGP::sub_10006FB0()
{
}


void CW83627DHGP::sub_10007000()
{
}


void CW83627DHGP::sub_10007050()
{
}


BYTE CW83627DHGP::sub_1000A490()
{
	return m_by30;
}


BYTE CW83627DHGP::sub_1000A4B0()
{
	return m_by38;
}


BYTE CW83627DHGP::sub_1000A4A0()
{
	return m_by28;
}


void CW83627DHGP::sub_1000A730()
{
}


void CW83627DHGP::sub_1000AB50()
{
}


void CW83627DHGP::sub_1000A7E0()
{
}


void CW83627DHGP::sub_1000A860()
{
}


void CW83627DHGP::sub_1000ABC0()
{
}


void CW83627DHGP::sub_1000A8A0()
{
}


void CW83627DHGP::sub_1000A900()
{
}


void CW83627DHGP::sub_1000AC20()
{
}


DWORD CW83627DHGP::sub_10009DE0()
{
	return 1;
}


void CW83627DHGP::sub_1000AC60()
{
}


void CW83627DHGP::sub_1000A940()
{
}


void CW83627DHGP::sub_1000A9A0()
{
}


void CW83627DHGP::sub_1000ACE0()
{
}


void CW83627DHGP::sub_1000AA00()
{
}


void CW83627DHGP::sub_1000AD60()
{
}


void CW83627DHGP::sub_1000AA90()
{
}

#endif

PDWORD CW83627DHGP::sub_1000B420(DWORD *pdwArg1, PDWORD pdwArg2)
{
	DWORD *result; // eax

	result = pdwArg1;
	*pdwArg1 = (DWORD)g_dword_10015A60;
	*pdwArg2 = 3;
	return result;
}


PDWORD CW83627DHGP::sub_1000B440(DWORD *pdwArg1, BYTE *pdwArg2)
{
	DWORD *result; // eax

	result = pdwArg1;
	*pdwArg1 = (DWORD)g_dword_10015AA8;
	*pdwArg2 = 9;
	return result;
}


PDWORD CW83627DHGP::sub_1000B460(DWORD *pdwArg1, BYTE *pdwArg2)
{
	DWORD *result;
	result = pdwArg1;
	*pdwArg1 = (DWORD)g_dword_10015BB0;
	*pdwArg2 = 5;
	return result;
}
#if 0

void CW83627DHGP::sub_1000A4D0()
{
}


void CW83627DHGP::sub_1000B4E0()
{
}
#endif
