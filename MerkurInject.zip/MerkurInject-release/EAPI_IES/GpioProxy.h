#pragma once
class CGpioProxy
{
public:
	CGpioProxy();
	~CGpioProxy();

public:

	virtual void sub_10007520();
};

