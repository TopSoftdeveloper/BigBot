// dllmain.cpp : Defines the entry point for the DLL application.
#include "stdafx.h"
#include "EAPI_IES_global.h"
#include "Smbus_Def.h"
#include <malloc.h>
#include "SuperIo.h"
#include "Sensor.h"
#include "W836x.h"
#include "Adt7475.h"
#include "Adt7490.h"
#include "W83L771Ax.h"
#include "NCT7802.h"
#include "AmdBrazos.h"
#include "W83627DHGP.h"
#include <tchar.h>
//#include "GpioDefaultProxy.h"

HMODULE g_hmod_1001ADB4;
HMODULE g_hmod_1001ADE4;

DWORD   g_dwTlsIndex_10019FFC;
HANDLE g_hHeap_1001ADE8;
HANDLE g_hObject_1001ADE0;
CRITICAL_SECTION g_CriticalSection_1001AD9C;
BOOL g_dword_1001ADE4;
DWORD g_dword_1001ADD8;
DWORD g_off_10002F40;
CGpioDefaultProxy* g_pGpioDefaultProxy_1001AD98;//; g_dword_1001AD98;// class address
LPVOID g_pCSmbus_Def_1001ADEC;// class address
HANDLE g_hFile_10019FF8;
PDWORD  g_pClassList_1001ADB8[8];


DWORD g_dword_1001AE00[8];
DWORD  g_dword_1001AE30;
PDWORD  g_dword_1001AE20;
LPVOID g_lpMem_1001AE24;
DWORD  g_dword_1001ADDC;
HANDLE g_hMutex_1001ADFC;
DWORD  g_ClassGuid_10015A3C[4];
DWORD	g_ClassGuid_10015A4C[4];
DWORD g_DS_0[2];
CCmos* g_pCCmos_1001AE2C = NULL;
DWORD g_dword_1001ADF0;
CStorage* g_pCEmbeddedEeprom_1001AE28[2];
 DWORD g_dword_1001ADF4[2];
 BYTE g_byte_10015DC4[4] = {0x2E, 0x4E, 0, 0};
 DWORD g_dword_10015DE4[4] = {7, 0x0A, 0x1E, 0x01};

FUNCTBL16 g_dword_10015BE8[9]=
{{0, 0x2C, 1,(LPVOID)MySetupDiGetDeviceRegistryProperty_1000A3D0},  
{0x0B, 30,0x1,(LPVOID)MySetupDiGetDeviceRegistryProperty_1000A3D0},
{0x1,0x1C,0x1,(LPVOID)MySetupDiGetDeviceRegistryProperty_1000A3D0},
{0x2,0x20,0x1,(LPVOID)MySetupDiGetDeviceRegistryProperty_1000A3D0},
{0x12,0x34,0x1,(LPVOID)MySetupDiGetDeviceRegistryProperty_1000A3D0},
{0x0E,0x28,0x1,(LPVOID)MySetupDiGetDeviceRegistryProperty_1000A3D0},
{0x9,0x38,0x1,(LPVOID)MySetupDiGetDeviceRegistryProperty_1000A3D0},
{0x19,0x24,0,(LPVOID)MySetupDiGetDeviceRegistryProperty_1000A420},
{0x0F,0x18,0, (LPVOID)MySetupDiGetDeviceRegistryProperty_1000A420}
};
PDWORD  g_dword_10015BF0;

FUNCTBL20 g_dword_1001A01C[3] ={
	{
		0x0FC1FF2F1,0x41118870,0x235F3C90,0x117489F1, (LPVOID)CSmbusCreate_10006980 // CSmbus_constructor
	},
	{
		0x85118BA9,0x4544B089,0x787498A8,0x0AD6C7915, (LPVOID)CGpioDefalutCreate_100075D0// CGpioDefalut_constructor
	},
	{
		0x0C3B40AAB,0x4FAF5EE8,0x0CA94B591,0x0B094009D, (LPVOID)CGpioDefalutCreate2_10007E70//CGpioDefalut_constructor
	}
};
LPVOID CSensorIoCreators_10006B8D[7]=
{
	sub_10009340, sub_10009440, sub_100086E0, sub_10009650, sub_10009E20, sub_10006A80, sub_10006A80
	////CAdt7475,CAdt7490,CW83L771Ax,CNCT7802,CAmdBrazos,CSuperIo,CSuperIo
};
BYTE g_byte_10015BA8[8] = {1,2,4,8,0x10,0x20,0x40,0x80};

DWORD g_dword_10015A84[9] = 
{
	0x27, 0x3900, 0x10045900, 0x1520150, 0x15501, 0x20045900, 0x2520250,0x25501, 0x20045A00
};

DWORD g_dword_10015B28[32] = 
{0x20,
0x2C002B00,	0x1045900,	0x216410,	0x2D000000,	0x59002E00,	0x64100204,	0x22,	0x30002F00,	0x4045900,	0x236410,
0x31000000,	0x59003200,	0x0A8100804,	0x24,	0x34003300,	0x1045A00,	0x256410,	0x35000000,	0x5A003600,	0x64100204,
0x26,	0x38003700,	0x4045A00,	0x5506410,	0x54000000,	0x5B055505,	0x98100104,	0x5D0551,	0x57055601,	0x2045B05,
0x6410,
};

DWORD g_dword_10015BB0[14] = 
{
	0x14D0028, 0x5D043047,0x290320,	0x0C047044D,0x4405D06,0x104D002A,0x5D06C04B,0x3F0580,0x3590447,0x5804C00,0x1470553,
	0x59020C59,	0x580,	0x0
};
DWORD g_dword_10015A60[9] = {0x27,0x77007600,0x10045900,0x1520150,0x79007801,0x20045900,0x2520250,0x7B007A00,0x20045A00};

DWORD g_dword_10015AA8[32] = {
	0x20, 0x2C002B00,0x1045900,0x216408,0x2D000000,0x59002E00,0x64080204,0x24,0x34003300,0x1045A00,0x256408,0x35000000,
	0x5B003600,	0x64082004,	0x26,0x38003700,0x10045B00,0x5506408,0x54000000,0x5B055505,0x0C8080104,0x5D0551,0x57055601,
	0x2045B05,	0x23C808,0x31000000,0x59003200,0x0C8080804,0x22,0x30002F00,	0x4045900,	0x0C808};
DWORD g_dword_10015D48[6] = {0x2062176, 0x5354647, 0x241, 0x4302276, 0x7A44849, 0x441};
DWORD g_dword_10015D60[21] = {0x2062176, 0x5354647, 0x200241, 0x4302276, 0x7A44849, 0x441, 0x4301E1F,
	0x3E88486,0x8081,0x6C02376,0xB934A4B,0x400841,0x32477,0x1BC74C4D,0x800142,0x32076,0x5C84445,0x100141,0x6C01D1F,0x5C88587,0x4081};
BYTE g_byte_10015D20[16] = {0x29, 0x28, 0x42, 0x04, 0x2B, 0x2A, 0x42, 0x08, 0x2D, 0x2C, 0x42, 0x10, 0x2f, 0x2E, 0x42,0x20};
BYTE g_byte_10015D30[24] = {0x77,0x25,0x6,0x7,0x4f,0x4e,0x41,0x10,
0x77,0x26,0x30,0x4,0x51,0x50,0x41,0x20,
0x77,0x27, 0xc0, 0x6, 0x53, 0x52, 0x41, 0x40};
LPVOID		createClasssW83627DHGP_1000A5C0(SHORT wArg1, CW83627DHGP* pW83627DHGP, DWORD dwArg3);

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
					 )
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		{
		
			TCHAR tszModuleName[MAX_PATH] = _T("");
			TCHAR tszDllName[MAX_PATH] = _T("");
			GetModuleFileName(NULL, tszModuleName, MAX_PATH);
			TCHAR* p = _tcsrchr(tszModuleName, '\\');

			*(p) = NULL;
			SetCurrentDirectory(tszModuleName);
			
		}
		return InitDll_10004BE0(hModule);
		
	case DLL_THREAD_ATTACH:
		return (getTlsValue_10004D00()!= NULL);
	case DLL_THREAD_DETACH:
		releaseTlsValue_10004CB0();
		return TRUE;
	case DLL_PROCESS_DETACH:
		if(!lpReserved) return TRUE;
		ReleaseDll_10004C10();
		break;
	}
	return TRUE;
}
BOOL sub_10002F40()
{
	return TRUE;
}
DWORD MySetupDiGetDeviceRegistryProperty_1000A3D0(
						   HDEVINFO DeviceInfoSet,
						   PSP_DEVINFO_DATA DeviceInfoData,
						   DWORD Property,
						   PBYTE PropertyBuffer,
						   DWORD PropertyBufferSize,
						   PDWORD  RequiredSize)
{
	DWORD result; 

	if ( SetupDiGetDeviceRegistryPropertyW(
		DeviceInfoSet,
		DeviceInfoData,
		Property,
		0,
		PropertyBuffer,
		PropertyBufferSize,
		RequiredSize) )
	{
		return 0;
	}
	result = GetLastError();
	if ( result == ERROR_INSUFFICIENT_BUFFER )
		*RequiredSize *= 2;
	return result;
}
DWORD MySetupDiGetDeviceRegistryProperty_1000A420(
						   HDEVINFO DeviceInfoSet,
						   PSP_DEVINFO_DATA DeviceInfoData,
						   DWORD Property,
						   PBYTE PropertyBuffer)
{
	if ( SetupDiGetDeviceRegistryPropertyW(DeviceInfoSet, DeviceInfoData, Property, 0, PropertyBuffer, 4u, 0) )
		return 0;
	else
		return GetLastError();
}

DWORD	CSmbusCreate_10006980()
{
	CSmbus_Def* pCSmbus_Def = new CSmbus_Def();
	pCSmbus_Def->m_dw1C = 0;
	pCSmbus_Def->m_funcstr20 = 0;
	pCSmbus_Def->m_lp24 = 0;
	return (DWORD)pCSmbus_Def;

}
LPVOID		CGpioDefalutCreate_100075D0()
{
	CGpioDefaultProxy* pCGpioDefaultProxy = new CGpioDefaultProxy();
	pCGpioDefaultProxy->m_hHandle = g_hFile_10019FF8;
	return pCGpioDefaultProxy;
}
LPVOID CGpioDefalutCreate2_10007E70()
{

	HANDLE hHandle; 
	if ( sub_10005000((DWORD*)&hHandle, L"topcliffgpio") )
		return 0;
	hHandle = 0;
	if ( sub_10004EC0(&hHandle, (GUID *)&g_ClassGuid_10015A4C) )
		return 0;
	CGpioDefaultProxy* pClass = new CGpioDefaultProxy();
	pClass->m_hHandle = hHandle;
	return pClass;

}
void	sub_10006E10()
{
	DWORD i; 
	
	for ( i = 0; i < 8; ++i )
	{
		PDWORD  func_addr = g_pClassList_1001ADB8[i];
		if ( func_addr )
		{
			//LPFnV_V lpFunc = (LPFnV_V)*(PDWORD )(*(DWORD*)func_addr + 4);
			//lpFunc();
			delete func_addr;
			g_pClassList_1001ADB8[i] = NULL;
		}
	}
	
	if ( g_dword_1001AE00[1] )
		HeapFree(g_hHeap_1001ADE8, 0, (LPVOID)g_dword_1001AE00[1]);
	g_dword_1001AE00[1] = NULL;
	g_dword_1001AE00[0] = 0;
	
}
DWORD sub_10005000(DWORD* pdwIn, LPCWSTR lpServiceName)
{
	SC_HANDLE hManager; 
	SC_HANDLE hService;
	DWORD LastError; 

	hManager = OpenSCManagerW(0, 0, 2);
	hService = OpenServiceW(hManager, lpServiceName, SERVICE_ALL_ACCESS);
	if ( !hService )
		return GetLastError();
	if ( StartServiceW(hService, 0, 0) )
	{
		*pdwIn = 1;
		CloseServiceHandle(hService);
		return 0;
	}
	else
	{
		LastError = GetLastError();
		if ( LastError == ERROR_SERVICE_ALREADY_RUNNING )
		{
			*pdwIn = 0;
			LastError = 0;
		}
		CloseServiceHandle(hService);
		return LastError;
	}
}

DWORD sub_10004EC0(HANDLE* pFileHandle, GUID* bGUID)
{
	DWORD LastError; 
	SP_DEVICE_INTERFACE_DETAIL_DATA * pDeviceData;
	DWORD RequiredSize; 
	DWORD MemberIndex; 
	SP_DEVICE_INTERFACE_DATA DeviceInterfaceData; 

	RequiredSize = 0;
	LastError = 1168;
	HDEVINFO hClassDevs = (HDEVINFO)SetupDiGetClassDevs((LPGUID)bGUID, 0, 0, 0x12u);
	if ( (HANDLE)hClassDevs == INVALID_HANDLE_VALUE)
		return LastError;
	MemberIndex = 0;
	DeviceInterfaceData.cbSize = 28;
	while ( !SetupDiEnumDeviceInterfaces(hClassDevs, 0, (LPGUID)bGUID, MemberIndex, &DeviceInterfaceData) )
	{
		if ( GetLastError() == 259 )
		{ SetupDiDestroyDeviceInfoList(hClassDevs); return GetLastError();}

		++MemberIndex;
	}
	do{
		SetupDiGetDeviceInterfaceDetailW(hClassDevs, &DeviceInterfaceData, 0, 0, &RequiredSize, 0);
		LastError = GetLastError();
		++MemberIndex;
	}
	while(LastError != ERROR_INSUFFICIENT_BUFFER);
		
	LastError = 8;
	pDeviceData = (SP_DEVICE_INTERFACE_DETAIL_DATA *)HeapAlloc(g_hHeap_1001ADE8, 8u, RequiredSize);
	
	if ( pDeviceData )
	{
		pDeviceData->cbSize = 6;
		SetupDiGetDeviceInterfaceDetailW(hClassDevs, &DeviceInterfaceData, pDeviceData, RequiredSize, &RequiredSize, 0);
		LastError = 110;
		HANDLE hFile = CreateFileW(pDeviceData->DevicePath, 0xC0000000, 3, 0, 3, 0x40000000, 0);
		if ( hFile != INVALID_HANDLE_VALUE )
		{
			LastError = 0;
			*pFileHandle = hFile;
		}
		HeapFree(g_hHeap_1001ADE8, 0, pDeviceData);
	}

	SetupDiDestroyDeviceInfoList(hClassDevs);
	return LastError;
}

DWORD sub_100031D0(PBYTE lpOutBuffer)
{
	DWORD LastError; 
	DWORD result; 
	OVERLAPPED* pOverLapped1; 	
	
	LastError = 0;
	result = 87;
	*(DWORD*)lpOutBuffer = NULL;
	if ( lpOutBuffer )
	{
		pOverLapped1 = (OVERLAPPED *)getTlsValue_10004D00();
		
		if ( !pOverLapped1 )
			return ERROR_NO_SYSTEM_RESOURCES;
		DeviceIoControl(g_hFile_10019FF8, 0xEA606000, 0, 0, (LPDWORD)lpOutBuffer, 6, 0, pOverLapped1);
		if ( !GetOverlappedResult(g_hFile_10019FF8, pOverLapped1, (LPDWORD)lpOutBuffer, 1) )
		{
			LastError = GetLastError();
			if ( LastError == 0xE0000109 )
				return ERROR_TIMEOUT;
		}
		return LastError;
	}
	return result;
}

DWORD sub_10004FE0()
{
	CloseHandle(g_hFile_10019FF8);
	g_hFile_10019FF8 = INVALID_HANDLE_VALUE;
	return 1;
}

DWORD sub_10005270()
{
	if ( g_hMutex_1001ADFC )
		return 1;
	g_hMutex_1001ADFC = CreateMutexW(0, 0, L"KBSP_MUTEX_CE8C0FFA-D8B3-43e4-8F58-24AFB0E31F6A");
	return (g_hMutex_1001ADFC != 0);
}

DWORD sub_10003430(PDWORD  pdwIn, DWORD dwFlag, WORD wSize, PWORD dwVal4)
{
	PDWORD  pdwTemp; 
	
	OVERLAPPED *pOverLapped6; 
	DWORD LastError; 
	int nOffset = 0; 
	DWORD i = 0; 
	
	DWORD dwRetVal; 
	DWORD dwRetError; 
	DWORD NumberOfBytesTransferred; 
	DWORD dwVal14; 
	DWORD nOutBufferSize; 
	NumberOfBytesTransferred = 0;
	dwVal14 = 0;
	if ( pdwIn && wSize >= 4 )
	{
		pdwTemp = pdwIn;
		nOutBufferSize = wSize;
	}
	else
	{
		pdwTemp = (PDWORD )&dwVal14;
		nOutBufferSize = 4;
	}
	
	dwRetError = 0;
	pOverLapped6 = (OVERLAPPED *)getTlsValue_10004D00();
	
	if ( pOverLapped6 )
	{
		DeviceIoControl(g_hFile_10019FF8, 0xEA60E00C, &dwFlag, 4, pdwTemp, nOutBufferSize, 0, pOverLapped6);
		if ( !GetOverlappedResult(g_hFile_10019FF8, pOverLapped6, &NumberOfBytesTransferred, 1) )
		{
			LastError = GetLastError();
			if ( LastError == 0xE0000109 )
				dwRetError = ERROR_TIMEOUT;
		}
	}
	else
	{
		dwRetError = ERROR_NO_SYSTEM_RESOURCES;
	}
	LastError = dwRetError;

	if ( LastError )
	{
		if ( LastError == ERROR_MORE_DATA )
		{
			dwRetVal = *pdwTemp;
			LastError = ERROR_INSUFFICIENT_BUFFER;
		}
		else
		{
			
			*(WORD*)&dwRetVal = (WORD)dwVal14;
		}
	
	}
	else
	{
	
		if ( wSize >= NumberOfBytesTransferred && pdwIn )
		{
			if ( pdwTemp == (DWORD*)&dwVal14 )
				memcpy_s(pdwIn, wSize, pdwTemp, NumberOfBytesTransferred);
				
			
		}
		else
		{
			LastError = ERROR_INSUFFICIENT_BUFFER;
		}

		if ( dwFlag == 1 )
		{
			*pdwIn += (int)pdwIn;
	
		}
		else if ( dwFlag == 2 && pdwIn[1] && *(WORD*)pdwIn)
		{
			
			do
			{
				DWORD dwFlag = 0;
				dwFlag = *(DWORD*)(nOffset + pdwIn[1] + 12);
				if ( dwFlag )
					*(DWORD*)(nOffset + pdwIn[1] + 12) = nOffset + dwFlag + pdwIn[1] + 8;
				
				dwFlag = *(DWORD*)(nOffset + pdwIn[1] + 20);
				if ( dwFlag )
					*(DWORD*)(nOffset + pdwIn[1] + 20) = nOffset + dwFlag + pdwIn[1] + 16;
				
				dwFlag = *(PDWORD )(nOffset + pdwIn[1] + 28);
				if ( dwFlag )
					*(DWORD*)(nOffset + pdwIn[1] + 28) = nOffset + dwFlag + pdwIn[1] + 24;
				++i;
				nOffset += 32;
			}
			while ( i < *(WORD*)pdwIn );
		}
		
	}

	if ( dwVal4 )
		*dwVal4 =(WORD)NumberOfBytesTransferred;
	return LastError;
}

LPVOID		sub_10005A10(LPVOID lpMem)
{
	PDWORD  pTemp = (PDWORD )lpMem;
	if (pTemp[6])
		HeapFree(g_hHeap_1001ADE8, 0, (LPVOID)pTemp[6]);
	pTemp[6] = 0;
	return lpMem;
}

LPVOID sub_100052E0(PBYTE pbAddr, DWORD dwClassAddr, PDWORD  pdwOutBuff, DWORD dwFlag)
{
	PControlDevice30 pCtrlDev = (PControlDevice30)pbAddr;
	pCtrlDev->dwOutBuffer[0] = pdwOutBuff[0];
	pCtrlDev->dwOutBuffer[1] = pdwOutBuff[1];
	pCtrlDev->dwOutBuffer[2] = pdwOutBuff[2];
	pCtrlDev->dwOutBuffer[3] = pdwOutBuff[3];
	pCtrlDev->dwOutBuffer[4] = pdwOutBuff[4];
	pCtrlDev->lpClass = (LPVOID)dwClassAddr;
	pCtrlDev->dwUnk18 = 0;
	pCtrlDev->dwUnk1C = 0;
	pCtrlDev->dwUnk20 = 0;
	pCtrlDev->dwUnk24 = 0;
	pCtrlDev->dwFlag = dwFlag;
	pCtrlDev->dwUnk2C = 0;
	
	return pbAddr;
}

BOOL sub_10005320(PControlDevice30 lpParam)
{
	PControlDevice30 pVal = (PControlDevice30)lpParam;
	DWORD dwVal1;
	DWORD dwBytes;
	CCmos* pCmos = NULL;	
	CEmbeddedEeprom* pEeprom=NULL;
	DWORD dwRet = 0;
	if(pVal->dwFlag == 0)
		pCmos = (CCmos*)pVal->lpClass;
	else 
		pEeprom = (CEmbeddedEeprom*)pVal->lpClass;

	if(!pVal->dwOutBuffer[4] && pVal->dwOutBuffer[3])
	{
		
		
		if(pVal->dwFlag == 0)
			dwRet = pCmos->sub_10006050(&dwBytes, &dwVal1);
		else 
			dwRet = pEeprom->sub_10005B90(&dwBytes, &dwVal1);

		if(dwRet)
		{
			LPVOID lpTemp1 = HeapAlloc(g_hHeap_1001ADE8, 8, dwBytes);
			PBYTE lpTemp2 = (PBYTE)lpTemp1 + dwBytes;
			if(lpTemp2)
			{
				
				if(pVal->dwFlag == 0)
					dwRet = pCmos->sub_10005FF0(0, (BYTE*)lpTemp1, dwBytes);
				else 
					dwRet = pEeprom->sub_10005C90(0, (BYTE*)lpTemp1, dwBytes);
				if(dwRet)
				{
					PBYTE lpTemp3 = (PBYTE)lpTemp1 + (2*(*(BYTE*)((BYTE*)lpTemp1+4)));
					if(lpTemp3 < lpTemp2)
					{
						while ( *(WORD*)((PBYTE)lpTemp3 + 1) )
						{
							if ( *(PBYTE)lpTemp3 == 0xF0 && *(WORD*)((PBYTE)lpTemp3 + 3) == 0xAD2C && *(DWORD*)((PBYTE)lpTemp3 + 6) == 0x52535524 )
							{
						
								pVal->dwOutBuffer[4] = 2 * (WORD)((*(PWORD)((PBYTE)lpTemp3 + 1))<<8) - 14;;
								pVal->dwOutBuffer[3] = (PBYTE)lpTemp3 - (PBYTE)lpTemp1 + 14;
								pVal->dwUnk2C= (PBYTE)lpTemp3 - (PBYTE)lpTemp1 + 12;
								if ( !pVal->dwFlag )
								{
									
									pVal->dwUnk18 = (DWORD)HeapAlloc(g_hHeap_1001ADE8, 8, pVal->dwOutBuffer[4]);
									if ( pVal->dwUnk18 )
									{
										memcpy((void*)pVal->dwUnk18 ,(void*)(lpTemp3 + 14), pVal->dwOutBuffer[4]);
										*(WORD*)((PBYTE)lpParam + 28) = (*((PWORD)lpTemp3 + 6))<<8;
										*(DWORD*)((PBYTE)lpParam + 32) = (*(PBYTE)lpTemp3) & 1;
									}
								}
								break;
							}
							DWORD val = (2 * ((*(PWORD)((PBYTE)lpTemp3 + 1))<<8));
							(PBYTE)lpTemp3 += val;
							if ( lpTemp3 >= lpTemp2 )
								break;
						}
					}
					
					HeapFree(g_hHeap_1001ADE8, 0, lpTemp1);
				}

			}
		}
	}

	if ( !pVal->dwOutBuffer[4] )
		return 0;
	if ( pVal->dwFlag )
	{
		pVal->dwUnk18 =(DWORD) HeapAlloc(g_hHeap_1001ADE8, 8, pVal->dwOutBuffer[4]);
		if ( pVal->dwUnk18 )
		{
			
			if(pVal->dwFlag == 0)
				dwRet = pCmos->sub_10005FF0((BYTE)pVal->dwOutBuffer[3], (PBYTE)pVal->dwUnk18, pVal->dwOutBuffer[4]);
			else 
				dwRet = pEeprom->sub_10005C90((BYTE)pVal->dwOutBuffer[3], (PBYTE)pVal->dwUnk18, pVal->dwOutBuffer[4]);
			if(!dwRet)
			{ 
				pVal->dwOutBuffer[4] = 0; pVal->dwOutBuffer[3] = 0;
			}
			
		}
	}
	return 1;
}

void sub_10005730()
{
	DWORD dwVal1 = 0, dwVal2 = 0, dwTemp1, dwCnt;
	int i = dwVal1;
	DWORD dwOffset;
	DWORD OutBuffer;
	DWORD NumberOfBytesTransferred;
	DWORD InBuffer;
	DWORD dwLastError = 0;
	if(g_dword_1001AE30)
	{
		InBuffer = 5;
		NumberOfBytesTransferred = 0;
		OutBuffer = 0;
		OVERLAPPED* pRet = (OVERLAPPED* )getTlsValue_10004D00();
		if(pRet)
		{
			DeviceIoControl(g_hFile_10019FF8, 0xEA60E00C, &InBuffer, 4, &OutBuffer, 4, 0, pRet);
			if(!GetOverlappedResult(g_hFile_10019FF8, pRet, &NumberOfBytesTransferred, 1))
			{
				dwLastError = GetLastError();
				if ( dwLastError == 0xE0000109 )
					dwLastError = ERROR_TIMEOUT;
			}
		}
		else
			dwLastError = ERROR_NO_SYSTEM_RESOURCES;

		if(dwLastError == 0)
		{
			OutBuffer = NumberOfBytesTransferred;
			dwOffset = InBuffer-1;
			if(dwOffset==0 && g_DS_0[1] && g_DS_0[0] <= 0)
			{
				dwVal2 = 1;//4
				dwVal1 = 0;
				do{
					dwTemp1 = *(PDWORD )(g_DS_0[1]+dwOffset+0x0C);
					if(dwTemp1)
					{
						dwTemp1 += dwOffset;
						*(PDWORD )(g_DS_0[1]+dwOffset+0x0C)= dwTemp1+g_DS_0[1]+8;
					}
					dwTemp1 = *(PDWORD )(g_DS_0[1]+dwOffset+0x14);
					if(dwTemp1)
					{
						dwTemp1 += dwOffset;
						*(PDWORD )(g_DS_0[1]+dwOffset+0x14)= dwTemp1+g_DS_0[1]+0x10;
					}
					dwTemp1 = *(PDWORD )(g_DS_0[1]+dwOffset+0x1C);
					if(dwTemp1)
					{
						dwTemp1 += dwOffset;
						*(PDWORD )(g_DS_0[1]+dwOffset+0x1C)= dwTemp1+g_DS_0[1]+0x18;
						
					}
					dwCnt = LOWORD(g_DS_0[0]);
					dwVal1++;
					dwOffset += 0x20;
				}while(dwVal1 >dwCnt);
			}
			OutBuffer = NumberOfBytesTransferred;
		}
		

		if(dwLastError == ERROR_MORE_DATA)
		{
			PWORD pHeap = NULL;
			if(pHeap = (PWORD)HeapAlloc(g_hHeap_1001ADE8, HEAP_ZERO_MEMORY, OutBuffer))
			{
				sub_10003430((PDWORD )pHeap,5, (WORD)OutBuffer, 0);

				g_lpMem_1001AE24 = HeapAlloc(g_hHeap_1001ADE8, HEAP_ZERO_MEMORY, sizeof(ControlDevice30)*pHeap[0]);

				PBYTE lpMem  = (PBYTE)g_lpMem_1001AE24;
				if(g_lpMem_1001AE24)
				{
					if(pHeap[0]) OutBuffer = (DWORD)((BYTE*)pHeap+4);

				}

				do
				{
					DWORD temp = *(DWORD*)(OutBuffer+4);
					if(!g_pCEmbeddedEeprom_1001AE28[temp])
					{
						if(temp !=0 )
						{
							if(temp == 1)

								g_pCEmbeddedEeprom_1001AE28[1] = (CStorage*)new CCmos();

						}
						else
						{

							g_pCEmbeddedEeprom_1001AE28[0] = (CStorage*)(new CEmbeddedEeprom());
							if(g_pCEmbeddedEeprom_1001AE28[0])
							{
								((CEmbeddedEeprom*)(g_pCEmbeddedEeprom_1001AE28[0]))->m_dw04 = (DWORD)INVALID_HANDLE_VALUE;
								((CEmbeddedEeprom*)(g_pCEmbeddedEeprom_1001AE28[0]))->m_dw08 = 0;
							}
							else
								g_pCEmbeddedEeprom_1001AE28[0] = NULL;


						}
						
						if(temp ==0) 
						{
							CEmbeddedEeprom* pEmbeddedEeprom = (CEmbeddedEeprom*)g_pCEmbeddedEeprom_1001AE28[0];
							if(!pEmbeddedEeprom->Init_10005D40()){
								delete pEmbeddedEeprom;
								g_pCEmbeddedEeprom_1001AE28[temp] = NULL;
							}
						}
						else if(temp == 1) 
						{
							CCmos* pCmos = (CCmos*)g_pCEmbeddedEeprom_1001AE28[1];
							if(!pCmos->sub_100052A0()){
								delete pCmos;
								g_pCEmbeddedEeprom_1001AE28[temp] = NULL;
							}
						}

						if ( g_pCEmbeddedEeprom_1001AE28[temp] )
						{
							if ( lpMem )
								sub_100052E0(lpMem, (DWORD)g_pCEmbeddedEeprom_1001AE28[temp], (PDWORD )OutBuffer, (temp == 0));

							if ( sub_10005320((PControlDevice30)lpMem) )
							{
								*(WORD*)g_dword_1001AE20++;
								(PBYTE)lpMem += sizeof(ControlDevice30);
							}
							else if ( lpMem )
							{
								sub_10005A10(lpMem);
							}
						}
						
						OutBuffer += 20;
						++i;

					}

				}while(i <pHeap[0]);

				g_dword_1001AE30 = 1;

				HeapFree(g_hHeap_1001ADE8, 0, pHeap);
			}
		}
	}
}
DWORD sub_1000A2B0(LPVOID pParam, HDEVINFO hDevInfo, SP_DEVINFO_DATA* pDevData, DWORD* dwBytes)
{

	BYTE *pbTemp1; 
	DWORD cnt; 
	int nVal; 
	int ret; 
	DWORD result; 
	BYTE* pbData = (BYTE*)pParam;
	result = 0;

	if ( pbData ) pbTemp1 = &pbData[15];
	else	pbTemp1 = 0;
	if ( pbData && pbData[0] > 0x3C ){
		nVal = pbData[0] - 60;
		cnt = 0;
	}
	else{
		nVal = 0;
		cnt = 0;
	}

	do
	{
		ret = 0;
		if ( g_dword_10015BE8[cnt].unk08 )
		{
			LPFnD_HPDPDP pFunc = (LPFnD_HPDPDP)g_dword_10015BE8[cnt].pFunc;
			if ( pFunc(hDevInfo,pDevData, g_dword_10015BF0[cnt],	pbTemp1,	nVal,	(PDWORD )&ret) )
			{
				if ( pParam )
					*(PDWORD )((char *)pParam + g_dword_10015BE8[cnt].unk00) = 0;
				result += ret;
			}
			else
			{
				*(PDWORD )((char *)pParam + g_dword_10015BE8[cnt].unk04) = (DWORD)pbTemp1;
				nVal -= ret;
				pbTemp1 += ret;
				result += ret;
			}
		}
		else if ( pParam )
		{
			PBYTE pTemp = (BYTE *)pParam + g_dword_10015BE8[cnt].unk04;
			LPFnD_HPDPDP pFunc = (LPFnD_HPDPDP)g_dword_10015BE8[cnt].pFunc;
			if ( pFunc(hDevInfo,pDevData,g_dword_10015BE8[cnt].unk08,	pTemp,4,0) )
			{
				*(DWORD*)pTemp = 0;
			}
		}
		cnt++;
	}
	while ( cnt < 9 );
	*dwBytes = result + 0x3C;
	if ( pParam!=NULL && (*(DWORD*)pParam) >= result )
		return 0;
	else
		return 0x7A;
}
DWORD sub_10004E50(	void *a1, 
				   DWORD dwIoControlCode,	
				   void *lpInBuffer,	
				   DWORD nInBufferSize,
				   void *lpOutBuffer,
				DWORD nOutBufferSize, 
				PDWORD  lpNumberOfBytesTransferred)
{
	OVERLAPPED *pOverLapped; 
	DWORD result; 

	pOverLapped = (OVERLAPPED *)getTlsValue_10004D00();
	
	if ( !pOverLapped )
		return ERROR_NO_SYSTEM_RESOURCES;
	DeviceIoControl(a1, dwIoControlCode, lpInBuffer, nInBufferSize, lpOutBuffer, nOutBufferSize, 0, pOverLapped);
	if ( GetOverlappedResult(a1, pOverLapped, lpNumberOfBytesTransferred, 1) )
		return 0;
	result = GetLastError();
	if ( result == 0xE0000109 )
		return ERROR_TIMEOUT;
	return result;
}
DWORD sub_10009F30(wchar_t *Source, void *a2)
{
	DWORD result; // eax
	size_t nLen; // eax
	DWORD dwOut; // [esp+4h] [ebp-4h] BYREF

	result = 87;
	dwOut = 0;
	if ( Source )
	{
		nLen = wcsnlen(Source, 0x104);
		return sub_10004E50(g_hFile_10019FF8, 0xEA60E184, Source, 2 * nLen + 2, a2, 4, &dwOut);
	}
	return result;
}

DWORD sub_1000A180(HDEVINFO hDevInfo)
{
	
	SIZE_T dwBytes; 
	SP_DEVINFO_DATA DeviceInfoData; 
	int cnt = 0;
	LPVOID hHeap = NULL;
	DWORD dwRet = FALSE;
	DeviceInfoData.cbSize = 28;
	DWORD var_24[2];
	if (SetupDiEnumDeviceInfo(hDevInfo, 0, &DeviceInfoData))
	{
		do{
			if( (dwRet = sub_1000A2B0(hHeap, hDevInfo, &DeviceInfoData, &dwBytes))== 0x7A)
			{
				HeapFree((LPVOID)g_hHeap_1001ADE8, 0, hHeap);
			
				hHeap = HeapAlloc(g_hHeap_1001ADE8, 8, dwBytes);
				if(!hHeap){
					HeapFree((LPVOID)g_hHeap_1001ADE8, 0, hHeap);
					SetupDiDestroyDeviceInfoList(hDevInfo);
					return 8;
				}
				dwRet = sub_1000A2B0(hHeap, hDevInfo, &DeviceInfoData, &dwBytes);
			}
			PDWORD  pData= (PDWORD )hHeap;
			pData[0] = dwBytes;
			pData[1] = DeviceInfoData.ClassGuid.Data1;
			pData[2] = DeviceInfoData.ClassGuid.Data2;
			pData[3] = *(PDWORD )(DeviceInfoData.ClassGuid.Data4);
			pData[4] = *(PDWORD )(DeviceInfoData.ClassGuid.Data4 +4);
			if(!dwRet){
				var_24[0] = dwRet;
				if(!sub_10009F30((wchar_t*)pData[7], (void*)var_24))
				{
					g_dword_1001ADF0 = var_24[0];
					break;
				}

			}
			memset(pData, 0, pData[0]);
		
		}while(SetupDiEnumDeviceInfo(hDevInfo, cnt, &DeviceInfoData));
		if(hHeap)
			HeapFree(g_hHeap_1001ADE8, 0, hHeap);
	}
	SetupDiDestroyDeviceInfoList(hDevInfo);
	return 1;
	
}

BOOL sub_10007260()
{
	 
	if ( g_dword_1001ADF0 )
		return 1;
	HDEVINFO hDevInfo;
	if ( (hDevInfo = SetupDiGetClassDevsW(0, L"ACPI", 0, DIGCF_ALLCLASSES | DIGCF_PRESENT)) != INVALID_HANDLE_VALUE)
		sub_1000A180(hDevInfo);
	return 0;

}
int sub_100068E0(PDWORD  pdwBuff1, PDWORD  pdwBuff2)
{
	DWORD i; 
	i = 4;
	while ( pdwBuff2[i] == pdwBuff1[i] )
	{
		i--;
		
		if ( i < 1 )
			return 1;
	}
	return 0;
}
BOOL sub_100069E0()
{
	
	DWORD dwTemp[4]; 
	if ( g_pCSmbus_Def_1001ADEC || sub_10003430(dwTemp, 0, 0x10, 0) )
		return (g_pCSmbus_Def_1001ADEC != 0);
	int i = 0;
	while(1) 
	{
		if ( !sub_100068E0((DWORD*)&g_dword_1001A01C[i], dwTemp) )
		{
			LPFnP_V pFunc = (LPFnP_V)g_dword_1001A01C[i].pFunc;
			CSmbus_Def* pClass = (CSmbus_Def*)pFunc();// call class contructor
			if(pClass)
			{
				if(((CSmbus_Def*)pClass)->sub_10007EE0())// func_off = 4
				{
					g_pCSmbus_Def_1001ADEC = pClass; return TRUE;
				}
				delete pClass;
			}
			
		}
		i++;
		if(i >=1)
			return (g_pCSmbus_Def_1001ADEC != 0);
		
	}
	
	return (g_pCSmbus_Def_1001ADEC != 0);
}

LPVOID sub_10007550()
{
	int i; 
	PDWORD  pdwTemp; 
	DWORD dwOffset; 
	DWORD dwBuff[9];

	if ( sub_10003430(dwBuff, 3, 0x24, 0) )
		return 0;
	i = 0;
	pdwTemp = &g_dword_1001A01C[1].unk08;//g_dword_1001A038;
	dwOffset = 0;
	while ( (*(pdwTemp-2) != dwBuff[1]) || (*(pdwTemp - 1) != dwBuff[2]) || (pdwTemp[0]!= dwBuff[3]) || (pdwTemp[1] != dwBuff[4]) )
	{
		dwOffset += 20;
		++i;
		pdwTemp += 5;
		if ( dwOffset >= 30 )
			return 0;
	}
	LPFnD_V pFunc = (LPFnD_V)g_dword_1001A01C[i].pFunc;// create a CGpioDefaultProxy;
	
	return (LPVOID)pFunc();
}

DWORD		sub_10002E30()
{
	BYTE bOutBuffer[8];
	DWORD ret = 0;
	WaitForSingleObject(g_hObject_1001ADE0, INFINITE);
	if(g_hFile_10019FF8)
	{
		if((ret = sub_10005000(&g_dword_1001ADDC, L"KCPLD")) || (ret = sub_10004EC0(&g_hFile_10019FF8, (GUID*)g_ClassGuid_10015A3C))) 
			{ ReleaseMutex(g_hObject_1001ADE0);	return ret;}
		if((ret = sub_100031D0(bOutBuffer)))
		{
			CloseHandle(g_hFile_10019FF8);
			g_hFile_10019FF8 = INVALID_HANDLE_VALUE;
			if(g_dword_1001ADDC ==0)
				sub_10005070();
			ReleaseMutex(g_hObject_1001ADE0);
			return 1;
		}
		
		if(*(PWORD)bOutBuffer != 5)
		{
			sub_10004FE0();
			if(!g_dword_1001ADDC)
			{
				sub_10005070();
				
			}
			ReleaseMutex(g_hObject_1001ADE0);	return 0x0E0000120;
		}
		sub_10005270();
		sub_10005730();
		sub_10007260();
		sub_100069E0();
		g_pGpioDefaultProxy_1001AD98  = (CGpioDefaultProxy*)sub_10007550();
		sub_10006AD0();

	}
	
	g_dword_1001ADD8++;
	ReleaseMutex(g_hObject_1001ADE0);
	return 0;

}

void		sub_10005A30()
{

	DWORD i; 

	if ( g_dword_1001AE30 == 1 )
	{
		if ( LOWORD(*g_dword_1001AE20) )
		{
			PDWORD  p = (PDWORD )(g_lpMem_1001AE24) + 6;// dwUnk18
			do
			{
				if ( p -6 )
				{
					if ( *p )
						HeapFree(g_hHeap_1001ADE8, 0, (LPVOID)*p);
					*p = NULL;
				}
				p += 12;
				
				*(WORD*)g_dword_1001AE20 = LOWORD(*g_dword_1001AE20)-1;
			}
			while ( LOWORD(*g_dword_1001AE20) );
		}
		for ( i = 0; i < 2; ++i )
		{
			if(g_pCEmbeddedEeprom_1001AE28[i])
				delete g_pCEmbeddedEeprom_1001AE28[i];
			g_pCEmbeddedEeprom_1001AE28[i] = NULL;
		
		}
	
		
		if ( g_lpMem_1001AE24 )
			HeapFree(g_hHeap_1001ADE8, 0, g_lpMem_1001AE24);
		g_lpMem_1001AE24 = NULL;
		g_dword_1001AE30 = 0;
	}
	
}
DWORD sub_10005070()
{
	
	SC_HANDLE hManager;
	
	SC_HANDLE hService;
	DWORD LastError; 
	struct _SERVICE_STATUS SvcStatus; 



	hManager = OpenSCManagerW(0, 0, SC_MANAGER_CREATE_SERVICE);
	hService = OpenServiceW(hManager, L"KCPLD", SERVICE_ALL_ACCESS);
	if ( !hService )
		return GetLastError();
	if ( ControlService(hService, 1, &SvcStatus) )
	{
		CloseServiceHandle(hService);
		return 0;
	}
	else
	{
		LastError = GetLastError();
		CloseServiceHandle(hService);
		return LastError;
	}
}
int sub_10002F70()
{
	WaitForSingleObject(g_hObject_1001ADE0, 0xFFFFFFFF);
	if ( g_dword_1001ADD8 )
	{
		g_dword_1001ADD8--;
		if ( g_dword_1001ADD8==0 )
		{
			sub_10006E10();
			
			if(g_pGpioDefaultProxy_1001AD98)
			{
				delete g_pGpioDefaultProxy_1001AD98;
			}
			if ( g_pCSmbus_Def_1001ADEC )
			{
				((CSmbus_Def*)g_pCSmbus_Def_1001ADEC)->sub_10007F80();
				
				if ( g_pCSmbus_Def_1001ADEC ){
					delete ((CSmbus_Def*)g_pCSmbus_Def_1001ADEC);
				}
				g_pCSmbus_Def_1001ADEC = NULL;
			}
			sub_10005A30();
			CloseHandle(g_hFile_10019FF8);
			g_hFile_10019FF8 = INVALID_HANDLE_VALUE;
			if ( !g_dword_1001ADDC )
				sub_10005070();
		}
	}
	ReleaseMutex(g_hObject_1001ADE0);
	return 1;
	
}
BOOL ReleaseDll_10004C10()
{
	HANDLE *hRet; 
	HANDLE result; 

	if(g_dword_1001ADD8)
	{
		do{
			sub_10002F70();
		}
		while ( g_dword_1001ADD8 );
	}
	hRet = (HANDLE *)TlsGetValue(g_dwTlsIndex_10019FFC);
	
	if ( hRet )
	{
		if ( hRet[4] )
			CloseHandle(hRet[4]);
		HeapFree(g_hHeap_1001ADE8, 0, (LPVOID)hRet);
		TlsSetValue(g_dwTlsIndex_10019FFC, 0);
	}
	TlsFree(g_dwTlsIndex_10019FFC);
	DeleteCriticalSection(&g_CriticalSection_1001AD9C);
	if ( g_hObject_1001ADE0 )
		CloseHandle(g_hObject_1001ADE0);
	result = g_hHeap_1001ADE8;
	if ( g_hHeap_1001ADE8 )
		return HeapDestroy(g_hHeap_1001ADE8);
	return FALSE;
}
BOOL releaseTlsValue_10004CB0()
{
	PDWORD result; 
	result = (PDWORD )TlsGetValue(g_dwTlsIndex_10019FFC);
	
	if ( result )
	{
		if ( result[4] )
			CloseHandle((HANDLE)result[4]);
		HeapFree(g_hHeap_1001ADE8, 0, (LPVOID)result);
		return TlsSetValue(g_dwTlsIndex_10019FFC, 0);
	}
	return FALSE;
}

BOOL sub_10004B60(void)
{
	BOOL result; 

	g_hHeap_1001ADE8 = HeapCreate(4, 0, 0);
	if ( g_hHeap_1001ADE8 && (g_hObject_1001ADE0 = CreateMutexW(0, 0, L"JIDA32_MUTEX_D3FBDCCE-066A-4658-BC5B-0E0B6F786417")) != 0 )
	{
		InitializeCriticalSection(&g_CriticalSection_1001AD9C);
		result = TRUE;
		g_dword_1001ADE4 = TRUE;
	}
	else
	{
		result = g_dword_1001ADE4;
		if ( !g_dword_1001ADE4 )
		{
			DeleteCriticalSection(&g_CriticalSection_1001AD9C);
			if ( g_hObject_1001ADE0 )
				CloseHandle(g_hObject_1001ADE0);
			if ( g_hHeap_1001ADE8 )
				HeapDestroy(g_hHeap_1001ADE8);
			return g_dword_1001ADE4;
		}
	}
	return result;
}

OVERLAPPED*  getTlsValue_10004D00(void)
{
	OVERLAPPED* result;

	HANDLE EventW; 

	result = (OVERLAPPED*)TlsGetValue(g_dwTlsIndex_10019FFC);
	if ( !result )
	{
		result = (OVERLAPPED*)HeapAlloc(g_hHeap_1001ADE8, 8, sizeof(OVERLAPPED));
		
		if ( result )
		{
			result->Internal = 0;
			result->InternalHigh = 0;
			result->Offset = 0;
			result->OffsetHigh = 0;
			result->hEvent = NULL;
			EventW = CreateEventW(0, 0, 0, 0);
			result->hEvent = EventW;
			if ( EventW )
			{
				TlsSetValue(g_dwTlsIndex_10019FFC, (LPVOID)result);
				return result;
			}
			else
			{
				HeapFree(g_hHeap_1001ADE8, 0, (LPVOID)result);
				return NULL;
			}
		}
	}
	return result;
}

BOOL InitDll_10004BE0(HMODULE hInstDll)
{
	g_hmod_1001ADB4 = hInstDll;
	if ( g_hmod_1001ADE4 || sub_10004B60() != 0 )
	{
		g_dwTlsIndex_10019FFC = TlsAlloc();
		return (getTlsValue_10004D00() != 0);
	}
	return FALSE;
}


///EApiBoardGetStringA//////////////////////////////////////////////////////////////////////////
int  sub_100032B0(PDWORD pdwArg1)
{
	int result; 
	void *lpTmp; 
	int nTmp2; 
	int nTmp3; 
	LPVOID lpMem; 

	nTmp3 = 161;
	lpMem = 0;
	result = sub_10006240((DWORD*)&lpMem, 161);
	if ( !result )
	{
		lpTmp = lpMem;
		if ( *((PDWORD )lpMem + 6) == -1 && *((PDWORD )lpMem + 7) == -1 )
		{
			nTmp2 = 50;
		}
		else
		{
			*pdwArg1 = *((PDWORD )lpMem + 6);
			nTmp2 = 0;
		}
		if ( lpMem )
			HeapFree(g_hHeap_1001ADE8, 0, lpTmp);
		return nTmp2;
	}
	return result;
}

int sub_100020F0(DWORD dwVal)
{
	int result; 
	DWORD dwTemp1; 
	DWORD dwTemp2; 

	result = 0xFFFFF0FF;
	if ( dwVal <= 0x3E3 )
	{
		if ( dwVal == 995 )
			return 0x80000001;
		if ( dwVal <= 0x57 )
		{
			if ( dwVal == 0x57 )
				return 0xFFFFFEFF;
			switch ( dwVal )
			{
			case 0x00:
				result = 0;
				break;
			case 0x08:
				result = 0xFFFFFFFD;
				break;
			case 0x1D:
				result = 0xFFFFFAFE;
				break;
			case 0x32:
				result = 0xFFFFFCFF;
				break;
			default:
				return result;
			}
			return result;
		}
		dwTemp1 = dwVal - 0x7A;
		if ( !dwTemp1 )
			return 0xFFFFF9FF;
		dwTemp2 = dwTemp1 - 0x30;
		if ( dwTemp2 )
		{
			if ( dwTemp2 != 0x13D )
				return result;
			return 0xFFFFFBFF;
		}
		return 0xFFFFFBFD;
	}
	if ( dwVal > 0xE0000104 )
	{
		switch ( dwVal )
		{
		case 0xE0000105:
			result = 0x80000003;
			break;
		case 0xE0000106:
			result = 0xFFFFFFFF;
			break;
		case 0xE0000107:
			result = 0xFFFFFEFA;
			break;
		case 0xE0000108:
			result = 0x80000002;
			break;
		case 0xE000010A:
			return 0xFFFFFBFD;
		default:
			return result;
		}
	}
	else
	{
		if ( dwVal == 0xE0000104 )
			return 0xFFFFFEFC;
		if ( dwVal <= 0x5B4 )
		{
			if ( dwVal == 0x5B4 )
				return 0xFFFFFBFE;
			if ( dwVal != 0x424 )
				return result;
			return 0xFFFFFBFF;
		}
		switch ( dwVal )
		{
		case 0xE0000101:
			return 0xFFFFFBFD;
		case 0xE0000102:
			return 0xFFFFFEFB;
		case 0xE0000103:
			return 0xFFFFFEFD;
		}
	}
	return result;
}

int sub_10001EE0(PBYTE pbOutBuffer, PDWORD pdwOutVal)
{
	void *lpTemp; 
	const char *pszStr; 
	DWORD nLen; 
	int nRet;
	LPVOID lpMem;
	DWORD dwTemp1;
	lpMem = 0;
	nRet = sub_10006240((PDWORD )&lpMem, 2);
	if ( nRet )
		return sub_100020F0(nRet);
	lpTemp = lpMem;
	if ( *((PDWORD )lpMem + 2) )
	{
		pszStr = (const char *)*((PDWORD )lpMem + 2);
		if ( pszStr )
			nLen = strlen(pszStr);
		else
			nLen = 0;
		dwTemp1 = nLen + 1;
		if ( pbOutBuffer && dwTemp1 <= *pdwOutVal )
		{
			sub_10004DB0((BYTE*)&lpMem, nLen + 1, pbOutBuffer);
			*pdwOutVal = dwTemp1;
			nRet = 0;
		}
		else
		{
			*pdwOutVal = dwTemp1;
			nRet = 0xFFFFF9FF;
		}
	}
	else
	{
		nRet = 0xFFFFFBFF;
	}
	if ( lpMem )
		HeapFree(g_hHeap_1001ADE8, 0, lpMem);
	return nRet;
}

int sub_10003310(char InBuffer, DWORD* lpOutBuffer, DWORD DestinationSize, PDWORD pdwRet)
{
	PDWORD pdwTemp1; 
	PDWORD p_Source; 
	OVERLAPPED *pOverLapped1; 
	OVERLAPPED *pOverLapped2; 
	DWORD LastError; 
	int nRetCode; 
	DWORD dwTempVal; 
	DWORD Source; 
	DWORD NumberOfBytesTransferred; 
	DWORD nOutBufferSize; 
	DWORD dwTempVal2; 

	pdwTemp1 = (PDWORD )lpOutBuffer;
	NumberOfBytesTransferred = 0;
	Source = 0;
	dwTempVal2 = 0;
	if ( lpOutBuffer && DestinationSize >= 4 )
	{
		nOutBufferSize = DestinationSize;
		p_Source = (PDWORD )lpOutBuffer;
		dwTempVal2 = *(PDWORD )lpOutBuffer;
	}
	else
	{
		p_Source = &Source;
		nOutBufferSize = 4;
	}
	
	lpOutBuffer = 0;
	pOverLapped1 = (OVERLAPPED *)getTlsValue_10004D00();
	pOverLapped2 = pOverLapped1;
	if ( pOverLapped1 )
	{
		DeviceIoControl(g_hFile_10019FF8, 0xEA606008, &InBuffer, 4, p_Source, nOutBufferSize, 0, pOverLapped1);
		if ( !GetOverlappedResult(g_hFile_10019FF8, pOverLapped2, &NumberOfBytesTransferred, 1) )
		{
			LastError = GetLastError();
			if ( LastError != 0xE0000109 )
			{	
				*lpOutBuffer = ERROR_TIMEOUT;
			}
		}
	}
	else
	{
		*lpOutBuffer = ERROR_NO_SYSTEM_RESOURCES;
	}
	LastError = *lpOutBuffer;

	nRetCode = LastError;
	if ( LastError )
	{
		if ( LastError == ERROR_MORE_DATA )
		{
			dwTempVal = *p_Source;
			nRetCode = ERROR_INSUFFICIENT_BUFFER;
			if ( p_Source == pdwTemp1 )
				*pdwTemp1 = dwTempVal2;
		}
		else
		{
			dwTempVal = Source;
		}
	}
	else
	{
		dwTempVal = NumberOfBytesTransferred;
		if ( DestinationSize >= NumberOfBytesTransferred && pdwTemp1 )
		{
			if ( p_Source == &Source )
			{
				memcpy_s(pdwTemp1, DestinationSize, &Source, NumberOfBytesTransferred);
				dwTempVal = NumberOfBytesTransferred;
			}
		}
		else
		{
			nRetCode = ERROR_INSUFFICIENT_BUFFER;
		}
	}
	if ( pdwRet )
		*pdwRet = dwTempVal;
	return nRetCode;
}

int sub_100024D0(BYTE *lpOutBuffer, PDWORD pdwVal)
{
	CHAR *pszTemp1; 
	DWORD dwRet; 
	int nStrLen; 
	int nTemp2; 
	CHAR szStr2[12];
	LPCWCH lpWideCharStr; 
	DWORD dwBytes; 

	pszTemp1 = 0;
	dwBytes = 0;
	dwRet = sub_10003310(1, 0, 0, &dwBytes);
	if ( dwRet != ERROR_INSUFFICIENT_BUFFER )
		return sub_100020F0(dwRet);
	if ( (dwBytes >> 1) <= *pdwVal )
	{
		lpWideCharStr = (const WCHAR *)HeapAlloc(g_hHeap_1001ADE8, 8, dwBytes);
		if ( lpWideCharStr )
		{
			sub_10003310(1, (DWORD*)lpOutBuffer, *pdwVal, &dwBytes);
			nStrLen = 2 * wcslen(lpWideCharStr) + 2;
			if ( szStr2 )
			{
				szStr2[0] = 0;
				if ( WideCharToMultiByte(0, 0, lpWideCharStr, -1, szStr2, nStrLen, 0, 0) )
					pszTemp1 = szStr2;
			}
			nTemp2 = *pdwVal;
			if ( pszTemp1 && lpOutBuffer && nTemp2 > 0 )
				sub_10004B10((BYTE*)pszTemp1, nTemp2, lpOutBuffer);
			*pdwVal = dwBytes;
			HeapFree(g_hHeap_1001ADE8, 0, (LPVOID)lpWideCharStr);
			return 0;
		}
		else
		{
			return 0xFFFFFFFD;
		}
	}
	else
	{
		*pdwVal = dwBytes >> 1;
		return 0xFFFFF9FF;
	}
}

int sub_10001F90(PBYTE pbOut, PDWORD pdwLen)
{
	int nRet; 
	
	const char *pszStr;
	DWORD nStrLen;
	int nRetCode; 
	LPVOID lpMem; 

	lpMem = 0;
	nRet = sub_10006240((DWORD*)&lpMem, 2);
	if ( nRet )
		return sub_100020F0(nRet);
	if ( *((PDWORD )lpMem + 5) )
	{
		pszStr = (const char *)*((PDWORD )lpMem + 5);
		if ( pszStr )
			nStrLen = strlen(pszStr);
		else
			nStrLen = 0;
		
		if ( pbOut && (nStrLen + 1) <= *pdwLen )
		{
			sub_10004DB0((BYTE*)pszStr, nStrLen + 1, pbOut);
			*pdwLen = nStrLen + 1;
			nRetCode = 0;
		}
		else
		{
			*pdwLen = nStrLen + 1;
			nRetCode = 0xFFFFF9FF;
		}
	}
	else
	{
		nRetCode = 0xFFFFFBFF;
	}
	if ( lpMem )
		HeapFree(g_hHeap_1001ADE8, 0, lpMem);
	return nRetCode;
}

int sub_10002040(PBYTE pbOut, PDWORD pdwArg2)
{
	int nVal1; 
	const char *pszStr; 
	DWORD nStrLen;
	int nRetCode; 
	LPVOID lpMem;
	
	lpMem = 0;
	nVal1 = sub_10006240((PDWORD )&lpMem, 0);
	if ( nVal1 )
		return sub_100020F0(nVal1);
	
	if ( *((PDWORD )lpMem + 3) )
	{
		pszStr = (const char *)*((PDWORD )lpMem + 3);
		if ( pszStr )
			nStrLen = strlen(pszStr);
		else
			nStrLen = 0;
		
		if ( pbOut && (nStrLen + 1) <= *pdwArg2 )
		{
			sub_10004DB0((BYTE*)pszStr, nStrLen + 1, pbOut);
			*pdwArg2 = nStrLen + 1;
			nRetCode = 0;
		}
		else
		{
			*pdwArg2 = nStrLen + 1;
			nRetCode = 0xFFFFF9FF;
		}
	}
	else
	{
		nRetCode = 0xFFFFFBFF;
	}
	if ( lpMem)
		HeapFree(g_hHeap_1001ADE8, 0, lpMem);
	return nRetCode;
}
int sub_100050E0(char bParam1, PDWORD  pdwParam2, WORD wParam3, PWORD pdwRetVal)
{
	PDWORD p_Source; 
	
	OVERLAPPED *pOverLapped1; 

	DWORD LastError; 
	int nRetCode; 
	int nTmp1; 
	char InBuffer[4]; 
	DWORD dwErrCode; 
	int Source; 
	DWORD NumberOfBytesTransferred;
	DWORD nOutBufferSize; 
	int nTmp2; 

	NumberOfBytesTransferred = 0;
	Source = 0;
	nTmp2 = 0;
	InBuffer[0] = bParam1;
	InBuffer[1] = 0;
	if ( pdwParam2 && wParam3 >= 4)
	{
		p_Source = pdwParam2;
		nOutBufferSize = wParam3;
		nTmp2 = *pdwParam2;
	}
	else
	{
		p_Source = (PDWORD )&Source;
		nOutBufferSize = 4;
	}
	dwErrCode = 0;
	pOverLapped1 = (OVERLAPPED *)getTlsValue_10004D00();
	
	if ( pOverLapped1 )
	{
		DeviceIoControl(g_hFile_10019FF8, 0xEA606020, InBuffer, 2, p_Source, nOutBufferSize, 0, pOverLapped1);
		if ( !GetOverlappedResult(g_hFile_10019FF8, pOverLapped1, &NumberOfBytesTransferred, 1) )
		{
			LastError = GetLastError();
			if ( LastError == 0xE0000109 )
			{	
				dwErrCode = ERROR_TIMEOUT;
			}
		}
	}
	else
	{
		dwErrCode = ERROR_NO_SYSTEM_RESOURCES;
	}
	LastError = dwErrCode;

	nRetCode = LastError;
	if ( LastError )
	{
		if ( LastError == ERROR_MORE_DATA )
		{
			nTmp1 = *p_Source;
			nRetCode = ERROR_INSUFFICIENT_BUFFER;
			if ( p_Source == pdwParam2 )
				*pdwParam2 = nTmp2;
		}
		else
		{
			nTmp1 = Source;
		}
	}
	else
	{
		if ( wParam3 >= NumberOfBytesTransferred && pdwParam2 )
		{
			if ( p_Source == (PDWORD )&Source )
			{
				memcpy_s(pdwParam2, wParam3, &Source, NumberOfBytesTransferred);
				nTmp1 = NumberOfBytesTransferred;
				
			}
		}
		else
		{
			nRetCode = ERROR_INSUFFICIENT_BUFFER;
		}
		nTmp1 = NumberOfBytesTransferred;
	}

	if ( pdwRetVal )
		*pdwRetVal = (WORD)nTmp1;
	return nRetCode;
}
int sub_100068A0(PBYTE pbBuff1, PBYTE pbBuff2)
{
	BYTE *pbTemp1; 
	int result; 
	PBYTE pbEnd;

	pbTemp1 = (BYTE *)(pbBuff1 + *(PBYTE)(pbBuff1 + 1));
	result = 0;
	pbEnd = pbBuff2 - 1;
	if ( *pbTemp1 || pbTemp1[1] )
	{
		for ( result = 1; pbTemp1 < pbEnd; ++result )
		{
			if ( !*pbTemp1 && !pbTemp1[1] )
				break;
			++pbTemp1;
		}
	}
	return result;
}
int  sub_10006330(PBYTE pbSrc, PBYTE pbBuff)
{
	BYTE *pbRet1; 
	BYTE *pbRet2; 
	char bTemp1; 
	SHORT wTemp3; 
	int result; 

	pbRet1 = sub_10006820(4, pbSrc, (BYTE *)(pbBuff + 8), (BYTE *)(pbBuff + 72));
	pbRet2 = sub_10006820(5, pbSrc, (BYTE *)(pbBuff + 12), pbRet1);
	*(PWORD)(pbBuff + 16) = *(PWORD)(pbSrc + 6);
	sub_10006820(8, pbSrc, (BYTE *)(pbBuff + 20), pbRet2);
	*(PDWORD )(pbBuff + 24) = (*(char *)(pbSrc + 9) + 1) << 16;
	*(PDWORD )(pbBuff + 28) = *(PDWORD )(pbSrc + 10);
	*(PWORD)(pbBuff + 36) = *(PWORD)(pbSrc + 14);
	*(PWORD)(pbBuff + 38) = *(PWORD)(pbSrc + 16);
	bTemp1 = *(BYTE *)(pbBuff + 5) - 18;
	*(BYTE *)(pbBuff + 34) = *(BYTE *)(pbBuff + 5) - 18;
	if ( !bTemp1 )
		return 1;

	wTemp3 = *(BYTE *)(pbSrc + 18);
	*(PWORD)(pbBuff + 32) = wTemp3;
	if ( bTemp1 == 1 )
		return 1;
	bTemp1--;
	
	*(PWORD)(pbBuff + 32) = wTemp3 | (*(BYTE *)(pbSrc + 19) << 8);
	if ( bTemp1 == 1 )
		return 1;
	bTemp1--;
	
	*(BYTE *)(pbBuff + 40) = *(BYTE *)(pbSrc + 20);
	if ( bTemp1 == 1 )
		return 1;
	bTemp1--;
	
	*(BYTE *)(pbBuff + 41) = *(BYTE *)(pbSrc + 21);
	if ( bTemp1 == 1 )
		return 1;
	bTemp1--;
	*(BYTE *)(pbBuff + 42) = *(BYTE *)(pbSrc + 22);
	result = 1;
	if ( bTemp1 != 1 )
		*(BYTE *)(pbBuff + 43) = *(BYTE *)(pbSrc + 23);
	return result;
}
int  sub_100063F0(PBYTE pbBuff1, PBYTE pbBuff2)
{
	char bVal; 
	PBYTE pbTmp1; 
	BYTE *pbRet; 
	char bVal2;
	

	bVal = *(BYTE *)(pbBuff1 + 5);
	pbTmp1 = pbBuff1 + 8;
	pbRet = sub_10006820(4, pbBuff2, (BYTE *)(pbBuff1 + 8), (BYTE *)(pbBuff1 + 72));
	pbRet = sub_10006820(5, pbBuff2, (BYTE *)(pbTmp1 + 4), pbRet);
	pbRet = sub_10006820(6, pbBuff2, (BYTE *)(pbTmp1 + 8), pbRet);
	pbRet = sub_10006820(7, pbBuff2, (BYTE *)(pbTmp1 + 12), pbRet);
	
	bVal2 = bVal - 8;
	if ( bVal != 8 )
	{
		*(PDWORD )(pbTmp1 + 16) = *(PDWORD )(pbBuff2 + 8);
		*(PWORD)(pbTmp1 + 20) = *(PWORD)(pbBuff2 + 12);
		*(PWORD)(pbTmp1 + 22) = *(PWORD)(pbBuff2 + 14);
		memcpy_s((void *const)(pbTmp1 + 24), 8, (const void *const)(pbBuff2 + 16), 8u);
		
		*(PDWORD )(pbTmp1 + 32) = *(BYTE *)(pbBuff2 + 24);
		if ( bVal2 != 17 )
		{
			bVal2 -= 17;
			pbRet = sub_10006820(0x19, pbBuff2, (BYTE *)(pbTmp1 + 36), pbRet);
			if ( bVal2 != 1 )
				sub_10006820(0x1A, pbBuff2, (BYTE *)(pbTmp1 + 40), pbRet);
		}
	}
	return 1;
}
int  sub_10006530(PBYTE pbBuff1, PBYTE pbBuff2)
{
	BYTE* pbTemp1; 
	BYTE *pbRet; 


	char bTmpVal; 

	pbTemp1 = pbBuff1 + 8;
	pbRet = sub_10006820(4, pbBuff2, (BYTE *)(pbBuff1 + 8), (BYTE *)(pbBuff1 + 72));
	*(PDWORD )(pbTemp1 + 4) = *(char *)(pbBuff2 + 5);
	*(PDWORD )(pbTemp1 + 8) = (WORD)(*(char *)(pbBuff2 + 6));
	pbRet = sub_10006820(7, pbBuff2, (BYTE *)(pbTemp1 + 12), pbRet);
	*(PDWORD )(pbTemp1 + 16) = *(PDWORD )(pbBuff2 + 8);
	*(PDWORD )(pbTemp1 + 20) = *(PDWORD )(pbBuff2 + 12);
	pbRet = sub_10006820(0x10, pbBuff2, (BYTE *)(pbTemp1 + 24), pbRet);
	bTmpVal = *(BYTE *)(pbBuff2 + 17);
	if ( bTmpVal < 0 )
	{
		
		*(PWORD)(pbTemp1 + 28) = 100 * (bTmpVal & 0x7F);
	}
	else if ( (bTmpVal & 1) != 0 )
	{
		*(PWORD)(pbTemp1 + 28) = 5000;
	
	}
	else if ( (bTmpVal & 2) != 0 )
	{
		
		*(PWORD)(pbTemp1 + 28) = 3300;
		
	}
	else if ( (bTmpVal & 4) != 0 )
		*(PWORD)(pbTemp1 + 28) = 2900;

	*(PWORD)(pbTemp1 + 30) = *(PWORD)(pbBuff2 + 18);
	*(PWORD)(pbTemp1 + 32) = *(PWORD)(pbBuff2 + 20);
	*(PWORD)(pbTemp1 + 34) = *(PWORD)(pbBuff2 + 22);
	*(PDWORD )(pbTemp1 + 36) = *(BYTE *)(pbBuff2 + 24) & 7;
	pbRet = sub_10006820(0x20, pbBuff2, (BYTE *)(pbTemp1 + 40), pbRet);
	pbRet = sub_10006820(0x21, pbBuff2, (BYTE *)(pbTemp1 + 44), pbRet);
	sub_10006820(0x22, pbBuff2, (BYTE *)(pbTemp1 + 48), pbRet);
	*(BYTE *)(pbTemp1 + 52) = *(BYTE *)(pbBuff2 + 35);
	*(BYTE *)(pbTemp1 + 53) = *(BYTE *)(pbBuff2 + 36);
	*(BYTE *)(pbTemp1 + 54) = *(BYTE *)(pbBuff2 + 37);
	*(PWORD)(pbTemp1 + 56) = *(PWORD)(pbBuff2 + 38);
	return 1;
}
BYTE* sub_10006820(BYTE bVal, PBYTE pbBuff1, BYTE *pbBuff2, BYTE *pbBuff3)
{
	BYTE bTemp1; 
	char *pbTmp;
	DWORD nStrLen; 

	bTemp1 = *(BYTE *)(bVal + pbBuff1);
	pbTmp = (char *)(pbBuff1 + *(BYTE *)(pbBuff1 + 1));
	if ( !bTemp1 )
		return pbBuff3;
	while ( bTemp1 > 1 )
	{
		if ( !*pbTmp++ )
			--bTemp1;
	}
	if ( !pbTmp )
		return pbBuff3;
	nStrLen = strlen(pbTmp) + 1;
	if ( pbBuff2 )
		*pbBuff2 = (BYTE)pbBuff3;
	if ( *pbBuff2 )
	{
		if ( (WORD)nStrLen )
			sub_10004B10((BYTE*)pbTmp, nStrLen, pbBuff2);
	}
	return &pbBuff3[nStrLen];
}

int  sub_10006650(PBYTE pbBuff1, PBYTE pbBuff2)
{
	DWORD dwTmp1; 
	BYTE *pbRet; 


	*(PWORD)(pbBuff2 + 8) = *(PWORD)(pbBuff1 + 8);
	*(PWORD)(pbBuff2 + 10) = *(PWORD)(pbBuff1 + 10);
	dwTmp1 = *(PWORD)(pbBuff1 + 12);
	*(PDWORD )(pbBuff2 + 12) = dwTmp1;
	if ( dwTmp1 == 0x7FFF )
		*(PDWORD )(pbBuff2 + 12) = *(PDWORD )(pbBuff1 + 28);
	*(PDWORD )(pbBuff2 + 16) = *(char *)(pbBuff1 + 14);
	*(BYTE *)(pbBuff2 + 20) = *(BYTE *)(pbBuff1 + 15);
	pbRet = sub_10006820(0x10, pbBuff1, (BYTE *)(pbBuff2 + 24), (BYTE *)(pbBuff2 + 72));
	pbRet = sub_10006820(0x11, pbBuff1, (BYTE *)(pbBuff2 + 28), pbRet);
	*(PDWORD )(pbBuff2 + 32) = *(char *)(pbBuff1 + 18);
	*(PWORD)(pbBuff2 + 60) = *(PWORD)(pbBuff1 + 19);
	*(PWORD)(pbBuff2 + 36) = *(PWORD)(pbBuff1 + 21);
	pbRet = sub_10006820(0x17u, pbBuff1, (BYTE *)(pbBuff2 + 40), pbRet);
	pbRet = sub_10006820(0x18u, pbBuff1, (BYTE *)(pbBuff2 + 44), pbRet);
	pbRet = sub_10006820(0x19u, pbBuff1, (BYTE *)(pbBuff2 + 48), pbRet);
	sub_10006820(0x1Au, pbBuff1, (BYTE *)(pbBuff2 + 52), pbRet);
	*(BYTE *)(pbBuff2 + 56) = *(BYTE *)(pbBuff1 + 27);
	*(PWORD)(pbBuff2 + 58) = *(PWORD)(pbBuff1 + 32);
	return 1;
}
int  sub_10006710(PBYTE pbBuff1, PBYTE pbBuff2)
{
	BYTE *pbRet; 

	*(PDWORD )(pbBuff2 + 8) = *(PDWORD )(pbBuff1 + 4);
	*(BYTE *)(pbBuff2 + 12) = *(BYTE *)(pbBuff1 + 8);
	pbRet = sub_10006820(9, pbBuff1, (BYTE *)(pbBuff2 + 16), (BYTE *)(pbBuff2 + 72));
	pbRet = sub_10006820(0xA, pbBuff1, (BYTE *)(pbBuff2 + 20), pbRet);
	pbRet = sub_10006820(0xB, pbBuff1, (BYTE *)(pbBuff2 + 24), pbRet);
	sub_10006820(0xC, pbBuff1, (BYTE *)(pbBuff2 + 28), pbRet);
	return 1;
}
DWORD64  sub_10004DE0(DWORD64 dwVal)
{
	DWORD64 ret;
	PBYTE pDest = (PBYTE)&ret;
	PBYTE pSrc = (PBYTE)&dwVal;
	
	pDest[7] = pSrc[0];
	pDest[6] = pSrc[1];
	pDest[5] = pSrc[2];
	pDest[4] = pSrc[3];
	pDest[3] = pSrc[4];
	pDest[2] = pSrc[5];
	pDest[1] = pSrc[6];
	pDest[0] = pSrc[7];

	
	return ret;
}
int  sub_10006760(PBYTE pbBuff1, PBYTE pbBuff2)
{
	*(PDWORD )(pbBuff2 + 8) = *(PDWORD )(pbBuff1 + 4);
	*(BYTE *)(pbBuff2 + 12) = *(BYTE *)(pbBuff1 + 8);
	*(DWORD64 *)(pbBuff2 + 16) = sub_10004DE0(*(DWORD64 *)(pbBuff1 + 12));
	*(DWORD64 *)(pbBuff2 + 24) = sub_10004DE0(*(DWORD64 *)(pbBuff1 + 20));
	return 1;
}
int  sub_100067B0(PBYTE pbBuff1, PBYTE pbBuff2)
{
	DWORD dwRet; 

	*(PDWORD )(pbBuff1 + 8) = *(PDWORD )(pbBuff2 + 4);
	*(BYTE *)(pbBuff1 + 12) = *(BYTE *)(pbBuff2 + 8);
	dwRet = *(BYTE *)(pbBuff2 + 9);
	if ( (*(BYTE *)(pbBuff2 + 9) & 3) != 0 )
	{
		if ( (*(BYTE *)(pbBuff2 + 9) & 3) == 1 )
		{
			*(PDWORD )(pbBuff1 + 16) = 1;
		}
		else if ( (*(BYTE *)(pbBuff2 + 9) & 3) == 2 )
		{
			*(PDWORD )(pbBuff1 + 16) = 2;
		}
		else
		{
			*(PDWORD )(pbBuff1 + 16) = -1;
		}
	}
	else
	{
		*(PDWORD )(pbBuff1 + 16) = 0;
	}
	*(PDWORD )(pbBuff1 + 20) = (dwRet >> 2) & 1;
	*(BYTE *)(pbBuff1 + 25) = *(BYTE *)(pbBuff2 + 10);
	*(PDWORD )(pbBuff1 + 28) = *(PDWORD )(pbBuff2 + 12);
	return 1;
}
int  sub_100064B0(PBYTE pbBuff1, PBYTE pbBuff2)
{
	BYTE bVal1; 
	int result; 
	PBYTE pbTmp; 
	BYTE *pbRet; 


	bVal1 = *(BYTE *)(pbBuff2 + 5);
	result = 0;
	pbTmp  = pbBuff2 + 8;
	if ( bVal1 >= 8u )
	{
		pbRet = sub_10006820(4, pbBuff1, (BYTE *)pbTmp, (BYTE *)(pbBuff2 + 72));
		pbRet = sub_10006820(5, pbBuff1, (BYTE *)(pbTmp + 4), pbRet);
		pbRet = sub_10006820(6, pbBuff1, (BYTE *)(pbTmp + 8), pbRet);
		pbRet = sub_10006820(7, pbBuff1, (BYTE *)(pbTmp + 12), pbRet);
		bVal1 = bVal1 - 8;
		if ( bVal1 )
		{
			sub_10006820(8, pbBuff1, (BYTE *)(pbTmp + 16), pbRet);
			if ( bVal1 != 1 )
				*(BYTE *)(pbTmp + 40) = *(BYTE *)(pbBuff1 + 9);
		}
		return 1;
	}
	return result;
}
int sub_10006070(BYTE * pbBuff1, BYTE *pbBuff2)
{
	int result; 

	switch ( *pbBuff2 )
	{
	case 0:
		result = sub_10006330(pbBuff2, pbBuff1);
		break;
	case 1:
		result = sub_100063F0(pbBuff1, pbBuff2);
		break;
	case 2:
		result = sub_100064B0(pbBuff1, pbBuff2);
		break;
	case 4:
		result = sub_10006530(pbBuff1, pbBuff2);
		break;
	case 0x11:
		result = sub_10006650(pbBuff2, pbBuff1);
		break;
	case 0xA0:
		result = sub_10006710(pbBuff2, pbBuff1);
		break;
	case 0xA1:
		result = sub_10006760(pbBuff2, pbBuff1);
		break;
	case 0xA2:
		result = sub_100067B0(pbBuff1, pbBuff2);
		break;
	default:
		result = 0;
		break;
	}
	return result;
}

int sub_100061C0( int nVal,	 PDWORD pdwBuff1, PBYTE pbMem, WORD wSize, PWORD pdwRet)
{
	int result; 
	WORD wRetVal; 

	result = 87;
	if ( pbMem && nVal )
	{
		wRetVal = sub_100068A0(pbMem, pbMem + nVal) + 72;
		result = ERROR_INSUFFICIENT_BUFFER;
		if ( pdwBuff1 && wSize >= wRetVal )
		{
			memset(pdwBuff1, 0, wSize);
			*pdwBuff1 = wRetVal;
			*((BYTE *)pdwBuff1 + 4) = *(BYTE *)pbMem;
			*((BYTE *)pdwBuff1 + 5) = *(BYTE *)(pbMem + 1);
			*((PWORD)pdwBuff1 + 3) = *(PWORD)(pbMem + 2);
			result = sub_10006070((PBYTE)pdwBuff1, (BYTE *)pbMem) != 1 ? 0x646 : 0;
		}
		if ( pdwRet )
			*pdwRet = wRetVal;
	}
	return result;
}

int sub_10006240(PDWORD pdwBuff1, BYTE bVal)
{
	int result; 
	void *lpMem;
	int nTmpVal2; 
	
	int nTmpVal1; 
	int nTmpVal3;

	nTmpVal1 = 0;
	nTmpVal3 = 0;
	result = 87;
	if ( pdwBuff1 )
	{
		*pdwBuff1 = 0;
		result = sub_100050E0(bVal, NULL, 0, (WORD*)&nTmpVal1);
		if ( result == ERROR_INSUFFICIENT_BUFFER )
		{
			
			lpMem = HeapAlloc(g_hHeap_1001ADE8, 8, (WORD)nTmpVal1);
			if ( lpMem )
			{
				sub_100050E0(bVal, (PDWORD )lpMem, nTmpVal1, (WORD*)&nTmpVal1);

				nTmpVal2 = sub_100061C0(nTmpVal1, 0, (PBYTE)lpMem, 0, (WORD*)&nTmpVal3);//int@<ecx>, PDWORD @<edi>, int@<esi>, WORD, PWORD
				if ( nTmpVal2 == ERROR_INSUFFICIENT_BUFFER )
				{
					nTmpVal2 = 8;
					
					*pdwBuff1 = (DWORD)HeapAlloc(g_hHeap_1001ADE8, 8, (WORD)nTmpVal3);
					if ( *pdwBuff1 )
						nTmpVal2 = sub_100061C0(nTmpVal1, pdwBuff1, (PBYTE)lpMem, nTmpVal3, 0);
				}
				HeapFree(g_hHeap_1001ADE8, 0, lpMem);
				return nTmpVal2;
			}
			else
			{
				return 8;
			}
		}
	}
	return result;
}
int sub_10001E30(PBYTE pbOut, PDWORD pdwBuff2)
{
	int nRet1; 
	
	const char *pbStr1; 
	DWORD nStrLen; 
	int nRetCode; 
	LPVOID lpMem; 


	lpMem = 0;
	nRet1 = sub_10006240((DWORD*)&lpMem, 2);
	if ( nRet1 )
		return sub_100020F0(nRet1);
	
	if ( *((PDWORD )lpMem + 4) )
	{
		pbStr1 = (const char *)*((PDWORD )lpMem + 4);
		if ( pbStr1 )
			nStrLen = strlen(pbStr1);
		else
			nStrLen = 0;
	
		if ( pbOut && (nStrLen + 1 )<= *pdwBuff2 )
		{
			sub_10004DB0((BYTE*)pbStr1, nStrLen + 1, pbOut);
			*pdwBuff2 = nStrLen + 1;
			nRetCode = 0;
		}
		else
		{
			*pdwBuff2 = nStrLen + 1;
			nRetCode = 0xFFFFF9FF;
		}
	}
	else
	{
		nRetCode = 0xFFFFFBFF;
	}
	if ( lpMem )
		HeapFree(g_hHeap_1001ADE8, 0, lpMem);
	return nRetCode;
}
BOOL sub_10004DB0(BYTE *lpOutBuffer, DWORD dwVal, PBYTE pbBuff2)
{
	if(lpOutBuffer && pbBuff2 && (dwVal > 0) && (sub_10004B10(lpOutBuffer, dwVal, pbBuff2) >= 0))
		return TRUE;
	return FALSE;
}
int sub_10004B10(BYTE *pbBuff1, int nVal, BYTE *pbBuff2)
{
	int result; 
	int nFlag; 

	result = 0;
	nFlag = 0x7FFFFFFE;
	if ( nVal )
	{
		while ( nFlag && *pbBuff1 )
		{
			*pbBuff2 = *pbBuff1;
			--nVal;
			++pbBuff2;
			++pbBuff1;
			--nFlag;
			if ( !nVal )
			{
				result = 0x8007007A;
				*(pbBuff2 - 1) = 0;
				return result;
			}
		}
		*pbBuff2 = 0;
	}
	else
	{
		result = 0x8007007A;
		*(pbBuff2 - 1) = 0;
	}
	return result;
}
///EapiBoardGetValue//////////////////////////////////////////////////////////////////////////
int  sub_100023B0(PDWORD pdwBuff1, int nVal)
{
	WORD wVal1; 
	WORD i; 
	int result; 
	PDWORD pdwOffset; 
	DWORD dwRet; 

	wVal1 = (WORD)g_dword_1001AE00[4];
	i = 0;
	result = 0xFFFFFCFF;
	if ( (WORD)g_dword_1001AE00[4] )
	{
		while ( 1 )
		{
			if ( i < (WORD)g_dword_1001AE00[4] )
			{
				pdwOffset = (PDWORD )(g_dword_1001AE00[5] + 20 * i);
				if ( pdwOffset )
				{
					if ( pdwOffset[1] == nVal )
					{
						LPFnU_DDP pFunc =(LPFnU_DDP) (*(PDWORD )*pdwOffset + 20);
						dwRet = pFunc(	pdwOffset[2],	*((PWORD)pdwOffset + 6),	pdwBuff1);
						*pdwBuff1 = *pdwBuff1 * pdwOffset[4] / 1000;
						if ( dwRet )
							break;
					}
				}
			}
			if ( ++i >= wVal1 )
				return 0xFFFFFCFF;
		}
		return 0;
	}
	return result;
}
int			sub_10002440(PDWORD pdwBuff1, DWORD dwVal)
{
	WORD wVal1; 
	WORD i; 
	int result; 
	PDWORD pdwOffset; 
	DWORD dwRet; 
	
	wVal1 = (WORD)g_dword_1001AE00[6];
	i = 0;
	result = 0xFFFFFCFF;
	if ( (WORD)g_dword_1001AE00[6] )
	{
		while ( 1 )
		{
			if ( i < (WORD)g_dword_1001AE00[6] )
			{
				pdwOffset = (PDWORD )(g_dword_1001AE00[7] + 20 * i);
				if ( pdwOffset )
				{
					if ( pdwOffset[1] == dwVal )
					{
						LPFnU_DDP pFunc = (LPFnU_DDP)(*(PDWORD )*pdwOffset + 20);
						dwRet = pFunc(
							pdwOffset[2],
							*((PWORD)pdwOffset + 6),
							pdwBuff1);
						*pdwBuff1 = ((*pdwBuff1) * pdwOffset[4]) / 1000;
						if ( dwRet )
							break;
					}
				}
			}
			if ( ++i >= wVal1 )
				return 0xFFFFFCFF;
		}
		return 0;
	}
	return result;
}
int  sub_100022F0(int nVal, PDWORD pdwBuff)
{
	WORD wTmp1; 
	WORD i; 
	int result; 
	PDWORD pdwOffset; 
	int nRet; 
	DWORD dwTmp1;
	int nTmp2;
	
	wTmp1 = (WORD)g_dword_1001AE00[2];
	i = 0;
	result = 0xFFFFFCFF;
	nTmp2 = 0;
	if ( (WORD)g_dword_1001AE00[2] )
	{
		while ( 1 )
		{
			if ( i < (WORD)g_dword_1001AE00[2] )
			{
				pdwOffset = (PDWORD )(g_dword_1001AE00[3] + 20 * i);
				if ( pdwOffset )
				{
					if ( pdwOffset[1] == nVal )
					{
						LPFnU_DDP pFunc = (LPFnU_DDP)(*(PDWORD )*pdwOffset + 20);
						nRet = pFunc(pdwOffset[2],	*((PWORD)pdwOffset + 6),	&nTmp2);
						dwTmp1 = (int)((DWORD64)(0x10624DD3 * nTmp2 * pdwOffset[4]) >> 32) >> 6;
						nTmp2 = nTmp2 * pdwOffset[4] / 1000;
						if ( nRet )
							break;
					}
				}
			}
			if ( ++i >= wTmp1 )
				return 0xFFFFFCFF;
		}
		*pdwBuff = (int)(dwTmp1 + (dwTmp1 >> 31)) / 100 + 2731;
		return 0;
	}
	return result;
}
int  sub_10003250(PDWORD pdwBuff1)
{
	int result; 
	int nRet;
	LPVOID lpMem; 

	
	lpMem = 0;
	result = sub_10006240((DWORD*)&lpMem, 161);
	if ( !result )
	{
		
		if ( *((PDWORD )lpMem + 4) == -1 && *((PDWORD )lpMem + 5) == -1 )
		{
			nRet = 50;
		}
		else
		{
			*pdwBuff1 = *((PDWORD )lpMem + 4);
			nRet = 0;
		}
		if ( lpMem)
			HeapFree(g_hHeap_1001ADE8, 0, lpMem);
		return nRet;
	}
	return result;
}
///eagle
DWORD sub_10003B30(int nSizeDest, int a2, WORD a3, WORD a4, int a5, void *pDest)
{
	DWORD dwAllocSize; 
	BYTE *pAlloc;
	DWORD dwRes;
	BYTE by_9; 
	DWORD NumberOfBytesTransferred; 
	int tmpa2; 

	dwRes = 0x57;
	tmpa2 = a2;
	by_9 = 0;
	if ( !pDest ) return dwRes;
	dwRes = sub_10003D70((DWORD*)&a2, &by_9);
	if (dwRes) return dwRes;
	dwAllocSize = 4 + 0x24 + nSizeDest;
	pAlloc = (BYTE*)HeapAlloc(g_hHeap_1001ADE8, 8, dwAllocSize);
	if (!pAlloc) return dwRes;

	*(DWORD*)pAlloc = a2;
	*(WORD*)(pAlloc + 4) = a3;
	*(DWORD*)(pAlloc + 8) = 1;
	*(BYTE*)(pAlloc+0xC) = by_9;
	*(PDWORD )(pAlloc + 0x10) = 1;
	*(PDWORD )(pAlloc + 0x14) = nSizeDest;
	NumberOfBytesTransferred = 0;
	if ( a5 == 1 )
	{			
		*(PDWORD )(pAlloc + 0x10) = 2;
		*(BYTE *)(pAlloc + 0x18) = a4>>8;
		*(BYTE *)(pAlloc + 0x19) = a4 & 0xFF;
	}
	else
	{
		*(BYTE *)(pAlloc + 0x18) = a4 & 0xFF;
	}
	dwRes = sub_10004E50(g_hFile_10019FF8, 0xEA60E048, pAlloc, dwAllocSize, pAlloc, dwAllocSize, &NumberOfBytesTransferred);
	if ( dwRes )
	{
		if ( tmpa2 != a2 )
		{
			sub_100036F0(a2, 255, 0, 0, 0, 1);
			ReleaseMutex(g_hMutex_1001ADFC);
		}
	}
	else
	{
		dwRes = sub_10005200(*(DWORD*)(pAlloc+0x1C));
		if ( !dwRes )
		{
			memcpy_s(pDest, nSizeDest, pAlloc + 0x28, *(DWORD*)(pAlloc+0x24));
			if ( nSizeDest != *(PDWORD )(pAlloc + 0x24) )
				dwRes = 30;
		}
	}
	HeapFree(g_hHeap_1001ADE8, 0, pAlloc);
	return dwRes;

}
DWORD sub_10003D70(DWORD* pdwArg, BYTE* pbyArg)
{
	BYTE byVal; 
	DWORD dwVal; 
	int nCnt; 
	HANDLE hf; 
	OVERLAPPED *Value; 
	HANDLE hevent;	
	char by_29;
	char Source[4]; 
	DWORD dwRet; 
	DWORD dwres;
	DWORD NumberOfBytesTransferred;
	int InBuffer[3]; 


	*pbyArg = 0;
	if (*pdwArg  > 17)
	{
		*pbyArg = *(BYTE*)pdwArg - 16;
		*pdwArg = 0;
		return 0;
	}
	switch ( *pdwArg - 8 )
	{
	case 0:
		byVal = 1;
		dwVal = 0x70;
	case 1:
		byVal = 2;
		dwVal = 0x70;
	case 2:		
		byVal = 4;
		dwVal = 0x70;
	case 3:
		byVal = 8;
		dwVal = 0x70;
	case 4:
		byVal = 1;
		dwVal = 0x72;
	case 5:
		byVal = 2;
		dwVal = 0x72;
	case 6:
		byVal = 4;
		dwVal = 0x72;		
	case 7:
		byVal = 8;
		dwVal = 0x72;
	default:
		return 0;
	}
	nCnt = 0;	
	dwres = 0;
	by_29 = 3;
	Source[0] = 7;
	Source[1] = byVal;
	Source[2] = 0x7A;
	if ( g_hMutex_1001ADFC )
		WaitForSingleObject(g_hMutex_1001ADFC, 0xFFFFFFFF);
	dwRet = sub_100036F0(1, (WORD)dwVal, Source, 3, &dwres, 0);
	hf = g_hFile_10019FF8;
	if ( dwRet )
	{		
		NumberOfBytesTransferred = 0;
		InBuffer[0] = 1;
		Value = (OVERLAPPED *)TlsGetValue(g_dwTlsIndex_10019FFC);
		if ( Value )
		{
			DeviceIoControl(hf, 0xEA60E050, InBuffer, 0x18, 0, 0, 0, Value);
			if ( !GetOverlappedResult(hf, Value, &NumberOfBytesTransferred, 1) )
				GetLastError();
			ReleaseMutex(g_hMutex_1001ADFC);
			return dwRet;
		}			
		Value = (OVERLAPPED *)HeapAlloc(g_hHeap_1001ADE8, 8, 0x14);
		if ( Value )
		{
			Value->Internal = 0;
			Value->InternalHigh = 0;
			Value->Offset = 0;
			Value->OffsetHigh = 0;
			Value->hEvent = 0;
			hevent = CreateEventW(0, 0, 0, 0);
			Value->hEvent = hevent;
			if ( hevent )
			{
				TlsSetValue(g_dwTlsIndex_10019FFC, Value);
				DeviceIoControl(hf, 0xEA60E050, InBuffer, 0x18, 0, 0, 0, Value);
				if ( !GetOverlappedResult(hf, Value, &NumberOfBytesTransferred, 1) )
					GetLastError();
				ReleaseMutex(g_hMutex_1001ADFC);
				return dwRet;
			}
			HeapFree(g_hHeap_1001ADE8, 0, Value);
		}
		ReleaseMutex(g_hMutex_1001ADFC);
		return dwRet;
	}
	Source[0] = 9;
	do
	{
		if ( dwRet )	break;
		dwRet = sub_10003820(1, 1, (WORD)dwVal, Source, 1, &dwres, &by_29, &NumberOfBytesTransferred, 0);
		if ( by_29 != 4 ) 	break;
		++nCnt;
	}
	while ( nCnt < 3 );

	NumberOfBytesTransferred = 0;
	InBuffer[0] = 1;
	Value = (OVERLAPPED *)TlsGetValue(g_dwTlsIndex_10019FFC);
	if ( !Value )
	{
		Value = (OVERLAPPED *)HeapAlloc(g_hHeap_1001ADE8, 8, 0x14);
		if ( Value )
		{
			Value->Internal = 0;
			Value->InternalHigh = 0;
			Value->Offset = 0;
			Value->OffsetHigh = 0;
			Value->hEvent = 0;
			hevent = CreateEventW(0, 0, 0, 0);
			Value->hEvent = hevent;
			if (!hevent)
			{
				HeapFree(g_hHeap_1001ADE8, 0, Value);
			}
			else
			{
				TlsSetValue(g_dwTlsIndex_10019FFC, Value);	
				DeviceIoControl(hf, 0xEA60E050, InBuffer, 0x18, 0, 0, 0, Value);
				if ( !GetOverlappedResult(hf, Value, &NumberOfBytesTransferred, 1) )
					GetLastError();
			}
		}
	}
	else
	{
		DeviceIoControl(hf, 0xEA60E050, InBuffer, 0x18, 0, 0, 0, Value);
		if ( !GetOverlappedResult(hf, Value, &NumberOfBytesTransferred, 1) )
			GetLastError();
	}

	if ( dwRet ) return dwRet;
	if ( by_29 == 1 )
	{		
		*pdwArg = 1;
	}
	else
	{
		dwRet = 0xE0000108;
	}
	return dwRet;
}
DWORD sub_100036F0(DWORD a1, WORD a2, void *Source, DWORD dwSizeSrc, PDWORD a5, DWORD a6)
{
	DWORD result;
	DWORD dwSize;
	BYTE* pAlloc;
	DWORD dwsubret; 
	BYTE byVal; 
	DWORD dwSavea1; 
	DEVOUT_0C devout;
	DWORD dwBytesReturn = 0;

	dwSavea1 = a1;
	byVal = 0;
	result = sub_10003D70(&a1, &byVal);
	dwSize = 0;

	if ( !result )
	{
		memset(&devout, 0, sizeof(DEVOUT_0C));
		if ( Source )
			dwSize = dwSizeSrc;
		pAlloc = (BYTE*)HeapAlloc(g_hHeap_1001ADE8, 8, dwSize + 0x18);
		if ( pAlloc )
		{
			*(DWORD*)pAlloc = a1;
			*(WORD*)(pAlloc+4) = a2;
			*(DWORD*)(pAlloc+0x8) = a6;
			*(BYTE*)(pAlloc+0xC) = byVal;
			*(DWORD*)(pAlloc+0x10) = dwSize;

			if ( Source )
				memcpy_s(pAlloc + 0x18, dwSize + 0x18, Source, dwSize);
			dwsubret = sub_10004E50(g_hFile_10019FF8, 0xEA60A040, pAlloc, dwSize + 0x18, &devout, 0xC, &dwBytesReturn);
			if ( dwsubret )
			{
				if ( dwSavea1 != a1 )
				{
					sub_100036F0(a1, 255, 0, 0, 0, 1);
					ReleaseMutex(g_hMutex_1001ADFC);
				}
			}
			else
			{
				dwsubret = sub_10005200(devout.nErrCode_0);
				if ( a5 )
					*a5 = devout.nResult_4;
			}
			HeapFree(g_hHeap_1001ADE8, 0, pAlloc);
			return dwsubret;
		}
		else
		{
			return result;
		}
	}
	return result;
}
DWORD sub_10005200(DWORD dwParam) // param ecx
{
	DWORD dwRet; // eax

	dwRet = 0x54F;
	switch ( dwParam )
	{
	case 3:
		dwRet = 0xE000010A;
		break;
	case 4:
		dwRet = 0x1D;
		break;
	case 5:
		dwRet = 0x1E7;
		break;
	case 6:
		dwRet = 0xAA;
		break;
	case 7:
		dwRet = 0;
		break;
	case 8:
		dwRet = 0x5B4;
		break;
	case 9:
		dwRet = 0x4C7;
		break;
	case 0xA:
		dwRet = 0x32;
		break;
	default:
		return dwRet;
	}
	return dwRet;
}

DWORD sub_10003820(DWORD dwArg1, DWORD dwArg2, WORD wArg3, void *Source, DWORD SrcSize, DWORD* pdwArg6, void* Dest,PDWORD pdwArg8,  int nArg9)
{

	DWORD dwRet; 
	BYTE *pAlloc;
	BYTE byVal;
	DWORD dwBytesReturned; 
	int dwtmp; 
	dwtmp = dwArg2;
	byVal = 0;
	if ( !Dest )
		return sub_100036F0(dwArg2, wArg3, Source, SrcSize, pdwArg6, 1);
	dwRet = sub_10003D70(&dwArg2, &byVal);
	if (dwRet) return dwRet;
	DWORD dwTail = (SrcSize + 3) & 0xFFFFFFFC;
	DWORD dwAllocSize = dwTail + dwArg1 + 0x24;
	pAlloc = (BYTE*)HeapAlloc(g_hHeap_1001ADE8, 8, dwAllocSize);
	if (!pAlloc)
	{
		return dwRet;
	}

	dwBytesReturned = 0;
	if ( Source )
	{
		memcpy_s(pAlloc + 0x18, SrcSize, Source, SrcSize);
		*(DWORD*)(pAlloc + 0x10) =  SrcSize;
	}
	else
	{
		*(DWORD*)(pAlloc + 0x10) =  0;
	}
	*(DWORD*)pAlloc = dwArg2;
	*(WORD*)(pAlloc+4) = wArg3;
	*(DWORD*)(pAlloc+0x8) = nArg9;
	*(BYTE*)(pAlloc+0xC) = byVal;
	*(DWORD*)(pAlloc+0x14) = dwArg1;

	dwRet = sub_10004E50(g_hFile_10019FF8,0xEA60E048,	pAlloc, dwAllocSize, pAlloc, dwAllocSize, &dwBytesReturned);
	if ( dwRet )
	{
		if ( dwtmp != dwArg2 )
		{
			sub_100036F0(dwArg2, 255, 0, 0, 0, 1);
			ReleaseMutex(g_hMutex_1001ADFC);
		}
	}
	else
	{
		DWORD* pInfo = (DWORD*)(pAlloc+0x18+dwTail);
		dwRet = sub_10005200(*(DWORD*)pInfo);
		if ( !dwRet )
		{			
			if (*(PDWORD )(pInfo + 4) == SrcSize )
			{
				if ( *(PDWORD )(pInfo + 8) != dwArg1 )
					dwRet = 0x1E;
			}
			else
			{
				dwRet = 0x1D;
			}
			if ( pdwArg6 )
				*(PDWORD )pdwArg6 = *(PDWORD )(pInfo + 4);
			if ( pdwArg8 )
				*pdwArg8 = *(PDWORD )(pInfo + 8);
			memcpy_s(Dest, dwArg1, pAlloc+dwTail+0x24, *(PDWORD )(pInfo + 8));
		}
	}
	HeapFree(g_hHeap_1001ADE8, 0, pAlloc);
	return dwRet;
}

DWORD sub_100039D0(DWORD dwlen, DWORD a2, DWORD a3, WORD a4, WORD a5, void *Source)
{
	DWORD dwRet; 
	int dwAllocSize; 
	BYTE *pAlloc; 
	BYTE *pSub; 
	BYTE byVal; 
	DWORD dwBytesReturn; 
	DWORD tmpa3; 
	DEVOUT_0C devout; 

	dwRet = 0x57;
	tmpa3 = a3;
	byVal = 0;
	if (!Source) return dwRet;

	dwRet = sub_10003D70(&a3, &byVal);
	if (dwRet) return dwRet;
	dwBytesReturn = 0;
	memset(&devout, 0, sizeof(DEVOUT_0C));
	if (a2 != 0)
	{
		dwAllocSize = 1 + 1 + dwlen + 24;
	}
	else dwAllocSize = 1 + dwlen + 24;

	pAlloc = (BYTE *)HeapAlloc(g_hHeap_1001ADE8, 8, dwAllocSize);
	if (!pAlloc) return dwRet;

	*(PDWORD )pAlloc = a3;
	*(PWORD)(pAlloc + 4) = a4;
	*(PDWORD )(pAlloc + 8) = 1;
	*(BYTE *)(pAlloc + 0xC) = byVal;
	*(PDWORD )(pAlloc + 0x10) = dwlen + 1;
	*(PDWORD )(pAlloc + 0x14) = 0;

	if ( a2 == 1 )
	{
		*(PDWORD )(pAlloc + 0x10) = dwlen + 2;
		*(BYTE *)(pAlloc + 0x18) = a5>>8;
		*(BYTE *)(pAlloc + 0x19) = a5 & 0xFF;
		pSub = pAlloc + 0x1A;
	}
	else
	{
		*(BYTE *)(pAlloc + 0x18) = a5 & 0xFF;
		pSub = pAlloc + 0x19;
	}
	memcpy_s(pSub, dwAllocSize, Source, dwlen);
	dwRet = sub_10004E50(g_hFile_10019FF8, 0xEA60A040, pAlloc, dwAllocSize, &devout, 0xC, &dwBytesReturn);
	if ( dwRet )
	{
		if ( tmpa3 != a3 )
		{
			sub_100036F0(a3, 255, 0, 0, 0, 1);
			ReleaseMutex(g_hMutex_1001ADFC);
		}
	}
	else
	{
		dwRet = sub_10005200(devout.nErrCode_0);
	}
	HeapFree(g_hHeap_1001ADE8, 0, pAlloc);
	return dwRet;
}

DWORD sub_10009F80()
{
	OVERLAPPED* pOverlap; 
	DWORD OutBuffer; 
	DWORD InBuffer; 
	DWORD NumberOfBytesTransferred; 

	InBuffer = g_dword_1001ADF0;
	NumberOfBytesTransferred = 0;
	OutBuffer = 0;
	pOverlap = getTlsValue_10004D00();
	if ( pOverlap )
	{
		DeviceIoControl(g_hFile_10019FF8, 0xEA60E188, &InBuffer, 4, &OutBuffer, 4, 0, pOverlap);
		if ( !GetOverlappedResult(g_hFile_10019FF8, pOverlap, &NumberOfBytesTransferred, 1) )
			GetLastError();
	}
	return OutBuffer;
}
DWORD  sub_1000A060(PDWORD pdwOut, DWORD InBuffer, DWORD nOutBufferSize, PDWORD a4)
{
	PDWORD pOutbuf; 
	OVERLAPPED* pOverlap; 
	DWORD result; 
	DWORD dwtmp; 
	DWORD NumberOfBytesTransferred; 
	DWORD dwOut; 

	NumberOfBytesTransferred = 0;
	dwOut = 0;
	if ( pdwOut && nOutBufferSize >= 0x38 )
	{
		pOutbuf = pdwOut;
	}
	else
	{
		pOutbuf = &dwOut;
		nOutBufferSize = 4;
	}

	result = 0;
	pOverlap = getTlsValue_10004D00();
	if ( pOverlap )
	{
		DeviceIoControl(g_hFile_10019FF8, 0xEA60E190, &InBuffer, 4, pOutbuf, nOutBufferSize, 0, pOverlap);
		if ( !GetOverlappedResult(g_hFile_10019FF8, pOverlap, &NumberOfBytesTransferred, 1) )
		{
			result = GetLastError();
			if ( result == 0xE0000109 )				
				result = 0x5B4;
		}
	}
	else
	{
		result = 0x5AA;
	}
	if ( !result )
	{
		if ( NumberOfBytesTransferred == 4 )
		{
			dwtmp = dwOut;
			result = 0x7A;
		}
		else
		{
			dwtmp = *(WORD*)pdwOut;
			pdwOut[13] = pdwOut[13] + (DWORD)pdwOut;		
			pdwOut[12] = pdwOut[12] + (DWORD)pdwOut;
			pdwOut[11] = pdwOut[11] + (DWORD)pdwOut;				
			result = 0;
		}
		if ( a4 )
			*a4 = dwtmp;
	}
	return result;
}
DWORD sub_10009FF0(DWORD InBuffer)
{

	OVERLAPPED *lpOverlap; 
	DWORD OutBuffer; 
	DWORD NumberOfBytesTransferred; 

	OutBuffer = 0;
	NumberOfBytesTransferred = 0;
	lpOverlap = getTlsValue_10004D00();
	if ( lpOverlap )
	{
		DeviceIoControl(g_hFile_10019FF8, 0xEA60E18C, &InBuffer, 4, &OutBuffer, 4, 0, lpOverlap);
		if ( !GetOverlappedResult(g_hFile_10019FF8, lpOverlap, &NumberOfBytesTransferred, 1) )
			GetLastError();
	}
	return OutBuffer;
}
char szHACPI[8] = "HACPI"; 
PDWORD  sub_1000A150()
{
	PDWORD result; // eax

	result = (DWORD*)HeapAlloc(g_hHeap_1001ADE8, 8, 0x14);
	if ( result )
	{
		result[0] = (DWORD)result;
		result[1] = 0;
		result[2] = 4;
		result[3] = (DWORD)szHACPI;
	}
	return result;
}
PDWORD  sub_100070A0(PDWORD  pdwBuf)
{
	if ( pdwBuf && pdwBuf[0] == (DWORD)pdwBuf && !strcmp((char*)pdwBuf[3], "HACPI") )
		return pdwBuf + 0x10;
	else return 0;
}
DWORD sub_100070F0(WCHAR* wszStr)
{
	DWORD dwOutsize; 
	PDWORD  dwRet; // esi
	HDEVINFO hDevInfo; // eax
	DWORD dwinfo; // ebx
	PDWORD pAlloc; // edi
	DWORD dwSubRet; // eax
	DWORD dwTmpSize; // esi
	WCHAR* wszsubstr; // eax
	DWORD dwBytes; 


	dwOutsize = 0;
	dwRet = 0;
	if ( !wszStr )		return 0;
	if ( !g_dword_1001ADF0 )
	{
		hDevInfo = SetupDiGetClassDevsW(0, L"ACPI", 0, DIGCF_ALLCLASSES | DIGCF_PRESENT );
		if ( hDevInfo != (HDEVINFO)-1 )
			sub_1000A180(hDevInfo);
		if ( !g_dword_1001ADF0 )
			return 0;

	}
	dwinfo = sub_10009F80();
	if (!dwinfo ) return 0;

	pAlloc = 0;
	dwBytes = 0;

	while ( 1 )
	{
		dwSubRet = sub_1000A060(0, dwinfo, dwOutsize, &dwBytes);
		if ( dwSubRet == 0x7A )
		{
			if ( pAlloc )
				HeapFree(g_hHeap_1001ADE8, 0, pAlloc);
			dwTmpSize = dwBytes;
			pAlloc = (DWORD*)HeapAlloc(g_hHeap_1001ADE8, 8, dwBytes);
			if ( !pAlloc )
				return 0;
			dwOutsize = dwTmpSize;
			dwSubRet = sub_1000A060(pAlloc, dwinfo, dwTmpSize, &dwBytes);
		}
		if ( !dwSubRet )
		{
			wszsubstr = (WCHAR*)pAlloc[13];
			if ( wszsubstr )
			{
				if ( !wcscmp(wszsubstr, wszStr) )
					break;
			}
		}
		dwinfo = sub_10009FF0(dwinfo);
		if ( !dwinfo )
		{
			if ( pAlloc )
				HeapFree(g_hHeap_1001ADE8, 0, pAlloc);
			return 0;
		}
	}
	dwRet = sub_1000A150();
	*(PDWORD )sub_100070A0(dwRet) = dwinfo;
	if ( pAlloc )
		HeapFree(g_hHeap_1001ADE8, 0, pAlloc);

	return (DWORD)dwRet;
}

//////////////////////////////EApi2WriteTransfer////////////////////////////////////////////
int  sub_10002240(DWORD dwFlag)
{
	int result; 

	result = -1;
	if ( dwFlag > 0x40001 )
	{
		switch ( dwFlag )
		{
		case 0x40002:
			result = 10;
			break;
		case 0x40003:
			result = 13;
			break;
		case 0x40004:
			result = 14;
			break;
		case 0x40007:
			result = 5;
			break;
		case 0x40008:
			result = 6;
			break;
		case 0x40009:
			result = 18;
			break;
		case 0x4000Au:
			result = 19;
			break;
		default:
			return result;
		}
	}
	else if ( dwFlag == 262145 )
	{
		return 9;
	}
	else
	{
		switch ( dwFlag )
		{
		case 0:
			result = 0;
			break;
		case 1:
			result = 4;
			break;
		case 2:
			result = 1;
			break;
		case 4:
			result = 3;
			break;
		default:
			return result;
		}
	}
	return result;
}
///////////////////////Eapi2ReadBuffer///////////////////////////////////////////////////
int  sub_100035B0(int nSize, DWORD dwVal2, SHORT wVal3, void *lpDest)
{
	int result; 
	char *pszBuff1; 
	char *pszBuff2; 
	DWORD dwRet; 
	BYTE bTmpVal1; 
	DWORD dwTmpVal2; 
	int dwTmpVal3; 
	int nRet2; 

	result = 87;
	dwTmpVal3 = dwVal2;
	bTmpVal1 = 0;
	if ( lpDest )
	{
		result = sub_10003D70(&dwVal2, &bTmpVal1);
		nRet2 = result;
		if ( !result )
		{
			dwTmpVal2 = 0;
			pszBuff1 = (char *)HeapAlloc(g_hHeap_1001ADE8, 8, nSize + 12);
			pszBuff2 = pszBuff1;
			if ( pszBuff1 )
			{
				dwRet = sub_10004E50(g_hFile_10019FF8, 0xEA606044, &dwVal2, 0x18, pszBuff1, nSize + 12, &dwTmpVal2);
				if ( dwRet )
				{
					if ( dwTmpVal3 != dwVal2 )
					{
						sub_100036F0(dwVal2, 255, 0, 0, 0, 1);
						ReleaseMutex(g_hMutex_1001ADFC);
					}
				}
				else
				{
					dwRet = sub_10005200((DWORD)(*(void **)pszBuff2));
					if ( !dwRet )
					{
						if ( *((PDWORD )pszBuff2 + 2) != nSize )
							dwRet = 30;
						memcpy_s(lpDest, nSize, pszBuff2 + 12, *((PDWORD )pszBuff2 + 2));
					}
				}
				HeapFree(g_hHeap_1001ADE8, 0, pszBuff2);
				return dwRet;
			}
			else
			{
				return nRet2;
			}
		}
	}
	return result;
}
//////////////////////////////////////////////////////////////////////////
DWORD  sub_10004170(PDWORD pdwBuff)
{
	
	OVERLAPPED *pOverlapped1;
	DWORD result; 
	DWORD NumberOfBytesTransferred; // [esp+10h] [ebp-24h] BYREF
	int OutBuffer[8]; // [esp+14h] [ebp-20h] BYREF

	
	NumberOfBytesTransferred = 0;
	pOverlapped1 = (OVERLAPPED *)getTlsValue_10004D00();
	
	if ( !pOverlapped1 )
		return ERROR_NO_SYSTEM_RESOURCES;

	DeviceIoControl(g_hFile_10019FF8, 0xEA606288, 0, 0, OutBuffer, 0x20u, 0, pOverlapped1);

	if ( GetOverlappedResult(g_hFile_10019FF8, pOverlapped1, &NumberOfBytesTransferred, 1) ){
				
		pdwBuff[0] = OutBuffer[0];
		pdwBuff[1] = OutBuffer[1];
		pdwBuff[2] = OutBuffer[2];
		return 0;
	}
		
	result = GetLastError();

	if ( result == 0xE0000109 )
		return ERROR_TIMEOUT;

	if ( !result )
	{
		pdwBuff[0] = OutBuffer[0];
		pdwBuff[1] = OutBuffer[1];
		pdwBuff[2] = OutBuffer[2];
		return result;
	}
	return result;
}

DWORD sub_10004100()
{
	
	OVERLAPPED *pOverlapped1;
	DWORD result; 
	DWORD NumberOfBytesTransferred; 

	
	NumberOfBytesTransferred = 0;
	pOverlapped1 = (OVERLAPPED *)getTlsValue_10004D00();
	
	if ( !pOverlapped1 )
		return ERROR_NO_SYSTEM_RESOURCES;
	DeviceIoControl(g_hFile_10019FF8, 0xEA60A298, 0, 0, 0, 0, 0, pOverlapped1);
	if ( GetOverlappedResult(g_hFile_10019FF8, pOverlapped1, &NumberOfBytesTransferred, 1) )
		return 0;
	result = GetLastError();
	if ( result == 0xE0000109 )
		return ERROR_TIMEOUT;
	return result;
}

DWORD sub_10004830(PDWORD pdwRetCode, ...)
{
	
	OVERLAPPED *pOverlapped; 
	
	DWORD result; 
	int OutBuffer; 
	DWORD NumberOfBytesTransferred; 
	va_list va; 

	va_start(va, pdwRetCode);
	
	NumberOfBytesTransferred = 0;
	OutBuffer = 0;
	
	pOverlapped = (OVERLAPPED *)getTlsValue_10004D00();
	
	if ( !pOverlapped )
		return ERROR_NO_SYSTEM_RESOURCES;

	DeviceIoControl(g_hFile_10019FF8, 0xEA60E254, va, 4, &OutBuffer, 4, 0, pOverlapped);

	if ( GetOverlappedResult(g_hFile_10019FF8, pOverlapped, &NumberOfBytesTransferred, 1) )
	{
		*pdwRetCode = OutBuffer;
		return 0;
	}
	result = GetLastError();
	
	if ( result == 0xE0000109 )
		return ERROR_TIMEOUT;

	if ( !result )
	{

		*pdwRetCode = OutBuffer;
		return result;
	}
	return result;
}

DWORD  sub_100047B0(BYTE bFlag, DWORD dwVal)
{
	
	OVERLAPPED *pOverlapped; 
	DWORD result;
	DWORD NumberOfBytesTransferred; 
	int InBuffer[2]; 

	
	NumberOfBytesTransferred = 0;
	InBuffer[1] = bFlag;
	InBuffer[0] = dwVal;

	pOverlapped = (struct _OVERLAPPED *)getTlsValue_10004D00();
	
	if ( !pOverlapped )
		return ERROR_NO_SYSTEM_RESOURCES;

	DeviceIoControl(g_hFile_10019FF8, 0xEA60A258, InBuffer, 8, 0, 0, 0, pOverlapped);

	if ( GetOverlappedResult(g_hFile_10019FF8, pOverlapped, &NumberOfBytesTransferred, 1) )
		return 0;

	result = GetLastError();

	if ( result == 0xE0000109 )
		return ERROR_TIMEOUT;

	return result;
}

int  sub_10003CA0(DWORD dwVal, LPVOID lpOutBuffer)
{
	DWORD LastError; 
	BYTE dwTmp; 
	OVERLAPPED *pOverlapped; 
	int result; 
	DWORD NumberOfBytesTransferred; 
	int InBuffer[3]; 

	LastError = 0;
	dwTmp = 0;
	NumberOfBytesTransferred = 0;
	switch ( dwVal )
	{
	case 8:
	case 9:
	case 10:
	case 11:
		dwVal = 1;
		break;
	case 17:
	case 18:
	case 19:
		dwTmp = (BYTE)(dwVal - 16);
		dwVal = 0;
		break;
	default:
		break;
	}
	
	InBuffer[0] = dwVal;
	pOverlapped = (OVERLAPPED *)getTlsValue_10004D00();
	
	if ( pOverlapped )
	{
		DeviceIoControl(g_hFile_10019FF8, 0xEA60E054, InBuffer, 0x18, lpOutBuffer, 8, 0, pOverlapped);
		if ( !GetOverlappedResult(g_hFile_10019FF8, pOverlapped, &NumberOfBytesTransferred, 1) )
		{
			LastError = GetLastError();
			if ( LastError == 0xE0000109 )
				LastError = ERROR_TIMEOUT;
		}
	}
	else
	{
		LastError = ERROR_NO_SYSTEM_RESOURCES;
	}
	if ( LastError )
		return LastError;
	result = 1168;
	if ( dwTmp < *((BYTE *)lpOutBuffer + 4) )
		return LastError;
	return result;
}

PDWORD sub_10005AE0(PWORD pwBuff1, int nSize)
{
	DWORD dwTmp1; 
	PDWORD result; 
	DWORD nCnt; 
	PDWORD pdwTmp2; 
	PDWORD i; 

	dwTmp1 = *pwBuff1;
	result = 0;
	nCnt = 0;
	if ( dwTmp1 )
	{
		pdwTmp2 = (PDWORD )*((PDWORD )pwBuff1 + 1);
		for ( i = pdwTmp2; *i != nSize; i += 12 )
		{
			if ( ++nCnt >= dwTmp1 )
				return 0;
		}
		return &pdwTmp2[12 * nCnt];
	}
	return result;
}

int  sub_100056E0(PControlDevice30 pCtrlDevice, void *lpBuff2, size_t nSize, DWORD dwVal4)
{
	int result; 
	DWORD dwTmp1; 
	DWORD dwTmp2; 

	result = 0;
	if ( lpBuff2 )
	{
		dwTmp1 = pCtrlDevice->dwOutBuffer[4];
		if ( dwVal4 < dwTmp1 && nSize <= dwTmp1 && dwVal4 + nSize <= dwTmp1 )
		{
			dwTmp2 = pCtrlDevice->dwUnk18;
			if ( dwTmp2 )
			{
				memcpy(lpBuff2, (const void *)(dwVal4 + dwTmp2), nSize);
				return 1;
			}
			else
			{
				CCmos* pCmos = NULL;	
				CEmbeddedEeprom* pEeprom=NULL;
				DWORD dwRet = 0;
				if(pCtrlDevice->dwFlag == 0)
				{
					pCmos = (CCmos*)pCtrlDevice->lpClass;
					return pCmos->sub_10005FF0((BYTE)(dwVal4+pCtrlDevice->dwOutBuffer[3]), (BYTE*)lpBuff2,  nSize);
				}
				else 
				{
					pEeprom = (CEmbeddedEeprom*)pCtrlDevice->lpClass;
					return pEeprom->sub_10005C90((BYTE)(dwVal4+pCtrlDevice->dwOutBuffer[3]),(BYTE*)lpBuff2,  nSize);
				}

			}
		}
	}
	return result;
}

DWORD  sub_10001000(PControlDevice30 pControlDevice)
{
	
	DWORD result; 
	DWORD dwRet; 
	DWORD dwTmp2; 

	CCmos* pCmos = NULL;	
	CEmbeddedEeprom* pEeprom=NULL;
	
	if(pControlDevice->dwFlag == 0)
		pCmos = (CCmos*)pControlDevice->lpClass;
	else 
		pEeprom = (CEmbeddedEeprom*)pControlDevice->lpClass;
		
	dwTmp2 = 0;
	
	if(pControlDevice->dwFlag == 0)
		
		pCmos->sub_10006050(&dwTmp2, &dwRet);
	else 
		pEeprom->sub_10005B90(&dwTmp2, &dwRet);
			
	result = 1;
	if ( !(pControlDevice->dwOutBuffer[3] % dwRet) )
		return dwRet;

	return result;
}

int sub_100054A0(PControlDevice30 pCtrlDevice, SIZE_T nSize, DWORD dwArg2, BYTE *Src)
{
	LPVOID lpMem;
	int dwResult;
	int dwCnt;
	dwCnt = dwArg2;
	
	int dwTmp = 0;
	if(dwArg2 >= pCtrlDevice->dwOutBuffer[4] || nSize< pCtrlDevice->dwOutBuffer[4] || dwArg2+nSize < pCtrlDevice->dwOutBuffer[4])
	{
				
		CCmos* pCmos = NULL;	
		CEmbeddedEeprom* pEeprom=NULL;
		DWORD dwRet = 0;

		if(pCtrlDevice->dwFlag == 0)
		{
			pCmos = (CCmos*)pCtrlDevice->lpClass;
			dwRet = dwTmp = pCmos->sub_10005F90((BYTE)(pCtrlDevice->dwOutBuffer[3] + dwArg2), Src, nSize);
		}
		else 
		{
			pEeprom = (CEmbeddedEeprom*)pCtrlDevice->lpClass;
			dwRet = dwTmp = pEeprom->sub_10005BC0((BYTE)(pCtrlDevice->dwOutBuffer[3] + dwArg2), (char*)Src, nSize);
		}

		//eax = call eax(edx, Src, esi);
		if(dwRet == 1)
		{
			if(dwRet == pCtrlDevice->dwUnk24)// + 0x24)
			{
				lpMem = HeapAlloc(g_hHeap_1001ADE8, HEAP_ZERO_MEMORY, nSize);
				if(lpMem)
				{					
					if(pCtrlDevice->dwFlag == 0)
					{
						pCmos = (CCmos*)pCtrlDevice->lpClass;
						dwRet = dwTmp = pCmos->sub_10005F90((BYTE)(pCtrlDevice->dwOutBuffer[3] + dwArg2), (BYTE*)lpMem, nSize);
					}
					else 
					{
						pEeprom = (CEmbeddedEeprom*)pCtrlDevice->lpClass;
						dwRet = dwTmp = pEeprom->sub_10005BC0((BYTE)(pCtrlDevice->dwOutBuffer[3] + dwArg2), (char*)lpMem, nSize);
					}

					
					dwCnt = nSize;
					bool fBreak = false;
					int i = nSize/4;
					PBYTE pData  = (PBYTE)lpMem;
					if(nSize >= 4)
					{
						do{
							
							if(pData[i] == Src[i])
							{
								i++;
								dwCnt-=4;
// 								
							}
							else { fBreak = true; break;}

						}while(dwCnt>=4);

					}

					if(fBreak == false && dwCnt == 0) dwTmp = 0;
					else
					{
						if((dwTmp = pData[0] - Src[0]) == 0)
						{
							if(dwCnt <= 1) { dwTmp = 0;}
							else if((dwTmp = pData[1] - Src[1]) == 0)
							{
								if(dwCnt <=2){dwTmp = 0;}
								else if((dwTmp = pData[2] - Src[2]) == 0)
								{
									if(dwCnt<=3) {dwTmp = 0;}
									else
									{
										dwTmp = pData[3] - Src[3];
									}
								}
							}
						}
						if(dwTmp != 0)
						{
							dwTmp >>= 31;
							dwTmp |= 1;
						}
						
					}
										
					if(dwTmp == 0) dwResult = 1;
					else dwResult = 0;

					HeapFree(g_hHeap_1001ADE8, 0, lpMem);

					if(dwResult != 1) return dwResult;
				}
			}

			
			if(pCtrlDevice->dwUnk18){
				memcpy((void*)(pCtrlDevice->dwUnk18+dwArg2), Src, nSize);
			}
			if(pCtrlDevice->dwUnk20 == 1)
				return sub_10005610(pCtrlDevice);
		
			return dwResult;
		}
		return 0;
	}

	return 0;
}

int  sub_10005610(PControlDevice30 pCtrlDev)
{
	
	int result; 
	DWORD i;
		
	DWORD dwTmp1, dwResult = 0;
	PBYTE pbData = (PBYTE)pCtrlDev->dwUnk18;
	for( i = 0; i < pCtrlDev->dwOutBuffer[4]; i++)
	{
		
		dwTmp1 = (WORD)((BYTE)(dwResult >> 8)) | (WORD)(dwResult <<=8);
		dwResult = (WORD)((WORD)dwTmp1 ^(WORD)pbData[i]);
		BYTE bTmp2 = (BYTE)dwResult; bTmp2 >>= 4; dwResult ^=(WORD)bTmp2;
		dwResult ^= (dwResult<<12);
		dwTmp1 = (BYTE)dwResult; dwTmp1 <<= 5; dwTmp1 ^= dwResult;
		dwResult = (WORD)dwTmp1;
		
	}
		
	dwResult = (WORD)(dwResult<< 8);
	CCmos* pCmos = NULL;	
	CEmbeddedEeprom* pEeprom=NULL;
	DWORD dwRet = 0;
	if(pCtrlDev->dwFlag == 0)
	{
		pCmos = (CCmos*)pCtrlDev->lpClass;
		pCmos->sub_10005F90((BYTE)pCtrlDev->dwUnk2C, (BYTE*)&dwResult, 2);
		pCmos->sub_10005FF0((BYTE)pCtrlDev->dwUnk2C, (BYTE*)&i, 2);
	}
	else 
	{
		pEeprom = (CEmbeddedEeprom*)pCtrlDev->lpClass;
		pEeprom->sub_10005BC0((BYTE)pCtrlDev->dwUnk2C, (char*)&dwResult, 2);
		pEeprom->sub_10005C90((BYTE)pCtrlDev->dwUnk2C, (BYTE*)&i, 2);
	}
	
	if ( (WORD)dwResult != (WORD)i )
		return 0;
	result = 1;
	pCtrlDev->dwUnk1C = (dwResult<<8);
	return result;
}

DWORD  sub_10004520(PDWORD pdwBuff)
{

	OVERLAPPED *pOverlapped1; 
	DWORD result; 
	DWORD NumberOfBytesTransferred; 
	int OutBuffer[5]; 

	
	NumberOfBytesTransferred = 0;
	
	pOverlapped1 = (OVERLAPPED *)getTlsValue_10004D00();

	

	if ( !pOverlapped1 )
		return ERROR_NO_SYSTEM_RESOURCES;

	DeviceIoControl(g_hFile_10019FF8, 0xEA6061C4, 0, 0, OutBuffer, 0x14, 0, pOverlapped1);

	if ( GetOverlappedResult(g_hFile_10019FF8, pOverlapped1, &NumberOfBytesTransferred, 1) )
	{
		*pdwBuff = OutBuffer[0];
		return 0;
	}
		
	result = GetLastError();
	
	if ( result == 0xE0000109 )
		return ERROR_TIMEOUT;

	if ( !result )
	{
		*pdwBuff = OutBuffer[0];
		return 0;
	}
	return result;
}

DWORD  sub_100044B0(DWORD dwFlag)
{

	OVERLAPPED *pOverlapped; 
	
	DWORD result; 
	DWORD NumberOfBytesTransferred; 

	
	NumberOfBytesTransferred = 0;
	pOverlapped = (OVERLAPPED *)getTlsValue_10004D00();

	if ( !pOverlapped )
		return ERROR_NO_SYSTEM_RESOURCES;

	DeviceIoControl(g_hFile_10019FF8, 0xEA60E1C0, &dwFlag, 4, 0, 0, 0, pOverlapped);

	if ( GetOverlappedResult(g_hFile_10019FF8, pOverlapped, &NumberOfBytesTransferred, 1) )
		return 0;

	result = GetLastError();

	if ( result == 0xE0000109 )
		return ERROR_TIMEOUT;
	return result;
}

DWORD  sub_10004280(PDWORD pdwBuff)
{
	
	OVERLAPPED *pOverlapped; 

	DWORD result; 
	DWORD NumberOfBytesTransferred; 
	DWORD OutBuffer[8]; 

	
	NumberOfBytesTransferred = 0;
	
	pOverlapped = (OVERLAPPED *)getTlsValue_10004D00();

	if ( !pOverlapped )
		return ERROR_NO_SYSTEM_RESOURCES;

	DeviceIoControl(g_hFile_10019FF8, 0xEA60628C, 0, 0, OutBuffer, 0x20, 0, pOverlapped);

	if ( GetOverlappedResult(g_hFile_10019FF8, pOverlapped, &NumberOfBytesTransferred, 1) )
	{
		*pdwBuff = OutBuffer[0];
		return 0;
	}
		
	result = GetLastError();
	
	if ( result == 0xE0000109 )
		return ERROR_TIMEOUT;

	if ( !result )
	{

		*pdwBuff = OutBuffer[0];
		return 0;
	}
	return result;
}

DWORD  sub_10004090(PDWORD  pdwBuff)
{
	
	OVERLAPPED *pOverlapped; 
	DWORD result; 
	DWORD NumberOfBytesTransferred; 

	
	NumberOfBytesTransferred = 0;

	pOverlapped = (OVERLAPPED *)getTlsValue_10004D00();

	if ( !pOverlapped )
		return ERROR_NO_SYSTEM_RESOURCES;

	DeviceIoControl(g_hFile_10019FF8, 0xEA60A29C, pdwBuff, 0x1C, 0, 0, 0, pOverlapped);

	if ( GetOverlappedResult(g_hFile_10019FF8, pOverlapped, &NumberOfBytesTransferred, 1) )
		return 0;

	result = GetLastError();

	if ( result == 0xE0000109 )
		return ERROR_TIMEOUT;

	return result;
}

DWORD sub_10004210()
{
	
	OVERLAPPED *pOverlapped;
	
	DWORD result; 
	DWORD NumberOfBytesTransferred; 

	
	NumberOfBytesTransferred = 0;
	pOverlapped = (OVERLAPPED *)getTlsValue_10004D00();
	
	if ( !pOverlapped )
		return ERROR_NO_SYSTEM_RESOURCES;

	DeviceIoControl(g_hFile_10019FF8, 0xEA60A290, 0, 0, 0, 0, 0, pOverlapped);
	if ( GetOverlappedResult(g_hFile_10019FF8, pOverlapped, &NumberOfBytesTransferred, 1) )
		return 0;

	result = GetLastError();

	if ( result == 0xE0000109 )
		return ERROR_TIMEOUT;

	return result;
}

DWORD sub_10004310()
{
	
	OVERLAPPED *pOverlapped;
	
	DWORD result; 
	DWORD NumberOfBytesTransferred; 

	
	NumberOfBytesTransferred = 0;
	pOverlapped = (struct _OVERLAPPED *)getTlsValue_10004D00();
	
	if ( !pOverlapped )
		return ERROR_NO_SYSTEM_RESOURCES;

	DeviceIoControl(g_hFile_10019FF8, 0xEA60A294, 0, 0, 0, 0, 0, pOverlapped);
	if ( GetOverlappedResult(g_hFile_10019FF8, pOverlapped, &NumberOfBytesTransferred, 1) )
		return 0;

	result = GetLastError();

	if ( result == 0xE0000109 )
		return ERROR_TIMEOUT;

	return result;
}

DWORD  sub_10004A30(DWORD InBuffer, DWORD dwMilliseconds)
{
	
	OVERLAPPED *pOverlapped; 
	DWORD result; 
	
	DWORD NumberOfBytesTransferred; 
	
	NumberOfBytesTransferred = 0;
	pOverlapped = (struct _OVERLAPPED *)getTlsValue_10004D00();

	if ( !pOverlapped )
		return ERROR_NO_SYSTEM_RESOURCES;
	DeviceIoControl(g_hFile_10019FF8, 0xEA60A018, &InBuffer, 4, 0, 0, 0, pOverlapped);
	if ( !GetOverlappedResult(g_hFile_10019FF8, pOverlapped, &NumberOfBytesTransferred, 1) )
	{
		result = GetLastError();
		
		if ( result == 0xE0000109 )
			return ERROR_TIMEOUT;
		return result;
	}
		
	Sleep(dwMilliseconds);
	
	InBuffer = 0;
	pOverlapped = (OVERLAPPED *)getTlsValue_10004D00();
	
	if ( pOverlapped )
	{
		DeviceIoControl(g_hFile_10019FF8, 0xEA60A018, &InBuffer, 4, 0, 0, 0, pOverlapped);
		if ( !GetOverlappedResult(g_hFile_10019FF8, pOverlapped, &NumberOfBytesTransferred, 1) )
			GetLastError();
	}
	return 0;

}

DWORD  sub_100049C0(PDWORD  pdwOutBuffer)
{
	OVERLAPPED *pOverlapped; 
	DWORD result; 
	DWORD NumberOfBytesTransferred; 
	
	NumberOfBytesTransferred = 0;
	pOverlapped = (OVERLAPPED *)getTlsValue_10004D00();
	if ( !pOverlapped )
		return ERROR_NO_SYSTEM_RESOURCES;

	DeviceIoControl(g_hFile_10019FF8, 0xEA6062CC, 0, 0, pdwOutBuffer, 4, 0, pOverlapped);
	if ( GetOverlappedResult(g_hFile_10019FF8, pOverlapped, &NumberOfBytesTransferred, 1) )
		return 0;

	result = GetLastError();

	if ( result == 0xE0000109 )
		return ERROR_TIMEOUT;

	return result;
}

DWORD  sub_100048D0(DWORD InBuffer, DWORD dwFlag)
{
	
	OVERLAPPED *pOverlapped; 
	
	DWORD result; 
	DWORD NumberOfBytesTransferred;
	
	NumberOfBytesTransferred = 0;
	pOverlapped = (OVERLAPPED *)getTlsValue_10004D00();
	
	if ( !pOverlapped )
		return ERROR_NO_SYSTEM_RESOURCES;

	DWORD dwIOCode = 0xEA60A2C0;

	if(dwFlag == 0) dwIOCode -=4;

	DeviceIoControl(g_hFile_10019FF8, dwIOCode, &InBuffer, 4, 0, 0, 0, pOverlapped);
	if ( GetOverlappedResult(g_hFile_10019FF8, pOverlapped, &NumberOfBytesTransferred, 1) )
		return 0;
	result = GetLastError();
	if ( result == 0xE0000109 )
		return ERROR_TIMEOUT;
	return result;
}

DWORD  sub_10004950(LPVOID lpOutBuffer)
{
	OVERLAPPED *pOverlapped; 
	DWORD result; 
	DWORD NumberOfBytesTransferred; 

	
	NumberOfBytesTransferred = 0;
	pOverlapped = (OVERLAPPED *)getTlsValue_10004D00();
	if ( !pOverlapped )
		return ERROR_NO_SYSTEM_RESOURCES;
	DeviceIoControl(g_hFile_10019FF8, 0xEA6062C8, 0, 0, lpOutBuffer, 4u, 0, pOverlapped);
	if ( GetOverlappedResult(g_hFile_10019FF8, pOverlapped, &NumberOfBytesTransferred, 1) )
		return 0;

	result = GetLastError();
	if ( result == 0xE0000109 )
		return ERROR_TIMEOUT;
	return result;
}
//////////////////////////////////////////////////////////////////////////
void sub_100072A0(WORD wCnt, BYTE *pSrc, SMBUSPARAM* pDest, WORD wMod)
{
	WORD v5; // cx

	DWORD pBody; // ecx

	v5 = 4;
	if ( wCnt >= 4 )
		v5 = wCnt;

	if ( pDest->dwCode_10 != 0x43696541 ) return;
	if (wCnt == 0) return;


	pBody = (DWORD)pDest->pAddHeaderInfo_8;// pdest + 0x20
	if ( pDest->wHeaderlen_0 < (WORD)(v5 + 4 + pBody - (DWORD)pDest) ) return;

	switch ( wMod )
	{
	case 0:		
		*(PWORD)pBody = 0;
		*(PWORD)(pBody + 2) = 4;
		*(PDWORD )(pBody + 4) = *(PDWORD )pSrc;
		break;
	case 1:
		*(PWORD)pBody = 1;
		*(PWORD)(pBody + 2) = strlen((char*)pSrc) + 1;///???
		memcpy((void *)(pBody + 4), pSrc, *(PWORD)(pBody + 2));
		break;
	case 2:
		*(PWORD)pBody = 2;
		*(PWORD)(pBody + 2) = wCnt;
		memcpy((void *)(pBody + 4), pSrc, *(PWORD)(pBody + 2));
		break;
	case 3:
		*(PWORD)pBody = 3;
		*(PWORD)(pBody + 2) = wCnt;
		memcpy_s((void *)(pBody + 4),*(PWORD)(pBody + 2),pSrc,*(PWORD)(pBody + 2));
		break;
	default:
		return;
	}
	pDest->dwUnk_18 += v5 + 4;
	pDest->dwUnk_1C++;

	if ( *(PWORD)(pBody + 2) >= 4)
		pDest->pAddHeaderInfo_8 = pDest->pAddHeaderInfo_8 + *(PWORD)(pBody + 2) + 4;
	else
		pDest->pAddHeaderInfo_8 = pDest->pAddHeaderInfo_8 + 8;

	return;

}

DWORD sub_10007460(SMBUSPARAM* lpBuf, DWORD dwParam, DWORD dwCmd, PDWORD pdwOut)
{
	FUNCSTRUC10* pFunStruc; // ebp
	DWORD dwRet; // eax

	if (!lpBuf) return 0x57;

	pFunStruc = (FUNCSTRUC10*)dwParam;
	dwParam = 0;
	if ( !pFunStruc || pFunStruc->dwSelfAddr00 != (DWORD)pFunStruc || strcmp(pFunStruc->szStr0C, "HACPI") ) return 0x57;

	lpBuf->pAddHeaderInfo_8 = 0;
	lpBuf->dwUnk_C = pFunStruc->dwParam10;
	lpBuf->dwUnk_14 = dwCmd;
	dwRet = sub_10004E50(g_hFile_10019FF8, 0xEA60E024, lpBuf, lpBuf->wHeaderlen_0 + lpBuf->wBodyLen_2, lpBuf, lpBuf->wHeaderlen_0 + lpBuf->wBodyLen_2, (PDWORD )&dwParam);
	if ( !dwRet )
	{		
		if ( *(PDWORD )(lpBuf->pAddrBody_4 + 8) )
		{
			lpBuf->pAddHeaderInfo_8 = lpBuf->pAddrBody_4 + 0xC;
			if ( pdwOut )
				*pdwOut = *(PDWORD )(lpBuf->pAddrBody_4 + 8);
		}
	}
	return dwRet;
}
DWORD sub_100073E0(PDWORD pDest, SMBUSPARAM* plpParam)
{
	DWORD dwRet; // eax
	dwRet = 0x103;
	if ( !plpParam->pAddHeaderInfo_8 ) return dwRet;

	if ( *(WORD*)(plpParam->pAddHeaderInfo_8 + 2) > 4 || !pDest ) return 0x7A;

	memcpy_s(pDest, 4, (BYTE*)(plpParam->pAddHeaderInfo_8 + 4), *(WORD*)(plpParam->pAddHeaderInfo_8 + 2));
	*(DWORD*)(plpParam->pAddrBody_4 + 8) -= 1;
	if ( *(DWORD*)(plpParam->pAddrBody_4 + 8) )
	{
		if ( *(PWORD)(plpParam->pAddHeaderInfo_8 + 2) >= 4 )
			plpParam->pAddHeaderInfo_8 = plpParam->pAddHeaderInfo_8 + *(PWORD)(plpParam->pAddHeaderInfo_8 + 2) + 4;
		else
			plpParam->pAddHeaderInfo_8 = plpParam->pAddHeaderInfo_8 + 8;
		return 0;
	}
	else
	{
		plpParam->pAddHeaderInfo_8 = 0;
		return 0;
	}
	return dwRet;
}

//////////////////////////////////////////////////////////////////////////
DWORD  sub_10004700(PDWORD pdwBuff)
{

	OVERLAPPED *pOverlapped;
	DWORD result; 
	DWORD NumberOfBytesTransferred; 
	int OutBuffer[5]; 
	NumberOfBytesTransferred = 0;
	pOverlapped = (OVERLAPPED *)getTlsValue_10004D00();
	
	if ( !pOverlapped )
		return ERROR_NO_SYSTEM_RESOURCES;

	DeviceIoControl(g_hFile_10019FF8, 0xEA6061E0, 0, 0, OutBuffer, 0x14, 0, pOverlapped);
	if ( GetOverlappedResult(g_hFile_10019FF8, pOverlapped, &NumberOfBytesTransferred, 1) )
	{
		
		pdwBuff[0] = OutBuffer[0];
		pdwBuff[1] = OutBuffer[1];
		pdwBuff[2] = OutBuffer[2];
		pdwBuff[3] = OutBuffer[3];
		pdwBuff[4] = OutBuffer[4];
		return 0;
	}
		
	result = GetLastError();
	
	if ( result == 0xE0000109 )
		return ERROR_TIMEOUT;
	if ( !result )
	{

		pdwBuff[0] = OutBuffer[0];
		pdwBuff[1] = OutBuffer[1];
		pdwBuff[2] = OutBuffer[2];
		pdwBuff[3] = OutBuffer[3];
		pdwBuff[4] = OutBuffer[4];
		return 0;
	}
	return result;
}

DWORD  sub_100045B0(DWORD dwInBuffer)
{
	
	OVERLAPPED *pOverlapped; 
	
	DWORD result; 
	DWORD NumberOfBytesTransferred; 

	
	NumberOfBytesTransferred = 0;
	pOverlapped = (OVERLAPPED *)getTlsValue_10004D00();
	
	if ( !pOverlapped )
		return ERROR_NO_SYSTEM_RESOURCES;

	DeviceIoControl(g_hFile_10019FF8, 0xEA60E1D0, &dwInBuffer, 4, 0, 0, 0, pOverlapped);
	if ( GetOverlappedResult(g_hFile_10019FF8, pOverlapped, &NumberOfBytesTransferred, 1) )
		return 0;

	result = GetLastError();

	if ( result == 0xE0000109 )
		return ERROR_TIMEOUT;

	return result;
}

DWORD  sub_10004620(DWORD InBuffer)
{
	
	OVERLAPPED *pOverlapped;
	
	DWORD result; 
	DWORD NumberOfBytesTransferred; 

	
	NumberOfBytesTransferred = 0;
	pOverlapped = (OVERLAPPED *)getTlsValue_10004D00();

	if ( !pOverlapped )
		return ERROR_NO_SYSTEM_RESOURCES;

	DeviceIoControl(g_hFile_10019FF8, 0xEA60E1C8, &InBuffer, 4, 0, 0, 0, pOverlapped);
	if ( GetOverlappedResult(g_hFile_10019FF8, pOverlapped, &NumberOfBytesTransferred, 1) )
		return 0;

	result = GetLastError();
	if ( result == 0xE0000109 )
		return ERROR_TIMEOUT;
	return result;
}

DWORD  sub_10004690(DWORD dwInBuffer)
{
	
	struct _OVERLAPPED *pOverlapped; 
	
	DWORD result; // eax
	DWORD NumberOfBytesTransferred;
	
	NumberOfBytesTransferred = 0;
	pOverlapped = (OVERLAPPED *)getTlsValue_10004D00();
	
	if ( !pOverlapped )
		return ERROR_NO_SYSTEM_RESOURCES;

	DeviceIoControl(g_hFile_10019FF8, 0xEA60E1D8, &dwInBuffer, 4, 0, 0, 0, pOverlapped);
	if ( GetOverlappedResult(g_hFile_10019FF8, pOverlapped, &NumberOfBytesTransferred, 1) )
		return 0;

	result = GetLastError();
	if ( result == 0xE0000109 )
		return ERROR_TIMEOUT;
	return result;
}

SHORT *sub_10006AD0()
{
	PDWORD pdwMem; 
	int j; 
	SHORT dwRet; 
	SHORT *result; 
	DWORD dwAddr; 
	int idx;
	
	dwAddr = 0;
	g_dword_1001AE00[0] = 0;
	g_dword_1001AE00[2] = 0;
	g_dword_1001AE00[3] = 0;
	g_dword_1001AE00[4] = 0;
	g_dword_1001AE00[5] = 0;
	g_dword_1001AE00[6] = 0;
	g_dword_1001AE00[7] = 0;
	int i = 0;
	if(sub_10003430(0, 2, 0, (WORD*)&dwAddr) == ERROR_INSUFFICIENT_BUFFER)
	{
		pdwMem = (PDWORD )HeapAlloc(g_hHeap_1001ADE8, 8, (WORD)dwAddr);
		if(pdwMem)
		{
			sub_10003430(pdwMem, 2, (WORD)dwAddr, 0);
			if(pdwMem[0] )
			{
				DWORD dwOffset = 0;
								
				do 
				{
					if(i >=8) break;
					idx = *(DWORD*)(dwOffset + pdwMem[1]);
					if(idx <7)
					{
						LPFnP_D pFnClassCreator = (LPFnP_D)CSensorIoCreators_10006B8D[idx];
						DWORD dwTmp = *(BYTE*)(pdwMem[1] + dwOffset + 4);
						g_pClassList_1001ADB8[i] = (PDWORD )pFnClassCreator(dwTmp);
						if(g_pClassList_1001ADB8[i])
						{
							if(!sub_10006DD0((DWORD)g_pClassList_1001ADB8[i], idx)) 
							{ 								
								delete (CSensor*)g_pClassList_1001ADB8[i];
								g_pClassList_1001ADB8[i] = NULL;
							}
						}
						i++;
					}
					dwOffset += 0x20;
					
				}while ( i < (WORD)pdwMem[0] );

			}
			
		}
	}
	if(i < 8)
	{
		
		CW83627DHGP* pW83627DHGP = (CW83627DHGP*)sub_100083C0(0);
		CSuperIo* pSuperIo = dynamic_cast<CSuperIo*>((CSensor*)pW83627DHGP);
		g_pClassList_1001ADB8[i] = (PDWORD )pSuperIo;
		
	}

	j = 0;
	if ( g_pClassList_1001ADB8[i] )
	{
		dwAddr = 0;
		do
		{
			dwRet = (SHORT)((CSensor*)g_pClassList_1001ADB8[i])->sub_10009DF0(j);
			dwAddr = dwRet + dwAddr;
			++j;
		}
		while ( j < 3 );
		g_dword_1001AE00[0] += dwAddr;
		if ( dwAddr == 0 )
		{
			delete g_pClassList_1001ADB8[i];
			g_pClassList_1001ADB8[i] = 0;
		}
	}
	result = sub_10006C80((PDWORD )pdwMem, idx);
	if ( pdwMem )
		return (SHORT *)HeapFree(g_hHeap_1001ADE8, 0, pdwMem);
	return result;
}

BOOL sub_10006DD0(DWORD dwArg1, int iClassType)
{
	WORD dwVal; 
	int i; 
	WORD wRet; 
	dwVal = 0;
	switch(iClassType)
	{
	case 0:
		{
			CAdt7475* pAdt7475 = (CAdt7475*)dwArg1;
			for ( i = 0; i < 3; ++i )
			{
				
				wRet =(WORD)pAdt7475->sub_10006E70(i);
				dwVal += wRet;
			}
		}
	
		break;
	case 1:
		{
			CAdt7490* pAdt7490 = (CAdt7490*)dwArg1;
			for ( i = 0; i < 3; ++i )
			{
				
				wRet =(WORD)pAdt7490->sub_10006E70(i);
				dwVal += wRet;
			}
		}
		break;
	case 2:
		{
			CW83L771Ax* pW83L771Ax = (CW83L771Ax*)dwArg1;
			for ( i = 0; i < 3; ++i )
			{
			
				wRet =(WORD)pW83L771Ax->sub_10006E70(i);
				dwVal += wRet;
			}
		}
		break;
	case 3:
		{
			CNCT7802* pNCT7802 = (CNCT7802*)dwArg1;
			for ( i = 0; i < 3; ++i )
			{
				
				wRet =(WORD)pNCT7802->sub_10006E70(i);
				dwVal += wRet;
			}
		}
		break;
	case 4:
		{
			CAmdBrazos* pAmdBrazos = (CAmdBrazos*)dwArg1;
			for ( i = 0; i < 3; ++i )
			{
				
				wRet =(WORD)pAmdBrazos->sub_10006E70(i);
				dwVal += wRet;
			}
		}
		break;
	case 5:
	case 6:
		{
			CSuperIo* pSuperIo = (CSuperIo*)dwArg1;
			for ( i = 0; i < 3; ++i )
			{
				
				pSuperIo->purecall();
				dwVal = 0;
				//dwVal += wRet;
			}
		}
		break;
	}
		
	g_dword_1001AE00[0] += dwVal;
	return dwVal != 0;

}
DWORD sub_10003040(BYTE bArg1, DWORD dwArg2)
{
	
	OVERLAPPED *pOverlapped; 
	DWORD result; 
	DWORD NumberOfBytesTransferred;
	DWORD InBuffer[2]; 
	
	
	NumberOfBytesTransferred = 0;
	InBuffer[0] = bArg1;
	InBuffer[1] = dwArg2;
	pOverlapped = (OVERLAPPED *)sub_10004D00();
	
	if ( !pOverlapped )
		return ERROR_NO_SYSTEM_RESOURCES;
	DeviceIoControl(g_hFile_10019FF8, 0xEA60A028, InBuffer, 8, 0, 0, 0, pOverlapped);
	if ( GetOverlappedResult(g_hFile_10019FF8, pOverlapped, &NumberOfBytesTransferred, 1) )
		return 0;
	result = GetLastError();
	if ( result == 0xE0000109 )
		return ERROR_TIMEOUT;
	return result;
}
DWORD sub_100083C0(WORD wArg1)
{
	int i; 

	OVERLAPPED *pOverlapped; 
	HANDLE EventW; 
	DWORD result; 
	DWORD j; 
	int OutBuffer;
	int InBuffer; 
	
	DWORD NumberOfBytesTransferred; 
	DWORD dwTmp3; 
	i = 0;
	while ( g_dword_1001ADF4[i] )
	{
	
		sub_10003040(g_byte_10015DC4[i], 135);
		sub_10003040(g_byte_10015DC4[i], 135);
		sub_10003040(g_byte_10015DC4[i], 32);
		
		OutBuffer = -1;
		InBuffer = (BYTE)g_byte_10015DC4[i] + 1;
		NumberOfBytesTransferred = 0;
		pOverlapped = (OVERLAPPED *)TlsGetValue(g_dwTlsIndex_10019FFC);
		if ( !pOverlapped )
		{
			pOverlapped = (OVERLAPPED *)HeapAlloc(g_hHeap_1001ADE8, 8, 0x14);
			if(pOverlapped)
			{
				pOverlapped->Internal = 0;
				pOverlapped->InternalHigh = 0;
				pOverlapped->Offset = 0;
				pOverlapped->OffsetHigh = 0;
				pOverlapped->hEvent = 0;
				EventW = CreateEventW(0, 0, 0, 0);
				pOverlapped->hEvent = EventW;
				if ( !EventW )
				{
					HeapFree(g_hHeap_1001ADE8, 0, pOverlapped);
				
				}
				else
					TlsSetValue(g_dwTlsIndex_10019FFC, pOverlapped);
			}
			
		}
		if(pOverlapped && pOverlapped->hEvent)
		{
			DeviceIoControl(g_hFile_10019FF8, 0xEA60E034, &InBuffer, 2, &OutBuffer, 4, 0, pOverlapped);
			if ( !GetOverlappedResult(g_hFile_10019FF8, pOverlapped, &NumberOfBytesTransferred, 1) )
				GetLastError();
		}
		

		sub_10003040((BYTE)g_byte_10015DC4[i], 33);
	
		InBuffer = -1;
		NumberOfBytesTransferred = (BYTE)g_byte_10015DC4[i] + 1;
		dwTmp3 = 0;
		pOverlapped = (OVERLAPPED *)TlsGetValue(g_dwTlsIndex_10019FFC);
		if ( !pOverlapped )
		{
			pOverlapped = (OVERLAPPED *)HeapAlloc(g_hHeap_1001ADE8, 8, 0x14u);
			if ( pOverlapped )
			{
					
				pOverlapped->Internal = 0;
				pOverlapped->InternalHigh = 0;
				pOverlapped->Offset = 0;
				pOverlapped->OffsetHigh = 0;
				pOverlapped->hEvent = 0;
				pOverlapped->hEvent =  CreateEventW(0, 0, 0, 0);
				if ( !pOverlapped->hEvent )
				{
					HeapFree(g_hHeap_1001ADE8, 0, pOverlapped);
					
				}
				else
					TlsSetValue(g_dwTlsIndex_10019FFC, pOverlapped);
			}
		}
		if(pOverlapped && pOverlapped->hEvent)
		DeviceIoControl(g_hFile_10019FF8, 0xEA60E034, &NumberOfBytesTransferred, 2, &InBuffer, 4, 0, pOverlapped);
		if ( !GetOverlappedResult(g_hFile_10019FF8, pOverlapped, &dwTmp3, 1) )
			GetLastError();

		result = sub_10003040((BYTE)g_byte_10015DC4[i], 170);
		
		if((BYTE)OutBuffer != 0xFF)
		{
			j = 0;
			while ( 1 )
			{
				result = (BYTE)g_byte_10015DC4[i];
				result =(DWORD) sub_1000A510((SHORT)result , OutBuffer, InBuffer, wArg1!=(WORD)result);
				if ( result )
				{
					g_dword_1001ADF4[i] = 1;
					return result;
				}
				j += 4;
				if ( j >= 4)
					return 0;
			}
		}
		if ( ++i >= 2 )
			return 0;
	}
	return result;
}

DWORD sub_10009340(DWORD dwArg1)
{
	
	BYTE byRet; 
	if ( !g_pCSmbus_Def_1001ADEC )
		return 0;
	byRet = 0;
	if(((CSmbus_Def*)g_pCSmbus_Def_1001ADEC)->sub_100081F0(7, (BYTE)dwArg1, 62, &byRet, 1) || byRet != 65 
		||((CSmbus_Def*)g_pCSmbus_Def_1001ADEC)->sub_100081F0(7, (BYTE)dwArg1, 61, &byRet, 1) ||  byRet != 117)
	{
		return 0;
	}

	CAdt7475* pAdt7475 = new CAdt7475();
	pAdt7475->m_by04 = (BYTE)dwArg1;
	pAdt7475->m_dw08 = 0;
	pAdt7475->m_pSmbus_Def0C = (CSmbus_Def*)g_pCSmbus_Def_1001ADEC;
	pAdt7475->m_dw10 = 0;
	pAdt7475->m_dw14 = 0;
	pAdt7475->m_by18 = 0;
	pAdt7475->m_dw1C = 0;
	
	if ( !pAdt7475 )
		return NULL;

	if(pAdt7475->sub_10008A90())

		return (DWORD)pAdt7475;
	delete pAdt7475;
	return 0;

}
DWORD sub_10009440(DWORD dwArg1)
{

	BYTE byRet1; 
	if ( !g_pCSmbus_Def_1001ADEC )
		return 0;
	
	byRet1 = 0;
	if(((CSmbus_Def*)g_pCSmbus_Def_1001ADEC)->sub_100081F0(7, (BYTE)dwArg1, 62, &byRet1, 1)|| byRet1 != 65
		||((CSmbus_Def*)g_pCSmbus_Def_1001ADEC)->sub_100081F0(7, (BYTE)dwArg1, 63, &byRet1, 1) || (byRet1 & 0xF0) != 96 )
	{
		return 0;
	}
	
	CAdt7490* pAdt7490 = new CAdt7490();
	if(pAdt7490)
	{
		pAdt7490->m_pSmbus_Def0C = (CSmbus_Def*)g_pCSmbus_Def_1001ADEC; 
		pAdt7490->m_by04 = (BYTE)dwArg1;
		pAdt7490->m_dw08 = 0;
		pAdt7490->m_dw10 = 0;
		pAdt7490->m_dw14 = 0;
		pAdt7490->m_by18 = 0;
		pAdt7490->m_dw1C = 0;
		if(pAdt7490->sub_10009520()) 
			return (DWORD)pAdt7490;
		delete pAdt7490; return NULL;
	}
	else return NULL;
	
}

DWORD sub_10006A80(DWORD dwArg1)
{
	CW83627DHGP* pW83627DHGP = (CW83627DHGP*)sub_100083C0((WORD)dwArg1);
	CSuperIo* pSuperIo = dynamic_cast<CSuperIo*>((CSensor*)pW83627DHGP);
	return (DWORD)pSuperIo;
}

DWORD sub_10009E20(DWORD dwArg1)
{
	CAmdBrazos* pAmdBrazos = new CAmdBrazos();
	return (DWORD)pAmdBrazos;
}

DWORD sub_10009650(DWORD dwArg1)
{
	BYTE byRet;
	if ( !g_pCSmbus_Def_1001ADEC )
		return 0;
	
	byRet = 0;
	if ( ((CSmbus_Def*)g_pCSmbus_Def_1001ADEC)->sub_100081F0(7, (BYTE)dwArg1, 254, &byRet, 1) )
		return 0;
	if ( byRet != 0xC3 )
		return 0;
	
	byRet = 0;
	if ( ((CSmbus_Def*)g_pCSmbus_Def_1001ADEC)->sub_100081F0(7, (BYTE)dwArg1, 253, &byRet, 1) || byRet != 80 )
		return 0;

	CNCT7802* pNCT802 = new CNCT7802();
	if(pNCT802)
	{
		pNCT802->m_pSmbus_Def04 = (CSmbus_Def*)g_pCSmbus_Def_1001ADEC;
		pNCT802->m_by08 = (BYTE)dwArg1;
		if(pNCT802->sub_100052A0())
			return (DWORD)pNCT802;
		delete pNCT802;
		return NULL;

	}
	else  return NULL;
	
}

DWORD sub_100086E0(DWORD dwArg1)
{
		
	BYTE byRet; 
	byRet = 0;
	if ( !g_pCSmbus_Def_1001ADEC )
		return 0;
	
	if(((CSmbus_Def*)g_pCSmbus_Def_1001ADEC)->sub_100081F0(7, (BYTE)dwArg1, 254, &byRet, 1) || byRet != 92)
		return 0;
	
		
	CW83L771Ax* pW83L771Ax = new CW83L771Ax();
	if(pW83L771Ax)
	{
			pW83L771Ax->m_pSmbus_Def4 = (CSmbus_Def*)g_pCSmbus_Def_1001ADEC;
			pW83L771Ax->m_by08 = (BYTE)dwArg1;
	}
	if(!pW83L771Ax) return 0;
	if(pW83L771Ax->sub_100052A0())
		return (DWORD)pW83L771Ax;
	delete pW83L771Ax;
	return 0;
}

SHORT* sub_10006C80(PDWORD  pdwArg1, int iClassType)
{
	PWORD lpMem; 
	PWORD pdwTmp1; 
	int j; 
	int k; 
	int i; 
	WORD dwRet; 
	WORD wTmp2; 
	WORD ii; 
	PDWORD pdwTmp2; 
	PWORD pwTmp3; 

	lpMem = (PWORD)HeapAlloc(g_hHeap_1001ADE8, 8, 20 * (WORD)g_dword_1001AE00[0]);
	
	g_dword_1001AE00[1] =(DWORD)lpMem;
	if ( lpMem )
	{
		pdwTmp1 = lpMem;
		j = 0;
		pwTmp3 = (PWORD)g_dword_1001AE00;
		do
		{
			k = 0;
			g_dword_1001AE00[3] = (DWORD)lpMem;
			i = 0;
			do
			{
				if ( g_pClassList_1001ADB8[i] )
				{
					
					switch(iClassType)
					{
					case 0:
						{
							CAdt7475* pAdt7475 = (CAdt7475*)g_pClassList_1001ADB8[i];
							pAdt7475->sub_100086C0();
							dwRet = (WORD)pAdt7475->sub_10006E70(j);
						}

						break;
					case 1:
						{
							CAdt7490* pAdt7490 = (CAdt7490*)g_pClassList_1001ADB8[i];
							pAdt7490->sub_100052A0();
							dwRet = (WORD)pAdt7490->sub_10006E70(j);
						}
						break;
					case 2:
						{
							CW83L771Ax* pW83L771Ax = (CW83L771Ax*)g_pClassList_1001ADB8[i];
							pW83L771Ax->sub_100086B0();
							dwRet = (WORD)pW83L771Ax->sub_10006E70(j);
						}
						break;
					case 3:
						{
							CNCT7802* pNCT7802 = (CNCT7802*)g_pClassList_1001ADB8[i];
							pNCT7802->sub_100086B0();
							dwRet = (WORD)pNCT7802->sub_10006E70(j);
						}
						break;
					case 4:
						{
							CAmdBrazos* pAmdBrazos = (CAmdBrazos*)g_pClassList_1001ADB8[i];
							pAmdBrazos->sub_10009DD0();
							dwRet = (WORD)pAmdBrazos->sub_10006E70(j);
												
						}
						break;
					case 5:
					case 6:
						{
							CSuperIo* pSuperIo = (CSuperIo*)g_pClassList_1001ADB8[i];
							pSuperIo->purecall();
							//pSuperIo->purecall(j);
							dwRet = 0;
														
						}
						break;
					}

					wTmp2 = 0;
				
					if ( pdwArg1 && k < *(WORD*)pdwArg1 )
					{
				
						wTmp2 = *(PWORD)((pdwArg1[1]+ 8*(j + 4 * k)) + 8);
						pdwTmp2 = *(DWORD **)((pdwArg1[1]+ 8*(j + 4 * k)) + 12);
					}
					else
					{
						pdwTmp2 = 0;
					}
					ii = 0;
					if ( dwRet )
					{
						do
						{
							if ( !pdwTmp2 || pdwTmp2[0] )
							{
								DWORD dwVal1 = 0, dwVal2 = 0;
								if ( pdwTmp1 )
								{
									if ( ii >= wTmp2 )
									{  dwVal1 = 1000, dwVal2 = g_dword_10015DE4[j];}
									else
									{	dwVal1 = pdwTmp2[1],dwVal2 = pdwTmp2[0];}

									*(PDWORD )pdwTmp1 = (DWORD)g_pClassList_1001ADB8[i];
									*((PDWORD )pdwTmp1 + 1) = dwVal2;
									*((PDWORD )pdwTmp1 + 2) = j;
									*(WORD*)((PDWORD )pdwTmp1 + 3) = (WORD)dwVal1;
									*((PDWORD )pdwTmp1 + 4) = dwVal1;
								}
								pdwTmp1 += 10;
								pwTmp3[2]++;
								
							}
							++ii;
							//v10 += 2;
						}
						while ( ii < dwRet );
						
					}
				}
				++i;
				++k;
			}
			while ( i != 8 );
			lpMem = (PWORD)g_dword_1001AE00[2];
			++j;
			
			pwTmp3 += 4;
		}
		while ( (int)pwTmp3 < (int)g_dword_1001AE00[6] );
	}
	return (SHORT*)lpMem;
}

OVERLAPPED *sub_10004D00()
{
	OVERLAPPED *result; 
		
	result = (OVERLAPPED*)TlsGetValue(g_dwTlsIndex_10019FFC);
	if ( !result )
	{
		result = (OVERLAPPED*)HeapAlloc(g_hHeap_1001ADE8, 8, 0x14);
		
		if ( result )
		{
		
			result->Internal = NULL;
			result->InternalHigh = NULL;
			result->Offset = NULL;
			result->OffsetHigh = NULL;
			result->hEvent = CreateEventW(0, 0, 0, 0);
						
			if ( result->hEvent )
			{
				TlsSetValue(g_dwTlsIndex_10019FFC, result);
				return result;
			}
			else
			{
				HeapFree(g_hHeap_1001ADE8, 0, result);
				return 0;
			}
		}
	}
	return result;
}
LPVOID createClasssW83627DHGP_1000A5C0(SHORT wArg1, CW83627DHGP* pW83627DHGP, DWORD dwArg3)
{
	
	pW83627DHGP->m_w08 = wArg1;
	*(WORD *)(pW83627DHGP + 0x32) = 0;
	pW83627DHGP->m_w32 = 0;
	pW83627DHGP->m_w2A = 0;
	pW83627DHGP->m_w22 = 0;
	pW83627DHGP->m_pby24 = 0;
	pW83627DHGP->m_by28 = 0;
	pW83627DHGP->m_pby2C = NULL;
	pW83627DHGP->m_by30 = 0;
	pW83627DHGP->m_pby34 = NULL;
	pW83627DHGP->m_by38 = 0;
	pW83627DHGP->m_w3A = 0;
	pW83627DHGP->m_dw3C = dwArg3;
	InitializeCriticalSection(&pW83627DHGP->m_cs40);
	pW83627DHGP->m_pdw60 = 0;
	pW83627DHGP->m_pWPARAM64 = 0;
	return (LPVOID)pW83627DHGP;
}
LPVOID sub_1000A510(SHORT wArg1, BYTE bArg2, BYTE bArg3, DWORD dwArg4)
{
	
	CW83627DHGP* pW83627DHGP;
	if ( bArg2 == (char)0xB0 )
	{
		if ( (bArg3 & 0xF0) == 0x70 )
		{
			
			pW83627DHGP = new CW83627DHGP();
			if ( !pW83627DHGP )
				return 0;
			createClasssW83627DHGP_1000A5C0(wArg1, pW83627DHGP, dwArg4);
			if(!pW83627DHGP->sub_1000A6B0())
			{
				delete pW83627DHGP;
				return 0;
			}
			return (LPVOID)pW83627DHGP;
		}
		else return 0;
		
	}
	if ( bArg2 != 82 )
		return 0;
		
	pW83627DHGP = new CW83627DHGP();

	if ( !pW83627DHGP )
		return 0;
	createClasssW83627DHGP_1000A5C0(wArg1, pW83627DHGP, dwArg4);
	if(!pW83627DHGP->sub_1000A6B0())
	{
		delete pW83627DHGP;
		return 0;
	}
	return (LPVOID)pW83627DHGP;
	
	
}
DWORD		sub_100030C0(char InBuffer, LPVOID lpOutBuffer)
{
	OVERLAPPED *pOverlapped; // esi
	DWORD result; // eax
	DWORD NumberOfBytesTransferred; // [esp+Ch] [ebp-4h] BYREF

	NumberOfBytesTransferred = 0;
	pOverlapped = (struct _OVERLAPPED *)sub_10004D00();
	if ( !pOverlapped )
		return 1450;
	DeviceIoControl(g_hFile_10019FF8, 0xEA60E034, &InBuffer, 2, lpOutBuffer, 4, 0, pOverlapped);
	if ( GetOverlappedResult(g_hFile_10019FF8, pOverlapped, &NumberOfBytesTransferred, 1) )
		return 0;
	result = GetLastError();
	if ( result == 0xE0000109 )
		return 1460;
	return result;
}