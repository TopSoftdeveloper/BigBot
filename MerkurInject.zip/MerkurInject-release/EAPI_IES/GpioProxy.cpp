#include "stdafx.h"
#include "GpioProxy.h"


CGpioProxy::CGpioProxy()
{
}


CGpioProxy::~CGpioProxy()
{
}


void CGpioProxy::sub_10007520()
{
}
