#pragma once
#include "stdafx.h"
#include "GpioProxy.h"

class CGpioDefaultProxy : public CGpioProxy
{
public:
	CGpioDefaultProxy();
	virtual ~CGpioDefaultProxy();
public:
	HANDLE m_hHandle;
public:

	virtual DWORD sub_10007600(DWORD *pdwArg1);
	virtual DWORD sub_10007C40(DWORD dwArg1, DWORD dwArg2);
	virtual DWORD sub_10007960(DWORD dwArg1, PDWORD pdwArg2);
	virtual DWORD sub_100077A0(DWORD dwArg1, PDWORD pdwArg2);
	virtual DWORD sub_10007660(DWORD dwArg1, PDWORD pdwArg2);
	virtual DWORD sub_10007830(DWORD dwArg1, DWORD dwArg2);
	virtual DWORD sub_10007700(DWORD dwArg1, PDWORD pdwArg2);
	virtual DWORD sub_10007A00(DWORD dwArg1, DWORD dwArg2);
	virtual DWORD sub_100078C0(DWORD dwArg1, PDWORD pdwArg2);
	virtual DWORD sub_10007B00(DWORD dwArg1, PDWORD pdwArg2);
	virtual DWORD sub_10007BA0(BYTE InBuffer, BYTE *pbBuff);
	virtual DWORD sub_10007CD0(BYTE InBuffer, DWORD *pdwBuff);
	virtual DWORD sub_10007D70(BYTE InBuffer, DWORD *pdwArg2, DWORD *pdwArg3 );
	virtual DWORD sub_10007A90(DWORD* lpOutBuffer);
	virtual OVERLAPPED* sub_10007E20();
	virtual DWORD sub_10007520(DWORD* pdwArg1);
};

