#pragma once
#include "Adt74x.h"
#include "Smbus_Def.h"
class CAdt7490 : public CAdt74x
{
public:
	CAdt7490();
	virtual ~CAdt7490();//virtual DWORD sub_10009DF0();
public:
	CAdt7490* m_hSelf;
	BYTE m_by04;

	DWORD m_dw08;
	CSmbus_Def* m_pSmbus_Def0C;
	DWORD m_dw10;
	DWORD m_dw14;
	BYTE m_by18;
	DWORD m_dw1C;
	DWORD m_dw20;
public:
	void sub_1001B150();
	DWORD sub_10008A90();
	DWORD sub_10008A60(DWORD dwArg1, DWORD dwArg2, BYTE* pDest);
public:

	virtual void sub_1000A480(CAdt7490* pSelf);
	virtual DWORD sub_10009520();
	virtual DWORD sub_100052A0();
	virtual DWORD sub_10006E70(DWORD i);
	virtual DWORD sub_10006EB0(DWORD dwArg1, DWORD dwArg2, PDWORD pdwArg3);
	virtual DWORD sub_10006F00(DWORD dwArg1, DWORD dwArg2, PDWORD pdwArg3, PDWORD pdwArg4);
	virtual DWORD sub_10006F60(DWORD dwFlag, DWORD dwArg1, PDWORD pdwArg2);
	virtual DWORD sub_10006FB0(DWORD dwFlag, DWORD dwArg1, PDWORD pdwArg2);
	virtual DWORD sub_10007000(DWORD dwFlag, DWORD dwArg1, PDWORD pdwArg2);
	virtual DWORD sub_10007050(DWORD dwFlag, DWORD dwArg1, LPVOID pdwArg2);
	virtual DWORD sub_10009010();
	virtual WORD sub_10008A50();
	virtual DWORD sub_10009DD0();
	virtual BOOL sub_10009020(WORD wArg1, DWORD *pdwArg2);
	virtual BOOL sub_10008CB0(DWORD dwArg, PDWORD pdwArg);
	virtual BOOL sub_10008B40(WORD wArg, DWORD *pdwVal);
	virtual BOOL sub_100090E0(WORD wArg, PDWORD pdwVal1, PDWORD pdwVal2);
	virtual BOOL sub_10008D80( DWORD dwArg, PDWORD pdwVal1, PDWORD pdwVal2);
	virtual BOOL sub_10008C00(WORD wArg, PDWORD pdwVal1, PDWORD pdwVal2);
	virtual BOOL sub_10009130(WORD wArg, PDWORD pdwVal);
	virtual BOOL sub_10008DF0(DWORD dwArg, DWORD* pdwVal);
	virtual DWORD sub_10009DE0();
	virtual BOOL sub_10008E50(DWORD dwArg, DWORD* pdwVal);
	virtual BOOL sub_10009160(WORD wArg, DWORD* pdwVal);
	virtual BOOL sub_100091D0(WORD wArg, DWORD *pdwVal);
	virtual BOOL sub_10008EF0(DWORD dwArg, DWORD* pdwVal);
	virtual BOOL sub_10009240(DWORD dwArg, WORD *pwVal);
	virtual BOOL sub_10008F90(WORD wArg, WORD* pwVal);
	virtual BOOL sub_10008C30(WORD wArg1, PBYTE pbyArg2);
	virtual BOOL sub_10009580(WORD wArg);
	virtual PDWORD sub_100095C0(PDWORD pdwArg1, BYTE *pbyArg2);
	
};

