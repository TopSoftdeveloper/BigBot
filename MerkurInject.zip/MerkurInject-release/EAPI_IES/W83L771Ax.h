#pragma once
#include "MultiSensor.h"
#include "Smbus_Def.h"
class CW83L771Ax;
typedef BYTE (__thiscall CW83L771Ax:: *CW83L771Ax_LPFnB_DDDDPD)(DWORD, DWORD, DWORD, DWORD, BYTE *, DWORD);
typedef BYTE (__thiscall CW83L771Ax:: *CW83L771Ax_LPFnB_DBB)(DWORD, BYTE, BYTE);
class CW83L771Ax:public CMultiSensor
{
public:
	CW83L771Ax();
	~CW83L771Ax();
public:
	CSmbus_Def* m_pSmbus_Def4;
	BYTE m_by08;
	
public:

	virtual void sub_1000A480();
	virtual DWORD sub_100052A0();
	virtual DWORD sub_100086B0();
	virtual DWORD sub_10006E70(DWORD i);
	virtual DWORD sub_10006EB0(DWORD dwArg1, DWORD dwArg2, PDWORD pdwArg3);
	virtual DWORD sub_10006F00(DWORD dwArg1, DWORD dwArg2, DWORD* pdwArg3, DWORD* pdwArg4);
	virtual DWORD sub_10006F60(DWORD dwArg1, DWORD dwArg2, PDWORD pdwArg3);
	virtual DWORD sub_10006FB0(DWORD dwFlag, DWORD dwArg2, PDWORD pdwArg3);
	virtual DWORD sub_10007000(DWORD dwFlag, DWORD dwArg2, PDWORD pdwArg3);
	virtual DWORD sub_10007050(DWORD dwArg1, DWORD dwArg2, PDWORD pdwArg3);
	virtual DWORD sub_100086C0();
	virtual DWORD sub_10008780(DWORD dwArg1, DWORD *pdwArg2);
	virtual DWORD sub_10009DE0(DWORD dwArg1, DWORD *pdwArg2);
	virtual DWORD sub_10008920(WORD wArg1, DWORD *pdwArg2, DWORD *pdwArg3);
	virtual BOOL sub_100086D0(WORD wArg1, DWORD *pdwArg2, DWORD *pdwArg3);
	virtual DWORD sub_10008970(WORD wArg1, DWORD *pdwArg2);
	virtual DWORD sub_10008840(DWORD dwArg1, DWORD *pdwArg2);
	virtual DWORD sub_100088B0(DWORD dwArg1, DWORD *pdwArg2);
	virtual DWORD sub_100089B0(DWORD dwArg1, DWORD *pdwArg2);
	virtual DWORD sub_10009DF0();
};

