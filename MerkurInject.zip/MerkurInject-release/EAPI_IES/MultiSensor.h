#pragma once
#include "Sensor.h"

class CMultiSensor : public CSensor
{
public:
	CMultiSensor();
	~CMultiSensor();
};

