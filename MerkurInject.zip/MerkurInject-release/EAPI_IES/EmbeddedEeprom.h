﻿#pragma once
#include "Eeprom.h"

class CEmbeddedEeprom : public CEeprom
{
public:
	CEmbeddedEeprom();
	virtual ~CEmbeddedEeprom(); //sub_100052B0
public:
	DWORD m_dw04;	
	DWORD m_dw08;
	DWORD m_dw0C;
	DWORD m_dw10;
	WORD m_w14;
	DWORD m_dw18;
	BOOL sub_10005D60();
	BOOL sub_10005E60();
	BOOL sub_10005CF0();
public:

	virtual BOOL Init_10005D40();
	virtual BOOL sub_10005BC0(DWORD a2, char *pBuf, DWORD dwSize);
	virtual BOOL sub_10005C90(DWORD a2, void *pDest, DWORD dwSize);
	virtual DWORD sub_10009DE0();
	virtual BOOL sub_10005B90(DWORD* pdwArg1, DWORD* pdwArg2 );
	virtual BOOL sub_10005B30(DWORD a2, WORD a3, DWORD a4,DWORD a5,WORD a6,DWORD a7);
	//virtual void sub_100052B0();
};

