#include "stdafx.h"
#include "Cmos.h"
#include "EAPI_IES_global.h"


CCmos::CCmos()
{
}


CCmos::~CCmos()
{
}


BOOL CCmos::sub_100052A0()
{
	return TRUE;
}
DWORD sub_10004420(BYTE a1, BYTE a2)
{
	HANDLE hDev; 
	OVERLAPPED *overlap; 
	DWORD result; 
	int InBuffer; 
	DWORD NumberOfBytesTransferred; 

	hDev = g_hFile_10019FF8;
	NumberOfBytesTransferred = 0;
	InBuffer = a2 | (a1 << 8);
	overlap = (OVERLAPPED *)getTlsValue_10004D00();	
	if ( !overlap )
		return 0x5AA;
	DeviceIoControl(hDev, 0xEA60A084, &InBuffer, 4, 0, 0, 0, overlap);
	if ( GetOverlappedResult(hDev, overlap, &NumberOfBytesTransferred, 1) )
		return 0;
	result = GetLastError();
	if ( result == 0xE0000109 )
		return 0x5B4;
	return result;
}
DWORD sub_10004380(BYTE a1, BYTE* a2)
{
	HANDLE hDev; 
	OVERLAPPED *overlap; 
	DWORD result; 
	int InBuffer; 
	DWORD NumberOfBytesTransferred; 
	BYTE OutBuf[4];

	hDev = g_hFile_10019FF8;
	NumberOfBytesTransferred = 0;
	InBuffer = a1 ;
	overlap = (OVERLAPPED *)getTlsValue_10004D00();	
	if ( !overlap )
		return 0x5AA;
	DeviceIoControl(hDev, 0xEA60A080, &InBuffer, 4, OutBuf, 4, 0, overlap);
	if ( GetOverlappedResult(hDev, overlap, &NumberOfBytesTransferred, 1) )
	{
		*a2 = OutBuf[0];
		return 0;
	}
	result = GetLastError();
	if ( result == 0xE0000109 )	return 0x5B4;
	else if(result == 0)
	{
		*a2 = OutBuf[0];
		return 0;
	}
	return result;
}

BOOL CCmos::sub_10005F90(BYTE byVal, BYTE* pbyBuf, int nCnt)
{
	DWORD dwSubret; 	
	if ( !pbyBuf )	return 0;
	if ( !nCnt )	return 0;
	if ( byVal < 0x100 )
	{
		dwSubret = 0;
		while ( !dwSubret )
		{

			dwSubret = sub_10004420(*pbyBuf++, byVal++);
			nCnt = nCnt - 1;
			if ( !nCnt )
			{
				if (!dwSubret) return TRUE;
				return FALSE;
			}
		}
	}
	return FALSE;
}


BOOL CCmos::sub_10005FF0(BYTE byVal, BYTE* pbyBuf, int nCnt)
{
	DWORD dwSubret; 	
	if ( !pbyBuf )	return 0;
	if ( !nCnt )	return 0;
	if ( byVal < 0x100 )
	{
		dwSubret = 0;
		while ( !dwSubret )
		{

			dwSubret = sub_10004380(byVal++, pbyBuf++);
			nCnt = nCnt - 1;
			if ( !nCnt )
			{
				if (!dwSubret) return TRUE;
				return FALSE;
			}
		}
	}
	return FALSE;
}


DWORD CCmos::sub_10009DE0()
{
	return FALSE;
}


BOOL CCmos::sub_10006050(DWORD* pdwVal1, DWORD* pdwVal2)
{
	*pdwVal1 = 0x100;
	*pdwVal2 = 0x100;
	return TRUE;
}
