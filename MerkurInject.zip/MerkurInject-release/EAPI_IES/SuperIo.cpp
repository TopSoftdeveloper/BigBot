#include "stdafx.h"
#include "SuperIo.h"


CSuperIo::CSuperIo()
{
}


CSuperIo::~CSuperIo()
{
}


void CSuperIo::sub_1000A450()
{
}
void CSuperIo::purecall()
{

}
