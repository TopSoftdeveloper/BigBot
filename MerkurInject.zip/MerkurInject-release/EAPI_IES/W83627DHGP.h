#pragma once
#include "W836x.h"
class CW836x;
class CW83627DHGP : public CW836x
{
public:
	CW83627DHGP();
	~CW83627DHGP();

public:

	virtual void sub_1000A480();
#if 0
	virtual DWORD sub_1000A6B0();

	virtual DWORD sub_10006E70();
	virtual void sub_10006EB0();
	virtual void sub_10006F00();
	virtual DWORD sub_10006F60();

	virtual void sub_10006FB0();

	virtual void sub_10007000();
	virtual void sub_10007050();

	virtual BYTE sub_1000A490();
	virtual BYTE sub_1000A4B0();
	virtual BYTE sub_1000A4A0();
	virtual void sub_1000A730();
	virtual void sub_1000AB50();
	virtual void sub_1000A7E0();
	virtual void sub_1000A860();
	virtual void sub_1000ABC0();
	virtual void sub_1000A8A0();
	virtual void sub_1000A900();
	virtual void sub_1000AC20();
	virtual DWORD sub_10009DE0();
	virtual void sub_1000AC60();
	virtual void sub_1000A940();
	virtual void sub_1000A9A0();
	//virtual void sub_1000ACE0();
	virtual void sub_1000AA00();
	virtual void sub_1000AD60();
	virtual void sub_1000AA90();
#endif
	virtual PDWORD sub_1000B420(DWORD *pdwArg1, PDWORD pdwArg2);
	virtual PDWORD sub_1000B440(DWORD *pdwArg1, BYTE *pdwArg2);
	virtual PDWORD sub_1000B460(DWORD *pdwArg1, BYTE *pdwArg2);
	//virtual void sub_1000A4D0();
	//virtual void sub_1000B4E0();
};

