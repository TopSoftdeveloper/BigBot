#include "stdafx.h"
#include "NCT7802.h"


CNCT7802::CNCT7802()
{
}


CNCT7802::~CNCT7802()
{
}


void CNCT7802::sub_1000A480()
{
}


DWORD CNCT7802::sub_100052A0()
{
	return 1;
}


void CNCT7802::sub_100086B0()
{
}


DWORD CNCT7802::sub_10006E70(DWORD i)
{
	return 1;
}


void CNCT7802::sub_10006EB0()
{
}


void CNCT7802::sub_10006F00()
{
}


void CNCT7802::sub_10006F60()
{
}


void CNCT7802::sub_10006FB0()
{
}


void CNCT7802::sub_10007000()
{
}


void CNCT7802::sub_10007050()
{
}


void CNCT7802::sub_1000A500()
{
}


void CNCT7802::sub_10009010()
{
}


void CNCT7802::sub_10009720()
{
}


void CNCT7802::sub_100099A0()
{
}


void CNCT7802::sub_10009C40()
{
}


void CNCT7802::sub_10009840()
{
}


void CNCT7802::sub_10009A20()
{
}


void CNCT7802::sub_10009CC0()
{
}


void CNCT7802::sub_10009890()
{
}


void CNCT7802::sub_10009A60()
{
}


DWORD CNCT7802::sub_10009DE0()
{
	return 1;
}


void CNCT7802::sub_10009A90()
{
}


void CNCT7802::sub_100097A0()
{
}


void CNCT7802::sub_10009CF0()
{
}


void CNCT7802::sub_100097F0()
{
}


void CNCT7802::sub_10009B10()
{
}


void CNCT7802::sub_100098C0()
{
}


void CNCT7802::sub_10009B90()
{
}


void CNCT7802::sub_10009D50()
{
}


DWORD CNCT7802::sub_10009DF0()
{
	return 1;
}
