#include "stdafx.h"
#include "EmbeddedEeprom.h"
#include "EAPI_IES_global.h"


CEmbeddedEeprom::CEmbeddedEeprom()
{
}


CEmbeddedEeprom::~CEmbeddedEeprom()
{
}


BOOL CEmbeddedEeprom::sub_10005B30(DWORD a2, WORD a3, DWORD a4,DWORD a5,WORD a6,DWORD a7)
{
	if ( a2 <= 0x13 && a2 != 7 && a5 && a6 && a6 <= a5 )
	{
		m_dw04 = a2;
		m_dw08 = a5;
		m_dw0C = a6;
		m_dw10 = a7;
		m_w14 = a3;
		m_dw18 = a4;
		return TRUE;
	}
	return FALSE;
}

BOOL CEmbeddedEeprom::sub_10005B90(DWORD* pdwArg1, DWORD* pdwArg2 )
{
	if(m_dw04 != -1)
	{
		*pdwArg1 = m_dw08;
		*pdwArg2 = m_dw0C;
		return TRUE;
	}
	return FALSE;
}
BOOL CEmbeddedEeprom::sub_10005CF0()
{
	int i = 0; // esi

	if ( m_dw04 == -1 )	return FALSE;

	while ( sub_100036F0(m_dw04, m_w14, 0, 0, 0, 1) )
	{
		i++;
		if ( i >= 200 )return FALSE;
	}
	return TRUE;
}

BOOL CEmbeddedEeprom::sub_10005BC0(DWORD a2, char *pBuf, DWORD dwSize)
{
	BOOL bRet; 
	DWORD dwMod; 
	DWORD dwtmp; 
	DWORD dwSubRet; 
	DWORD dwlen; 
	DWORD dwTail; 

	bRet = 0;
	if ( pBuf )
	{		
		if ( a2 < m_dw08 && a2 + dwSize <= m_dw08 )
		{
			dwMod = a2 % m_dw10;
			dwTail = m_w14 + 2 * (a2 / m_dw10);
			dwtmp = m_dw0C - dwMod % m_dw0C;
			if ( dwtmp > dwSize )
				dwtmp = dwSize;
			bRet = 1;
			if ( dwSize )
			{
				while ( 1 )
				{
					dwSubRet = sub_100039D0(dwtmp, m_dw18, m_dw04, (WORD)dwTail, (WORD)dwMod, pBuf);
					dwMod += dwtmp;
					if ( m_dw10 == dwMod )
						dwTail += 16;
					pBuf += dwtmp;
					dwlen = dwSize - dwtmp;
					dwtmp = m_dw0C;
					dwSize = dwlen;
					if ( dwlen < dwtmp )
						dwtmp = dwlen;
					if ( dwSubRet || !sub_10005CF0() )
						break;
					if ( !dwlen )
						return 1;
				}
				return 0;
			}
		}
	}
	return bRet;
}
BOOL CEmbeddedEeprom::sub_10005C90(DWORD a2, void *pDest, DWORD dwSize)
{
	if ( pDest )
	{
		if ( a2 + dwSize <= m_dw08 && a2 < m_dw08 )
		{
			if (sub_10003B30(dwSize,	m_dw04, (WORD)(m_w14 + 2*(a2 / m_dw10)), (WORD)(a2 % m_dw10), m_dw18,pDest) == 0)
			{
				return TRUE;
			}
		}
	}
	return FALSE;
}

BOOL CEmbeddedEeprom::sub_10005D60()
{
	DWORD dwVar = 0;
	DWORD dwVal = 0;
	if ( !sub_10003B30(4, 2, 160, 0, 0, &dwVar)  && dwVar == 0x504D554A) 
	{
		dwVal = 2;
	}
	else if ( !sub_10003B30(4, 0, 160, 0, 0, &dwVar) && dwVar == 0x504D554A)
	{
		dwVal = 0;
	}
	else
	{
		return 0;
	}	
	m_dw04 = dwVal;
	m_dw08 = 0x200;
	m_dw0C = 0x10;
	m_dw10 = 0x100;
	m_w14 = 0xA0;
	m_dw18 = 0;
	return 1;
}
WORD g_word_10015EB0[8] = {8, 0x10, 0x20, 0x40, 0x80, 0x100, 0x200};
DWORD gDWORD_10015EC0[27] = {0,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,-1,30,58,
89,119,150,180,211,242,272,303,333,364,29296};
BOOL CEmbeddedEeprom::sub_10005E60()
{
	DWORD dwflag; 
	WORD wVal; 
	int dwVal; 
	char cDest2[2];
	char cDest6[6];

	dwflag = 1;
	if ( sub_10003B30(2, 0, 160, 1, 1, cDest2) || cDest2[0] != 0x33 || cDest2[1] != 0x50 )
	{
		dwflag = 0;
		if ( sub_10003B30(2, 0, 160, 1, 0, cDest2) || cDest2[0] != 0x33 || cDest2[1] != 0x50)	return 0;
	}
	sub_10003B30(6, 0, 160, 0, dwflag, cDest6);

	int nIdx1 = cDest6[5] >> 5;
	int nIdx2 = cDest6[5] & 0xF;
	if ( nIdx1 > 7 || nIdx2 > 0xD || nIdx2 == 0 ) return 0;
	wVal = g_word_10015EB0[nIdx1];
	dwVal = gDWORD_10015EC0[nIdx2] * 2;
	if ( dwVal && wVal && wVal <= dwVal )
	{
		m_dw04 = 0;
		m_dw08 = dwVal;
		m_dw0C = wVal;
		m_dw10 = 0x10000;
		m_w14 = 0xA0;
		m_dw18 = dwflag;
		return 1;
	}
	return 0;
}

BOOL CEmbeddedEeprom::Init_10005D40(void)
{
	BOOL result; 
	result = sub_10005D60();
	if ( !result )
		return sub_10005E60();
	return result;

}

DWORD CEmbeddedEeprom::sub_10009DE0(void)
{
	return FALSE;
}

