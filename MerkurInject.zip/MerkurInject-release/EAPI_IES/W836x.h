#pragma once
#include "MultiSensor.h"
//#include "EAPI_IES_global.h"

typedef struct tagW836XPARAM_6C //0x4E4
{
	WORD wHeaderlen_0;		//0xD0
	WORD wBodyLen_2;		//0x414
	DWORD pAddrBody_4;		// SMBUSPARAM* + 0xD0
	DWORD pAddHeaderInfo_8;	// SMBUSPARAM* + 0x20
	DWORD dwUnk_C;
	DWORD dwCode_10;
	DWORD dwUnk_14;
	DWORD dwUnk_18;
	DWORD dwUnk_1C;
	DWORD dwPrefixBody_4C;
} W836XPARAM_6C, *LW836XPARAM_6C;

typedef struct tagSMBUSPARAM //0x4E4
{
	WORD wHeaderlen_0;		//0xD0
	WORD wBodyLen_2;		//0x414
	DWORD pAddrBody_4;		// SMBUSPARAM* + 0xD0
	DWORD pAddHeaderInfo_8;	// SMBUSPARAM* + 0x20
	DWORD dwUnk_C;
	DWORD dwCode_10;
	DWORD dwUnk_14;
	DWORD dwUnk_18;
	DWORD dwUnk_1C;
	BYTE  AddInfo_20[0xB0];
	BYTE  Body_D0[0x414];
} SMBUSPARAM, *LPSMBUSPARAM;

class CW836x;
typedef BYTE (__thiscall CW836x:: *CW386_LPFnB_DBP)(DWORD, BYTE, PBYTE);
typedef BYTE (__thiscall CW836x:: *CW386_LPFnB_DBB)(DWORD, BYTE, BYTE);
class CW836x : public CMultiSensor
{

public:

	CW836x();
	BOOL sub_1000B150();
	BOOL sub_1000B2B0(DWORD bySrc, BYTE byVal, BYTE *pDest);
	BOOL sub_1000B370(DWORD bySrc, BYTE byVal,BYTE byParam);
	void sub_1000B070(DWORD OutBuffer, BYTE byParam, BYTE *pDest);
	void sub_1000B0F0(BYTE byArg1, BYTE byArg2, BYTE byArg3);
	WORD sub_10008630();
	BYTE sub_1000AE80();
	BYTE sub_1000AAE0(WORD wArg1);
	BYTE sub_1000ADF0();
	BYTE sub_1000AF00();
	BOOL sub_1000AF70();
	DWORD sub_1000A620();
	DWORD m_dw04;
	WORD m_w08;
	CW386_LPFnB_DBP m_lpFn10;//sub_1000B2B0
	DWORD m_dw14;
	CW386_LPFnB_DBB m_lpFn18;
	DWORD m_dw1C;
	WORD m_w20;
	WORD m_w22;
	
	PBYTE m_pby24;
	BYTE m_by28;
	WORD m_w2A;
	PBYTE m_pby2C;
	BYTE m_by30;
	WORD m_w32;
	PBYTE  m_pby34;
	BYTE m_by38;
	WORD m_w3A;
	DWORD m_dw3C;
	CRITICAL_SECTION m_cs40;
	DWORD m_dw58;
	DWORD m_dw5C;
	DWORD* m_pdw60;
	W836XPARAM_6C* m_pWPARAM64;
	
public:	
	virtual ~CW836x(); //virtual void sub_1000A4D0();
	virtual void sub_1000A480();
	virtual DWORD sub_1000A6B0();
	//virtual DWORD purecall();
	virtual DWORD sub_10006E70(DWORD dwArg);
	virtual DWORD sub_10006EB0(DWORD dwArg1, DWORD dwArg2, PDWORD pdwArg3);
	virtual DWORD sub_10006F00(DWORD dwArg1, DWORD dwArg2, PDWORD pdwArg3, PDWORD pdwArg4);
	virtual DWORD sub_10006F60(DWORD dwArg1, DWORD dwArg2, PDWORD pdwArg3);
	virtual DWORD sub_10006FB0(DWORD dwFlag, DWORD dwArg2, PDWORD pdwArg3);
	virtual DWORD sub_10007000(DWORD dwFlag, DWORD dwArg2, PDWORD pdwArg3);
	virtual DWORD sub_10007050(DWORD dwArg1, DWORD dwArg2, PDWORD pdwArg3);
	virtual BYTE sub_1000A490();
	virtual BYTE sub_1000A4B0();
	virtual BYTE sub_1000A4A0();
	virtual DWORD sub_1000A730(WORD, PDWORD);
	virtual DWORD sub_1000AB50(WORD dwArg1, DWORD *pdwArg2);
	virtual DWORD sub_1000A7E0(WORD dwArg1, DWORD *pdwArg2);
	virtual DWORD sub_1000A860(BYTE byArg1, DWORD *a3, DWORD *a4);
	virtual DWORD sub_1000ABC0(WORD wArg1, DWORD *pdwArg2, DWORD *pdwArg3);
	virtual DWORD sub_1000A8A0(WORD wArg1, DWORD *pdwArg2, DWORD *pdwArg3);
	virtual DWORD sub_1000A900(WORD wArg1, PDWORD pdwArg2);
	virtual DWORD sub_1000AC20(WORD wArg1, PDWORD pdwArg2);
	virtual DWORD sub_10009DE0(DWORD, PDWORD);
	virtual DWORD sub_1000AC60(WORD wArg1, DWORD *pdwArg4);
	virtual DWORD sub_1000A940(WORD wArg1, DWORD *pdwArg2);
	virtual DWORD sub_1000A9A0(WORD wArg1, DWORD *pdwArg2);
	virtual DWORD sub_1000ACE0(WORD wArg1, DWORD *pdwArg2);
	virtual DWORD sub_1000AA00(WORD wArg1, PWORD pdwArg2);
	virtual DWORD sub_1000AD60(WORD wArg1, PDWORD pdwArg2);
	virtual DWORD sub_1000AA90(WORD wArg1, PDWORD pdwArg2);
	virtual LPVOID sub_1000A4D0(LPVOID lpMem, BYTE bFlag);
	virtual void sub_1000B4E0();
};

