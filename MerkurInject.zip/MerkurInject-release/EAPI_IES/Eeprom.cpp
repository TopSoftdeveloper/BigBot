#include "stdafx.h"
#include "Eeprom.h"

CEeprom::CEeprom()
{

}
CEeprom::~CEeprom()
{

}