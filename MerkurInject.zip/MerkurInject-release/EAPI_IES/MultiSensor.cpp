#include "stdafx.h"
#include "MultiSensor.h"


CMultiSensor::CMultiSensor()
{
}


CMultiSensor::~CMultiSensor()
{
}
