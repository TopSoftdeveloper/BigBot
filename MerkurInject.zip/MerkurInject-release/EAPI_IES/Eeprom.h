#pragma once
#include "Storage.h"

class CEeprom : public CStorage
{
public:
	CEeprom();
	virtual ~CEeprom();
public:
	
};

