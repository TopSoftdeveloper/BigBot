#pragma once
#include "MultiSensor.h"
#include "Smbus_Def.h"
class CNCT7802 : public CMultiSensor
{
public:
	CNCT7802();
	~CNCT7802();
public:
	CSmbus_Def* m_pSmbus_Def04;
	BYTE m_by08;
public:

	virtual void sub_1000A480();
	virtual DWORD sub_100052A0();
	virtual void sub_100086B0();
	virtual DWORD sub_10006E70(DWORD i);
	virtual void sub_10006EB0();
	virtual void sub_10006F00();
	virtual void sub_10006F60();
	virtual void sub_10006FB0();
	virtual void sub_10007000();
	virtual void sub_10007050();
	virtual void sub_1000A500();
	virtual void sub_10009010();
	virtual void sub_10009720();
	virtual void sub_100099A0();
	virtual void sub_10009C40();
	virtual void sub_10009840();
	virtual void sub_10009A20();
	virtual void sub_10009CC0();
	virtual void sub_10009890();
	virtual void sub_10009A60();
	virtual DWORD sub_10009DE0();
	virtual void sub_10009A90();
	virtual void sub_100097A0();
	virtual void sub_10009CF0();
	virtual void sub_100097F0();
	virtual void sub_10009B10();
	virtual void sub_100098C0();
	virtual void sub_10009B90();
	virtual void sub_10009D50();
	virtual DWORD sub_10009DF0();
};

