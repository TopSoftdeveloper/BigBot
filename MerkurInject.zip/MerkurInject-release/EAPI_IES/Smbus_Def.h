#pragma once
#include "SmbusInrerface.h"
#include "EAPI_IES_global.h"

class CSmbus_Def : public CSmbusInrerface
{
public:
	CSmbus_Def();
	virtual ~CSmbus_Def();
public:
	CRITICAL_SECTION m_cs_04;
	DWORD m_dw1C;
	FUNCSTRUC10* m_funcstr20;
	SMBUSPARAM* m_lp24;
public:

	virtual DWORD sub_10007EE0();
	virtual void sub_10007F80();
	virtual DWORD sub_10008000(LPCRITICAL_SECTION lpCriticalSection,  BYTE byOpt1,	 BYTE byOpt2,  BYTE* pbybuf,  DWORD dwOut);
	virtual DWORD sub_100081F0(DWORD dwFlag, BYTE byOpt1, BYTE byOpt2, BYTE *pDest, BYTE byLen);
};

