// EAPI_IES.cpp : Defines the exported functions for the DLL application.
//

#include "stdafx.h"
#include "EAPI_IES.h"
#include "EAPI_IES_global.h"
#include "Smbus_Def.h"

EAPI_IES_API int	EApiBoardGetStringA(int nCode, LPVOID lpOutBuffer, DWORD nParam1)
{
	int result; 

	result = 0xFFFFFFFF;
	if ( g_dword_1001ADD8 )
	{
		if ( nParam1 )
		{
			switch ( nCode )
			{
			case 0:
				result = sub_10001EE0((PBYTE)lpOutBuffer,&nParam1);
				break;
			case 1:
			case 6:
				result = sub_100024D0((PBYTE)lpOutBuffer, &nParam1);
				break;
			case 3:
				result = sub_10001F90((PBYTE)lpOutBuffer, &nParam1);
				break;
			case 4:
				result = sub_10002040((PBYTE)lpOutBuffer, &nParam1);
				break;
			case 5:
				result = sub_10001E30((PBYTE)lpOutBuffer, &nParam1);
				break;
			default:
				result = 0xFFFFFCFF;
				break;
			}
		}
		else
		{
			return 0xFFFFFEFF;
		}
	}
	return result;
	
}

EAPI_IES_API int	EApiBoardGetValue(DWORD dwVal, DWORD *pdwBuff)
{
	int result; 
	int nRet1; 
	WORD OutBuffer[3]; 

	result = 0xFFFFFFFF;
	if ( g_dword_1001ADD8 )
	{
		result = 0xFFFFFEFF;
		if ( pdwBuff )
		{
			if ( dwVal > 0x10000 )
			{
				if ( dwVal > 0x21010 )
				{
					if ( dwVal > 0x22000 )
					{
						if ( dwVal == 0x22001 )
							return sub_10002440(pdwBuff, 27);
						if ( dwVal == 0x40001 )
							return sub_100023B0(pdwBuff, 15);
						if ( dwVal == 0x40002 )
							return sub_100023B0(pdwBuff, 14);
					}
					else
					{
						switch ( dwVal )
						{
						case 0x22000:
							return sub_10002440(pdwBuff, 26);
						case 0x21014:
							return sub_100023B0(pdwBuff, 19);
						case 0x21018:
							return sub_100023B0(pdwBuff, 20);
						case 0x2101C:
							return sub_100023B0(pdwBuff, 14);
						}
						
							
					}

					
				}
				else
				{
					if ( dwVal == 0x21010 )
						return sub_100023B0(pdwBuff, 12);
					if ( dwVal > 0x20002 )
					{
						switch ( dwVal )
						{
						case 0x21004:
							return sub_100023B0(pdwBuff, 11);
						case 0x21008:
							return sub_100023B0(pdwBuff, 16);
						case 0x2100C:
							return sub_100023B0(pdwBuff, 17);
						}
					}
					else
					{
						switch ( dwVal )
						{
						case 0x20002:
							return sub_100022F0(4, pdwBuff);
						case 0x10001:
							pdwBuff[0] = 0x1010001;
							return 0;
						case 0x20000:
							return sub_100022F0(1, pdwBuff);
						case 0x20001:
							return sub_100022F0(5, pdwBuff);
						}
					}
				}
				return 0xFFFFFCFF;
			}

			if ( dwVal == 0x10000 )
			{
				result = sub_100031D0((PBYTE)OutBuffer);
				result = sub_100020F0((DWORD)result);
				if ( !result )
					*pdwBuff = OutBuffer[2] | (((OutBuffer[0] << 8) | OutBuffer[1]) << 16);
			}
			else
			{
				switch ( dwVal )
				{
				case 0:
					*pdwBuff = 0x520000;
					result = 0;
					break;
				case 1:
					nRet1 = sub_10003250(pdwBuff);
					result = sub_100020F0(nRet1);
					break;
				case 2:
					nRet1 = sub_100032B0(pdwBuff);
					result = sub_100020F0(nRet1);
					if ( !result )
						*pdwBuff *= 60;
					break;
				case 3:
					*pdwBuff = 0xAD2C;
					result = 0;
					break;
				case 4:
					nRet1 = sub_10003310(3, (PDWORD )OutBuffer, 6, 0);
					result = sub_100020F0(nRet1);
					if ( !result )
						*pdwBuff = OutBuffer[2] | (((OutBuffer[0] << 8) | OutBuffer[1]) << 16);
					break;
				default:
					return 0xFFFFFCFF;
				}
			}
		}
	}
	return result;
}
EAPI_IES_API int	EApiGPIOGetDirection(DWORD dwVal1, DWORD dwVal2, DWORD dwVal3)
{
	int result; 
	DWORD dwTmp; 

	result = -1;
	if ( g_dword_1001ADD8 )
	{
		if ( !dwVal3 )
			return 0xFFFFFEFF;
		if ( dwVal1 == 0x10000 )
		{
			dwTmp = 1168;
			if ( g_pGpioDefaultProxy_1001AD98 )
				g_pGpioDefaultProxy_1001AD98->sub_10007830(dwVal2, dwVal3);// vftable+220
			return sub_100020F0(dwTmp);
		}
		if ( dwVal1 < 0x20 )
		{
			dwTmp = 1168;
			if ( g_pGpioDefaultProxy_1001AD98 )
				g_pGpioDefaultProxy_1001AD98->sub_10007A00(dwVal1,dwVal3);// vftable+28
				
			return sub_100020F0(dwTmp);
		}
		return 0xFFFFFCFF;
	}
	return result;
}
EAPI_IES_API int	EApiGPIOGetDirectionCaps(DWORD dwArg1, DWORD *pdwBuff1, DWORD *pdwBuff2)
{
	int result; 
	DWORD dwRet; 
	DWORD dwOut[10]; 

	result = -1;
	if ( !g_dword_1001ADD8 )
		return result;
	if ( !pdwBuff1 && !pdwBuff2 )
		return 0xFFFFFEFF;
	dwRet = 1168;
	if ( g_pGpioDefaultProxy_1001AD98 )
		dwRet = g_pGpioDefaultProxy_1001AD98->sub_10007520(dwOut);// vftoff = 60
		
	result = sub_100020F0(dwRet);
	if ( !result && dwArg1 >= 0x20 )
	{
		if ( dwArg1 == 0x10000 )
		{
			if ( pdwBuff1 )
				*pdwBuff1 = dwOut[0];
			if ( pdwBuff2 )
				*pdwBuff2 = dwOut[1];
			return 0;
		}
		return 0xFFFFFEFF;
	}
	return result;
}

EAPI_IES_API int	EApiGPIOGetLevel(DWORD dwVal1, DWORD dwVal2, PDWORD pdwVal3)
{
	int result; 
	DWORD dwRet; 

	result = -1;
	if ( g_dword_1001ADD8 )
	{
		if ( !pdwVal3 )
			return 0xFFFFFEFF;
		if ( dwVal1 == 0x10000 )
		{
			dwRet = 1168;
			if ( g_pGpioDefaultProxy_1001AD98 )
				dwRet = g_pGpioDefaultProxy_1001AD98->sub_10007B00(dwVal2, pdwVal3);// off = 36
				
			return sub_100020F0(dwRet);
		}
		if ( dwVal1 < 0x20 )
		{
			dwRet = 1168;
			if ( g_pGpioDefaultProxy_1001AD98 )
				dwRet = g_pGpioDefaultProxy_1001AD98->sub_100077A0(dwVal1, pdwVal3);
				
			return sub_100020F0(dwRet);
		}
		return 0xFFFFFCFF;
	}
	return result;
}
EAPI_IES_API int	EApiGPIOSetDirection(DWORD dwVal1, DWORD dwVal2, PDWORD pdwVal3)
{
	int result; 
	DWORD dwRet; 

	result = -1;
	if ( g_dword_1001ADD8 )
	{
		if ( dwVal1 == 0x10000 )
		{
			dwRet = 1168;
			if ( g_pGpioDefaultProxy_1001AD98 )
				g_pGpioDefaultProxy_1001AD98->sub_10007660(dwVal2, pdwVal3);// off = 16
				
			return sub_100020F0(dwRet);
		}
		if ( dwVal1 < 0x20 )
		{
			dwRet = 1168;
			if ( g_pGpioDefaultProxy_1001AD98 )
				dwRet = g_pGpioDefaultProxy_1001AD98->sub_10007700(dwVal1,pdwVal3);// off = 24
				
			return sub_100020F0(dwRet);
		}
		return 0xFFFFFCFF;
	}
	return result;
}

EAPI_IES_API int	EApiGPIOSetLevel(DWORD dwVal1, DWORD dwVal2, PDWORD pdwVal3)
{
	int result; 
	DWORD dwRet; 

	result = -1;
	if ( g_dword_1001ADD8 )
	{
		if ( dwVal1 == 0x10000 )
		{
			dwRet = 1168;
			if ( g_pGpioDefaultProxy_1001AD98 )
				dwRet = g_pGpioDefaultProxy_1001AD98->sub_100078C0(dwVal2, pdwVal3);// off = 32
				
			return sub_100020F0(dwRet);
		}
		if ( dwVal1 < 0x20 )
		{
			dwRet = 1168;
			if ( g_pGpioDefaultProxy_1001AD98 ) 
				dwRet = g_pGpioDefaultProxy_1001AD98->sub_10007960(dwVal1, pdwVal3);
				
			return sub_100020F0(dwRet);
		}
		return 0xFFFFFCFF;
	}
	return result;
}
EAPI_IES_API int	EApiI2CGetBusCap(DWORD dwVal, DWORD *dwBuff)
{
	int result; 
	DWORD dwRet; 
	
	DWORD OutBuffer; 

	if ( !g_dword_1001ADD8 )
		return -1;
	if ( !dwBuff )
		return 0xFFFFFEFF;
	dwRet = sub_10002240(dwVal);
	dwRet = sub_10003CA0(dwRet, &OutBuffer);
	result = sub_100020F0(dwRet);
	if ( !result )
		*dwBuff = OutBuffer;
	return result;
}
EAPI_IES_API int	EApiI2CProbeDevice(DWORD dwVal1, WORD dwVal2)
{
	int nRet; 
	
	if ( !g_dword_1001ADD8 )
		return -1;
	nRet = sub_10002240(dwVal1);
	nRet = (DWORD)sub_100036F0((DWORD)nRet, dwVal2, 0, 0, 0, 1);
	return sub_100020F0((DWORD)nRet);
}
EAPI_IES_API int	EApiI2CReadTransfer(DWORD dwFlag, SHORT wVal2, int nVal3, void *lpBuff, DWORD dwVal5, DWORD dwVal6)
{
	int nRet; 
	
	nRet = sub_10002240(dwFlag);
	if ( !g_dword_1001ADD8 )
		return -1;

	if ( !lpBuff || !dwVal6 )
		return 0xFFFFFEFF;

	if ( dwVal6 > dwVal5 )
		return 0xFFFFF9FF;

	
	if ( (nVal3 & 0xC0000000) == 0 )
	{
		nRet = sub_10003B30(dwVal6, nRet, wVal2, nVal3, 0, lpBuff);
		return sub_100020F0(nRet);
	}
	if ( (nVal3 & 0xC0000000) == 0x80000000 )
	{
		nRet = sub_10003B30(dwVal6, nRet, wVal2, nVal3, 1, lpBuff);
		return sub_100020F0(nRet);
	}
	if ( (nVal3 & 0xC0000000) != 0x40000000 )
		return 0xFFFFFEFF;

	nRet = sub_100035B0(dwVal6, nRet, wVal2, lpBuff);
	return sub_100020F0(nRet);
}

EAPI_IES_API int	EApiI2CWriteReadRaw(DWORD dwVal1,BYTE bVal2, void *lpVal3, DWORD dwVal4, void *lpVal5, DWORD dwVal6, DWORD dwVal7)
{
	int nRet; 
		
	nRet = sub_10002240(dwVal1);
	if ( !g_dword_1001ADD8 )
		return -1;
	
	if ( dwVal4 > 1 && !lpVal3 )
		return 0xFFFFFEFF;
	
	if ( dwVal7 > 1 && !lpVal5 )
		return 0xFFFFFEFF;

	if ( !dwVal4 && !dwVal7 || dwVal7 > 1 && !dwVal6 )
		return 0xFFFFFEFF;

	if ( dwVal7 > dwVal6 )
		return 0xFFFFF9FF;
	dwVal1 = 0;
	if ( dwVal4 )
		dwVal4 = dwVal4 - 1;
	if ( dwVal7 )
		dwVal7 = dwVal7 - 1;
	nRet = sub_10003820(dwVal7, nRet, bVal2, lpVal3, dwVal4, &dwVal1, lpVal5, 0, 1);

	return sub_100020F0(nRet);
}

EAPI_IES_API int	EApiI2CWriteTransfer(int nVal1, int nVal2, int nVal3, void *Source, int nVal4)
{
	int nRet; 
	
	nRet = sub_10002240(nVal1);
	if ( !g_dword_1001ADD8 )
		return -1;
	if ( !Source || !nVal4 )
		return 0xFFFFFEFF;
	
	if ( (nVal3 & 0xC0000000) == 0 || (nVal3 & 0xC0000000)  == 0x80000000 )
	{
		int nVal4 = 0;

		if((nVal3 & 0xC0000000) == 0) 
			nVal4 = 0;

		if((nVal3 & 0xC0000000)  == 0x80000000 ) 
			nVal4 = 1;

		DWORD ret = sub_100039D0(g_dword_1001ADD8, nVal4, nRet, nVal2, nVal3, Source);

		return sub_100020F0(ret);
	}
	else if ( (nVal3 & 0xC0000000)  == 0x40000000 )
	{
		DWORD ret = sub_100036F0(nRet, nVal2, Source, nVal4, 0, 1);

		return sub_100020F0(ret);
	}
	else
	{
		return 0xFFFFFEFF;
	}
	return 42;
}

EAPI_IES_API int	EApiLibInitialize(void)
{
	int ret;
	ret = sub_10002E30();
	return sub_100020F0(ret);
	
}

EAPI_IES_API DWORD	EApiLibUnInitialize(void)
{
	if(sub_10002F70() != 1)
		return 1;
	return 0;
	
}

EAPI_IES_API int	EApiStorageAreaRead(DWORD fFlag, DWORD dwVal2, void *lpBuff3, DWORD dwVal4, DWORD dwVal5)
{
	DWORD *pdwRet; 

	if ( !g_dword_1001ADD8 )
		return -1;
	if ( fFlag )
		return 0xFFFFFCFF;
	pdwRet = sub_10005AE0((WORD *)g_dword_1001AE20, 0);

	if ( !pdwRet )
		return 0xFFFFFCFF;

	if ( !lpBuff3 || !dwVal5 || !dwVal4 )
		return 0xFFFFFEFF;

	if ( dwVal2 + dwVal5 > pdwRet[4] )
		return 0xFFFFFEFD;

	if ( dwVal5 <= dwVal4 )
		return sub_100056E0((PControlDevice30)pdwRet, lpBuff3, dwVal5, dwVal2) != 0 ? 0 : 0xFFFFFAFF;

	return 0xFFFFF9FF;
}

EAPI_IES_API int	EApiStorageAreaWrite(DWORD dwVal1, DWORD dwVal2, BYTE *pbBuff3, SIZE_T nSize)
{
	DWORD *pdwTmp; 
	
	DWORD dwRet; 

	if ( !g_dword_1001ADD8 )
		return -1;

	if ( dwVal1 )
		return 0xFFFFFCFF;

	pdwTmp = sub_10005AE0((WORD*)g_dword_1001AE20, 0);
	

	if ( !pdwTmp )
		return 0xFFFFFCFF;

	if ( !pbBuff3 || !nSize )
		return 0xFFFFFEFF;

	if ( nSize + dwVal2 > pdwTmp[4] )
		return 0xFFFFFEFD;

	dwRet = sub_10001000((PControlDevice30)pdwTmp);

	if ( nSize % dwRet || dwVal2 % dwRet )
		return 0xFFFFFEFD;
	else
		return sub_100054A0((PControlDevice30)pdwTmp, nSize, dwVal2, (PBYTE)pbBuff3) != 0 ? 0 : 0xFFFFFAFE;
}

EAPI_IES_API int	EApiStorageCap(DWORD dwArg1, DWORD *pdwBuff1, DWORD *pdwBuff2)
{
	DWORD result; // eax
	DWORD dwTmp1; // eax
	DWORD *dwRet; // esi

	result = 0xFFFFFFFF;
	if ( g_dword_1001ADD8 )
	{
		dwTmp1 = 0xFFFFFFFF;
		if ( !dwArg1 )
			dwTmp1 = 0;
		dwRet = sub_10005AE0((WORD *)g_dword_1001AE20, dwTmp1);
		if ( dwRet )
		{
			result = 0xFFFFFEFF;
			if ( pdwBuff1 )
			{
				*pdwBuff1 = dwRet[4];
				result = 0;
			}
			if ( pdwBuff2 )
			{
				*pdwBuff2 = sub_10001000((PControlDevice30)dwRet);
				return 0;
			}
		}
		else
		{
			return 0xFFFFFCFF;
		}
	}
	return result;
}
EAPI_IES_API int	EApiVgaGetBacklightBrightness(DWORD dwFlag, DWORD *pdwBuff)
{
	int result; 
	DWORD dwRet; 
	DWORD dwTmp; 

	dwTmp = 0;
	if ( !g_dword_1001ADD8 )
		return 0xFFFFFFFF;
	if ( !pdwBuff )
		return 0xFFFFFEFF;
	if ( dwFlag )
	{
		if ( dwFlag != 1 )
			return 0xFFFFFCFF;
		dwRet = sub_10004830(&dwTmp, 2);
	}
	else
	{
		dwRet = sub_10004830(&dwTmp, 1);
	}
	result = sub_100020F0(dwRet);
	if ( !result )
		*pdwBuff = dwTmp;
	return result;
}

EAPI_IES_API int	EApiVgaGetBacklightEnable(DWORD dwArg1, DWORD *pdwBuff)
{
	int result; 
	DWORD dwRet; 
	void *lpTmp; 

	
	if ( !g_dword_1001ADD8 )
		return 0xFFFFFFFF;

	if ( !pdwBuff )
		return 0xFFFFFEFF;
	if ( dwArg1 >= 2 )
		return 0xFFFFFCFF;

	lpTmp = NULL;

	dwRet = sub_10004520((DWORD*)&lpTmp);

	result = sub_100020F0(dwRet);

	if ( !result )
		*pdwBuff = (lpTmp != 0) - 1;

	return result;
}

EAPI_IES_API int	EApiVgaSetBacklightBrightness(DWORD dwVal1, DWORD dwVal2)
{
	DWORD dwRet; 
	if ( !g_dword_1001ADD8 )
		return -1;

	if ( dwVal2 > 0xFF )
		return 0xFFFFFEFF;

	if ( dwVal1 )
	{
		if ( dwVal1 == 1 )
		{
			dwRet = sub_100047B0((BYTE)dwVal2, 2);
			return sub_100020F0(dwRet);
		}
		else
		{
			return 0xFFFFFCFF;
		}
	}
	else
	{
		dwRet = sub_100047B0((BYTE)dwVal2, 1);
		return sub_100020F0(dwRet);
	}
}

EAPI_IES_API int	EApiVgaSetBacklightEnable(DWORD dwArg1, DWORD dwArg2)
{
	DWORD dwRet; // eax

	if ( dwArg2 && dwArg2 != -1 )
		return 0xFFFFFEFF;

	if ( dwArg1 >= 2 )
		return 0xFFFFFCFF;

	dwRet = sub_100044B0(dwArg2 == 0);

	return sub_100020F0(dwRet);
}

EAPI_IES_API int	EApiWDogGetCap(DWORD *pdwBuff1, DWORD *pdwBuff2, DWORD *pdwBuff3)
{
	int result; 
	DWORD dwRet; 
	DWORD nTemp[3]; 

	result = -1;
	if ( g_dword_1001ADD8 )
	{
		if ( pdwBuff1 || pdwBuff2 || pdwBuff3 )
		{
			dwRet = sub_10004170(nTemp);
			result = sub_100020F0(dwRet);
			if ( !result )
			{
				if ( pdwBuff1 )
					*pdwBuff1 = nTemp[0];
				if ( pdwBuff2 )
					*pdwBuff2 = nTemp[1];
				if ( pdwBuff3 )
					*pdwBuff3 = nTemp[2];
			}
		}
		else
		{
			return 0xFFFFFEFF;
		}
	}
	return result;
}
EAPI_IES_API int	EApiWDogStart(DWORD dwArg1, DWORD dwArg2, DWORD dwArg3)
{
	int result; 
	DWORD dwRet; 
	DWORD dwTmp1;
	DWORD InBuffer[7];

	result = -1;
	if ( g_dword_1001ADD8 )
	{
		dwTmp1 = 0;
		dwRet = sub_10004280(&dwTmp1);
		if ( sub_100020F0(dwRet) || dwTmp1 )
		{
			return 0xFFFFFEFA;
		}
		else
		{
			InBuffer[0] = dwArg1;
			InBuffer[2] = 1;
			InBuffer[3] = 1;
			InBuffer[1] = dwArg2;
			InBuffer[5] = 2;
			InBuffer[4] = dwArg3;
			InBuffer[6] = 0;
			dwRet = sub_10004090(InBuffer);
			result = sub_100020F0(dwRet);
			if ( !result )
			{
				dwRet = sub_10004210();
				return sub_100020F0(dwRet);
			}
		}
	}
	return result;
}

EAPI_IES_API int	EApiWDogStop(void)
{
	int result; 
	DWORD dwRet; 

	result = -1;
	if ( g_dword_1001ADD8 )
	{
		dwRet = sub_10004310();
		return sub_100020F0(dwRet);
	}
	return result;
}

EAPI_IES_API DWORD	EApiWDogTrigger(void)
{
	DWORD result; 

	result = 0xFFFFFFFF;
	if ( g_dword_1001ADD8 )
		return ((sub_10004100() != 0) ? 0xFFFFF0FF : 0);
	return result;
}
EAPI_IES_API int	KemEApiBeep(DWORD InBuffer, DWORD dwMilliseconds)
{
	DWORD dwRet; 

	if ( !g_dword_1001ADD8 )
		return -1;

	dwRet = sub_10004A30(InBuffer, dwMilliseconds);

	return sub_100020F0(dwRet);
}

EAPI_IES_API int	KemEApiGPIOCancelEvent(void)
{
	int result; // eax

	result = -1;
	if ( g_dword_1001ADD8 )
	{
		CGpioDefaultProxy* pClass = g_pGpioDefaultProxy_1001AD98;
		if ( pClass )
			pClass->sub_10007E20();
		return 0;
	}
	return result;
}
EAPI_IES_API int	KemEApiGPIOGetCaps(DWORD dwArg1, DWORD *pdwBuff)
{
	int result; 
	DWORD dwRet; 
	BOOL fFlag; 
	DWORD Outbuffer[10];
	result = -1;
	if ( g_dword_1001ADD8 )
	{
		if ( !pdwBuff )
			return 0xFFFFFEFF;

		dwRet = 1168;
		if ( g_pGpioDefaultProxy_1001AD98 )
			dwRet = g_pGpioDefaultProxy_1001AD98->sub_10007A90(Outbuffer);
			
		result = sub_100020F0(dwRet);
		if ( !result )
		{
		
			memset(pdwBuff, 0 ,sizeof(DWORD)*10);

			if ( dwArg1 < 0x20 )
			{
				*((BYTE*)pdwBuff + 8) = *((BYTE*)&Outbuffer[2] + dwArg1);
				fFlag = (Outbuffer[1] & (1 << dwArg1)) != 0;
				pdwBuff[0] = (Outbuffer[0] & (1 << dwArg1)) != 0;
				pdwBuff[1] = fFlag;
				return result;
			}
			if ( dwArg1 == 0x10000 )
			{
				
				*pdwBuff = Outbuffer[0];
				pdwBuff[1] = Outbuffer[1];
				memcpy_s(pdwBuff + 2, 0x20, &Outbuffer[2], 0x20);
				return 0;
			}
			return -257;
		}
	}
	return result;
}
EAPI_IES_API int	KemEApiGPIOGetEvent(DWORD dwArg1, DWORD dwArg2, BYTE *pbDest)
{
	int result; 
	DWORD dwRet; 
	BOOL fFlag; 
	
	BYTE OutBuff[36];
	result = -1;
	if ( g_dword_1001ADD8 )
	{
		if ( pbDest )
		{
			if ( dwArg1 == 0x10000 )
			{
				dwRet = 1168;
				dwRet = g_pGpioDefaultProxy_1001AD98->sub_10007BA0((BYTE)dwArg2, &OutBuff[4]);
				
				fFlag = sub_100020F0(dwRet);
				if ( !fFlag )
					memcpy_s(pbDest, 0x20, OutBuff+4, 0x20);
				return fFlag;
			}
			else if ( dwArg1 >= 0x20 )
			{
				return 0xFFFFFCFF;
			}
			else
			{
				dwRet = 1168;
				if(g_pGpioDefaultProxy_1001AD98)
					dwRet = g_pGpioDefaultProxy_1001AD98->sub_10007CD0((BYTE)dwArg1, (PDWORD )OutBuff);
				
				result = sub_100020F0(dwRet);
				if ( !result )
					pbDest[0] = OutBuff[0];
			}
		}
		else
		{
			return 0xFFFFFEFF;
		}
	}
	return result;
}
EAPI_IES_API int	KemEApiGPIOSetEvent(DWORD dwArg1, int dwArg2, DWORD *pdwBuff)
{
	int result; 
	DWORD dwRet; 
	char Destination[32]; 

	result = -1;
	if ( g_dword_1001ADD8 )
	{
		if ( pdwBuff )
		{
			if ( dwArg1 == 0x10000 )
			{
				memcpy_s(Destination, 0x20, pdwBuff, 0x20);
				dwRet = 1168;

				if ( g_pGpioDefaultProxy_1001AD98 )
					dwRet = g_pGpioDefaultProxy_1001AD98->sub_10007B00(dwArg2, (PDWORD)Destination);
					
				return sub_100020F0(dwRet);
			}
			else if ( dwArg1 >= 0x20 )
			{
				return 0xFFFFFCFF;
			}
			else
			{
				dwRet = 1168;
				if ( g_pGpioDefaultProxy_1001AD98 )
					dwRet = g_pGpioDefaultProxy_1001AD98->sub_10007CD0((BYTE)dwArg1, pdwBuff);
				
				return sub_100020F0(dwRet);
			}
		}
		else
		{
			return 0xFFFFFEFF;
		}
	}
	return result;
}

EAPI_IES_API int	KemEApiGPIOWaitOnEvent(DWORD dwArg1, DWORD dwArg2, DWORD dwArg3)
{
	int result; // eax
	DWORD dwRet; // eax

	result = -1;
	if ( g_dword_1001ADD8 )
	{
		dwRet = 1168;
		if ( g_pGpioDefaultProxy_1001AD98 )
			dwRet = g_pGpioDefaultProxy_1001AD98->sub_10007D70((BYTE)dwArg1, &dwArg2, &dwArg3);
			
		return sub_100020F0(dwRet);
	}
	return result;
}

EAPI_IES_API int	KemEApiMuxCaps(PDWORD  pdwOutBuffer)
{
	DWORD dwRet;

	if ( !g_dword_1001ADD8 )
		return -1;

	if ( !pdwOutBuffer )
		return 0xFFFFFEFF;

	dwRet = sub_100049C0(pdwOutBuffer);
	return sub_100020F0(dwRet);
}

EAPI_IES_API int	KemEApiMuxEnable(DWORD InBuffer, DWORD dwFlag)
{
	DWORD dwRet; // eax

	if ( !g_dword_1001ADD8 )
		return -1;
	dwRet = sub_100048D0(InBuffer, dwFlag != 0);
	return sub_100020F0(dwRet);
}

EAPI_IES_API int	KemEApiMuxGetState(LPVOID lpOutBuffer)
{
	DWORD dwRet; 

	if ( !g_dword_1001ADD8 )
		return -1;
	if ( !lpOutBuffer )
		return 0xFFFFFEFF;

	dwRet = sub_10004950(lpOutBuffer);

	return sub_100020F0(dwRet);
}

EAPI_IES_API int	KemEApiPwmGetCaps(DWORD dwArg1, DWORD* pdwBuff)
{
	int result; 
	DWORD dwRet; 

	DWORD dwInBuff[5]; 
	if ( !g_dword_1001ADD8 )
		return 0xFFFFFFFF;
	if ( dwArg1 )
		return 0xFFFFFCFF;
	if ( !pdwBuff )
		return 0xFFFFFEFF;
	dwRet = sub_10004700(dwInBuff);
	result = sub_100020F0(dwRet);
	if ( !result )
	{
		BYTE bFlag = 0;
		if(dwInBuff[4] == 0)
			bFlag = 0;
		else bFlag = 1;
	
		pdwBuff[1] = dwInBuff[1];
		pdwBuff[3] = dwInBuff[3];
		pdwBuff[0] = dwInBuff[0];
		pdwBuff[2] = dwInBuff[2];
		pdwBuff[4] = 2 * bFlag + 1;
	}
	return result;
}

EAPI_IES_API int	KemEApiPwmSetDuty(int dwArg1, DWORD dwInBuffer)
{
	DWORD dwRet;

	if ( !g_dword_1001ADD8 )
		return -1;
	if ( dwArg1 )
		return 0xFFFFFCFF;
	dwRet = sub_100045B0(dwInBuffer);

	return sub_100020F0(dwRet);
}

EAPI_IES_API int	KemEApiPwmSetFrequency(DWORD dwFlag, DWORD dwInBuffer)
{
	DWORD dwRet; 

	if ( !g_dword_1001ADD8 )
		return -1;
	if ( dwFlag )
		return 0xFFFFFCFF;

	dwRet = sub_10004620(dwInBuffer);

	return sub_100020F0(dwRet);
}

EAPI_IES_API int	KemEApiPwmSetPolarity(DWORD dwArg1, DWORD dwArg2)
{
	DWORD dwRet; 

	if ( !g_dword_1001ADD8 )
		return -1;
	if ( dwArg1 )
		return 0xFFFFFCFF;
	if ( dwArg2 >= 2 )
		return 0xFFFFFEFF;
	dwRet = sub_10004690(dwArg2 == 1);
	return sub_100020F0(dwRet);
}

EAPI_IES_API int	KemEApiSmbusQuickRead(DWORD dwOpt)
{
	if ( !g_dword_1001ADD8 )
		return -1;
	if ( g_pCSmbus_Def_1001ADEC )
		return ((((CSmbus_Def*)g_pCSmbus_Def_1001ADEC)->sub_100081F0(3,	(BYTE)dwOpt,	0,	0,	0))!=0) ? 0x80000000 : 0;
		
	return 0xFFFFFCFF;
}

EAPI_IES_API int	KemEApiSmbusQuickWrite(DWORD dwArg1)
{
	if ( !g_dword_1001ADD8 )
		return -1;

	if ( g_pCSmbus_Def_1001ADEC )
		return ((((CSmbus_Def*)g_pCSmbus_Def_1001ADEC)->sub_10008000((LPCRITICAL_SECTION)2,	(BYTE)dwArg1,	0,	0,	0))!=0) ? 0x80000000 : 0;
		
	return 0xFFFFFCFF;
}

EAPI_IES_API int	KemEApiSmbusReadByte(DWORD dwArg1, DWORD dwArg2, DWORD dwArg3)
{
	DWORD dwRet; // eax

	if ( !g_dword_1001ADD8 )
		return -1;
	if ( !g_pCSmbus_Def_1001ADEC )
		return 0xFFFFFCFF;

	if ( g_pCSmbus_Def_1001ADEC )
		dwRet =  ((CSmbus_Def*)g_pCSmbus_Def_1001ADEC)->sub_100081F0(7, (BYTE)dwArg1,	(BYTE)dwArg2,	(PBYTE)&dwArg3,	1);
			
	return sub_100020F0(dwRet);
}
EAPI_IES_API int	KemEApiSmbusReadWord(DWORD dwArg1, DWORD dwArg2, DWORD dwArg3)
{
	DWORD dwRet; // eax

	if ( !g_dword_1001ADD8 )
		return -1;
	if ( !g_pCSmbus_Def_1001ADEC )
		return 0xFFFFFCFF;

	if ( g_pCSmbus_Def_1001ADEC )
		dwRet =  ((CSmbus_Def*)g_pCSmbus_Def_1001ADEC)->sub_100081F0(9, (BYTE)dwArg1,	(BYTE)dwArg2,	(PBYTE)&dwArg3,	2);
	
	return sub_100020F0(dwRet);
}
EAPI_IES_API int	KemEApiSmbusReceiveByte(DWORD dwArg1, DWORD dwArg2)
{
	DWORD dwRet; // eax

	if ( !g_dword_1001ADD8 )
		return -1;
	if ( !g_pCSmbus_Def_1001ADEC )
		return 0xFFFFFCFF;
	if ( g_pCSmbus_Def_1001ADEC )
		dwRet =  ((CSmbus_Def*)g_pCSmbus_Def_1001ADEC)->sub_100081F0(5, (BYTE)dwArg1, 0,	(PBYTE)&dwArg2,	1);
	
	return sub_100020F0(dwRet);
}
EAPI_IES_API int	KemEApiSmbusSendByte(int dwArg2, char dwArg3)
{
	
	BYTE bRet; 

	if ( !g_dword_1001ADD8 )
		return -1;
	if ( !g_pCSmbus_Def_1001ADEC )
		return 0xFFFFFCFF;

	bRet = (BYTE)dwArg3;

	return (((CSmbus_Def*)g_pCSmbus_Def_1001ADEC)->sub_10008000((LPCRITICAL_SECTION)4, dwArg2, 0, &bRet, 1)) != 0 ? 0x80000000 : 0;
}
EAPI_IES_API int	KemEApiSmbusWriteByte(DWORD dwArg1, DWORD dwArg2, BYTE bArg3)
{
	
	DWORD dwRet; 
	BYTE bCode; 

	if ( !g_dword_1001ADD8 )
		return -1;
	if ( !g_pCSmbus_Def_1001ADEC )
		return 0xFFFFFCFF;
	bCode = bArg3;
	dwRet = ((CSmbus_Def*)g_pCSmbus_Def_1001ADEC)->sub_10008000((LPCRITICAL_SECTION)6, (BYTE)dwArg1, (BYTE)dwArg2, &bCode, 1);

	return sub_100020F0(dwRet);
}
EAPI_IES_API int	KemEApiSmbusWriteWord(int dwArg1, int dwArg2, int dwArg3, int dwArg4, WORD wArg5)
{
	
	DWORD dwRet; 
	int dwCode; 
	dwCode = dwArg1;
	if ( !g_dword_1001ADD8 )
		return -1;
	if ( !g_pCSmbus_Def_1001ADEC )
		return 0xFFFFFCFF;
	dwCode = wArg5;
	dwRet = ((CSmbus_Def*)g_pCSmbus_Def_1001ADEC)->sub_10008000((LPCRITICAL_SECTION)8, dwArg3, dwArg4, (PBYTE)&dwCode, 2);

	return sub_100020F0(dwRet);
}

// This is the constructor of a class that has been exported.
// see EAPI_IES.h for the class definition
#if 0
CEAPI_IES::CEAPI_IES()
{
	return;
}
#endif